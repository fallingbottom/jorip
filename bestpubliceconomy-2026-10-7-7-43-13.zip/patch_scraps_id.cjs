const fs = require('fs');
let code = fs.readFileSync('components/PersonalDashboard.tsx', 'utf8');

const target = `      {/* Main Content Area: Favorites List & Detail Modal */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'SCRAPS') && (
      <div className="space-y-6">`;

const replacement = `      {/* Main Content Area: Favorites List & Detail Modal */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'SCRAPS') && (
      <div id="scraps-section" className="space-y-6">`;

code = code.replace(target, replacement);

fs.writeFileSync('components/PersonalDashboard.tsx', code);
