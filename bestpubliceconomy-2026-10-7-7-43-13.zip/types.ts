
export enum BusinessType {
  PRE_STARTUP = 'PRE_STARTUP',
  INDIVIDUAL = 'INDIVIDUAL',
  CORPORATION = 'CORPORATION',
}

export enum Industry {
  MANUFACTURING = 'MANUFACTURING',
  IT_SOFTWARE = 'IT_SOFTWARE',
  RETAIL = 'RETAIL',
  SERVICE = 'SERVICE',
  RESTAURANT = 'RESTAURANT',
  OTHER = 'OTHER',
}

export interface UserProfile {
  name: string;
  gender?: string;
  ageGroup?: string;
  businessName: string;
  businessRegistrationNumber: string;
  businessAddress: string;
  businessType: BusinessType;
  industry: Industry;
  location: string;
  foundedYear: string;
  annualRevenue: number; // In Won
  creditScore: number;
  employees: number;
  fundingNeed: number; // In Won
  businessPhotoUrl?: string;
  expectedProfitMargin: number; // Percentage 0-100
  cashFlowStatus: number; // Score 0-100
  // 부채 내역 추가
  debt1Tier: number; // 1금융권 부채
  debt2Tier: number; // 2금융권 부채
  debtCardLoan: number; // 카드론/캐피탈
  debtOther: number; // 기타 부채
  debtRatio?: number; // 부채 비율 (%) (총부채 / 연매출 * 100)
  hasTaxArrears?: boolean; // 국세/지방세 체납 여부
  hasOverdue?: boolean; // 금융 연체 여부
  applicationHistories?: PolicyApplicationHistory[]; // 과거 정책자금 신청 이력
  isMyDataLinked?: boolean; // 마이데이터 연동 여부
  policyBonusFactors?: PolicyBonusFactors; // 정책적 가점 항목 (스마트공장, 탄소중립 등)
  phoneNumber?: string;
  contactNumber?: string;
  email?: string;
  representativeName?: string;
  businessAge?: number;
}

export interface PolicyBonusFactors {
  hasSmartFactory?: boolean; // 스마트공장·스마트공방·스마트상점 도입 여부
  hasCarbonNeutrality?: boolean; // 탄소중립·친환경 ESG 실천 여부 (서약/에너지절감설비)
  hasJobCreation?: boolean; // 최근 1년 청년 또는 정규직 신규 고용 창출
  hasVentureOrInnoBiz?: boolean; // 이노비즈·메인비즈·벤처기업·특허 보유
  hasCreditEducation?: boolean; // 소진공 지식배움터 신용관리/정책자금 사전교육 이수
  smartFactoryLevel?: 'NONE' | 'SMART_WORKSHOP' | 'BASIC' | 'ADVANCED'; // 스마트공방/기초/고도화
  carbonCertType?: 'NONE' | 'PLEDGE' | 'ENERGY_SAVING' | 'GREEN_CERT'; // 서약/에너지절감설비/녹색인증
}

export interface PolicyBonusItemBreakdown {
  id: string;
  name: string; // e.g. "스마트공장·스마트공방 도입", "탄소중립 실천"
  category: string;
  points: number; // e.g. 10 (%)
  description: string;
  agencyBenefit: string;
  isActive: boolean;
}

export interface PolicyBonusAdjustmentReport {
  baseProbability: number;
  calibratedProbability: number;
  totalBonusUplift: number;
  appliedBonuses: PolicyBonusItemBreakdown[];
  examinerCommitteeImpact: string;
}

export interface PolicyApplicationHistory {
  id: string;
  agency: string; // e.g. '소상공인시장진흥공단', '지역신용보증재단', '신용보증기금', '기술보증기금', '중소벤처기업진흥공단', '시중은행', '기타'
  productName: string; // e.g. '일반경영안정자금', '청년특례보증', '소공인특화자금'
  applyYear: number;
  applyMonth?: number;
  applyAmount: number; // In KRW
  status: 'APPROVED' | 'REJECTED' | 'IN_PROGRESS' | 'ON_HOLD'; // 승인, 부결, 심사중, 보류
  approvedAmount?: number; // In KRW
  remainingBalance?: number; // 현재 남은 대출 잔액 (KRW)
  interestRate?: number; // %
  rejectionReason?: string; // 부결 사유 (예: '신용점수 미달', '보증한도 초과', '부채비율 과다', '동일보증 중복')
  note?: string;
}

export interface PolicyCriteriaCheck {
  criterion: string; // 요건명 (예: "상시 종사자 수", "업종 요건", "부채비율 및 재무건전성", "신용도", "정책자금 신청이력")
  userValue: string; // 사용자 현황 (예: "상시근로자 3인")
  policyRequirement: string; // 정책자금 자격 기준 (예: "5인 미만 (음식점업)")
  status: 'MET' | 'WARNING' | 'FAILED'; // 충족, 주의/조건부, 미충족
  detail: string;
}

export interface PolicyComparisonAnalysis {
  fundId: string;
  fundTitle: string;
  agency: string;
  category: string;
  qualificationStatus: 'ELIGIBLE' | 'CONDITIONAL' | 'INELIGIBLE';
  qualificationStatusLabel: string; // '신청 가능 (적격)' | '조건부 신청 (주의)' | '신청 불가 (부적격)'
  matchScore: number; // 0-100
  estimatedAmount: {
    minAmount: number;
    maxAmount: number;
    recommendedAmount: number;
    formattedAmount: string; // e.g. "최대 5,000만원 (예상: 4,000만원)"
    calculationBasis: string; // 산출 근거
  };
  estimatedInterestRate: {
    baseRate: string;
    expectedRateValue: number;
    formattedRate: string; // e.g. "연 3.35%"
    discountConditions: string[];
    rateType: 'fixed' | 'variable';
  };
  criteriaChecks: PolicyCriteriaCheck[];
  repaymentPeriod: string;
  applicationProcedure: string[];
  requiredDocuments: string[];
  strategicAdvice: string;
  applicationCaution?: string;
  isBudgetLow?: boolean;
  onlineApplyUrl?: string;
}

export interface ComprehensiveEvaluationResult {
  summary: {
    totalEvaluated: number;
    eligibleCount: number;
    conditionalCount: number;
    ineligibleCount: number;
    totalAvailableEstimatedFunding: number;
    averageExpectedRate: number;
    overallBusinessGrade: string;
    debtRatioValue: number;
    debtRatioGrade: 'SAFE' | 'NORMAL' | 'WARNING' | 'HIGH_RISK';
    priorApplicationSummary: string;
  };
  recommendedFunds: PolicyComparisonAnalysis[];
  restrictedOrIneligibleFunds: PolicyComparisonAnalysis[];
  strategicRoadmap: {
    stepNumber: number;
    title: string;
    agency: string;
    actionDescription: string;
    timing: string;
    priority: 'FIRST_CHOICE' | 'SECONDARY' | 'BACKUP';
  }[];
  restrictionAlerts: {
    type: 'WARNING' | 'CRITICAL' | 'INFO';
    title: string;
    message: string;
    solution: string;
  }[];
}

export interface SourcePolicy {
  matchConstraints?: {
    targetIndustries?: string[];
    maxEmployees?: number;
    maxRevenue?: number;
    minFoundedYears?: number;
    maxFoundedYears?: number;
    minCreditScore?: number;
  };
  name: string;
  gender?: string;
  ageGroup?: string;
  agency: string;
  baseInterestRate: string;
  currentStatus: 'OPEN' | 'CLOSED' | 'BUDGET_ALMOST_EXHAUSTED';
  lastUpdated: string;
  startDate?: string;
  endDate?: string;
  announcementDate?: string;
  description?: string;
  eligibility?: string;
  maxAmount?: string;
  repaymentPeriod?: string;
  budgetExhaustionRate?: number;
  applicationProcedure?: string[];
  contactInfo?: string;
  applicationUrl?: string;
  requiredDocuments?: string[];
}

export interface PolicyFund {
  id: string;
  title: string;
  agency: string;
  category: string;
  maxAmount: string;
  estimatedMaxAmount?: string;
  interestRate: string;
  description: string;
  eligibility: string;
  applicationDeadline: string;
  contactInfo: string;
  requiredDocuments: string[];
  applicationUrl?: string;
  currentStatus?: 'OPEN' | 'CLOSED' | 'BUDGET_ALMOST_EXHAUSTED';
  applicationProcedure: string[];
  writingGuide: string;
  announcementDate: string;
  startDate: string;
  endDate: string;
  repaymentPeriod?: string;
  budgetExhaustionRate?: number;
}

export interface AnnouncementRule {
  schema_version: string;
  program_name: string;
  gender?: string;
  ageGroup?: string;
  eligibility: {
    credit_score?: {
      value: number;
      operator: 'lte' | 'gte' | 'range';
    };
    max_business_age_years?: number;
    requires_credit_education?: boolean;
    revenue_drop_rate?: number;
    target_industries?: string[];
    excluded_industries?: string[];
  };
  finance: {
    loan_limit_krw: number;
    rate: {
      type: 'fixed' | 'base_plus';
      value: number;
      description?: string;
    };
    term_years: number;
    grace_years: number;
    channel: 'direct' | 'proxy';
  };
  tags: string[];
}

export interface AnnouncementVersion {
  version: string;
  changedAt: string;
  changedFields: string[];
  snapshotTitle: string;
  summary: string;
}

export interface PolicyAnnouncement {
  id: string;
  title: string;
  agency: string;
  source: string;
  category: string;
  status: 'OPEN' | 'CLOSED' | 'BUDGET_ALMOST_EXHAUSTED';
  reviewStatus: 'pending' | 'approved' | 'rejected';
  isActive: boolean;
  budgetExhaustionRate: number;
  completenessScore: number;
  warnings: string[];
  collectedAt: string;
  lastUpdatedAt: string;
  startDate: string;
  endDate: string;
  maxAmount: string;
  baseInterestRate: string;
  repaymentPeriod: string;
  description: string;
  sourceUrl?: string;
  contactInfo: string;
  rule: AnnouncementRule;
  versions: AnnouncementVersion[];
}

export interface AnalysisResult {
  eligibilityScore: number;
  businessHealth: {
    growthPotential: number;
    financialStability: number;
    creditWorthiness: number;
    policyFit: number;
    innovation: number;
    expectedProfitMargin: number;
    cashFlowStatus: number;
  };
  matchedFunds: PolicyFund[];
  strategicAdvice: string;
  actionPlan: string[];
  approvalFactors?: { factor: string; impact: number }[];
}

export interface SimilarFundRecommendation {
  id: string;
  title: string;
  agency: string;
  category: string;
  maxAmount: string;
  estimatedMaxAmount?: string;
  interestRate: string;
  similarityReason: string;
  matchScore: number;
  eligibility: string;
  applicationDeadline: string;
  description: string;
  contactInfo?: string;
  basedOnFundName: string;
}

export interface PolicyNewsItem {
  id: string;
  title: string;
  summary: string;
  agency: string;
  category: 'FINANCE' | 'SUBSIDY' | 'LOCAL' | 'TAX_REGULATION' | 'GENERAL';
  publishedDate: string;
  locationScope?: string; // e.g. "전국", "서울", "경기도"
  industryScope?: string; // e.g. "전체 업종", "음식점업", "제조업"
  keyBenefits?: string; // e.g. "최대 5천만원 이차보전, 전기요금 최대 20만원 감면"
  businessImpactTip?: string; // AI personalized tip for the user
  sourceUrl?: string;
  sourceTitle?: string;
  isOfficialAnnouncement?: boolean;
}

export interface ChecklistItem {
  id: string;
  title: string;
  description: string;
  category: 'ELIGIBILITY' | 'DOCUMENTS' | 'BONUS_POINTS' | 'DISQUALIFICATION' | 'EXECUTION';
  isChecked: boolean;
  priority: 'HIGH' | 'MEDIUM' | 'LOW';
  issuingAgency?: string;
  tip?: string;
}

export interface FundPdfAnalysis {
  fundTitle: string;
  agency: string;
  announcementTitle: string;
  pdfSummary: string;
  targetFitScore: number;
  keyDeadlines: { phase: string; date: string; description: string }[];
  eligibilityChecklist: ChecklistItem[];
  documentChecklist: ChecklistItem[];
  bonusPointTips: { criterion: string; points: string; howToPrepare: string }[];
  disqualificationRisks: { risk: string; severity: 'CRITICAL' | 'WARNING' | 'INFO'; solution: string }[];
  applicationRoadmap: { step: number; title: string; duration: string; details: string }[];
  officialContact: { department: string; phone: string; website: string };
  extractedFromCustomPdf?: boolean;
}

export interface PolicyNewsResponse {
  newsItems: PolicyNewsItem[];
  searchQueries: string[];
  groundingSources: { title: string; url: string }[];
  lastFetchedAt: string;
  searchSummary: string;
}

export interface ReanalysisFeedback {
  satisfactionRating: number;
  isHelpful: boolean;
  selectedReasons: string[];
  excludedFundIds: string[];
  excludedFundReasons?: Record<string, string>;
  preferredInterestRateMax?: number;
  preferredFundCategory?: string;
  preferredAgency?: string;
  userCustomPrompt?: string;
  createdAt: string;
}

export interface RegionalAvailableFund {
  id: string;
  title: string;
  category: 'STABILITY' | 'GUARANTEE' | 'YOUTH_STARTUP' | 'FACILITY_SMART' | 'REFINANCE' | 'EMERGENCY';
  categoryLabel: string;
  maxAmount: string;
  estimatedMaxAmount?: string;
  interestRate: string;
  targetAudience: string;
  deadline: string;
  status: 'OPEN' | 'CLOSED' | 'BUDGET_ALMOST_EXHAUSTED' | 'URGENT_DEADLINE';
  interestSubsidy?: string;
  requiredDocsSummary?: string;
  repaymentPeriod?: string;
  budgetExhaustionRate?: number;
  originalFundId?: string;
  onlineApplyUrl?: string;
  notice?: string;
}

export interface RegionalFundCenter {
  id: string;
  name: string;
  gender?: string;
  ageGroup?: string;
  agency: string;
  agencyType: 'SEMAS' | 'CREDIT_GUARANTEE' | 'SBC' | 'LOCAL_GOV' | 'KODIT_KIBO';
  address: string;
  region: string; // '서울', '경기', '인천', '부산', '대구', '대전', '광주', '울산', '세종', '강원', '충북', '충남', '전북', '전남', '경북', '경남', '제주'
  coordinates: { lat: number; lng: number };
  phone: string;
  operatingHours: string;
  availableFunds: RegionalAvailableFund[];
  isDirectReception: boolean;
  visitBookingUrl?: string;
  notice?: string;
}

export type ApplicationStage = 
  | 'PREPARING'        // 1단계: 신청 준비 및 자격검토
  | 'DOCS_SUBMITTED'   // 2단계: 서류 제출 완료
  | 'UNDER_REVIEW'     // 3단계: 기관 심사 대기 및 현장실사
  | 'APPROVED'         // 4단계: 승인 완료 / 보증서 발급
  | 'DISBURSED'        // 5단계: 대출 약정 및 자금 수령
  | 'SUPPLEMENT_REQ'   // 보완 요청
  | 'REJECTED';        // 반려 / 중단

export interface PolicyApplicationTrackerItem {
  id: string;
  fundId: string;
  fundTitle: string;
  agency: string;
  stage: ApplicationStage;
  appliedDate: string;
  updatedDate: string;
  targetAmount?: string;
  interestRate?: string;
  applicationNumber?: string; // 접수번호
  assignedBranch?: string; // 담당지점
  officerContact?: string; // 담당관 연락처
  submittedDocs: string[]; // 제출 완료 서류 목록
  notes: { id: string; date: string; content: string }[];
  expectedApprovalDate?: string;
}

export interface FounderAdviceItem {
  number: number;
  title: string;
  detail: string;
  highlightTag: string;
  actionMetric?: string;
}

export interface AiFaqItem {
  id: string;
  category: 'CREDIT' | 'DOCS' | 'PERIOD' | 'LIMIT_RATE' | 'STRATEGY';
  categoryLabel: string;
  question: string;
  aiSummaryAnswer: string;
  keyTakeaway: string;
  confidenceScore: number;
  verifiedAgency: string;
  helpfulCount?: number;
}

export type ApprovalLikelihoodTier = 
  | 'VERY_HIGH'   // 매우 높음 (90% ~ 99%)
  | 'HIGH'        // 높음 (75% ~ 89%)
  | 'MODERATE'    // 보통 (60% ~ 74%)
  | 'LOW'         // 주의/다소 낮음 (40% ~ 59%)
  | 'VERY_LOW';   // 낮음/보완 필수 (< 40%)

export interface ApprovalDimensionMetric {
  id: string;
  dimensionName: string;
  score: number; // 0-100
  cohortBenchmark: number; // 0-100 (과거 승인자 평균)
  minPassThreshold: number; // 0-100 (최소 승인 기준선)
  status: 'EXCELLENT' | 'GOOD' | 'NEEDS_WORK' | 'CRITICAL';
  statusLabel: string;
  weight: number; // percentage in deep learning model
  evaluationReason: string;
}

export interface ImprovementActionItem {
  id: string;
  title: string;
  category: 'DEBT_STRUCTURE' | 'CREDIT_MANAGEMENT' | 'REVENUE_PROOF' | 'LOCAL_QUOTA' | 'BONUS_POINTS' | 'BUSINESS_PLAN';
  categoryLabel: string;
  currentStatus: string;
  recommendedTarget: string;
  actionGuide: string;
  potentialUpliftPercent: number; // e.g. +18 (%)
  priority: 'URGENT' | 'HIGH' | 'MEDIUM';
  estimatedDays: string;
  isAppliedInSimulation?: boolean;
}

export interface MatchedPeerStoryCase {
  id: string;
  businessName: string;
  ownerName: string;
  location: string;
  industryLabel: string;
  fundName: string;
  approvedAmount: string;
  rateReduction: string;
  patternSimilarity: number; // e.g. 96.8 (%)
  keySuccessFactor: string;
  beforeVsAfter: string;
  similarityReasons: string[];
}

export interface DeepLearningApprovalReport {
  fundId: string;
  fundTitle: string;
  agency: string;
  category: string;
  overallProbability: number; // 0 - 100
  tier: ApprovalLikelihoodTier;
  tierLabel: string; // '매우 높음' | '높음' | '보통' | '주의/다소 낮음' | '낮음/보완 필수'
  tierBadgeColor: string;
  summaryVerdict: string;
  examinerReviewOpinion: string;
  dimensions: ApprovalDimensionMetric[];
  matchedPeers: MatchedPeerStoryCase[];
  improvementItems: ImprovementActionItem[];
  keyRiskFactors: string[];
  bonusStrengths: string[];
  policyBonusAdjustment?: PolicyBonusAdjustmentReport; // 정책 가점(스마트공장, 탄소중립 등) 보정 상세
  predictedMaxAmount: string;
  predictedInterestRate: string;
  generatedAt: string;
}



// Admin CRM Types
export interface CrmCustomer {
  id: string;
  displayId: string;
  userId: string;
  ceoName: string;
  businessName: string;
  industryName?: string;
  industryCode?: string;
  businessType?: string;
  province?: string;
  city?: string;
  address?: string;
  openDate?: string;
  employeeCount?: number;
  phone?: string;
  memo?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CrmFinancial {
  id: string;
  userId: string;
  customerId: string;
  year: number;
  vatRevenue?: number;
  cardRevenue?: number;
  cashRevenueEstimate?: number;
  incomeAmount?: number;
  creditScore?: number;
  creditGrade?: string;
  totalLoanBalance?: number;
  bizLoan?: number;
  cardLoan?: number;
  cashAdvance?: number;
  isOverdue?: 'Y' | 'N';
  isTaxArrears?: 'Y' | 'N';
  note?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CrmApplication {
  id: string;
  displayId: string;
  userId: string;
  customerId: string;
  applyDate: string;
  applyType: '직접대출' | '대리대출' | '보증';
  agency: string;
  productName: string;
  applyAmount: number;
  purpose: '운영자금' | '설비투자' | '인테리어' | '기존대출대환' | '세금납부' | '기타';
  status: '승인' | '부결' | '진행중' | '보류';
  approvedAmount?: number;
  interestRate?: number;
  guaranteeRatio?: number;
  reason?: string;
  followUp?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CrmConsultation {
  id: string;
  displayId: string;
  userId: string;
  customerId: string;
  consultDate: string;
  channel: '전화' | '대면' | '카톡' | '이메일' | '기타';
  primaryNeeds: string;
  primaryDiagnosis: string;
  nextStep: string;
  importantNote?: string;
  createdAt: string;
  updatedAt: string;
}
