function parseMaxAmountInWon(str) {
  if (!str) return 0;
  
  // Find all matches of numbers with optional units like "억", "천만", "만"
  // e.g. "1.5억", "7천만원", "70,000,000", "5억원"
  
  const regex = /([\d,\.]+)\s*(억|천만|만|원)?/g;
  let matches;
  let maxVal = 0;
  
  while ((matches = regex.exec(str)) !== null) {
    if (!matches[1]) continue;
    
    let numStr = matches[1].replace(/,/g, '');
    let num = parseFloat(numStr);
    
    if (isNaN(num)) continue;
    
    const unit = matches[2];
    if (unit === '억' || str.slice(regex.lastIndex).startsWith('억원')) {
      num *= 100000000;
    } else if (unit === '천만' || str.slice(regex.lastIndex).startsWith('천만원')) {
      num *= 10000000;
    } else if (unit === '만' || str.slice(regex.lastIndex).startsWith('만원')) {
      num *= 10000;
    } else if (num < 10000 && num > 0) {
      // If it's a small number without unit, it's likely not the amount. 
      // But if no unit, and it's a large number, it's probably raw Won.
      if (num < 1000) continue; 
    }
    
    if (num > maxVal) maxVal = num;
  }
  
  // Also check explicitly for '1억' where '원' is optional
  const regex2 = /([\d\.]+)\s*억/g;
  while ((matches = regex2.exec(str)) !== null) {
      let num = parseFloat(matches[1]) * 100000000;
      if (num > maxVal) maxVal = num;
  }
  
  const regex3 = /([\d\.]+)\s*천만/g;
  while ((matches = regex3.exec(str)) !== null) {
      let num = parseFloat(matches[1]) * 10000000;
      if (num > maxVal) maxVal = num;
  }
  
  const regex4 = /([\d\.]+)\s*만/g;
  while ((matches = regex4.exec(str)) !== null) {
      let num = parseFloat(matches[1]) * 10000;
      if (num > maxVal) maxVal = num;
  }

  return maxVal;
}

console.log(parseMaxAmountInWon("70,000,000")); // 70m
console.log(parseMaxAmountInWon("1억원")); // 100m
console.log(parseMaxAmountInWon("일반형 7천만원, 희망형 1억원, 도약형 2.5억원")); // 250m
console.log(parseMaxAmountInWon("운전 1억원 / 일반형 시설 5억원, 유망형 시설 10억원")); // 1b
console.log(parseMaxAmountInWon("재해 1억원 / 경영애로 70,000,000")); // 100m
console.log(parseMaxAmountInWon("5000만원")); // 50m
