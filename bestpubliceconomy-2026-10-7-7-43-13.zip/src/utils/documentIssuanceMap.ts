export interface DocumentIssuanceInfo {
  id: string;
  name: string;
  agencyName: string;
  agencyCategory: 'HOMETAX' | 'GOV24' | 'SMINFO' | 'INSURANCE' | 'COURT' | 'BANK' | 'CREDIT' | 'GOV_AGENCY' | 'OTHER';
  issuanceUrl: string;
  isOnlineInstant: boolean;
  isFree: boolean;
  costText: string;
  pathGuide: string;
  tip: string;
  recommendedValidity: string;
  badgeColor: string;
}

export interface QuickIssuancePortal {
  id: string;
  name: string;
  description: string;
  url: string;
  iconName: string;
  badge: string;
  color: string;
}

export const QUICK_ISSUANCE_PORTALS: QuickIssuancePortal[] = [
  {
    id: 'hometax',
    name: '국세청 홈택스',
    description: '사업자등록증명, 재무제표, 부가세과표, 국세완납증명',
    url: 'https://www.hometax.go.kr',
    iconName: 'Building2',
    badge: '인터넷 무료 즉시발급',
    color: 'border-blue-200 bg-blue-50/70 text-blue-800'
  },
  {
    id: 'gov24',
    name: '정부24 (Gov.kr)',
    description: '지방세 납세증명서, 주민등록등본/초본, 건축물대장',
    url: 'https://www.gov.kr',
    iconName: 'Building',
    badge: '인터넷 무료 즉시발급',
    color: 'border-emerald-200 bg-emerald-50/70 text-emerald-800'
  },
  {
    id: 'sminfo',
    name: '중소기업현황정보시스템',
    description: '중소기업(소상공인)확인서 발급 및 유효기간 조회',
    url: 'https://sminfo.mss.go.kr',
    iconName: 'Award',
    badge: '필수 우대 증빙',
    color: 'border-indigo-200 bg-indigo-50/70 text-indigo-800'
  },
  {
    id: '4insure',
    name: '4대사회보험 연계센터',
    description: '4대보험 사업장 가입자명부, 가입내역확인서',
    url: 'https://www.4insure.or.kr',
    iconName: 'ShieldCheck',
    badge: '고용인원/가점 증빙',
    color: 'border-purple-200 bg-purple-50/70 text-purple-800'
  },
  {
    id: 'iros',
    name: '대법원 인터넷등기소',
    description: '법인등기부등본(등기사항전부증명서), 부동산등기',
    url: 'http://www.iros.go.kr',
    iconName: 'Layers',
    badge: '법인 필수 서류',
    color: 'border-amber-200 bg-amber-50/70 text-amber-800'
  },
  {
    id: 'semas',
    name: '소상공인 정책자금 포털',
    description: '소진공 직접대출 신청, 대리대출 확인서 발급',
    url: 'https://ols.semas.or.kr',
    iconName: 'ExternalLink',
    badge: '소진공 공식 포털',
    color: 'border-cyan-200 bg-cyan-50/70 text-cyan-800'
  }
];

export const DOCUMENT_ISSUANCE_DATABASE: DocumentIssuanceInfo[] = [
  {
    id: 'doc-business-cert',
    name: '사업자등록증 / 사업자등록증명원',
    agencyName: '국세청 홈택스',
    agencyCategory: 'HOMETAX',
    issuanceUrl: 'https://www.hometax.go.kr',
    isOnlineInstant: true,
    isFree: true,
    costText: '무료 (즉시발급)',
    pathGuide: '홈택스 로그인 > 국세증명·사업자등록·세금관련 신청/신고 > 즉시발급증명 > 사업자등록증명',
    tip: '사업자등록증 사본 또는 최근 1개월 이내 발급된 사업자등록증명원을 제출하세요. 휴·폐업 여부 확인 필수.',
    recommendedValidity: '최근 1개월 이내 발급분',
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-200'
  },
  {
    id: 'doc-financial-statements',
    name: '표준재무제표증명 (재무제표)',
    agencyName: '국세청 홈택스',
    agencyCategory: 'HOMETAX',
    issuanceUrl: 'https://www.hometax.go.kr',
    isOnlineInstant: true,
    isFree: true,
    costText: '무료 (즉시발급)',
    pathGuide: '홈택스 로그인 > 국세증명 > 즉시발급증명 > 표준재무제표증명(개인/법인)',
    tip: '최근 2~3개년 재무상태표 및 손익계산서 일괄 발급. 간편장부 대상자나 신규창업자는 부가세과표증명으로 대체 가능.',
    recommendedValidity: '최근 3개년치 제출',
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-200'
  },
  {
    id: 'doc-vat-cert',
    name: '부가가치세과세표준증명 / 면세수입금액증명',
    agencyName: '국세청 홈택스',
    agencyCategory: 'HOMETAX',
    issuanceUrl: 'https://www.hometax.go.kr',
    isOnlineInstant: true,
    isFree: true,
    costText: '무료 (즉시발급)',
    pathGuide: '홈택스 로그인 > 국세증명 > 즉시발급증명 > 부가가치세 과세표준증명',
    tip: '기업의 실제 매출액과 분기별 현금흐름을 심사하는 핵심 증빙입니다. 최근 1~3년치를 발급받으세요.',
    recommendedValidity: '최근 1~3개년 분기별',
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-200'
  },
  {
    id: 'doc-national-tax-cert',
    name: '국세납세증명서 (국세 완납증명)',
    agencyName: '국세청 홈택스',
    agencyCategory: 'HOMETAX',
    issuanceUrl: 'https://www.hometax.go.kr',
    isOnlineInstant: true,
    isFree: true,
    costText: '무료 (즉시발급)',
    pathGuide: '홈택스 로그인 > 국세증명 > 즉시발급증명 > 납세증명서(국세완납증명)',
    tip: '국세 체납 사실이 없음을 증명합니다. 체납이 있는 경우 심사 즉시 부결되므로 사전 완납 필수. 유효기간(30일) 유의.',
    recommendedValidity: '발급일로부터 30일 유효',
    badgeColor: 'bg-rose-100 text-rose-800 border-rose-200'
  },
  {
    id: 'doc-local-tax-cert',
    name: '지방세 납세증명서 (지방세 완납증명)',
    agencyName: '정부24 (Gov.kr)',
    agencyCategory: 'GOV24',
    issuanceUrl: 'https://www.gov.kr/portal/service/serviceInfo/PTR000050337',
    isOnlineInstant: true,
    isFree: true,
    costText: '무료 (인터넷 즉시)',
    pathGuide: '정부24 로그인 > 자주 찾는 서비스 > 지방세 납세증명서 발급신청',
    tip: '사업장 및 대표자 주소지의 지방세(취득세, 재산세, 주민세 등) 체납 유무를 확인합니다.',
    recommendedValidity: '발급일로부터 30일 유효',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200'
  },
  {
    id: 'doc-sme-cert',
    name: '중소기업·소상공인 확인서',
    agencyName: '중소기업현황정보시스템',
    agencyCategory: 'SMINFO',
    issuanceUrl: 'https://sminfo.mss.go.kr',
    isOnlineInstant: true,
    isFree: true,
    costText: '무료 (온라인 신청)',
    pathGuide: '중소기업현황정보시스템(SMINFO) > 온라인 서류제출 > 확인서 발급신청',
    tip: '소상공인 정책자금 및 우대금리 심사 필수 서류입니다. 유효기간이 1년이므로 최신 상태인지 확인하세요.',
    recommendedValidity: '연간 갱신 (유효기간 내)',
    badgeColor: 'bg-indigo-100 text-indigo-800 border-indigo-200'
  },
  {
    id: 'doc-4insure-cert',
    name: '4대사회보험 가입자 가입내역확인서 (사업장)',
    agencyName: '4대사회보험 정보연계센터',
    agencyCategory: 'INSURANCE',
    issuanceUrl: 'https://www.4insure.or.kr',
    isOnlineInstant: true,
    isFree: true,
    costText: '무료 (즉시발급)',
    pathGuide: '4대보험 정보연계센터 > 증명서 발급 > 가입내역확인서(사업장용)',
    tip: '상시근로자 수 확인 및 일자리 창출 우대 가점 심사에 활용됩니다. 1인 사업자는 가입대상이 아닐 수 있습니다.',
    recommendedValidity: '최근 1개월 이내 발급분',
    badgeColor: 'bg-purple-100 text-purple-800 border-purple-200'
  },
  {
    id: 'doc-4insure-payment',
    name: '4대보험 완납증명서',
    agencyName: '국민건강보험 사회보험통합징수포털',
    agencyCategory: 'INSURANCE',
    issuanceUrl: 'https://si4n.nhis.or.kr',
    isOnlineInstant: true,
    isFree: true,
    costText: '무료 (즉시발급)',
    pathGuide: '사회보험통합징수포털 > 제증명발급 > 완납증명서/납부확인서',
    tip: '건강보험, 국민연금, 고용보험, 산재보험 체납 유무 확인용입니다.',
    recommendedValidity: '발급일로부터 30일 유효',
    badgeColor: 'bg-purple-100 text-purple-800 border-purple-200'
  },
  {
    id: 'doc-resident-cert',
    name: '주민등록표등본 / 초본 (대표자)',
    agencyName: '정부24 (Gov.kr)',
    agencyCategory: 'GOV24',
    issuanceUrl: 'https://www.gov.kr/portal/service/serviceInfo/131000000097',
    isOnlineInstant: true,
    isFree: true,
    costText: '무료 (인터넷 발급)',
    pathGuide: '정부24 > 서비스 > 주민등록표등본(초본) 교부신청',
    tip: '대표자 주민등록번호 뒷자리 포함, 과거 주소변동 이력을 포함하여 발급받는 것이 일반적입니다.',
    recommendedValidity: '최근 1개월 이내 발급분',
    badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200'
  },
  {
    id: 'doc-corporate-cert',
    name: '법인등기사항전부증명서 (법인등기부등본)',
    agencyName: '대법원 인터넷등기소',
    agencyCategory: 'COURT',
    issuanceUrl: 'http://www.iros.go.kr',
    isOnlineInstant: true,
    isFree: false,
    costText: '발급 1,000원 / 열람 700원',
    pathGuide: '대법원 인터넷등기소 > 법인등기 > 발급(전자납부) > 말소사항포함 선택',
    tip: '법인사업자 필수. 반드시 [말소사항 포함] 및 제출용 [발급]으로 출력해야 심사 인정됩니다.',
    recommendedValidity: '최근 1개월 이내 발급분',
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-200'
  },
  {
    id: 'doc-lease-contract',
    name: '사업장 임대차계약서 사본 (또는 부동산등기부등본)',
    agencyName: '자가 보유 / 대법원 인터넷등기소',
    agencyCategory: 'COURT',
    issuanceUrl: 'http://www.iros.go.kr',
    isOnlineInstant: true,
    isFree: false,
    costText: '자가인 경우 열람 700원',
    pathGuide: '임대차계약서 사본 준비 (자가인 경우 대법원 인터넷등기소에서 건물/토지 등기부등본 발급)',
    tip: '확정일자가 날인된 계약서 사본 제출. 전대차인 경우 건물주 전대동의서 첨부 필수.',
    recommendedValidity: '계약기간 유효 확인',
    badgeColor: 'bg-slate-100 text-slate-800 border-slate-200'
  },
  {
    id: 'doc-financial-status',
    name: '금융거래확인서 / 부채증명원',
    agencyName: '주거래 은행 영업점 / 기업인터넷뱅킹',
    agencyCategory: 'BANK',
    issuanceUrl: 'https://www.kfb.or.kr',
    isOnlineInstant: true,
    isFree: false,
    costText: '은행별 2,000~5,000원',
    pathGuide: '주거래은행 기업인터넷뱅킹 > 부가서비스/증명서 > 금융거래확인서 발급',
    tip: '대출 심사일 기준 1개월 이내 기준일로 발급. 모든 거래 금융기관의 대출 및 담보 내역 확인용.',
    recommendedValidity: '최근 1개월 이내 발급분',
    badgeColor: 'bg-teal-100 text-teal-800 border-teal-200'
  },
  {
    id: 'doc-semas-policy-cert',
    name: '소상공인 정책자금 지원대상 확인서',
    agencyName: '소상공인 정책자금 포털',
    agencyCategory: 'GOV_AGENCY',
    issuanceUrl: 'https://ols.semas.or.kr',
    isOnlineInstant: true,
    isFree: true,
    costText: '무료 (온라인 신청 승인 후)',
    pathGuide: '소상공인 정책자금 온라인 사이트(ols.semas.or.kr) > 자금신청 > 확인서 출력',
    tip: '대리대출 승인 후 협약 은행(국민, 신한, 우리, 하나, 농협 등)에 제출하는 정책자금 지원 확인서입니다.',
    recommendedValidity: '발급 후 유효기간 60일',
    badgeColor: 'bg-cyan-100 text-cyan-800 border-cyan-200'
  },
  {
    id: 'doc-venture-cert',
    name: '벤처기업·이노비즈·메인비즈 확인서',
    agencyName: '벤처인 / 이노비즈넷',
    agencyCategory: 'GOV_AGENCY',
    issuanceUrl: 'https://www.smes.go.kr/venturein/',
    isOnlineInstant: true,
    isFree: true,
    costText: '무료 (인증 보유 시)',
    pathGuide: '벤처확인종합관리시스템 또는 이노비즈넷 로그인 후 확인서 재출력',
    tip: '금리 우대(0.1~0.5%p) 및 한도 우대 가점 심사에 결정적인 필수 인증 서류입니다.',
    recommendedValidity: '유효기간 내 인증서',
    badgeColor: 'bg-orange-100 text-orange-800 border-orange-200'
  },
  {
    id: 'doc-patent-cert',
    name: '특허·실용신안·지식재산권 등록원부',
    agencyName: '특허청 특허로',
    agencyCategory: 'GOV_AGENCY',
    issuanceUrl: 'https://www.patent.go.kr',
    isOnlineInstant: true,
    isFree: true,
    costText: '인터넷 무료발급',
    pathGuide: '특허로(patent.go.kr) > 증명서 발급 > 특허(등록)원부 등본 교부',
    tip: '기술평가 및 R&D/운전자금 심사 시 기술력 가점 확보용 증빙 서류입니다.',
    recommendedValidity: '현재 권리 유효 상태',
    badgeColor: 'bg-violet-100 text-violet-800 border-violet-200'
  },
  {
    id: 'doc-export-cert',
    name: '수출실적증명서 / 무역증명',
    agencyName: '한국무역협회 (KITA)',
    agencyCategory: 'GOV_AGENCY',
    issuanceUrl: 'https://www.kita.net',
    isOnlineInstant: true,
    isFree: true,
    costText: '온라인 즉시발급',
    pathGuide: '한국무역협회 또는 무역통계진흥원 > 수출실적증명 발급',
    tip: '수출기업 전용 정책자금 및 글로벌 판로개척 자금 신청 시 가점 서류.',
    recommendedValidity: '최근 1~2년 실적',
    badgeColor: 'bg-sky-100 text-sky-800 border-sky-200'
  }
];

/**
 * Intelligent Document Matcher: Matches any arbitrary document string from policy funds to issuance details
 */
export function matchDocumentToIssuanceInfo(docString: string): DocumentIssuanceInfo {
  const clean = docString.trim().toLowerCase();

  if (clean.includes('사업자등록') || clean.includes('등록증')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-business-cert')!;
  }
  if (clean.includes('재무제표') || clean.includes('손익계산서') || clean.includes('재무상태표') || clean.includes('결산서')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-financial-statements')!;
  }
  if (clean.includes('부가가치세') || clean.includes('부가세') || clean.includes('과세표준') || clean.includes('수입금액')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-vat-cert')!;
  }
  if (clean.includes('국세') || clean.includes('납세증명') || clean.includes('국세완납')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-national-tax-cert')!;
  }
  if (clean.includes('지방세') || clean.includes('세목별') || clean.includes('지방세완납')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-local-tax-cert')!;
  }
  if (clean.includes('소상공인확인서') || clean.includes('중소기업확인서') || clean.includes('소상공인 확인서') || clean.includes('기업확인서')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-sme-cert')!;
  }
  if (clean.includes('4대보험') || clean.includes('4대사회보험') || clean.includes('가입자명부') || clean.includes('고용보험')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-4insure-cert')!;
  }
  if (clean.includes('완납증명') && clean.includes('보험')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-4insure-payment')!;
  }
  if (clean.includes('주민등록') || clean.includes('등본') || clean.includes('초본')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-resident-cert')!;
  }
  if (clean.includes('법인등기') || clean.includes('등기사항전부') || clean.includes('법인인감')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-corporate-cert')!;
  }
  if (clean.includes('임대차') || clean.includes('계약서') || clean.includes('임차') || clean.includes('부동산등기')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-lease-contract')!;
  }
  if (clean.includes('금융거래') || clean.includes('부채증명') || clean.includes('통장거래') || clean.includes('대출잔액')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-financial-status')!;
  }
  if (clean.includes('지원대상확인서') || clean.includes('정책자금확인서') || clean.includes('소진공')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-semas-policy-cert')!;
  }
  if (clean.includes('벤처') || clean.includes('이노비즈') || clean.includes('메인비즈') || clean.includes('여성기업')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-venture-cert')!;
  }
  if (clean.includes('특허') || clean.includes('지식재산') || clean.includes('실용신안') || clean.includes('연구소')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-patent-cert')!;
  }
  if (clean.includes('수출') || clean.includes('무역') || clean.includes('실적증명')) {
    return DOCUMENT_ISSUANCE_DATABASE.find(d => d.id === 'doc-export-cert')!;
  }

  // Generic fallback info with smart defaults
  return {
    id: `custom-doc-${Math.random().toString(36).substring(2, 7)}`,
    name: docString,
    agencyName: '정부24 / 공식 발급기관',
    agencyCategory: 'GOV24',
    issuanceUrl: 'https://www.gov.kr',
    isOnlineInstant: true,
    isFree: true,
    costText: '발급기관 확인 필요',
    pathGuide: '정부24 또는 해당 발급기관 웹사이트에서 온라인 발급 가능',
    tip: '공식 공고문 또는 주관기관(1357)에 구비 요건을 재확인하세요.',
    recommendedValidity: '최근 1개월 이내 발급 권장',
    badgeColor: 'bg-slate-100 text-slate-800 border-slate-200'
  };
}
