export type GovernmentDocType =
  | 'APPLICATION_FORM'       // [별지 제1호 서식] 정책자금 융자/지원 신청서 및 기업현황표
  | 'BUSINESS_PLAN'          // [별지 제2호 서식] 정책자금 사업계획서 및 자금소요·상환계획서
  | 'FUND_USAGE_PLAN'        // [별지 제3호 서식] 시설·운전자금 세부 활용계획서 및 소요명세서
  | 'ASSURANCE_PLEDGE'       // [별지 제4호 서식] 정책자금 신청 자격 자가진단 및 사실확인 확약서
  | 'CEO_PROFILE_STATEMENT'; // [별지 제5호 서식] 대표자 이력 및 사업장 운영 현황 설명서

export interface FundUsageItem {
  id: string;
  itemName: string;
  category: '운전자금' | '시설자금' | '원부자재' | '인건비' | '임차료' | '마케팅' | '설비구입';
  supplier: string;
  amount: number;
  executionMonth: string;
  notes?: string;
}

export interface DraftFormData {
  docType: GovernmentDocType;
  // 문서 행정 정보
  documentNumber: string;
  applicationDate: string;
  targetAgency: string;
  fundName: string;
  submissionYear: string;

  // 기업 기본 정보
  businessName: string;
  businessRegistrationNumber: string;
  corporateRegistrationNumber?: string;
  ceoName: string;
  birthDate?: string;
  businessType: string;
  industryCategory: string;
  mainProduct: string;
  businessAddress: string;
  factoryAddress?: string;
  foundedDate: string;
  contactPhone: string;
  email: string;
  homepage?: string;

  // 재무 및 고용 지표
  annualRevenue: number;
  prevYearRevenue: number;
  twoYearsAgoRevenue: number;
  operatingProfit: number;
  employeeCount: number;
  fullTimeEmployees: number;
  primaryBank: string;
  existingDebtTotal: number;

  // 자금 신청 내역
  requestedAmount: number;
  fundUsageCategory: '운전자금' | '시설자금' | '운전+시설자금';
  preferredTerm: string;
  gracePeriodMonths: number;
  collateralType: '신용보증서' | '부동산담보' | '순수신용' | '기타';

  // 서술형 본문 항목 (표준 양식 필수 항목)
  businessOverview: string;
  marketCompetitiveness: string;
  fundRequirementDetails: string;
  fundUsageSchedule: string;
  salesGrowthPlan: string;
  debtRepaymentPlan: string;
  riskManagementPlan: string;
  ceoExperienceSummary?: string;

  // 자금 활용 상세 품목 표
  fundUsageItems: FundUsageItem[];

  // 법정 확약 및 서약 항목
  pledgeNoBroker: boolean;
  pledgeNoTaxDelinquency: boolean;
  pledgeFactTrue: boolean;
  pledgeRefundOnFalse: boolean;
  pledgeCreditInfoConsent: boolean;

  // 서명 및 날인
  representativeSignatureName: string;
  hasStamp: boolean;
  stampText?: string;
}

export interface StandardDocTemplateMetadata {
  id: GovernmentDocType;
  formNumber: string;
  title: string;
  shortTitle: string;
  authority: string;
  description: string;
  badge: string;
  recommendedFor: string;
}

export const GOVERNMENT_DOC_TEMPLATES: StandardDocTemplateMetadata[] = [
  {
    id: 'APPLICATION_FORM',
    formNumber: '별지 제1호 서식',
    title: '소상공인·중소기업 정책자금 융자신청서 및 기업현황표',
    shortTitle: '융자신청서 & 기업현황표',
    authority: '중소벤처기업부 / 소상공인시장진흥공단 / 중진공',
    description: '기업 일반현황, 재무실적, 신청금액 및 자금용도를 공식 규격에 맞춰 정리하는 기본 필수 신청서',
    badge: '필수 1순위',
    recommendedFor: '모든 정책자금 융자 및 보증 신청 기본 서식'
  },
  {
    id: 'BUSINESS_PLAN',
    formNumber: '별지 제2호 서식',
    title: '정책자금 표준 사업계획서 및 자금소요·상환계획서',
    shortTitle: '표준 사업계획서 & 상환계획서',
    authority: '신용보증재단 / 기술보증기금 / 정책금융기관',
    description: '핵심 제품 경쟁력, 시장성, 자금 소요 내역 및 향후 3개년 매출·원리금 상환 재원 조달 계획',
    badge: '심사 핵심',
    recommendedFor: '대출 심사관 기술평가 및 상환능력 검증용'
  },
  {
    id: 'FUND_USAGE_PLAN',
    formNumber: '별지 제3호 서식',
    title: '시설·운전자금 세부 활용계획서 및 소요명세서',
    shortTitle: '자금세부활용계획서',
    authority: '소상공인시장진흥공단 / 시중 협약은행',
    description: '구입 품목별 단가·견적, 공급처, 집행 예정일 및 사후 증빙(세금계산서) 관리 확약 명세서',
    badge: '용도 증빙',
    recommendedFor: '운전자금 및 기계/인테리어 시설자금 신청 기업'
  },
  {
    id: 'ASSURANCE_PLEDGE',
    formNumber: '별지 제4호 서식',
    title: '정책자금 신청 자격 자가진단 및 사실확인 서약서',
    shortTitle: '신청자격 확인 및 서약서',
    authority: '중소벤처기업진흥공단 / 신용보증재단중앙회',
    description: '불법 제3자 브로커 부당개입 금지, 세금체납 부존재, 허위자료 제출 시 환수 동의 법정 서약',
    badge: '법정 필수',
    recommendedFor: '부결 방지 및 법적 결격사유 사전 자가진단'
  },
  {
    id: 'CEO_PROFILE_STATEMENT',
    formNumber: '별지 제5호 서식',
    title: '대표자 이력 및 사업장 운영 현황 설명서',
    shortTitle: '대표자 이력 & 사업장 현황',
    authority: '지역신용보증재단 / 서민금융진흥원',
    description: '대표자의 동종 업계 실무 경력, 보유 특허/자격증, 사업장 임차 및 설비 운영 현황 보고서',
    badge: '경영자 가점',
    recommendedFor: '초기 창업기업 및 대표자 전문성 가점 확보'
  }
];
