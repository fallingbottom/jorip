const fs = require('fs');
let code = fs.readFileSync('services/geminiService.ts', 'utf8');

const target1 = `    - Address (businessAddress)
    - Date of Opening (foundedYear) - Extract only the year (YYYY)`;

const replacement1 = `    - Address (businessAddress)
    - Date of Opening (foundedYear) - Extract only the year (YYYY)
    - Province/City (location) - Based on the address, determine the major province/city and map exactly to one of these: '서울', '경기', '인천', '부산', '대구', '광주', '대전', '울산', '강원', '충북', '충남', '전북', '전남', '경북', '경남', '제주'.`;

code = code.replace(target1, replacement1);
code = code.replace(target1, replacement1); // there are two instances (image and text)

const schemaTarget1 = `          businessAddress: { type: Type.STRING },
          foundedYear: { type: Type.STRING },`;
const schemaReplacement1 = `          businessAddress: { type: Type.STRING },
          foundedYear: { type: Type.STRING },
          location: { type: Type.STRING },`;

code = code.replace(schemaTarget1, schemaReplacement1);
code = code.replace(schemaTarget1, schemaReplacement1);

fs.writeFileSync('services/geminiService.ts', code);
