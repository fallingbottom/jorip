const fs = require('fs');
let code = fs.readFileSync('services/fundDataSource.ts', 'utf8');

// I will append a map over the return array to add requiredDocuments and applicationUrl dynamically.
const replacement = `
  const funds = [
`;
code = code.replace(/  return \[\n/, replacement);

const returnReplacement = `
  ];

  return funds.map(fund => {
    // Default URL and Documents based on agency
    let applicationUrl = "https://ols.semas.or.kr";
    let requiredDocuments = [
      "사업자등록증명원 (최근 1개월 이내)",
      "부가가치세과세표준증명원 (최근 3개년)",
      "국세 및 지방세 납세증명서",
      "임대차계약서 사본 또는 부동산등기부등본",
      "대표자 신분증 및 주민등록등본"
    ];

    if (fund.agency.includes("기술보증기금")) {
      applicationUrl = "https://www.kibo.or.kr";
      requiredDocuments.push("기술사업계획서");
      requiredDocuments.push("재무제표 (최근 3개년)");
    } else if (fund.agency.includes("서민금융진흥원")) {
      applicationUrl = "https://www.kinfa.or.kr";
      requiredDocuments.push("기초생활수급자/차상위계층 증명서 (해당시)");
    } else if (fund.agency.includes("신용보증기금")) {
      applicationUrl = "https://www.kodit.co.kr";
      requiredDocuments.push("법인등기부등본 (법인인 경우)");
      requiredDocuments.push("주주명부");
    }

    if (fund.name.includes("온라인셀러")) {
      requiredDocuments.push("온라인 쇼핑몰 매출 내역서");
    }

    return {
      ...fund,
      applicationUrl,
      requiredDocuments
    };
  });
};
`;
code = code.replace(/  \];\n\};/, returnReplacement);

fs.writeFileSync('services/fundDataSource.ts', code);
