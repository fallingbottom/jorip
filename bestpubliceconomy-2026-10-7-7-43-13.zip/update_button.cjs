const fs = require('fs');
let code = fs.readFileSync('components/PersonalDashboard.tsx', 'utf8');

const target = `            <button
              onClick={() => window.print()}
              className="sm:hidden print:hidden p-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors"
            >
              <FileText className="w-4 h-4" />
            </button>`;

const replacement = `            <button
              onClick={() => window.print()}
              title="현재 화면을 PDF로 저장하거나 인쇄합니다"
              className="print:hidden p-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors"
            >
              <FileText className="w-4 h-4" />
            </button>`;

code = code.replace(target, replacement);
fs.writeFileSync('components/PersonalDashboard.tsx', code);
