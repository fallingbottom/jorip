import { CrmCustomer, CrmFinancial } from '../types';
import { getCustomers, getFinancials } from './crmService';

export interface FinancialRecommendation {
  sampleCount: number;
  matchedBy: 'industry' | 'businessType' | 'scale' | 'overall';
  matchedCriteriaText: string;
  sourceNote: string;
  revenue: {
    min: number;
    avg: number;
    median: number;
    max: number;
    p25: number;
    p75: number;
    formatted: {
      min: string;
      avg: string;
      median: string;
      max: string;
      p25: string;
      p75: string;
      range: string;
    };
  };
  creditScore: {
    min: number;
    avg: number;
    max: number;
    p25: number;
    p75: number;
    formatted: {
      min: string;
      avg: string;
      max: string;
      p25: string;
      p75: string;
      range: string;
    };
  };
}

export const formatKoreanMoney = (amount: number): string => {
  if (!amount || amount <= 0) return '0원';
  const eok = Math.floor(amount / 100000000);
  const man = Math.floor((amount % 100000000) / 10000);
  
  if (eok > 0 && man > 0) {
    return `${eok}억 ${man.toLocaleString()}만원`;
  } else if (eok > 0) {
    return `${eok}억원`;
  } else {
    return `${man.toLocaleString()}만원`;
  }
};

// Benchmark priors by industry keyword
interface BenchmarkPrior {
  category: string;
  keywords: string[];
  indivRevenue: { min: number; avg: number; max: number; p25: number; p75: number };
  corpRevenue: { min: number; avg: number; max: number; p25: number; p75: number };
  creditScore: { min: number; avg: number; max: number; p25: number; p75: number };
}

const INDUSTRY_BENCHMARKS: BenchmarkPrior[] = [
  {
    category: '외식/음식점업',
    keywords: ['음식', '식당', '카페', '커피', '제과', '베이커리', '주점', '외식', '치킨', '한식', '중식', '일식', '양식', '분식'],
    indivRevenue: { min: 60000000, p25: 110000000, avg: 165000000, p75: 240000000, max: 450000000 },
    corpRevenue: { min: 200000000, p25: 350000000, avg: 520000000, p75: 750000000, max: 1500000000 },
    creditScore: { min: 640, p25: 695, avg: 730, p75: 785, max: 860 }
  },
  {
    category: '도소매/유통/전자상거래',
    keywords: ['도매', '소매', '유통', '쇼핑몰', '온라인', '스마트스토어', '이커머스', '무역', '슈퍼', '마트', '의류', '잡화'],
    indivRevenue: { min: 80000000, p25: 150000000, avg: 240000000, p75: 380000000, max: 800000000 },
    corpRevenue: { min: 300000000, p25: 600000000, avg: 950000000, p75: 1500000000, max: 3000000000 },
    creditScore: { min: 660, p25: 710, avg: 745, p75: 800, max: 880 }
  },
  {
    category: '제조업/뿌리산업/소공인',
    keywords: ['제조', '공장', '가공', '기계', '부품', '금속', '화학', '인쇄', '식품제조', '금형', '생산'],
    indivRevenue: { min: 150000000, p25: 280000000, avg: 450000000, p75: 700000000, max: 1400000000 },
    corpRevenue: { min: 500000000, p25: 900000000, avg: 1500000000, p75: 2400000000, max: 5000000000 },
    creditScore: { min: 680, p25: 730, avg: 765, p75: 820, max: 910 }
  },
  {
    category: 'IT/소프트웨어/정보통신',
    keywords: ['it', '소프트웨어', '개발', '앱', '웹', '정보통신', '솔루션', 'ai', '빅데이터', '플랫폼', '보안'],
    indivRevenue: { min: 100000000, p25: 180000000, avg: 310000000, p75: 480000000, max: 900000000 },
    corpRevenue: { min: 400000000, p25: 800000000, avg: 1350000000, p75: 2200000000, max: 4500000000 },
    creditScore: { min: 700, p25: 755, avg: 785, p75: 840, max: 940 }
  },
  {
    category: '전문/교육/생활서비스업',
    keywords: ['서비스', '학원', '교육', '미용', '헤어', '헬스', '피트니스', '컨설팅', '세무', '법무', '광고', '디자인', '세탁', '차량정비'],
    indivRevenue: { min: 50000000, p25: 90000000, avg: 140000000, p75: 210000000, max: 400000000 },
    corpRevenue: { min: 200000000, p25: 380000000, avg: 600000000, p75: 950000000, max: 2000000000 },
    creditScore: { min: 670, p25: 720, avg: 750, p75: 810, max: 890 }
  },
  {
    category: '건설/인테리어/설비',
    keywords: ['건설', '인테리어', '설비', '토목', '전기', '도장', '배관', '창호', '샤시'],
    indivRevenue: { min: 120000000, p25: 220000000, avg: 380000000, p75: 580000000, max: 1200000000 },
    corpRevenue: { min: 400000000, p25: 750000000, avg: 1250000000, p75: 2000000000, max: 4000000000 },
    creditScore: { min: 660, p25: 705, avg: 740, p75: 795, max: 870 }
  }
];

const DEFAULT_BENCHMARK = {
  category: '소상공인 전체 일반',
  indivRevenue: { min: 70000000, p25: 120000000, avg: 180000000, p75: 260000000, max: 550000000 },
  corpRevenue: { min: 250000000, p25: 450000000, avg: 750000000, p75: 1200000000, max: 2500000000 },
  creditScore: { min: 650, p25: 700, avg: 740, p75: 800, max: 880 }
};

export interface CustomerFinancialPair {
  customer: CrmCustomer;
  financial: CrmFinancial;
}

// In-memory cache for all customer financials to prevent repeated roundtrips
let cachedPairs: CustomerFinancialPair[] | null = null;
let lastFetchTime = 0;

export const fetchAllCustomerFinancials = async (forceRefresh = false): Promise<CustomerFinancialPair[]> => {
  const now = Date.now();
  if (!forceRefresh && cachedPairs && now - lastFetchTime < 60000) {
    return cachedPairs;
  }

  try {
    const customers = await getCustomers();
    const pairs: CustomerFinancialPair[] = [];

    // Fetch financials in batches
    await Promise.all(
      customers.map(async (customer) => {
        try {
          const fins = await getFinancials(customer.id);
          if (fins && fins.length > 0) {
            // Pick most recent year or highest valid record
            pairs.push({ customer, financial: fins[0] });
          }
        } catch {
          // ignore individual fetch errors
        }
      })
    );

    cachedPairs = pairs;
    lastFetchTime = now;
    return pairs;
  } catch (err) {
    console.error('Failed to fetch all customer financials:', err);
    return [];
  }
};

export interface CalculateRecommendationParams {
  industryName?: string;
  businessType?: string; // '개인사업자' | '법인'
  province?: string;
  employeeCount?: number;
  existingPairs?: CustomerFinancialPair[];
}

export const calculateFinancialRecommendation = (
  params: CalculateRecommendationParams
): FinancialRecommendation => {
  const { industryName = '', businessType = '개인사업자', employeeCount = 0, existingPairs = [] } = params;
  const isCorp = businessType === '법인';

  // 1. Detect matching industry benchmark prior
  const searchInd = industryName.trim().toLowerCase();
  let matchedBenchmark = INDUSTRY_BENCHMARKS.find(b => 
    b.keywords.some(kw => searchInd.includes(kw.toLowerCase())) ||
    searchInd.includes(b.category.toLowerCase())
  );

  const benchmarkCategory = matchedBenchmark ? matchedBenchmark.category : DEFAULT_BENCHMARK.category;
  const priorRev = matchedBenchmark 
    ? (isCorp ? matchedBenchmark.corpRevenue : matchedBenchmark.indivRevenue)
    : (isCorp ? DEFAULT_BENCHMARK.corpRevenue : DEFAULT_BENCHMARK.indivRevenue);
  const priorCredit = matchedBenchmark ? matchedBenchmark.creditScore : DEFAULT_BENCHMARK.creditScore;

  // Scale adjustment if employee count is high
  const scaleMultiplier = employeeCount > 10 ? 1.8 : employeeCount > 4 ? 1.3 : 1.0;

  // 2. Filter existing CRM pairs for relevant empirical data
  let matchedPairs = existingPairs.filter(p => {
    const cust = p.customer;
    if (isCorp && cust.businessType !== '법인') return false;
    if (!isCorp && cust.businessType === '법인') return false;

    if (searchInd && cust.industryName) {
      const cInd = cust.industryName.toLowerCase();
      const hasIndMatch = searchInd.split(/[\s,]+/).some(token => token.length > 1 && cInd.includes(token)) ||
                          cInd.split(/[\s,]+/).some(token => token.length > 1 && searchInd.includes(token));
      return hasIndMatch;
    }
    return true;
  });

  let matchedBy: FinancialRecommendation['matchedBy'] = 'overall';
  let matchedCriteriaText = '';

  if (matchedPairs.length > 0 && searchInd) {
    matchedBy = 'industry';
    matchedCriteriaText = `동종 업종(${benchmarkCategory}) 및 ${businessType} 데이터`;
  } else if (matchedPairs.length > 0) {
    matchedBy = 'businessType';
    matchedCriteriaText = `${businessType} 기존 고객 데이터`;
  } else if (existingPairs.length > 0) {
    matchedPairs = existingPairs;
    matchedBy = 'overall';
    matchedCriteriaText = `전체 등록 고객 및 ${benchmarkCategory} 표준 통계`;
  } else {
    matchedBy = 'overall';
    matchedCriteriaText = `${benchmarkCategory} 소상공인·중소기업 표준 데이터`;
  }

  // 3. Extract actual values if available
  const actualRevs = matchedPairs
    .map(p => p.financial.vatRevenue)
    .filter((v): v is number => typeof v === 'number' && v > 0);
  
  const actualCredits = matchedPairs
    .map(p => p.financial.creditScore)
    .filter((v): v is number => typeof v === 'number' && v > 0);

  // 4. Calculate blended revenue
  let revMin = Math.round(priorRev.min * scaleMultiplier);
  let revMax = Math.round(priorRev.max * scaleMultiplier);
  let revAvg = Math.round(priorRev.avg * scaleMultiplier);
  let revP25 = Math.round(priorRev.p25 * scaleMultiplier);
  let revP75 = Math.round(priorRev.p75 * scaleMultiplier);
  let revMed = revAvg;

  if (actualRevs.length >= 2) {
    actualRevs.sort((a, b) => a - b);
    const actMin = actualRevs[0];
    const actMax = actualRevs[actualRevs.length - 1];
    const actAvg = Math.round(actualRevs.reduce((a, b) => a + b, 0) / actualRevs.length);
    const actMed = actualRevs[Math.floor(actualRevs.length / 2)];
    const actP25 = actualRevs[Math.floor(actualRevs.length * 0.25)];
    const actP75 = actualRevs[Math.floor(actualRevs.length * 0.75)];

    // Blend actual (70%) with benchmark (30%)
    revMin = Math.round(actMin * 0.7 + revMin * 0.3);
    revMax = Math.round(actMax * 0.7 + revMax * 0.3);
    revAvg = Math.round(actAvg * 0.7 + revAvg * 0.3);
    revMed = Math.round(actMed * 0.7 + revMed * 0.3);
    revP25 = Math.round(actP25 * 0.7 + revP25 * 0.3);
    revP75 = Math.round(actP75 * 0.7 + revP75 * 0.3);
  } else if (actualRevs.length === 1) {
    revAvg = Math.round(actualRevs[0] * 0.6 + revAvg * 0.4);
    revMed = revAvg;
  }

  // 5. Calculate blended credit score
  let credMin = priorCredit.min;
  let credMax = priorCredit.max;
  let credAvg = priorCredit.avg;
  let credP25 = priorCredit.p25;
  let credP75 = priorCredit.p75;

  if (actualCredits.length >= 2) {
    actualCredits.sort((a, b) => a - b);
    const actMin = actualCredits[0];
    const actMax = actualCredits[actualCredits.length - 1];
    const actAvg = Math.round(actualCredits.reduce((a, b) => a + b, 0) / actualCredits.length);
    const actP25 = actualCredits[Math.floor(actualCredits.length * 0.25)];
    const actP75 = actualCredits[Math.floor(actualCredits.length * 0.75)];

    credMin = Math.round(actMin * 0.6 + credMin * 0.4);
    credMax = Math.round(actMax * 0.6 + credMax * 0.4);
    credAvg = Math.round(actAvg * 0.7 + credAvg * 0.3);
    credP25 = Math.round(actP25 * 0.6 + credP25 * 0.4);
    credP75 = Math.round(actP75 * 0.6 + credP75 * 0.4);
  } else if (actualCredits.length === 1) {
    credAvg = Math.round(actualCredits[0] * 0.6 + credAvg * 0.4);
  }

  // Ensure credit scores are within valid 300~1000 range
  credMin = Math.max(300, Math.min(credMin, 950));
  credMax = Math.max(credMin, Math.min(credMax, 1000));
  credAvg = Math.max(credMin, Math.min(credAvg, credMax));

  const sampleCount = matchedPairs.length;
  const sourceNote = sampleCount > 0
    ? `기존 CRM 고객 데이터 ${sampleCount}건 + 중기부·소진공 ${benchmarkCategory} 통계 기반`
    : `중기부·소진공 2026 ${benchmarkCategory} 통계 및 업종 표준 기반`;

  return {
    sampleCount,
    matchedBy,
    matchedCriteriaText,
    sourceNote,
    revenue: {
      min: revMin,
      avg: revAvg,
      median: revMed,
      max: revMax,
      p25: revP25,
      p75: revP75,
      formatted: {
        min: formatKoreanMoney(revMin),
        avg: formatKoreanMoney(revAvg),
        median: formatKoreanMoney(revMed),
        max: formatKoreanMoney(revMax),
        p25: formatKoreanMoney(revP25),
        p75: formatKoreanMoney(revP75),
        range: `${formatKoreanMoney(revP25)} ~ ${formatKoreanMoney(revP75)}`
      }
    },
    creditScore: {
      min: credMin,
      avg: credAvg,
      max: credMax,
      p25: credP25,
      p75: credP75,
      formatted: {
        min: `${credMin}점`,
        avg: `${credAvg}점`,
        max: `${credMax}점`,
        p25: `${credP25}점`,
        p75: `${credP75}점`,
        range: `${credP25}점 ~ ${credP75}점`
      }
    }
  };
};
