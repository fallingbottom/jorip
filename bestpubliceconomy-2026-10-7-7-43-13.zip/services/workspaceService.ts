import { 
  collection, 
  doc, 
  addDoc, 
  getDocs, 
  updateDoc, 
  deleteDoc, 
  query, 
  orderBy, 
  serverTimestamp 
} from 'firebase/firestore';
import { db } from './firebaseService';

// Firestore Error handler interface and logger (as required per Firebase Skill)
enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null, userId: string) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: { userId },
    operationType,
    path
  };
  console.error('Firestore Permission Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// -----------------------------------------------------------------
// 1. Firebase Firestore - BizKeep Notes CRUD
// -----------------------------------------------------------------
export interface KeepNote {
  id?: string;
  userId: string;
  title: string;
  content: string;
  color: string; // Tailwind bg color class
  isPinned: boolean;
  createdAt: any;
  updatedAt: any;
}

export const fetchKeepNotes = async (userId: string): Promise<KeepNote[]> => {
  const path = `users/${userId}/keepNotes`;
  try {
    const q = query(collection(db, path), orderBy('isPinned', 'desc'), orderBy('updatedAt', 'desc'));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    } as KeepNote));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path, userId);
    return [];
  }
};

export const createKeepNote = async (userId: string, note: Omit<KeepNote, 'userId' | 'createdAt' | 'updatedAt'>): Promise<string> => {
  const path = `users/${userId}/keepNotes`;
  try {
    const docRef = await addDoc(collection(db, path), {
      ...note,
      userId,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    return docRef.id;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path, userId);
    return '';
  }
};

export const updateKeepNote = async (userId: string, noteId: string, updates: Partial<KeepNote>): Promise<void> => {
  const path = `users/${userId}/keepNotes/${noteId}`;
  try {
    const docRef = doc(db, `users/${userId}/keepNotes`, noteId);
    await updateDoc(docRef, {
      ...updates,
      updatedAt: serverTimestamp()
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path, userId);
  }
};

export const deleteKeepNote = async (userId: string, noteId: string): Promise<void> => {
  const path = `users/${userId}/keepNotes/${noteId}`;
  try {
    const docRef = doc(db, `users/${userId}/keepNotes`, noteId);
    await deleteDoc(docRef);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path, userId);
  }
};

// -----------------------------------------------------------------
// 1.1 Firebase Firestore - Consultation Inquiries CRUD
// -----------------------------------------------------------------
export interface ConsultationInquiryDoc {
  id?: string;
  userId: string;
  fundTitle: string;
  fundAgency: string;
  fundMaxAmount?: string;
  fundInterestRate?: string;
  applicantName: string;
  businessName: string;
  contactNumber: string;
  email: string;
  preferredChannel?: 'CALL' | 'VIDEO' | 'CHAT' | string;
  preferredDate?: string;
  preferredTimeSlot?: string;
  inquiryCategory?: string;
  inquiryDetails?: string;
  googleFormUrl?: string;
  submittedVia: 'google_forms' | 'direct';
  status: 'PENDING' | 'ASSIGNED' | 'CONFIRMED';
  assignedExpert?: {
    name: string;
    role: string;
    agencyExperience: string;
  };
  createdAt: any;
  updatedAt?: any;
}

export const fetchUserConsultations = async (userId: string): Promise<ConsultationInquiryDoc[]> => {
  const path = `users/${userId}/consultations`;
  try {
    const q = query(collection(db, path), orderBy('createdAt', 'desc'));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(d => ({
      id: d.id,
      ...d.data()
    } as ConsultationInquiryDoc));
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path, userId);
    return [];
  }
};

export const saveUserConsultation = async (
  userId: string, 
  data: Omit<ConsultationInquiryDoc, 'userId' | 'createdAt' | 'updatedAt'>
): Promise<string> => {
  const path = `users/${userId}/consultations`;
  try {
    const docRef = await addDoc(collection(db, path), {
      ...data,
      userId,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    return docRef.id;
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path, userId);
    return '';
  }
};

export const deleteUserConsultation = async (userId: string, consultationId: string): Promise<void> => {
  const path = `users/${userId}/consultations/${consultationId}`;
  try {
    const docRef = doc(db, `users/${userId}/consultations`, consultationId);
    await deleteDoc(docRef);
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path, userId);
  }
};

export const updateUserConsultationStatus = async (
  userId: string, 
  consultationId: string, 
  status: 'PENDING' | 'ASSIGNED' | 'CONFIRMED'
): Promise<void> => {
  const path = `users/${userId}/consultations/${consultationId}`;
  try {
    const docRef = doc(db, `users/${userId}/consultations`, consultationId);
    await updateDoc(docRef, {
      status,
      updatedAt: serverTimestamp()
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path, userId);
  }
};

// -----------------------------------------------------------------
// 2. Google Drive API (Folder, List, Upload)
// -----------------------------------------------------------------
export interface DriveFile {
  id: string;
  name: string;
  mimeType: string;
  createdTime: string;
  size?: string;
  webViewLink?: string;
}

export const fetchDriveFiles = async (token: string, searchTerm: string = ''): Promise<DriveFile[]> => {
  let q = "trashed = false";
  if (searchTerm) {
    q += ` and name contains '${searchTerm}'`;
  }
  
  const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id,name,mimeType,createdTime,size,webViewLink)&orderBy=modifiedTime desc&pageSize=30`;
  
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` }
  });
  
  if (!res.ok) {
    throw new Error(`Drive list failed: ${res.statusText}`);
  }
  
  const data = await res.json();
  return data.files || [];
};

export const saveReportToDrive = async (token: string, fileName: string, content: string): Promise<string> => {
  // Multimodal file creation in Drive using basic metadata mapping
  const metadata = {
    name: fileName,
    mimeType: 'text/plain',
  };
  
  const form = new FormData();
  form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
  form.append('file', new Blob([content], { type: 'text/plain; charset=utf-8' }));
  
  const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}` },
    body: form
  });
  
  if (!res.ok) {
    throw new Error(`Drive upload failed: ${res.statusText}`);
  }
  
  const data = await res.json();
  return data.id;
};

// Helper to fetch file content from Google Drive
export const downloadDriveFileText = async (token: string, fileId: string): Promise<string> => {
  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  
  if (!res.ok) {
    throw new Error(`Failed to download Drive file content`);
  }
  
  return await res.text();
};


// -----------------------------------------------------------------
// 3. Gmail API (Send Email, Sync Emails)
// -----------------------------------------------------------------
export interface FundingEmail {
  id: string;
  sender: string;
  subject: string;
  date: string;
  snippet: string;
}

// UTF-8 Clean Base64 Encoder for Web-Safe Email Payloads
const base64UrlSafe = (str: string): string => {
  const base64 = btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, (_, p1) => {
    return String.fromCharCode(parseInt(p1, 16));
  }));
  return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
};

export const sendGmailReport = async (token: string, to: string, subject: string, htmlContent: string) => {
  // Construct email in RFC 2822 format
  const emailLines = [
    `To: ${to}`,
    `Subject: =?utf-8?B?${btoa(encodeURIComponent(subject).replace(/%([0-9A-F]{2})/g, (_, p1) => String.fromCharCode(parseInt(p1, 16))))}?=`,
    'MIME-Version: 1.0',
    'Content-Type: text/html; charset=utf-8',
    'Content-Transfer-Encoding: base64',
    '',
    // Base64 encode the HTML body
    btoa(encodeURIComponent(htmlContent).replace(/%([0-9A-F]{2})/g, (_, p1) => String.fromCharCode(parseInt(p1, 16))))
  ];
  
  const rawMessage = emailLines.join('\r\n');
  const safeRaw = base64UrlSafe(rawMessage);
  
  const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ raw: safeRaw })
  });
  
  if (!res.ok) {
    const errorDetails = await res.text();
    throw new Error(`Gmail send error: ${errorDetails}`);
  }
};

// Sync Inbox: Searches for recent funding emails
export const syncFundingEmails = async (token: string): Promise<FundingEmail[]> => {
  const queryParam = "소상공인 OR 정책자금 OR 정부지원 OR 창업대출";
  const url = `https://gmail.googleapis.com/gmail/v1/users/me/messages?q=${encodeURIComponent(queryParam)}&maxResults=5`;
  
  const res = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` }
  });
  
  if (!res.ok) {
    throw new Error('Gmail synchronization failed.');
  }
  
  const listData = await res.json();
  if (!listData.messages || listData.messages.length === 0) {
    return [];
  }
  
  const emailResults: FundingEmail[] = [];
  
  for (const msg of listData.messages) {
    const msgRes = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${msg.id}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    
    if (msgRes.ok) {
      const msgData = await msgRes.json();
      const headers = msgData.payload.headers;
      const subject = headers.find((h: any) => h.name.toLowerCase() === 'subject')?.value || '(제목 없음)';
      const fromHeader = headers.find((h: any) => h.name.toLowerCase() === 'from')?.value || '알 수 없음';
      const dateHeader = headers.find((h: any) => h.name.toLowerCase() === 'date')?.value || '';
      
      let cleanDate = dateHeader;
      try {
        const parsedDate = new Date(dateHeader);
        cleanDate = parsedDate.toLocaleDateString('ko-KR', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
      } catch (e) {}

      emailResults.push({
        id: msg.id,
        sender: fromHeader,
        subject,
        date: cleanDate,
        snippet: msgData.snippet || ''
      });
    }
  }
  
  return emailResults;
};


// -----------------------------------------------------------------
// 4. Google Sheets API (Export)
// -----------------------------------------------------------------
export const createFundingGoogleSheet = async (token: string, title: string, headers: string[], rows: string[][]): Promise<string> => {
  const body = {
    properties: { title: title },
    sheets: [
      {
        properties: { title: '정책자금 분석' },
        data: [
          {
            startRow: 0,
            startColumn: 0,
            rowData: [
              // Header row
              {
                values: headers.map(h => ({
                  userEnteredValue: { stringValue: h },
                  userEnteredFormat: {
                    textFormat: { bold: true },
                    backgroundColor: { red: 0.9, green: 0.95, blue: 1.0 } // Soft Blue
                  }
                }))
              },
              // Value rows
              ...rows.map(row => ({
                values: row.map(cell => ({
                  userEnteredValue: { stringValue: cell }
                }))
              }))
            ]
          }
        ]
      }
    ]
  };
  
  const res = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });
  
  if (!res.ok) {
    throw new Error('Sheets creation failed');
  }
  
  const resultData = await res.json();
  return resultData.spreadsheetUrl;
};


// -----------------------------------------------------------------
// 5. Google Slides API (Export Presentation)
// -----------------------------------------------------------------
export const createWorkspaceSlideshow = async (token: string, presentationTitle: string, userProfile: any, analysisResult: any): Promise<string> => {
  // A. Create the base presentation
  const createRes = await fetch('https://slides.googleapis.com/v1/presentations', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ title: presentationTitle })
  });
  
  if (!createRes.ok) {
    throw new Error('Slides creation failed');
  }
  
  const pData = await createRes.json();
  const presentationId = pData.presentationId;
  
  // B. Run batch updates to add beautiful slides
  const requests: any[] = [];
  
  // Slide 1: Pitch Title Slide (Already exists as default first slide, we just edit it)
  // Let's customize page elements if we can, but a simpler, 100% reliable approach is to add NEW custom slides and delete the raw default slide later, or write on it. 
  // Let's create new slides to ensure precise ID matching!
  
  const addSlide = (slideId: string) => ({
    createSlide: {
      objectId: slideId,
      insertionIndex: 1,
      slideLayoutReference: { predefinedLayout: 'TITLE_AND_BODY' }
    }
  });

  const addTextRequest = (slideId: string, titleId: string, bodyId: string, titleText: string, bodyText: string) => [
    {
      createShape: {
        objectId: titleId,
        shapeType: 'TEXT_BOX',
        elementProperties: {
          pageId: slideId,
          size: { width: { magnitude: 600, unit: 'PT' }, height: { magnitude: 80, unit: 'PT' } },
          transform: { scaleX: 1, scaleY: 1, translateX: 50, translateY: 30, unit: 'PT' }
        }
      }
    },
    {
      insertText: {
        objectId: titleId,
        text: titleText
      }
    },
    {
      createShape: {
        objectId: bodyId,
        shapeType: 'TEXT_BOX',
        elementProperties: {
          pageId: slideId,
          size: { width: { magnitude: 600, unit: 'PT' }, height: { magnitude: 280, unit: 'PT' } },
          transform: { scaleX: 1, scaleY: 1, translateX: 50, translateY: 120, unit: 'PT' }
        }
      }
    },
    {
      insertText: {
        objectId: bodyId,
        text: bodyText
      }
    }
  ];

  // 1. Slide: Company Profile (기업 진단 현황)
  requests.push(addSlide('slide_profile'));
  requests.push(...addTextRequest(
    'slide_profile', 'title_profile', 'body_profile',
    '1. 우리 기업 진단 현황',
    `■ 상호명: ${userProfile.businessName || '미지정'}\n` +
    `■ 대표자: ${userProfile.name || '미지정'}\n` +
    `■ 소재지 / 설립연도: ${userProfile.location} / ${userProfile.foundedYear}년\n` +
    `■ 직원수: ${userProfile.employees}명\n` +
    `■ 연간 매출액: ${new Intl.NumberFormat('ko-KR').format(userProfile.annualRevenue)}원\n` +
    `■ 종합 부양도 / 신용 점수: ${analysisResult.eligibilityScore}점 / ${userProfile.creditScore}점\n` +
    `■ 신청 대상 필터링: 필요 자금 ${new Intl.NumberFormat('ko-KR').format(userProfile.fundingNeed)}원`
  ));

  // 2. Slide: Matching Report (추천 정책자금 목록)
  const fundsText = analysisResult.matchedFunds.map((f: any, i: number) => 
    `[추천 ${i+1}] ${f.title} (${f.agency})\n` +
    `  - 한도/금리: ${f.maxAmount} / ${f.interestRate}\n` +
    `  - 자격 조건: ${f.eligibility.substring(0, 100)}...`
  ).join('\n\n');

  requests.push(addSlide('slide_matching'));
  requests.push(...addTextRequest(
    'slide_matching', 'title_matching', 'body_matching',
    '2. 맞춤 추천 정책자금 상세 목록',
    fundsText
  ));

  // 3. Slide: Strategy (AI 추천 핵심 전략)
  requests.push(addSlide('slide_strategy'));
  requests.push(...addTextRequest(
    'slide_strategy', 'title_strategy', 'body_strategy',
    '3. AI 경영 전략 코멘트 및 실행 계획',
    `▶ 종합 경영 소견:\n` +
    `${analysisResult.strategicAdvice}\n\n` +
    `▶ 핵심 단계별 실행 계획:\n` +
    analysisResult.actionPlan.map((p: string, i: number) => `  ${i+1}. ${p}`).join('\n')
  ));

  const updateRes = await fetch(`https://slides.googleapis.com/v1/presentations/${presentationId}:batchUpdate`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ requests })
  });

  if (!updateRes.ok) {
    console.error('Failed to populate Google Slides content');
  }
  
  return `https://docs.google.com/presentation/d/${presentationId}/edit`;
};

// -----------------------------------------------------------------
// 6. Google Docs API (Export Document)
// -----------------------------------------------------------------
export const createWorkspaceDocument = async (token: string, docTitle: string, userProfile: any, analysisResult: any): Promise<string> => {
  // A. Create a blank Google Document
  const createRes = await fetch('https://docs.googleapis.com/v1/documents', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ title: docTitle })
  });
  
  if (!createRes.ok) {
    const errorDetails = await createRes.text();
    throw new Error(`Docs creation failed: ${errorDetails}`);
  }
  
  const docData = await createRes.json();
  const documentId = docData.documentId;
  
  // B. Construct elegant structural layout text
  const dateStr = new Date().toLocaleDateString('ko-KR', { year: 'numeric', month: 'long', day: 'numeric' });
  
  const contentText = 
    `BizMatch AI - 소상공인 정책자금 종합 진단 보고서\n` +
    `발행일: ${dateStr}\n` +
    `--------------------------------------------------\n\n` +
    `■ 1. 우리 기업 기본 진단 현황\n` +
    `  - 상호명: ${userProfile.businessName || '미지정'}\n` +
    `  - 대표자: ${userProfile.name || '미지정'}\n` +
    `  - 소재지 / 설립연도: ${userProfile.location || '미지정'} / ${userProfile.foundedYear || '미지정'}년\n` +
    `  - 종업원 수: ${userProfile.employees || 0}명\n` +
    `  - 연간 매출액: ${new Intl.NumberFormat('ko-KR').format(userProfile.annualRevenue || 0)}원\n` +
    `  - 종합 신용 점수: ${userProfile.creditScore || 0}점\n` +
    `  - 희망 필요 자금액: ${new Intl.NumberFormat('ko-KR').format(userProfile.fundingNeed || 0)}원\n\n` +
    `■ 2. AI 정책자금 종합 평가 점수\n` +
    `  - 종합 분석 적합도: ${analysisResult.eligibilityScore || 0} 점\n\n` +
    `■ 3. AI 맞춤형 경영 분석 조언\n` +
    `  ${analysisResult.strategicAdvice || '정보가 존재하지 않습니다.'}\n\n` +
    `■ 4. 추천 단계별 핵심 실행 계획\n` +
    (analysisResult.actionPlan || []).map((p: string, i: number) => `  ${i+1}. ${p}`).join('\n') + `\n\n` +
    `■ 5. 맞춤 매칭 완료된 지원 사업 목록 (총 ${analysisResult.matchedFunds?.length || 0}건)\n` +
    `--------------------------------------------------\n` +
    (analysisResult.matchedFunds || []).map((f: any, idx: number) => 
      `[지원사업 ${idx+1}] ${f.title}\n` +
      `  - 지원 기관: ${f.agency}\n` +
      `  - 지원 카테고리: ${f.category}\n` +
      `  - 최대한도 지원: ${f.maxAmount}\n` +
      `  - 이율/기한: ${f.interestRate} / ${f.deadline}\n` +
      `  - 자격 조건 설명: ${f.eligibility}\n` +
      `  - 문의 및 안내처: ${f.contactInfo || '해당 주관기관 담당부서'}\n`
    ).join('\n') +
    `\n\n--------------------------------------------------\n` +
    `* 본 보고서는 BizMatch AI 및 Google Workspace 지능형 클라우드 통합 서비스를 바탕으로 실시간 진단 및 동기화되어 발행되었습니다.`;

  // C. Execute batchUpdate to write text (at index 1)
  const updateRes = await fetch(`https://docs.googleapis.com/v1/documents/${documentId}:batchUpdate`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      requests: [
        {
          insertText: {
            location: { index: 1 },
            text: contentText
          }
        }
      ]
    })
  });
  
  if (!updateRes.ok) {
    const errorDetails = await updateRes.text();
    console.error('Failed to fill Google Document content:', errorDetails);
  }
  
  return `https://docs.google.com/document/d/${documentId}/edit`;
};

// -----------------------------------------------------------------
// 7. Google Calendar API (Fetch & Schedule Events)
// -----------------------------------------------------------------
export interface CalendarEvent {
  id: string;
  summary: string;
  description?: string;
  start: {
    dateTime?: string;
    date?: string;
  };
  end: {
    dateTime?: string;
    date?: string;
  };
  htmlLink?: string;
}

export const fetchUpcomingEvents = async (token: string): Promise<CalendarEvent[]> => {
  const timeMin = new Date().toISOString();
  const url = `https://www.googleapis.com/calendar/v3/calendars/primary/events?timeMin=${encodeURIComponent(timeMin)}&orderBy=startTime&singleEvents=true&maxResults=10`;
  
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`
    }
  });
  
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Calendar list failed: ${errText}`);
  }
  
  const data = await res.json();
  return data.items || [];
};

export const createCalendarEvent = async (
  token: string, 
  summary: string, 
  description: string, 
  startDateTime: string, 
  endDateTime: string
): Promise<string> => {
  const url = 'https://www.googleapis.com/calendar/v3/calendars/primary/events';
  
  const body = {
    summary,
    description,
    start: {
      dateTime: startDateTime,
      timeZone: 'Asia/Seoul'
    },
    end: {
      dateTime: endDateTime,
      timeZone: 'Asia/Seoul'
    }
  };
  
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });
  
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Calendar event creation failed: ${errText}`);
  }
  
  const data = await res.json();
  return data.htmlLink || 'https://calendar.google.com';
};

// -----------------------------------------------------------------
// 8. Google Forms API (Create Survey Forms, Read Form Details & Responses)
// -----------------------------------------------------------------
export interface GoogleFormInfo {
  formId: string;
  title: string;
  description?: string;
  responderUri: string;
  editUri: string;
  revisionId?: string;
  createdAt?: string;
}

export interface GoogleFormQuestionItem {
  id?: string;
  title: string;
  description?: string;
  required?: boolean;
  type: 'TEXT' | 'PARAGRAPH' | 'RADIO' | 'CHECKBOX' | 'SCALE';
  options?: string[];
}

export interface FormResponseAnswer {
  questionId: string;
  questionTitle?: string;
  textAnswers: string[];
}

export interface FormResponseEntry {
  responseId: string;
  createTime: string;
  lastSubmittedTime: string;
  respondentEmail?: string;
  answers: Record<string, FormResponseAnswer>;
}

/**
 * Creates a blank Google Form and returns its metadata
 */
export const createBaseGoogleForm = async (
  token: string, 
  title: string, 
  documentTitle?: string
): Promise<{ formId: string; responderUri: string; editUri: string; revisionId: string }> => {
  const url = 'https://forms.googleapis.com/v1/forms';
  
  const body = {
    info: {
      title: title,
      documentTitle: documentTitle || title
    }
  };
  
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });
  
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Google Forms creation failed: ${errText}`);
  }
  
  const data = await res.json();
  const formId = data.formId;
  const responderUri = data.responderUri || `https://docs.google.com/forms/d/e/${formId}/viewform`;
  const editUri = `https://docs.google.com/forms/d/${formId}/edit`;
  
  return {
    formId,
    responderUri,
    editUri,
    revisionId: data.revisionId || ''
  };
};

/**
 * Updates form items/questions in batch
 */
export const updateGoogleFormItems = async (
  token: string, 
  formId: string, 
  items: GoogleFormQuestionItem[],
  formDescription?: string
): Promise<void> => {
  const url = `https://forms.googleapis.com/v1/forms/${formId}:batchUpdate`;
  
  const requests: any[] = [];
  
  // 1. Update form description if provided
  if (formDescription) {
    requests.push({
      updateFormInfo: {
        info: {
          description: formDescription
        },
        updateMask: 'description'
      }
    });
  }
  
  // 2. Add question items
  items.forEach((item, index) => {
    const questionItemObj: any = {
      title: item.title,
      description: item.description || ''
    };
    
    if (item.type === 'TEXT') {
      questionItemObj.questionItem = {
        question: {
          required: !!item.required,
          textQuestion: {
            paragraph: false
          }
        }
      };
    } else if (item.type === 'PARAGRAPH') {
      questionItemObj.questionItem = {
        question: {
          required: !!item.required,
          textQuestion: {
            paragraph: true
          }
        }
      };
    } else if (item.type === 'RADIO') {
      questionItemObj.questionItem = {
        question: {
          required: !!item.required,
          choiceQuestion: {
            type: 'RADIO',
            options: (item.options || ['예', '아니오']).map(opt => ({ value: opt })),
            shuffle: false
          }
        }
      };
    } else if (item.type === 'CHECKBOX') {
      questionItemObj.questionItem = {
        question: {
          required: !!item.required,
          choiceQuestion: {
            type: 'CHECKBOX',
            options: (item.options || ['해당 사항 없음']).map(opt => ({ value: opt })),
            shuffle: false
          }
        }
      };
    } else if (item.type === 'SCALE') {
      questionItemObj.questionItem = {
        question: {
          required: !!item.required,
          scaleQuestion: {
            low: 1,
            high: 5,
            lowLabel: '매우 불만족/부족',
            highLabel: '매우 만족/완벽'
          }
        }
      };
    }
    
    requests.push({
      createItem: {
        item: questionItemObj,
        location: {
          index: index
        }
      }
    });
  });
  
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ requests })
  });
  
  if (!res.ok) {
    const errText = await res.text();
    console.warn('Batch update for Google Form had errors:', errText);
  }
};

/**
 * 1. Creates a Policy Fund Eligibility Self-Assessment Form
 */
export const createPolicyAssessmentForm = async (
  token: string, 
  userProfile?: any, 
  targetFundTitle?: string
): Promise<GoogleFormInfo> => {
  const title = targetFundTitle 
    ? `[BizMatch] ${targetFundTitle} 신청 자격 사전 자가진단표` 
    : `[BizMatch AI] 소상공인 정책자금 신청 적격성 사전 자가진단 설문`;
    
  const base = await createBaseGoogleForm(token, title);
  
  const questions: GoogleFormQuestionItem[] = [
    {
      title: '사업체 기본 정보 (대표자 성명 및 상호명)',
      description: userProfile?.businessName ? `현재 프로필: ${userProfile.businessName} (${userProfile.name})` : '사업자등록증 상의 대표자 성명과 상호명을 입력해 주세요.',
      type: 'TEXT',
      required: true
    },
    {
      title: '사업자 유형 및 과세 형태',
      type: 'RADIO',
      required: true,
      options: [
        '개인사업자 (간이과세자)',
        '개인사업자 (일반과세자)',
        '법인사업자 (중소기업)',
        '예비창업자 (사업자 등록 예정)'
      ]
    },
    {
      title: '대표자 NICE / KCB 신용평점 구간',
      description: '정책자금 심사 시 신용평점은 주요 대출 금리 및 지원 한도 결정 요소입니다.',
      type: 'RADIO',
      required: true,
      options: [
        '840점 이상 (우량 신용 / 일반 1금융권 연계 가능)',
        '750점 ~ 839점 (중상위 신용 / 소진공 및 지자체 특례보증 유리)',
        '600점 ~ 749점 (중저신용 / 취약 소상공인 특별자금 대상)',
        '600점 미만 (저신용 / 재도약·대환 특례 프로그램 권장)'
      ]
    },
    {
      title: '필요 자금 용도 및 지원 유형',
      type: 'CHECKBOX',
      required: true,
      options: [
        '운전자금 (인건비, 원부자재 매입, 매장 임대료 등)',
        '시설자금 (설비 자동화, 기계 설비 구입, 인테리어 개선)',
        '대환대출 (2금융권·카드론 등 7% 이상 고금리 채무 저금리 전환)',
        '스마트화·R&D 지원 (디지털 전환, 키오스크/테이블오더, 스마트공방)',
        '청년 창업 및 초기 사업화 자금'
      ]
    },
    {
      title: '희망 필요 자금액 (원 단위 또는 만원 단위)',
      description: '예: 5,000만원, 1억원 등',
      type: 'TEXT',
      required: true
    },
    {
      title: '최근 1개년 매출 추이 및 국세·지방세 체납 여부',
      type: 'RADIO',
      required: true,
      options: [
        '체납 없음 / 전년 대비 매출 증가세',
        '체납 없음 / 전년 대비 매출 유지 (±10% 이내)',
        '체납 없음 / 전년 대비 매출 10%~30% 감소 (경영위기 특례 대상)',
        '체납 없음 / 전년 대비 매출 30% 이상 급감 (긴급 경영안정자금 대상)',
        '현재 세금 분납 중이거나 체납 해소 예정'
      ]
    },
    {
      title: '희망 대출 만기 및 거치기간',
      type: 'RADIO',
      required: false,
      options: [
        '5년 (2년 거치, 3년 분할상환)',
        '7년 이상 (장기 시설자금)',
        '3년 이내 단기 일시상환',
        '상관 없음 (승인 확률 최우선)'
      ]
    },
    {
      title: '기타 문의사항 또는 사전 심사 시 소명할 특이사항',
      description: '특허 보유, 벤처/이노비즈 인증, 고용 증가 실적 등이 있다면 기재해 주세요.',
      type: 'PARAGRAPH',
      required: false
    }
  ];
  
  const description = `본 설문지는 소상공인 정책자금 매칭 AI(BizMatch AI)와 Google Workspace가 연동되어 발행한 사전 자가진단서입니다.\n제출된 정보는 정책자금 심사 적격성 평가 및 최적 한도 산출에만 안전하게 활용됩니다.`;
  
  await updateGoogleFormItems(token, base.formId, questions, description);
  
  return {
    formId: base.formId,
    title,
    description,
    responderUri: base.responderUri,
    editUri: base.editUri,
    createdAt: new Date().toISOString()
  };
};

/**
 * 2. Creates a 1:1 Expert Consultation Intake Form
 */
export const createConsultationIntakeForm = async (
  token: string, 
  businessName?: string
): Promise<GoogleFormInfo> => {
  const title = `[BizMatch] 1:1 비대면 정책자금 수석 전문상담 접수 신청서`;
  const base = await createBaseGoogleForm(token, title);
  
  const questions: GoogleFormQuestionItem[] = [
    {
      title: '신청자 성명 및 상호명',
      description: businessName ? `상호: ${businessName}` : '',
      type: 'TEXT',
      required: true
    },
    {
      title: '연락 가능한 전화번호 및 이메일',
      description: '상담 일정 조율 및 사전 안내 링크가 발송됩니다.',
      type: 'TEXT',
      required: true
    },
    {
      title: '상담 희망 일시 및 시간대',
      type: 'RADIO',
      required: true,
      options: [
        '평일 오전 (09:00 ~ 12:00)',
        '평일 오후 (13:00 ~ 18:00)',
        '평일 야간 (18:00 ~ 20:00 - 야간 집중상담)',
        '주말/공휴일 비대면 상담 희망'
      ]
    },
    {
      title: '가장 궁금하거나 해결하고 싶은 핵심 과제',
      type: 'CHECKBOX',
      required: true,
      options: [
        '소상공인시장진흥공단 직접대출 vs 대리대출 신청 경로 선택',
        '지역신용보증재단 특례보증서 발급 가능 한도 및 이율 최적화',
        '사업계획서 작성 및 AI 가점 서류 무결성 검토',
        '2금융권 고금리 대출 대환(갈아타기) 자금 신청 가이드',
        '정책자금 부결 이력 후 재도전 전략'
      ]
    },
    {
      title: '사전 준비 완료된 증빙 서류 현황',
      type: 'CHECKBOX',
      required: false,
      options: [
        '사업자등록증명원 (최근 1개월 이내)',
        '부가가치세과세표준증명원 (최근 3개년)',
        '국세 및 지방세 납세증명서 (체납 없음 확인)',
        '4대보험 사업장 가입자 명부',
        '온라인 신용관리 교육 이수증 (소진공 0.1%p 우대용)'
      ]
    },
    {
      title: '전문위원에게 전달할 추가 요청사항',
      type: 'PARAGRAPH',
      required: false
    }
  ];
  
  const description = `소상공인 정책자금 전문 경영지도사 및 정책자금 심사역과의 1:1 비대면 집중 상담을 위한 사전 접수 양식입니다.`;
  await updateGoogleFormItems(token, base.formId, questions, description);
  
  return {
    formId: base.formId,
    title,
    description,
    responderUri: base.responderUri,
    editUri: base.editUri,
    createdAt: new Date().toISOString()
  };
};

/**
 * 3. Creates a Customer / Beneficiary Feedback Form
 */
export const createCustomerFeedbackForm = async (
  token: string
): Promise<GoogleFormInfo> => {
  const title = `[BizMatch AI] 정책자금 매칭 서비스 만족도 및 사후 관리 설문`;
  const base = await createBaseGoogleForm(token, title);
  
  const questions: GoogleFormQuestionItem[] = [
    {
      title: 'AI 정책자금 추천 결과의 정확도 및 유용성',
      type: 'SCALE',
      required: true
    },
    {
      title: '가장 만족스러웠던 기능',
      type: 'CHECKBOX',
      required: true,
      options: [
        '5단계 딥러닝 승인 확률 진단 및 시뮬레이터',
        '서류 발급 가이드 및 홈택스/정부24 바로가기',
        'Google Workspace (Drive, Sheets, Slides, Calendar) 클라우드 연동',
        '신용점수 향상 및 맞춤형 대환대출 안내',
        '실시간 정책자금 속보 및 알림'
      ]
    },
    {
      title: '정책자금 실제 신청 및 승인 결과',
      type: 'RADIO',
      required: false,
      options: [
        '신청 완료 후 현재 심사 대기 중',
        '최종 승인 완료되어 자금 수령 완료',
        '서류 보완 요청 후 재접수 준비 중',
        '추후 적절한 시기에 신청 예정'
      ]
    },
    {
      title: '향후 개선 희망 사항 및 자유 의견',
      type: 'PARAGRAPH',
      required: false
    }
  ];
  
  const description = `BizMatch AI 서비스를 이용해주셔서 감사합니다. 더 나은 소상공인 지원 서비스를 위해 소중한 의견을 부탁드립니다.`;
  await updateGoogleFormItems(token, base.formId, questions, description);
  
  return {
    formId: base.formId,
    title,
    description,
    responderUri: base.responderUri,
    editUri: base.editUri,
    createdAt: new Date().toISOString()
  };
};

/**
 * Fetches form details (metadata, questions)
 */
export const fetchGoogleFormDetails = async (token: string, formId: string): Promise<any> => {
  const url = `https://forms.googleapis.com/v1/forms/${formId}`;
  
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`
    }
  });
  
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Google Form retrieval failed: ${errText}`);
  }
  
  return await res.json();
};

/**
 * Fetches all responses submitted to a Google Form
 */
export const fetchGoogleFormResponses = async (token: string, formId: string): Promise<{ responses: FormResponseEntry[]; totalCount: number }> => {
  const url = `https://forms.googleapis.com/v1/forms/${formId}/responses`;
  
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`
    }
  });
  
  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Google Form responses retrieval failed: ${errText}`);
  }
  
  const data = await res.json();
  const rawResponses = data.responses || [];
  
  const parsedResponses: FormResponseEntry[] = rawResponses.map((r: any) => {
    const answersObj: Record<string, FormResponseAnswer> = {};
    if (r.answers) {
      Object.keys(r.answers).forEach((qId) => {
        const itemAns = r.answers[qId];
        const textList: string[] = [];
        if (itemAns.textAnswers?.answers) {
          itemAns.textAnswers.answers.forEach((ans: any) => {
            if (ans.value) textList.push(ans.value);
          });
        }
        answersObj[qId] = {
          questionId: qId,
          textAnswers: textList
        };
      });
    }
    
    return {
      responseId: r.responseId,
      createTime: r.createTime,
      lastSubmittedTime: r.lastSubmittedTime,
      respondentEmail: r.respondentEmail || '',
      answers: answersObj
    };
  });
  
  return {
    responses: parsedResponses,
    totalCount: parsedResponses.length
  };
};

// -----------------------------------------------------------------
// 10. Google Chat API (Spaces, Messages, Cards)
// -----------------------------------------------------------------
export interface GoogleChatSpace {
  name: string; // "spaces/AAA..."
  type?: 'SPACE' | 'GROUP_CHAT' | 'DIRECT_MESSAGE';
  displayName?: string;
  spaceType?: 'SPACE' | 'GROUP_CHAT' | 'DIRECT_MESSAGE';
  singleUserBotDm?: boolean;
  threaded?: boolean;
  spaceDetails?: {
    description?: string;
    guidelines?: string;
  };
  spaceHistoryState?: string;
  createTime?: string;
}

export interface GoogleChatMessage {
  name?: string; // "spaces/AAA/messages/BBB"
  sender?: {
    name?: string;
    displayName?: string;
    avatarUrl?: string;
    type?: 'HUMAN' | 'BOT';
  };
  text?: string;
  createTime?: string;
  cardsV2?: any[];
  thread?: {
    name?: string;
  };
  space?: {
    name?: string;
    displayName?: string;
  };
}

/**
 * Lists the Google Chat spaces that the authenticated user is a member of.
 */
export const fetchGoogleChatSpaces = async (token: string): Promise<GoogleChatSpace[]> => {
  const url = 'https://chat.googleapis.com/v1/spaces?pageSize=100';
  
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`
    }
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Google Chat Spaces 조회 실패 (${res.status}): ${errText}`);
  }

  const data = await res.json();
  return data.spaces || [];
};

/**
 * Creates a new named Google Chat space for policy consultation or team collaboration.
 */
export const createGoogleChatSpace = async (
  token: string, 
  displayName: string, 
  description?: string
): Promise<GoogleChatSpace> => {
  const url = 'https://chat.googleapis.com/v1/spaces';
  
  const payload: any = {
    spaceType: 'SPACE',
    displayName: displayName.trim(),
  };

  if (description) {
    payload.spaceDetails = {
      description: description.trim()
    };
  }

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Google Chat Space 생성 실패 (${res.status}): ${errText}`);
  }

  return await res.json();
};

/**
 * Lists messages in a Google Chat space.
 */
export const fetchGoogleChatMessages = async (
  token: string, 
  spaceName: string, 
  pageSize: number = 30
): Promise<GoogleChatMessage[]> => {
  const encodedSpace = encodeURIComponent(spaceName.replace('spaces/', ''));
  const url = `https://chat.googleapis.com/v1/spaces/${encodedSpace}/messages?pageSize=${pageSize}`;

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`
    }
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Google Chat 메시지 목록 조회 실패 (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const messages: GoogleChatMessage[] = data.messages || [];
  // Sort chronologically (oldest first or newest first)
  return messages.sort((a, b) => {
    const timeA = new Date(a.createTime || 0).getTime();
    const timeB = new Date(b.createTime || 0).getTime();
    return timeA - timeB;
  });
};

/**
 * Sends a text message or rich card to a Google Chat space.
 */
export const sendGoogleChatMessage = async (
  token: string, 
  spaceName: string, 
  text: string,
  cardsV2?: any[]
): Promise<GoogleChatMessage> => {
  const encodedSpace = encodeURIComponent(spaceName.replace('spaces/', ''));
  const url = `https://chat.googleapis.com/v1/spaces/${encodedSpace}/messages`;

  const payload: any = {
    text: text.trim()
  };

  if (cardsV2 && cardsV2.length > 0) {
    payload.cardsV2 = cardsV2;
  }

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Google Chat 메시지 전송 실패 (${res.status}): ${errText}`);
  }

  return await res.json();
};

/**
 * Sends a structured Policy Fund card message to Google Chat Space.
 */
export const sendPolicyShareToGoogleChat = async (
  token: string,
  spaceName: string,
  policy: {
    title: string;
    agency: string;
    maxAmount?: string;
    interestRate?: string;
    category?: string;
    applyUrl?: string;
    senderName?: string;
    businessName?: string;
    note?: string;
  }
): Promise<GoogleChatMessage> => {
  const formattedText = `📢 *[BizMatch AI] 맞춤 정책자금 공유 알림*\n` +
    `📌 *자금명:* ${policy.title}\n` +
    `🏛️ *지원기관:* ${policy.agency}\n` +
    (policy.maxAmount ? `💰 *최대 한도:* ${policy.maxAmount}\n` : '') +
    (policy.interestRate ? `📉 *금리 조건:* ${policy.interestRate}\n` : '') +
    (policy.businessName ? `🏢 *기업명:* ${policy.businessName}\n` : '') +
    (policy.note ? `💬 *메모:* ${policy.note}\n` : '') +
    (policy.applyUrl ? `🔗 *공고 바로가기:* ${policy.applyUrl}` : '');

  const cardsV2 = [
    {
      cardId: `policy-${Date.now()}`,
      card: {
        header: {
          title: policy.title,
          subtitle: `주관기관: ${policy.agency}`,
          imageUrl: 'https://cdn-icons-png.flaticon.com/512/3135/3135706.png',
          imageType: 'CIRCLE'
        },
        sections: [
          {
            header: '정책자금 핵심 혜택',
            widgets: [
              {
                decoratedText: {
                  topLabel: '최대 대출/지원 한도',
                  text: policy.maxAmount || '한도 공고문 참조',
                  startIcon: { knownIcon: 'DOLLAR' }
                }
              },
              {
                decoratedText: {
                  topLabel: '적용 금리 / 조건',
                  text: policy.interestRate || '연 1.5% ~ 3.5% 정책우대금리',
                  startIcon: { knownIcon: 'STAR' }
                }
              },
              ...(policy.note ? [{
                decoratedText: {
                  topLabel: '공유 메시지',
                  text: policy.note,
                  wrapText: true
                }
              }] : [])
            ]
          }
        ]
      }
    }
  ];

  return sendGoogleChatMessage(token, spaceName, formattedText, cardsV2);
};

/**
 * Sends Consultation Request Notification to Google Chat.
 */
export const sendConsultationToGoogleChat = async (
  token: string,
  spaceName: string,
  consultation: {
    fundTitle: string;
    fundAgency: string;
    applicantName: string;
    businessName: string;
    contactNumber: string;
    preferredDate?: string;
    preferredTimeSlot?: string;
    inquiryDetails?: string;
    googleFormUrl?: string;
  }
): Promise<GoogleChatMessage> => {
  const formattedText = `🤝 *[1:1 정책자금 상담 접수 알림]*\n` +
    `📋 *대상 정책:* ${consultation.fundTitle} (${consultation.fundAgency})\n` +
    `👤 *신청자:* ${consultation.applicantName} 대표님 / ${consultation.businessName}\n` +
    `📞 *연락처:* ${consultation.contactNumber}\n` +
    (consultation.preferredDate ? `📅 *희망 상담일:* ${consultation.preferredDate} (${consultation.preferredTimeSlot || '오후'})\n` : '') +
    (consultation.inquiryDetails ? `💬 *문의 요약:* ${consultation.inquiryDetails}\n` : '') +
    (consultation.googleFormUrl ? `🔗 *Google Forms 설문:* ${consultation.googleFormUrl}` : '');

  return sendGoogleChatMessage(token, spaceName, formattedText);
};

// -----------------------------------------------------------------
// 12. Google People API - Google Contacts Management
// -----------------------------------------------------------------

export interface GoogleContact {
  resourceName: string; // e.g. "people/c12345678"
  etag: string;
  name: string;
  givenName?: string;
  familyName?: string;
  email?: string;
  phone?: string;
  organization?: string;
  title?: string;
  photoUrl?: string;
  addresses?: string[];
  notes?: string;
  category?: 'CONSULTANT' | 'BANKER' | 'TAX_ACCOUNTANT' | 'PARTNER' | 'OTHER';
}

/**
 * Fetches user's Google Contacts using Google People API.
 */
export const fetchGoogleContacts = async (
  token: string, 
  pageSize: number = 100
): Promise<GoogleContact[]> => {
  try {
    const url = `https://people.googleapis.com/v1/people/me/connections?personFields=names,emailAddresses,phoneNumbers,organizations,photos,addresses,biographies,userDefined&pageSize=${pageSize}&sortOrder=LAST_MODIFIED_DESCENDING`;
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json'
      }
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      console.warn('Failed to fetch Google Contacts:', err);
      return [];
    }

    const data = await res.json();
    const connections = data.connections || [];

    return connections.map((person: any): GoogleContact => {
      const primaryName = person.names?.[0];
      const displayName = primaryName?.displayName || 
        [primaryName?.familyName, primaryName?.givenName].filter(Boolean).join('') || 
        '이름 없음';

      const primaryEmail = person.emailAddresses?.[0]?.value;
      const primaryPhone = person.phoneNumbers?.[0]?.value;
      const primaryOrg = person.organizations?.[0];
      const photoUrl = person.photos?.[0]?.url;
      const notes = person.biographies?.[0]?.value;

      const addresses = (person.addresses || []).map((a: any) => a.formattedValue || a.streetAddress).filter(Boolean);

      // Determine category hint
      let category: GoogleContact['category'] = 'OTHER';
      const combinedText = `${displayName} ${primaryOrg?.name || ''} ${primaryOrg?.title || ''} ${notes || ''}`.toLowerCase();
      if (combinedText.includes('세무') || combinedText.includes('회계')) {
        category = 'TAX_ACCOUNTANT';
      } else if (combinedText.includes('은행') || combinedText.includes('금융') || combinedText.includes('지점') || combinedText.includes('심사')) {
        category = 'BANKER';
      } else if (combinedText.includes('컨설턴트') || combinedText.includes('위원') || combinedText.includes('지도사') || combinedText.includes('평가')) {
        category = 'CONSULTANT';
      } else if (combinedText.includes('대표') || combinedText.includes('협력') || combinedText.includes('사')) {
        category = 'PARTNER';
      }

      return {
        resourceName: person.resourceName,
        etag: person.etag,
        name: displayName,
        givenName: primaryName?.givenName,
        familyName: primaryName?.familyName,
        email: primaryEmail,
        phone: primaryPhone,
        organization: primaryOrg?.name,
        title: primaryOrg?.title,
        photoUrl,
        addresses,
        notes,
        category
      };
    });
  } catch (err) {
    console.error('Error fetching Google Contacts:', err);
    return [];
  }
};

/**
 * Searches user's Google Contacts using query string.
 */
export const searchGoogleContacts = async (
  token: string, 
  query: string
): Promise<GoogleContact[]> => {
  if (!query.trim()) {
    return fetchGoogleContacts(token);
  }
  try {
    const url = `https://people.googleapis.com/v1/people:searchContacts?query=${encodeURIComponent(query)}&readMask=names,emailAddresses,phoneNumbers,organizations,photos,addresses,biographies`;
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json'
      }
    });

    if (!res.ok) {
      // Fallback: fetch all and filter in memory if search endpoint has index delay
      const all = await fetchGoogleContacts(token);
      const q = query.toLowerCase();
      return all.filter(c => 
        c.name.toLowerCase().includes(q) || 
        c.email?.toLowerCase().includes(q) || 
        c.phone?.includes(q) || 
        c.organization?.toLowerCase().includes(q)
      );
    }

    const data = await res.json();
    const results = data.results || [];

    return results.map((item: any): GoogleContact => {
      const person = item.person;
      const primaryName = person.names?.[0];
      const displayName = primaryName?.displayName || '이름 없음';
      const primaryEmail = person.emailAddresses?.[0]?.value;
      const primaryPhone = person.phoneNumbers?.[0]?.value;
      const primaryOrg = person.organizations?.[0];

      return {
        resourceName: person.resourceName,
        etag: person.etag,
        name: displayName,
        givenName: primaryName?.givenName,
        familyName: primaryName?.familyName,
        email: primaryEmail,
        phone: primaryPhone,
        organization: primaryOrg?.name,
        title: primaryOrg?.title,
        photoUrl: person.photos?.[0]?.url,
        notes: person.biographies?.[0]?.value
      };
    });
  } catch (err) {
    console.error('Error searching Google Contacts:', err);
    return [];
  }
};

/**
 * Creates a new contact in Google Contacts.
 */
export const createGoogleContact = async (
  token: string,
  contactData: {
    name: string;
    email?: string;
    phone?: string;
    organization?: string;
    title?: string;
    note?: string;
  }
): Promise<GoogleContact> => {
  const parts = contactData.name.trim().split(' ');
  const familyName = parts.length > 1 ? parts[0] : '';
  const givenName = parts.length > 1 ? parts.slice(1).join(' ') : parts[0];

  const body: any = {
    names: [
      {
        displayName: contactData.name,
        givenName,
        familyName
      }
    ]
  };

  if (contactData.email) {
    body.emailAddresses = [{ value: contactData.email, type: 'work' }];
  }

  if (contactData.phone) {
    body.phoneNumbers = [{ value: contactData.phone, type: 'work' }];
  }

  if (contactData.organization || contactData.title) {
    body.organizations = [
      {
        name: contactData.organization || '',
        title: contactData.title || '담당자',
        type: 'work'
      }
    ];
  }

  if (contactData.note) {
    body.biographies = [
      {
        value: contactData.note,
        contentType: 'TEXT_PLAIN'
      }
    ];
  }

  const res = await fetch('https://people.googleapis.com/v1/people:createContact', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || '구글 연락처 생성에 실패했습니다.');
  }

  const created = await res.json();
  return {
    resourceName: created.resourceName,
    etag: created.etag,
    name: contactData.name,
    email: contactData.email,
    phone: contactData.phone,
    organization: contactData.organization,
    title: contactData.title,
    notes: contactData.note
  };
};

/**
 * Updates an existing Google Contact.
 */
export const updateGoogleContact = async (
  token: string,
  resourceName: string,
  etag: string,
  contactData: {
    name: string;
    email?: string;
    phone?: string;
    organization?: string;
    title?: string;
    note?: string;
  }
): Promise<GoogleContact> => {
  const parts = contactData.name.trim().split(' ');
  const familyName = parts.length > 1 ? parts[0] : '';
  const givenName = parts.length > 1 ? parts.slice(1).join(' ') : parts[0];

  const body: any = {
    etag,
    names: [
      {
        displayName: contactData.name,
        givenName,
        familyName
      }
    ]
  };

  if (contactData.email) {
    body.emailAddresses = [{ value: contactData.email, type: 'work' }];
  } else {
    body.emailAddresses = [];
  }

  if (contactData.phone) {
    body.phoneNumbers = [{ value: contactData.phone, type: 'work' }];
  } else {
    body.phoneNumbers = [];
  }

  if (contactData.organization || contactData.title) {
    body.organizations = [
      {
        name: contactData.organization || '',
        title: contactData.title || '',
        type: 'work'
      }
    ];
  }

  if (contactData.note) {
    body.biographies = [
      {
        value: contactData.note,
        contentType: 'TEXT_PLAIN'
      }
    ];
  }

  const url = `https://people.googleapis.com/v1/${resourceName}:updateContact?updatePersonFields=names,emailAddresses,phoneNumbers,organizations,biographies`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || '구글 연락처 수정에 실패했습니다.');
  }

  const updated = await res.json();
  return {
    resourceName: updated.resourceName,
    etag: updated.etag,
    name: contactData.name,
    email: contactData.email,
    phone: contactData.phone,
    organization: contactData.organization,
    title: contactData.title,
    notes: contactData.note
  };
};

/**
 * Deletes a Google Contact permanently.
 * MANDATORY: Always execute only AFTER explicit user confirmation in UI!
 */
export const deleteGoogleContact = async (
  token: string,
  resourceName: string
): Promise<void> => {
  const res = await fetch(`https://people.googleapis.com/v1/${resourceName}:deleteContact`, {
    method: 'DELETE',
    headers: {
      Authorization: `Bearer ${token}`
    }
  });

  if (!res.ok && res.status !== 404) {
    const errorData = await res.json().catch(() => ({}));
    throw new Error(errorData.error?.message || '구글 연락처 삭제에 실패했습니다.');
  }
};

/**
 * Retrieves the current authenticated user's profile info via People API.
 */
export const getUserPeopleProfile = async (
  token: string
): Promise<{ displayName?: string; email?: string; photoUrl?: string; organization?: string; phone?: string }> => {
  try {
    const url = 'https://people.googleapis.com/v1/people/me?personFields=names,emailAddresses,phoneNumbers,photos,organizations';
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });

    if (!res.ok) return {};
    const data = await res.json();
    return {
      displayName: data.names?.[0]?.displayName,
      email: data.emailAddresses?.[0]?.value,
      photoUrl: data.photos?.[0]?.url,
      organization: data.organizations?.[0]?.name,
      phone: data.phoneNumbers?.[0]?.value
    };
  } catch (err) {
    console.error('Error fetching People user profile:', err);
    return {};
  }
};

// -----------------------------------------------------------------
// 13. Google Tasks API - Task Lists and To-Do Item Management
// -----------------------------------------------------------------

export interface GoogleTaskList {
  id: string;
  title: string;
  updated?: string;
}

export interface GoogleTask {
  id: string;
  title: string;
  notes?: string;
  status: 'needsAction' | 'completed';
  due?: string; // RFC 3339 format, e.g. "2026-10-20T00:00:00.000Z"
  completed?: string;
  updated?: string;
  position?: string;
}

/**
 * Fetches all Task Lists from user's Google Tasks.
 */
export const fetchGoogleTaskLists = async (
  token: string
): Promise<GoogleTaskList[]> => {
  try {
    const res = await fetch('https://tasks.googleapis.com/tasks/v1/users/@me/lists', {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json'
      }
    });

    if (!res.ok) {
      console.warn('Failed to fetch Google Task lists:', await res.json().catch(() => ({})));
      return [];
    }

    const data = await res.json();
    return (data.items || []).map((list: any): GoogleTaskList => ({
      id: list.id,
      title: list.title,
      updated: list.updated
    }));
  } catch (err) {
    console.error('Error fetching Google Task lists:', err);
    return [];
  }
};

/**
 * Creates a new Task List in Google Tasks.
 */
export const createGoogleTaskList = async (
  token: string,
  title: string
): Promise<GoogleTaskList> => {
  const res = await fetch('https://tasks.googleapis.com/tasks/v1/users/@me/lists', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ title })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || 'Google Tasks 목록 생성에 실패했습니다.');
  }

  const created = await res.json();
  return {
    id: created.id,
    title: created.title,
    updated: created.updated
  };
};

/**
 * Fetches all tasks in a specific task list (defaults to @default).
 */
export const fetchGoogleTasks = async (
  token: string,
  taskListId: string = '@default'
): Promise<GoogleTask[]> => {
  try {
    const url = `https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(taskListId)}/tasks?showCompleted=true&showHidden=true`;
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json'
      }
    });

    if (!res.ok) {
      console.warn('Failed to fetch Google tasks:', await res.json().catch(() => ({})));
      return [];
    }

    const data = await res.json();
    return (data.items || []).map((item: any): GoogleTask => ({
      id: item.id,
      title: item.title || '(제목 없음)',
      notes: item.notes,
      status: item.status || 'needsAction',
      due: item.due,
      completed: item.completed,
      updated: item.updated,
      position: item.position
    }));
  } catch (err) {
    console.error('Error fetching Google tasks:', err);
    return [];
  }
};

/**
 * Creates a new task in a specified Google Tasks list.
 */
export const createGoogleTask = async (
  token: string,
  taskListId: string = '@default',
  task: {
    title: string;
    notes?: string;
    due?: string; // e.g. "2026-10-25" or ISO string
  }
): Promise<GoogleTask> => {
  const body: any = {
    title: task.title
  };

  if (task.notes) {
    body.notes = task.notes;
  }

  if (task.due) {
    // Google Tasks expects RFC 3339 formatted date (e.g. 2026-10-20T00:00:00.000Z)
    const dueDate = new Date(task.due);
    if (!isNaN(dueDate.getTime())) {
      body.due = dueDate.toISOString();
    }
  }

  const url = `https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(taskListId)}/tasks`;
  const res = await fetch(url, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || 'Google Task 생성에 실패했습니다.');
  }

  const created = await res.json();
  return {
    id: created.id,
    title: created.title,
    notes: created.notes,
    status: created.status,
    due: created.due,
    updated: created.updated
  };
};

/**
 * Toggles task status between completed and needsAction.
 */
export const updateGoogleTaskStatus = async (
  token: string,
  taskListId: string = '@default',
  taskId: string,
  completed: boolean
): Promise<GoogleTask> => {
  const body: any = {
    status: completed ? 'completed' : 'needsAction'
  };
  if (!completed) {
    body.completed = null;
  }

  const url = `https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(taskListId)}/tasks/${encodeURIComponent(taskId)}`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || '할 일 상태 변경에 실패했습니다.');
  }

  const updated = await res.json();
  return {
    id: updated.id,
    title: updated.title,
    notes: updated.notes,
    status: updated.status,
    due: updated.due,
    completed: updated.completed
  };
};

/**
 * Updates a task title, notes, or due date.
 */
export const updateGoogleTask = async (
  token: string,
  taskListId: string = '@default',
  taskId: string,
  taskData: {
    title?: string;
    notes?: string;
    due?: string;
    status?: 'needsAction' | 'completed';
  }
): Promise<GoogleTask> => {
  const body: any = {};
  if (taskData.title !== undefined) body.title = taskData.title;
  if (taskData.notes !== undefined) body.notes = taskData.notes;
  if (taskData.status !== undefined) body.status = taskData.status;
  if (taskData.due) {
    const d = new Date(taskData.due);
    if (!isNaN(d.getTime())) body.due = d.toISOString();
  }

  const url = `https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(taskListId)}/tasks/${encodeURIComponent(taskId)}`;
  const res = await fetch(url, {
    method: 'PATCH',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || '할 일 정보 수정에 실패했습니다.');
  }

  const updated = await res.json();
  return {
    id: updated.id,
    title: updated.title,
    notes: updated.notes,
    status: updated.status,
    due: updated.due
  };
};

/**
 * Deletes a Google Task permanently.
 * MANDATORY: Always execute only AFTER explicit user confirmation dialog in UI!
 */
export const deleteGoogleTask = async (
  token: string,
  taskListId: string = '@default',
  taskId: string
): Promise<void> => {
  const url = `https://tasks.googleapis.com/tasks/v1/lists/${encodeURIComponent(taskListId)}/tasks/${encodeURIComponent(taskId)}`;
  const res = await fetch(url, {
    method: 'DELETE',
    headers: {
      Authorization: `Bearer ${token}`
    }
  });

  if (!res.ok && res.status !== 404) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error?.message || 'Google Task 삭제에 실패했습니다.');
  }
};

/**
 * Exports policy fund application checklist items to a dedicated Google Tasks list.
 */
export const exportPolicyFundChecklistToGoogleTasks = async (
  token: string,
  fundTitle: string,
  tasks: Array<{ title: string; notes?: string; due?: string }>
): Promise<{ taskListId: string; count: number }> => {
  // 1. Get or create a dedicated task list
  const existingLists = await fetchGoogleTaskLists(token);
  const targetTitle = `[BizMatch AI] ${fundTitle.slice(0, 20)} 준비 체크리스트`;
  let targetList = existingLists.find(l => l.title === targetTitle);

  if (!targetList) {
    targetList = await createGoogleTaskList(token, targetTitle);
  }

  const taskListId = targetList.id;

  // 2. Insert tasks
  let count = 0;
  for (const t of tasks) {
    try {
      await createGoogleTask(token, taskListId, t);
      count++;
    } catch (e) {
      console.warn('Failed to add task item to Google Tasks:', t.title, e);
    }
  }

  return { taskListId, count };
};



