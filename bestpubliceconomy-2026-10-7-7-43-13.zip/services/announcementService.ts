import { PolicyAnnouncement, AnnouncementRule, AnnouncementVersion } from '../types';

const STORAGE_KEY = 'bizmatch_policy_announcements_v04';

const INITIAL_ANNOUNCEMENTS: PolicyAnnouncement[] = [
  {
    id: 'ann-semas-vuln-2026',
    title: '신용취약소상공인자금 (2026년 상반기)',
    agency: '소상공인시장진흥공단 (직접대출)',
    source: '소상공인시장진흥공단',
    category: '직접대출·특별경영안정',
    status: 'OPEN',
    reviewStatus: 'approved',
    isActive: true,
    budgetExhaustionRate: 64,
    completenessScore: 100,
    warnings: [],
    collectedAt: '2026-01-02T09:12:15',
    lastUpdatedAt: '2026-01-10T14:20:00',
    startDate: '2026-01-02',
    endDate: '2026-12-31',
    maxAmount: '30,000,000원',
    baseInterestRate: '정책자금 기준금리 + 1.6%p (변동)',
    repaymentPeriod: '5년 (2년 거치 3년 분할상환)',
    description: 'NICE 또는 NCB 신용점수 839점 이하 중·저신용 소상공인의 유동성 위기 극복 및 채무부담 완화를 위한 특화자금입니다.',
    sourceUrl: 'https://ols.semas.or.kr/ols/man/SMAS010M/page.do',
    contactInfo: '중소기업통합콜센터 (1357)',
    rule: {
      schema_version: '2026.1',
      program_name: '신용취약소상공인자금',
      eligibility: {
        credit_score: {
          value: 839,
          operator: 'lte'
        },
        requires_credit_education: true,
      },
      finance: {
        loan_limit_krw: 30000000,
        rate: {
          type: 'base_plus',
          value: 1.6,
          description: '기준금리 + 1.6%p 변동금리'
        },
        term_years: 5,
        grace_years: 2,
        channel: 'direct'
      },
      tags: ['low_credit', 'vulnerable', 'education_required']
    },
    versions: [
      {
        version: 'v1.1',
        changedAt: '2026-01-10T14:20:00',
        changedFields: ['budgetExhaustionRate', 'rule.finance.rate.value'],
        snapshotTitle: '1월 2주차 금리 가산율 조정',
        summary: '가산금리 1.4% -> 1.6% 변동 고시 반영 및 소진율 업데이트'
      },
      {
        version: 'v1.0',
        changedAt: '2026-01-02T09:12:15',
        changedFields: [],
        snapshotTitle: '최초 공고 수집',
        summary: '소진공 원문 크롤링 후 JSON 규칙 자동 추출 완료'
      }
    ]
  },
  {
    id: 'ann-semas-refin-2026',
    title: '소상공인 저금리 대환대출',
    agency: '소상공인시장진흥공단 (대리대출)',
    source: '소상공인시장진흥공단',
    category: '대리대출·금융비용경감',
    status: 'OPEN',
    reviewStatus: 'approved',
    isActive: true,
    budgetExhaustionRate: 82,
    completenessScore: 95,
    warnings: ['취급 금융기관(1금융권) 확인서 발급 요건 주의'],
    collectedAt: '2026-01-05T10:00:00',
    lastUpdatedAt: '2026-01-12T16:30:00',
    startDate: '2026-01-05',
    endDate: '2026-12-31',
    maxAmount: '50,000,000원',
    baseInterestRate: '연 4.5% (고정금리)',
    repaymentPeriod: '최대 10년 (거치기간 없음)',
    description: '7% 이상 고금리 대출 또는 만기연장 애로가 있는 소상공인을 대상으로 저금리 장기분할상환 대출로 전환 지원합니다.',
    sourceUrl: 'https://ols.semas.or.kr/ols/man/SMAS020M/page.do',
    contactInfo: '대환대출 전담콜센터 (1533-0100)',
    rule: {
      schema_version: '2026.1',
      program_name: '소상공인 저금리 대환대출',
      eligibility: {
        credit_score: {
          value: 839,
          operator: 'lte'
        },
        requires_credit_education: false
      },
      finance: {
        loan_limit_krw: 50000000,
        rate: {
          type: 'fixed',
          value: 4.5,
          description: '연 4.5% 고정금리'
        },
        term_years: 10,
        grace_years: 0,
        channel: 'proxy'
      },
      tags: ['debt_refinance', 'high_rate_debt', 'proxy_loan']
    },
    versions: [
      {
        version: 'v1.0',
        changedAt: '2026-01-05T10:00:00',
        changedFields: [],
        snapshotTitle: '최초 공고 수집',
        summary: '신용점수 및 고금리 대환 규칙 자동 파싱 통과'
      }
    ]
  },
  {
    id: 'ann-bizinfo-hope-2026',
    title: '희망리턴패키지 재도전 성공패키지 특례보증',
    agency: '중소벤처기업부 / 기업마당',
    source: '기업마당',
    category: '재도전·재창업',
    status: 'OPEN',
    reviewStatus: 'pending',
    isActive: false,
    budgetExhaustionRate: 35,
    completenessScore: 78,
    warnings: ['금리 우대율 수동 검증 필요', '폐업확인서 증빙 조건 추가 확인 요망'],
    collectedAt: '2026-01-14T08:45:00',
    lastUpdatedAt: '2026-01-14T08:45:00',
    startDate: '2026-01-15',
    endDate: '2026-03-31',
    maxAmount: '20,000,000원',
    baseInterestRate: '연 2.8% (고정/협약금리)',
    repaymentPeriod: '5년 (2년 거치 3년 상환)',
    description: '경영위기 극복 또는 재창업 소상공인 대상 재기 지원 및 신용보증재단 연계 100% 전액보증 지원사업.',
    sourceUrl: 'https://www.bizinfo.go.kr/web/lay1/bbs/S1T122C128/AS/74/view.do',
    contactInfo: '소상공인진흥공단 재도전지원실 (042-363-7764)',
    rule: {
      schema_version: '2026.1',
      program_name: '희망리턴패키지 재도전 특례보증',
      eligibility: {
        credit_score: {
          value: 744,
          operator: 'lte'
        },
        requires_credit_education: true
      },
      finance: {
        loan_limit_krw: 20000000,
        rate: {
          type: 'fixed',
          value: 2.8,
          description: '연 2.8% 협약금리'
        },
        term_years: 5,
        grace_years: 2,
        channel: 'direct'
      },
      tags: ['rechallenge', 'turnaround', 'guarantee']
    },
    versions: [
      {
        version: 'v1.0',
        changedAt: '2026-01-14T08:45:00',
        changedFields: [],
        snapshotTitle: '신규 크롤링 수집',
        summary: '기업마당 RSS 수집 후 관리자 검수 대기(Pending) 큐 인입'
      }
    ]
  },
  {
    id: 'ann-semas-general-2026',
    title: '일반경영안정자금 (2026년)',
    agency: '소상공인시장진흥공단 (대리대출)',
    source: '소상공인시장진흥공단',
    category: '보편적 운전자금',
    status: 'OPEN',
    reviewStatus: 'approved',
    isActive: true,
    budgetExhaustionRate: 58,
    completenessScore: 92,
    warnings: ['신용점수 제한 없음 (전체 신용등급 신청 가능)'],
    collectedAt: '2026-01-02T09:00:00',
    lastUpdatedAt: '2026-01-08T11:00:00',
    startDate: '2026-01-02',
    endDate: '2026-12-31',
    maxAmount: '70,000,000원',
    baseInterestRate: '정책자금 기준금리 + 0.6%p (변동)',
    repaymentPeriod: '5년 (2년 거치 3년 분할상환)',
    description: '업력과 무관하게 보편적인 유동성을 공급하는 소상공인 대상 경영안정자금으로 은행 및 보증서 담보 대출.',
    sourceUrl: 'https://ols.semas.or.kr/ols/man/SMAS001M/page.do',
    contactInfo: '중소기업통합콜센터 (1357)',
    rule: {
      schema_version: '2026.1',
      program_name: '일반경영안정자금',
      eligibility: {
        requires_credit_education: false
      },
      finance: {
        loan_limit_krw: 70000000,
        rate: {
          type: 'base_plus',
          value: 0.6,
          description: '기준금리 + 0.6%p 변동'
        },
        term_years: 5,
        grace_years: 2,
        channel: 'proxy'
      },
      tags: ['general', 'liquidity', 'working_capital']
    },
    versions: [
      {
        version: 'v1.0',
        changedAt: '2026-01-02T09:00:00',
        changedFields: [],
        snapshotTitle: '최초 등록',
        summary: '운영 DB 승인 완료'
      }
    ]
  },
  {
    id: 'ann-semas-growth-2026',
    title: '성장촉진 소상공인 특화자금 (스마트화·혁신형)',
    agency: '소상공인시장진흥공단 (직접대출)',
    source: '소상공인시장진흥공단',
    category: '직접대출·혁신성장',
    status: 'OPEN',
    reviewStatus: 'pending',
    isActive: true,
    budgetExhaustionRate: 42,
    completenessScore: 84,
    warnings: ['매출 신장률(전년 대비 10% 이상) 또는 스마트설비 증빙 필수'],
    collectedAt: '2026-01-13T15:10:00',
    lastUpdatedAt: '2026-01-13T15:10:00',
    startDate: '2026-01-15',
    endDate: '2026-11-30',
    maxAmount: '100,000,000원',
    baseInterestRate: '정책자금 기준금리 + 0.4%p (우대금리)',
    repaymentPeriod: '5년 (2년 거치 3년 원금균등상환)',
    description: '스마트오더, 키오스크 도입 또는 매출 성장세가 뚜렷한 유망 소상공인을 대상으로 우대금리 직접대출을 지원합니다.',
    sourceUrl: 'https://ols.semas.or.kr/ols/man/SMAS035M/page.do',
    contactInfo: '소진공 혁신성장실 (042-363-7123)',
    rule: {
      schema_version: '2026.1',
      program_name: '성장촉진 소상공인 특화자금',
      eligibility: {
        revenue_drop_rate: 0,
        requires_credit_education: false
      },
      finance: {
        loan_limit_krw: 100000000,
        rate: {
          type: 'base_plus',
          value: 0.4,
          description: '기준금리 + 0.4%p'
        },
        term_years: 5,
        grace_years: 2,
        channel: 'direct'
      },
      tags: ['growth', 'smart_tech', 'direct_loan']
    },
    versions: [
      {
        version: 'v1.0',
        changedAt: '2026-01-13T15:10:00',
        changedFields: [],
        snapshotTitle: '신규 공고 정규화',
        summary: '관리자 승인 대기'
      }
    ]
  },
  {
    id: 'ann-kinfa-miso-2026',
    title: '서민금융진흥원 미소금융 운영자금',
    agency: '서민금융진흥원',
    source: '서민금융진흥원',
    category: '취약계층·마이크로크레딧',
    status: 'OPEN',
    reviewStatus: 'approved',
    isActive: true,
    budgetExhaustionRate: 51,
    completenessScore: 92,
    warnings: ['재산세 과세표준 1억 5천만원 이하 요건'],
    collectedAt: '2026-01-03T11:20:00',
    lastUpdatedAt: '2026-01-09T14:15:00',
    startDate: '2026-01-03',
    endDate: '2026-12-31',
    maxAmount: '20,000,000원',
    baseInterestRate: '연 4.5% (성실상환시 0.5%p 우대)',
    repaymentPeriod: '5년 (1년 거치 4년 상환)',
    description: 'NICE 744점 또는 KCB 700점 이하 저신용 자영업자를 위한 무담보·무보증 소액대출.',
    sourceUrl: 'https://www.kinfa.or.kr/customer/product/miso.do',
    contactInfo: '서민금융콜센터 (1397)',
    rule: {
      schema_version: '2026.1',
      program_name: '미소금융 운영자금',
      eligibility: {
        credit_score: {
          value: 744,
          operator: 'lte'
        },
        requires_credit_education: false
      },
      finance: {
        loan_limit_krw: 20000000,
        rate: {
          type: 'fixed',
          value: 4.5,
          description: '연 4.5%'
        },
        term_years: 5,
        grace_years: 1,
        channel: 'direct'
      },
      tags: ['low_credit', 'microcredit', 'kinfa']
    },
    versions: [
      {
        version: 'v1.0',
        changedAt: '2026-01-03T11:20:00',
        changedFields: [],
        snapshotTitle: '정규화 완료',
        summary: '서금원 저신용 규칙 매핑 승인'
      }
    ]
  },
  {
    id: 'ann-unverified-blog-sample',
    title: '[비공식 수집] 2026년 무이자 특별 소상공인 긴급재난 지원금 안내',
    agency: '출처 불명 포털 블로그',
    source: '외부 수집 크롤러',
    category: '비공식·검증필요',
    status: 'CLOSED',
    reviewStatus: 'rejected',
    isActive: false,
    budgetExhaustionRate: 0,
    completenessScore: 35,
    warnings: ['공식 정부 고시 URL 미확인 (스팸/피싱 의심)', '금리 및 한도 산출식 불명확', '지원기관 불일치'],
    collectedAt: '2026-01-14T02:10:00',
    lastUpdatedAt: '2026-01-14T09:30:00',
    startDate: '2026-01-01',
    endDate: '2026-01-10',
    maxAmount: '미상',
    baseInterestRate: '무이자 (확인 불가)',
    repaymentPeriod: '미확인',
    description: '개인 블로그에서 자동 수집된 자료로 공식 고시 링크가 없고 유효한 금융 조건이 결여되어 관리자 검수에서 반려 조치되었습니다.',
    sourceUrl: 'https://example.com/unverified-post',
    contactInfo: '없음',
    rule: {
      schema_version: '2026.1',
      program_name: '무이자 지원금',
      eligibility: {
        requires_credit_education: false
      },
      finance: {
        loan_limit_krw: 0,
        rate: {
          type: 'fixed',
          value: 0,
          description: '미추출'
        },
        term_years: 0,
        grace_years: 0,
        channel: 'direct'
      },
      tags: ['unverified', 'rejected']
    },
    versions: [
      {
        version: 'v1.0',
        changedAt: '2026-01-14T02:10:00',
        changedFields: [],
        snapshotTitle: '수집 및 자동 점수 평가',
        summary: '완성도 35점 미달로 반려(Rejected) 처리'
      }
    ]
  },
  {
    id: 'ann-kosme-urgent-2026',
    title: '2026년 3분기 긴급 경영안정자금 (재해·유동성 위기)',
    agency: '중소벤처기업진흥공단',
    source: '중소벤처기업진흥공단',
    category: '긴급경영안정·재해복구',
    status: 'BUDGET_ALMOST_EXHAUSTED',
    reviewStatus: 'approved',
    isActive: true,
    budgetExhaustionRate: 91,
    completenessScore: 96,
    warnings: ['예산 소진율 90% 돌파로 조기 마감 임박 (선착순 접수)'],
    collectedAt: '2026-08-20T09:00:00',
    lastUpdatedAt: '2026-09-08T10:00:00',
    startDate: '2026-08-20',
    endDate: '2026-09-15',
    maxAmount: '100,000,000원',
    baseInterestRate: '정책자금 기준금리 (연 3.2% 수준)',
    repaymentPeriod: '5년 (2년 거치 3년 분할상환)',
    description: '매출 급감 또는 일시적 자금난을 겪는 소상공인·중소기업 대상 긴급 유동성 공급 자금. 예산 한도 소진으로 9월 15일 마감.',
    sourceUrl: 'https://www.kosmes.or.kr/sbc/SH/OAS/SHOAS030M.do',
    contactInfo: '중진공 정책자금 안내콜센터 (1811-3655)',
    rule: {
      schema_version: '2026.1',
      program_name: '긴급 경영안정자금',
      eligibility: {
        revenue_drop_rate: 10,
        requires_credit_education: false
      },
      finance: {
        loan_limit_krw: 100000000,
        rate: {
          type: 'fixed',
          value: 3.2,
          description: '연 3.2% 기준금리'
        },
        term_years: 5,
        grace_years: 2,
        channel: 'direct'
      },
      tags: ['urgent', 'emergency', 'kosme', 'liquidity']
    },
    versions: [
      {
        version: 'v1.1',
        changedAt: '2026-09-08T10:00:00',
        changedFields: ['budgetExhaustionRate', 'endDate'],
        snapshotTitle: '예산 90% 소진에 따른 조기 마감 고시',
        summary: '접수 마감일 9월 15일로 조기 확정 고시'
      }
    ]
  },
  {
    id: 'ann-koreg-special-2026',
    title: '지역신용보증재단 3분기 골목상권 활성화 특례보증',
    agency: '신용보증재단중앙회',
    source: '신용보증재단',
    category: '특례보증·골목상권',
    status: 'OPEN',
    reviewStatus: 'pending',
    isActive: false,
    budgetExhaustionRate: 68,
    completenessScore: 88,
    warnings: ['지역별 보증재단별 할당 한도 소진 전 신청 권장'],
    collectedAt: '2026-09-01T11:00:00',
    lastUpdatedAt: '2026-09-05T14:30:00',
    startDate: '2026-09-01',
    endDate: '2026-09-28',
    maxAmount: '30,000,000원',
    baseInterestRate: '연 3.8% (보증료 0.8% 별도)',
    repaymentPeriod: '5년 (1년 거치 4년 상환)',
    description: '지역 골목상권 및 영세 소상공인의 운전자금 조달을 지원하기 위한 100% 전액 특례보증 협약 상품.',
    sourceUrl: 'https://www.koreg.or.kr/product/special.do',
    contactInfo: '신보중앙회 콜센터 (1588-7365)',
    rule: {
      schema_version: '2026.1',
      program_name: '골목상권 활성화 특례보증',
      eligibility: {
        requires_credit_education: false
      },
      finance: {
        loan_limit_krw: 30000000,
        rate: {
          type: 'fixed',
          value: 3.8,
          description: '연 3.8%'
        },
        term_years: 5,
        grace_years: 1,
        channel: 'proxy'
      },
      tags: ['guarantee', 'koreg', 'local_business']
    },
    versions: [
      {
        version: 'v1.0',
        changedAt: '2026-09-01T11:00:00',
        changedFields: [],
        snapshotTitle: '신규 고시 수집',
        summary: '관리자 검수 대기 중'
      }
    ]
  }
];

export const getAnnouncements = (): PolicyAnnouncement[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        const existingIds = new Set(parsed.map((a: any) => a.id));
        const missing = INITIAL_ANNOUNCEMENTS.filter(a => !existingIds.has(a.id));
        if (missing.length > 0) {
          const merged = [...parsed, ...missing];
          localStorage.setItem(STORAGE_KEY, JSON.stringify(merged));
          return merged;
        }
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Failed to load announcements from storage:', e);
  }
  localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_ANNOUNCEMENTS));
  return INITIAL_ANNOUNCEMENTS;
};

export const saveAnnouncements = (list: PolicyAnnouncement[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
  } catch (e) {
    console.error('Failed to save announcements to storage:', e);
  }
};

export const toggleAnnouncementActive = (id: string): { updated: PolicyAnnouncement; list: PolicyAnnouncement[] } => {
  const current = getAnnouncements();
  const target = current.find(a => a.id === id);
  if (!target) throw new Error('Announcement not found');
  
  const updatedTarget: PolicyAnnouncement = {
    ...target,
    isActive: !target.isActive,
    lastUpdatedAt: new Date().toISOString()
  };

  const updatedList = current.map(a => a.id === id ? updatedTarget : a);
  saveAnnouncements(updatedList);
  return { updated: updatedTarget, list: updatedList };
};

export const updateAnnouncementReviewStatus = (
  id: string, 
  reviewStatus: 'pending' | 'approved' | 'rejected',
  adminNote?: string
): { updated: PolicyAnnouncement; list: PolicyAnnouncement[] } => {
  const current = getAnnouncements();
  const target = current.find(a => a.id === id);
  if (!target) throw new Error('Announcement not found');

  const now = new Date().toISOString();
  const newVersion: AnnouncementVersion = {
    version: `v${(target.versions.length * 0.1 + 1.0).toFixed(1)}`,
    changedAt: now,
    changedFields: ['reviewStatus'],
    snapshotTitle: `검수상태 변경: ${reviewStatus === 'approved' ? '운영 승인' : reviewStatus === 'rejected' ? '검수 반려' : '검수 대기'}`,
    summary: adminNote || `관리자 검수 조치 (${reviewStatus})`
  };

  const updatedTarget: PolicyAnnouncement = {
    ...target,
    reviewStatus,
    // Automatically turn off activation if rejected
    isActive: reviewStatus === 'rejected' ? false : target.isActive,
    lastUpdatedAt: now,
    versions: [newVersion, ...target.versions]
  };

  const updatedList = current.map(a => a.id === id ? updatedTarget : a);
  saveAnnouncements(updatedList);
  return { updated: updatedTarget, list: updatedList };
};

export const bulkUpdateAnnouncementReviewStatus = (
  ids: string[], 
  reviewStatus: 'pending' | 'approved' | 'rejected',
  adminNote?: string
): { updatedCount: number; list: PolicyAnnouncement[] } => {
  const current = getAnnouncements();
  const idSet = new Set(ids);
  const now = new Date().toISOString();
  let updatedCount = 0;

  const updatedList = current.map(item => {
    if (!idSet.has(item.id)) return item;
    
    updatedCount++;
    const newVersion: AnnouncementVersion = {
      version: `v${(item.versions.length * 0.1 + 1.0).toFixed(1)}`,
      changedAt: now,
      changedFields: ['reviewStatus'],
      snapshotTitle: `일괄 검증: ${reviewStatus === 'approved' ? '검증 완료(운영 승인)' : reviewStatus === 'rejected' ? '검수 반려' : '검수 대기'}`,
      summary: adminNote || `관리자 일괄 검증 처리 (${ids.length}건 동시 ${reviewStatus === 'approved' ? '승인' : reviewStatus})`
    };

    return {
      ...item,
      reviewStatus,
      isActive: reviewStatus === 'rejected' ? false : (reviewStatus === 'approved' ? true : item.isActive),
      lastUpdatedAt: now,
      versions: [newVersion, ...item.versions]
    };
  });

  saveAnnouncements(updatedList);
  return { updatedCount, list: updatedList };
};

export const deleteAnnouncement = (id: string): PolicyAnnouncement[] => {
  const current = getAnnouncements();
  const filtered = current.filter(a => a.id !== id);
  saveAnnouncements(filtered);
  return filtered;
};

export const updateAnnouncementRule = (
  id: string,
  updatedRule: AnnouncementRule,
  updatedCompletenessScore?: number
): { updated: PolicyAnnouncement; list: PolicyAnnouncement[] } => {
  const current = getAnnouncements();
  const target = current.find(a => a.id === id);
  if (!target) throw new Error('Announcement not found');

  const now = new Date().toISOString();
  const score = updatedCompletenessScore ?? calculateCompletenessScore(updatedRule);
  const warnings = generateWarnings(updatedRule);

  const newVersion: AnnouncementVersion = {
    version: `v${(target.versions.length * 0.1 + 1.0).toFixed(1)}`,
    changedAt: now,
    changedFields: ['rule', 'completenessScore'],
    snapshotTitle: 'JSON 정책 규칙 수동 수정/재추출',
    summary: '관리자에 의해 규칙 조건이 수정 및 정규화되었습니다.'
  };

  const updatedTarget: PolicyAnnouncement = {
    ...target,
    rule: updatedRule,
    completenessScore: score,
    warnings,
    lastUpdatedAt: now,
    versions: [newVersion, ...target.versions]
  };

  const updatedList = current.map(a => a.id === id ? updatedTarget : a);
  saveAnnouncements(updatedList);
  return { updated: updatedTarget, list: updatedList };
};

export const calculateCompletenessScore = (rule: AnnouncementRule): number => {
  let score = 20; // Base score for valid schema
  if (rule.eligibility?.credit_score?.value) score += 20;
  if (rule.finance?.loan_limit_krw && rule.finance.loan_limit_krw > 0) score += 20;
  if (rule.finance?.rate?.value !== undefined && rule.finance.rate.value > 0) score += 20;
  if (rule.finance?.term_years && rule.finance.term_years > 0) score += 10;
  if (rule.tags && rule.tags.length > 0) score += 10;
  return Math.min(100, score);
};

export const generateWarnings = (rule: AnnouncementRule): string[] => {
  const warnings: string[] = [];
  if (!rule.finance?.rate?.value || rule.finance.rate.value <= 0) {
    warnings.push('금리 미추출 또는 고시 금리 불명확');
  }
  if (!rule.eligibility?.credit_score?.value) {
    warnings.push('신용점수 조건 수동 확인 필요');
  }
  if (!rule.finance?.loan_limit_krw || rule.finance.loan_limit_krw <= 0) {
    warnings.push('대출 지원 한도 확인 요망');
  }
  if (rule.eligibility?.requires_credit_education) {
    warnings.push('사전 신용관리교육 이수 필수 요건 부과');
  }
  return warnings;
};

export interface AnnouncementStats {
  total: number;
  approved: number;
  pending: number;
  rejected: number;
  activeCount: number;
  averageCompleteness: number;
  closingWithin7Days: number;
  sourcesCount: number;
}

export const getAnnouncementStats = (list?: PolicyAnnouncement[]): AnnouncementStats => {
  const data = list || getAnnouncements();
  const total = data.length;
  const approved = data.filter(a => a.reviewStatus === 'approved').length;
  const pending = data.filter(a => a.reviewStatus === 'pending').length;
  const rejected = data.filter(a => a.reviewStatus === 'rejected').length;
  const activeCount = data.filter(a => a.isActive).length;
  
  const completenessSum = data.reduce((acc, a) => acc + (a.completenessScore || 0), 0);
  const averageCompleteness = total > 0 ? Math.round((completenessSum / total) * 10) / 10 : 0;

  // Mock / calculate closing within 7 days
  const closingWithin7Days = data.filter(a => a.budgetExhaustionRate > 80 || a.status === 'BUDGET_ALMOST_EXHAUSTED').length;
  const sources = new Set(data.map(a => a.source));

  return {
    total,
    approved,
    pending,
    rejected,
    activeCount,
    averageCompleteness,
    closingWithin7Days,
    sourcesCount: Math.max(5, sources.size)
  };
};

export const runCrawlerSyncSimulation = async (): Promise<{ added: number; updated: number }> => {
  // Simulate 3 retries, exponential backoff, and JSON extraction
  await new Promise(r => setTimeout(r, 1200));
  const current = getAnnouncements();
  
  // Randomly update budget exhaustion on some funds
  const updated = current.map(item => {
    if (item.reviewStatus === 'approved') {
      const newRate = Math.min(99, Math.max(10, item.budgetExhaustionRate + Math.floor(Math.random() * 5 - 2)));
      return {
        ...item,
        budgetExhaustionRate: newRate,
        lastUpdatedAt: new Date().toISOString()
      };
    }
    return item;
  });

  saveAnnouncements(updated);
  return { added: 0, updated: updated.length };
};
