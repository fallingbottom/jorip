/**
 * 소상공인 정책자금별 상세 신청 가이드 데이터 및 유틸리티
 * 
 * 소상공인시장진흥공단, 지역신용보증재단, 중소벤처기업진흥공단 등
 * 대표 정책자금별 신청 일정, 온라인·오프라인 접수 절차, 제출 서류 및 심사 전략 데이터
 */

export interface DetailedFundGuideItem {
  id: string;
  title: string;
  agency: string;
  badge: string;
  category: string;
  targetAudience: string;
  maxAmount: string;
  interestRate: string;
  repaymentPeriod: string;
  expectedScreeningTimeline: {
    isFastTrack: boolean;
    totalDuration: string;
    stages: Array<{
      stepNumber: number;
      stageName: string;
      institution: string;
      duration: string;
      description: string;
      actionRequired: string;
    }>;
  };
  applicationPeriod: {
    schedule: string;
    announcementCycle: string;
    nextOpenDate: string;
    timeNotice: string;
    urgencyTip: string;
  };
  applicationMethods: {
    online: {
      portalName: string;
      operatingHours: string;
      url: string;
      requiredAuth: string;
      steps: string[];
      keyTips: string;
    };
    offline: {
      locationName: string;
      operatingHours: string;
      phone: string;
      reservationNotice: string;
      steps: string[];
      bringItems: string[];
      keyTips: string;
    };
  };
  requiredDocuments: {
    specific: Array<{
      id: string;
      name: string;
      issuanceAgency: string;
      mandatory: boolean;
      purpose: string;
      tip: string;
    }>;
    common: Array<{
      id: string;
      name: string;
      agency: string;
      validity: string;
      isFree: boolean;
      portalUrl?: string;
      tip: string;
    }>;
  };
  underwritingCriteria: Array<{
    criterion: string;
    importance: string;
    standard: string;
    strategyTip: string;
  }>;
  troubleshootingGuide: Array<{
    problem: string;
    cause: string;
    actionableSolution: string;
  }>;
}

// 공통 전국 발급 기본 서류 세트
const COMMON_DOCUMENTS = [
  {
    id: "com-01",
    name: "사업자등록증명 (또는 사업자등록증 사본)",
    agency: "국세청 홈택스 / 정부24",
    validity: "최근 1개월 이내",
    isFree: true,
    portalUrl: "https://hometax.go.kr",
    tip: "홈택스 민원증명 메뉴에서 24시간 즉시 무료 발급(주민등록번호 뒷자리 공개 선택)."
  },
  {
    id: "com-02",
    name: "부가가치세과세표준증명 (최근 1~3개년)",
    agency: "국세청 홈택스",
    validity: "최근 3개월 이내",
    isFree: true,
    portalUrl: "https://hometax.go.kr",
    tip: "면세사업자는 '면세사업자수입금액증명', 간이과세자는 전년도분 전체를 발급받으세요."
  },
  {
    id: "com-03",
    name: "국세 완납증명서 (납세증명서)",
    agency: "국세청 홈택스",
    validity: "발급일로부터 30일",
    isFree: true,
    portalUrl: "https://hometax.go.kr",
    tip: "체납 사실이 없어야 유효하며 유효기간 만료 전 접수해야 합니다."
  },
  {
    id: "com-04",
    name: "지방세 완납증명서 (납세증명서)",
    agency: "위택스 / 정부24",
    validity: "발급일로부터 30일",
    isFree: true,
    portalUrl: "https://wetax.go.kr",
    tip: "위택스에서 온라인 즉시 무료 출력 가능, 관할 구청 세무과 방문 시 신분증 지참."
  },
  {
    id: "com-05",
    name: "주민등록표등본(초본)",
    agency: "정부24",
    validity: "최근 1개월 이내",
    isFree: true,
    portalUrl: "https://gov.kr",
    tip: "대표자 본인 실거주지 및 세대원 포함 내역 확인용(정부24 무료 발급)."
  },
  {
    id: "com-06",
    name: "4대사회보험 사업장 가입자명부",
    agency: "4대사회보험 정보연계센터",
    validity: "최근 1개월 이내",
    isFree: true,
    portalUrl: "https://4insure.4insure.or.kr",
    tip: "상시근로자 5인 미만(제조·광업·건설·운수는 10인 미만) 소상공인 여부 증빙 필수."
  }
];

export const POLICY_FUND_DETAILED_GUIDES: DetailedFundGuideItem[] = [
  {
    id: "fund-general-management",
    title: "일반경영안정자금",
    agency: "소상공인시장진흥공단 (대리대출)",
    badge: "가장 보편적",
    category: "운전자금",
    targetAudience: "업력 무관 소상공인(상시근로자 5인 미만, 제조업·건설업 등 10인 미만)",
    maxAmount: "최대 7,000만원",
    interestRate: "연 2.85% (분기별 변동금리, 정책기준금리 + 0.6%p)",
    repaymentPeriod: "5년 (2년 거치 후 3년 원금균등분할상환)",
    expectedScreeningTimeline: {
      isFastTrack: true,
      totalDuration: "접수 후 약 2~3주",
      stages: [
        {
          stepNumber: 1,
          stageName: "소상공인24 온라인 신청 및 확인서 발급",
          institution: "소상공인시장진흥공단",
          duration: "1~2영업일",
          description: "온라인 자격 사전진단 및 정책자금 지원대상 확인서 즉시 출력",
          actionRequired: "공동인증서 로그인 후 자가진단표 및 기본 사업정보 등록"
        },
        {
          stepNumber: 2,
          stageName: "지역신용보증재단 신용보증 심사",
          institution: "지역신용보증재단",
          duration: "5~7영업일",
          description: "사업장 현장 실사 또는 비대면 스크래핑을 통한 신용보증서 발급",
          actionRequired: "모바일 신보 앱 보증신청 및 서류 제출 완료"
        },
        {
          stepNumber: 3,
          stageName: "취급은행 대출 실행",
          institution: "시중 은행 (국민/신한/우리/하나/농협/기업 등)",
          duration: "2~3영업일",
          description: "발급된 보증서를 바탕으로 계좌 입금 및 약정 체결",
          actionRequired: "은행 영업점 방문 또는 비대면 모바일 대출 전자약정"
        }
      ]
    },
    applicationPeriod: {
      schedule: "매월 첫째 주 월요일 09:00 정각 접수 개시",
      announcementCycle: "매월 정기 공고 (예산 소진 시 조기 마감)",
      nextOpenDate: "매월 1일 09:00",
      timeNotice: "평일 09:00 ~ 18:00 (온라인 시스템 기준)",
      urgencyTip: "각 회차별 접수 시작 10분 이내에 관할 지역 한도가 마감될 수 있으므로 전날 자정까지 회원가입 및 서류 준비를 완료하세요."
    },
    applicationMethods: {
      online: {
        portalName: "소상공인정책자금 누리집 (ols.sbiz.or.kr) / 소상공인24",
        operatingHours: "24시간 접수 (신청 당일은 09:00 오픈)",
        url: "https://ols.sbiz.or.kr",
        requiredAuth: "대표자 본인 공동인증서, 금융인증서, 간편인증(카카오·PASS·토스)",
        steps: [
          "소상공인정책자금 누리집 접속 및 대표자 인증 로그인",
          "자가진단 체크리스트 (세금 체납, 신용불량 여부 확인)",
          "공공 마이데이터 정보제공 동의 (사업자등록증, 부가세증명 자동 연계)",
          "정책자금 지원대상 확인서 발급 신청 및 확인서 출력",
          "지역신용보증재단(온라인/앱) 또는 신한·국민 등 시중은행 연계 접수"
        ],
        keyTips: "공공 마이데이터를 이용하면 8종 관공서 서류가 30초 만에 자동 전송되어 별도 파일 업로드가 필요 없습니다."
      },
      offline: {
        locationName: "전국 77개 소상공인시장진흥공단 지역센터 또는 지역신용보증재단 지점",
        operatingHours: "평일 09:00 ~ 18:00 (점심시간 12:00 ~ 13:00 제외)",
        phone: "중소기업통합콜센터 1357 / 관할 신보 지점",
        reservationNotice: "사전 전화 예약 또는 누리집 방문 상담 예약 필수",
        steps: [
          "1357 콜센터를 통한 관할 센터 배정 및 상담 예약",
          "구비 서류 원본 지참 후 센터 내방",
          "정책자금 상담창구 서류 접수 및 자격 검토",
          "확인서 수령 후 지정 은행 방문 상담"
        ],
        bringItems: [
          "신분증(주민등록증/운전면허증)",
          "사업자등록증명",
          "부가가치세과세표준증명",
          "국세/지방세 납세증명서",
          "임대차계약서 사본"
        ],
        keyTips: "인터넷 이용이 익숙하지 않은 디지털 취약 차주는 관할 소상공인지원센터 매니저의 대면 입력 지원을 요청할 수 있습니다."
      }
    },
    requiredDocuments: {
      specific: [
        {
          id: "spec-gen-01",
          name: "정책자금 융자신청서 및 사업계획 요약서",
          issuanceAgency: "소상공인24 온라인 서식 작성",
          mandatory: true,
          purpose: "대출 자금의 신청 사유 및 운전계획 검토",
          tip: "월 고정지출(임대료, 인건비, 매입비용)을 수치화하여 신청금액과의 정합성을 명시하세요."
        },
        {
          id: "spec-gen-02",
          name: "사업장 임대차계약서 사본 (자가인 경우 부동산등기부등본)",
          issuanceAgency: "사업장 소재지 계약서 원본 촬영본",
          mandatory: true,
          purpose: "실제 사업 영위 장소 확인 및 임대보증금/월세 부담률 점검",
          tip: "확정일자 또는 계약 갱신 특약사항이 표기된 최신 계약서를 첨부하세요."
        },
        {
          id: "spec-gen-03",
          name: "최근 6개월 주거래 은행 계좌 거래내역서",
          issuanceAgency: "거래은행 인터넷뱅킹 / 지점",
          mandatory: false,
          purpose: "실제 매출 발생 현황 및 고정비 지출 흐름 교차 검증",
          tip: "매출 입금 계좌의 엑셀 또는 PDF 거래내역을 준비하면 심사 기간이 단축됩니다."
        }
      ],
      common: COMMON_DOCUMENTS
    },
    underwritingCriteria: [
      {
        criterion: "세금 완납 및 금융 연체 여부 (적격 필수 조건)",
        importance: "최고",
        standard: "국세·지방세 체납 없음, 신용평가기관 연체등록 사실 무",
        strategyTip: "단 1원의 소액 세금 체납도 즉시 자동 부결 처리되므로 위택스/홈택스에서 사전 완납 후 완납증명서를 발급받으세요."
      },
      {
        criterion: "매출액 대비 기존 부채 비율 (차입금 상환능력)",
        importance: "높음",
        standard: "총 대출 잔액이 연간 매출액의 100~150% 이내 유지",
        strategyTip: "제2금융권 고금리 대출이 있는 경우 정책자금 실행 후 상환 우선순위를 명시하여 부채 건전성을 소명하세요."
      },
      {
        criterion: "상시근로자 수 및 업종 적격성 (소상공인 법정 기준)",
        importance: "높음",
        standard: "제조/건설 10인 미만, 기타 도소매/서비스 5인 미만",
        strategyTip: "4대보험 가입자명부상 인원수 기준이며, 가족 종사자나 단기 알바생의 포함 여부를 명확히 구분하세요."
      },
      {
        criterion: "사업장의 실질 영위 여부 (유령회사 방지)",
        importance: "보통",
        standard: "현장 간판, 실제 영업 재고, 최근 신용카드 매출 전표 발생",
        strategyTip: "공유오피스나 주거지 사업장인 경우 실제 영업 활동 사진(명함, 제품, 집기)을 미리 구비해 두세요."
      }
    ],
    troubleshootingGuide: [
      {
        problem: "신청 첫날 오전 9시 시스템 접속 지연 및 대기열 초과",
        cause: "전국 동시 접속 폭주로 인한 인증서 로그인 서버 트래픽 병목",
        actionableSolution: "08시 40분 사전 로그인 후 간편인증(카카오/토스) 대신 크롬 브라우저에 저장된 금융인증서로 대기열을 우회 진입하세요."
      },
      {
        problem: "소상공인확인서 발급 시 '상시근로자 기준 초과' 알림",
        cause: "퇴사 근로자 4대보험 상실 신고가 공단 시스템에 미반영",
        actionableSolution: "국민건강보험EDI에서 '자격상실신고서 접수증'을 발급받아 관할 공단 센터에 팩스로 긴급 수기 수정을 요청하세요."
      },
      {
        problem: "신용보증재단 심사 중 기존 대출 한도 초과로 감액 또는 거절",
        cause: "기존 지역신보 및 신보·기보 보증잔액의 기보증 제한 한도 도달",
        actionableSolution: "보증부 대출 대신 소진공 '직접대출' 트랙으로 전환하거나, 기존 고금리 채무를 대환하는 조건부 승인을 협의하세요."
      }
    ]
  },
  {
    id: "fund-credit-vulnerable",
    title: "신용취약소상공인자금",
    agency: "소상공인시장진흥공단 (직접대출)",
    badge: "중·저신용자 특화",
    category: "특별자금",
    targetAudience: "NICE 또는 KCB 신용평점 839점 이하의 중·저신용 소상공인",
    maxAmount: "최대 3,000만원",
    interestRate: "연 3.85% (분기별 변동금리, 기준금리 + 1.6%p)",
    repaymentPeriod: "5년 (2년 거치 후 3년 분할상환)",
    expectedScreeningTimeline: {
      isFastTrack: true,
      totalDuration: "접수 후 약 10~14영업일",
      stages: [
        {
          stepNumber: 1,
          stageName: "신용관리 교육 온라인 이수",
          institution: "소상공인지식배움터",
          duration: "1일 (약 2시간)",
          description: "소상공인지식배움터 필수 동영상 교육 수료증 발급",
          actionRequired: "신청 전 반드시 수료증 번호 확보"
        },
        {
          stepNumber: 2,
          stageName: "소진공 직접대출 온라인 접수 및 심사",
          institution: "소상공인시장진흥공단",
          duration: "5~7영업일",
          description: "은행 보증서 없이 공단 심사관이 직접 신용 및 사업성 심사",
          actionRequired: "온라인 서류 제출 및 심사관 유선 인터뷰 응대"
        },
        {
          stepNumber: 3,
          stageName: "비대면 전자약정 및 즉시 입금",
          institution: "소상공인시장진흥공단",
          duration: "1~2영업일",
          description: "모바일 알림톡 인증을 통한 전자계약 체결 및 차주 명의 계좌 송금",
          actionRequired: "공동인증서 또는 모바일 본인인증으로 전자약정 서명"
        }
      ]
    },
    applicationPeriod: {
      schedule: "분기별 정기 공고 (예산 소진 시까지)",
      announcementCycle: "분기 1회",
      nextOpenDate: "공고일 상시 확인",
      timeNotice: "평일 09:00 ~ 18:00",
      urgencyTip: "취약차주를 위해 별도 배정된 특별 기금이므로 일반 은행 대출이 부결된 경우 최우선으로 접수하세요."
    },
    applicationMethods: {
      online: {
        portalName: "소상공인정책자금 누리집 (직접대출 전용 코너)",
        operatingHours: "24시간 접수",
        url: "https://ols.sbiz.or.kr",
        requiredAuth: "대표자 본인 인증서",
        steps: [
          "소상공인지식배움터 접속 후 '신용취약 사전교육' 수료 (2시간)",
          "소상공인정책자금 직접대출 신청 메뉴 접속",
          "NICE/KCB 신용평점 자동 조회 (839점 이하 확인)",
          "사업장 및 재무정보 입력 후 신청 완료",
          "공단 심사관 배정 후 비대면 전자약정"
        ],
        keyTips: "시중 은행을 거치지 않는 '직접대출'이므로 은행권 보증 거절 이력이 있어도 신청 가능합니다."
      },
      offline: {
        locationName: "소상공인시장진흥공단 관할 지역드림센터",
        operatingHours: "09:00 ~ 18:00",
        phone: "1357",
        reservationNotice: "사전 전화 예약 권장",
        steps: [
          "1357 상담 후 관할 센터 안내 수령",
          "교육 수료증 출력 및 구비서류 지참 방문",
          "현장 상담관과 1:1 심층 상담",
          "직접대출 신청서 수기 접수"
        ],
        bringItems: [
          "신용관리교육 수료증",
          "신분증",
          "사업자등록증명",
          "국세/지방세 납세증명서"
        ],
        keyTips: "신용도가 낮아 심리적 부담이 큰 소상공인도 재기 지원 컨설팅과 병행 지원받을 수 있습니다."
      }
    },
    requiredDocuments: {
      specific: [
        {
          id: "spec-vuln-01",
          name: "소상공인 신용관리 자가교육 이수증",
          issuanceAgency: "소상공인지식배움터 (edu.sbiz.or.kr)",
          mandatory: true,
          purpose: "금융 취약계층의 부채 관리 역량 및 신용 회복 의지 확인",
          tip: "온라인 2시간 강의 수강 후 즉시 PDF 발급 가능합니다."
        },
        {
          id: "spec-vuln-02",
          name: "부채 상환 및 사업 재기 계획서",
          issuanceAgency: "공단 표준 양식",
          mandatory: true,
          purpose: "대출금 실행 후 매월 원리금 상환 재원 확보 방안 소명",
          tip: "고정 매출처와 원가 절감 계획을 숫자로 기재하세요."
        }
      ],
      common: COMMON_DOCUMENTS
    },
    underwritingCriteria: [
      {
        criterion: "성실 경영 의지 및 현금흐름 유지도",
        importance: "최고",
        standard: "신용점수는 낮으나 최근 3개월간 실매출 발생 여부",
        strategyTip: "카드매출 입금 내역이나 POS 매출 기록을 증빙으로 제출하세요."
      },
      {
        criterion: "단기 연체금 및 체납 즉시 해소 여부",
        importance: "최고",
        standard: "신청일 현재 미납 세금 및 30일 이상 금융 연체 부존재",
        strategyTip: "기존 연체 채무가 남아있다면 접수 전 완제 또는 신복위 분할협약을 체결해야 합니다."
      }
    ],
    troubleshootingGuide: [
      {
        problem: "신용평점이 840점으로 1점 차이로 지원 불가 판정",
        cause: "NICE/KCB 중 한 곳만 충족해도 되나 전산상 두 평가사가 상이한 경우",
        actionableSolution: "NICE와 KCB 중 유리한 신용평가사 기준 확인서를 발급받아 공단 심사관에게 예외 인정을 신청하세요."
      }
    ]
  },
  {
    id: "fund-debt-refinance",
    title: "소상공인 대환대출",
    agency: "소상공인시장진흥공단 / 시중은행",
    badge: "이자 부담 경감",
    category: "대환자금",
    targetAudience: "7% 이상 고금리 대출을 3개월 이상 정상 이용 중인 중·저신용 소상공인",
    maxAmount: "최대 5,000만원",
    interestRate: "연 4.5% (10년 고정금리)",
    repaymentPeriod: "최대 10년 (거치기간 포함 장기분할)",
    expectedScreeningTimeline: {
      isFastTrack: false,
      totalDuration: "접수 후 약 2~4주",
      stages: [
        {
          stepNumber: 1,
          stageName: "고금리 대출 대상 확인 및 금융회사 채무내역서 발급",
          institution: "기존 대출 취급 금융기관",
          duration: "1~2영업일",
          description: "대환 대상 대출의 금리(7% 이상) 및 대출잔액 증명서 발급",
          actionRequired: "기존 금융사에 '금융거래확인서' 및 '부채잔액증명서' 요청"
        },
        {
          stepNumber: 2,
          stageName: "소상공인24 대환대출 대상 확인서 발급",
          institution: "소상공인시장진흥공단",
          duration: "1~2영업일",
          description: "온라인으로 지원 대상자 요건 검증 및 추천서 발급",
          actionRequired: "온라인 신청서 및 부채증명 서류 업로드"
        },
        {
          stepNumber: 3,
          stageName: "대환 취급은행 신청 및 기존 채무 직접 상환",
          institution: "6대 시중은행",
          duration: "7~10영업일",
          description: "신규 정책자금 대출로 기존 고금리 대출 원리금을 직접 대리 상환",
          actionRequired: "은행 영업점 방문하여 대환 입금 위임동의서 작성"
        }
      ]
    },
    applicationPeriod: {
      schedule: "연중 상시 접수 (예산 한도 내)",
      announcementCycle: "상시",
      nextOpenDate: "상시 접수 가능",
      timeNotice: "은행 및 온라인 영업시간",
      urgencyTip: "연 7% 이상의 제2금융권(저축은행·캐피탈·카드론) 대출 이자를 4.5% 고정으로 즉시 낮출 수 있는 가장 확실한 기회입니다."
    },
    applicationMethods: {
      online: {
        portalName: "소상공인정책자금 누리집 (ols.sbiz.or.kr)",
        operatingHours: "평일 09:00 ~ 18:00",
        url: "https://ols.sbiz.or.kr",
        requiredAuth: "대표자 본인 인증서",
        steps: [
          "기존 금융기관에서 금융거래확인서 발급",
          "소진공 누리집에서 '대환대출 지원대상 확인서' 신청",
          "확인서 승인 후 대환 취급 은행(국민/신한/우리 등) 방문 접수"
        ],
        keyTips: "대출금이 차주 통장으로 입금되는 것이 아니라 기존 고금리 채무 계좌로 은행 간 직접 상환 처리됩니다."
      },
      offline: {
        locationName: "대환대출 참여 6대 시중은행 영업점",
        operatingHours: "09:00 ~ 16:00",
        phone: "1357 및 각 은행 콜센터",
        reservationNotice: "영업점 기업상담창구 사전 방문 예약",
        steps: [
          "소진공 확인서 출력 후 은행 내방",
          "은행 심사역 상담 및 대환 대출 신청서 작성",
          "은행 승인 후 기존 채무 상환 영수증 수령"
        ],
        bringItems: [
          "소진공 지원대상 확인서",
          "기존 고금리 대출 부채잔액증명서",
          "신분증",
          "사업자등록증명"
        ],
        keyTips: "대환 대상 대출이 연체 중이면 대환이 불가하므로 연체 전 신청해야 합니다."
      }
    },
    requiredDocuments: {
      specific: [
        {
          id: "spec-ref-01",
          name: "기존 고금리 대출 금융거래확인서 및 부채증명원",
          issuanceAgency: "기존 대출 취급 금융기관(저축은행/카드사/캐피탈)",
          mandatory: true,
          purpose: "대출 실행일(3개월 이상 경과) 및 적용금리(연 7% 이상) 입증",
          tip: "발급 목적에 '대환대출 제출용'을 명시하고 대출 잔액과 금리가 기재되어야 합니다."
        }
      ],
      common: COMMON_DOCUMENTS
    },
    underwritingCriteria: [
      {
        criterion: "기존 대출의 금리 조건 및 정상 이용 기간",
        importance: "최고",
        standard: "적용금리 7% 이상, 최소 3개월 이상 정상 상환 중",
        strategyTip: "최근 1개월 이내 신규 실행된 대출은 대환 대상에서 제외될 수 있습니다."
      }
    ],
    troubleshootingGuide: [
      {
        problem: "카드론이나 현금서비스도 대환이 가능한지 여부",
        cause: "카드론은 건별 대출 확인서 발급 요건이 상이",
        actionableSolution: "카드사 고객센터에서 '카드론 금융거래확인서(대출과목, 금리, 최초약정일 명시)'를 정식 서면 발급받으면 인정됩니다."
      }
    ]
  },
  {
    id: "fund-youth-employment",
    title: "청년고용연계자금",
    agency: "소상공인시장진흥공단 (대리대출)",
    badge: "청년 우대",
    category: "고용창출자금",
    targetAudience: "만 39세 이하 청년 소상공인 또는 청년 근로자(만 34세 이하)를 고용한 사업장",
    maxAmount: "최대 7,000만원",
    interestRate: "연 2.45% (분기별 변동금리, 기준금리 수준 우대)",
    repaymentPeriod: "5년 (2년 거치 후 3년 원금균등분할상환)",
    expectedScreeningTimeline: {
      isFastTrack: true,
      totalDuration: "접수 후 약 2~3주",
      stages: [
        {
          stepNumber: 1,
          stageName: "청년 고용 요건 사전 검증 및 소진공 신청",
          institution: "소상공인시장진흥공단",
          duration: "1~2영업일",
          description: "청년 대표자 신분 확인 또는 청년 근로자 4대보험 가입 명부 검증",
          actionRequired: "소상공인24 온라인 접수"
        },
        {
          stepNumber: 2,
          stageName: "신용보증재단 청년 특례보증 심사",
          institution: "지역신용보증재단",
          duration: "5~7영업일",
          description: "보증료율 인하(0.8% 이하) 혜택 및 특례 보증서 발급",
          actionRequired: "신보 모바일 전자보증 신청"
        },
        {
          stepNumber: 3,
          stageName: "은행 대출 실행",
          institution: "시중 은행",
          duration: "2~3영업일",
          description: "우대금리 적용 대출금 계좌 입금",
          actionRequired: "전자약정 체결"
        }
      ]
    },
    applicationPeriod: {
      schedule: "매월 첫째 주 공고",
      announcementCycle: "매월 정기",
      nextOpenDate: "매월 1일",
      timeNotice: "09:00 ~ 18:00",
      urgencyTip: "청년 창업가 또는 청년 고용 기업에게 가장 낮은 금리가 적용되는 인기 자금입니다."
    },
    applicationMethods: {
      online: {
        portalName: "소상공인정책자금 누리집",
        operatingHours: "24시간 접수",
        url: "https://ols.sbiz.or.kr",
        requiredAuth: "대표자 본인 인증서",
        steps: [
          "온라인 자가진단표에서 '청년고용' 유형 체크",
          "공공 마이데이터 동의로 주민등록초본 및 4대보험 자동 전송",
          "확인서 발급 후 보증재단 접수"
        ],
        keyTips: "대표자가 만 39세를 넘더라도 만 34세 이하 청년 정규직 근로자가 1명 이상 있으면 동일 혜택을 받습니다."
      },
      offline: {
        locationName: "관할 소상공인센터 및 지역신보",
        operatingHours: "09:00 ~ 18:00",
        phone: "1357",
        reservationNotice: "사전 상담 예약",
        steps: ["서류 지참 방문", "청년 요건 대면 검증"],
        bringItems: ["신분증", "주민등록등본", "4대사회보험 가입자명부"],
        keyTips: "신규 채용 예정인 경우에도 채용 확약서를 제출하여 가점을 취득할 수 있습니다."
      }
    },
    requiredDocuments: {
      specific: [
        {
          id: "spec-youth-01",
          name: "4대사회보험 사업장 가입자명부 (청년 근로자 고용 입증)",
          issuanceAgency: "4대사회보험 정보연계센터",
          mandatory: true,
          purpose: "만 34세 이하 청년 상시근로자 재직 여부 확인 (대표자가 청년인 경우 주민등록초본으로 대체)",
          tip: "근로자 주민등록번호 앞자리가 명시되어 연령 확인이 가능해야 합니다."
        }
      ],
      common: COMMON_DOCUMENTS
    },
    underwritingCriteria: [
      {
        criterion: "청년 고용 유지 의지 및 근로 계약 적법성",
        importance: "높음",
        standard: "근로계약서 체결, 최저임금 준수, 4대보험 가입",
        strategyTip: "정규직 채용 및 1년 이상 고용 유지 계획을 사업계획서에 기재하세요."
      }
    ],
    troubleshootingGuide: [
      {
        problem: "만 39세 생일이 지난 달에 도래한 경우",
        cause: "신청일 기준 만 나이 초과",
        actionableSolution: "청년 근로자 고용 요건(만 34세 이하 직원 1인 이상)으로 전환 신청하시면 지원 대상이 됩니다."
      }
    ]
  },
  {
    id: "fund-special-manufacturer",
    title: "소공인특화자금",
    agency: "소상공인시장진흥공단 (직접/대리대출)",
    badge: "제조업 특화",
    category: "제조·시설자금",
    targetAudience: "상시근로자 10인 미만의 제조업 영위 소공인(금속가공, 기계, 섬유, 식품제조 등)",
    maxAmount: "운전 1억원 / 시설 5억원",
    interestRate: "연 2.65% ~ 3.25% (분기별 변동금리)",
    repaymentPeriod: "최대 8년 (거치 3년 포함 시설자금)",
    expectedScreeningTimeline: {
      isFastTrack: false,
      totalDuration: "접수 후 약 3~4주",
      stages: [
        {
          stepNumber: 1,
          stageName: "소진공 직접대출 온라인 신청",
          institution: "소상공인시장진흥공단",
          duration: "1~2영업일",
          description: "제조 공장등록증 또는 제조설비 사진 첨부 접수",
          actionRequired: "사업계획서 및 견적서 업로드"
        },
        {
          stepNumber: 2,
          stageName: "제조 현장 실사 및 기술성 평가",
          institution: "소진공 심사역 현장 실사",
          duration: "7~10영업일",
          description: "사업장 방문을 통한 기계 설비 가동 상태 및 납품 계약 검증",
          actionRequired: "공장 현장 정돈 및 주요 제품/원부자재 가동 확인"
        },
        {
          stepNumber: 3,
          stageName: "대출 승인 및 시설자금 분할 실행",
          institution: "소진공",
          duration: "3~5영업일",
          description: "전자약정 후 기계 구매처 세금계산서 대금 결제",
          actionRequired: "기계 공급업체 계약서 및 계좌 입금"
        }
      ]
    },
    applicationPeriod: {
      schedule: "매월 정기 공고",
      announcementCycle: "월 1회",
      nextOpenDate: "매월 초",
      timeNotice: "09:00 ~ 18:00",
      urgencyTip: "시설자금은 기계설비 매매계약서 및 세금계산서 발행 전 사전 신청해야 승인이 납니다."
    },
    applicationMethods: {
      online: {
        portalName: "소상공인정책자금 누리집",
        operatingHours: "24시간",
        url: "https://ols.sbiz.or.kr",
        requiredAuth: "사업자 공동인증서",
        steps: [
          "직접대출 코너에서 '소공인특화자금' 선택",
          "제조시설 내역 및 생산능력 작성",
          "기계도입 견적서 첨부"
        ],
        keyTips: "스마트공방 또는 클린사업장 지원사업 참여 이력이 있으면 최고 가점을 받습니다."
      },
      offline: {
        locationName: "전국 소공인특화지원센터",
        operatingHours: "09:00 ~ 18:00",
        phone: "1357",
        reservationNotice: "사전 방문 예약",
        steps: ["현장 상담", "시제품 및 제조 공정 확인"],
        bringItems: ["공장등록증(해당시)", "주요 설비 목록표", "제품 카탈로그"],
        keyTips: "임차 공장의 경우 집기 압류 방지 및 임대인의 기계 설치 동의 여부를 확인합니다."
      }
    },
    requiredDocuments: {
      specific: [
        {
          id: "spec-mfg-01",
          name: "제조공장등록증명서 (또는 직접생산증명서 / 제조설비확인서)",
          issuanceAgency: "정부24 또는 공장 소재지 지자체",
          mandatory: false,
          purpose: "제조업 실질 영위 및 자가 생산능력 검증",
          tip: "공장등록 면제 대상(500㎡ 미만)은 사업자등록증상 종목 '제조' 및 전기세 영수증으로 대체 가능합니다."
        },
        {
          id: "spec-mfg-02",
          name: "기계 설비 도입 견적서 및 사양서 (시설자금 신청 시)",
          issuanceAgency: "기계 공급업체",
          mandatory: true,
          purpose: "시설자금 실소요 금액 산출 및 도입 기계의 생산성 기여도 심사",
          tip: "비교 견적서 2부 이상 첨부 시 심사관 신뢰도가 향상됩니다."
        }
      ],
      common: COMMON_DOCUMENTS
    },
    underwritingCriteria: [
      {
        criterion: "자가 제조 설비 보유 및 수주 거래처 다변화",
        importance: "최고",
        standard: "단순 유통이 아닌 실질 임가공/제조 수행, 안정적 납품처 확보",
        strategyTip: "주요 거래처와의 최근 납품 계약서나 발주서(PO) 사본을 함께 제출하세요."
      }
    ],
    troubleshootingGuide: [
      {
        problem: "공장등록증이 없는 영세 소공인",
        cause: "사업장 면적이 작거나 건축물대장상 2종 근생 제조소로 등록된 경우",
        actionableSolution: "건축물관리대장 및 현장 제조설비 가동 사진 5컷(외부 간판, 작업장 전경, 주요 가공 기계, 원자재, 완제품)을 첨부하면 심사관이 인정합니다."
      }
    ]
  },
  {
    id: "fund-smart-growth",
    title: "혁신성장촉진자금",
    agency: "소상공인시장진흥공단 (직접대출)",
    badge: "스마트·DX 특화",
    category: "성장촉진자금",
    targetAudience: "스마트기술(키오스크, 테이블오더, AI로봇 등) 도입 소상공인, 수출형·백년가게 등 혁신 소상공인",
    maxAmount: "일반형 1억원 / 시설 5억원",
    interestRate: "연 2.65% (기준금리 + 0.4%p)",
    repaymentPeriod: "최대 8년 (거치기간 포함)",
    expectedScreeningTimeline: {
      isFastTrack: true,
      totalDuration: "접수 후 약 2~3주",
      stages: [
        {
          stepNumber: 1,
          stageName: "스마트기술 도입 계획서 작성 및 온라인 신청",
          institution: "소상공인시장진흥공단",
          duration: "1~2영업일",
          description: "디지털 전환(DX) 기술 도입 계획 온라인 심사",
          actionRequired: "도입 장비 사양서 첨부"
        },
        {
          stepNumber: 2,
          stageName: "직접대출 기술평가 심사",
          institution: "소진공",
          duration: "5~7영업일",
          description: "혁신성 및 경영 효율화 개선 가능성 평가",
          actionRequired: "심사관 인터뷰 대응"
        },
        {
          stepNumber: 3,
          stageName: "전자약정 및 대출 실행",
          institution: "소진공",
          duration: "2~3영업일",
          description: "전자서명 후 계좌 송금",
          actionRequired: "전자계약 서명"
        }
      ]
    },
    applicationPeriod: {
      schedule: "매월 정기 접수",
      announcementCycle: "월 1회",
      nextOpenDate: "매월 초",
      timeNotice: "09:00 ~ 18:00",
      urgencyTip: "소상공인시장진흥공단의 '스마트상점 기술보급사업' 선정 소상공인은 우선 배정됩니다."
    },
    applicationMethods: {
      online: {
        portalName: "소상공인정책자금 누리집",
        operatingHours: "24시간",
        url: "https://ols.sbiz.or.kr",
        requiredAuth: "사업자 공동인증서",
        steps: ["혁신형 유형 선택", "스마트설비 도입 계약서 등록", "자가진단 제출"],
        keyTips: "서빙로봇, 무인 키오스크, 클라우드 ERP 등 도입 내역 증빙 시 손쉽게 인정됩니다."
      },
      offline: {
        locationName: "관할 소진공 드림센터",
        operatingHours: "09:00 ~ 18:00",
        phone: "1357",
        reservationNotice: "방문 예약",
        steps: ["센터 방문", "혁신성 소명"],
        bringItems: ["신분증", "스마트기기 계약서", "사업자등록증"],
        keyTips: "백년가게 또는 백년소공인 지정서는 심사 프리패스 요건입니다."
      }
    },
    requiredDocuments: {
      specific: [
        {
          id: "spec-smart-01",
          name: "스마트기술 도입 계약서 또는 견적서 (키오스크, 테이블오더, 자동화 설비 등)",
          issuanceAgency: "스마트기술 솔루션 공급업체",
          mandatory: true,
          purpose: "혁신형 자금 지원 요건 부합성 및 기술 도입 실효성 확인",
          tip: "도입 후 인건비 절감액 및 회전율 개선 예상치를 간략히 기재하세요."
        }
      ],
      common: COMMON_DOCUMENTS
    },
    underwritingCriteria: [
      {
        criterion: "디지털 전환에 따른 생산성 개선 가능성",
        importance: "높음",
        standard: "기기 도입을 통한 원가 절감 또는 온라인 판로 확대 계획 타당성",
        strategyTip: "도입 전후의 인건비 및 주문 처리 속도 비교표를 첨부하세요."
      }
    ],
    troubleshootingGuide: [
      {
        problem: "이미 도입을 완료한 기기의 소급 지원 가능 여부",
        cause: "신청일 기준 3개월 이내 도입 설치 완료 건",
        actionableSolution: "세금계산서 및 설치 완료 확인서를 제출하면 3개월 이내 집행 건에 한해 인정됩니다."
      }
    ]
  }
];

/**
 * 펀드 제목이나 키워드로 가장 일치하는 상세 가이드 데이터를 반환합니다.
 * 매칭되는 것이 없으면 일반경영안정자금을 기반으로 유연한 기본 가이드를 생성하여 반환합니다.
 */
export function getDetailedGuideByFundKey(fundKey: string): DetailedFundGuideItem {
  if (!fundKey || fundKey.trim() === '') {
    return POLICY_FUND_DETAILED_GUIDES[0];
  }

  const query = fundKey.trim().toLowerCase();

  // 1. 정확한 ID 일치
  const byId = POLICY_FUND_DETAILED_GUIDES.find(g => g.id.toLowerCase() === query);
  if (byId) return byId;

  // 2. 정확한 Title 일치
  const byTitle = POLICY_FUND_DETAILED_GUIDES.find(g => g.title.toLowerCase() === query);
  if (byTitle) return byTitle;

  // 3. 키워드 매칭
  if (query.includes('신용취약') || query.includes('저신용') || query.includes('취약')) {
    const found = POLICY_FUND_DETAILED_GUIDES.find(g => g.id === 'fund-credit-vulnerable');
    if (found) return found;
  }
  if (query.includes('대환') || query.includes('고금리')) {
    const found = POLICY_FUND_DETAILED_GUIDES.find(g => g.id === 'fund-debt-refinance');
    if (found) return found;
  }
  if (query.includes('청년') || query.includes('청년고용') || query.includes('테크스타')) {
    const found = POLICY_FUND_DETAILED_GUIDES.find(g => g.id === 'fund-youth-employment');
    if (found) return found;
  }
  if (query.includes('소공인') || query.includes('제조') || query.includes('시설')) {
    const found = POLICY_FUND_DETAILED_GUIDES.find(g => g.id === 'fund-special-manufacturer');
    if (found) return found;
  }
  if (query.includes('스마트') || query.includes('혁신') || query.includes('dx')) {
    const found = POLICY_FUND_DETAILED_GUIDES.find(g => g.id === 'fund-smart-growth');
    if (found) return found;
  }

  // 4. 일반 부분 매칭
  const partial = POLICY_FUND_DETAILED_GUIDES.find(g => 
    query.includes(g.title.toLowerCase()) || g.title.toLowerCase().includes(query)
  );
  if (partial) return partial;

  // 5. 동적 커스텀 객체 생성 (기본 템플릿에 사용자 정책명 적용)
  const defaultBase = POLICY_FUND_DETAILED_GUIDES[0];
  return {
    ...defaultBase,
    id: `fund-${encodeURIComponent(fundKey)}`,
    title: fundKey,
    badge: "정부 지원",
    targetAudience: `${fundKey} 지원 대상 소상공인 및 중소기업`,
    description: `${fundKey} 맞춤형 정책자금 신청 가이드`,
    requiredDocuments: {
      ...defaultBase.requiredDocuments,
      specific: [
        {
          id: `spec-${encodeURIComponent(fundKey)}-01`,
          name: `${fundKey} 전용 융자신청서 및 사업계획서`,
          issuanceAgency: "소상공인24 또는 소관 기관 누리집",
          mandatory: true,
          purpose: "자금 사용 목적 및 상환 계획 심사",
          tip: "정책 목적에 부합하는 정량적 기대 효과(매출 증대, 고용 창출)를 기술하세요."
        },
        ...defaultBase.requiredDocuments.specific.slice(1)
      ]
    }
  } as DetailedFundGuideItem;
}
