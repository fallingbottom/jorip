import { SourcePolicy } from '../types';

/**
 * 주요 정책자금 집행 기관(신용보증재단, 소상공인24, 중기부, 신보, 기보 등)의 
 * 실시간 상태를 시뮬레이션합니다.
 */
export const getDefaultPolicyData = (): SourcePolicy[] => {
  const now = new Date().toISOString();
  const funds: Array<Omit<SourcePolicy, 'applicationUrl' | 'requiredDocuments'>> = [
    {
      name: "일반경영안정자금",
      matchConstraints: { maxEmployees: 5, maxRevenue: 3000000000 },
      agency: "소상공인시장진흥공단 (대리대출)",
      baseInterestRate: "정책자금 기준금리 + 0.6%p (변동)",
      currentStatus: "OPEN",
      budgetExhaustionRate: 65,
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "업력과 무관하게 보편적인 유동성을 공급하는 소상공인 대상 경영안정자금",
      eligibility: "업력 무관 소상공인",
      maxAmount: "70,000,000",
      repaymentPeriod: "2년 거치 3년 원금균등분할상환 (총 5년)",
      applicationProcedure: ["소상공인정책자금 누리집 신청", "지원대상 확인서 발급", "보증기관 및 은행 방문 대출"],
      contactInfo: "중소기업통합콜센터 (1357)"
    },
    {
      name: "신용취약소상공인자금",
      matchConstraints: { maxEmployees: 5 },
      agency: "소상공인시장진흥공단 (직접대출)",
      baseInterestRate: "정책자금 기준금리 + 1.6%p (변동)",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "신용취약계층 소상공인의 유동성 위기 극복을 위한 특별경영안정자금",
      eligibility: "NCB 839점 이하 중·저신용자 (사전 신용관리교육 필수 이수)",
      maxAmount: "30,000,000",
      repaymentPeriod: "2년 거치 3년 원금균등분할상환 (총 5년)",
      applicationProcedure: ["사전 신용관리교육 이수", "소상공인정책자금 누리집 신청", "공단 직접 심사 및 전자약정"],
      contactInfo: "중소기업통합콜센터 (1357)"
    },
    {
      name: "대환대출",
      agency: "소상공인시장진흥공단 (대리대출)",
      baseInterestRate: "연 4.5% (고정금리)",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-05",
      endDate: "2026-12-31",
      announcementDate: "2026-01-05",
      description: "고금리 대출을 저금리 및 장기분할상환으로 전환하여 금융부담 완화",
      eligibility: "7% 이상 고금리 대출을 보유한 중·저신용 소상공인",
      maxAmount: "50,000,000",
      repaymentPeriod: "최대 10년",
      applicationProcedure: ["지원대상 확인서 발급", "대환대출 취급은행 접수·심사", "기존 대출 대환처리"],
      contactInfo: "중소기업통합콜센터 (1357)"
    },
    {
      name: "청년고용연계자금",
      matchConstraints: { minFoundedYears: 0 },
      agency: "소상공인시장진흥공단 (대리대출)",
      baseInterestRate: "정책자금 기준금리 (변동)",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "청년 고용 소상공인 또는 청년 소상공인의 경영 안정 지원",
      eligibility: "청년(만 39세 이하) 소상공인 또는 만 34세 이하 청년 근로자 고용 사업장",
      maxAmount: "70,000,000",
      repaymentPeriod: "2년 거치 3년 원금균등분할상환 (총 5년)",
      applicationProcedure: ["소상공인정책자금 누리집 신청", "은행 대리대출 신청"],
      contactInfo: "중소기업통합콜센터 (1357)"
    },
    {
      name: "재도전특별자금",
      agency: "소상공인시장진흥공단 (직접대출)",
      baseInterestRate: "정책자금 기준금리 + 0.4%p ~ 1.6%p (유형별 가산금리)",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "채무조정 등 재창업 및 재도전 소상공인의 성공적인 재기 지원",
      eligibility: "재창업 또는 채무조정(성실상환) 등 재도전 소상공인",
      maxAmount: "일반형 7천만원, 희망형 1억원, 도약형 2억원",
      repaymentPeriod: "거치기간 포함 분할상환",
      applicationProcedure: ["소상공인정책자금 누리집 신청", "공단 심사 및 대출"],
      contactInfo: "중소기업통합콜센터 (1357)"
    },
    {
      name: "장애인기업지원자금",
      agency: "소상공인시장진흥공단 (대리대출)",
      baseInterestRate: "연 2.0% (고정금리)",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "장애인 소상공인의 경영 안정 및 자립 지원",
      eligibility: "장애인기업 확인서를 발급받은 장애인 소상공인",
      maxAmount: "100,000,000",
      repaymentPeriod: "2년 거치 5년 원금균등분할상환 (총 7년)",
      applicationProcedure: ["소상공인정책자금 누리집 신청", "대리대출 취급은행 신청"],
      contactInfo: "중소기업통합콜센터 (1357)"
    },
    {
      name: "긴급경영안정자금 (재해/경영애로)",
      agency: "소상공인시장진흥공단",
      baseInterestRate: "재해 2.0% (고정) / 경영애로 기준금리 (변동)",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "재해 피해 및 일시적 경영애로(매출 15% 이상 감소 등)를 겪는 소상공인 긴급 지원",
      eligibility: "재해 피해 소상공인 또는 매출 15% 이상 감소 소상공인",
      maxAmount: "재해 1억원 / 경영애로 70,000,000",
      repaymentPeriod: "거치기간 포함 분할상환",
      applicationProcedure: ["피해 사실 확인서 발급", "공단 신청 및 심사"],
      contactInfo: "중소기업통합콜센터 (1357)"
    },
    {
      name: "소공인특화자금",
      matchConstraints: { targetIndustries: ["MANUFACTURING"], maxEmployees: 10 },
      agency: "소상공인시장진흥공단 (대리/직접대출)",
      baseInterestRate: "정책자금 기준금리 + 0.4%p ~ 0.6%p (변동)",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "제조업 기반 소공인의 성장 지원을 위한 운전 및 시설자금",
      eligibility: "상시근로자 10인 미만 제조업 소공인",
      maxAmount: "운전 1억원 / 일반형 시설 5억원, 유망형 시설 10억원",
      repaymentPeriod: "거치기간 포함 분할상환",
      applicationProcedure: ["소상공인정책자금 누리집 신청", "공단 심사 또는 은행 보증/대출"],
      contactInfo: "중소기업통합콜센터 (1357)"
    },
    {
      name: "혁신성장촉진자금",
      agency: "소상공인시장진흥공단 (직접대출)",
      baseInterestRate: "정책자금 기준금리 + 0.4%p (변동)",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "혁신형 기업, 스마트상점 도입 등 혁신 소상공인의 성장 촉진",
      eligibility: "스마트기술 도입, 혁신형 소상공인 등 정책적 지원이 필요한 소상공인",
      maxAmount: "일반형 시설 5억원 / 혁신형 시설 10억원 이내",
      repaymentPeriod: "거치기간 포함 분할상환",
      applicationProcedure: ["소상공인정책자금 누리집 신청", "공단 직접 심사"],
      contactInfo: "중소기업통합콜센터 (1357)"
    },
    {
      name: "상생성장지원자금",
      agency: "소상공인시장진흥공단 (직접대출)",
      baseInterestRate: "정책자금 기준금리 + 0.4%p (변동)",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "민간 벤처캐피털 매칭 및 대기업 플랫폼 연계 상생성장 지원",
      eligibility: "상생지원 프로그램 참여 소상공인",
      maxAmount: "일반형 7천만원, 성장형 5억원, 도약형 10억원",
      repaymentPeriod: "거치기간 포함 분할상환",
      applicationProcedure: ["소상공인정책자금 누리집 신청", "공단 직접 심사"],
      contactInfo: "중소기업통합콜센터 (1357)"
    },
    {
      name: "청년테크스타보증",
      matchConstraints: { maxFoundedYears: 7 },
      agency: "기술보증기금 (KIBO)",
      baseInterestRate: "보증부대출 취급은행 금리",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "우수 기술을 보유한 청년 창업자의 혁신성장 및 기술개발 지원",
      eligibility: "대표자가 만 39세 이하이고 창업 후 7년 이내인 기술혁신형 중소기업",
      maxAmount: "300,000,000",
      repaymentPeriod: "최대 5년 (거치 2년 포함)",
      applicationProcedure: ["기술보증기금 영업점 방문 또는 온라인 상담", "기술평가 및 보증심사", "보증서 발급 및 은행 대출"],
      contactInfo: "기술보증기금 고객센터 (1544-1120)"
    },
    {
      name: "미소금융 창업·운영자금",
      agency: "서민금융진흥원 (미소금융)",
      baseInterestRate: "연 4.5% (고정금리)",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "제도권 금융 이용이 어려운 취약계층의 창업 및 생계형 사업 운영 지원",
      eligibility: "개인신용평점 하위 20% 이거나 기초생활수급자·차상위계층",
      maxAmount: "창업 70,000,000 / 운영 20,000,000",
      repaymentPeriod: "최대 5.5년 (거치 6개월 포함)",
      applicationProcedure: ["서민금융진흥원 또는 미소금융 지점 방문 상담", "사업장 현장실사 및 심사", "대출금 지급"],
      contactInfo: "서민금융콜센터 (1397)"
    },
    {
      name: "스타트업 NEST 보증",
      matchConstraints: { maxFoundedYears: 3 },
      agency: "신용보증기금 (KODIT)",
      baseInterestRate: "보증부대출 취급은행 금리",
      currentStatus: "OPEN",
      budgetExhaustionRate: 68,
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "유망 스타트업을 발굴하여 보증, 투자 등 금융지원 및 컨설팅 융복합 지원",
      eligibility: "창업 후 3년 이내의 혁신성장 유망 스타트업",
      maxAmount: "500,000,000",
      repaymentPeriod: "협약 은행 기준에 따름",
      applicationProcedure: ["신보스타트업 플랫폼 회원가입 및 접수", "서류 및 발표 평가", "보증 및 금융지원"],
      contactInfo: "신용보증기금 고객센터 (1588-6565)"
    },
    {
      name: "온라인셀러 특별보증",
      agency: "신용보증기금 (KODIT)",
      baseInterestRate: "보증부대출 취급은행 금리",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "전자상거래 플랫폼(쿠팡, 네이버 등) 입점 소상공인을 위한 선정산 및 유동성 지원",
      eligibility: "주요 이커머스 플랫폼에 입점하여 6개월 이상 영업 중인 온라인 셀러",
      maxAmount: "100,000,000",
      repaymentPeriod: "최대 5년",
      applicationProcedure: ["온라인셀러 전용 플랫폼 또는 신용보증기금 영업점 신청", "매출 데이터 기반 보증심사", "보증서 발급"],
      contactInfo: "신용보증기금 고객센터 (1588-6565)"
    }

  ];

  return funds.map(fund => {
    // Default URL and Documents based on agency
    let applicationUrl = "https://ols.semas.or.kr";
    let requiredDocuments = [
      "사업자등록증명원 (최근 1개월 이내)",
      "부가가치세과세표준증명원 (최근 3개년)",
      "국세 및 지방세 납세증명서",
      "임대차계약서 사본 또는 부동산등기부등본",
      "대표자 신분증 및 주민등록등본"
    ];

    if (fund.agency.includes("기술보증기금")) {
      applicationUrl = "https://www.kibo.or.kr";
      requiredDocuments.push("기술사업계획서");
      requiredDocuments.push("재무제표 (최근 3개년)");
    } else if (fund.agency.includes("서민금융진흥원")) {
      applicationUrl = "https://www.kinfa.or.kr";
      requiredDocuments.push("기초생활수급자/차상위계층 증명서 (해당시)");
    } else if (fund.agency.includes("신용보증기금")) {
      applicationUrl = "https://www.kodit.co.kr";
      requiredDocuments.push("법인등기부등본 (법인인 경우)");
      requiredDocuments.push("주주명부");
    }

    if (fund.name.includes("온라인셀러")) {
      requiredDocuments.push("온라인 쇼핑몰 매출 내역서");
    }

    return {
      ...fund,
      applicationUrl,
      requiredDocuments
    };
  });
};

export const fetchLatestPolicyData = async (): Promise<SourcePolicy[]> => {
  await new Promise(resolve => setTimeout(resolve, 400));
  return getDefaultPolicyData();
};
