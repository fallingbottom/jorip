import { 
  UserProfile, 
  SourcePolicy, 
  PolicyComparisonAnalysis, 
  PolicyCriteriaCheck, 
  ComprehensiveEvaluationResult,
  Industry,
  BusinessType
} from '../types';
import { getDefaultPolicyData } from './fundDataSource';

export const formatKoreanCurrency = (amount: number): string => {
  if (!amount || amount <= 0) return '0원';
  const eok = Math.floor(amount / 100000000);
  const man = Math.floor((amount % 100000000) / 10000);
  
  if (eok > 0 && man > 0) {
    return `${eok}억 ${man.toLocaleString()}만원`;
  } else if (eok > 0) {
    return `${eok}억원`;
  } else {
    return `${man.toLocaleString()}만원`;
  }
};

const parseAmountNumber = (amountStr?: string): number => {
  if (!amountStr) return 50000000;
  const cleaned = amountStr.replace(/[^0-9]/g, '');
  return cleaned ? parseInt(cleaned, 10) : 50000000;
};

// 소상공인 기준: 제조업/건설업/운수업 10인 미만, 기타 5인 미만
export const isSmallBusinessByEmployee = (industry: Industry, employees: number): { isSmall: boolean; limit: number } => {
  const is10Limit = [Industry.MANUFACTURING].includes(industry);
  const limit = is10Limit ? 10 : 5;
  return {
    isSmall: employees < limit,
    limit
  };
};

export const evaluatePolicyQualifications = (
  profile: UserProfile,
  policies: SourcePolicy[] = getDefaultPolicyData()
): ComprehensiveEvaluationResult => {
  const currentYear = new Date().getFullYear();
  const foundedYear = parseInt(profile.foundedYear, 10) || currentYear;
  const businessYears = Math.max(0, currentYear - foundedYear);

  const totalDebt = (profile.debt1Tier || 0) + 
                    (profile.debt2Tier || 0) + 
                    (profile.debtCardLoan || 0) + 
                    (profile.debtOther || 0);

  // 부채비율 계산 (총부채 / 연매출 * 100)
  const calculatedDebtRatio = profile.debtRatio !== undefined && profile.debtRatio > 0
    ? profile.debtRatio
    : (profile.annualRevenue > 0 ? Math.round((totalDebt / profile.annualRevenue) * 100) : 0);

  // 부채비율 등급 산정
  let debtRatioGrade: 'SAFE' | 'NORMAL' | 'WARNING' | 'HIGH_RISK' = 'SAFE';
  if (calculatedDebtRatio > 200) {
    debtRatioGrade = 'HIGH_RISK';
  } else if (calculatedDebtRatio > 100) {
    debtRatioGrade = 'WARNING';
  } else if (calculatedDebtRatio > 50) {
    debtRatioGrade = 'NORMAL';
  } else {
    debtRatioGrade = 'SAFE';
  }

  // 기존 정책자금 잔액 총합 및 최근 부결 이력 확인
  const histories = profile.applicationHistories || [];
  let existingPolicyFundBalance = 0;
  let hasRecentRejectionIn6Months = false;
  let hasShinboHistory = false;
  let hasKiboHistory = false;
  let recentRejectionAgency = '';

  histories.forEach(h => {
    if (h.status === 'APPROVED') {
      existingPolicyFundBalance += (h.remainingBalance || h.approvedAmount || 0);
    }
    if (h.status === 'REJECTED') {
      // 최근 1년/6개월 내 부결 확인
      if (h.applyYear === currentYear || (h.applyYear === currentYear - 1 && (h.applyMonth || 12) >= 6)) {
        hasRecentRejectionIn6Months = true;
        recentRejectionAgency = h.agency;
      }
    }
    const agencyLower = h.agency.toLowerCase();
    if (agencyLower.includes('신용보증기금') || agencyLower.includes('신보')) {
      hasShinboHistory = true;
    }
    if (agencyLower.includes('기술보증기금') || agencyLower.includes('기보')) {
      hasKiboHistory = true;
    }
  });

  const { isSmall, limit: employeeLimit } = isSmallBusinessByEmployee(profile.industry, profile.employees);

  const evaluatedList: PolicyComparisonAnalysis[] = [];
  const restrictionAlerts: ComprehensiveEvaluationResult['restrictionAlerts'] = [];

  // 체납 및 연체 공통 경고
  if (profile.hasTaxArrears) {
    restrictionAlerts.push({
      type: 'CRITICAL',
      title: '국세 및 지방세 체납 주의',
      message: '정부 지원 정책자금은 조세완납증명서 제출이 필수 요건입니다. 체납 상태에서는 모든 정책자금 신청이 원칙적으로 즉시 부결됩니다.',
      solution: '홈택스/위택스를 통해 체납 세금을 완납하거나 분납 승인을 취득한 후 납세증명서를 구비하여 신청하십시오.'
    });
  }

  if (profile.hasOverdue) {
    restrictionAlerts.push({
      type: 'CRITICAL',
      title: '금융기관 대출·카드 연체 주의',
      message: '연체 정보가 신용정보원(KCB/NICE)에 등록되어 있을 경우 보증서 발급 및 공단 직접대출 심사가 불가합니다.',
      solution: '단기 연체금을 최우선 상환하고 연체 해제 정보가 전산 반영(통상 영업일 1~3일)된 후 접수하시길 권장합니다.'
    });
  }

  // 중복 보증 제한 경고
  if (hasShinboHistory && hasKiboHistory) {
    restrictionAlerts.push({
      type: 'WARNING',
      title: '신보 및 기보 중복보증 제한 유의',
      message: '신용보증기금과 기술보증기금은 원칙적으로 중복 보증이 엄격히 금지됩니다.',
      solution: '기존 이용 중인 보증기관을 확인하고 한 기관으로 보증 라인을 일원화하거나 소상공인진흥공단 직접대출로 신청 경로를 설정하세요.'
    });
  }

  // 최근 부결 이력 경고
  if (hasRecentRejectionIn6Months) {
    restrictionAlerts.push({
      type: 'WARNING',
      title: `최근 6개월 내 ${recentRejectionAgency || '정책자금'} 부결 이력`,
      message: '동일 기관에 부결 후 6개월 이내 재신청할 경우 심사 반려 사유가 될 수 있습니다.',
      solution: '부결 사유(부채비율, 신용도 등)를 보완하거나 소진공 ↔ 지역신용보증재단 등 주관 기관 및 취급 채널(직접/대리)을 우회하여 신청하세요.'
    });
  }

  for (const policy of policies) {
    const criteriaChecks: PolicyCriteriaCheck[] = [];
    let matchScore = 85;
    let qualificationStatus: 'ELIGIBLE' | 'CONDITIONAL' | 'INELIGIBLE' = 'ELIGIBLE';
    const c = policy.matchConstraints;
    const policyMaxRaw = parseAmountNumber(policy.maxAmount);
    const policyName = policy.name;

    // 1. 종사자 수 (소상공인 기준 검증)
    const maxEmp = c?.maxEmployees !== undefined ? c.maxEmployees : employeeLimit;
    if (profile.employees > maxEmp) {
      matchScore -= 45;
      qualificationStatus = 'INELIGIBLE';
      criteriaChecks.push({
        criterion: '상시 종사자 수',
        userValue: `${profile.employees}인`,
        policyRequirement: `${maxEmp}인 이하 (소상공인 기준)`,
        status: 'FAILED',
        detail: `상시근로자 기준(${maxEmp}인 이하)을 초과하여 본 정책자금 지원 대상에서 제외됩니다.`
      });
    } else {
      criteriaChecks.push({
        criterion: '상시 종사자 수',
        userValue: `${profile.employees}인`,
        policyRequirement: `${maxEmp}인 이하`,
        status: 'MET',
        detail: `상시근로자 수 ${profile.employees}인으로 소상공인 요건을 완벽히 충족합니다.`
      });
    }

    // 2. 업종 요건
    if (c?.targetIndustries && c.targetIndustries.length > 0) {
      if (c.targetIndustries.includes(profile.industry)) {
        matchScore += 15;
        criteriaChecks.push({
          criterion: '업종 요건',
          userValue: profile.industry,
          policyRequirement: c.targetIndustries.join(', '),
          status: 'MET',
          detail: '지원 대상 우선 우대 업종에 해당하여 심사 가점이 부여됩니다.'
        });
      } else {
        matchScore -= 50;
        qualificationStatus = 'INELIGIBLE';
        criteriaChecks.push({
          criterion: '업종 요건',
          userValue: profile.industry,
          policyRequirement: c.targetIndustries.join(', ') + ' 전용',
          status: 'FAILED',
          detail: '본 자금은 특정 타 업종 전용 특화자금으로 해당되지 않습니다.'
        });
      }
    } else {
      criteriaChecks.push({
        criterion: '업종 요건',
        userValue: profile.industry,
        policyRequirement: '소상공인 전 업종 (유흥·사행성 제외)',
        status: 'MET',
        detail: '융자제한업종이 아닌 일반 지원 가능 업종에 해당합니다.'
      });
    }

    // 3. 업력 (개업연도 기준)
    if (c?.maxFoundedYears !== undefined && businessYears > c.maxFoundedYears) {
      matchScore -= 40;
      qualificationStatus = 'INELIGIBLE';
      criteriaChecks.push({
        criterion: '사업 업력 (창업 기간)',
        userValue: `${businessYears}년차`,
        policyRequirement: `창업 후 ${c.maxFoundedYears}년 이내`,
        status: 'FAILED',
        detail: `업력 제한(${c.maxFoundedYears}년 이내)을 초과하였습니다. (현재 업력: ${businessYears}년)`
      });
    } else if (c?.minFoundedYears !== undefined && businessYears < c.minFoundedYears) {
      matchScore -= 40;
      qualificationStatus = 'INELIGIBLE';
      criteriaChecks.push({
        criterion: '사업 업력 (창업 기간)',
        userValue: `${businessYears}년차`,
        policyRequirement: `창업 후 ${c.minFoundedYears}년 이상`,
        status: 'FAILED',
        detail: `최소 필요 업력(${c.minFoundedYears}년 이상)에 미달하였습니다.`
      });
    } else {
      criteriaChecks.push({
        criterion: '사업 업력',
        userValue: `${businessYears}년차 (개업: ${profile.foundedYear}년)`,
        policyRequirement: c?.maxFoundedYears ? `${c.maxFoundedYears}년 이내` : '업력 무관',
        status: 'MET',
        detail: '업력 요건을 충족합니다.'
      });
    }

    // 4. 신용도 (Credit Score)
    const isLowCreditFund = policyName.includes('신용취약') || policyName.includes('대환대출') || policyName.includes('미소금융');
    if (isLowCreditFund) {
      if (profile.creditScore <= 839) {
        matchScore += 20;
        criteriaChecks.push({
          criterion: '대표자 신용점수',
          userValue: `${profile.creditScore}점`,
          policyRequirement: 'NCB/KCB 839점 이하 (중·저신용자 특화)',
          status: 'MET',
          detail: '취약계층 및 중·저신용자 전용 우대 기준에 부합하여 승인율이 높습니다.'
        });
      } else {
        matchScore -= 40;
        qualificationStatus = 'INELIGIBLE';
        criteriaChecks.push({
          criterion: '대표자 신용점수',
          userValue: `${profile.creditScore}점 (고신용)`,
          policyRequirement: '839점 이하 전용',
          status: 'FAILED',
          detail: '고신용자로 분류되어 중·저신용자 전용 특화자금 지원 대상에서 제외됩니다.'
        });
      }
    } else {
      if (profile.creditScore < 600) {
        matchScore -= 30;
        if (qualificationStatus !== 'INELIGIBLE') qualificationStatus = 'CONDITIONAL';
        criteriaChecks.push({
          criterion: '대표자 신용점수',
          userValue: `${profile.creditScore}점 (저신용)`,
          policyRequirement: '일반 600점 이상 권장',
          status: 'WARNING',
          detail: '신용점수가 다소 낮아 일반 보증서 발급 시 한도 감액 또는 추가 심사가 요구될 수 있습니다.'
        });
      } else {
        criteriaChecks.push({
          criterion: '대표자 신용점수',
          userValue: `${profile.creditScore}점`,
          policyRequirement: '보증서 발급 적격선 충족',
          status: 'MET',
          detail: '금융권 정책자금 및 보증서 발급에 안정적인 신용등급입니다.'
        });
      }
    }

    // 5. 재무 상태 및 부채 비율
    if (profile.hasTaxArrears || profile.hasOverdue) {
      matchScore -= 50;
      qualificationStatus = 'INELIGIBLE';
      criteriaChecks.push({
        criterion: '재무 건전성 및 부채비율',
        userValue: `부채비율 ${calculatedDebtRatio}% / ${profile.hasTaxArrears ? '세금체납' : ''} ${profile.hasOverdue ? '연체보유' : ''}`,
        policyRequirement: '체납 및 연체 무결 요건',
        status: 'FAILED',
        detail: '국세/지방세 체납 또는 금융 연체 기록으로 인해 정규 심사 진행이 불가능합니다.'
      });
    } else if (calculatedDebtRatio > 200) {
      if (policyName.includes('대환대출') || policyName.includes('재도전')) {
        matchScore += 25;
        criteriaChecks.push({
          criterion: '부채비율 및 차환 적합도',
          userValue: `부채비율 ${calculatedDebtRatio}% (고부채)`,
          policyRequirement: '고금리/과다부채 차환 대상',
          status: 'MET',
          detail: '과다 부채 소상공인을 위한 특별 대환/재도전 자금으로 우선 지원 대상입니다.'
        });
      } else {
        matchScore -= 25;
        if (qualificationStatus !== 'INELIGIBLE') qualificationStatus = 'CONDITIONAL';
        criteriaChecks.push({
          criterion: '부채비율',
          userValue: `${calculatedDebtRatio}% (연매출 2배 초과)`,
          policyRequirement: '통상 200% 이하 권장',
          status: 'WARNING',
          detail: '연매출 대비 총부채 비율이 높아 일반 신규 유동성 심사 시 한도가 축소될 가능성이 큽니다.'
        });
      }
    } else {
      criteriaChecks.push({
        criterion: '부채비율 및 이익률',
        userValue: `부채비율 ${calculatedDebtRatio}% / 이익률 ${profile.expectedProfitMargin}%`,
        policyRequirement: '상환여력 심사 적정선',
        status: 'MET',
        detail: '안정적인 부채비율과 영업이익률로 원리금 상환능력(DSCR) 심사 통과가 기대됩니다.'
      });
    }

    // 6. 정책자금 신청 이력 및 중복/재신청 제한 체크
    const isSameAgencyRecentRejection = hasRecentRejectionIn6Months && 
      recentRejectionAgency && 
      policy.agency.includes(recentRejectionAgency);

    const isKiboFund = policy.agency.includes('기술보증기금') || policyName.includes('테크');
    const isShinboConflict = isKiboFund && hasShinboHistory;

    if (isSameAgencyRecentRejection) {
      matchScore -= 35;
      if (qualificationStatus !== 'INELIGIBLE') qualificationStatus = 'CONDITIONAL';
      criteriaChecks.push({
        criterion: '과거 신청 이력',
        userValue: `최근 6개월 내 ${recentRejectionAgency} 부결`,
        policyRequirement: '동일 기관 재신청 제한 기간 주의',
        status: 'WARNING',
        detail: '최근 부결 이력으로 인해 심사 반려 가능성이 있으므로 보완자료 제출 또는 타 채널 전환이 필수적입니다.'
      });
    } else if (isShinboConflict) {
      matchScore -= 40;
      qualificationStatus = 'INELIGIBLE';
      criteriaChecks.push({
        criterion: '정책자금 이력 (중복보증)',
        userValue: '기존 신용보증기금 이용 중',
        policyRequirement: '신보/기보 중복보증 불가',
        status: 'FAILED',
        detail: '신보 보증 이용 이력이 있어 기술보증기금 신규 보증 대상에서 제한됩니다.'
      });
    } else if (existingPolicyFundBalance > 0) {
      criteriaChecks.push({
        criterion: '정책자금 누적 이용 잔액',
        userValue: `기존 잔액 ${formatKoreanCurrency(existingPolicyFundBalance)} 보유`,
        policyRequirement: '기관별 누적 보증/대출 한도 내 차감',
        status: 'MET',
        detail: `기존 정책자금 대출 잔액(${formatKoreanCurrency(existingPolicyFundBalance)})을 감안하여 잔여 한도가 계산됩니다.`
      });
    } else {
      criteriaChecks.push({
        criterion: '과거 신청 이력',
        userValue: '신규 신청 (이력 무결)',
        policyRequirement: '누적 한도 소진 없음',
        status: 'MET',
        detail: '과거 정책자금 수혜 이력이 없어 최대 신규 지원 한도를 온전히 확보할 수 있습니다.'
      });
    }

    // 7. 정부 정책 가점 항목 (스마트공장, 탄소중립 등) 검증 및 승인 확률 보정
    const bonus = profile.policyBonusFactors;
    const bonusActiveList: string[] = [];
    if (bonus?.hasSmartFactory) bonusActiveList.push('스마트공장·공방 도입');
    if (bonus?.hasCarbonNeutrality) bonusActiveList.push('탄소중립 ESG 실천');
    if (bonus?.hasJobCreation) bonusActiveList.push('청년/일자리 창출');
    if (bonus?.hasVentureOrInnoBiz) bonusActiveList.push('기술혁신·특허');
    if (bonus?.hasCreditEducation) bonusActiveList.push('신용관리 교육');

    if (bonusActiveList.length > 0) {
      matchScore += Math.min(18, bonusActiveList.length * 6);
      criteriaChecks.push({
        criterion: '정부 정책 가점 (스마트공장·탄소중립 등)',
        userValue: bonusActiveList.join(', ') + ' 적용 중',
        policyRequirement: '우대 가점 확보 (심사 우선 배정 대상)',
        status: 'MET',
        detail: `정부 우대 가점(${bonusActiveList.join(', ')})이 유효하게 등록되어 심사 통과 예측 확률이 보정 상향되었습니다.`
      });
    } else {
      criteriaChecks.push({
        criterion: '정부 정책 가점 (스마트공장·탄소중립 등)',
        userValue: '가점 미등록 (일반 심사 트랙)',
        policyRequirement: '스마트공장 도입 또는 탄소중립 서약 권장',
        status: 'WARNING',
        detail: '스마트공방/스마트상점 도입 또는 탄소중립 실천 서약서 등록 시 심사 배점 최대 18점 추가 가산이 가능합니다.'
      });
    }

    // 예상 지원 금액 (추정 한도) 정밀 산출
    // 공식: (연간 매출액 x 25% + 영업이익률 가산) - (기존 정책자금 잔액 x 0.5)
    const revenueCapacity = Math.round(profile.annualRevenue * 0.25 * (1 + (profile.expectedProfitMargin - 15) / 100));
    const rawCalculated = Math.max(10000000, revenueCapacity - Math.round(existingPolicyFundBalance * 0.4));
    const estimatedMaxAmount = Math.min(policyMaxRaw, rawCalculated);
    const recommendedAmount = Math.round(Math.min(estimatedMaxAmount, profile.fundingNeed > 0 ? profile.fundingNeed : estimatedMaxAmount * 0.85) / 1000000) * 1000000;
    const minAmount = Math.round(recommendedAmount * 0.7 / 1000000) * 1000000;

    let calculationBasis = `공고 한도(${formatKoreanCurrency(policyMaxRaw)}) 대비 연매출(${formatKoreanCurrency(profile.annualRevenue)})의 약 25% 상환능력`;
    if (existingPolicyFundBalance > 0) {
      calculationBasis += ` 및 기존 정책자금 잔액(${formatKoreanCurrency(existingPolicyFundBalance)}) 차감 감안 산출`;
    }

    // 예상 금리 정밀 산정
    let baseRateVal = 3.45;
    let rateType: 'fixed' | 'variable' = 'variable';
    const discountConditions: string[] = [];

    if (policy.baseInterestRate.includes('고정')) {
      rateType = 'fixed';
      const numMatch = policy.baseInterestRate.match(/([0-9]+\.?[0-9]*)%/);
      baseRateVal = numMatch ? parseFloat(numMatch[1]) : 4.5;
    } else {
      // 정책자금 기준금리 약 2.95% 가정
      if (policy.baseInterestRate.includes('+ 1.6')) baseRateVal = 4.55;
      else if (policy.baseInterestRate.includes('+ 0.6')) baseRateVal = 3.55;
      else if (policy.baseInterestRate.includes('+ 0.4')) baseRateVal = 3.35;
      else baseRateVal = 3.45;
    }

    // 청년(만 39세 이하) 우대
    if (profile.ageGroup === '청년' || (profile.gender && profile.ageGroup?.includes('20')) || (profile.ageGroup?.includes('30'))) {
      baseRateVal = Math.max(1.5, baseRateVal - 0.2);
      discountConditions.push('청년 우대 (-0.2%p 감면)');
    }
    // 스마트공장 / 탄소중립 실천 특별 이차보전 우대
    if (bonus?.hasSmartFactory || bonus?.hasCarbonNeutrality) {
      baseRateVal = Math.max(1.5, baseRateVal - 0.2);
      discountConditions.push('스마트공장·탄소중립 특별 이차보전 (-0.2%p 감면)');
    }
    // 제로페이 / 전자세금계산서 발행 등 우대
    discountConditions.push('자동이체 및 성실상환 시 우대 (-0.1%p)');

    const expectedRateValue = Math.round(baseRateVal * 100) / 100;

    // 최종 스코어 및 자격 판정 라벨
    matchScore = Math.max(10, Math.min(99, matchScore));
    if (qualificationStatus === 'INELIGIBLE') {
      matchScore = Math.min(45, matchScore);
    }

    let qualificationStatusLabel = '신청 가능 (적격)';
    if (qualificationStatus === 'INELIGIBLE') {
      qualificationStatusLabel = '신청 불가 (부적격)';
    } else if (qualificationStatus === 'CONDITIONAL') {
      qualificationStatusLabel = '조건부 신청 (주의)';
    }

    evaluatedList.push({
      fundId: `eval-${policyName.replace(/\s+/g, '-')}`,
      fundTitle: policyName,
      agency: policy.agency,
      category: policy.eligibility || '경영안정자금',
      qualificationStatus,
      qualificationStatusLabel,
      matchScore,
      estimatedAmount: {
        minAmount,
        maxAmount: estimatedMaxAmount,
        recommendedAmount,
        formattedAmount: `최대 ${formatKoreanCurrency(estimatedMaxAmount)} (추천: ${formatKoreanCurrency(recommendedAmount)})`,
        calculationBasis
      },
      estimatedInterestRate: {
        baseRate: policy.baseInterestRate,
        expectedRateValue,
        formattedRate: `연 ${expectedRateValue.toFixed(2)}% (${rateType === 'fixed' ? '고정' : '변동'})`,
        discountConditions,
        rateType
      },
      criteriaChecks,
      repaymentPeriod: policy.repaymentPeriod || '거치기간 포함 분할상환',
      applicationProcedure: policy.applicationProcedure || ['온라인 신청 접수', '자격 검토', '보증 및 대출 약정'],
      requiredDocuments: [
        '사업자등록증명원 (최근 1개월 이내)',
        '부가가치세과세표준증명원 (최근 1~2개년)',
        '국세 및 지방세 납세증명서',
        '소득금액증명원',
        '임대차계약서 (사업장)'
      ],
      strategicAdvice: qualificationStatus === 'ELIGIBLE' 
        ? `${profile.businessName}의 업종 및 재무 조건이 잘 부합합니다. 조기 예산 소진 전 우선 접수를 추천합니다.`
        : qualificationStatus === 'CONDITIONAL'
          ? '일부 지표(부채비율 또는 신용도)로 인해 한도 감액 가능성이 있으므로 증빙자료를 철저히 보완하십시오.'
          : '필수 지원 조건 미달 항목이 존재하므로 대안 자금 또는 우회 신청 채널을 검토하십시오.',
      applicationCaution: isSameAgencyRecentRejection
        ? '⚠️ 최근 동일 기관 부결 이력으로 인한 접수 반려 위험이 있으니 사전 상담 후 진행하세요.'
        : undefined,
      isBudgetLow: policy.currentStatus === 'BUDGET_ALMOST_EXHAUSTED',
      onlineApplyUrl: 'https://ols.semas.or.kr'
    });
  }

  // 적격/조건부 vs 부적격 분리 및 정렬
  const recommendedFunds = evaluatedList
    .filter(f => f.qualificationStatus !== 'INELIGIBLE')
    .sort((a, b) => b.matchScore - a.matchScore);

  const restrictedOrIneligibleFunds = evaluatedList
    .filter(f => f.qualificationStatus === 'INELIGIBLE')
    .sort((a, b) => b.matchScore - a.matchScore);

  // 종합 지표 집계
  const totalAvailableEstimatedFunding = recommendedFunds.reduce(
    (acc, cur) => acc + cur.estimatedAmount.recommendedAmount, 
    0
  );
  const avgRate = recommendedFunds.length > 0
    ? Math.round((recommendedFunds.reduce((acc, cur) => acc + cur.estimatedInterestRate.expectedRateValue, 0) / recommendedFunds.length) * 100) / 100
    : 3.5;

  let overallBusinessGrade = '우수 (A등급)';
  if (profile.hasTaxArrears || profile.hasOverdue) overallBusinessGrade = '보완필수 (D등급)';
  else if (debtRatioGrade === 'HIGH_RISK') overallBusinessGrade = '위험관리 필요 (C등급)';
  else if (debtRatioGrade === 'WARNING' || profile.creditScore < 650) overallBusinessGrade = '보통 (B등급)';

  const priorSummaryText = histories.length > 0
    ? `과거 신청 ${histories.length}건 (승인 잔액: ${formatKoreanCurrency(existingPolicyFundBalance)}, ${hasRecentRejectionIn6Months ? '최근 부결 1건' : '부결 없음'})`
    : '과거 정책자금 신청 이력 없음 (신규 신청 우대)';

  // 최적 신청 로드맵 생성
  const strategicRoadmap: ComprehensiveEvaluationResult['strategicRoadmap'] = [];
  if (recommendedFunds.length > 0) {
    const topFund = recommendedFunds[0];
    strategicRoadmap.push({
      stepNumber: 1,
      title: `${topFund.fundTitle} 1순위 신청`,
      agency: topFund.agency,
      actionDescription: `예상 한도 ${formatKoreanCurrency(topFund.estimatedAmount.recommendedAmount)}, 최적 금리 ${topFund.estimatedInterestRate.formattedRate}로 가장 유리합니다.`,
      timing: '즉시 접수 (1~2주 이내)',
      priority: 'FIRST_CHOICE'
    });

    if (recommendedFunds.length > 1) {
      const secondFund = recommendedFunds[1];
      strategicRoadmap.push({
        stepNumber: 2,
        title: `${secondFund.fundTitle} 2순위 병행/추가 검토`,
        agency: secondFund.agency,
        actionDescription: `1순위 승인 후 시설자금 또는 운전자금 보동으로 ${formatKoreanCurrency(secondFund.estimatedAmount.recommendedAmount)} 추가 한도 확보 가능`,
        timing: '1순위 집행 후 1개월 이내',
        priority: 'SECONDARY'
      });
    }

    if (calculatedDebtRatio > 100) {
      strategicRoadmap.push({
        stepNumber: strategicRoadmap.length + 1,
        title: '소상공인 저금리 대환대출을 통한 고금리 부채 정리',
        agency: '소상공인시장진흥공단 / 취급은행',
        actionDescription: '2금융권 및 카드론 고금리 채무를 연 4.5% 장기 저금리로 전환하여 월 원리금 상환 부담 40% 이상 경감',
        timing: '자금 수령 후 즉시 실행',
        priority: 'BACKUP'
      });
    }
  }

  return {
    summary: {
      totalEvaluated: evaluatedList.length,
      eligibleCount: recommendedFunds.filter(f => f.qualificationStatus === 'ELIGIBLE').length,
      conditionalCount: recommendedFunds.filter(f => f.qualificationStatus === 'CONDITIONAL').length,
      ineligibleCount: restrictedOrIneligibleFunds.length,
      totalAvailableEstimatedFunding,
      averageExpectedRate: avgRate,
      overallBusinessGrade,
      debtRatioValue: calculatedDebtRatio,
      debtRatioGrade,
      priorApplicationSummary: priorSummaryText
    },
    recommendedFunds,
    restrictedOrIneligibleFunds,
    strategicRoadmap,
    restrictionAlerts
  };
};
