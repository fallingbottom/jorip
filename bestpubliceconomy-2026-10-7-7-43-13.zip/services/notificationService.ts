import { PolicyFund, SourcePolicy, SimilarFundRecommendation } from '../types';

export type NotificationPermissionState = 'granted' | 'denied' | 'default' | 'unsupported';

export interface PushNotificationSubscription {
  id: string; // Fund ID or title
  fundTitle: string;
  agency: string;
  deadlineDate: string;
  notifyOnDeadline: boolean;      // 신청 기간 임박 (D-7, D-3, D-Day)
  notifyOnNewAnnouncement: boolean; // 추가 공고 발생 / 차수 추가 공고
  notifyOnDocumentUpdate: boolean;  // 제출 서류 및 양식 업데이트
  deadlineThresholdDays: number;   // 1, 3, 5, 7 days before
  subscribedAt: string;
  lastNotifiedAt?: string;
}

export interface NotificationHistoryItem {
  id: string;
  type: 'DEADLINE_URGENT' | 'NEW_ANNOUNCEMENT' | 'DOCUMENT_UPDATE' | 'CUSTOM_SYSTEM';
  title: string;
  message: string;
  fundTitle: string;
  agency?: string;
  timestamp: string;
  read: boolean;
  linkAction?: string;
}

const STORAGE_KEY_SUBSCRIPTIONS = 'bizmatch_push_subscriptions_v1';
const STORAGE_KEY_HISTORY = 'bizmatch_notification_history_v1';

export const getNotificationPermission = (): NotificationPermissionState => {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  return Notification.permission as NotificationPermissionState;
};

export const requestNotificationPermission = async (): Promise<NotificationPermissionState> => {
  if (typeof window === 'undefined' || !('Notification' in window)) {
    return 'unsupported';
  }
  try {
    const permission = await Notification.requestPermission();
    return permission as NotificationPermissionState;
  } catch (err) {
    console.error('Failed to request notification permission:', err);
    return 'denied';
  }
};

export const triggerPushNotification = (title: string, options?: NotificationOptions) => {
  const perm = getNotificationPermission();
  if (perm !== 'granted') {
    console.warn('Notification permission not granted.');
    return false;
  }

  try {
    const defaultOptions: any = {
      icon: 'https://cdn-icons-png.flaticon.com/512/2910/2910768.png',
      badge: 'https://cdn-icons-png.flaticon.com/512/2910/2910768.png',
      vibrate: [200, 100, 200],
      tag: 'bizmatch-push-alert',
      ...options,
    };
    new Notification(title, defaultOptions);
    return true;
  } catch (err) {
    console.error('Error firing browser push notification:', err);
    return false;
  }
};

/**
 * Load push subscriptions for policy funds from localStorage
 */
export const loadPushSubscriptions = (): Record<string, PushNotificationSubscription> => {
  if (typeof window === 'undefined') return {};
  try {
    const saved = localStorage.getItem(STORAGE_KEY_SUBSCRIPTIONS);
    if (!saved) return {};
    return JSON.parse(saved);
  } catch (e) {
    console.error('Failed to parse push subscriptions', e);
    return {};
  }
};

/**
 * Save push subscriptions to localStorage
 */
export const savePushSubscriptions = (subs: Record<string, PushNotificationSubscription>) => {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_SUBSCRIPTIONS, JSON.stringify(subs));
  } catch (e) {
    console.error('Failed to save push subscriptions', e);
  }
};

/**
 * Load push notification history
 */
export const loadNotificationHistory = (): NotificationHistoryItem[] => {
  if (typeof window === 'undefined') return [];
  try {
    const saved = localStorage.getItem(STORAGE_KEY_HISTORY);
    if (!saved) return getDefaultNotificationHistory();
    return JSON.parse(saved);
  } catch (e) {
    console.error('Failed to parse notification history', e);
    return getDefaultNotificationHistory();
  }
};

/**
 * Save notification history
 */
export const saveNotificationHistory = (history: NotificationHistoryItem[]) => {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_HISTORY, JSON.stringify(history.slice(0, 50)));
  } catch (e) {
    console.error('Failed to save notification history', e);
  }
};

const getDefaultNotificationHistory = (): NotificationHistoryItem[] => {
  return [
    {
      id: 'noti-init-1',
      type: 'DEADLINE_URGENT',
      title: '⏰ [신청 마감 임박 D-3] 소상공인 대환대출 특별자금',
      message: '소상공인시장진흥공단 1분기 예산 소진이 임박했습니다. 필수 서류(부가가치세 과세표준증명원)를 확인 후 접수하세요.',
      fundTitle: '소상공인 대환대출 특별자금',
      agency: '소상공인시장진흥공단',
      timestamp: '2026-08-19 09:30',
      read: false
    },
    {
      id: 'noti-init-2',
      type: 'NEW_ANNOUNCEMENT',
      title: '📢 [추가 공고 발생] 지역신용보증재단 2차 긴급특례보증 개시',
      message: '2026년 하반기 소상공인 금융비용 경감을 위한 추가 2차 추경 보증 공고가 등록되었습니다. (금리 연 2.8% 고정우대)',
      fundTitle: '지역신용보증재단 특례보증',
      agency: '신용보증재단중앙회',
      timestamp: '2026-08-18 14:10',
      read: true
    },
    {
      id: 'noti-init-3',
      type: 'DOCUMENT_UPDATE',
      title: '📝 [제출 서류 업데이트] 스마트상점 기술보급 사업',
      message: '2026년 하반기 공급기업 견적서 양식이 신규 표준 서식(v2.4)으로 변경되었습니다. 다운로드하여 작성해 주세요.',
      fundTitle: '스마트상점 기술보급 사업',
      agency: '중소벤처기업부',
      timestamp: '2026-08-17 11:00',
      read: true
    }
  ];
};

export interface DeadlineAlertItem {
  id: string;
  title: string;
  agency: string;
  endDate: string;
  daysLeft: number;
  statusText: string;
}

/**
 * Calculates remaining days from today until target ISO date (YYYY-MM-DD)
 */
export const calculateDaysRemaining = (endDateStr?: string): number => {
  if (!endDateStr) return 999;
  const targetDate = new Date(endDateStr);
  if (isNaN(targetDate.getTime())) return 999;
  
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  targetDate.setHours(0, 0, 0, 0);

  const diffTime = targetDate.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

/**
 * Inspect favorited policy funds for approaching deadlines and trigger push notification
 */
export const checkAndNotifyUpcomingDeadlines = (
  favorites: (PolicyFund | SourcePolicy | SimilarFundRecommendation)[]
): DeadlineAlertItem[] => {
  const alerts: DeadlineAlertItem[] = [];
  const subs = loadPushSubscriptions();

  favorites.forEach((item) => {
    const title = 'title' in item ? item.title : item.name;
    const id = 'id' in item ? item.id : item.name;
    const endDate = 'endDate' in item ? item.endDate : ('applicationDeadline' in item ? item.applicationDeadline : '');
    const agency = item.agency;

    const daysLeft = calculateDaysRemaining(endDate);
    const sub = subs[id] || subs[title];
    const threshold = sub?.deadlineThresholdDays || 7;

    // Check if deadline notification is enabled for this fund (or default enabled)
    const isDeadlineActive = sub ? sub.notifyOnDeadline : true;

    if (isDeadlineActive && daysLeft >= 0 && daysLeft <= threshold) {
      let statusText = '';
      if (daysLeft === 0) statusText = '오늘 마감';
      else if (daysLeft === 1) statusText = '내일 마감';
      else statusText = `마감 D-${daysLeft}`;

      alerts.push({
        id,
        title,
        agency,
        endDate: endDate || '일정 확인 필요',
        daysLeft,
        statusText,
      });
    }
  });

  // Sort by closest deadline
  alerts.sort((a, b) => a.daysLeft - b.daysLeft);

  // If permission granted and there are alerts, fire a summary notification
  if (alerts.length > 0 && getNotificationPermission() === 'granted') {
    const closest = alerts[0];
    triggerPushNotification(`⏰ [BizMatch AI] 정책자금 마감 임박 알림`, {
      body: `'${closest.title}' (${closest.agency}) 마감이 ${closest.daysLeft === 0 ? '오늘' : `${closest.daysLeft}일`} 남았습니다!`,
      tag: `deadline-${closest.id}`,
    });
  }

  return alerts;
};

/**
 * Trigger simulated push notification for specific event types
 */
export const triggerEventPushNotification = (
  type: 'DEADLINE_URGENT' | 'NEW_ANNOUNCEMENT' | 'DOCUMENT_UPDATE',
  fundTitle: string,
  agency: string,
  customDetail?: string
): { success: boolean; historyItem: NotificationHistoryItem } => {
  let title = '';
  let body = '';

  const now = new Date();
  const timestamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

  switch (type) {
    case 'DEADLINE_URGENT':
      title = `⏰ [신청 마감 임박] ${fundTitle}`;
      body = customDetail || `${agency} 정책자금 접수 마감이 D-3일 남았습니다. 예산 소진 전 최종 신청 서류를 점검하세요.`;
      break;
    case 'NEW_ANNOUNCEMENT':
      title = `📢 [추가 공고 발생] ${fundTitle}`;
      body = customDetail || `${agency}에서 2026년 하반기 추가 배정 예산 및 2차 모집 공고를 발표했습니다. 지금 확인해 보세요!`;
      break;
    case 'DOCUMENT_UPDATE':
      title = `📝 [제출 서류 업데이트] ${fundTitle}`;
      body = customDetail || `${agency} 필수 구비서류 양식(사업계획서/신청서)이 최신 버전으로 개정되었습니다.`;
      break;
  }

  const success = triggerPushNotification(title, {
    body,
    tag: `event-${type}-${Date.now()}`
  });

  const historyItem: NotificationHistoryItem = {
    id: `noti-${Date.now()}`,
    type,
    title,
    message: body,
    fundTitle,
    agency,
    timestamp,
    read: false
  };

  const existingHistory = loadNotificationHistory();
  saveNotificationHistory([historyItem, ...existingHistory]);

  return { success, historyItem };
};
