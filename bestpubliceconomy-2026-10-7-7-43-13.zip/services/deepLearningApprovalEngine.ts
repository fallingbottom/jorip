import { 
  UserProfile, 
  PolicyFund, 
  SourcePolicy, 
  DeepLearningApprovalReport, 
  ApprovalLikelihoodTier, 
  ApprovalDimensionMetric, 
  ImprovementActionItem, 
  MatchedPeerStoryCase,
  Industry,
  BusinessType,
  PolicyBonusItemBreakdown,
  PolicyBonusAdjustmentReport
} from '../types';
import { SUCCESS_STORIES, SuccessStory } from '../components/successStoriesData';
import { getPolicyBonusWeights } from './matchingParamService';

export interface ApprovalTierDetails {
  tier: ApprovalLikelihoodTier;
  tierKorean: string;
  minScore: number;
  maxScore: number;
  label: string;
  badgeColor: string;
  bgColor: string;
  color: string;
  description: string;
}

export const APPROVAL_TIERS: ApprovalTierDetails[] = [
  {
    tier: 'VERY_HIGH',
    tierKorean: '매우 높음',
    minScore: 90,
    maxScore: 100,
    label: '심사 통과 최유력 (안전권)',
    badgeColor: '#10b981',
    bgColor: '#ecfdf5',
    color: '#065f46',
    description: '지원 요건을 완벽히 충족하며 심사 통과 확률이 매우 높은 최상위 구간입니다.'
  },
  {
    tier: 'HIGH',
    tierKorean: '높음',
    minScore: 75,
    maxScore: 89,
    label: '심사 통과 유력 (보완 시 완벽)',
    badgeColor: '#3b82f6',
    bgColor: '#eff6ff',
    color: '#1e40af',
    description: '자격 요건을 여유 있게 충족하며 기본 가점 확보 시 무난히 승인될 가능성이 높습니다.'
  },
  {
    tier: 'MODERATE',
    tierKorean: '보통',
    minScore: 60,
    maxScore: 74,
    label: '심사 경합 구간 (가점 보강 권장)',
    badgeColor: '#f59e0b',
    bgColor: '#fffbeb',
    color: '#92400e',
    description: '기본 요건은 충족하나 동일 업종/지역 신청자 간 경합이 예상되므로 1~2개 가점 보완을 권장합니다.'
  },
  {
    tier: 'LOW',
    tierKorean: '주의/다소 낮음',
    minScore: 40,
    maxScore: 59,
    label: '부결 위험 존재 (요건 사전 점검)',
    badgeColor: '#f97316',
    bgColor: '#fff7ed',
    color: '#9a3412',
    description: '2금융권 채무 또는 신용도 문제로 감액이나 재검토 가능성이 있어 채무 구조 정비 후 신청이 안전합니다.'
  },
  {
    tier: 'VERY_LOW',
    tierKorean: '낮음/보완 필수',
    minScore: 0,
    maxScore: 39,
    label: '자격 요건 불일치 또는 보완 필수',
    badgeColor: '#ef4444',
    bgColor: '#fef2f2',
    color: '#991b1b',
    description: '현 상태로는 부결 위험이 높으므로 저신용/대환 특례 프로그램으로 우회하거나 신용 개선이 선행되어야 합니다.'
  }
];

export function getApprovalLikelihoodTier(score: number): ApprovalTierDetails {
  if (score >= 90) return APPROVAL_TIERS[0];
  if (score >= 75) return APPROVAL_TIERS[1];
  if (score >= 60) return APPROVAL_TIERS[2];
  if (score >= 40) return APPROVAL_TIERS[3];
  return APPROVAL_TIERS[4];
}

/**
 * Calculates a deep learning pattern matching approval probability report
 * by analyzing user profile vectors against historical approval cohorts and target fund requirements.
 */
export function generateDeepLearningApprovalReport(
  profile: UserProfile | null | undefined,
  fund: PolicyFund | SourcePolicy
): DeepLearningApprovalReport {
  const fundTitle = 'title' in fund ? fund.title : fund.name;
  const agency = fund.agency || '중소벤처기업부/소진공';
  const category = 'category' in fund ? fund.category : '정책자금';
  const maxAmount = 'maxAmount' in fund ? fund.maxAmount : (fund.maxAmount || '최대 1억원');
  const interestRate = 'interestRate' in fund ? fund.interestRate : (fund.baseInterestRate || '연 2~4%대');

  // Fallback defaults for empty profile
  const creditScore = profile?.creditScore || 740;
  const annualRevenue = profile?.annualRevenue || 120000000;
  const debt1Tier = profile?.debt1Tier || 0;
  const debt2Tier = profile?.debt2Tier || 0;
  const debtCardLoan = profile?.debtCardLoan || 0;
  const debtOther = profile?.debtOther || 0;
  const isMyDataLinked = Boolean(profile?.isMyDataLinked);
  const profitMargin = profile?.expectedProfitMargin || 18;
  const cashFlow = profile?.cashFlowStatus || 65;
  const employees = profile?.employees || 2;
  const location = profile?.location || profile?.businessAddress || '전국';
  const industry = profile?.industry || Industry.RESTAURANT;

  // 1. Feature Extraction & Vector Normalization
  // [Credit & Multi-debt feature] (0 - 100)
  const totalHighInterestDebt = debt2Tier + debtCardLoan + debtOther;
  let creditVectorScore = 70;
  if (creditScore >= 850) creditVectorScore = 95;
  else if (creditScore >= 780) creditVectorScore = 88;
  else if (creditScore >= 720) creditVectorScore = 76;
  else if (creditScore >= 650) creditVectorScore = 62;
  else creditVectorScore = 42;

  // Penalty for high 2nd tier / card loan debt unless fund is specialized in refinancing
  const isRefinanceFund = fundTitle.includes('대환') || fundTitle.includes('저신용') || fundTitle.includes('취약') || fundTitle.includes('재도전');
  if (totalHighInterestDebt > 30000000) {
    creditVectorScore = isRefinanceFund ? creditVectorScore + 10 : creditVectorScore - 18;
  } else if (totalHighInterestDebt > 10000000) {
    creditVectorScore = isRefinanceFund ? creditVectorScore + 6 : creditVectorScore - 10;
  } else {
    creditVectorScore += 5;
  }
  creditVectorScore = Math.max(25, Math.min(98, creditVectorScore));

  // [Revenue & Cash Flow feature] (0 - 100)
  let revenueVectorScore = 70;
  if (annualRevenue > 300000000) revenueVectorScore = 92;
  else if (annualRevenue > 150000000) revenueVectorScore = 84;
  else if (annualRevenue > 50000000) revenueVectorScore = 74;
  else revenueVectorScore = 60;

  // Profit margin & cash flow adjustment
  if (profitMargin >= 25) revenueVectorScore += 5;
  else if (profitMargin < 10) revenueVectorScore -= 6;
  if (cashFlow >= 70) revenueVectorScore += 4;
  else if (cashFlow < 40) revenueVectorScore -= 8;
  revenueVectorScore = Math.max(30, Math.min(99, revenueVectorScore));

  // [Industry & Local Quota Fit] (0 - 100)
  let quotaVectorScore = 75;
  if (fundTitle.includes('지역') || fundTitle.includes('특례') || agency.includes('신용보증재단')) {
    quotaVectorScore += 12;
  }
  if (location.includes('서울') || location.includes('경기') || location.includes('인천')) {
    quotaVectorScore += 4;
  } else if (location !== '전국' && location.length > 1) {
    quotaVectorScore += 8; // Local province allocation bonus
  }
  quotaVectorScore = Math.max(35, Math.min(98, quotaVectorScore));

  // [Policy Purpose Fit] (0 - 100)
  let purposeVectorScore = 78;
  if (isRefinanceFund && totalHighInterestDebt > 0) purposeVectorScore = 96;
  else if (fundTitle.includes('스마트') || fundTitle.includes('혁신')) purposeVectorScore = 82;
  else if (fundTitle.includes('운전') || fundTitle.includes('성장')) purposeVectorScore = 88;
  if (isMyDataLinked) purposeVectorScore += 5;
  purposeVectorScore = Math.max(40, Math.min(98, purposeVectorScore));

  // [Compliance & Bonus Point Completeness] (0 - 100)
  let bonusVectorScore = 72;
  if (isMyDataLinked) bonusVectorScore += 14;
  if (employees >= 3) bonusVectorScore += 6;
  if (profile?.businessType === BusinessType.CORPORATION) bonusVectorScore += 4;

  // Evaluate Policy Bonus Factors with Tuned Weights from Admin Matching Engine
  const tunedWeights = getPolicyBonusWeights();
  const globalSens = tunedWeights.globalBonusSensitivity || 1.0;
  const multipliers = tunedWeights.multipliers || {
    manufacturing: 1.2,
    esgGreen: 1.2,
    youthEmployment: 1.2,
    techVenture: 1.2,
    generalStability: 1.0,
    refinanceRelief: 1.0
  };

  const bonusFactors = profile?.policyBonusFactors;
  const hasSmartFactory = Boolean(bonusFactors?.hasSmartFactory);
  const hasCarbonNeutrality = Boolean(bonusFactors?.hasCarbonNeutrality);
  const hasJobCreation = Boolean(bonusFactors?.hasJobCreation);
  const hasVentureOrInnoBiz = Boolean(bonusFactors?.hasVentureOrInnoBiz);
  const hasCreditEducation = Boolean(bonusFactors?.hasCreditEducation);

  const appliedBonuses: PolicyBonusItemBreakdown[] = [];
  let totalBonusUplift = 0;

  if (hasSmartFactory) {
    const isSmartSpecializedFund = fundTitle.includes('스마트') || fundTitle.includes('혁신') || fundTitle.includes('소공인') || fundTitle.includes('제조');
    const basePts = isSmartSpecializedFund 
      ? (tunedWeights.smartFactoryBasePoints + tunedWeights.smartFactorySpecializedBonus) 
      : tunedWeights.smartFactoryBasePoints;
    const catMultiplier = isSmartSpecializedFund ? (multipliers.manufacturing || 1.2) : 1.0;
    const smartPoints = Math.round(basePts * catMultiplier * globalSens);

    totalBonusUplift += smartPoints;
    appliedBonuses.push({
      id: 'bonus-smart-factory',
      name: '스마트공장·스마트공방 도입',
      category: '공정 혁신 및 디지털화',
      points: smartPoints,
      description: '공정 자동화(ERP/MES/스마트공방/스마트상점) 도입으로 생산성 혁신 공인',
      agencyBenefit: isSmartSpecializedFund 
        ? `중진공/소진공 스마트공방 및 특화자금 1순위 우선 심사 배정 (+${smartPoints}%p 반영)` 
        : `신보/기보/지역재단 심사표 상 공정혁신 우대 가점 반영 (+${smartPoints}%p 반영)`,
      isActive: true
    });
    bonusVectorScore += Math.round(18 * globalSens);
    purposeVectorScore += Math.round(12 * (isSmartSpecializedFund ? catMultiplier : 1.0));
  }

  if (hasCarbonNeutrality) {
    const isEsgFund = fundTitle.includes('탄소') || fundTitle.includes('ESG') || fundTitle.includes('녹색') || fundTitle.includes('친환경');
    const catMultiplier = isEsgFund ? (multipliers.esgGreen || 1.2) : 1.0;
    const carbonPoints = Math.round(tunedWeights.carbonNeutralityPoints * catMultiplier * globalSens);

    totalBonusUplift += carbonPoints;
    appliedBonuses.push({
      id: 'bonus-carbon-neutrality',
      name: '탄소중립·친환경 ESG 실천',
      category: 'ESG 녹색금융',
      points: carbonPoints,
      description: '탄소중립 실천 서약 또는 친환경·고효율 에너지 절감 설비 도입',
      agencyBenefit: `정부 녹색금융 이차보전(0.2%p 금리 인하) 및 보증비율 95% 우대 (+${carbonPoints}%p 반영)`,
      isActive: true
    });
    bonusVectorScore += Math.round(14 * globalSens);
    purposeVectorScore += Math.round(8 * (isEsgFund ? catMultiplier : 1.0));
  }

  if (hasJobCreation) {
    const isYouthFund = fundTitle.includes('청년') || fundTitle.includes('일자리') || fundTitle.includes('고용');
    const catMultiplier = isYouthFund ? (multipliers.youthEmployment || 1.2) : 1.0;
    const jobPoints = Math.round(tunedWeights.jobCreationPoints * catMultiplier * globalSens);

    totalBonusUplift += jobPoints;
    appliedBonuses.push({
      id: 'bonus-job-creation',
      name: '청년·정규직 일자리 창출',
      category: '고용 우대',
      points: jobPoints,
      description: '최근 1년 이내 청년 또는 정규직 신규 고용 창출',
      agencyBenefit: `일자리 창출 우수기업 전용 심사 가점 및 신속 보증 (+${jobPoints}%p 반영)`,
      isActive: true
    });
    bonusVectorScore += Math.round(8 * catMultiplier * globalSens);
  }

  if (hasVentureOrInnoBiz) {
    const isTechFund = fundTitle.includes('기술') || fundTitle.includes('벤처') || fundTitle.includes('특허') || agency.includes('기술보증기금');
    const catMultiplier = isTechFund ? (multipliers.techVenture || 1.2) : 1.0;
    const techPoints = Math.round(tunedWeights.ventureInnoBizPoints * catMultiplier * globalSens);

    totalBonusUplift += techPoints;
    appliedBonuses.push({
      id: 'bonus-venture-innobiz',
      name: '이노비즈·메인비즈·벤처·특허',
      category: '기술혁신',
      points: techPoints,
      description: '기술/경영혁신형 중소기업(Inno-Biz) 또는 특허·실용신안 보유',
      agencyBenefit: `기술보증기금 기술평가 A등급 가산 및 보증료 0.2%p 감면 (+${techPoints}%p 반영)`,
      isActive: true
    });
    bonusVectorScore += Math.round(10 * catMultiplier * globalSens);
  }

  if (hasCreditEducation) {
    const isDirectFund = fundTitle.includes('직접대출') || fundTitle.includes('소진공');
    const catMultiplier = isDirectFund ? 1.2 : 1.0;
    const eduPoints = Math.round(tunedWeights.creditEducationPoints * catMultiplier * globalSens);

    totalBonusUplift += eduPoints;
    appliedBonuses.push({
      id: 'bonus-credit-edu',
      name: '소진공 신용관리 사전교육 이수',
      category: '정책 사전준비',
      points: eduPoints,
      description: '소상공인 지식배움터 온라인 정책자금/신용관리 교육 수료',
      agencyBenefit: `소진공 직접대출 심사표 상 비금융 확정 가점 부여 (+${eduPoints}%p 반영)`,
      isActive: true
    });
    bonusVectorScore += Math.round(6 * globalSens);
  }

  // Check additional bonus factors if provided: MyData instant verification
  if (isMyDataLinked) {
    const myDataBonus = Math.round(tunedWeights.myDataInstantPoints * globalSens);
    if (myDataBonus > 0) {
      totalBonusUplift += myDataBonus;
      appliedBonuses.push({
        id: 'bonus-mydata',
        name: '마이데이터 공공서류 즉시 검증',
        category: '행정 전산화',
        points: myDataBonus,
        description: '공공 마이데이터 연동으로 국세청·건보공단 서류 즉시 스크래핑 제출',
        agencyBenefit: `심사 소요기간 단축(Fast-track) 및 전산 무서류 우대 (+${myDataBonus}%p 반영)`,
        isActive: true
      });
    }
  }

  bonusVectorScore = Math.max(35, Math.min(99, bonusVectorScore));

  // Weighted Base Probability (Without Policy Bonus Adjustments)
  const weightedScore = Math.round(
    creditVectorScore * 0.30 +
    revenueVectorScore * 0.25 +
    quotaVectorScore * 0.15 +
    purposeVectorScore * 0.20 +
    bonusVectorScore * 0.10
  );

  const baseProbability = Math.max(28, Math.min(95, weightedScore));
  
  // Calibrate Overall Probability with Policy Bonus Uplift
  const calibratedProbability = Math.min(99, baseProbability + totalBonusUplift);
  const overallProbability = calibratedProbability;

  // Determine 5-Tier Likelihood based on Calibrated Score
  let tier: ApprovalLikelihoodTier = 'MODERATE';
  let tierLabel = '보통';
  let tierBadgeColor = 'bg-amber-500 text-white';
  let summaryVerdict = '';
  let examinerReviewOpinion = '';

  const bonusSummaryNames = appliedBonuses.map(b => b.name).join(', ');

  if (overallProbability >= 90) {
    tier = 'VERY_HIGH';
    tierLabel = '매우 높음';
    tierBadgeColor = 'bg-emerald-600 text-white';
    summaryVerdict = totalBonusUplift > 0
      ? `정책적 가점(${bonusSummaryNames} 등 +${totalBonusUplift}%p 보정)이 유효하게 반영되어 과거 유사 승인 집단 대비 최상위 3% 안전권에 진입했습니다.`
      : '과거 유사 승인 집단 대비 최상위 5% 적합도로, 필수 서류 구비 시 1차 서류 및 보증서 심사 즉시 통과가 유력합니다.';
    examinerReviewOpinion = totalBonusUplift > 0
      ? `기본 재무 지표와 더불어 [${bonusSummaryNames}] 정책적 가점이 심사역 배점표에 100% 반영되었습니다. 지자체·소진공 우선 승인 심사 트랙 배정이 유력하며 한도 삭감 없이 추천됩니다.`
      : '매출 규모와 신용 및 상환 능력 지표가 안정적이며, 정책자금 목적과의 부합도가 매우 뛰어납니다. 신청 즉시 우선 심사 트랙 배정이 예상됩니다.';
  } else if (overallProbability >= 75) {
    tier = 'HIGH';
    tierLabel = '높음';
    tierBadgeColor = 'bg-blue-600 text-white';
    summaryVerdict = totalBonusUplift > 0
      ? `정책적 가점 보정(+${totalBonusUplift}%p)을 통해 합격선에 안착하였으며, 필수 증빙 첨부 시 무난한 승인이 기대됩니다.`
      : '지원 자격 요건을 여유 있게 충족하며, 지자체/소진공 심사 가점 항목 1~2개 추가 시 확정적 승인이 기대됩니다.';
    examinerReviewOpinion = totalBonusUplift > 0
      ? `정책적 가점 항목(${bonusSummaryNames})이 반영되어 심사위원회의 정성 평가에서 높은 호평을 얻었습니다. 사업계획서 상 자금 사용 소명자료만 보강하면 감액 없는 전액 승인이 가능합니다.`
      : '전반적인 재무 건전성과 사업 지속성이 우수합니다. 마이데이터 부채 검증 또는 사업계획서 자금 소명자료를 보강하면 감액 없는 전액 승인이 가능합니다.';
  } else if (overallProbability >= 60) {
    tier = 'MODERATE';
    tierLabel = '보통';
    tierBadgeColor = 'bg-amber-500 text-white';
    summaryVerdict = '기본 적격 요건은 만족하나 동일 업종/지역 신청자 간 심사 경합이 예상되므로, 스마트공장/탄소중립 등 가점 항목 보강 또는 채무 개선을 권장합니다.';
    examinerReviewOpinion = '신용점수 또는 고금리 채무 비율로 인해 심사 배점이 보합권에 머물러 있습니다. 스마트공장·탄소중립 실천 서약이나 신용관리 교육 이수 가점을 추가 제출하여 승인율을 80% 이상으로 끌어올릴 수 있습니다.';
  } else if (overallProbability >= 40) {
    tier = 'LOW';
    tierLabel = '주의/다소 낮음';
    tierBadgeColor = 'bg-orange-500 text-white';
    summaryVerdict = '현 상태로 직접 접수 시 보증 한도 축소 또는 심사 보완 요청(재검토) 확률이 높습니다. 채무 구조 개선 및 정책 가점 확보 후 신청이 안전합니다.';
    examinerReviewOpinion = '2금융권 채무 또는 최근 현금흐름 지표가 심사 기준선에 근접해 있습니다. 일반 운전자금보다는 소진공 대환대출 특별자금 또는 스마트·탄소중립 특례보증 트랙으로 우회 신청하는 전략이 유리합니다.';
  } else {
    tier = 'VERY_LOW';
    tierLabel = '낮음/보완 필수';
    tierBadgeColor = 'bg-rose-600 text-white';
    summaryVerdict = '신용점수 또는 다중채무 부담으로 인해 기본 심사 통과선에 미달할 위험이 큽니다. 신용 회복 및 대환 프로그램 선행이 필수적입니다.';
    examinerReviewOpinion = '채무 재조정 또는 저신용 소상공인 전용 직접대출(소진공 희망플러스 등)으로 전환 검토가 요구됩니다. 신용관리 교육 이수 및 국세 완납 증빙을 최우선 정비하십시오.';
  }

  // 2. Multi-Dimension Metric Breakdown
  const dimensions: ApprovalDimensionMetric[] = [
    {
      id: 'dim-credit',
      dimensionName: '신용도 및 다중채무 건전성',
      score: creditVectorScore,
      cohortBenchmark: 82,
      minPassThreshold: 60,
      weight: 30,
      status: creditVectorScore >= 80 ? 'EXCELLENT' : creditVectorScore >= 65 ? 'GOOD' : creditVectorScore >= 50 ? 'NEEDS_WORK' : 'CRITICAL',
      statusLabel: creditVectorScore >= 80 ? '우수 (안전권)' : creditVectorScore >= 65 ? '양호' : creditVectorScore >= 50 ? '보완 권장' : '집중 관리 필요',
      evaluationReason: creditScore >= 750 
        ? `NICE ${creditScore}점으로 기본 신용 배점 확보. 2금융권 채무 관리 지속 필요` 
        : `신용점수(${creditScore}점) 및 다중채무 잔액에 대한 보증심사 가점 보완 필요`
    },
    {
      id: 'dim-revenue',
      dimensionName: '매출 지속성 및 원리금 상환 여력',
      score: revenueVectorScore,
      cohortBenchmark: 78,
      minPassThreshold: 55,
      weight: 25,
      status: revenueVectorScore >= 80 ? 'EXCELLENT' : revenueVectorScore >= 65 ? 'GOOD' : revenueVectorScore >= 50 ? 'NEEDS_WORK' : 'CRITICAL',
      statusLabel: revenueVectorScore >= 80 ? '우수' : revenueVectorScore >= 65 ? '양호' : '보완 권장',
      evaluationReason: `연매출 ${Math.round(annualRevenue / 10000000)}천만원대 및 영업이익률 ${profitMargin}% 기반 원리금 상환 DSR 적정 평가`
    },
    {
      id: 'dim-quota',
      dimensionName: '업종·지자체 특례보증 쿼터 적합도',
      score: quotaVectorScore,
      cohortBenchmark: 76,
      minPassThreshold: 50,
      weight: 15,
      status: quotaVectorScore >= 80 ? 'EXCELLENT' : quotaVectorScore >= 65 ? 'GOOD' : 'NEEDS_WORK',
      statusLabel: quotaVectorScore >= 80 ? '우수' : quotaVectorScore >= 65 ? '양호' : '보완 권장',
      evaluationReason: `${location} 소재 ${industry} 업종 대상 지자체 이차보전 및 보증재단 특별 배정 쿼터 부합`
    },
    {
      id: 'dim-purpose',
      dimensionName: '자금 사용 목적 및 정책 적합성',
      score: purposeVectorScore,
      cohortBenchmark: 80,
      minPassThreshold: 60,
      weight: 20,
      status: purposeVectorScore >= 80 ? 'EXCELLENT' : purposeVectorScore >= 65 ? 'GOOD' : 'NEEDS_WORK',
      statusLabel: purposeVectorScore >= 80 ? '최우수' : purposeVectorScore >= 65 ? '양호' : '보완 권장',
      evaluationReason: isRefinanceFund 
        ? '고금리 금융비용 절감 및 사업 영속성 확보를 위한 대환 지원 목적 100% 일치' 
        : '경영 안정 및 운전자금 수급 목적과 정책자금 지원 취지 일치'
    },
    {
      id: 'dim-bonus',
      dimensionName: '가점 요건 및 심사 서류 무결성',
      score: bonusVectorScore,
      cohortBenchmark: 74,
      minPassThreshold: 50,
      weight: 10,
      status: bonusVectorScore >= 80 ? 'EXCELLENT' : bonusVectorScore >= 65 ? 'GOOD' : 'NEEDS_WORK',
      statusLabel: isMyDataLinked ? '가점 획득' : '보완 시 +14점',
      evaluationReason: isMyDataLinked 
        ? '마이데이터 연동으로 서류 위변조 방지 및 부채 실시간 증빙 가점 확보' 
        : '마이데이터 미연동 상태로 오프라인 증빙 서류 보강 권장'
    }
  ];

  // 3. Deep Learning Historical Cohort Pattern Matching (Match with SUCCESS_STORIES)
  const matchedPeers: MatchedPeerStoryCase[] = SUCCESS_STORIES.map((story) => {
    let similarity = 70;
    const reasons: string[] = [];

    // Industry match (+12)
    if (
      (industry === Industry.RESTAURANT && story.industryCategory === 'FOOD') ||
      (industry === Industry.IT_SOFTWARE && story.industryCategory === 'TECH') ||
      (industry === Industry.MANUFACTURING && story.industryCategory === 'MANUFACTURING') ||
      (industry === Industry.RETAIL && story.industryCategory === 'RETAIL') ||
      (industry === Industry.SERVICE && story.industryCategory === 'SERVICE')
    ) {
      similarity += 12;
      reasons.push('동일 업종 비즈니스 모델');
    }

    // Debt pattern match (+8)
    if (totalHighInterestDebt > 0 && story.fundingNeedType === 'DEBT_REFINANCE') {
      similarity += 8;
      reasons.push('고금리 채무 구조 및 대환 니즈 유사');
    }

    // Region match (+6)
    if (location.includes(story.province)) {
      similarity += 6;
      reasons.push(`동일 지자체(${story.province}) 보증재단 관할`);
    }

    // Fund category match (+4)
    if (story.fundName.includes('대환') && isRefinanceFund) {
      similarity += 4;
      reasons.push('동일 유형 정책자금');
    }

    const patternSimilarity = Math.min(98.8, similarity + Math.floor(Math.random() * 3));

    return {
      id: story.id,
      businessName: story.businessName,
      ownerName: story.ownerName,
      location: story.location,
      industryLabel: story.industryLabel,
      fundName: story.fundName,
      approvedAmount: story.approvedAmount,
      rateReduction: story.rateReduction,
      patternSimilarity,
      keySuccessFactor: story.keySuccessFactor,
      beforeVsAfter: `${story.rateReduction} 금리 인하, ${story.revenueGrowth}`,
      similarityReasons: reasons.length > 0 ? reasons : ['유사 매출 및 사업 단계']
    };
  })
  .sort((a, b) => b.patternSimilarity - a.patternSimilarity)
  .slice(0, 3); // Top 3 most similar cohorts

  // 4. Actionable Improvement Items (구체적 개선 필요 항목 & 시뮬레이션 포인트)
  const improvementItems: ImprovementActionItem[] = [];

  // Item 1: High Interest Debt Refinancing
  if (totalHighInterestDebt > 0) {
    improvementItems.push({
      id: 'act-debt-refinance',
      title: '2금융권 카드론/캐피탈 채무 우선 대환 소명',
      category: 'DEBT_STRUCTURE',
      categoryLabel: '채무 구조 최적화',
      currentStatus: `2금융권/카드론 고금리 부채 보유 (${(totalHighInterestDebt / 10000).toLocaleString()}만원)`,
      recommendedTarget: '정책 대환자금 신청 시 상환확약서 동봉으로 기존 고금리 부채 100% 해소 계획 명시',
      actionGuide: '심사관에게 단순 신규 부채가 아닌 기존 10%대 고금리를 3%대로 전환하는 "대환 목적"임을 명확히 서류화하면 DSR 예외 적용과 함께 심사 승인율이 급상승합니다.',
      potentialUpliftPercent: 18,
      priority: 'URGENT',
      estimatedDays: '즉시 적용 가능',
      isAppliedInSimulation: false
    });
  }

  // Item 2: MyData Linkage
  if (!isMyDataLinked) {
    improvementItems.push({
      id: 'act-mydata-link',
      title: '소상공인 마이데이터 실시간 연동 및 전자증빙 완료',
      category: 'BONUS_POINTS',
      categoryLabel: '심사 가점 및 신속 트랙',
      currentStatus: '마이데이터 미연동 (수기 종이 서류 발급 필요 상태)',
      recommendedTarget: '홈택스 및 금융 마이데이터 원클릭 연동으로 신뢰성 최고 등급 획득',
      actionGuide: '마이데이터를 연동하면 금융거래확인서, 부가세증명 등 필수 서류 7종이 실시간 자동 검증되어 심사 기간이 14일에서 3~5일로 단축되고 서류 미비 감점이 0건이 됩니다.',
      potentialUpliftPercent: 12,
      priority: 'HIGH',
      estimatedDays: '소요시간 1분',
      isAppliedInSimulation: false
    });
  }

  // Item 3: Credit Education Bonus Points
  improvementItems.push({
    id: 'act-credit-edu',
    title: '소상공인시장진흥공단 온라인 무료 신용관리 교육 이수',
    category: 'CREDIT_MANAGEMENT',
    categoryLabel: '정책 가점',
    currentStatus: '신용관리 비금융 가점 미확보 상태',
    recommendedTarget: '소상공인 지식배움터 온라인 1시간 교육 이수증 첨부',
    actionGuide: '소진공 및 지역신용보증재단 심사 기준표 상 "신용관리 교육 이수자"는 공식 심사 가점 5점~10점이 자동 부여되어 저신용 구간에서도 합격선으로 진입합니다.',
    potentialUpliftPercent: 10,
    priority: 'HIGH',
    estimatedDays: '1일 (온라인 1시간)',
    isAppliedInSimulation: false
  });

  // Item 4: Revenue & Tax Certificate Proof
  improvementItems.push({
    id: 'act-vat-cert',
    title: '최근 6개월 부가가치세 과세표준증명 및 매출 상승 추이 강조',
    category: 'REVENUE_PROOF',
    categoryLabel: '상환 능력 증빙',
    currentStatus: '단순 연매출 표기',
    recommendedTarget: '월별 결제 승인액 및 계절성 매출 회복 추이를 도표화한 보조자료 동봉',
    actionGuide: '비수기 대비 성수기 매출 회복 탄력성을 보여주는 통장 거래내역 또는 POS 매출 리포트를 추가하면 심사역의 원리금 회수 리스크 우려를 완벽히 해소할 수 있습니다.',
    potentialUpliftPercent: 8,
    priority: 'MEDIUM',
    estimatedDays: '2~3일',
    isAppliedInSimulation: false
  });

  // Item 5: Regional Special Quota & Smart Shop Certification
  improvementItems.push({
    id: 'act-local-cert',
    title: '지자체 우대 가점 항목(음식점 위생등급제 / 스마트상점 / 제로페이)',
    category: 'LOCAL_QUOTA',
    categoryLabel: '지자체 특별 가점',
    currentStatus: '일반 지자체 보증 배점',
    recommendedTarget: '식약처 위생등급, 키오스크 도입 증빙, 또는 전통시장 가맹 확인서 제출',
    actionGuide: '지자체별 소상공인 특례보증은 지역 내 스마트화 도입 기업이나 위생 우수 업소에 대해 최대 0.5%p 추가 이차보전 혜택 및 보증비율 100% 우대를 제공합니다.',
    potentialUpliftPercent: 9,
    priority: 'MEDIUM',
    estimatedDays: '3~5일',
    isAppliedInSimulation: false
  });

  // Key risk factors & bonus strengths
  const keyRiskFactors = [];
  if (totalHighInterestDebt > 20000000) keyRiskFactors.push('2금융권 고금리 다중채무로 인한 DSR 부담');
  if (creditScore < 720) keyRiskFactors.push('NICE/KCB 신용평점 보합권으로 가점 서류 보강 필수');
  if (!isMyDataLinked) keyRiskFactors.push('마이데이터 미연동으로 인한 서류 심사 지연 가능성');
  if (keyRiskFactors.length === 0) keyRiskFactors.push('예산 조기 소진 시 접수 마감 위험 (신청 일정 선점 필수)');

  const bonusStrengths = [
    `${industry} 업종 경기 회복 정책 수혜 대상`,
    `${location} 권역 지자체 이차보전 및 보증재단 특별 지원 대상`,
    profitMargin >= 15 ? `안정적인 영업이익률(${profitMargin}%) 기반 원리금 상환력 우수` : '성실 사업 영위 기반 심사 우호적'
  ];
  if (isMyDataLinked) bonusStrengths.push('마이데이터 부채 실시간 공인 인증 완료');
  if (hasSmartFactory) bonusStrengths.push('🏭 스마트공장·스마트공방 도입 기업 (정책 심사 1순위 우대 배정)');
  if (hasCarbonNeutrality) bonusStrengths.push('🌿 ESG 탄소중립 실천 서약 (녹색금융 이차보전 우대)');
  if (hasJobCreation) bonusStrengths.push('👥 청년/정규직 일자리 창출 우수기업');
  if (hasVentureOrInnoBiz) bonusStrengths.push('💡 기술혁신형(이노비즈/벤처/특허) 가점 확보');

  // If Smart Factory or Carbon Neutrality is not active, add them as high-impact improvement items
  if (!hasSmartFactory) {
    improvementItems.unshift({
      id: 'act-smart-factory',
      title: '중기부 소공인 스마트공방/스마트상점 무료 보급사업 참여',
      category: 'BONUS_POINTS',
      categoryLabel: '정부 핵심 가점',
      currentStatus: '스마트공장·공방 미도입 상태',
      recommendedTarget: '중기부 스마트공방 또는 스마트상점 사업 참여 확인서 발급',
      actionGuide: '중기부 스마트공방·스마트상점 사업(정부지원 최대 70~100%) 참여 확인서를 첨부하면, 소진공 및 중진공 심사 시 1차 서류 가점(+12%p)이 즉시 공인 부여됩니다.',
      potentialUpliftPercent: 12,
      priority: 'HIGH',
      estimatedDays: '온라인 신청 1일',
      isAppliedInSimulation: false
    });
  }

  if (!hasCarbonNeutrality) {
    improvementItems.splice(1, 0, {
      id: 'act-carbon-neutrality',
      title: '소진공 넷제로 탄소중립 실천 서약서 온라인 발급 및 등록',
      category: 'BONUS_POINTS',
      categoryLabel: 'ESG 녹색금융 가점',
      currentStatus: '탄소중립 우대 가점 미등록 상태',
      recommendedTarget: '소상공인 탄소중립 실천 서약서(온라인 즉시 발급) 제출',
      actionGuide: '소진공 및 탄소중립포털에서 "소상공인 탄소중립 실천 서약서"를 온라인으로 1분 만에 발급받아 첨부하면, 정책자금 녹색 이차보전(-0.2%p 금리 인하) 및 가점(+8%p)을 획득합니다.',
      potentialUpliftPercent: 8,
      priority: 'HIGH',
      estimatedDays: '온라인 1분 즉시',
      isAppliedInSimulation: false
    });
  }

  return {
    fundId: 'id' in fund ? fund.id : `fund-${Date.now()}`,
    fundTitle,
    agency,
    category,
    overallProbability,
    tier,
    tierLabel,
    tierBadgeColor,
    summaryVerdict,
    examinerReviewOpinion,
    dimensions,
    matchedPeers,
    improvementItems,
    keyRiskFactors,
    bonusStrengths,
    policyBonusAdjustment: {
      baseProbability,
      calibratedProbability,
      totalBonusUplift,
      appliedBonuses,
      examinerCommitteeImpact: totalBonusUplift > 0
        ? `스마트공장(${hasSmartFactory ? '도입' : '미도입'}), 탄소중립(${hasCarbonNeutrality ? '실천' : '미실천'}) 등 총 ${totalBonusUplift}%p의 정책적 우대 가점이 심사역 배점표에 가산되어, 최종 승인 예측 확률이 ${baseProbability}%에서 ${calibratedProbability}%로 보정 상향되었습니다.`
        : '현재 등록된 정책적 가점(스마트공장, 탄소중립 등)이 없습니다. 가점 항목 보완 시 최대 +20%p 이상의 승인 확률 상향이 가능합니다.'
    },
    predictedMaxAmount: maxAmount,
    predictedInterestRate: interestRate,
    generatedAt: new Date().toLocaleDateString('ko-KR', { year: 'numeric', month: 'long', day: 'numeric' })
  };
}
