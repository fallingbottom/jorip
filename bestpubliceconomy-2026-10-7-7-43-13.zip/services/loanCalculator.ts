import { UserProfile, PolicyFund, Industry } from '../types';

export function parseMaxAmountInWon(str?: string): number {
  if (!str) return 0;
  
  const regex = /([\d,\.]+)\s*(억|천만|만|원)?/g;
  let matches;
  let maxVal = 0;
  
  while ((matches = regex.exec(str)) !== null) {
    if (!matches[1]) continue;
    
    let numStr = matches[1].replace(/,/g, '');
    let num = parseFloat(numStr);
    
    if (isNaN(num)) continue;
    
    const unit = matches[2];
    if (unit === '억' || str.slice(regex.lastIndex).startsWith('억원')) {
      num *= 100000000;
    } else if (unit === '천만' || str.slice(regex.lastIndex).startsWith('천만원')) {
      num *= 10000000;
    } else if (unit === '만' || str.slice(regex.lastIndex).startsWith('만원')) {
      num *= 10000;
    } else if (num < 10000 && num > 0) {
      if (num < 1000) continue; 
    }
    
    if (num > maxVal) maxVal = num;
  }
  
  const regex2 = /([\d\.]+)\s*억/g;
  while ((matches = regex2.exec(str)) !== null) {
      let num = parseFloat(matches[1]) * 100000000;
      if (num > maxVal) maxVal = num;
  }
  
  const regex3 = /([\d\.]+)\s*천만/g;
  while ((matches = regex3.exec(str)) !== null) {
      let num = parseFloat(matches[1]) * 10000000;
      if (num > maxVal) maxVal = num;
  }
  
  const regex4 = /([\d\.]+)\s*만/g;
  while ((matches = regex4.exec(str)) !== null) {
      let num = parseFloat(matches[1]) * 10000;
      if (num > maxVal) maxVal = num;
  }

  return maxVal;
}

export function formatWon(amount: number): string {
  if (amount === 0) return '0원';
  if (amount >= 100000000) {
    const uk = Math.floor(amount / 100000000);
    const man = Math.floor((amount % 100000000) / 10000);
    return `${uk}억${man > 0 ? ' ' + man + '만' : ''}원`;
  }
  if (amount >= 10000) {
    const man = Math.floor(amount / 10000);
    return `${man.toLocaleString()}만원`;
  }
  return `${amount.toLocaleString()}원`;
}

export function calculateEstimatedLoanLimit(profile: UserProfile | null | undefined, fund: PolicyFund): number {
  const fundMax = parseMaxAmountInWon(fund.maxAmount);
  if (!profile || !profile.annualRevenue) {
    // If no revenue input, return the fund's max limit, or something conservative.
    return fundMax;
  }
  
  const revenue = profile.annualRevenue;
  
  // Typical maximum loan limit to annual revenue ratio by industry
  let ratio = 0.3; // Default 30%
  
  switch(profile.industry) {
    case Industry.MANUFACTURING:
      ratio = 0.5; // up to 50%
      break;
    case Industry.IT_SOFTWARE:
      ratio = 0.4;
      break;
    case Industry.RETAIL:
      ratio = 0.3;
      break;
    case Industry.RESTAURANT:
      ratio = 0.25;
      break;
    case Industry.SERVICE:
      ratio = 0.25;
      break;
    case Industry.OTHER:
    default:
      ratio = 0.2;
      break;
  }
  
  let estimatedLimit = Math.floor(revenue * ratio);
  
  // Apply a minimum floor (e.g. 10m won for small businesses with low reported revenue)
  if (estimatedLimit < 10000000) {
    estimatedLimit = 10000000; // 10 million won minimum base logic
  }
  
  // Cap at the fund's maximum allowed amount
  if (fundMax > 0 && estimatedLimit > fundMax) {
    estimatedLimit = fundMax;
  }
  
  // Round to nearest million (백만원)
  estimatedLimit = Math.floor(estimatedLimit / 1000000) * 1000000;
  
  return estimatedLimit;
}
