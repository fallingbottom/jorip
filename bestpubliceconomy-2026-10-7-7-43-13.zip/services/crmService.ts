import { collection, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc, query, orderBy, where, serverTimestamp } from 'firebase/firestore';
import { db, auth } from './firebaseService';
import { CrmCustomer, CrmFinancial, CrmApplication, CrmConsultation } from '../types';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: any;
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Format display IDs
const getCustomerDisplayId = (index: number) => `C${new Date().getFullYear()}${String(index + 1).padStart(4, '0')}`;
const getApplicationDisplayId = (index: number) => `A${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${String(index + 1).padStart(4, '0')}`;
const getConsultationDisplayId = (index: number) => `CT${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}${String(new Date().getDate()).padStart(2, '0')}-${String(index + 1).padStart(4, '0')}`;

const STORAGE_KEY_CUSTOMERS = 'bizmatch_crm_customers';

const DEFAULT_DEMO_CUSTOMERS: CrmCustomer[] = [
  {
    id: 'demo-cust-1',
    displayId: 'C20260001',
    userId: 'system',
    businessName: '(주)한라정밀',
    ceoName: '김철수',
    businessType: '법인',
    industryName: '금속가공 제조업',
    industryCode: '25111',
    province: '경기',
    city: '화성시',
    address: '경기도 화성시 향남읍 발안공단로 45',
    openDate: '2021-03-15',
    employeeCount: 7,
    phone: '010-3456-7890',
    memo: '스마트공장 설비투자 목적 시설자금 2억원 상담 희망 (기존 2금융권 1건 보유)',
    createdAt: '2026-01-10T09:00:00.000Z',
    updatedAt: '2026-01-10T09:00:00.000Z',
  },
  {
    id: 'demo-cust-2',
    displayId: 'C20260002',
    userId: 'system',
    businessName: '을지로 맛고을',
    ceoName: '이영희',
    businessType: '개인사업자',
    industryName: '한식 음식점업',
    industryCode: '56111',
    province: '서울',
    city: '중구',
    address: '서울특별시 중구 을지로 124 1층',
    openDate: '2019-06-20',
    employeeCount: 3,
    phone: '010-9876-5432',
    memo: '고금리 카드론(14.8%) 3,000만원 대환 및 소진공 저금리 대환대출 신청 희망',
    createdAt: '2026-01-12T11:30:00.000Z',
    updatedAt: '2026-01-12T11:30:00.000Z',
  },
  {
    id: 'demo-cust-3',
    displayId: 'C20260003',
    userId: 'system',
    businessName: '(주)넥스트소프트',
    ceoName: '박준혁',
    businessType: '법인',
    industryName: '응용 소프트웨어 개발 및 공급업',
    industryCode: '58222',
    province: '경기',
    city: '성남시 분당구',
    address: '경기도 성남시 분당구 판교역로 166',
    openDate: '2023-08-01',
    employeeCount: 5,
    phone: '010-5555-1234',
    memo: '창업 3년 이내 혁신성장유망자금 및 기보 벤처보증 심사 준비 중',
    createdAt: '2026-01-15T14:20:00.000Z',
    updatedAt: '2026-01-15T14:20:00.000Z',
  },
];

// Customers
export const getCustomer = async (customerId: string): Promise<CrmCustomer | null> => {
  const user = auth.currentUser;
  if (user) {
    const path = `users/${user.uid}/crmCustomers/${customerId}`;
    try {
      const docSnap = await getDoc(doc(db, path));
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as CrmCustomer;
      }
    } catch (e) {
      console.warn('Firestore getCustomer warning:', e);
    }
  }

  // Fallback to local storage or demo
  const all = await getCustomers();
  return all.find(c => c.id === customerId) || null;
};

export const getCustomers = async (): Promise<CrmCustomer[]> => {
  const user = auth.currentUser;
  if (user) {
    const path = `users/${user.uid}/crmCustomers`;
    try {
      const q = query(collection(db, path), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      if (!snapshot.empty) {
        const firestoreCustomers = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CrmCustomer));
        localStorage.setItem(STORAGE_KEY_CUSTOMERS, JSON.stringify(firestoreCustomers));
        return firestoreCustomers;
      }
    } catch (error) {
      console.warn('Firestore getCustomers fallback to local cache:', error);
    }
  }

  // Fallback to local storage or initial seed
  try {
    const local = localStorage.getItem(STORAGE_KEY_CUSTOMERS);
    if (local) {
      const parsed = JSON.parse(local);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
    // Seed initial demo customers
    localStorage.setItem(STORAGE_KEY_CUSTOMERS, JSON.stringify(DEFAULT_DEMO_CUSTOMERS));
    return DEFAULT_DEMO_CUSTOMERS;
  } catch (err) {
    return DEFAULT_DEMO_CUSTOMERS;
  }
};

export const addCustomer = async (data: Omit<CrmCustomer, 'id' | 'displayId' | 'userId' | 'createdAt' | 'updatedAt'>): Promise<CrmCustomer> => {
  const user = auth.currentUser;
  const existing = await getCustomers();
  const displayId = getCustomerDisplayId(existing.length);
  const newId = `cust_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  
  const customer: CrmCustomer = {
    ...data,
    id: newId,
    displayId,
    userId: user?.uid || 'system',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  if (user) {
    const path = `users/${user.uid}/crmCustomers`;
    try {
      const newRef = doc(db, path, newId);
      await setDoc(newRef, customer);
    } catch (error) {
      console.warn('Firestore addCustomer fallback to local storage:', error);
    }
  }

  // Always update local cache
  const updated = [customer, ...existing.filter(c => c.id !== newId)];
  localStorage.setItem(STORAGE_KEY_CUSTOMERS, JSON.stringify(updated));
  return customer;
};

export const deleteCustomer = async (customerId: string): Promise<void> => {
  const user = auth.currentUser;
  
  // 1. Delete from Firestore if authenticated
  if (user) {
    const path = `users/${user.uid}/crmCustomers/${customerId}`;
    try {
      await deleteDoc(doc(db, path));
    } catch (error) {
      console.warn('Firestore delete failed, syncing local storage:', error);
    }
  }

  // 2. Synchronize with localStorage
  try {
    const local = localStorage.getItem(STORAGE_KEY_CUSTOMERS);
    if (local) {
      const parsed: CrmCustomer[] = JSON.parse(local);
      const filtered = parsed.filter(c => c.id !== customerId);
      localStorage.setItem(STORAGE_KEY_CUSTOMERS, JSON.stringify(filtered));
    }
  } catch (err) {
    console.error('Failed to remove customer from local storage:', err);
  }
};

// Financials
export const getFinancials = async (customerId: string): Promise<CrmFinancial[]> => {
  const user = auth.currentUser;
  if (!user) return [];
  const path = `users/${user.uid}/crmCustomers/${customerId}/financials`;
  try {
    const q = query(collection(db, path), orderBy('year', 'desc'));
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CrmFinancial));
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
    return [];
  }
};

export const addFinancial = async (customerId: string, data: Omit<CrmFinancial, 'id' | 'userId' | 'customerId' | 'createdAt' | 'updatedAt'>): Promise<CrmFinancial> => {
  const user = auth.currentUser;
  if (!user) throw new Error('Not authenticated');
  const path = `users/${user.uid}/crmCustomers/${customerId}/financials`;
  try {
    const newRef = doc(collection(db, path));
    const financial: CrmFinancial = {
      ...data,
      id: newRef.id,
      userId: user.uid,
      customerId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await setDoc(newRef, financial);
    return financial;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
};

// Applications
export const getApplications = async (customerId?: string): Promise<CrmApplication[]> => {
  const user = auth.currentUser;
  if (!user) return [];
  
  if (customerId) {
    const path = `users/${user.uid}/crmCustomers/${customerId}/applications`;
    try {
      const q = query(collection(db, path), orderBy('applyDate', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CrmApplication));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  }
  return []; // We won't query globally across subcollections for now to avoid collection group index requirement.
};

export const addApplication = async (customerId: string, data: Omit<CrmApplication, 'id' | 'displayId' | 'userId' | 'customerId' | 'createdAt' | 'updatedAt'>): Promise<CrmApplication> => {
  const user = auth.currentUser;
  if (!user) throw new Error('Not authenticated');
  const path = `users/${user.uid}/crmCustomers/${customerId}/applications`;
  try {
    const existing = await getApplications(customerId);
    const displayId = getApplicationDisplayId(existing.length);
    const newRef = doc(collection(db, path));
    const application: CrmApplication = {
      ...data,
      id: newRef.id,
      displayId,
      userId: user.uid,
      customerId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await setDoc(newRef, application);
    return application;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
};

// Consultations
export const getConsultations = async (customerId?: string): Promise<CrmConsultation[]> => {
  const user = auth.currentUser;
  if (!user) return [];
  if (customerId) {
    const path = `users/${user.uid}/crmCustomers/${customerId}/consultationRecords`;
    try {
      const q = query(collection(db, path), orderBy('consultDate', 'desc'));
      const snapshot = await getDocs(q);
      return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as CrmConsultation));
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, path);
      return [];
    }
  }
  return [];
};

export const addConsultation = async (customerId: string, data: Omit<CrmConsultation, 'id' | 'displayId' | 'userId' | 'customerId' | 'createdAt' | 'updatedAt'>): Promise<CrmConsultation> => {
  const user = auth.currentUser;
  if (!user) throw new Error('Not authenticated');
  const path = `users/${user.uid}/crmCustomers/${customerId}/consultationRecords`;
  try {
    const existing = await getConsultations(customerId);
    const displayId = getConsultationDisplayId(existing.length);
    const newRef = doc(collection(db, path));
    const record: CrmConsultation = {
      ...data,
      id: newRef.id,
      displayId,
      userId: user.uid,
      customerId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    await setDoc(newRef, record);
    return record;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    throw error;
  }
};
