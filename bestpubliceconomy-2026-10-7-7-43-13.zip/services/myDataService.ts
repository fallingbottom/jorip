import { UserProfile, BusinessType, Industry } from '../types';

/**
 * 마이데이터 연동을 시뮬레이션하는 서비스입니다.
 * 실제 환경에서는 금융결제원 API 또는 스크래핑 기술을 사용합니다.
 */
export const connectMyData = async (): Promise<Partial<UserProfile>> => {
  // 실제 API 통신 지연 시간 시뮬레이션 (1.5초)
  await new Promise(resolve => setTimeout(resolve, 1500));

  // 가상의 국세청/은행 데이터 반환
  return {
    name: '김토스',
    businessName: '혁신 베이커리',
    businessRegistrationNumber: '123-45-67890',
    businessAddress: '서울시 강남구 테헤란로 123',
    businessType: BusinessType.INDIVIDUAL,
    industry: Industry.RESTAURANT,
    location: '서울',
    foundedYear: '2021',
    annualRevenue: 450000000, // 4.5억
    creditScore: 880, // KCB 기준
    employees: 4,
    expectedProfitMargin: 22, // 국세청 신고 기준 영업이익률
    cashFlowStatus: 85, // 통장 입출금 내역 기반 점수
    
    // 부채 정보 (금융권 공유 데이터)
    debt1Tier: 50000000, // 1금융권 5천
    debt2Tier: 10000000, // 2금융권 1천
    debtCardLoan: 0,
    debtOther: 0,
    
    isMyDataLinked: true
  };
};
