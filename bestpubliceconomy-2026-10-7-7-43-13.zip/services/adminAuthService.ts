import { User } from 'firebase/auth';

export type AdminRole = 'SUPER_ADMIN' | 'AUDITOR' | 'CONSULTANT';

export interface AdminUser {
  id: string;
  email: string;
  name: string;
  role: AdminRole;
  businessName?: string;
  phone?: string;
  createdAt: string;
  lastLoginAt?: string;
  isApproved: boolean;
  provider?: 'google' | 'email' | 'master_passcode';
}

export interface AdminSettings {
  isProtectionEnabled: boolean;
  masterPasscode: string;
  allowSelfRegistration: boolean;
  requireAdminCode: boolean;
  adminInvitationCode: string;
  authorizedEmails: string[];
}

const STORAGE_KEY_ADMIN_USERS = 'bizmatch_admin_users';
const STORAGE_KEY_ADMIN_SETTINGS = 'bizmatch_admin_settings';
const STORAGE_KEY_CURRENT_ADMIN = 'bizmatch_current_admin_session';

// Bootstrapped default super admin (from project metadata: fujinilove@gmail.com)
const DEFAULT_AUTHORIZED_EMAILS = [
  'fujinilove@gmail.com',
  'admin@bizmatch.ai',
  'examiner@semas.or.kr',
];

const INITIAL_ADMIN_USERS: AdminUser[] = [
  {
    id: 'admin-master-1',
    email: 'fujinilove@gmail.com',
    name: '최고 관리자 (fujini)',
    role: 'SUPER_ADMIN',
    businessName: 'BizMatch AI 시스템 총괄',
    createdAt: '2026-01-01T00:00:00.000Z',
    isApproved: true,
    provider: 'google',
  },
  {
    id: 'admin-consultant-2',
    email: 'admin@bizmatch.ai',
    name: '수석 정책자금 심사역',
    role: 'CONSULTANT',
    businessName: '중소기업정책연구소',
    createdAt: '2026-02-01T00:00:00.000Z',
    isApproved: true,
    provider: 'email',
  },
];

const INITIAL_SETTINGS: AdminSettings = {
  isProtectionEnabled: true,
  masterPasscode: '2026',
  allowSelfRegistration: true,
  requireAdminCode: true,
  adminInvitationCode: 'BIZ-ADMIN-2026',
  authorizedEmails: DEFAULT_AUTHORIZED_EMAILS,
};

// Retrieve Admin Settings
export const getAdminSettings = (): AdminSettings => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_ADMIN_SETTINGS);
    if (raw) {
      const parsed = JSON.parse(raw);
      // Ensure fujinilove@gmail.com is always authorized
      if (!parsed.authorizedEmails.includes('fujinilove@gmail.com')) {
        parsed.authorizedEmails.unshift('fujinilove@gmail.com');
      }
      return parsed;
    }
  } catch (e) {
    console.warn('Failed to load admin settings', e);
  }
  return INITIAL_SETTINGS;
};

// Save Admin Settings
export const saveAdminSettings = (settings: AdminSettings): void => {
  try {
    localStorage.setItem(STORAGE_KEY_ADMIN_SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.warn('Failed to save admin settings', e);
  }
};

// Retrieve Admin Users
export const getAdminUsers = (): AdminUser[] => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_ADMIN_USERS);
    if (raw) {
      const parsed: AdminUser[] = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        // Ensure fujinilove is in the list
        if (!parsed.some(u => u.email.toLowerCase() === 'fujinilove@gmail.com')) {
          parsed.unshift(INITIAL_ADMIN_USERS[0]);
        }
        return parsed;
      }
    }
  } catch (e) {
    console.warn('Failed to load admin users', e);
  }
  return INITIAL_ADMIN_USERS;
};

// Save Admin Users
export const saveAdminUsers = (users: AdminUser[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY_ADMIN_USERS, JSON.stringify(users));
  } catch (e) {
    console.warn('Failed to save admin users', e);
  }
};

// Check if an email is an authorized admin
export const isAuthorizedAdminEmail = (email?: string | null): boolean => {
  if (!email) return false;
  const normalized = email.trim().toLowerCase();
  const settings = getAdminSettings();
  const isEmailListed = settings.authorizedEmails.some(e => e.toLowerCase() === normalized);
  if (isEmailListed) return true;

  const users = getAdminUsers();
  return users.some(u => u.email.toLowerCase() === normalized && u.isApproved);
};

// Current Session Management
export const getCurrentAdminSession = (): AdminUser | null => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_CURRENT_ADMIN);
    if (raw) {
      return JSON.parse(raw);
    }
  } catch (e) {
    console.warn('Failed to load current admin session', e);
  }
  return null;
};

export const setAdminSession = (adminUser: AdminUser | null): void => {
  try {
    if (adminUser) {
      localStorage.setItem(STORAGE_KEY_CURRENT_ADMIN, JSON.stringify(adminUser));
    } else {
      localStorage.removeItem(STORAGE_KEY_CURRENT_ADMIN);
    }
  } catch (e) {
    console.warn('Failed to set admin session', e);
  }
};

export const clearAdminSession = (): void => {
  setAdminSession(null);
};

// Verify Master Passcode
export const verifyMasterPasscode = (passcode: string): boolean => {
  const settings = getAdminSettings();
  return settings.masterPasscode.trim() === passcode.trim();
};

// Create a session with master passcode
export const authenticateWithMasterPasscode = (passcode: string): { success: boolean; user?: AdminUser; error?: string } => {
  if (!verifyMasterPasscode(passcode)) {
    return { success: false, error: '마스터 패스코드가 일치하지 않습니다.' };
  }

  const sessionUser: AdminUser = {
    id: `admin-master-session-${Date.now()}`,
    email: 'fujinilove@gmail.com',
    name: '마스터 인증 관리자',
    role: 'SUPER_ADMIN',
    businessName: 'BizMatch AI CRM 관제탑',
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
    isApproved: true,
    provider: 'master_passcode',
  };

  setAdminSession(sessionUser);
  return { success: true, user: sessionUser };
};

// Authenticate with Google User
export const authenticateWithGoogleUser = (googleUser: User): { success: boolean; user?: AdminUser; isAuthorizedAdmin: boolean } => {
  const email = googleUser.email || '';
  const isAuthorized = isAuthorizedAdminEmail(email);

  const existingUsers = getAdminUsers();
  let matched = existingUsers.find(u => u.email.toLowerCase() === email.toLowerCase());

  if (!matched && isAuthorized) {
    matched = {
      id: `admin-${googleUser.uid}`,
      email: email,
      name: googleUser.displayName || '구글 인증 관리자',
      role: email.toLowerCase() === 'fujinilove@gmail.com' ? 'SUPER_ADMIN' : 'CONSULTANT',
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
      isApproved: true,
      provider: 'google',
    };
    saveAdminUsers([...existingUsers, matched]);
  }

  if (matched) {
    matched.lastLoginAt = new Date().toISOString();
    setAdminSession(matched);
    return { success: true, user: matched, isAuthorizedAdmin: true };
  }

  // Not an admin, but a normal authenticated user
  return {
    success: false,
    isAuthorizedAdmin: false,
  };
};

// Add / Update Admin User
export const addAdminUser = (email: string, name: string, role: AdminRole, businessName?: string): AdminUser => {
  const normalizedEmail = email.trim().toLowerCase();
  const users = getAdminUsers();
  const settings = getAdminSettings();

  const existingIndex = users.findIndex(u => u.email.toLowerCase() === normalizedEmail);
  const updatedUser: AdminUser = {
    id: existingIndex >= 0 ? users[existingIndex].id : `admin-${Date.now()}`,
    email: normalizedEmail,
    name: name.trim(),
    role: role,
    businessName: businessName?.trim(),
    createdAt: existingIndex >= 0 ? users[existingIndex].createdAt : new Date().toISOString(),
    lastLoginAt: existingIndex >= 0 ? users[existingIndex].lastLoginAt : undefined,
    isApproved: true,
  };

  let newUsers: AdminUser[];
  if (existingIndex >= 0) {
    newUsers = [...users];
    newUsers[existingIndex] = updatedUser;
  } else {
    newUsers = [updatedUser, ...users];
  }
  saveAdminUsers(newUsers);

  // Sync with authorizedEmails in settings
  if (!settings.authorizedEmails.some(e => e.toLowerCase() === normalizedEmail)) {
    settings.authorizedEmails.push(normalizedEmail);
    saveAdminSettings(settings);
  }

  return updatedUser;
};

// Remove Admin User
export const removeAdminUser = (email: string): boolean => {
  const normalizedEmail = email.trim().toLowerCase();
  // Prevent removing master admin
  if (normalizedEmail === 'fujinilove@gmail.com') {
    return false;
  }

  const users = getAdminUsers().filter(u => u.email.toLowerCase() !== normalizedEmail);
  saveAdminUsers(users);

  const settings = getAdminSettings();
  settings.authorizedEmails = settings.authorizedEmails.filter(e => e.toLowerCase() !== normalizedEmail);
  saveAdminSettings(settings);

  return true;
};

// Update Master Passcode
export const updateMasterPasscode = (newPasscode: string): boolean => {
  if (!newPasscode || newPasscode.trim().length < 4) {
    return false;
  }
  const settings = getAdminSettings();
  settings.masterPasscode = newPasscode.trim();
  saveAdminSettings(settings);
  return true;
};

// Toggle CRM Protection Mode
export const toggleCrmProtection = (enabled: boolean): void => {
  const settings = getAdminSettings();
  settings.isProtectionEnabled = enabled;
  saveAdminSettings(settings);
};
