export interface MatchingParameters {
  budgetExhaustionWeight: number; // 예산 소진율 가중치 (0 ~ 100%)
  industryPreferenceRate: number; // 업종별 금리 우대율 (0 ~ 2.0%p)
  creditCutoffThreshold: number; // 저신용 기준 컷오프 (e.g. 839점)
  urgentDeadlineWindowDays: number; // 마감 임박 기준 일수 (e.g. 3일 또는 7일)
  regionalQuotaBias: number; // 지역 예산 우선 배정 비율 (%)
  autoSyncIntervalMinutes: number; // 수집기 동기화 주기 (분 단위)
}

export interface PolicyBonusWeights {
  // 개별 가점 항목 기본 점수 (0 ~ 30점)
  smartFactoryBasePoints: number;       // 스마트공장·스마트공방 도입 (기본: 10점, 0~30점)
  smartFactorySpecializedBonus: number; // 스마트/제조 특화 자금 추가 부스팅 (기본: 4점, 0~15점)
  carbonNeutralityPoints: number;      // 탄소중립·친환경 ESG 실천 (기본: 8점, 0~30점)
  jobCreationPoints: number;           // 청년·정규직 일자리 창출 (기본: 6점, 0~25점)
  ventureInnoBizPoints: number;        // 이노비즈·벤처·특허 기술혁신 (기본: 8점, 0~30점)
  creditEducationPoints: number;       // 소진공 신용관리 사전교육 이수 (기본: 5점, 0~20점)
  exportPromisingPoints: number;       // 수출유망·글로벌 강소기업 (기본: 7점, 0~25점)
  femaleOrDisabledPoints: number;      // 여성·장애인·사회적기업 (기본: 5점, 0~20점)
  myDataInstantPoints: number;         // 마이데이터 즉시 검증 (기본: 5점, 0~20점)

  // 정책 분야별 가점 부스팅 배율 (0.5x ~ 3.0x)
  multipliers: {
    manufacturing: number;   // 제조/소공인 특화 자금 배율 (1.0x ~ 3.0x)
    esgGreen: number;        // ESG 녹색금융/탄소중립 자금 배율 (1.0x ~ 3.0x)
    youthEmployment: number; // 청년고용/일자리 자금 배율 (1.0x ~ 3.0x)
    techVenture: number;     // 기술보증/혁신 스타트업 자금 배율 (1.0x ~ 3.0x)
    generalStability: number;// 일반경영안정 자금 배율 (0.5x ~ 2.0x)
    refinanceRelief: number; // 고금리 대환/채무조정 자금 배율 (0.5x ~ 2.0x)
  };

  // AI 승인 알고리즘 글로벌 감도 (Global Sensitivity, 0.5 ~ 2.0)
  globalBonusSensitivity: number; // 전체 가점 가중치 마스터 슬라이더

  // 메타 정보
  activePreset: 'DEFAULT' | 'SMART_MANUFACTURING' | 'ESG_CARBON' | 'YOUTH_EMPLOYMENT' | 'TECH_VENTURE' | 'CUSTOM';
  presetName: string;
  lastTunedAt: string;
  tunedBy: string;
}

export const DEFAULT_BONUS_WEIGHTS: PolicyBonusWeights = {
  smartFactoryBasePoints: 10,
  smartFactorySpecializedBonus: 4,
  carbonNeutralityPoints: 8,
  jobCreationPoints: 6,
  ventureInnoBizPoints: 8,
  creditEducationPoints: 5,
  exportPromisingPoints: 7,
  femaleOrDisabledPoints: 5,
  myDataInstantPoints: 5,
  multipliers: {
    manufacturing: 1.2,
    esgGreen: 1.2,
    youthEmployment: 1.2,
    techVenture: 1.2,
    generalStability: 1.0,
    refinanceRelief: 1.0
  },
  globalBonusSensitivity: 1.0,
  activePreset: 'DEFAULT',
  presetName: '2026 정부 정책자금 표준 가중치',
  lastTunedAt: '2026-10-01 10:00:00',
  tunedBy: '중기부 표준 매칭 엔진'
};

export const BONUS_WEIGHT_PRESETS: Record<string, Partial<PolicyBonusWeights>> = {
  DEFAULT: {
    activePreset: 'DEFAULT',
    presetName: '2026 정부 정책자금 표준 가중치',
    smartFactoryBasePoints: 10,
    smartFactorySpecializedBonus: 4,
    carbonNeutralityPoints: 8,
    jobCreationPoints: 6,
    ventureInnoBizPoints: 8,
    creditEducationPoints: 5,
    exportPromisingPoints: 7,
    femaleOrDisabledPoints: 5,
    myDataInstantPoints: 5,
    multipliers: {
      manufacturing: 1.2,
      esgGreen: 1.2,
      youthEmployment: 1.2,
      techVenture: 1.2,
      generalStability: 1.0,
      refinanceRelief: 1.0
    },
    globalBonusSensitivity: 1.0
  },
  SMART_MANUFACTURING: {
    activePreset: 'SMART_MANUFACTURING',
    presetName: '2026 첨단제조·스마트공방 집중 드라이브',
    smartFactoryBasePoints: 18,
    smartFactorySpecializedBonus: 8,
    carbonNeutralityPoints: 10,
    jobCreationPoints: 7,
    ventureInnoBizPoints: 12,
    creditEducationPoints: 5,
    exportPromisingPoints: 9,
    femaleOrDisabledPoints: 5,
    myDataInstantPoints: 6,
    multipliers: {
      manufacturing: 1.8,
      esgGreen: 1.1,
      youthEmployment: 1.2,
      techVenture: 1.5,
      generalStability: 1.0,
      refinanceRelief: 0.9
    },
    globalBonusSensitivity: 1.15
  },
  ESG_CARBON: {
    activePreset: 'ESG_CARBON',
    presetName: '친환경 ESG 탄소중립·녹색금융 우대 모드',
    smartFactoryBasePoints: 12,
    smartFactorySpecializedBonus: 4,
    carbonNeutralityPoints: 18,
    jobCreationPoints: 6,
    ventureInnoBizPoints: 10,
    creditEducationPoints: 5,
    exportPromisingPoints: 8,
    femaleOrDisabledPoints: 6,
    myDataInstantPoints: 6,
    multipliers: {
      manufacturing: 1.1,
      esgGreen: 2.0,
      youthEmployment: 1.1,
      techVenture: 1.3,
      generalStability: 1.0,
      refinanceRelief: 1.0
    },
    globalBonusSensitivity: 1.2
  },
  YOUTH_EMPLOYMENT: {
    activePreset: 'YOUTH_EMPLOYMENT',
    presetName: '청년 창업 & 일자리 창출 특화 모드',
    smartFactoryBasePoints: 8,
    smartFactorySpecializedBonus: 3,
    carbonNeutralityPoints: 7,
    jobCreationPoints: 16,
    ventureInnoBizPoints: 10,
    creditEducationPoints: 6,
    exportPromisingPoints: 8,
    femaleOrDisabledPoints: 9,
    myDataInstantPoints: 6,
    multipliers: {
      manufacturing: 1.0,
      esgGreen: 1.0,
      youthEmployment: 2.0,
      techVenture: 1.3,
      generalStability: 1.1,
      refinanceRelief: 1.0
    },
    globalBonusSensitivity: 1.1
  },
  TECH_VENTURE: {
    activePreset: 'TECH_VENTURE',
    presetName: '기보/신보 기술혁신·특허 고성장 모드',
    smartFactoryBasePoints: 14,
    smartFactorySpecializedBonus: 5,
    carbonNeutralityPoints: 9,
    jobCreationPoints: 8,
    ventureInnoBizPoints: 18,
    creditEducationPoints: 5,
    exportPromisingPoints: 14,
    femaleOrDisabledPoints: 6,
    myDataInstantPoints: 7,
    multipliers: {
      manufacturing: 1.3,
      esgGreen: 1.2,
      youthEmployment: 1.3,
      techVenture: 2.0,
      generalStability: 0.9,
      refinanceRelief: 0.8
    },
    globalBonusSensitivity: 1.25
  }
};

export const DEFAULT_MATCHING_PARAMS: MatchingParameters = {
  budgetExhaustionWeight: 35,
  industryPreferenceRate: 0.5,
  creditCutoffThreshold: 839,
  urgentDeadlineWindowDays: 3,
  regionalQuotaBias: 20,
  autoSyncIntervalMinutes: 5,
};

const STORAGE_KEY = 'bizmatch_matching_params';
const BONUS_WEIGHTS_STORAGE_KEY = 'bizmatch_policy_bonus_weights';

export const getMatchingParameters = (): MatchingParameters => {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      return { ...DEFAULT_MATCHING_PARAMS, ...JSON.parse(saved) };
    }
  } catch (err) {
    console.error("Failed to load matching parameters", err);
  }
  return DEFAULT_MATCHING_PARAMS;
};

export const saveMatchingParameters = (params: MatchingParameters): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(params));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('bizmatch_params_updated', { detail: params }));
    }
  } catch (err) {
    console.error("Failed to save matching parameters", err);
  }
};

export const getPolicyBonusWeights = (): PolicyBonusWeights => {
  try {
    const saved = localStorage.getItem(BONUS_WEIGHTS_STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved);
      return {
        ...DEFAULT_BONUS_WEIGHTS,
        ...parsed,
        multipliers: {
          ...DEFAULT_BONUS_WEIGHTS.multipliers,
          ...(parsed.multipliers || {})
        }
      };
    }
  } catch (err) {
    console.error("Failed to load policy bonus weights", err);
  }
  return DEFAULT_BONUS_WEIGHTS;
};

export const savePolicyBonusWeights = (weights: PolicyBonusWeights): void => {
  try {
    const enriched: PolicyBonusWeights = {
      ...weights,
      lastTunedAt: new Date().toLocaleString('ko-KR')
    };
    localStorage.setItem(BONUS_WEIGHTS_STORAGE_KEY, JSON.stringify(enriched));
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('bizmatch_bonus_weights_updated', { detail: enriched }));
    }
  } catch (err) {
    console.error("Failed to save policy bonus weights", err);
  }
};

export const resetPolicyBonusWeights = (): PolicyBonusWeights => {
  savePolicyBonusWeights(DEFAULT_BONUS_WEIGHTS);
  return DEFAULT_BONUS_WEIGHTS;
};

export const applyPresetBonusWeights = (presetKey: string): PolicyBonusWeights => {
  const preset = BONUS_WEIGHT_PRESETS[presetKey] || DEFAULT_BONUS_WEIGHTS;
  const current = getPolicyBonusWeights();
  const updated: PolicyBonusWeights = {
    ...current,
    ...preset,
    multipliers: {
      ...current.multipliers,
      ...(preset.multipliers || {})
    },
    activePreset: (preset.activePreset || 'CUSTOM') as any,
    presetName: preset.presetName || '커스텀 튜닝 모드',
    lastTunedAt: new Date().toLocaleString('ko-KR')
  };
  savePolicyBonusWeights(updated);
  return updated;
};
