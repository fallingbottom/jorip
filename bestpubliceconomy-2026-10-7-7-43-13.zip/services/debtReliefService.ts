import { DebtReliefInput, ScreeningResult } from '../debtReliefTypes';

export const runDebtReliefScreening = (input: DebtReliefInput): ScreeningResult[] => {
  const results: ScreeningResult[] = [];
  const totalDebt = input.unsecuredDebtAmount + input.securedDebtAmount;

  // CCRS Validation (신복위 공통)
  const isCcrsDebtExceeded = input.unsecuredDebtAmount > 500000000 || input.securedDebtAmount > 1000000000;
  
  // 1. 신속채무조정 (CCRS_FAST)
  let fastStatus: 'CANDIDATE' | 'BLOCKED_BY_OFFICIAL_RULE' | 'VERIFY_REQUIRED' = 'CANDIDATE';
  const fastReasons: string[] = [];
  const fastMissing: string[] = [];
  
  if (isCcrsDebtExceeded) {
    fastStatus = 'BLOCKED_BY_OFFICIAL_RULE';
    fastReasons.push('총 채무액 한도 초과 (무담보 5억 또는 담보 10억 초과)');
  } else if (input.recentDebtRatioOver30 === true) {
    fastStatus = 'BLOCKED_BY_OFFICIAL_RULE';
    fastReasons.push('최근 6개월 신규채무 비중 30% 이상');
  } else if (input.recentDebtRatioOver30 === null) {
    fastStatus = 'VERIFY_REQUIRED';
    fastMissing.push('최근 6개월 신규채무 비중 30% 미만 여부 확인 필요');
  }

  if (input.daysPastDue > 30) {
    fastStatus = 'BLOCKED_BY_OFFICIAL_RULE';
    fastReasons.push('연체 30일 초과 (신속채무조정 대상 아님)');
  } else if (input.daysPastDue === 0) {
    if (fastStatus !== 'BLOCKED_BY_OFFICIAL_RULE') {
      fastStatus = 'VERIFY_REQUIRED';
      fastMissing.push('비연체 신청사유 (실직, 휴직, 폐업 등) 확인 필요');
    }
  } else {
    fastReasons.push('연체 30일 이하 조건 충족');
  }

  results.push({
    programCode: 'CCRS_FAST',
    programName: '신속채무조정',
    status: fastStatus,
    reasons: fastReasons,
    missingInformation: fastMissing,
    agencyName: '신용회복위원회'
  });

  // 2. 사전채무조정 (CCRS_PRE)
  let preStatus: 'CANDIDATE' | 'BLOCKED_BY_OFFICIAL_RULE' | 'VERIFY_REQUIRED' = 'CANDIDATE';
  const preReasons: string[] = [];
  const preMissing: string[] = [];

  if (isCcrsDebtExceeded) {
    preStatus = 'BLOCKED_BY_OFFICIAL_RULE';
    preReasons.push('총 채무액 한도 초과');
  } else if (input.recentDebtRatioOver30 === true) {
    preStatus = 'BLOCKED_BY_OFFICIAL_RULE';
    preReasons.push('최근 6개월 신규채무 비중 30% 이상');
  } else if (input.recentDebtRatioOver30 === null) {
    preStatus = 'VERIFY_REQUIRED';
    preMissing.push('최근 6개월 신규채무 비중 확인 필요');
  }

  if (input.daysPastDue < 31 || input.daysPastDue > 89) {
    preStatus = 'BLOCKED_BY_OFFICIAL_RULE';
    preReasons.push(`연체 일수(${input.daysPastDue}일)가 31~89일 구간을 벗어남`);
  } else {
    preReasons.push('연체 31~89일 조건 충족');
  }
  preMissing.push('혼합 연체채권(다중 채무 연체일 상이) 처리 기준 확인 필요');

  if (preStatus !== 'BLOCKED_BY_OFFICIAL_RULE') preStatus = 'VERIFY_REQUIRED'; // due to missing rule

  results.push({
    programCode: 'CCRS_PRE',
    programName: '사전채무조정',
    status: preStatus,
    reasons: preReasons,
    missingInformation: preMissing,
    agencyName: '신용회복위원회'
  });

  // 3. 개인워크아웃 (CCRS_WORKOUT)
  let workoutStatus: 'CANDIDATE' | 'BLOCKED_BY_OFFICIAL_RULE' | 'VERIFY_REQUIRED' = 'CANDIDATE';
  const workoutReasons: string[] = [];
  const workoutMissing: string[] = [];

  if (isCcrsDebtExceeded) {
    workoutStatus = 'BLOCKED_BY_OFFICIAL_RULE';
    workoutReasons.push('총 채무액 한도 초과');
  } else if (input.recentDebtRatioOver30 === true) {
    workoutStatus = 'BLOCKED_BY_OFFICIAL_RULE';
    workoutReasons.push('최근 6개월 신규채무 비중 30% 이상');
  } else if (input.recentDebtRatioOver30 === null) {
    workoutStatus = 'VERIFY_REQUIRED';
    workoutMissing.push('최근 6개월 신규채무 비중 확인 필요');
  }

  if (input.daysPastDue < 90) {
    workoutStatus = 'BLOCKED_BY_OFFICIAL_RULE';
    workoutReasons.push('연체 90일 미만');
  } else {
    workoutReasons.push('연체 90일 이상 조건 충족');
  }
  
  workoutMissing.push('채권별 상각 여부 및 채권자 동의/상환안 확인 필요');
  if (workoutStatus !== 'BLOCKED_BY_OFFICIAL_RULE') workoutStatus = 'VERIFY_REQUIRED';

  results.push({
    programCode: 'CCRS_WORKOUT',
    programName: '개인워크아웃',
    status: workoutStatus,
    reasons: workoutReasons,
    missingInformation: workoutMissing,
    agencyName: '신용회복위원회'
  });

  // 4. 새출발기금 (NEW_START_FUND)
  let nsfStatus: 'CANDIDATE' | 'BLOCKED_BY_OFFICIAL_RULE' | 'VERIFY_REQUIRED' = 'CANDIDATE';
  const nsfReasons: string[] = [];
  const nsfMissing: string[] = [];

  if (!input.isBusiness) {
    nsfStatus = 'BLOCKED_BY_OFFICIAL_RULE';
    nsfReasons.push('소상공인/자영업자 대상 (비사업자 제외)');
  } else {
    nsfReasons.push('사업자(또는 폐업자) 요건 충족');
    nsfMissing.push('부실우려차주 세부 판정 요건 확인 필요 (최신 기준)');
    nsfMissing.push('협약기관 매입 가능 채권 여부 및 재산평가 확인 필요');
    nsfStatus = 'VERIFY_REQUIRED';
  }

  results.push({
    programCode: 'NEW_START_FUND',
    programName: '새출발기금',
    status: nsfStatus,
    reasons: nsfReasons,
    missingInformation: nsfMissing,
    agencyName: '캠코(KAMCO)'
  });

  // 5. 금융회사 직접 채무조정 (DIRECT_CREDITOR_ADJUSTMENT)
  results.push({
    programCode: 'DIRECT_CREDITOR_ADJUSTMENT',
    programName: '금융회사 직접 채무조정 요청',
    status: 'VERIFY_REQUIRED',
    reasons: ['개인채무자보호법에 따른 법정 요청 경로'],
    missingInformation: ['현행 금액·거절사유·회사별 내부기준 전부 확인 필요'],
    agencyName: '개별 금융회사'
  });

  return results;
};
