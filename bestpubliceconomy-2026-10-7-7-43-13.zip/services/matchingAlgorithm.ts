import { UserProfile, SourcePolicy } from '../types';
import { getPolicyBonusWeights } from './matchingParamService';

export interface ScoredPolicy extends SourcePolicy {
  matchScore: number;
  matchReasons: string[];
}

export const filterAndScorePolicies = (
  profile: UserProfile,
  policies: SourcePolicy[]
): ScoredPolicy[] => {
  const currentYear = new Date().getFullYear();
  const foundedYear = parseInt(profile.foundedYear) || currentYear;
  const businessYears = currentYear - foundedYear;

  const tunedWeights = getPolicyBonusWeights();
  const globalSens = tunedWeights.globalBonusSensitivity || 1.0;
  const multipliers = tunedWeights.multipliers || {
    manufacturing: 1.2,
    esgGreen: 1.2,
    youthEmployment: 1.2,
    techVenture: 1.2,
    generalStability: 1.0,
    refinanceRelief: 1.0
  };

  const scored: ScoredPolicy[] = [];

  for (const policy of policies) {
    let score = 100;
    const reasons: string[] = [];

    // Evaluate constraints if any
    if (policy.matchConstraints) {
      const c = policy.matchConstraints;

      // 1. Industry Check
      if (c.targetIndustries && c.targetIndustries.length > 0) {
        if (!c.targetIndustries.includes(profile.industry)) {
          // If strictly targeted to another industry, score drops significantly or ineligible
          score -= 50;
          reasons.push(`❌ ${profile.industry} 업종은 우선지원대상이 아닙니다.`);
        } else {
          score += 20;
          reasons.push(`✅ ${profile.industry} 업종 맞춤형 자금입니다.`);
        }
      }

      // 2. Employee Count Check
      if (c.maxEmployees !== undefined && profile.employees > c.maxEmployees) {
        score -= 40;
        reasons.push(`❌ 상시근로자 수 제한(${c.maxEmployees}인 이하) 초과`);
      } else if (c.maxEmployees !== undefined) {
        reasons.push(`✅ 상시근로자 수 조건 충족`);
      }

      // 3. Revenue Check
      if (c.maxRevenue !== undefined && profile.annualRevenue > c.maxRevenue) {
        score -= 40;
        reasons.push(`❌ 매출액 제한(${c.maxRevenue.toLocaleString()}원 이하) 초과`);
      }

      // 4. Founded Years (Business Duration)
      if (c.maxFoundedYears !== undefined && businessYears > c.maxFoundedYears) {
        score -= 40;
        reasons.push(`❌ 업력 제한(${c.maxFoundedYears}년 이내) 초과 (현재 업력: ${businessYears}년)`);
      }
      if (c.minFoundedYears !== undefined && businessYears < c.minFoundedYears) {
        score -= 40;
        reasons.push(`❌ 필요 업력(${c.minFoundedYears}년 이상) 미달 (현재 업력: ${businessYears}년)`);
      } else if (c.maxFoundedYears !== undefined || c.minFoundedYears !== undefined) {
        reasons.push(`✅ 사업자 등록 기간 조건 충족 (현재 업력: ${businessYears}년)`);
      }
    }

    // Amount vs Funding Need Matching
    // Parse maxAmount string loosely to get a number
    const amountStr = policy.maxAmount || "0";
    // basic parsing, e.g., "70,000,000" -> 70000000
    const numbersInAmount = amountStr.replace(/[^0-9]/g, '');
    const maxPossibleAmount = numbersInAmount ? parseInt(numbersInAmount) : 0;

    if (maxPossibleAmount > 0) {
      // If the max possible is significantly lower than funding need, penalize slightly but not eliminate
      if (maxPossibleAmount < profile.fundingNeed) {
        score -= 10;
        reasons.push(`⚠️ 지원 한도가 필요 금액(${profile.fundingNeed.toLocaleString()}원)보다 낮을 수 있습니다.`);
      } else {
        score += 10;
        reasons.push(`✅ 필요 금액(${profile.fundingNeed.toLocaleString()}원) 충분히 지원 가능`);
      }
    }

    // 5. 정책적 가점 항목 (스마트공장, 탄소중립 등) 튜닝 가중치 보정 반영
    const bonus = profile.policyBonusFactors;
    if (bonus) {
      if (bonus.hasSmartFactory) {
        const isSmartRelevant = policy.name.includes('스마트') || policy.name.includes('혁신') || policy.name.includes('소공인') || policy.name.includes('제조');
        const basePts = isSmartRelevant ? (tunedWeights.smartFactoryBasePoints + tunedWeights.smartFactorySpecializedBonus) : tunedWeights.smartFactoryBasePoints;
        const catMultiplier = isSmartRelevant ? (multipliers.manufacturing || 1.2) : 1.0;
        const smartPoints = Math.round(basePts * catMultiplier * globalSens);
        score += smartPoints;
        reasons.push(`🏭 스마트공장·공방 도입 우대 가점 적용 (+${smartPoints}점)`);
      }
      if (bonus.hasCarbonNeutrality) {
        const isEsgRelevant = policy.name.includes('탄소') || policy.name.includes('ESG') || policy.name.includes('녹색') || policy.name.includes('친환경');
        const catMultiplier = isEsgRelevant ? (multipliers.esgGreen || 1.2) : 1.0;
        const carbonPoints = Math.round(tunedWeights.carbonNeutralityPoints * catMultiplier * globalSens);
        score += carbonPoints;
        reasons.push(`🌿 ESG 탄소중립 실천 우대 가점 적용 (+${carbonPoints}점)`);
      }
      if (bonus.hasJobCreation) {
        const isYouthRelevant = policy.name.includes('청년') || policy.name.includes('일자리') || policy.name.includes('고용');
        const catMultiplier = isYouthRelevant ? (multipliers.youthEmployment || 1.2) : 1.0;
        const jobPoints = Math.round(tunedWeights.jobCreationPoints * catMultiplier * globalSens);
        score += jobPoints;
        reasons.push(`👥 일자리 창출 우수기업 가점 적용 (+${jobPoints}점)`);
      }
      if (bonus.hasVentureOrInnoBiz) {
        const isTechRelevant = policy.name.includes('기술') || policy.name.includes('벤처') || policy.name.includes('특허') || policy.agency?.includes('기술보증기금');
        const catMultiplier = isTechRelevant ? (multipliers.techVenture || 1.2) : 1.0;
        const techPoints = Math.round(tunedWeights.ventureInnoBizPoints * catMultiplier * globalSens);
        score += techPoints;
        reasons.push(`💡 벤처·이노비즈·특허 기술혁신 가점 적용 (+${techPoints}점)`);
      }
      if (bonus.hasCreditEducation) {
        const eduPoints = Math.round(tunedWeights.creditEducationPoints * globalSens);
        score += eduPoints;
        reasons.push(`🎓 신용관리 사전교육 이수 가점 적용 (+${eduPoints}점)`);
      }
    }

    scored.push({ ...policy, matchScore: Math.min(100, Math.max(10, score)), matchReasons: reasons });
  }

  // Sort by highest score first
  return scored.sort((a, b) => b.matchScore - a.matchScore);
};
