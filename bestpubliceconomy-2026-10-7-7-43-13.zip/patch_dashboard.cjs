const fs = require('fs');
let code = fs.readFileSync('components/PersonalDashboard.tsx', 'utf8');

code = code.replace(
  "const [activeDashboardTab, setActiveDashboardTab] = useState<'ALL' | 'SCRAPS' | 'CONSULTATIONS' | 'CHAT' | 'RADAR' | 'TRACKER' | 'TOOLS'>('ALL');",
  "const [activeDashboardTab, setActiveDashboardTab] = useState<'ALL' | 'QUICK_CHECK' | 'SCRAPS' | 'CONSULTATIONS' | 'CHAT' | 'RADAR' | 'TRACKER' | 'TOOLS'>('ALL');"
);

const targetImport = "import {";
const addImport = "import { Zap, HelpCircle, Activity } from 'lucide-react';\nimport {";
code = code.replace(targetImport, addImport);

const targetTabButton = `        <button
          type="button"
          onClick={() => setActiveDashboardTab('ALL')}
          className={\`px-4 py-2.5 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer flex items-center gap-1.5 \${
            activeDashboardTab === 'ALL'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }\`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>전체 모아보기</span>
        </button>`;
const addTabButton = targetTabButton + `
        <button
          type="button"
          onClick={() => setActiveDashboardTab('QUICK_CHECK')}
          className={\`px-4 py-2.5 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer flex items-center gap-1.5 \${
            activeDashboardTab === 'QUICK_CHECK'
              ? 'bg-rose-500 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }\`}
        >
          <Zap className="w-3.5 h-3.5" />
          <span>Quick Check (사전진단)</span>
        </button>`;
code = code.replace(targetTabButton, addTabButton);

// We'll need a state for QuickCheck in PersonalDashboard
const targetState = "const [activeChecklistFundTitle, setActiveChecklistFundTitle] = useState<string>('');";
const addState = targetState + `
  const [quickCheckAnswers, setQuickCheckAnswers] = useState({
    businessType: '개인사업자',
    operatingYears: '1-3',
    creditScore: '700-799',
    revenue: '30-100'
  });
  const [quickCheckResult, setQuickCheckResult] = useState<any>(null);

  const handleQuickCheckSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let score = 50; // base score
    if (quickCheckAnswers.operatingYears === '0-1') score += 20; // Good for startup funds
    else if (quickCheckAnswers.operatingYears === '1-3') score += 10;
    
    if (quickCheckAnswers.creditScore === '>900') score += 20;
    else if (quickCheckAnswers.creditScore === '800-899') score += 15;
    else if (quickCheckAnswers.creditScore === '700-799') score += 5;
    else if (quickCheckAnswers.creditScore === '<700') score -= 10;
    
    if (quickCheckAnswers.revenue === '>300') score += 10;
    else if (quickCheckAnswers.revenue === '100-300') score += 5;
    
    const eligibilityScore = Math.min(100, Math.max(0, score));
    setQuickCheckResult({
      score: eligibilityScore,
      message: eligibilityScore >= 80 ? '인기 정책자금 승인 확률이 매우 높습니다! 정밀 진단을 받아보세요.' : 
               eligibilityScore >= 60 ? '조건에 맞는 몇 가지 유망한 정책자금이 있습니다.' : 
               '현재는 특정 신용회복 자금 등 제한적인 지원이 가능할 수 있습니다.'
    });
  };
`;
code = code.replace(targetState, addState);

const targetRender = `      {/* If CONSULTATIONS Tab is active, show only ConsultationInquiryHistory */}`;
const addRender = `      {/* QUICK CHECK TAB */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'QUICK_CHECK') && (
        <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-slate-100 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-900">Quick Check (사전 1분 진단)</h2>
              <p className="text-xs font-bold text-slate-500">본격적인 프로필 작성 전, 주요 항목만으로 인기 정책자금 승인 가능성을 가늠해보세요.</p>
            </div>
          </div>
          
          <form onSubmit={handleQuickCheckSubmit} className="space-y-4 bg-slate-50 p-6 rounded-2xl border border-slate-100">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">사업자 형태</label>
                <select 
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium"
                  value={quickCheckAnswers.businessType}
                  onChange={e => setQuickCheckAnswers(prev => ({...prev, businessType: e.target.value}))}
                >
                  <option value="개인사업자">개인사업자</option>
                  <option value="법인사업자">법인사업자</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">업력 (영업 기간)</label>
                <select 
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium"
                  value={quickCheckAnswers.operatingYears}
                  onChange={e => setQuickCheckAnswers(prev => ({...prev, operatingYears: e.target.value}))}
                >
                  <option value="0-1">1년 미만 (예비/초기창업)</option>
                  <option value="1-3">1년 ~ 3년</option>
                  <option value="3-7">3년 ~ 7년</option>
                  <option value=">7">7년 초과</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">신용 점수 (추정)</label>
                <select 
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium"
                  value={quickCheckAnswers.creditScore}
                  onChange={e => setQuickCheckAnswers(prev => ({...prev, creditScore: e.target.value}))}
                >
                  <option value=">900">900점 이상 (우수)</option>
                  <option value="800-899">800점대 (양호)</option>
                  <option value="700-799">700점대 (보통)</option>
                  <option value="<700">700점 미만 (취약)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">연간 예상 매출</label>
                <select 
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium"
                  value={quickCheckAnswers.revenue}
                  onChange={e => setQuickCheckAnswers(prev => ({...prev, revenue: e.target.value}))}
                >
                  <option value="<30">3천만원 미만</option>
                  <option value="30-100">3천만원 ~ 1억원</option>
                  <option value="100-300">1억원 ~ 3억원</option>
                  <option value=">300">3억원 이상</option>
                </select>
              </div>
            </div>
            <div className="flex justify-end pt-2">
              <button 
                type="submit"
                className="px-6 py-3 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-xl text-sm transition-colors flex items-center gap-2"
              >
                <Activity className="w-4 h-4" /> 진단 점수 확인하기
              </button>
            </div>
          </form>

          {quickCheckResult && (
            <div className="mt-6 p-6 rounded-2xl border bg-white animate-fade-in flex items-center gap-6"
                 style={{ borderColor: quickCheckResult.score >= 80 ? '#10b981' : quickCheckResult.score >= 60 ? '#f59e0b' : '#ef4444' }}>
              <div className="flex-shrink-0 text-center">
                <div className="text-4xl font-black" style={{ color: quickCheckResult.score >= 80 ? '#10b981' : quickCheckResult.score >= 60 ? '#f59e0b' : '#ef4444' }}>
                  {quickCheckResult.score}점
                </div>
                <div className="text-xs font-bold text-slate-500 mt-1">사전 적합도</div>
              </div>
              <div>
                <p className="text-sm font-bold text-slate-800 leading-relaxed mb-2">
                  {quickCheckResult.message}
                </p>
                <button 
                  onClick={onNavigateToMatch}
                  className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 bg-indigo-50 px-3 py-1.5 rounded-lg transition-colors"
                >
                  정밀 분석(매칭) 시작하기 <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}
` + targetRender;
code = code.replace(targetRender, addRender);

fs.writeFileSync('components/PersonalDashboard.tsx', code);
