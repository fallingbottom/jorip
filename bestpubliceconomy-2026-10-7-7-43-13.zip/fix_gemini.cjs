const fs = require('fs');

const origCode = fs.readFileSync('services/geminiService.ts', 'utf8');

// The file got completely mangled from line 37. Let's rebuild the missing functions.
// We need extractCrmBusinessInfoFromImage, extractBusinessInfoFromImage, extractBusinessInfoFromText
// And then the proper analyzePolicyMatching

const restoredFunctions = `
export const extractBusinessInfoFromImage = async (file: File): Promise<Partial<UserProfile>> => {
  const ai = new GoogleGenAI({ apiKey: getApiKey() });
  const base64Data = await fileToBase64(file);
  const base64String = base64Data.split(',')[1] || base64Data;

  const prompt = \`
    You are an expert at extracting business information from Korean business registration certificates (사업자등록증).
    Extract the following information and return it as JSON:
    - name (대표자)
    - businessName (상호)
    - businessRegistrationNumber (등록번호)
    - businessAddress (사업장 소재지)
    - businessType (INDIVIDUAL for 개인사업자, CORPORATION for 법인사업자)
    - industry (Choose one: MANUFACTURING, IT_SOFTWARE, RETAIL, SERVICE, RESTAURANT, OTHER based on 업태/종목)
    - foundedYear (개업연월일 YYYY)
  \`;

  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      name: { type: Type.STRING },
      businessName: { type: Type.STRING },
      businessRegistrationNumber: { type: Type.STRING },
      businessAddress: { type: Type.STRING },
      businessType: { type: Type.STRING },
      industry: { type: Type.STRING },
      foundedYear: { type: Type.STRING },
    }
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: [
        prompt,
        { inlineData: { data: base64String, mimeType: file.type } }
      ],
      config: {
        responseMimeType: 'application/json',
        responseSchema: schema,
        temperature: 0.1
      }
    });
    
    if (response.text) {
      return JSON.parse(response.text);
    }
    return {};
  } catch (error) {
    console.error('Error extracting info from image:', error);
    return {};
  }
};

export const extractBusinessInfoFromText = async (text: string): Promise<Partial<UserProfile>> => {
  const ai = new GoogleGenAI({ apiKey: getApiKey() });
  const prompt = \`
    You are an expert at extracting business information from raw text.
    Extract the following information and return it as JSON:
    - name (대표자)
    - businessName (상호)
    - businessRegistrationNumber (등록번호)
    - businessAddress (사업장 소재지)
    - businessType (INDIVIDUAL for 개인사업자, CORPORATION for 법인사업자)
    - industry (Choose one: MANUFACTURING, IT_SOFTWARE, RETAIL, SERVICE, RESTAURANT, OTHER based on 업태/종목)
    - foundedYear (개업연월일 YYYY)

    Source text:
    \${text}
  \`;

  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      name: { type: Type.STRING },
      businessName: { type: Type.STRING },
      businessRegistrationNumber: { type: Type.STRING },
      businessAddress: { type: Type.STRING },
      businessType: { type: Type.STRING },
      industry: { type: Type.STRING },
      foundedYear: { type: Type.STRING },
    }
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: schema,
        temperature: 0.1
      }
    });
    
    if (response.text) {
      return JSON.parse(response.text);
    }
    return {};
  } catch (error) {
    console.error('Error extracting info from text:', error);
    return {};
  }
};

export const extractCrmBusinessInfoFromImage = async (file: File): Promise<Partial<any>> => {
  const ai = new GoogleGenAI({ apiKey: getApiKey() });
  const base64Data = await fileToBase64(file);
  const base64String = base64Data.split(',')[1] || base64Data;
  const prompt = \`
    You are an expert at extracting business information from Korean business registration certificates (사업자등록증).
    Extract all relevant details to prepopulate a CRM entry.
  \`;
  
  const schema: Schema = {
    type: Type.OBJECT,
    properties: {
      name: { type: Type.STRING },
      businessName: { type: Type.STRING },
      businessRegistrationNumber: { type: Type.STRING },
      businessAddress: { type: Type.STRING },
      businessType: { type: Type.STRING },
      industry: { type: Type.STRING },
      foundedYear: { type: Type.STRING },
    }
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: [
        prompt,
        { inlineData: { data: base64String, mimeType: file.type } }
      ],
      config: {
        responseMimeType: 'application/json',
        responseSchema: schema,
        temperature: 0.1
      }
    });
    
    if (response.text) {
      return JSON.parse(response.text);
    }
    return {};
  } catch (error) {
    console.error('Error extracting info from image:', error);
    return {};
  }
};

export const analyzePolicyMatching = async (
  profile: UserProfile, 
  latestPolicies: SourcePolicy[], 
  feedback?: ReanalysisFeedback
): Promise<AnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: getApiKey() });

  // 1. Run strict rule-based filtering and scoring
  const scoredPolicies = filterAndScorePolicies(profile, latestPolicies);
  const topMatches = scoredPolicies.filter(p => p.matchScore >= 50).slice(0, 5); // Take top 5 eligible

  // 2. Create a context string from the real-time policy data AND their algorithmic scores
  const policyContext = topMatches.map(p => 
    \`- \${p.name} (\${p.agency}):
      * Base Rate: \${p.baseInterestRate}
      * Status: \${p.currentStatus}
      * Budget Exhaustion: \${p.budgetExhaustionRate || 0}%
      * Algorithmic Match Score: \${p.matchScore}/100
      * Algorithmic Match Reasons: \${p.matchReasons.join(', ')}
      * Eligibility: \${p.eligibility || 'N/A'}
      * Repayment: \${p.repaymentPeriod || 'N/A'}
      * Max Amount: \${p.maxAmount || 'N/A'}
      * Description: \${p.description || 'N/A'}
      * Contact: \${p.contactInfo || 'N/A'}\`
  ).join('\\n\\n');

  let feedbackPromptSection = '';
  if (feedback) {
    feedbackPromptSection = \`
    === USER FEEDBACK & RE-ANALYSIS DIRECTIVES ===
    The user was not fully satisfied with previous AI recommendations and submitted specific criteria for re-analysis:
    - Dissatisfaction Reasons: \${feedback.selectedReasons && feedback.selectedReasons.length > 0 ? feedback.selectedReasons.join(', ') : 'None specified'}
    - Excluded Funds (MUST NOT RECOMMEND THESE AGAIN): \${feedback.excludedFundIds && feedback.excludedFundIds.length > 0 ? feedback.excludedFundIds.join(', ') : 'None'}
    \${feedback.preferredInterestRateMax ? \`- Target Max Interest Rate: Under \${feedback.preferredInterestRateMax}%\` : ''}
    \${feedback.preferredFundCategory && feedback.preferredFundCategory !== 'ALL' ? \`- Preferred Funding Category: \${feedback.preferredFundCategory}\` : ''}
    \${feedback.preferredAgency && feedback.preferredAgency !== 'ALL' ? \`- Preferred Agency: \${feedback.preferredAgency}\` : ''}
    \${feedback.userCustomPrompt ? \`- User's Specific Custom Request: "\${feedback.userCustomPrompt}"\` : ''}

    STRICT RE-ANALYSIS REQUIREMENTS:
    1. NEVER recommend any fund listed in the Excluded Funds (\${feedback.excludedFundIds?.join(', ') || ''}). Replace them with better matching alternatives.
    2. Directly resolve the user's dissatisfaction reasons.
    3. In 'strategicAdvice', explicitly address the user's feedback points.
    =============================================
    \`;
  }

  const prompt = \`
    You are an expert consultant for Korean government policy funds (소상공인 정책자금).
    We have ALREADY run a strict rule-based algorithm to find the top matching policy funds for this user.
    You MUST ONLY recommend the funds listed in "Real-time Policy Data (Top Algorithmic Matches)". Do not invent or recommend funds outside of this list unless specifically requested as a fallback.
    
    When generating the 'matchingReason' for each fund, YOU MUST incorporate the 'Algorithmic Match Reasons' provided in the context, expanding on them naturally for the user. Include details like eligibility, max amount, and repayment period based on the context data.

    User Profile:
    - Business: \${profile.businessName} (\${profile.name})
    - Type: \${mapEnumToKorean(profile.businessType)}
    - Industry: \${mapEnumToKorean(profile.industry)}
    - Location: \${profile.location}
    - Revenue: \${profile.annualRevenue} KRW
    - Founded Year (Business Duration): \${profile.foundedYear}
    - Credit Score: \${profile.creditScore}
    - Employees: \${profile.employees}
    - Funding Need: \${profile.fundingNeed} KRW
    - Metrics: Profit Margin \${profile.expectedProfitMargin}%, Cash Flow Score \${profile.cashFlowStatus}
    - Debt: 1st Tier \${profile.debt1Tier}, 2nd Tier \${profile.debt2Tier}, Card/Capital \${profile.debtCardLoan}

    Real-time Policy Data (Top Algorithmic Matches):
    \${policyContext}
    \${feedbackPromptSection}
    
    Task:
    1. Calculate eligibility score (0-100) based on credit, revenue, debt ratio, and industry.
    2. Analyze business health metrics (Growth, Stability, etc.).
    3. Recommend 3-5 specific policy funds.
       - CRITICAL: If a recommended fund matches one in the "Real-time Policy Data", YOU MUST USE its 'currentStatus' (OPEN or BUDGET_ALMOST_EXHAUSTED).
       - If a fund is 'BUDGET_ALMOST_EXHAUSTED', it means the budget is running low. Still recommend it if the fit is high, but mark the status correctly.
       - Do not recommend funds that are definitively 'CLOSED'.
       - For each recommended fund, provide 'applicationProcedure' as a step-by-step array of instructions.
       - Provide 'writingGuide' as detailed, practical advice on how to write the required documents (business plan, etc.).
       - Provide start, end, and announcement dates if possible (YYYY-MM-DD).
    4. Provide strategic advice and a step-by-step action plan.
    5. Provide 'approvalFactors', a list of 4-6 factors positively or negatively impacting the approval probability (eligibilityScore). The 'impact' should be a number (e.g. +15, -10) reflecting its weight. Ensure there are both positive and negative factors if applicable, or at least point out areas for improvement.

    Output as JSON matching the schema.
  \`;
`;

// In the original file, extractCrmBusinessInfoFromImage started at line 37.
// We will replace everything from extractCrmBusinessInfoFromImage up to the end of analyzePolicyMatching's prompt and schema definition.
// Wait, I need to see exactly where to inject this. Let's find "export const extractCrmBusinessInfoFromImage" and then find where the schema of analyzePolicyMatching was.

