# 1. Add state variable
sed -i '/const \[historyAnnouncement/i \
  const [viewingOriginal, setViewingOriginal] = useState<PolicyAnnouncement | null>(null);' components/admin/AnnouncementCurationManager.tsx

# 2. Add button in the Controls column
sed -i '/title="JSON 정책 규칙 보기\/수정"/i \
                          <button\
                            type="button"\
                            onClick={(e) => { e.stopPropagation(); setViewingOriginal(item); }}\
                            className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"\
                            title="공고 원문 보기"\
                          >\
                            <Eye className="w-4 h-4" />\
                          </button>' components/admin/AnnouncementCurationManager.tsx
