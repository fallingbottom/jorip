const fs = require('fs');
let code = fs.readFileSync('components/ResultDashboard.tsx', 'utf8');
console.log(code.includes("window.print()"));
