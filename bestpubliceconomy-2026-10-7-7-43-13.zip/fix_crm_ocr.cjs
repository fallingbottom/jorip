const fs = require('fs');
let code = fs.readFileSync('services/geminiService.ts', 'utf8');

const target = `    - Address (address) - Full address
    - Business Type (businessType) - Either '개인사업자' or '법인'`;
const replacement = `    - Address (address) - Full address
    - Province (province) - Determine the major province/city from the address and map exactly to one of: '서울', '경기', '인천', '부산', '대구', '광주', '대전', '울산', '강원', '충북', '충남', '전북', '전남', '경북', '경남', '제주'. For example, if address is "경기도 안산시...", province should be "경기".
    - City (city) - Determine the specific city/district (시/군/구) from the address.
    - Business Type (businessType) - Either '개인사업자' or '법인'`;

code = code.replace(target, replacement);

const schemaTarget = `          address: { type: Type.STRING },
          businessType: { type: Type.STRING },`;
const schemaReplacement = `          address: { type: Type.STRING },
          province: { type: Type.STRING },
          city: { type: Type.STRING },
          businessType: { type: Type.STRING },`;

code = code.replace(schemaTarget, schemaReplacement);

fs.writeFileSync('services/geminiService.ts', code);
