const fs = require('fs');
let code = fs.readFileSync('components/ResultDashboard.tsx', 'utf8');

const styleTarget = `      <style>{\`
        @media print {
          body { background: white !important; margin: 0; padding: 0; }
          header, footer, .no-print { display: none !important; }
          main { padding: 0 !important; }
          .max-w-5xl { max-width: 100% !important; margin: 0 !important; width: 100% !important; }
          .bg-white { border: none !important; box-shadow: none !important; }
          .rounded-3xl, .rounded-2xl, .rounded-xl { border-radius: 0 !important; }
          .shadow-sm, .shadow-lg, .shadow-xl { box-shadow: none !important; }
          .break-inside-avoid { break-inside: avoid; }
          .animate-fade-in { animation: none !important; }
        }
      \`}</style>`;

const styleReplacement = `      <style>{\`
        .print-only { display: none !important; }
        @media print {
          @page { size: A4 portrait; margin: 15mm; }
          body { background: white !important; margin: 0; padding: 0; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          header, footer, .no-print { display: none !important; }
          main { padding: 0 !important; }
          .print-only { display: block !important; }
          .print-flex { display: flex !important; }
          .max-w-5xl { max-width: 100% !important; margin: 0 !important; width: 100% !important; }
          .bg-white { border: 1px solid #e2e8f0 !important; box-shadow: none !important; }
          .bg-slate-50 { background: #f8fafc !important; }
          .rounded-3xl, .rounded-2xl, .rounded-xl { border-radius: 8px !important; }
          .shadow-sm, .shadow-lg, .shadow-xl { box-shadow: none !important; }
          .break-inside-avoid { break-inside: avoid !important; }
          .page-break-before { page-break-before: always !important; }
          .animate-fade-in { animation: none !important; }
        }
      \`}</style>

      {/* -------------------------------------------------------------
          Print Only Cover Page (Standardized Report)
         ------------------------------------------------------------- */}
      <div className="print-only flex flex-col items-center justify-center h-[90vh] break-after-page">
        <div className="text-center w-full max-w-3xl mx-auto border-8 border-slate-900 p-16">
          <div className="mb-4 text-xl font-bold text-slate-500 tracking-[0.2em] uppercase">BizMatch AI Report</div>
          <h1 className="text-5xl font-black mb-16 text-slate-900 leading-tight">소상공인 정책자금<br/>분석 리포트</h1>
          
          <table className="w-full text-left border-collapse mt-12 text-lg">
            <tbody>
              <tr>
                <th className="py-5 border-t border-b-2 border-slate-800 w-1/3 font-bold text-slate-600 bg-slate-50 px-4">기업명 (상호)</th>
                <td className="py-5 border-t border-b-2 border-slate-800 font-black text-slate-900 px-4">{profile?.businessName || '미입력'}</td>
              </tr>
              <tr>
                <th className="py-5 border-b border-slate-300 font-bold text-slate-600 bg-slate-50 px-4">대표자명</th>
                <td className="py-5 border-b border-slate-300 font-bold text-slate-900 px-4">{profile?.name || '미입력'}</td>
              </tr>
              <tr>
                <th className="py-5 border-b border-slate-300 font-bold text-slate-600 bg-slate-50 px-4">사업자등록번호</th>
                <td className="py-5 border-b border-slate-300 font-bold text-slate-900 px-4">{profile?.businessRegistrationNumber || '미입력'}</td>
              </tr>
              <tr>
                <th className="py-5 border-b border-slate-300 font-bold text-slate-600 bg-slate-50 px-4">주요 업종</th>
                <td className="py-5 border-b border-slate-300 font-bold text-slate-900 px-4">{profile?.industry || '미입력'}</td>
              </tr>
              <tr>
                <th className="py-5 border-b border-slate-300 font-bold text-slate-600 bg-slate-50 px-4">발급 일자</th>
                <td className="py-5 border-b border-slate-300 font-bold text-slate-900 px-4">{new Date().toLocaleDateString('ko-KR')}</td>
              </tr>
            </tbody>
          </table>
          
          <div className="mt-24 text-slate-500 text-sm leading-relaxed text-left">
            <p>※ 본 리포트는 실시간 정책자금 데이터 및 기업 진단 정보를 바탕으로 AI가 분석하여 자동 생성한 표준화된 보고서입니다.</p>
            <p>※ 대출 및 보증 심사 시 보조 참고 자료로 활용하실 수 있으며, 최종 승인 여부는 각 금융기관의 개별 심사 기준에 따릅니다.</p>
          </div>
        </div>
      </div>`;

code = code.replace(styleTarget, styleReplacement);
fs.writeFileSync('components/ResultDashboard.tsx', code);
