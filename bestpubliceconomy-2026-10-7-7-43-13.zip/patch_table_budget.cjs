const fs = require('fs');
let code = fs.readFileSync('components/PolicyFundComparisonTable.tsx', 'utf8');

const target = `                              {fund.currentStatus === 'BUDGET_ALMOST_EXHAUSTED' && (
                                <span className="px-2 py-0.5 bg-red-100 text-red-700 font-black rounded text-[10px]">
                                  예산 소진 임박
                                </span>
                              )}`;
                              
const replacement = `                              {(fund.currentStatus === 'BUDGET_ALMOST_EXHAUSTED' || (fund.budgetExhaustionRate && fund.budgetExhaustionRate >= 80)) && (
                                <span className="px-2 py-0.5 bg-red-100 text-red-700 font-black rounded text-[10px] animate-pulse">
                                  예산 소진 임박 {fund.budgetExhaustionRate ? \`(\${fund.budgetExhaustionRate}%)\` : ''}
                                </span>
                              )}`;

code = code.replace(target, replacement);
fs.writeFileSync('components/PolicyFundComparisonTable.tsx', code);
