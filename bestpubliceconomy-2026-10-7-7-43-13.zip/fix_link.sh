cat << 'INNER_EOF' > replace.txt
                        <div className="flex items-center justify-end gap-1.5">
                          {item.sourceUrl && (
                            <a
                              href={item.sourceUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="p-1.5 text-slate-400 hover:text-cyan-600 hover:bg-cyan-50 rounded-lg transition-colors"
                              title="공고 웹페이지 바로가기"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </a>
                          )}
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); setViewingOriginal(item); }}
                            className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                            title="공고 원문 보기"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
INNER_EOF

sed -i '1095,1114d' components/admin/AnnouncementCurationManager.tsx
sed -i '1094r replace.txt' components/admin/AnnouncementCurationManager.tsx
