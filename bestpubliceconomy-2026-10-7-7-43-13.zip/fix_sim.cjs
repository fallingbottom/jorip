const fs = require('fs');
let code = fs.readFileSync('components/admin/CustomerDetail.tsx', 'utf8');

const target = `<ResultDashboard 
                        result={simResult} 
                        onReset={() => setSimResult(null)}
                      />`;
const replacement = `<ResultDashboard 
                        result={simResult} 
                        onReset={() => setSimResult(null)}
                        profile={{
                          name: customer?.ceoName || '고객',
                          businessName: customer?.businessName || '사업장',
                          businessRegistrationNumber: '',
                          businessAddress: customer?.address || '',
                          businessType: customer?.businessType === '법인' ? BusinessType.CORPORATION : BusinessType.INDIVIDUAL,
                          industry: Industry.SERVICE,
                          location: customer?.province || '전국',
                          foundedYear: customer?.openDate ? customer.openDate.split('-')[0] : new Date().getFullYear().toString(),
                          annualRevenue: simRevenue,
                          creditScore: simCredit,
                          employees: customer?.employeeCount || 0,
                          fundingNeed: 50000000,
                          expectedProfitMargin: 15,
                          cashFlowStatus: 70,
                          debt1Tier: 0,
                          debt2Tier: 0,
                          debtCardLoan: 0,
                          debtOther: 0,
                          isMyDataLinked: true
                        }}
                      />`;
code = code.replace(target, replacement);

fs.writeFileSync('components/admin/CustomerDetail.tsx', code);
