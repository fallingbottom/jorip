export type ProgramCode = 'CCRS_FAST' | 'CCRS_PRE' | 'CCRS_WORKOUT' | 'NEW_START_FUND' | 'DIRECT_CREDITOR_ADJUSTMENT';

export type ScreeningStatus = 'CANDIDATE' | 'BLOCKED_BY_OFFICIAL_RULE' | 'VERIFY_REQUIRED' | 'OUT_OF_SCOPE' | 'HANDOFF';

export interface DebtReliefInput {
  isBusiness: boolean;
  isClosedBusiness: boolean;
  daysPastDue: number;
  unsecuredDebtAmount: number;
  securedDebtAmount: number;
  recentDebtRatioOver30: boolean | null; // null means unknown
}

export interface ScreeningResult {
  programCode: ProgramCode;
  programName: string;
  status: ScreeningStatus;
  reasons: string[];
  missingInformation: string[];
  agencyName: string;
}
