const fs = require('fs');
let code = fs.readFileSync('components/ResultDashboard.tsx', 'utf8');

// Import
code = code.replace(
  "import { FundPdfChecklistModal } from './FundPdfChecklistModal';",
  "import { FundPdfChecklistModal } from './FundPdfChecklistModal';\nimport { FundApplicationGuideModal } from './FundApplicationGuideModal';"
);

// Props for FundCard
code = code.replace(
  "  onOpenPdfChecklist?: (fund: PolicyFund) => void;",
  "  onOpenPdfChecklist?: (fund: PolicyFund) => void;\n  onOpenApplicationGuide?: (fund: PolicyFund) => void;"
);

// Arguments for FundCard
code = code.replace(
  "  onOpenPdfChecklist, onConfigurePush, onOpenConsultation, onOpenDeepLearningReport, onOpenFormsModal, profile }) => {",
  "  onOpenPdfChecklist, onOpenApplicationGuide, onConfigurePush, onOpenConsultation, onOpenDeepLearningReport, onOpenFormsModal, profile }) => {"
);

// Button in FundCard
const buttonTarget = `              {onOpenPdfChecklist && !isPrinting && (
                <button
                  type="button"
                  onClick={() => onOpenPdfChecklist(fund)}
                  className="text-xs font-bold border border-blue-200 bg-blue-50/80 hover:bg-blue-100 text-blue-700 rounded-xl px-2.5 py-1.5 flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs hover:shadow"
                  title="공고문 원문 PDF 분석 및 핵심 체크리스트 보기"
                >
                  <FileCheck2 className="w-3.5 h-3.5 text-blue-600" />
                  <span>PDF 체크리스트</span>
                </button>
              )}`;

const buttonReplacement = `              {onOpenPdfChecklist && !isPrinting && (
                <button
                  type="button"
                  onClick={() => onOpenPdfChecklist(fund)}
                  className="text-xs font-bold border border-blue-200 bg-blue-50/80 hover:bg-blue-100 text-blue-700 rounded-xl px-2.5 py-1.5 flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs hover:shadow"
                  title="공고문 원문 PDF 분석 및 핵심 체크리스트 보기"
                >
                  <FileCheck2 className="w-3.5 h-3.5 text-blue-600" />
                  <span>PDF 체크리스트</span>
                </button>
              )}
              {onOpenApplicationGuide && !isPrinting && (
                <button
                  type="button"
                  onClick={() => onOpenApplicationGuide(fund)}
                  className="text-xs font-bold border border-emerald-200 bg-emerald-50/80 hover:bg-emerald-100 text-emerald-700 rounded-xl px-2.5 py-1.5 flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs hover:shadow"
                  title="해당 자금의 상세 신청 절차 및 필수 구비 서류 확인"
                >
                  <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                  <span>신청 가이드</span>
                </button>
              )}`;

code = code.replace(buttonTarget, buttonReplacement);

fs.writeFileSync('components/ResultDashboard.tsx', code);
