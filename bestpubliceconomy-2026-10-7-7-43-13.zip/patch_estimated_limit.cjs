const fs = require('fs');
let code = fs.readFileSync('components/ResultDashboard.tsx', 'utf8');

const calcFunc = `
// 매출과 업종 기반으로 대략적인 예상 대출 한도 계산 (만원 단위 이하 절사)
const calculateEstimatedLoanLimit = (profile: UserProfile | null | undefined, fundMaxAmountStr: string): number | null => {
  if (!profile || !profile.annualRevenue) return null;
  
  const fundMax = parseKoreanAmount(fundMaxAmountStr);
  const revenue = profile.annualRevenue;
  
  let ratio = 0.3; // Default 30%
  switch(profile.industry) {
    case Industry.MANUFACTURING: ratio = 0.5; break;
    case Industry.IT_SOFTWARE: ratio = 0.4; break;
    case Industry.RETAIL: ratio = 0.3; break;
    case Industry.RESTAURANT: ratio = 0.25; break;
    case Industry.SERVICE: ratio = 0.25; break;
    default: ratio = 0.2; break;
  }
  
  let estimatedLimit = Math.floor(revenue * ratio);
  
  // 최소 1,000만원 보장
  if (estimatedLimit < 10000000) {
    estimatedLimit = 10000000;
  }
  
  // 상품의 최대 한도를 초과할 수 없음
  if (fundMax > 0 && estimatedLimit > fundMax) {
    estimatedLimit = fundMax;
  }
  
  // 100만원 단위 절사
  return Math.floor(estimatedLimit / 1000000) * 1000000;
};

// 숫자 금액을 한국어 단위로 포맷팅 (예: 50000000 -> 5,000만원)
const formatAmountKRW = (amount: number): string => {
  if (amount === 0) return '0원';
  if (amount >= 100000000) {
    const uk = Math.floor(amount / 100000000);
    const man = Math.floor((amount % 100000000) / 10000);
    return \`\${uk}억\${man > 0 ? ' ' + man.toLocaleString() + '만' : ''}원\`;
  }
  if (amount >= 10000) {
    const man = Math.floor(amount / 10000);
    return \`\${man.toLocaleString()}만원\`;
  }
  return \`\${amount.toLocaleString()}원\`;
};
`;

code = code.replace(
  "const FundCard: React.FC<{",
  calcFunc + "\nconst FundCard: React.FC<{"
);

// Add the estimated limit inside the card
const targetUI = `<div className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-1">최대 한도</div>
              <div className="text-xl font-black text-slate-900">{fund.maxAmount}</div>`;

const replacementUI = `<div className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-1">정책 최대 한도</div>
              <div className="text-xl font-black text-slate-900 line-through text-slate-400 decoration-slate-300 text-sm">{fund.maxAmount}</div>
              {(() => {
                const estLimit = calculateEstimatedLoanLimit(profile, fund.maxAmount);
                if (estLimit !== null) {
                  return (
                    <div className="mt-1">
                      <div className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded inline-block mb-0.5">내 사업장 예상 한도</div>
                      <div className="text-xl font-black text-emerald-700">{formatAmountKRW(estLimit)}</div>
                    </div>
                  );
                }
                return <div className="text-xl font-black text-slate-900">{fund.maxAmount}</div>;
              })()}
              `;

code = code.replace(targetUI, replacementUI);

fs.writeFileSync('components/ResultDashboard.tsx', code);
