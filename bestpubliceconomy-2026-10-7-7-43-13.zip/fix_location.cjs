const fs = require('fs');
let code = fs.readFileSync('services/geminiService.ts', 'utf8');

code = code.replace(
"          businessAddress: { type: Type.STRING },\n          foundedYear: { type: Type.STRING },\n          location: { type: Type.STRING },\n          location: { type: Type.STRING },",
"          businessAddress: { type: Type.STRING },\n          foundedYear: { type: Type.STRING },\n          location: { type: Type.STRING },"
);

code = code.replace(
"          businessAddress: { type: Type.STRING },\n          foundedYear: { type: Type.STRING },\n        }",
"          businessAddress: { type: Type.STRING },\n          foundedYear: { type: Type.STRING },\n          location: { type: Type.STRING },\n        }"
);

fs.writeFileSync('services/geminiService.ts', code);
