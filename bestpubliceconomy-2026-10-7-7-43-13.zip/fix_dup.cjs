const fs = require('fs');
let code = fs.readFileSync('components/PersonalDashboard.tsx', 'utf8');

const target = `      {/* OCR Business License Scanner (Shown when ALL or TOOLS) */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'TOOLS') && (
        <BusinessLicenseParser />
      )}
      
      {/* OCR Business License Scanner (Shown when ALL or TOOLS) */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'TOOLS') && (
        <BusinessLicenseParser />
      )}`;

const replacement = `      {/* OCR Business License Scanner (Shown when ALL or TOOLS) */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'TOOLS') && (
        <BusinessLicenseParser />
      )}`;

code = code.replace(target, replacement);
fs.writeFileSync('components/PersonalDashboard.tsx', code);
