const fs = require('fs');
let code = fs.readFileSync('components/ResultDashboard.tsx', 'utf8');

const targetStyle = `          .page-break-before { page-break-before: always !important; }
          .animate-fade-in { animation: none !important; }
        }
      \`}</style>`;

const newStyle = `          .page-break-before { page-break-before: always !important; }
          .animate-fade-in { animation: none !important; }
          
          /* Hide non-essential dashboard elements for a clean report */
          .dashboard-interactive-header { display: none !important; }
          .report-only-header { display: block !important; margin-bottom: 20px; border-bottom: 2px solid #000; padding-bottom: 10px; }
          
        }
        .report-only-header { display: none; }
      \`}</style>`;

code = code.replace(targetStyle, newStyle);

fs.writeFileSync('components/ResultDashboard.tsx', code);
