const fs = require('fs');
let code = fs.readFileSync('components/ResultDashboard.tsx', 'utf8');

// Change data slice to 3
code = code.replace(
  'filteredFunds.slice(0, 5).map(fund => {',
  'filteredFunds.slice(0, 3).map(fund => {'
);

// Change title
code = code.replace(
  '상위 추천 자금 핵심 조건 비교 (Top 5)',
  '상위 추천 자금 핵심 조건 비교 (Top 3)'
);

// Remove the third Bar for "상환기간"
const barToRemove = `                      <Bar yAxisId="left" dataKey="repaymentPeriod" name="상환기간" fill="#10b981" radius={[4, 4, 0, 0]} barSize={20} />`;
code = code.replace(barToRemove + '\\n', '');
code = code.replace(barToRemove, '');

fs.writeFileSync('components/ResultDashboard.tsx', code);
