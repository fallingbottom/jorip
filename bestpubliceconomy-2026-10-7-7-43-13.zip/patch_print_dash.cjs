const fs = require('fs');
let code = fs.readFileSync('components/PersonalDashboard.tsx', 'utf8');

code = code.replace(
  '{/* Dashboard Sub-Tab Navigation Bar */}\n      <div className="bg-white p-2 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-1.5 overflow-x-auto no-scrollbar">',
  '{/* Dashboard Sub-Tab Navigation Bar */}\n      <div className="bg-white p-2 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-1.5 overflow-x-auto no-scrollbar print:hidden">'
);

const chartHeaderTarget = `            <div className="flex items-center gap-2 mb-6">
              <Activity className="w-5 h-5 text-blue-600" />
              <h2 className="text-lg font-black text-slate-900">정책 상품 비교 그래프 (한도 vs 금리)</h2>
            </div>`;
            
const chartHeaderReplacement = `            <div className="flex items-center justify-between gap-4 mb-6">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-blue-600" />
                <h2 className="text-lg font-black text-slate-900">정책 상품 비교 그래프 (한도 vs 금리)</h2>
              </div>
              <button
                onClick={() => window.print()}
                className="print:hidden px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-all shadow-md active:scale-95 shrink-0"
                title="현재 화면을 PDF로 저장하거나 인쇄합니다"
              >
                <FileText className="w-4 h-4" />
                <span>PDF 저장 / 인쇄</span>
              </button>
            </div>`;
            
code = code.replace(chartHeaderTarget, chartHeaderReplacement);

const listHeaderTarget = `        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
            <h2 className="text-xl font-black text-slate-900">즐겨찾기한 정책자금 목록</h2>`;

const listHeaderReplacement = `        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center justify-between w-full sm:w-auto">
            <div className="flex items-center gap-2">
              <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
              <h2 className="text-xl font-black text-slate-900">즐겨찾기한 정책자금 목록</h2>
              <span className="text-xs font-extrabold bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full">
                {filteredFavorites.length}건
              </span>
            </div>
            
            <button
              onClick={() => window.print()}
              className="sm:hidden print:hidden p-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors"
            >
              <FileText className="w-4 h-4" />
            </button>
          </div>`;
          
code = code.replace(listHeaderTarget, listHeaderReplacement);

const listHeaderDuplicateTarget = `            <span className="text-xs font-extrabold bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full">
              {filteredFavorites.length}건
            </span>
          </div>

          <div className="relative w-full sm:w-64">`;

const listHeaderDuplicateReplacement = `          </div>

          <div className="relative w-full sm:w-64 print:hidden">`;

code = code.replace(listHeaderDuplicateTarget, listHeaderDuplicateReplacement);

code = code.replace(
  'className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1"',
  'className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1 print:hidden"'
);
code = code.replace(
  'className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1"',
  'className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1 print:hidden"'
); // There might be multiple

code = code.replaceAll(
  '<button\n                        onClick={() => setSelectedFund(fund)}\n                        className="mt-4 w-full px-4 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-sm font-black transition-all shadow-md active:scale-95 flex justify-center items-center gap-2"',
  '<button\n                        onClick={() => setSelectedFund(fund)}\n                        className="print:hidden mt-4 w-full px-4 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-sm font-black transition-all shadow-md active:scale-95 flex justify-center items-center gap-2"'
);

fs.writeFileSync('components/PersonalDashboard.tsx', code);
