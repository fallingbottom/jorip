const fs = require('fs');
let code = fs.readFileSync('components/ResultDashboard.tsx', 'utf8');

const target = `{/* -------------------------------------------------------------
          Print Only Cover Page (Standardized Report)
         ------------------------------------------------------------- */}`;

console.log(code.includes(target));
