const fs = require('fs');
let code = fs.readFileSync('components/PersonalDashboard.tsx', 'utf8');

// I will just replace the exact broken section with a correct one.
const brokenCode = `            <button
              onClick={() => window.print()}
              className="sm:hidden print:hidden p-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors"
            >
              <FileText className="w-4 h-4" />
            </button>
          </div>
          </div>

          <div className="relative w-full sm:w-64 print:hidden">`;

const fixedCode = `            <button
              onClick={() => window.print()}
              className="sm:hidden print:hidden p-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors"
            >
              <FileText className="w-4 h-4" />
            </button>
          </div>

          <div className="relative w-full sm:w-64 print:hidden">`;

code = code.replace(brokenCode, fixedCode);
fs.writeFileSync('components/PersonalDashboard.tsx', code);
