
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { UserProfile, BusinessType, Industry, PolicyApplicationHistory } from '../types';
import { 
  ArrowRight, 
  ArrowLeft,
  Building, 
  DollarSign, 
  MapPin, 
  User, 
  Wallet, 
  Upload, 
  Loader2, 
  FileText, 
  CheckCircle, 
  AlertCircle, 
  Camera, 
  Trash2, 
  TrendingUp, 
  Activity,
  Percent,
  Coins,
  ShieldAlert,
  CreditCard,
  Banknote,
  Link,
  ShieldCheck,
  Lock,
  Sparkles,
  ChevronRight,
  CloudOff,
  History,
  Plus,
  AlertTriangle,
  Leaf,
  Cpu,
  Award,
  Factory,
  Users
} from 'lucide-react';
import { extractBusinessInfoFromImage, extractBusinessInfoFromText } from '../services/geminiService';
import { connectMyData } from '../services/myDataService';
import { fetchDriveFiles, downloadDriveFileText, DriveFile } from '../services/workspaceService';

interface StepWizardProps {
  onComplete: (profile: UserProfile) => void;
  isLoading: boolean;
  token?: string | null;
}

const initialProfile: UserProfile = {
  name: '',
  businessName: '',
  businessRegistrationNumber: '',
  businessAddress: '',
  businessType: BusinessType.INDIVIDUAL,
  industry: Industry.RESTAURANT,
  location: '서울',
  foundedYear: new Date().getFullYear().toString(),
  annualRevenue: 0,
  creditScore: 750,
  employees: 0,
  fundingNeed: 30000000,
  expectedProfitMargin: 15,
  cashFlowStatus: 70,
  debt1Tier: 0,
  debt2Tier: 0,
  debtCardLoan: 0,
  debtOther: 0,
  debtRatio: 0,
  hasTaxArrears: false,
  hasOverdue: false,
  applicationHistories: [],
  isMyDataLinked: false,
  policyBonusFactors: {
    hasSmartFactory: false,
    hasCarbonNeutrality: false,
    hasJobCreation: false,
    hasVentureOrInnoBiz: false,
    hasCreditEducation: false,
    smartFactoryLevel: 'NONE',
    carbonCertType: 'NONE'
  }
};

export const StepWizard: React.FC<StepWizardProps> = ({ onComplete, isLoading, token }) => {
  const [step, setStep] = useState(1);
  const [profile, setProfile] = useState<UserProfile>(initialProfile);
  const [isAnalyzingImage, setIsAnalyzingImage] = useState(false);
  const [isConnectingMyData, setIsConnectingMyData] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<{ type: 'success' | 'error' | null, message: string }>({ type: null, message: '' });
  const [highlightedFields, setHighlightedFields] = useState<Set<string>>(new Set());

  // Google Drive integration states
  const [isGoogleSyncDisabled, setIsGoogleSyncDisabled] = useState(true);
  const [isDriveModalOpen, setIsDriveModalOpen] = useState(false);
  const [driveFiles, setDriveFiles] = useState<DriveFile[]>([]);
  const [isFetchingDrive, setIsFetchingDrive] = useState(false);
  const [driveSearch, setDriveSearch] = useState('');
  const [isAnalyzingDriveFile, setIsAnalyzingDriveFile] = useState(false);

  // Load drive files whenever modal is opened
  const loadDriveFiles = async (search: string = '') => {
    if (!token) return;
    setIsFetchingDrive(true);
    try {
      const files = await fetchDriveFiles(token, search);
      setDriveFiles(files);
    } catch (err) {
      console.error(err);
      setUploadStatus({ type: 'error', message: '구글 드라이브 파일을 가져오지 못했습니다.' });
    } finally {
      setIsFetchingDrive(false);
    }
  };

  const handleOpenDrivePicker = () => {
    if (isGoogleSyncDisabled) {
      setUploadStatus({ type: 'error', message: '구글 동기화가 비활성화되어 있습니다.' });
      return;
    }
    if (!token) {
      setUploadStatus({ type: 'error', message: '구글 워크스페이스 연동(로그인)이 필요합니다.' });
      return;
    }
    setIsDriveModalOpen(true);
    loadDriveFiles();
  };

  const handleSelectDriveFile = async (file: DriveFile) => {
    setIsDriveModalOpen(false);
    setIsAnalyzingDriveFile(true);
    setUploadStatus({ type: 'success', message: `${file.name} 자료 다운로드 및 AI 분석 중...` });
    try {
      const fileText = await downloadDriveFileText(token!, file.id);
      if (!fileText || fileText.trim().length === 0) {
        throw new Error('선택한 파일에 텍스트 내용이 없거나 읽을 수 없습니다.');
      }
      
      const extracted = await extractBusinessInfoFromText(fileText);
      setProfile((prev) => ({ ...prev, ...extracted }));
      setHighlightedFields(new Set(Object.keys(extracted)));
      setUploadStatus({ type: 'success', message: `구글 드라이브(${file.name})에서 자료 분석 및 세부 입력 완료!` });
    } catch (err: any) {
      console.error(err);
      setUploadStatus({ type: 'error', message: `자료 분석 실패: ${err.message || '텍스트를 파싱할 수 없는 형식입니다.'}` });
    } finally {
      setIsAnalyzingDriveFile(false);
    }
  };

  useEffect(() => {
    if (highlightedFields.size > 0) {
      const timer = setTimeout(() => {
        setHighlightedFields(new Set());
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [highlightedFields]);

  const handleNext = () => setStep((prev) => prev + 1);
  const handlePrev = () => setStep((prev) => prev - 1);

  const handleChange = (field: keyof UserProfile, value: any) => {
    setProfile((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = () => {
    const totalDebt = (profile.debt1Tier || 0) + (profile.debt2Tier || 0) + (profile.debtCardLoan || 0) + (profile.debtOther || 0);
    const calculatedDebtRatio = profile.annualRevenue > 0 ? Math.round((totalDebt / profile.annualRevenue) * 100) : (profile.debtRatio || 0);
    const finalizedProfile: UserProfile = {
      ...profile,
      debtRatio: calculatedDebtRatio
    };
    onComplete(finalizedProfile);
  };

  const handleMyDataConnect = async () => {
    setIsConnectingMyData(true);
    try {
      const myDataProfile = await connectMyData();
      setProfile((prev) => ({ ...prev, ...myDataProfile }));
      setHighlightedFields(new Set(Object.keys(myDataProfile)));
      setUploadStatus({ type: 'success', message: "마이데이터 연동 완료! 재무 정보가 자동으로 입력되었습니다." });
      
      // 약간의 딜레이 후 다음 단계로 이동 제안 효과 등을 줄 수 있음
    } catch (error) {
      setUploadStatus({ type: 'error', message: "마이데이터 연동 실패" });
    } finally {
      setIsConnectingMyData(false);
    }
  };

  const formatCurrency = (value: number) => {
    if (value === 0) return "0원";
    return new Intl.NumberFormat('ko-KR').format(value) + "원";
  };

  const formatToKoreanUnit = (value: number) => {
    if (value === 0) return "";
    const units = ["", "만", "억", "조"];
    let result = "";
    let temp = value;
    let unitIdx = 0;
    
    while (temp > 0) {
      const mod = temp % 10000;
      if (mod > 0) {
        result = `${mod}${units[unitIdx]} ` + result;
      }
      temp = Math.floor(temp / 10000);
      unitIdx++;
    }
    return result.trim() + "원";
  };

  const getFieldClass = (fieldName: string) => {
    const baseClass = "w-full pr-4 py-3 border rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all duration-300 font-bold text-slate-800";
    // 마이데이터로 연동된 경우 약간 다른 스타일 적용 (Readonly 느낌)
    const isMyDataField = profile.isMyDataLinked && highlightedFields.has(fieldName);
    const highlightClass = isMyDataField 
      ? "border-emerald-500 bg-emerald-50 ring-2 ring-emerald-100 text-emerald-900" 
      : highlightedFields.has(fieldName) 
        ? "border-blue-500 bg-blue-50 ring-2 ring-blue-100" 
        : "border-slate-200 bg-white";
        
    return `${baseClass} ${highlightClass}`;
  };

  // 마이데이터 인증 마크 렌더링
  const MyDataBadge = ({ fieldName }: { fieldName?: string }) => {
    if (profile.isMyDataLinked) {
      return (
        <span className="ml-auto flex items-center gap-1 text-[10px] text-emerald-600 font-bold bg-emerald-100 px-2 py-0.5 rounded-full">
          <ShieldCheck className="w-3 h-3" /> 인증됨
        </span>
      );
    }
    return null;
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsAnalyzingImage(true);
    try {
      const extractedInfo = await extractBusinessInfoFromImage(file);
      setProfile((prev) => ({ ...prev, ...extractedInfo }));
      setUploadStatus({ type: 'success', message: "성공적으로 추출되었습니다." });
    } catch (error) {
      setUploadStatus({ type: 'error', message: "분석 실패" });
    } finally {
      setIsAnalyzingImage(false);
    }
  };

  const renderStep = () => {
    switch (step) {
      case 1:
        return (
          <motion.div 
            key="step-1"
            initial={{ opacity: 0, x: -15 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 15 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            {/* Step 1 Intro Banner */}
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <span className="text-xs font-black text-blue-600 uppercase tracking-wider block">Step 01 / 03</span>
                <h3 className="text-lg font-black text-slate-900">기본 정보 및 서류 연동</h3>
              </div>
              <span className="text-[11px] font-bold text-slate-400 bg-slate-100 px-2.5 py-1 rounded-full">
                OCR · 마이데이터 자동 채움 지원
              </span>
            </div>

            {/* 마이데이터 & 카메라 & 구글 드라이브 연동 섹션 */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 mb-6">
                <button 
                  type="button"
                  onClick={handleMyDataConnect}
                  disabled={profile.isMyDataLinked || isConnectingMyData}
                  className={`relative p-4 rounded-2xl border-2 transition-all text-left flex flex-col gap-2.5 group overflow-hidden ${
                    profile.isMyDataLinked 
                      ? 'bg-emerald-50 border-emerald-300 cursor-default' 
                      : 'bg-white border-blue-100 hover:border-blue-400 hover:shadow-lg hover:shadow-blue-500/10'
                  }`}
                >
                    {isConnectingMyData && (
                        <div className="absolute inset-0 bg-white/90 z-10 flex items-center justify-center backdrop-blur-sm">
                            <div className="flex flex-col items-center gap-2">
                                <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
                                <span className="text-xs font-bold text-slate-700">국세청·은행 불러오는 중...</span>
                            </div>
                        </div>
                    )}
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-white ${profile.isMyDataLinked ? 'bg-emerald-500' : 'bg-blue-600'}`}>
                        {profile.isMyDataLinked ? <CheckCircle className="w-5 h-5" /> : <Link className="w-5 h-5" />}
                    </div>
                    <div>
                        <h4 className="font-black text-slate-900 text-sm flex items-center gap-1.5">
                          <span>마이데이터 연동</span>
                          {profile.isMyDataLinked && <span className="text-[10px] text-emerald-600 bg-emerald-100 px-1.5 py-0.5 rounded font-bold">완료</span>}
                        </h4>
                        <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                          {profile.isMyDataLinked 
                            ? "국세청·은행 정보 반영됨" 
                            : "홈택스·금융 내역 자동 조회"}
                        </p>
                    </div>
                    {!profile.isMyDataLinked && (
                        <div className="mt-auto pt-1 flex items-center gap-1 text-[10px] font-bold text-blue-600">
                           <ShieldCheck className="w-3 h-3" /> 안전 암호화 통신
                        </div>
                    )}
                </button>

                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col gap-2.5 shadow-xl relative overflow-hidden text-white">
                    <div className="w-9 h-9 bg-slate-800 rounded-xl flex items-center justify-center text-blue-400">
                        <Camera className="w-5 h-5" />
                    </div>
                    <div>
                        <h4 className="font-black text-white text-sm">사업자등록증 촬영/OCR</h4>
                        <p className="text-[11px] text-slate-400 font-medium mt-0.5">이미지 인식으로 즉시 입력</p>
                    </div>
                    <label className="mt-auto w-full py-2 bg-white text-slate-900 rounded-xl text-xs font-black cursor-pointer hover:bg-slate-100 transition-all flex items-center justify-center gap-1.5 shadow-xs">
                        {isAnalyzingImage ? <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600" /> : <Upload className="w-3.5 h-3.5 text-blue-600" />}
                        <span>{isAnalyzingImage ? "분석 중..." : "사업자등록증 업로드"}</span>
                        <input type="file" className="hidden" accept="image/*" onChange={handleFileUpload} />
                    </label>
                </div>

                <button
                  type="button"
                  onClick={handleOpenDrivePicker}
                  disabled={isGoogleSyncDisabled}
                  title="구글 동기화가 비활성화되었습니다."
                  aria-disabled={isGoogleSyncDisabled}
                  className={`relative p-4 rounded-2xl border-2 transition-all text-left flex flex-col gap-2.5 group overflow-hidden ${
                    isGoogleSyncDisabled
                      ? 'bg-slate-50 border-slate-200 cursor-not-allowed opacity-60'
                      : token 
                        ? 'bg-amber-50/50 border-amber-200 hover:border-amber-400 hover:shadow-lg hover:shadow-amber-500/10' 
                        : 'bg-slate-50 border-slate-200 cursor-not-allowed opacity-60'
                  }`}
                >
                    {isAnalyzingDriveFile && (
                        <div className="absolute inset-0 bg-white/90 z-10 flex items-center justify-center backdrop-blur-sm">
                            <div className="flex flex-col items-center gap-2">
                                <Loader2 className="w-6 h-6 animate-spin text-amber-600" />
                                <span className="text-xs font-bold text-slate-700">드라이브 분석 중...</span>
                            </div>
                        </div>
                    )}
                    <div className={`w-9 h-9 rounded-xl flex items-center justify-center text-white ${isGoogleSyncDisabled ? 'bg-slate-400' : token ? 'bg-amber-500' : 'bg-slate-400'}`}>
                        {isGoogleSyncDisabled ? <CloudOff className="w-5 h-5" /> : <FileText className="w-5 h-5" />}
                    </div>
                    <div>
                        <div className="flex items-center gap-1.5">
                          <h4 className="font-black text-slate-900 text-sm">구글 드라이브 서류</h4>
                          {isGoogleSyncDisabled && (
                            <span className="text-[10px] text-slate-500 bg-slate-200 px-1.5 py-0.5 rounded font-bold">비활성화</span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-500 font-medium mt-0.5">
                          {isGoogleSyncDisabled 
                            ? "구글 동기화 비활성화됨" 
                            : token 
                              ? "사업계획서·재무제표 추출" 
                              : "로그인 시 연동 가능"}
                        </p>
                    </div>
                    <div className="mt-auto pt-1 flex items-center gap-1 text-[10px] font-bold text-slate-400">
                       {isGoogleSyncDisabled ? (
                         <>
                           <ShieldAlert className="w-3 h-3 text-slate-400" /> 구글 동기화 비활성화
                         </>
                       ) : token ? (
                         <>
                           <ShieldCheck className="w-3 h-3 text-amber-600" /> <span className="text-amber-600">연동 활성화</span>
                         </>
                       ) : null}
                    </div>
                </button>
            </div>

            {uploadStatus.message && (
               <div className={`text-xs font-bold text-center py-2.5 px-4 rounded-xl border ${uploadStatus.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-emerald-700' : 'bg-red-50 border-red-200 text-red-700'}`}>
                 {uploadStatus.message}
               </div>
            )}

            {/* Basic Info Inputs */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                    <label className="text-xs font-black text-slate-600 uppercase flex items-center gap-1.5"><User className="w-3.5 h-3.5 text-blue-600" /> 대표자명</label>
                    <MyDataBadge />
                </div>
                <input type="text" className={getFieldClass('name')} value={profile.name} onChange={(e) => handleChange('name', e.target.value)} placeholder="홍길동" />
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                    <label className="text-xs font-black text-slate-600 uppercase flex items-center gap-1.5"><Building className="w-3.5 h-3.5 text-blue-600" /> 상호명</label>
                    <MyDataBadge />
                </div>
                <input type="text" className={getFieldClass('businessName')} value={profile.businessName} onChange={(e) => handleChange('businessName', e.target.value)} placeholder="(주)비즈솔루션" />
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <div className="flex items-center justify-between">
                     <label className="text-xs font-black text-slate-600 uppercase flex items-center gap-1.5"><FileText className="w-3.5 h-3.5 text-blue-600" /> 사업자등록번호</label>
                     <MyDataBadge />
                </div>
                <input type="text" className={getFieldClass('businessRegistrationNumber')} value={profile.businessRegistrationNumber} onChange={(e) => handleChange('businessRegistrationNumber', e.target.value)} placeholder="000-00-00000" />
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-black text-slate-600 uppercase">성별</label>
                <div className="grid grid-cols-2 gap-2">
                  {['남성', '여성'].map((g) => (
                    <button key={g} type="button" onClick={() => handleChange('gender', g)} className={`py-2.5 rounded-xl text-xs sm:text-sm font-black border transition-all ${profile.gender === g ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/20' : 'bg-white text-slate-600 border-slate-200 hover:border-blue-300'}`}>
                      {g}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-black text-slate-600 uppercase">연령대</label>
                <select className={getFieldClass('ageGroup')} value={profile.ageGroup || ''} onChange={(e) => handleChange('ageGroup', e.target.value)}>
                  <option value="" disabled>연령대를 선택하세요</option>
                  <option value="20대">20대</option>
                  <option value="30대">30대</option>
                  <option value="40대">40대</option>
                  <option value="50대">50대</option>
                  <option value="60대 이상">60대 이상</option>
                </select>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-black text-slate-600 uppercase">기업 형태</label>
                <MyDataBadge />
              </div>
              <div className="grid grid-cols-3 gap-2.5">
                {[BusinessType.PRE_STARTUP, BusinessType.INDIVIDUAL, BusinessType.CORPORATION].map((type) => (
                  <button key={type} type="button" onClick={() => handleChange('businessType', type)} className={`py-3 rounded-xl text-xs sm:text-sm font-black border transition-all ${profile.businessType === type ? 'bg-blue-600 text-white border-blue-600 shadow-md shadow-blue-500/20' : 'bg-white text-slate-600 border-slate-200 hover:border-blue-300'}`}>
                    {type === BusinessType.PRE_STARTUP ? '예비창업' : type === BusinessType.INDIVIDUAL ? '개인사업자' : '법인기업'}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                    <label className="text-xs font-black text-slate-600 uppercase">업종 분야</label>
                    <MyDataBadge />
                </div>
                <select className={getFieldClass('industry')} value={profile.industry} onChange={(e) => handleChange('industry', e.target.value)}>
                  <option value={Industry.RESTAURANT}>음식점업</option>
                  <option value={Industry.RETAIL}>도소매업</option>
                  <option value={Industry.MANUFACTURING}>제조업</option>
                  <option value={Industry.IT_SOFTWARE}>IT / 소프트웨어</option>
                  <option value={Industry.SERVICE}>서비스업</option>
                  <option value={Industry.OTHER}>기타 업종</option>
                </select>
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                    <label className="text-xs font-black text-slate-600 uppercase">소재지 (지역)</label>
                    <MyDataBadge />
                </div>
                <select className={getFieldClass('location')} value={profile.location} onChange={(e) => handleChange('location', e.target.value)}>
                  {['서울', '경기', '인천', '부산', '대구', '광주', '대전', '울산', '강원', '충북', '충남', '전북', '전남', '경북', '경남', '제주'].map(loc => <option key={loc} value={loc}>{loc}</option>)}
                </select>
              </div>
            </div>
            
            <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                    <label className="text-xs font-black text-slate-600 uppercase flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5 text-blue-600" /> 사업장 상세 주소</label>
                    <MyDataBadge />
                </div>
                <input type="text" className={getFieldClass('businessAddress')} value={profile.businessAddress} onChange={(e) => handleChange('businessAddress', e.target.value)} placeholder="사업자등록증 상의 사업장 도로명 주소를 입력하세요" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                    <label className="text-xs font-black text-slate-600 uppercase">설립연도</label>
                    <MyDataBadge />
                </div>
                <input type="number" className={getFieldClass('foundedYear')} value={profile.foundedYear} onChange={(e) => handleChange('foundedYear', e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                     <label className="text-xs font-black text-slate-600 uppercase">상시 종업원수 (명)</label>
                     <MyDataBadge />
                </div>
                <input type="number" className={getFieldClass('employees')} value={profile.employees} onChange={(e) => handleChange('employees', parseInt(e.target.value) || 0)} />
              </div>
            </div>
          </motion.div>
        );

      case 2:
        return (
          <motion.div 
            key="step-2"
            initial={{ opacity: 0, x: -15 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 15 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            {/* Step 2 Intro Banner */}
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <span className="text-xs font-black text-blue-600 uppercase tracking-wider block">Step 02 / 03</span>
                <h3 className="text-lg font-black text-slate-900">재무 및 신용 정보 연동</h3>
              </div>
              <span className="text-[11px] font-bold text-slate-500 bg-blue-50 text-blue-700 px-2.5 py-1 rounded-full border border-blue-100">
                심사 우대 가점 자동 산출
              </span>
            </div>

            <div className={`p-4 rounded-2xl flex items-center gap-3.5 border ${profile.isMyDataLinked ? 'bg-emerald-50 border-emerald-200 text-emerald-900' : 'bg-blue-50 border-blue-100 text-blue-900'}`}>
              {profile.isMyDataLinked ? <ShieldCheck className="w-7 h-7 shrink-0 text-emerald-600" /> : <Activity className="w-7 h-7 shrink-0 text-blue-600" />}
              <div>
                <h4 className="font-black text-sm">{profile.isMyDataLinked ? '마이데이터 재무·부채 자동 검증됨' : '재무 및 신용 지표 입력'}</h4>
                <p className="text-[11px] font-medium text-slate-600 mt-0.5">{profile.isMyDataLinked ? '국세청 매출 자료 및 금융결제원 대출 잔액이 연동되었습니다.' : '정확한 매출과 부채 규모를 입력할수록 AI 승인 예측율이 높아집니다.'}</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                     <label className="text-xs font-black text-slate-600 uppercase flex items-center gap-1.5"><DollarSign className="w-3.5 h-3.5 text-blue-600" /> 최근 1년 연간 매출액</label>
                     <MyDataBadge />
                </div>
                <input type="number" className={getFieldClass('annualRevenue')} value={profile.annualRevenue} onChange={(e) => handleChange('annualRevenue', parseInt(e.target.value) || 0)} placeholder="원 단위 입력" />
                <p className="text-[11px] font-black text-blue-600 text-right">{formatToKoreanUnit(profile.annualRevenue)}</p>
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                    <label className="text-xs font-black text-slate-600 uppercase flex items-center gap-1.5"><Percent className="w-3.5 h-3.5 text-blue-600" /> 예상 영업이익률</label>
                    <span className="text-sm font-black text-slate-900">{profile.expectedProfitMargin}%</span>
                </div>
                <input type="range" min="0" max="50" className="w-full accent-blue-600 h-2.5 bg-slate-200 rounded-full appearance-none cursor-pointer mt-3" value={profile.expectedProfitMargin} onChange={(e) => handleChange('expectedProfitMargin', parseInt(e.target.value))} />
                <div className="flex justify-between text-[10px] font-bold text-slate-400">
                  <span>0% (손익분기)</span>
                  <span>15% (평균)</span>
                  <span>50% 이상</span>
                </div>
              </div>
            </div>

            {/* Credit Score Slider */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <label className="text-xs font-black text-slate-700 uppercase flex items-center gap-1.5"><Sparkles className="w-3.5 h-3.5 text-blue-600" /> 대표자 신용 점수 (NICE/KCB 기준)</label>
                    <MyDataBadge />
                </div>
                <span className="px-3 py-1 bg-slate-900 text-blue-400 rounded-xl font-black text-sm">
                  {profile.creditScore}점 {profile.creditScore >= 840 ? '(우수 1~2등급)' : profile.creditScore >= 750 ? '(일반 3~4등급)' : '(관리필요 5등급 이하)'}
                </span>
              </div>
              <input type="range" min="300" max="1000" className="w-full accent-blue-600 h-2.5 bg-slate-200 rounded-full appearance-none cursor-pointer" value={profile.creditScore} onChange={(e) => handleChange('creditScore', parseInt(e.target.value))} />
              <div className="flex justify-between text-[10px] font-bold text-slate-400">
                <span>300점 (취약)</span>
                <span>750점 (보통)</span>
                <span>1000점 (최우수)</span>
              </div>
            </div>

            {/* Debt Status Breakdown */}
            <div className="space-y-3 pt-2">
              <h4 className="text-xs font-black text-slate-700 uppercase flex items-center gap-1.5">
                <CreditCard className="w-3.5 h-3.5 text-slate-500" /> 금융권별 부채 잔액 현황 (대환 및 한도 차감 분석)
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                <div className="space-y-1 bg-white p-3.5 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between">
                      <label className="text-[11px] font-bold text-slate-600">1금융권 대출 잔액</label>
                      <span className="text-[10px] font-black text-blue-600">{formatToKoreanUnit(profile.debt1Tier)}</span>
                  </div>
                  <input type="number" className="w-full py-1.5 px-3 border border-slate-200 rounded-lg text-xs font-bold" value={profile.debt1Tier} onChange={(e) => handleChange('debt1Tier', parseInt(e.target.value) || 0)} placeholder="시중은행 대출" />
                </div>

                <div className="space-y-1 bg-white p-3.5 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between">
                      <label className="text-[11px] font-bold text-slate-600">2금융권 대출 잔액</label>
                      <span className="text-[10px] font-black text-amber-600">{formatToKoreanUnit(profile.debt2Tier)}</span>
                  </div>
                  <input type="number" className="w-full py-1.5 px-3 border border-slate-200 rounded-lg text-xs font-bold" value={profile.debt2Tier} onChange={(e) => handleChange('debt2Tier', parseInt(e.target.value) || 0)} placeholder="저축은행/상호금융" />
                </div>

                <div className="space-y-1 bg-white p-3.5 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between">
                      <label className="text-[11px] font-bold text-slate-600">카드론 / 현금서비스 잔액</label>
                      <span className="text-[10px] font-black text-rose-600">{formatToKoreanUnit(profile.debtCardLoan)}</span>
                  </div>
                  <input type="number" className="w-full py-1.5 px-3 border border-slate-200 rounded-lg text-xs font-bold" value={profile.debtCardLoan} onChange={(e) => handleChange('debtCardLoan', parseInt(e.target.value) || 0)} placeholder="카드론 잔액" />
                </div>

                <div className="space-y-1 bg-white p-3.5 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between">
                      <label className="text-[11px] font-bold text-slate-600">기타 부채 잔액</label>
                      <span className="text-[10px] font-black text-slate-600">{formatToKoreanUnit(profile.debtOther)}</span>
                  </div>
                  <input type="number" className="w-full py-1.5 px-3 border border-slate-200 rounded-lg text-xs font-bold" value={profile.debtOther} onChange={(e) => handleChange('debtOther', parseInt(e.target.value) || 0)} placeholder="기타 대출" />
                </div>
              </div>
            </div>

            {/* Real-time Debt Ratio & Financial Health Gauge */}
            {(() => {
              const totalDebt = (profile.debt1Tier || 0) + (profile.debt2Tier || 0) + (profile.debtCardLoan || 0) + (profile.debtOther || 0);
              const liveRatio = profile.annualRevenue > 0 ? Math.round((totalDebt / profile.annualRevenue) * 100) : (profile.debtRatio || 0);
              const isSafe = liveRatio < 50;
              const isNormal = liveRatio >= 50 && liveRatio <= 100;
              const isWarning = liveRatio > 100 && liveRatio <= 200;
              const isHighRisk = liveRatio > 200;

              return (
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <span className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                        <Activity className="w-3.5 h-3.5 text-blue-600" />
                        매출액 대비 부채비율 실시간 진단
                      </span>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        총 부채 ({formatToKoreanUnit(totalDebt) || '0원'}) ÷ 연간 매출액 ({formatToKoreanUnit(profile.annualRevenue) || '0원'})
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`px-3 py-1 rounded-xl text-xs font-black ${
                        isSafe ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' :
                        isNormal ? 'bg-blue-100 text-blue-800 border border-blue-300' :
                        isWarning ? 'bg-amber-100 text-amber-800 border border-amber-300' :
                        'bg-rose-100 text-rose-800 border border-rose-300'
                      }`}>
                        부채비율 {liveRatio}% {isSafe ? '(안전)' : isNormal ? '(적정)' : isWarning ? '(주의)' : '(고위험)'}
                      </span>
                    </div>
                  </div>

                  <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden flex">
                    <div 
                      className={`h-full transition-all duration-500 ${
                        isSafe ? 'bg-emerald-500' : isNormal ? 'bg-blue-500' : isWarning ? 'bg-amber-500' : 'bg-rose-500'
                      }`}
                      style={{ width: `${Math.min(100, liveRatio)}%` }}
                    />
                  </div>

                  <div className="flex justify-between text-[10px] font-bold text-slate-400">
                    <span>안전 (&lt;50%)</span>
                    <span>적정 (50~100%)</span>
                    <span>주의 (100~200%)</span>
                    <span>고위험 (&gt;200%)</span>
                  </div>
                </div>
              );
            })()}

            {/* Mandatory Policy Ineligibility Pre-checks (Tax Arrears & Overdue) */}
            <div className="space-y-3 pt-1">
              <h4 className="text-xs font-black text-slate-700 uppercase flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-500" /> 정책자금 필수 결격 요건 확인 (부결 사전 차단)
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800">국세 및 지방세 체납</span>
                    <span className={`text-[10px] font-black px-2 py-0.5 rounded-md ${profile.hasTaxArrears ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'}`}>
                      {profile.hasTaxArrears ? '체납 있음 (심사제한)' : '완납/체납 없음'}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => handleChange('hasTaxArrears', false)}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        !profile.hasTaxArrears ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      체납 없음 (정상)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleChange('hasTaxArrears', true)}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        profile.hasTaxArrears ? 'bg-rose-600 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      체납 있음
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-400">※ 세금 체납 시 정책자금 접수가 자동 결격 처리됩니다.</p>
                </div>

                <div className="p-3.5 rounded-xl border border-slate-200 bg-white space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800">금융기관 30일 이상 연체</span>
                    <span className={`text-[10px] font-black px-2 py-0.5 rounded-md ${profile.hasOverdue ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'}`}>
                      {profile.hasOverdue ? '연체 이력 있음' : '연체 없음 (정상)'}
                    </span>
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => handleChange('hasOverdue', false)}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        !profile.hasOverdue ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      연체 없음 (정상)
                    </button>
                    <button
                      type="button"
                      onClick={() => handleChange('hasOverdue', true)}
                      className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        profile.hasOverdue ? 'bg-rose-600 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                      }`}
                    >
                      연체 있음
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-400">※ 연체 기록이 있는 경우 소명 또는 정리 후 신청을 권장합니다.</p>
                </div>
              </div>
            </div>
          </motion.div>
        );

      case 3:
        return (
          <motion.div 
            key="step-3"
            initial={{ opacity: 0, x: -15 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 15 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            {/* Step 3 Intro Banner */}
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <span className="text-xs font-black text-blue-600 uppercase tracking-wider block">Step 03 / 03</span>
                <h3 className="text-lg font-black text-slate-900">과거 신청 이력 & 희망 자금 설정</h3>
              </div>
              <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                진단 준비 100% 완료
              </span>
            </div>

            {/* Policy Application History Management */}
            <div className="space-y-3 p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <div>
                  <h4 className="text-xs font-black text-slate-800 uppercase flex items-center gap-1.5">
                    <History className="w-3.5 h-3.5 text-blue-600" />
                    과거 정부 정책자금 / 보증 신청 이력
                  </h4>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    중복 보증 금지 및 최근 부결 후 재신청 제한 규정을 정확히 판별하기 위해 입력합니다.
                  </p>
                </div>
                <span className="text-[11px] font-bold text-blue-700 bg-blue-100 px-2.5 py-0.5 rounded-full self-start sm:self-auto">
                  {(profile.applicationHistories || []).length}건 등록됨
                </span>
              </div>

              {/* Quick Preset Buttons */}
              <div className="flex items-center gap-1.5 flex-wrap pt-1">
                <span className="text-[10px] font-bold text-slate-400">테스트 빠른 등록:</span>
                <button
                  type="button"
                  onClick={() => {
                    const sample1: PolicyApplicationHistory = {
                      id: `hist-${Date.now()}`,
                      agency: '소상공인시장진흥공단',
                      productName: '일반경영안정자금',
                      applyYear: 2024,
                      applyMonth: 6,
                      applyAmount: 30000000,
                      status: 'APPROVED',
                      approvedAmount: 30000000,
                      remainingBalance: 20000000
                    };
                    handleChange('applicationHistories', [...(profile.applicationHistories || []), sample1]);
                  }}
                  className="px-2 py-1 bg-white hover:bg-blue-50 border border-slate-200 text-blue-700 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                >
                  + 소진공 승인 (잔액 2천만)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const sample2: PolicyApplicationHistory = {
                      id: `hist-${Date.now()}`,
                      agency: '지역신용보증재단',
                      productName: '소상공인 특례보증',
                      applyYear: 2024,
                      applyMonth: 10,
                      applyAmount: 50000000,
                      status: 'APPROVED',
                      approvedAmount: 50000000,
                      remainingBalance: 35000000
                    };
                    handleChange('applicationHistories', [...(profile.applicationHistories || []), sample2]);
                  }}
                  className="px-2 py-1 bg-white hover:bg-emerald-50 border border-slate-200 text-emerald-700 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                >
                  + 지역신보 보증서 승인 (잔액 3.5천만)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const sample3: PolicyApplicationHistory = {
                      id: `hist-${Date.now()}`,
                      agency: '신용보증기금',
                      productName: '소상공인 비즈니스 보증',
                      applyYear: 2024,
                      applyMonth: 11,
                      applyAmount: 50000000,
                      status: 'REJECTED',
                      rejectionReason: '부채비율 과다 및 한도 소진'
                    };
                    handleChange('applicationHistories', [...(profile.applicationHistories || []), sample3]);
                  }}
                  className="px-2 py-1 bg-white hover:bg-rose-50 border border-slate-200 text-rose-700 rounded-lg text-[10px] font-bold transition-colors cursor-pointer"
                >
                  + 신보 부결 이력 (4개월 전)
                </button>
                {(profile.applicationHistories || []).length > 0 && (
                  <button
                    type="button"
                    onClick={() => handleChange('applicationHistories', [])}
                    className="px-2 py-1 bg-slate-200 hover:bg-slate-300 text-slate-700 rounded-lg text-[10px] font-bold transition-colors cursor-pointer ml-auto"
                  >
                    전체 초기화 (첫 신청)
                  </button>
                )}
              </div>

              {/* Application History Cards */}
              <div className="space-y-2 pt-1">
                {(profile.applicationHistories || []).length === 0 ? (
                  <div className="p-3.5 bg-white rounded-xl border border-dashed border-slate-200 text-center">
                    <p className="text-xs font-bold text-slate-600">과거 정책자금 신청 이력이 없습니다. (첫 신청 우대 가능)</p>
                    <p className="text-[10px] text-slate-400 mt-0.5">기존에 지원받은 자금이나 보증서가 있다면 위의 버튼으로 손쉽게 추가해 보세요.</p>
                  </div>
                ) : (
                  (profile.applicationHistories || []).map((hist, idx) => (
                    <div key={hist.id || idx} className="p-3 bg-white rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-2xs">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black text-slate-900">{hist.agency}</span>
                          <span className="text-[11px] text-slate-600 font-medium">({hist.productName})</span>
                          <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-md ${
                            hist.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-800' :
                            hist.status === 'REJECTED' ? 'bg-rose-100 text-rose-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {hist.status === 'APPROVED' ? '승인' : hist.status === 'REJECTED' ? '부결' : '심사진행중'}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-2">
                          <span>{hist.applyYear}년 {hist.applyMonth ? `${hist.applyMonth}월` : ''} 신청</span>
                          {hist.status === 'APPROVED' && (
                            <span className="text-blue-600 font-bold">
                              대출 잔액: {formatToKoreanUnit(hist.remainingBalance || 0)}
                            </span>
                          )}
                          {hist.status === 'REJECTED' && (
                            <span className="text-rose-600 font-bold">
                              사유: {hist.rejectionReason || '기준 미달'}
                            </span>
                          )}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          const updated = (profile.applicationHistories || []).filter((_, i) => i !== idx);
                          handleChange('applicationHistories', updated);
                        }}
                        className="self-end sm:self-center p-1.5 text-slate-400 hover:text-rose-600 transition-colors cursor-pointer"
                        title="삭제"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Funding Need Input & Quick Presets */}
            <div className="p-5 bg-gradient-to-br from-blue-50 to-indigo-50/40 rounded-2xl border border-blue-100 space-y-3">
              <div className="flex justify-between items-center">
                <label className="text-xs font-black text-slate-800 uppercase flex items-center gap-1.5">
                  <Wallet className="w-4 h-4 text-blue-600" /> 필요 정책자금 희망 규모
                </label>
                <span className="text-lg font-black text-blue-700">{formatToKoreanUnit(profile.fundingNeed)}</span>
              </div>
              <input 
                type="number" 
                className="w-full py-2.5 px-4 bg-white border border-blue-200 rounded-xl text-base font-black text-slate-900 focus:ring-2 focus:ring-blue-500 outline-none" 
                value={profile.fundingNeed} 
                onChange={(e) => handleChange('fundingNeed', parseInt(e.target.value) || 0)} 
                step={10000000}
              />
              <div className="flex items-center gap-2 flex-wrap pt-1">
                <span className="text-[11px] font-bold text-slate-500">빠른 선택:</span>
                {[30000000, 50000000, 70000000, 100000000, 200000000].map((amt) => (
                  <button
                    key={amt}
                    type="button"
                    onClick={() => handleChange('fundingNeed', amt)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-black transition-all ${
                      profile.fundingNeed === amt
                        ? 'bg-blue-600 text-white shadow-xs'
                        : 'bg-white text-slate-700 border border-slate-200 hover:bg-blue-50'
                    }`}
                  >
                    {formatToKoreanUnit(amt)}
                  </button>
                ))}
              </div>
            </div>

            {/* Cash Flow Health Status */}
            <div className="space-y-3 p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                    <label className="text-xs font-black text-slate-700 uppercase flex items-center gap-1.5"><Activity className="w-3.5 h-3.5 text-emerald-600" /> 월 현금흐름 안정성 점수</label>
                </div>
                <span className="text-sm font-black text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-xl">{profile.cashFlowStatus}점 / 100점</span>
              </div>
              <input type="range" min="0" max="100" className="w-full accent-emerald-500 h-2 bg-slate-200 rounded-full appearance-none cursor-pointer" value={profile.cashFlowStatus} onChange={(e) => handleChange('cashFlowStatus', parseInt(e.target.value))} />
              <p className="text-[11px] text-slate-500 font-medium">
                안정적인 월 매출과 지출 관리 상태를 평가하여 정책자금 상환 가능성 가점을 부여합니다.
              </p>
            </div>

            {/* Policy Bonus Points (스마트공장, 탄소중립 등 정책적 가점 항목 승인 확률 보정) */}
            {(() => {
              const bonus = profile.policyBonusFactors || {};
              const liveUplift = 
                (bonus.hasSmartFactory ? 12 : 0) +
                (bonus.hasCarbonNeutrality ? 8 : 0) +
                (bonus.hasJobCreation ? 6 : 0) +
                (bonus.hasVentureOrInnoBiz ? 8 : 0) +
                (bonus.hasCreditEducation ? 5 : 0);

              const updateBonus = (key: string, val: any) => {
                setProfile(prev => ({
                  ...prev,
                  policyBonusFactors: {
                    ...(prev.policyBonusFactors || {}),
                    [key]: val
                  }
                }));
              };

              return (
                <div className="space-y-4 p-5 bg-gradient-to-br from-indigo-50/70 via-white to-blue-50/50 rounded-2xl border-2 border-indigo-200 shadow-xs">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-indigo-100">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="p-1.5 bg-indigo-600 text-white rounded-lg shadow-xs">
                          <Sparkles className="w-3.5 h-3.5" />
                        </span>
                        <h4 className="text-sm font-black text-slate-900 tracking-tight flex items-center gap-1.5">
                          정부 정책적 가점 우대 항목 (승인 예측 확률 보정)
                        </h4>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        <strong className="text-indigo-700">‘스마트공장’</strong> 도입, <strong className="text-emerald-700">‘탄소중립’</strong> 실천 등 정부가 우선 지원하는 가점 항목을 선택하시면 심사 합격선 예측 확률이 실시간 상향 보정됩니다.
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 text-white rounded-xl shadow-xs self-start sm:self-auto shrink-0">
                      <TrendingUp className="w-3.5 h-3.5 text-indigo-200" />
                      <span className="text-xs font-black">
                        예측 보정: {liveUplift > 0 ? `+${liveUplift}%p` : '0%p'}
                      </span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                    {/* 1. 스마트공장·스마트공방 도입 */}
                    <div 
                      onClick={() => updateBonus('hasSmartFactory', !bonus.hasSmartFactory)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer select-none flex flex-col justify-between ${
                        bonus.hasSmartFactory 
                          ? 'bg-blue-50/80 border-blue-500 ring-2 ring-blue-200 text-slate-900 shadow-xs' 
                          : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5">
                          <div className={`p-2 rounded-lg mt-0.5 ${bonus.hasSmartFactory ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                            <Factory className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-black text-slate-900">스마트공장·스마트공방 도입</span>
                              <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-100 text-blue-800 rounded-md">
                                +10~14%p
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                              ERP/MES, 스마트공방/스마트상점(키오스크·테이블오더·자동화설비) 도입 기업
                            </p>
                          </div>
                        </div>
                        <input 
                          type="checkbox" 
                          checked={Boolean(bonus.hasSmartFactory)} 
                          onChange={() => {}} // handled by parent onClick
                          className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 pointer-events-none mt-1" 
                        />
                      </div>

                      {bonus.hasSmartFactory && (
                        <div className="mt-3 pt-2.5 border-t border-blue-200/60 flex items-center justify-between text-[11px]" onClick={(e) => e.stopPropagation()}>
                          <span className="text-slate-600 font-bold">도입 수준:</span>
                          <select
                            value={bonus.smartFactoryLevel || 'SMART_WORKSHOP'}
                            onChange={(e) => updateBonus('smartFactoryLevel', e.target.value)}
                            className="bg-white border border-blue-300 rounded-lg px-2 py-1 text-xs font-bold text-slate-800 focus:ring-1 focus:ring-blue-500 outline-none"
                          >
                            <option value="SMART_WORKSHOP">스마트공방 / 스마트상점</option>
                            <option value="BASIC">스마트공장 기초 단계 (ERP/MES)</option>
                            <option value="ADVANCED">스마트공장 고도화 단계</option>
                          </select>
                        </div>
                      )}
                    </div>

                    {/* 2. 탄소중립·친환경 ESG 실천 */}
                    <div 
                      onClick={() => updateBonus('hasCarbonNeutrality', !bonus.hasCarbonNeutrality)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer select-none flex flex-col justify-between ${
                        bonus.hasCarbonNeutrality 
                          ? 'bg-emerald-50/80 border-emerald-500 ring-2 ring-emerald-200 text-slate-900 shadow-xs' 
                          : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5">
                          <div className={`p-2 rounded-lg mt-0.5 ${bonus.hasCarbonNeutrality ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                            <Leaf className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-black text-slate-900">탄소중립·친환경 ESG 실천</span>
                              <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-md">
                                +8%p · 금리 -0.2%p
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                              소진공 넷제로 탄소중립 실천서약 완료, 친환경 고효율 에너지 절감 설비
                            </p>
                          </div>
                        </div>
                        <input 
                          type="checkbox" 
                          checked={Boolean(bonus.hasCarbonNeutrality)} 
                          onChange={() => {}}
                          className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 pointer-events-none mt-1" 
                        />
                      </div>

                      {bonus.hasCarbonNeutrality && (
                        <div className="mt-3 pt-2.5 border-t border-emerald-200/60 flex items-center justify-between text-[11px]" onClick={(e) => e.stopPropagation()}>
                          <span className="text-slate-600 font-bold">인증·실천 유형:</span>
                          <select
                            value={bonus.carbonCertType || 'PLEDGE'}
                            onChange={(e) => updateBonus('carbonCertType', e.target.value)}
                            className="bg-white border border-emerald-300 rounded-lg px-2 py-1 text-xs font-bold text-slate-800 focus:ring-1 focus:ring-emerald-500 outline-none"
                          >
                            <option value="PLEDGE">탄소중립 넷제로 실천 서약서</option>
                            <option value="ENERGY_SAVING">고효율 에너지 절감 설비 보유</option>
                            <option value="GREEN_CERT">친환경 녹색인증 / 환경경영</option>
                          </select>
                        </div>
                      )}
                    </div>

                    {/* 3. 청년·정규직 일자리 창출 */}
                    <div 
                      onClick={() => updateBonus('hasJobCreation', !bonus.hasJobCreation)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer select-none ${
                        bonus.hasJobCreation 
                          ? 'bg-purple-50/80 border-purple-500 ring-2 ring-purple-200 text-slate-900 shadow-xs' 
                          : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5">
                          <div className={`p-2 rounded-lg mt-0.5 ${bonus.hasJobCreation ? 'bg-purple-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                            <Users className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-black text-slate-900">청년·일자리 창출 우수</span>
                              <span className="text-[10px] font-bold px-2 py-0.5 bg-purple-100 text-purple-800 rounded-md">
                                +6%p
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                              최근 1년 이내 청년(만39세 이하) 또는 정규직 신규 채용 실적
                            </p>
                          </div>
                        </div>
                        <input 
                          type="checkbox" 
                          checked={Boolean(bonus.hasJobCreation)} 
                          onChange={() => {}}
                          className="w-4 h-4 rounded text-purple-600 focus:ring-purple-500 pointer-events-none mt-1" 
                        />
                      </div>
                    </div>

                    {/* 4. 이노비즈·메인비즈·벤처·특허 */}
                    <div 
                      onClick={() => updateBonus('hasVentureOrInnoBiz', !bonus.hasVentureOrInnoBiz)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer select-none ${
                        bonus.hasVentureOrInnoBiz 
                          ? 'bg-amber-50/80 border-amber-500 ring-2 ring-amber-200 text-slate-900 shadow-xs' 
                          : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5">
                          <div className={`p-2 rounded-lg mt-0.5 ${bonus.hasVentureOrInnoBiz ? 'bg-amber-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                            <Cpu className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-black text-slate-900">기술혁신·특허·벤처인증</span>
                              <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-100 text-amber-800 rounded-md">
                                +8%p
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-500 mt-1 leading-snug">
                              이노비즈, 메인비즈, 벤처기업 인증 또는 등록 특허/실용신안 보유
                            </p>
                          </div>
                        </div>
                        <input 
                          type="checkbox" 
                          checked={Boolean(bonus.hasVentureOrInnoBiz)} 
                          onChange={() => {}}
                          className="w-4 h-4 rounded text-amber-600 focus:ring-amber-500 pointer-events-none mt-1" 
                        />
                      </div>
                    </div>
                  </div>

                  {/* Quick Policy Education Helper */}
                  <div className="flex items-center justify-between p-3 bg-white rounded-xl border border-slate-200 text-xs">
                    <div className="flex items-center gap-2">
                      <Award className="w-4 h-4 text-indigo-600 shrink-0" />
                      <span className="font-bold text-slate-700">소진공 지식배움터 온라인 신용관리 사전교육 수료 이수증</span>
                      <span className="text-[10px] font-black text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-200">+5%p</span>
                    </div>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input 
                        type="checkbox"
                        checked={Boolean(bonus.hasCreditEducation)}
                        onChange={(e) => updateBonus('hasCreditEducation', e.target.checked)}
                        className="w-4 h-4 rounded text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                      />
                      <span className="text-xs font-bold text-slate-800">이수 완료</span>
                    </label>
                  </div>
                </div>
              );
            })()}

            {/* Final Overview Summary Card */}
            <div className="p-4 bg-white rounded-2xl border-2 border-slate-100 shadow-sm space-y-3">
              <h4 className="text-xs font-black text-slate-800 uppercase flex items-center justify-between">
                <span>진단 입력 데이터 최종 요약</span>
                <span className="text-blue-600 text-[11px]">수정하려면 이전 단계를 누르세요</span>
              </h4>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
                <div className="bg-slate-50 p-2.5 rounded-xl">
                  <span className="text-[10px] text-slate-400 block font-bold">대표자 / 상호</span>
                  <span className="font-black text-slate-800 truncate block">{profile.name || '미입력'} ({profile.businessName || '상호'})</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-xl">
                  <span className="text-[10px] text-slate-400 block font-bold">성별 / 연령대</span>
                  <span className="font-black text-slate-800 truncate block">{profile.gender || '미입력'} / {profile.ageGroup || '미입력'}</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-xl">
                  <span className="text-[10px] text-slate-400 block font-bold">업종 / 지역</span>
                  <span className="font-black text-slate-800 truncate block">{profile.industry} / {profile.location}</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-xl">
                  <span className="text-[10px] text-slate-400 block font-bold">연매출 / 신용도</span>
                  <span className="font-black text-slate-800 truncate block">{formatToKoreanUnit(profile.annualRevenue) || '0원'} / {profile.creditScore}점</span>
                </div>
                <div className="bg-slate-50 p-2.5 rounded-xl">
                  <span className="text-[10px] text-slate-400 block font-bold">희망 자금 규모</span>
                  <span className="font-black text-blue-700 truncate block">{formatToKoreanUnit(profile.fundingNeed)}</span>
                </div>
              </div>
            </div>
          </motion.div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-[2.5rem] shadow-2xl overflow-hidden border border-slate-100">
      {/* Dynamic Progress Bar & Step Navigation */}
      <div className="bg-slate-900 px-6 sm:px-10 pt-8 pb-7 text-white relative">
        <div className="relative z-10 flex flex-col sm:flex-row sm:justify-between sm:items-end gap-3 mb-6">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2 py-0.5 bg-blue-500/20 border border-blue-400/30 text-[10px] font-black uppercase tracking-wider text-blue-300 rounded-full">
                AI BizMatch Wizard
              </span>
              <span className="text-[11px] font-bold text-slate-400">
                진행률 {Math.round((step / 3) * 100)}% ({step}/3단계)
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
              맞춤형 정책자금 정밀 진단
            </h2>
          </div>
          <div className="flex items-center gap-1.5 self-start sm:self-auto bg-white/10 border border-white/10 px-3 py-1.5 rounded-xl">
            <span className="text-xs font-black text-blue-400">{step === 1 ? '1단계 기본 정보' : step === 2 ? '2단계 재무/신용' : '3단계 AI 매칭'}</span>
            <span className="text-xs text-white/40">/ 3단계</span>
          </div>
        </div>

        {/* Step Indicator Breadcrumb Cards (1단계 ➔ 2단계 ➔ 3단계) */}
        <div className="grid grid-cols-3 gap-2 sm:gap-3 mb-4">
          {[
            { num: 1, title: '1단계: 기본 정보', desc: '사업자 OCR / 마이데이터' },
            { num: 2, title: '2단계: 재무·신용 연동', desc: '매출 · 신용도 · 부채' },
            { num: 3, title: '3단계: AI 매칭 진단', desc: '희망자금 · 적격 판정' }
          ].map((item) => {
            const isActive = step === item.num;
            const isDone = step > item.num;
            return (
              <button
                key={item.num}
                type="button"
                onClick={() => {
                  if (item.num <= step) setStep(item.num);
                }}
                className={`p-2.5 sm:p-3 rounded-xl border text-left transition-all relative overflow-hidden ${
                  isActive
                    ? 'bg-blue-600/30 border-blue-400 ring-2 ring-blue-500/40 text-white'
                    : isDone
                      ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                      : 'bg-white/5 border-white/5 text-slate-400 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-[10px] sm:text-xs font-black ${isActive ? 'text-blue-300' : isDone ? 'text-emerald-400' : 'text-slate-400'}`}>
                    {item.title}
                  </span>
                  {isDone ? (
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                  ) : isActive ? (
                    <div className="w-2 h-2 rounded-full bg-blue-400 animate-ping" />
                  ) : null}
                </div>
                <p className="text-[10px] text-slate-300 truncate hidden sm:block font-medium">
                  {item.desc}
                </p>
              </button>
            );
          })}
        </div>

        {/* Animated Progress Track */}
        <div className="h-2 w-full bg-white/10 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-400 rounded-full"
            initial={{ width: `${((step - 1) / 3) * 100}%` }}
            animate={{ width: `${(step / 3) * 100}%` }}
            transition={{ duration: 0.5, ease: 'easeInOut' }}
          />
        </div>
      </div>

      <div className="px-6 sm:px-10 py-10 min-h-[480px]">
        <AnimatePresence mode="wait">
          {renderStep()}
        </AnimatePresence>
      </div>

      {/* Navigation Footer */}
      <div className="px-6 sm:px-10 py-6 bg-slate-50 border-t border-slate-100 flex justify-between items-center">
        {step > 1 ? (
          <button 
            type="button"
            onClick={handlePrev} 
            className="px-5 py-3.5 text-slate-600 font-black text-xs uppercase tracking-wider flex items-center gap-2 hover:text-slate-900 transition-colors bg-white border border-slate-200 rounded-xl hover:bg-slate-100"
          >
            <ArrowLeft className="w-4 h-4" /> 이전 단계
          </button>
        ) : <div />}
        
        {step < 3 ? (
          <button 
            type="button"
            onClick={handleNext} 
            className="px-8 py-3.5 bg-slate-900 text-white rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-2 hover:bg-slate-800 transition-all shadow-lg active:scale-95"
          >
            <span>다음 단계 ({step + 1}/3)</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        ) : (
          <button 
            type="button"
            onClick={handleSubmit} 
            disabled={isLoading} 
            className="px-9 py-3.5 bg-blue-600 text-white rounded-xl font-black text-xs uppercase tracking-wider flex items-center gap-2 hover:bg-blue-700 transition-all shadow-xl shadow-blue-500/20 active:scale-95 disabled:opacity-50"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <>AI 맞춤 매칭 시작 <TrendingUp className="w-4 h-4" /></>}
          </button>
        )}
      </div>

      {/* Custom Google Picker Modal */}
      {isDriveModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-100 flex flex-col max-h-[85vh]">
            <div className="bg-slate-900 text-white p-6 flex justify-between items-center">
              <div>
                <span className="text-[9px] font-black tracking-widest text-blue-400 uppercase">Google Picker Integration</span>
                <h3 className="text-xl font-bold flex items-center gap-2">
                  <span className="text-amber-400">▲</span> 구글 드라이브 탐색기
                </h3>
              </div>
              <button 
                type="button"
                onClick={() => setIsDriveModalOpen(false)}
                className="text-slate-400 hover:text-white font-bold text-xs bg-white/10 px-3 py-1.5 rounded-lg transition-colors"
              >
                닫기
              </button>
            </div>
            
            <div className="p-4 border-b border-slate-100 bg-slate-50">
              <input 
                type="text" 
                placeholder="파일명 검색..." 
                value={driveSearch} 
                onChange={(e) => {
                  setDriveSearch(e.target.value);
                  loadDriveFiles(e.target.value);
                }}
                className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl font-bold text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all font-sans"
              />
            </div>

            <div className="flex-grow overflow-y-auto p-4 custom-scroll max-h-[350px]">
              {isFetchingDrive ? (
                <div className="flex flex-col items-center justify-center py-12 gap-3">
                  <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
                  <span className="text-xs font-bold text-slate-500">드라이브를 탐색 중입니다...</span>
                </div>
              ) : driveFiles.length === 0 ? (
                <div className="text-center py-12 text-slate-400">
                  <p className="font-bold text-sm">드라이브에 분석 가능한 문서가 없습니다.</p>
                  <p className="text-[10px] mt-1 text-slate-400">TXT, PDF 등 텍스트 문서를 업로드해 보세요.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-2">
                  {driveFiles.map((file) => (
                    <button
                      key={file.id}
                      type="button"
                      onClick={() => handleSelectDriveFile(file)}
                      className="w-full flex items-center text-left p-3.5 hover:bg-slate-50 border border-transparent hover:border-slate-100 rounded-2xl transition-all group"
                    >
                      <div className="w-10 h-10 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center shrink-0 font-bold group-hover:scale-110 transition-transform">
                        📄
                      </div>
                      <div className="ml-3 overflow-hidden">
                        <p className="font-bold text-xs text-slate-900 truncate">{file.name}</p>
                        <p className="text-[9px] font-bold text-slate-400 mt-1 flex items-center gap-2">
                          <span>{new Date(file.createdTime).toLocaleDateString()}</span>
                          {file.size && <span>• {(parseInt(file.size) / 1024).toFixed(1)} KB</span>}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-100 text-[10px] font-bold text-slate-500 text-center flex items-center justify-center gap-2">
              <span className="text-emerald-500">●</span> Google Drive API v3 사용으로 실시간 보안 동기화
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
