import React, { useState, useMemo } from 'react';
import { 
  AlertTriangle, 
  Clock, 
  BellRing, 
  TrendingUp, 
  FileText, 
  Sparkles, 
  AlertCircle, 
  ChevronRight, 
  CheckCircle2, 
  Bookmark, 
  Calendar, 
  ExternalLink,
  ShieldAlert,
  ArrowRight,
  Info,
  RefreshCw,
  HelpCircle,
  FileCheck2,
  Headphones
} from 'lucide-react';
import { PolicyFund, SourcePolicy } from '../types';

export interface PolicyChangeAlert {
  id: string;
  fundId: string;
  fundTitle: string;
  agency: string;
  type: 'DEADLINE_URGENT' | 'CONTENT_CHANGED' | 'BUDGET_EXHAUSTION' | 'DOC_REVISED';
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  badgeLabel: string;
  headline: string;
  details: string;
  changeSummary?: {
    before?: string;
    after?: string;
    changedAt: string;
  };
  daysLeft?: number;
  originalFund?: PolicyFund | SourcePolicy | any;
}

interface FavoritePolicyChangesSummaryProps {
  favorites: (PolicyFund | SourcePolicy | any)[];
  onOpenConsultation?: (fund: any) => void;
  onOpenPdfChecklist?: (fund: any) => void;
  onScheduleCalendar?: (fund: any) => void;
  onSelectFund?: (fund: any) => void;
  onConfigurePush?: (fund: any) => void;
}

// Calculate days remaining helper
const getDaysRemaining = (endDateStr?: string): number => {
  if (!endDateStr) return 999;
  const now = new Date();
  const end = new Date(endDateStr);
  if (isNaN(end.getTime())) return 999;
  const diffTime = end.getTime() - now.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
};

// Known mock dynamic changes for policies (simulates government policy updates/amendments)
const MOCK_POLICY_CHANGES_MAP: Record<string, {
  type: 'CONTENT_CHANGED' | 'BUDGET_EXHAUSTION' | 'DOC_REVISED';
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  badgeLabel: string;
  headline: string;
  details: string;
  before?: string;
  after?: string;
  changedAt: string;
}> = {
  '소상공인 대환대출': {
    type: 'CONTENT_CHANGED',
    severity: 'WARNING',
    badgeLabel: '금리·한도 공고 변경',
    headline: '지원 한도 상향 및 적용 금리 0.3%p 추가 인하 개정',
    details: '중기부 2차 추가 공고에 따라 7% 이상 고금리 대출 대환 한도가 기존 5,000만원에서 1억원으로 상향 조정되었습니다.',
    before: '대출한도 5,000만원 / 고정금리 4.5%',
    after: '대출한도 최대 1억원 / 특별우대 4.2%',
    changedAt: '2026-08-18'
  },
  '중소기업 정책자금': {
    type: 'DOC_REVISED',
    severity: 'WARNING',
    badgeLabel: '필수 제출서류 변경',
    headline: '사업계획서 표준 양식 2026 개정본 필수 적용',
    details: 'ESG 및 스마트공장 지표 항목이 필수 제출 항목으로 신설되었습니다. 구버전 양식 제출 시 반려 처리될 수 있습니다.',
    before: '2025 표준 사업계획서 5p',
    after: '2026 스마트·ESG 개정 양식(별첨 3호)',
    changedAt: '2026-08-16'
  },
  '스마트공장 보급확산': {
    type: 'BUDGET_EXHAUSTION',
    severity: 'CRITICAL',
    badgeLabel: '예산 90% 소진 임박',
    headline: '2026년 하반기 정부 배정 예산 88% 조기 소진',
    details: '지자체별 배정 한도 소진율이 급증하여 당초 예정일보다 선착순 조기 마감될 가능성이 높습니다. 이번 주 내 신청을 권장합니다.',
    before: '정규 접수 기간 운영 중',
    after: '잔여 예산 12% 미만 (조기 마감 예고)',
    changedAt: '2026-08-19'
  },
  '청년창업사관학교': {
    type: 'CONTENT_CHANGED',
    severity: 'INFO',
    badgeLabel: '가점 요건 확대',
    headline: '지방 소재 청년기업 및 AI·딥테크 특화 가점(3점) 신설',
    details: '수도권 외 지역 본점 기업 또는 AI 특허 보유 기업 대상 1차 서류 심사 면제/가점 혜택이 확대 적용됩니다.',
    before: '일반 창업 가점 2점',
    after: 'AI/지방 특화 우대 가점 최대 5점',
    changedAt: '2026-08-14'
  }
};

export const FavoritePolicyChangesSummary: React.FC<FavoritePolicyChangesSummaryProps> = ({
  favorites,
  onOpenConsultation,
  onOpenPdfChecklist,
  onScheduleCalendar,
  onSelectFund,
  onConfigurePush,
}) => {
  const [filterType, setFilterType] = useState<'ALL' | 'URGENT' | 'CHANGED'>('ALL');
  const [isDismissed, setIsDismissed] = useState(false);

  // Generate dynamic change alerts based on user favorites
  const alerts: PolicyChangeAlert[] = useMemo(() => {
    if (!favorites || favorites.length === 0) return [];

    const list: PolicyChangeAlert[] = [];

    favorites.forEach((fund) => {
      const title = 'title' in fund ? fund.title : fund.name;
      const id = 'id' in fund ? fund.id : fund.name;
      const agency = fund.agency || '정책금융기관';
      const endDate = 'endDate' in fund ? fund.endDate : ('applicationDeadline' in fund ? fund.applicationDeadline : '');
      const daysLeft = getDaysRemaining(endDate);

      // 1. Check for 3-day Urgent Deadline Alert (D-Day ~ D-3)
      if (daysLeft >= 0 && daysLeft <= 3) {
        list.push({
          id: `alert-deadline-${id}`,
          fundId: id,
          fundTitle: title,
          agency,
          type: 'DEADLINE_URGENT',
          severity: daysLeft === 0 ? 'CRITICAL' : 'CRITICAL',
          badgeLabel: daysLeft === 0 ? '🚨 오늘 마감 D-DAY' : `⚠️ 마감 D-${daysLeft}일 임박`,
          headline: daysLeft === 0 
            ? `오늘 오후 18:00 접수가 최종 마감됩니다!` 
            : `접수 마감까지 단 ${daysLeft}일 남았습니다. 서류 검토가 시급합니다.`,
          details: `마감 시점에는 공공 포털(소진공/중진공/신보) 트래픽 폭주로 인한 접수 지연이 발생할 수 있으니 오늘 즉시 구비서류를 최종 업로드하세요.`,
          daysLeft,
          originalFund: fund
        });
      } else if (daysLeft > 3 && daysLeft <= 7) {
        // Warning for D-4 ~ D-7
        list.push({
          id: `alert-deadline-${id}`,
          fundId: id,
          fundTitle: title,
          agency,
          type: 'DEADLINE_URGENT',
          severity: 'WARNING',
          badgeLabel: `⏰ 마감 D-${daysLeft}일`,
          headline: `접수 마감 D-${daysLeft}일 전: 필수 공문서 사전 발급을 완료하세요.`,
          details: `국세/지방세 납세증명서, 부가가치세 표준증명 등 유효기간 1개월 이내 서류 사전 구비가 필수적입니다.`,
          daysLeft,
          originalFund: fund
        });
      }

      // 2. Check for Content/Eligibility/Budget Changes
      // Match by keyword or partial title in MOCK_POLICY_CHANGES_MAP
      let matchedChangeKey = Object.keys(MOCK_POLICY_CHANGES_MAP).find(k => title.includes(k));
      
      // If no direct keyword match, for demo/enrichment give 1 change per agency pattern
      if (!matchedChangeKey && (title.includes('보증') || title.includes('특례'))) {
        matchedChangeKey = '소상공인 대환대출';
      }

      if (matchedChangeKey) {
        const changeInfo = MOCK_POLICY_CHANGES_MAP[matchedChangeKey];
        list.push({
          id: `alert-change-${id}-${changeInfo.type}`,
          fundId: id,
          fundTitle: title,
          agency,
          type: changeInfo.type,
          severity: changeInfo.severity,
          badgeLabel: changeInfo.badgeLabel,
          headline: changeInfo.headline,
          details: changeInfo.details,
          changeSummary: {
            before: changeInfo.before,
            after: changeInfo.after,
            changedAt: changeInfo.changedAt
          },
          daysLeft: daysLeft < 999 ? daysLeft : undefined,
          originalFund: fund
        });
      }
    });

    // Sort by severity (CRITICAL first) then by days left
    return list.sort((a, b) => {
      if (a.severity === 'CRITICAL' && b.severity !== 'CRITICAL') return -1;
      if (b.severity === 'CRITICAL' && a.severity !== 'CRITICAL') return 1;
      return (a.daysLeft ?? 99) - (b.daysLeft ?? 99);
    });
  }, [favorites]);

  const urgentCount = alerts.filter(a => a.type === 'DEADLINE_URGENT' && (a.daysLeft !== undefined && a.daysLeft <= 3)).length;
  const contentChangeCount = alerts.filter(a => a.type !== 'DEADLINE_URGENT').length;

  const filteredAlerts = useMemo(() => {
    if (filterType === 'URGENT') {
      return alerts.filter(a => a.type === 'DEADLINE_URGENT');
    }
    if (filterType === 'CHANGED') {
      return alerts.filter(a => a.type !== 'DEADLINE_URGENT');
    }
    return alerts;
  }, [alerts, filterType]);

  if (favorites.length === 0) {
    return null;
  }

  if (isDismissed) {
    return (
      <div className="bg-slate-900 text-white px-5 py-3 rounded-2xl flex items-center justify-between shadow-md mb-6 animate-fade-in">
        <div className="flex items-center gap-2.5">
          <BellRing className="w-4 h-4 text-amber-400" />
          <span className="text-xs font-bold">
            내 관심 정책 변화 요약이 접혀있습니다. (감지된 변동/마감 알림: {alerts.length}건)
          </span>
        </div>
        <button
          onClick={() => setIsDismissed(false)}
          className="text-xs text-indigo-300 hover:text-white font-black underline cursor-pointer"
        >
          요약 펼치기
        </button>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-b from-slate-900 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-7 shadow-xl border border-indigo-900/50 mb-8 relative overflow-hidden">
      {/* Background ambient accents */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-72 h-72 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Section */}
      <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-5 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
            <span className="px-2.5 py-1 rounded-lg bg-rose-500/20 border border-rose-500/40 text-rose-300 text-xs font-black flex items-center gap-1.5 animate-pulse">
              <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
              실시간 상태 모니터링
            </span>

            {urgentCount > 0 && (
              <span className="px-2.5 py-0.5 rounded-full bg-rose-600 text-white text-[11px] font-black shadow-xs">
                🚨 3일 내 마감 임박 {urgentCount}건
              </span>
            )}

            {contentChangeCount > 0 && (
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/30 border border-amber-400/40 text-amber-300 text-[11px] font-black">
                📢 공고·요건 변경 {contentChangeCount}건
              </span>
            )}
          </div>

          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2.5">
            <span>내 관심 정책 변화 요약</span>
            <span className="text-xs font-bold text-slate-400 bg-white/10 px-2.5 py-1 rounded-full">
              총 {alerts.length}개 알림
            </span>
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 font-medium mt-1 leading-relaxed max-w-2xl">
            대표님이 즐겨찾기(스크랩)하신 정책자금의 <strong>마감 3일 전 긴급 경고</strong>, <strong>공고 내용 변경</strong>, <strong>예산 조기 소진</strong> 소식을 실시간으로 감지하여 안내합니다.
          </p>
        </div>

        {/* Filter Chips & Action */}
        <div className="flex items-center gap-2 shrink-0 flex-wrap sm:flex-nowrap">
          <div className="bg-black/30 p-1 rounded-2xl border border-white/10 flex items-center gap-1 text-xs">
            <button
              onClick={() => setFilterType('ALL')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                filterType === 'ALL'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              전체 ({alerts.length})
            </button>
            <button
              onClick={() => setFilterType('URGENT')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1 ${
                filterType === 'URGENT'
                  ? 'bg-rose-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Clock className="w-3 h-3" />
              마감임박 ({alerts.filter(a => a.type === 'DEADLINE_URGENT').length})
            </button>
            <button
              onClick={() => setFilterType('CHANGED')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center gap-1 ${
                filterType === 'CHANGED'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <RefreshCw className="w-3 h-3" />
              공고변동 ({contentChangeCount})
            </button>
          </div>

          <button
            type="button"
            onClick={() => setIsDismissed(true)}
            className="text-slate-400 hover:text-white p-2 rounded-xl bg-white/5 hover:bg-white/10 transition-colors text-xs font-bold cursor-pointer"
            title="요약 숨기기"
          >
            접기
          </button>
        </div>
      </div>

      {/* Alerts Grid / List */}
      {filteredAlerts.length === 0 ? (
        <div className="py-10 text-center space-y-2 relative z-10">
          <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center mx-auto text-emerald-400">
            <CheckCircle2 className="w-6 h-6" />
          </div>
          <p className="text-sm font-bold text-white">
            현재 조건에 해당하는 긴급 마감 또는 공고 변동 사항이 없습니다.
          </p>
          <p className="text-xs text-slate-400">
            모든 즐겨찾기 자금이 정상 접수 기간을 유지 중이며 서류 변경 사항이 없습니다.
          </p>
        </div>
      ) : (
        <div className="mt-5 grid grid-cols-1 lg:grid-cols-2 gap-4 relative z-10">
          {filteredAlerts.map((alert) => {
            const isDeadlineCritical = alert.type === 'DEADLINE_URGENT' && (alert.daysLeft !== undefined && alert.daysLeft <= 3);
            const isToday = alert.daysLeft === 0;

            return (
              <div
                key={alert.id}
                className={`rounded-2xl p-5 border transition-all flex flex-col justify-between relative overflow-hidden group ${
                  isDeadlineCritical
                    ? 'bg-gradient-to-br from-rose-950/70 via-slate-900 to-slate-900 border-rose-500/60 shadow-lg shadow-rose-950/40 ring-1 ring-rose-500/40'
                    : alert.severity === 'CRITICAL'
                      ? 'bg-gradient-to-br from-amber-950/60 via-slate-900 to-slate-900 border-amber-500/50 shadow-md ring-1 ring-amber-500/30'
                      : 'bg-white/5 hover:bg-white/[0.08] border-white/10'
                }`}
              >
                {/* Visual Highlight bar for urgent items */}
                {isDeadlineCritical && (
                  <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-rose-500 via-amber-400 to-rose-500 animate-pulse" />
                )}

                <div className="space-y-3">
                  {/* Top Badge & Agency */}
                  <div className="flex items-center justify-between gap-2 flex-wrap">
                    <div className="flex items-center gap-2">
                      <span className={`text-[11px] font-black px-2.5 py-1 rounded-lg flex items-center gap-1 ${
                        isDeadlineCritical
                          ? 'bg-rose-500 text-white animate-bounce'
                          : alert.type === 'CONTENT_CHANGED'
                            ? 'bg-indigo-500/30 border border-indigo-400/40 text-indigo-200'
                            : alert.type === 'BUDGET_EXHAUSTION'
                              ? 'bg-amber-500/30 border border-amber-400/40 text-amber-200'
                              : 'bg-blue-500/30 border border-blue-400/40 text-blue-200'
                      }`}>
                        {isDeadlineCritical ? <AlertTriangle className="w-3.5 h-3.5 text-white" /> : <RefreshCw className="w-3.5 h-3.5" />}
                        {alert.badgeLabel}
                      </span>

                      <span className="text-xs font-bold text-slate-400 bg-black/40 px-2.5 py-0.5 rounded-md border border-white/5">
                        {alert.agency}
                      </span>
                    </div>

                    {alert.changeSummary?.changedAt && (
                      <span className="text-[10px] text-slate-400 font-medium">
                        변동일: {alert.changeSummary.changedAt}
                      </span>
                    )}
                  </div>

                  {/* Fund Name & Headline */}
                  <div>
                    <span className="text-xs font-bold text-indigo-300 block truncate">
                      📌 {alert.fundTitle}
                    </span>
                    <h3 className={`text-sm sm:text-base font-black mt-1 leading-snug ${
                      isDeadlineCritical ? 'text-rose-200' : 'text-white'
                    }`}>
                      {alert.headline}
                    </h3>
                  </div>

                  {/* Details Description */}
                  <p className="text-xs text-slate-300 font-medium leading-relaxed bg-black/30 p-3 rounded-xl border border-white/5">
                    {alert.details}
                  </p>

                  {/* Before vs After Comparison Box if applicable */}
                  {alert.changeSummary && alert.changeSummary.before && alert.changeSummary.after && (
                    <div className="p-3 rounded-xl bg-indigo-950/60 border border-indigo-500/30 space-y-1.5 text-xs">
                      <div className="flex items-center gap-2 text-slate-400">
                        <span className="text-[10px] font-black uppercase text-slate-500 px-1.5 py-0.5 bg-black/40 rounded">변경 전</span>
                        <span className="line-through">{alert.changeSummary.before}</span>
                      </div>
                      <div className="flex items-center gap-2 text-emerald-300 font-bold">
                        <span className="text-[10px] font-black uppercase bg-emerald-500/30 text-emerald-300 border border-emerald-400/30 px-1.5 py-0.5 rounded">변경 후</span>
                        <span>{alert.changeSummary.after}</span>
                      </div>
                    </div>
                  )}
                </div>

                {/* Bottom Action Bar */}
                <div className="mt-4 pt-3.5 border-t border-white/10 flex items-center justify-between gap-2 flex-wrap">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {onOpenConsultation && alert.originalFund && (
                      <button
                        type="button"
                        onClick={() => onOpenConsultation(alert.originalFund)}
                        className="px-3 py-1.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white rounded-xl text-xs font-black shadow-md shadow-indigo-500/25 transition-all flex items-center gap-1 cursor-pointer active:scale-95"
                        title="전문가에게 변경 요건 및 서류 비대면 상담 신청"
                      >
                        <Headphones className="w-3.5 h-3.5" />
                        <span>전문가 상담</span>
                      </button>
                    )}

                    {onOpenPdfChecklist && alert.originalFund && (
                      <button
                        type="button"
                        onClick={() => onOpenPdfChecklist(alert.originalFund)}
                        className="px-2.5 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                        title="개정 공고문 PDF 체크리스트 분석"
                      >
                        <FileCheck2 className="w-3.5 h-3.5 text-blue-400" />
                        <span className="hidden sm:inline">PDF 체크</span>
                      </button>
                    )}

                    {onScheduleCalendar && alert.originalFund && (
                      <button
                        type="button"
                        onClick={() => onScheduleCalendar(alert.originalFund)}
                        className="px-2.5 py-1.5 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                        title="구글 캘린더 마감 알림 등록"
                      >
                        <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                        <span className="hidden sm:inline">캘린더</span>
                      </button>
                    )}
                  </div>

                  {onSelectFund && alert.originalFund && (
                    <button
                      type="button"
                      onClick={() => onSelectFund(alert.originalFund)}
                      className="px-3 py-1.5 bg-white text-slate-900 hover:bg-slate-100 rounded-xl text-xs font-black transition-colors flex items-center gap-1 cursor-pointer ml-auto"
                    >
                      <span>상세 가이드</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Bottom Summary Tip */}
      <div className="mt-5 p-3.5 rounded-2xl bg-indigo-500/10 border border-indigo-400/20 flex items-start gap-2.5 text-xs text-indigo-200 relative z-10">
        <Info className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <strong>💡 AI 상태 감지 안내:</strong> 즐겨찾기한 정책자금의 예산 조기 소진 및 마감 3일 전 임박 건은 자동 푸시 알림으로도 즉시 연동됩니다. 신청 전 변경된 필수 양식을 반드시 확인하세요.
        </div>
      </div>
    </div>
  );
};
