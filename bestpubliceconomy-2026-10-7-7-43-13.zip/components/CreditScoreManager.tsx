import React, { useState, useEffect, useMemo } from 'react';
import { 
  ShieldCheck, 
  TrendingUp, 
  Award, 
  AlertCircle, 
  CheckCircle2, 
  Sparkles, 
  HelpCircle, 
  ArrowRight, 
  ChevronRight, 
  Zap, 
  Sliders, 
  RotateCcw, 
  FileText, 
  DollarSign, 
  Percent, 
  CheckSquare, 
  Square, 
  Building2, 
  Info,
  TrendingDown,
  Clock,
  Shield,
  Lightbulb,
  ExternalLink,
  Target
} from 'lucide-react';
import { UserProfile, PolicyFund } from '../types';

interface CreditScoreManagerProps {
  profile?: UserProfile | null;
  onUpdateCreditScore?: (newScore: number) => void;
  onSelectFundDetails?: (fundTitle: string) => void;
}

interface ImprovementAction {
  id: string;
  title: string;
  category: '비금융납부' | '부채구조개선' | '카드한도관리' | '신용조회/습관' | '정책컨설팅';
  scoreBoost: number;
  timeframe: string;
  difficulty: '쉬움' | '보통' | '노력필요';
  description: string;
  howTo: string;
  targetAgencies: string[];
}

const IMPROVEMENT_ACTIONS: ImprovementAction[] = [
  {
    id: 'act-mydata',
    title: '마이데이터 비금융 성실납부 내역 즉시 제출',
    category: '비금융납부',
    scoreBoost: 25,
    timeframe: '즉시 (1~3일)',
    difficulty: '쉬움',
    description: '통신비, 국민건강보험료, 국민연금, 도시가스/전기요금을 6개월 이상 성실 납부한 내역을 KCB/NICE에 원클릭 전송합니다.',
    howTo: '카카오페이, 토스, 올크레딧, 나이스지키미 앱의 [신용점수 올리기] 메뉴에서 공동인증서/간편인증으로 즉시 제출 가능합니다.',
    targetAgencies: ['NICE평가정보', 'KCB(올크레딧)']
  },
  {
    id: 'act-debt-refinance',
    title: '2금융권 카드론·캐피탈 고금리 대출을 저리 정책자금으로 대환',
    category: '부채구조개선',
    scoreBoost: 45,
    timeframe: '1~2주',
    difficulty: '보통',
    description: '15~19%대 카드론/현금서비스/캐피탈 채무를 소상공인진흥공단 대환대출(연 4.5%대 고정/변동)로 전환하여 2금융권 여신 건수를 0건으로 만듭니다.',
    howTo: '소진공 [소상공인 대환대출] 또는 서민금융진흥원 [햇살론15] 신청 후 기존 고금리 채무를 즉시 전액 상환합니다.',
    targetAgencies: ['소상공인시장진흥공단', '서민금융진흥원']
  },
  {
    id: 'act-card-utilization',
    title: '신용카드 한도 이용률 30% 이하 유지 및 선결제 습관',
    category: '카드한도관리',
    scoreBoost: 30,
    timeframe: '1개월',
    difficulty: '쉬움',
    description: '신용카드 한도(예: 1,000만원) 대비 월 사용액을 300만원(30%) 이하로 유지하거나, 결제일 이전 선결제를 진행하여 한도 대비 부채비율을 낮춥니다.',
    howTo: '카드사 앱에서 총 한도를 최대로 상향 신청(사용액은 그대로 유지)하거나, 결제일 3~5일 전 수시 즉시결제를 실행하세요.',
    targetAgencies: ['전 카드사', 'KCB', 'NICE']
  },
  {
    id: 'act-debt-consolidation',
    title: '소액 분산 대출 조기 집중 상환 (대출 건수 다이어트)',
    category: '부채구조개선',
    scoreBoost: 20,
    timeframe: '1개월 이내',
    difficulty: '보통',
    description: '신용평가사는 대출 총액보다 "대출 건수(다중 채무)"에 더 큰 감점을 부여합니다. 300만원 이하 소액 대출부터 우선 완납하여 채무 건수를 줄입니다.',
    howTo: '금액이 가장 작은 대출부터 1건씩 완납하여 금융결제원 전산상 대출 보유 건수를 최소화하세요.',
    targetAgencies: ['금융기관 전반']
  },
  {
    id: 'act-policy-consulting',
    title: '신용보증재단 소상공인 신용회복 컨설팅 무료 이수',
    category: '정책컨설팅',
    scoreBoost: 15,
    timeframe: '1회 (2시간)',
    difficulty: '쉬움',
    description: '지역신용보증재단에서 주관하는 "소상공인 신용·재무 개선 무료 컨설팅"을 수료하면 보증 심사 시 가점(+5점) 및 수수료 0.2%p 감면을 받습니다.',
    howTo: '관할 지역신용보증재단 홈페이지 또는 소진공 지사에서 [소상공인 역량강화 컨설팅]을 온라인 접수하세요.',
    targetAgencies: ['지역신용보증재단', '중소벤처기업부']
  },
  {
    id: 'act-longterm-repay',
    title: '체크카드 월 30만원 이상 6개월 연속 사용 (가점 부여)',
    category: '신용조회/습관',
    scoreBoost: 15,
    timeframe: '3~6개월',
    difficulty: '쉬움',
    description: '체크카드를 매월 30만원 이상 6개월 이상 연속 사용하면 금융 이력 부족자(Thin Filer) 및 중신용자에게 최대 40점의 비금융 가점이 부여됩니다.',
    howTo: '주거래 은행 체크카드로 정기 결제나 생활비를 분산 결제하여 성실 체크카드 이용 실적을 누적하세요.',
    targetAgencies: ['NICE평가정보', 'KCB']
  }
];

export const CreditScoreManager: React.FC<CreditScoreManagerProps> = ({
  profile,
  onUpdateCreditScore,
  onSelectFundDetails,
}) => {
  // Initial score from profile or localStorage or default 735
  const [creditScore, setCreditScore] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('bizmatch_user_credit_score');
      if (saved) {
        const val = parseInt(saved, 10);
        if (!isNaN(val) && val >= 300 && val <= 1000) return val;
      }
    } catch {
      // fallback
    }
    return profile?.creditScore || 735;
  });

  const [activeTab, setActiveTab] = useState<'PREDICTION' | 'SIMULATION' | 'TIPS'>('PREDICTION');
  const [selectedActions, setSelectedActions] = useState<string[]>(['act-mydata', 'act-card-utilization']);
  const [scoreAgencyType, setScoreAgencyType] = useState<'KCB' | 'NICE'>('KCB');
  const [showSaveToast, setShowSaveToast] = useState(false);

  // Sync when profile prop changes
  useEffect(() => {
    if (profile?.creditScore && profile.creditScore !== creditScore) {
      // keep current if manually edited, or update if initial
    }
  }, [profile]);

  const handleScoreChange = (newVal: number) => {
    const clamped = Math.max(300, Math.min(1000, newVal));
    setCreditScore(clamped);
    try {
      localStorage.setItem('bizmatch_user_credit_score', clamped.toString());
    } catch (e) {
      console.error(e);
    }
    if (onUpdateCreditScore) {
      onUpdateCreditScore(clamped);
    }
    setShowSaveToast(true);
    setTimeout(() => setShowSaveToast(false), 2000);
  };

  const handleToggleAction = (id: string) => {
    setSelectedActions(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  // Credit Rating Tier Classification
  const scoreTierInfo = useMemo(() => {
    if (creditScore >= 850) {
      return {
        grade: '1~2등급 (최상위 고신용)',
        badge: '최우량 신용',
        badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-300',
        textColor: 'text-emerald-600',
        bgColor: 'bg-emerald-50',
        gaugePercent: Math.min(100, Math.round(((creditScore - 300) / 700) * 100)),
        description: '시중 1금융권 최저금리(3%대) 이차보전 및 신용보증재단/신보 전액 100% 보증 승인 최우선 대상입니다.',
        benchmarkText: '전국 사업자 상위 12% 이내'
      };
    } else if (creditScore >= 750) {
      return {
        grade: '3~4등급 (우량 신용)',
        badge: '우량 신용',
        badgeColor: 'bg-blue-100 text-blue-800 border-blue-300',
        textColor: 'text-blue-600',
        bgColor: 'bg-blue-50',
        gaugePercent: Math.min(100, Math.round(((creditScore - 300) / 700) * 100)),
        description: '대부분의 중진공 혁신자금, 소진공 일반자금 및 지역신보 특례보증(보증비율 90~95%)을 안정적으로 승인받을 수 있습니다.',
        benchmarkText: '전국 사업자 상위 35% 수준'
      };
    } else if (creditScore >= 650) {
      return {
        grade: '5~6등급 (중신용 보통)',
        badge: '중신용 / 관리 필요',
        badgeColor: 'bg-amber-100 text-amber-800 border-amber-300',
        textColor: 'text-amber-600',
        bgColor: 'bg-amber-50',
        gaugePercent: Math.min(100, Math.round(((creditScore - 300) / 700) * 100)),
        description: '소진공 희망플러스 특례보증 및 중신용자 전용 이차보전 자금에 적합합니다. 750점 진입 시 금리가 1.5%p 이상 대폭 인하됩니다.',
        benchmarkText: '전국 사업자 중위 50% 구간'
      };
    } else if (creditScore >= 550) {
      return {
        grade: '7~8등급 (저신용 주의)',
        badge: '저신용 특례 대상',
        badgeColor: 'bg-orange-100 text-orange-800 border-orange-300',
        textColor: 'text-orange-600',
        bgColor: 'bg-orange-50',
        gaugePercent: Math.min(100, Math.round(((creditScore - 300) / 700) * 100)),
        description: '1금융권 일반 대출은 제한되나, 정부 주관 [소상공인 대환대출] 및 [새출발기금 저신용 특례자금(839점 이하 전용)] 신청에 매우 유리합니다.',
        benchmarkText: '정책 지원 저신용 특례 전용 구간'
      };
    } else {
      return {
        grade: '9~10등급 (취약 신용)',
        badge: '집중 회복 지원 대상',
        badgeColor: 'bg-rose-100 text-rose-800 border-rose-300',
        textColor: 'text-rose-600',
        bgColor: 'bg-rose-50',
        gaugePercent: Math.min(100, Math.round(((creditScore - 300) / 700) * 100)),
        description: '서민금융진흥원 햇살론15, 새출발기금 채무조정 및 재도전 특별자금을 통해 신용회복과 고금리 채무 정리가 우선되어야 합니다.',
        benchmarkText: '긴급 채무조정 및 특례 구제 구간'
      };
    }
  }, [creditScore]);

  // Simulation calculations
  const totalSimulatedBoost = useMemo(() => {
    return selectedActions.reduce((sum, actionId) => {
      const act = IMPROVEMENT_ACTIONS.find(a => a.id === actionId);
      return sum + (act ? act.scoreBoost : 0);
    }, 0);
  }, [selectedActions]);

  const simulatedScore = useMemo(() => {
    return Math.min(1000, creditScore + totalSimulatedBoost);
  }, [creditScore, totalSimulatedBoost]);

  // Policy Fund Predictions Data based on current vs simulated score
  const policyFundPredictions = useMemo(() => {
    const calcApproval = (score: number, minScore: number, optScore: number, isLowScoreSpecial = false) => {
      if (isLowScoreSpecial) {
        // Specifically for low-credit relief funds (e.g. NCBC or Daewhan target < 839)
        if (score <= 839 && score >= 550) {
          return Math.min(95, Math.round(75 + (839 - score) * 0.06));
        } else if (score < 550) {
          return 60;
        } else {
          return Math.max(30, Math.round(90 - (score - 839) * 0.4)); // high score may not qualify for low-score exclusive
        }
      }

      if (score < minScore - 50) return 15;
      if (score < minScore) return Math.round(25 + ((score - (minScore - 50)) / 50) * 25);
      if (score >= optScore) return Math.min(98, 85 + Math.round(((score - optScore) / (1000 - optScore)) * 13));
      return Math.round(55 + ((score - minScore) / (optScore - minScore)) * 30);
    };

    const funds = [
      {
        id: 'fund-daewhan',
        name: '소상공인 대환대출 (중·저신용자 특화)',
        agency: '소상공인시장진흥공단',
        category: '고금리 채무 전환',
        minScore: 550,
        optScore: 720,
        isLowScoreExclusive: true,
        currentProb: calcApproval(creditScore, 550, 720, true),
        simulatedProb: calcApproval(simulatedScore, 550, 720, true),
        maxLimit: '최대 5,000만원',
        estRate: '연 4.5% (고정금리)',
        guaranteeRatio: '100% 직대/보증',
        criteriaDesc: 'NCB 839점 이하 또는 7% 이상 고금리 대출 보유 소상공인',
        benefitTag: '이자부담 연 12%p 절감'
      },
      {
        id: 'fund-shinbo-special',
        name: '지역신용보증재단 특례보증 (희망플러스)',
        agency: '지역신용보증재단',
        category: '운전자금 보증서',
        minScore: 680,
        optScore: 780,
        currentProb: calcApproval(creditScore, 680, 780),
        simulatedProb: calcApproval(simulatedScore, 680, 780),
        maxLimit: '최대 7,000만원',
        estRate: '연 3.2% ~ 4.1%',
        guaranteeRatio: '95% 부분보증',
        criteriaDesc: 'NICE/KCB 680점 이상 사업자 (780점 이상 시 심사 간소화)',
        benefitTag: '보증료율 0.5%p 우대'
      },
      {
        id: 'fund-sbc-startup',
        name: '중진공 혁신창업 사업화 특별자금',
        agency: '중소벤처기업진흥공단',
        category: '시설 및 운전자금',
        minScore: 720,
        optScore: 820,
        currentProb: calcApproval(creditScore, 720, 820),
        simulatedProb: calcApproval(simulatedScore, 720, 820),
        maxLimit: '최대 1억원 ~ 5억원',
        estRate: '연 2.8% ~ 3.5%',
        guaranteeRatio: '기관 직접 대출',
        criteriaDesc: '창업 7년 이내 및 신용도 우량(720점 이상) 유망 기업',
        benefitTag: '직접대출 무보증'
      },
      {
        id: 'fund-bank-interest-sub',
        name: '지자체-1금융권 이차보전 연계 협약대출',
        agency: '시중은행 & 지자체',
        category: '이자 차액 보전',
        minScore: 760,
        optScore: 850,
        currentProb: calcApproval(creditScore, 760, 850),
        simulatedProb: calcApproval(simulatedScore, 760, 850),
        maxLimit: '최대 2억원',
        estRate: '연 2.1% ~ 2.9% (이차보전 2.5%p 반영 후)',
        guaranteeRatio: '은행 신용/보증',
        criteriaDesc: '고신용(760점 이상) 사업자 대상 지자체 이자 2.0~3.0%p 직접 지원',
        benefitTag: '최저 2%대 초저금리'
      },
      {
        id: 'fund-general-semas',
        name: '소진공 일반경영안정자금',
        agency: '소상공인시장진흥공단',
        category: '경영 안정',
        minScore: 600,
        optScore: 740,
        currentProb: calcApproval(creditScore, 600, 740),
        simulatedProb: calcApproval(simulatedScore, 600, 740),
        maxLimit: '최대 7,000만원',
        estRate: '정책자금 기준금리 + 0.6%p',
        guaranteeRatio: '보증서 발급',
        criteriaDesc: '업력 1년 이상 상시근로자 5인 미만 소상공인',
        benefitTag: '상시 신청 가능'
      },
      {
        id: 'fund-sunshine-bank',
        name: '서민금융진흥원 햇살론뱅크 / 희망대출',
        agency: '서민금융진흥원',
        category: '신용회복 / 대환',
        minScore: 500,
        optScore: 680,
        isLowScoreExclusive: true,
        currentProb: calcApproval(creditScore, 500, 680, true),
        simulatedProb: calcApproval(simulatedScore, 500, 680, true),
        maxLimit: '최대 2,500만원',
        estRate: '연 4.9% ~ 7.5%',
        guaranteeRatio: '서금원 90% 보증',
        criteriaDesc: 'KCB 700점 이하 또는 NICE 749점 이하 성실상환자',
        benefitTag: '저신용자 전용 패스트트랙'
      }
    ];

    return funds;
  }, [creditScore, simulatedScore]);

  // Overall average probability
  const avgCurrentProbability = useMemo(() => {
    const sum = policyFundPredictions.reduce((acc, f) => acc + f.currentProb, 0);
    return Math.round(sum / policyFundPredictions.length);
  }, [policyFundPredictions]);

  const avgSimulatedProbability = useMemo(() => {
    const sum = policyFundPredictions.reduce((acc, f) => acc + f.simulatedProb, 0);
    return Math.round(sum / policyFundPredictions.length);
  }, [policyFundPredictions]);

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-100 overflow-hidden space-y-6">
      
      {/* Top Banner Header */}
      <div className="p-6 md:p-8 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white relative overflow-hidden">
        <div className="absolute right-0 top-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
        
        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-xs font-bold text-indigo-200 border border-white/10">
              <ShieldCheck className="w-3.5 h-3.5 text-indigo-300" />
              <span>MY 신용점수 정밀 진단 & 승인율 예측 센터</span>
            </div>
            <h2 className="text-xl md:text-2xl font-black text-white tracking-tight">
              신용평점 관리 & 정책자금 수혜 시뮬레이터
            </h2>
            <p className="text-xs md:text-sm text-slate-300 font-medium max-w-2xl leading-relaxed">
              대표님의 신용점수(KCB/NICE)를 기반으로 기관별 <strong>정책자금 승인 가능성을 실시간 예측</strong>하고, 
              <strong>점수 향상 팁 실천 시 기대 승인율과 금리 인하 혜택</strong>을 시뮬레이션합니다.
            </p>
          </div>

          {/* Quick Score Input Card in Header */}
          <div className="bg-white/10 backdrop-blur-md p-4 sm:p-5 rounded-2xl border border-white/15 w-full lg:w-auto shrink-0 space-y-3">
            <div className="flex items-center justify-between gap-4">
              <span className="text-xs font-black text-slate-200 flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-indigo-300" /> 신용평점 입력
              </span>
              <div className="flex items-center gap-1 bg-black/30 p-0.5 rounded-lg text-[10px] font-bold">
                <button
                  onClick={() => setScoreAgencyType('KCB')}
                  className={`px-2 py-0.5 rounded ${scoreAgencyType === 'KCB' ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}
                >
                  KCB(올크레딧)
                </button>
                <button
                  onClick={() => setScoreAgencyType('NICE')}
                  className={`px-2 py-0.5 rounded ${scoreAgencyType === 'NICE' ? 'bg-indigo-600 text-white' : 'text-slate-400'}`}
                >
                  NICE(지키미)
                </button>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="relative flex-1">
                <input
                  type="number"
                  min={300}
                  max={1000}
                  step={5}
                  value={creditScore}
                  onChange={(e) => handleScoreChange(parseInt(e.target.value, 10) || 300)}
                  className="w-full bg-white text-slate-900 font-black text-2xl px-4 py-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-400 text-center shadow-inner"
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400">점</span>
              </div>
              <span className={`px-3 py-2 rounded-xl text-xs font-black shrink-0 border ${scoreTierInfo.badgeColor}`}>
                {scoreTierInfo.badge}
              </span>
            </div>

            {/* Quick Step Buttons */}
            <div className="flex items-center justify-between gap-1.5 pt-1">
              <button
                onClick={() => handleScoreChange(creditScore - 10)}
                className="flex-1 py-1 bg-white/10 hover:bg-white/20 text-white text-[11px] font-bold rounded-lg transition-colors"
              >
                -10점
              </button>
              <button
                onClick={() => handleScoreChange(creditScore + 10)}
                className="flex-1 py-1 bg-white/10 hover:bg-white/20 text-white text-[11px] font-bold rounded-lg transition-colors"
              >
                +10점
              </button>
              <button
                onClick={() => handleScoreChange(creditScore + 50)}
                className="flex-1 py-1 bg-indigo-500/50 hover:bg-indigo-500 text-white text-[11px] font-bold rounded-lg transition-colors"
              >
                +50점
              </button>
            </div>

            {showSaveToast && (
              <p className="text-[10px] text-emerald-300 font-bold text-center animate-fade-in">
                ✓ 점수가 저장 및 동기화되었습니다
              </p>
            )}
          </div>
        </div>

        {/* Score Benchmark Slider & Range Indicator */}
        <div className="mt-6 pt-5 border-t border-white/10 space-y-2">
          <div className="flex items-center justify-between text-xs font-bold text-slate-300">
            <span>300점 (취약)</span>
            <span className="text-amber-300 font-black">650점 (중신용 기준)</span>
            <span className="text-blue-300 font-black">750점 (우량 기준)</span>
            <span className="text-emerald-300 font-black">850점 (고신용)</span>
            <span>1,000점 (만점)</span>
          </div>

          <div className="relative">
            <input
              type="range"
              min="300"
              max="1000"
              step="5"
              value={creditScore}
              onChange={(e) => handleScoreChange(parseInt(e.target.value, 10))}
              className="w-full h-2.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-indigo-400"
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
            <span>현재 등급 환산: <strong className="text-white">{scoreTierInfo.grade}</strong></span>
            <span>{scoreTierInfo.benchmarkText}</span>
          </div>
        </div>
      </div>

      {/* Main Tab Navigation */}
      <div className="px-6 md:px-8 border-b border-slate-100 flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <button
            onClick={() => setActiveTab('PREDICTION')}
            className={`px-4 py-3 text-xs md:text-sm font-black border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'PREDICTION'
                ? 'border-indigo-600 text-indigo-700 bg-indigo-50/50 rounded-t-xl'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Percent className="w-4 h-4" />
            <span>정책자금 승인 가능성 예측 ({avgCurrentProbability}%)</span>
          </button>
          <button
            onClick={() => setActiveTab('SIMULATION')}
            className={`px-4 py-3 text-xs md:text-sm font-black border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'SIMULATION'
                ? 'border-emerald-600 text-emerald-700 bg-emerald-50/50 rounded-t-xl'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <TrendingUp className="w-4 h-4 text-emerald-600" />
            <span>점수 상승 실천 시뮬레이터 (+{totalSimulatedBoost}점)</span>
          </button>
          <button
            onClick={() => setActiveTab('TIPS')}
            className={`px-4 py-3 text-xs md:text-sm font-black border-b-2 transition-all flex items-center gap-2 cursor-pointer ${
              activeTab === 'TIPS'
                ? 'border-amber-600 text-amber-700 bg-amber-50/50 rounded-t-xl'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <Lightbulb className="w-4 h-4 text-amber-600" />
            <span>신용점수 구간별 맞춤 가이드</span>
          </button>
        </div>

        <div className="text-[11px] font-bold text-slate-400 hidden md:flex items-center gap-1">
          <Info className="w-3.5 h-3.5" />
          <span>점수 변경 시 자동 반영</span>
        </div>
      </div>

      {/* TAB 1: Policy Fund Approval Probability Prediction */}
      {activeTab === 'PREDICTION' && (
        <div className="px-6 md:px-8 pb-8 space-y-6 animate-fade-in">
          
          {/* Diagnostic Summary Header */}
          <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200/80 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-black text-slate-800">대표님의 현재 신용점수 진단</span>
                <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border ${scoreTierInfo.badgeColor}`}>
                  {creditScore}점 · {scoreTierInfo.grade}
                </span>
              </div>
              <p className="text-xs text-slate-600 font-medium leading-relaxed">
                {scoreTierInfo.description}
              </p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <div className="text-right">
                <span className="text-[10px] font-bold text-slate-400 block">전체 평균 예측 승인율</span>
                <span className="text-2xl font-black text-indigo-600">{avgCurrentProbability}%</span>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-black text-sm border border-indigo-200">
                {avgCurrentProbability >= 80 ? 'A+' : avgCurrentProbability >= 65 ? 'B+' : 'C'}
              </div>
            </div>
          </div>

          {/* Grid of Policy Funds & Approval Probability */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {policyFundPredictions.map((fund) => {
              const isHigh = fund.currentProb >= 80;
              const isMed = fund.currentProb >= 60 && fund.currentProb < 80;
              const probColor = isHigh ? 'text-emerald-600' : isMed ? 'text-blue-600' : 'text-amber-600';
              const barColor = isHigh ? 'bg-emerald-500' : isMed ? 'bg-blue-500' : 'bg-amber-500';
              const statusText = isHigh ? '승인 유력' : isMed ? '신청 적합' : '보완 권장';
              const statusBadgeBg = isHigh ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : isMed ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-amber-50 text-amber-700 border-amber-200';

              return (
                <div 
                  key={fund.id}
                  className="bg-white rounded-2xl p-5 border border-slate-200 hover:border-indigo-300 hover:shadow-md transition-all space-y-4 flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-bold text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                        {fund.agency}
                      </span>
                      <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${statusBadgeBg}`}>
                        {statusText}
                      </span>
                    </div>

                    <h4 className="text-sm font-black text-slate-900 leading-snug">
                      {fund.name}
                    </h4>

                    <span className="inline-block text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                      ★ {fund.benefitTag}
                    </span>
                  </div>

                  {/* Probability Meter */}
                  <div className="space-y-1.5 bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-500">예측 승인 가능성</span>
                      <span className={`font-black text-base ${probColor}`}>
                        {fund.currentProb}%
                      </span>
                    </div>
                    <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-500 ${barColor}`}
                        style={{ width: `${fund.currentProb}%` }}
                      ></div>
                    </div>
                  </div>

                  {/* Fund Spec Metrics */}
                  <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-slate-100 text-slate-600">
                    <div>
                      <span className="text-[10px] text-slate-400 block font-bold">지원 한도</span>
                      <span className="font-black text-slate-800">{fund.maxLimit}</span>
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block font-bold">예상 금리</span>
                      <span className="font-black text-blue-600">{fund.estRate}</span>
                    </div>
                  </div>

                  <p className="text-[10px] text-slate-500 leading-relaxed font-medium bg-slate-50/70 p-2 rounded-lg">
                    {fund.criteriaDesc}
                  </p>

                  {onSelectFundDetails && (
                    <button
                      onClick={() => onSelectFundDetails(fund.name)}
                      className="w-full py-2 bg-slate-900 hover:bg-indigo-600 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <span>자금 상세 확인</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: Actionable Score Simulation & Improvement Roadmap */}
      {activeTab === 'SIMULATION' && (
        <div className="px-6 md:px-8 pb-8 space-y-6 animate-fade-in">
          
          {/* Comparison Result Banner */}
          <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-indigo-950 text-white p-6 rounded-2xl shadow-md space-y-4">
            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-300 bg-emerald-900/50 px-2.5 py-0.5 rounded-full border border-emerald-700">
                  <Sparkles className="w-3.5 h-3.5" /> 점수 향상 실천 가상 시뮬레이션
                </span>
                <h3 className="text-lg md:text-xl font-black text-white">
                  실천 과제 적용 시: <span className="text-emerald-400">{creditScore}점</span> ➔ <span className="text-amber-300 font-extrabold">{simulatedScore}점</span> (+{totalSimulatedBoost}점 상승)
                </h3>
                <p className="text-xs text-slate-300">
                  선택한 {selectedActions.length}개 개선 과제를 완료하면 평균 정책자금 승인 확률이 <strong>+{avgSimulatedProbability - avgCurrentProbability}%p</strong> 상승합니다.
                </p>
              </div>

              <div className="flex items-center gap-3 bg-white/10 p-3 rounded-2xl border border-white/10 shrink-0">
                <div className="text-center px-2">
                  <span className="text-[10px] text-slate-300 font-bold block">현재 승인율</span>
                  <span className="text-xl font-black text-slate-200">{avgCurrentProbability}%</span>
                </div>
                <ArrowRight className="w-4 h-4 text-emerald-400" />
                <div className="text-center px-2">
                  <span className="text-[10px] text-emerald-300 font-bold block">시뮬레이션 승인율</span>
                  <span className="text-xl font-black text-emerald-400">{avgSimulatedProbability}%</span>
                </div>
              </div>
            </div>

            {/* Quick Summary Highlights */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-white/10 text-xs">
              <div className="bg-white/5 p-2.5 rounded-xl">
                <span className="text-slate-400 text-[10px] block font-bold">추가 수혜 가능 자금</span>
                <span className="font-black text-white">
                  {policyFundPredictions.filter(f => f.simulatedProb >= 75 && f.currentProb < 75).length}개 자금 진입 가능
                </span>
              </div>
              <div className="bg-white/5 p-2.5 rounded-xl">
                <span className="text-slate-400 text-[10px] block font-bold">예상 금리 인하 폭</span>
                <span className="font-black text-emerald-300">
                  최대 연 0.8%p ~ 1.5%p 절감
                </span>
              </div>
              <div className="bg-white/5 p-2.5 rounded-xl">
                <span className="text-slate-400 text-[10px] block font-bold">보증재단 보증비율</span>
                <span className="font-black text-amber-300">
                  최대 95% ~ 100% 전액 보증
                </span>
              </div>
            </div>
          </div>

          {/* Action Checklist */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                <CheckSquare className="w-4 h-4 text-indigo-600" />
                <span>실천 가능한 신용점수 부스팅 과제 체크리스트</span>
              </h4>
              <span className="text-xs font-bold text-slate-500">
                선택 항목: <strong className="text-indigo-600">{selectedActions.length}</strong> / {IMPROVEMENT_ACTIONS.length}개
              </span>
            </div>

            <div className="space-y-3">
              {IMPROVEMENT_ACTIONS.map((action) => {
                const isSelected = selectedActions.includes(action.id);

                return (
                  <div
                    key={action.id}
                    onClick={() => handleToggleAction(action.id)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col md:flex-row items-start md:items-center justify-between gap-4 ${
                      isSelected
                        ? 'bg-emerald-50/60 border-emerald-300 shadow-xs'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start gap-3.5">
                      <button type="button" className="mt-0.5 text-emerald-600 shrink-0">
                        {isSelected ? (
                          <CheckSquare className="w-5 h-5 fill-emerald-600 text-white" />
                        ) : (
                          <Square className="w-5 h-5 text-slate-300" />
                        )}
                      </button>

                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-black text-slate-900">
                            {action.title}
                          </span>
                          <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                            {action.category}
                          </span>
                          <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                            소요 기간: {action.timeframe}
                          </span>
                        </div>
                        <p className="text-xs text-slate-600 font-medium leading-relaxed">
                          {action.description}
                        </p>
                        <p className="text-[11px] text-slate-500 bg-white/80 p-2 rounded-lg border border-slate-200/60 font-medium">
                          💡 <strong>실천 방법:</strong> {action.howTo}
                        </p>
                      </div>
                    </div>

                    <div className="flex md:flex-col items-end justify-between w-full md:w-auto shrink-0 gap-1 border-t md:border-t-0 pt-2 md:pt-0 border-slate-200">
                      <div className="text-right">
                        <span className="text-[10px] font-bold text-slate-400 block">예상 상승</span>
                        <span className="text-base font-black text-emerald-600">+{action.scoreBoost}점</span>
                      </div>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        action.difficulty === '쉬움' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                      }`}>
                        난이도 {action.difficulty}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quick Realization Call to action */}
          <div className="bg-indigo-50 p-4 rounded-2xl border border-indigo-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2.5 text-indigo-900 font-bold">
              <Zap className="w-4 h-4 text-amber-500 shrink-0" />
              <span>시뮬레이션된 점수({simulatedScore}점)를 현재 점수로 확정 저장하시겠습니까?</span>
            </div>
            <button
              onClick={() => handleScoreChange(simulatedScore)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-xl transition-all shadow-sm active:scale-95 shrink-0 cursor-pointer"
            >
              시뮬레이션 점수로 적용
            </button>
          </div>
        </div>
      )}

      {/* TAB 3: Credit Score Tier Guidelines & Strategies */}
      {activeTab === 'TIPS' && (
        <div className="px-6 md:px-8 pb-8 space-y-6 animate-fade-in">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Guide 1: High Credit */}
            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-emerald-500"></span>
                <h4 className="text-sm font-black text-slate-900">
                  고신용 구간 (850점 이상) 극대화 전략
                </h4>
              </div>
              <ul className="text-xs text-slate-600 space-y-2 font-medium leading-relaxed list-disc pl-4">
                <li><strong>금리인하요구권 적극 행사:</strong> 기존 1금융권 대출에 대해 점수 상승을 근거로 금리 인하를 정기 신청하세요.</li>
                <li><strong>지자체 이차보전 자금 최우선 접수:</strong> 지자체에서 이자 2~3%p를 지원하는 협약 대출로 2%대 실부담 금리를 확보하세요.</li>
                <li><strong>신용보증기금/기술보증기금 직접 보증:</strong> 보증료율 감면(최대 0.3%p) 및 100% 전액 보증 혜택을 수령하세요.</li>
              </ul>
            </div>

            {/* Guide 2: Mid-High Credit */}
            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-blue-500"></span>
                <h4 className="text-sm font-black text-slate-900">
                  중상위 구간 (750점 ~ 849점) 도약 전략
                </h4>
              </div>
              <ul className="text-xs text-slate-600 space-y-2 font-medium leading-relaxed list-disc pl-4">
                <li><strong>2금융권 대출 전면 차단:</strong> 카드론 및 캐피탈 대출 조회가 1회라도 발생 시 30~50점 급락하므로 절대 자제하세요.</li>
                <li><strong>신용카드 한도 대비 30% 유지:</strong> 한도 상향 후 월 결제액을 적정 비율로 통제하여 부채 이용률 평가 가점을 챙기세요.</li>
                <li><strong>중진공 혁신창업자금 신청:</strong> 750점 이상 시 중진공 융자 심사에서 신용평가 감점 없이 사업계획서 기술성 평가를 받습니다.</li>
              </ul>
            </div>

            {/* Guide 3: Mid Credit */}
            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-amber-500"></span>
                <h4 className="text-sm font-black text-slate-900">
                  중신용 구간 (650점 ~ 749점) 회복 전략
                </h4>
              </div>
              <ul className="text-xs text-slate-600 space-y-2 font-medium leading-relaxed list-disc pl-4">
                <li><strong>비금융 성실납부 마이데이터 제출:</strong> 통신비/건보료 6개월 납부 내역 즉시 전송으로 20~30점 단기 상승을 노리세요.</li>
                <li><strong>소상공인 대환대출 신청:</strong> 7% 이상 고금리 대출을 4.5%대 정책자금으로 대환하여 다중채무를 일원화하세요.</li>
                <li><strong>지역신보 소상공인 특례보증:</strong> 보증비율 90% 이상 우대 보증서를 발급받아 1금융권 취급을 성사시키세요.</li>
              </ul>
            </div>

            {/* Guide 4: Low Credit */}
            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 space-y-3">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-rose-500"></span>
                <h4 className="text-sm font-black text-slate-900">
                  저신용·취약 구간 (649점 이하) 구제 전략
                </h4>
              </div>
              <ul className="text-xs text-slate-600 space-y-2 font-medium leading-relaxed list-disc pl-4">
                <li><strong>소진공 저신용 특례 전용 자금:</strong> NCB 839점 이하 소상공인만을 대상으로 배정된 전용 융자 트랙을 공략하세요.</li>
                <li><strong>새출발기금 및 서민금융진흥원 채무조정:</strong> 고금리 원리금 상환 부담을 최대 3년 거치 10년 분할상환으로 재조정하세요.</li>
                <li><strong>체크카드 정기 사용으로 얇은 이력 극복:</strong> 매월 30만원 이상 체크카드를 6개월 이상 사용하여 금융거래 점수를 쌓으세요.</li>
              </ul>
            </div>
          </div>

          {/* Institutional Credit Rating Notice */}
          <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl text-xs text-amber-900 space-y-1.5">
            <div className="flex items-center gap-1.5 font-black">
              <AlertCircle className="w-4 h-4 text-amber-600" />
              <span>정책금융기관의 신용평가 심사 유의사항</span>
            </div>
            <p className="leading-relaxed font-medium">
              신용보증재단, 소상공인진흥공단, 중진공 등 정부 정책금융기관은 단순 개인신용점수(CB) 외에도 <strong>대표자의 국세/지방세 체납 여부, 사업장 매출 추이, 사업계획서의 진정성</strong>을 종합 평가합니다. 신용점수가 다소 낮더라도 정부 대환대출이나 특례보증 트랙을 통해 충분히 승인이 가능합니다.
            </p>
          </div>
        </div>
      )}

    </div>
  );
};
