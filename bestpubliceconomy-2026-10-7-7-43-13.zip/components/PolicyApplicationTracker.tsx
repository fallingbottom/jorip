import React, { useState, useEffect, useMemo } from 'react';
import { 
  PolicyFund, 
  SourcePolicy, 
  UserProfile, 
  ApplicationStage, 
  PolicyApplicationTrackerItem 
} from '../types';
import { 
  CheckCircle2, 
  Clock, 
  FileCheck2, 
  Send, 
  Building2, 
  AlertCircle, 
  Plus, 
  Trash2, 
  Edit3, 
  ChevronRight, 
  ChevronDown, 
  ChevronUp, 
  Calendar, 
  HelpCircle, 
  Sparkles, 
  Award, 
  CheckSquare, 
  Square, 
  RotateCcw, 
  FileText, 
  Headphones, 
  ExternalLink, 
  Phone, 
  ArrowRight,
  TrendingUp,
  Banknote,
  ShieldCheck,
  Briefcase,
  Lightbulb,
  AlertTriangle,
  Info,
  BookOpen,
  ShieldAlert,
  X
} from 'lucide-react';

interface PolicyApplicationTrackerProps {
  favorites: (PolicyFund | SourcePolicy)[];
  profile?: UserProfile | null;
  onOpenConsultation?: (fund: any) => void;
  onOpenPdfChecklist?: (fund: any) => void;
  onOpenDocGuide?: (fundTitle?: string) => void;
  onScheduleCalendar?: (fund: any) => void;
}

const STAGES_CONFIG: {
  key: ApplicationStage;
  step: number;
  label: string;
  shortLabel: string;
  description: string;
  averageDays: string;
  color: string;
  badgeBg: string;
  badgeText: string;
  borderCol: string;
  proTip: string;
  corePreparations: { title: string; desc: string; mustCheck: boolean }[];
  commonMistakes: { mistake: string; consequence: string; solution: string }[];
}[] = [
  {
    key: 'PREPARING',
    step: 1,
    label: '1단계: 신청 준비 & 자격검토',
    shortLabel: '신청 준비',
    description: '공고문 확인, 자격 요건 자가진단 및 신청 경로 결정',
    averageDays: '1~3일 소요',
    color: 'slate',
    badgeBg: 'bg-slate-100',
    badgeText: 'text-slate-700',
    borderCol: 'border-slate-300',
    proTip: '신청 전 국세·지방세 체납 여부와 대표자 신용점수(NICE/KCB)를 우선 확인하세요.',
    corePreparations: [
      {
        title: '신청 자격 요건 사전 확인',
        desc: '업력(창업 3년/7년 이내), 업종 제한(유흥·도박·부동산임대 등 제외), 연매출 기준 검토',
        mustCheck: true
      },
      {
        title: '세금 체납 및 연체 기록 정리',
        desc: '국세·지방세 완납 증명 가능 여부 및 최근 3개월 이내 단기 연체 여부 점검',
        mustCheck: true
      },
      {
        title: '공동인증서(사업자/개인) 준비',
        desc: '소진공 또는 지역신용보증재단 온라인 포털 회원가입 및 본인 인증 수단 확보',
        mustCheck: false
      }
    ],
    commonMistakes: [
      {
        mistake: '사설 브로커/불법 컨설팅 대행 수수료 계약',
        consequence: '공공기관 적발 시 신청 취소 및 향후 3~5년간 정부 지원 사업 참여 제한',
        solution: '정책자금은 공공기관 직접 신청이 원칙이며 대행 수수료 요구 업체는 즉시 차단하세요.'
      },
      {
        mistake: '체납 사실을 모른 채 바로 온라인 접수 진행',
        consequence: '전산 스크래핑 단계에서 즉시 자동 탈락 처리',
        solution: '홈택스와 위택스에서 완납증명서를 사전 조회하고 체납액 완납 후 2~3일 뒤 접수하세요.'
      }
    ]
  },
  {
    key: 'DOCS_SUBMITTED',
    step: 2,
    label: '2단계: 필수 서류 제출',
    shortLabel: '서류 제출',
    description: '사업자등록증, 과세표준, 완납증명 등 온/오프라인 접수 완료',
    averageDays: '2~5일 소요',
    color: 'blue',
    badgeBg: 'bg-blue-100',
    badgeText: 'text-blue-700',
    borderCol: 'border-blue-300',
    proTip: '모든 공문서는 발급일 1개월 이내, 주민번호 뒷자리 공개로 발급해야 보완 요청이 없습니다.',
    corePreparations: [
      {
        title: '발급일자 30일 이내 최신 서류 구비',
        desc: '사업자등록증명원, 부가세과세표준(최근 1~2년), 국세·지방세 납세증명서 등',
        mustCheck: true
      },
      {
        title: '주민등록번호 뒷자리 전체 공개 발급',
        desc: '금융기관 및 보증재단 심사용 서류는 마스킹(별표) 없이 전체 출력 필수',
        mustCheck: true
      },
      {
        title: '사업장 임대차계약서 일치 여부 확인',
        desc: '계약서 상 임차인 성명과 사업자등록증상 대표자 성명 및 사업장 주소 일치',
        mustCheck: true
      }
    ],
    commonMistakes: [
      {
        mistake: '주민등록번호 뒷자리 마스킹(별표) 서류 제출',
        consequence: '서류 반려 및 재발급 보완 요청으로 심사 일정 5~10일 지연',
        solution: '정부24 및 홈택스 발급 시 "주민등록번호 뒷자리 공개", 제출용도 "금융기관용"으로 선택하세요.'
      },
      {
        mistake: '과거 폐업한 사업장의 부가세 증명서 오첨부',
        consequence: '매출액 산정 오류로 신청 한도 축소 또는 부적격 판정',
        solution: '현재 신청하는 사업자등록번호와 동일한 사업장의 과세표준증명원인지 재확인하세요.'
      }
    ]
  },
  {
    key: 'UNDER_REVIEW',
    step: 3,
    label: '3단계: 기관 심사 & 실사 대기',
    shortLabel: '심사 대기',
    description: '보증재단/소진공 심사평가, 현장 실사 및 매출·신용도 확인',
    averageDays: '7~14일 소요',
    color: 'amber',
    badgeBg: 'bg-amber-100',
    badgeText: 'text-amber-800',
    borderCol: 'border-amber-300',
    proTip: '심사 기간 중 신규 고금리 대출(카드론, 현금서비스)을 받으면 신용점수 하락으로 승인 거절될 수 있습니다.',
    corePreparations: [
      {
        title: '자금 사용 목적 명확한 설명 준비',
        desc: '원자재 구매, 매장 시설 개선, 인건비 지급 등 구체적인 지출 계획 답변 준비',
        mustCheck: true
      },
      {
        title: '사업장 현장 실사 대비 영업 환경 점검',
        desc: '외부 간판, 사업장 내 정상 영업 상태, 주거래 매출 통장 거래내역 준비',
        mustCheck: true
      },
      {
        title: '심사관 전화 응대 및 보완 서류 당일 대응',
        desc: '지역번호(02, 031 등) 확인 전화 수신 대기 및 요청 서류 24시간 내 제출',
        mustCheck: false
      }
    ],
    commonMistakes: [
      {
        mistake: '심사 기간 중 제2금융권 대출 및 카드론 이용',
        consequence: '기관 최종 전산 조회 시 신용점수 급락으로 사전 승인 건도 최종 부결',
        solution: '대출 실행 및 자금 입금 완료 시점까지는 추가 대출 조회를 전면 중단하세요.'
      },
      {
        mistake: '자금 용도를 "단순 생활비나 개인 부채 상환"으로 진술',
        consequence: '사업 목적 외 자금 운용으로 판단되어 심사 감점 또는 부적격 처리',
        solution: '"원자재 선구매 및 비수기 운영자금", "신규 메뉴 개발 및 마케팅비" 등 사업 목적을 명확히 하세요.'
      }
    ]
  },
  {
    key: 'APPROVED',
    step: 4,
    label: '4단계: 보증서 발급 & 승인 완료',
    shortLabel: '승인 완료',
    description: '전자보증서 발급 완료 또는 소진공 직접대출 승인 통보',
    averageDays: '1~3일 소요',
    color: 'indigo',
    badgeBg: 'bg-indigo-100',
    badgeText: 'text-indigo-700',
    borderCol: 'border-indigo-300',
    proTip: '보증서 유효기간(보통 30~60일) 내에 협약 은행에서 대출 약정을 반드시 완료해야 합니다.',
    corePreparations: [
      {
        title: '전자보증서 발급 승인 문자/공문 확인',
        desc: '승인 보증금액, 보증비율(85~100%), 보증료율 확인',
        mustCheck: true
      },
      {
        title: '보증료 납부용 결제 계좌 잔액 준비',
        desc: '보증서 발급 시 발생하는 보증료(통상 대출액의 연 0.5~1.0%) 계좌 예치',
        mustCheck: true
      },
      {
        title: '취급 협약 은행 사전 지정 및 우대금리 확인',
        desc: '기업/신한/국민/우리/농협/하나 등 주거래 은행 모바일 앱 또는 창구 지정',
        mustCheck: false
      }
    ],
    commonMistakes: [
      {
        mistake: '보증서 유효기간(30~60일) 도과 방치',
        consequence: '발급된 전자보증서 자동 효력 상실로 대출 취소 및 1단계부터 재신청 필요',
        solution: '승인 문자를 받자마자 3영업일 이내에 지정 은행 모바일 약정을 완료하세요.'
      },
      {
        mistake: '보증료 납부 계좌 잔액 부족',
        consequence: '보증서가 은행으로 전송되지 않아 은행 대출 심사 미진행',
        solution: '안내받은 보증료 금액을 확인 후 해당 출금 계좌에 여유 있게 잔액을 입금해 두세요.'
      }
    ]
  },
  {
    key: 'DISBURSED',
    step: 5,
    label: '5단계: 대출 약정 & 자금 수령',
    shortLabel: '자금 수령',
    description: '협약 시중은행 대출 약정 체결 및 사업장 계좌 입금 완료',
    averageDays: '당일~2일 소요',
    color: 'emerald',
    badgeBg: 'bg-emerald-100',
    badgeText: 'text-emerald-800',
    borderCol: 'border-emerald-300',
    proTip: '대출금은 사업용 계좌로 수령 후 사용 증빙(세금계산서, 이체증)을 사후관리용으로 보관하세요.',
    corePreparations: [
      {
        title: '은행 전자대출 약정서 체결 (모바일/방문)',
        desc: '은행 앱에서 대출 실행 버튼 클릭 및 원리금 자동이체 계좌 등록',
        mustCheck: true
      },
      {
        title: '지자체 이차보전(이자지원) 연계 확인',
        desc: '시·도 조례에 따른 연 1.5~3.0% 이자 환급 또는 자동 감면 적용 확인',
        mustCheck: true
      },
      {
        title: '자금 집행 증빙자료 보관 (사후관리)',
        desc: '물품 구매 세금계산서, 임차료 이체증 등 정책자금 용도 증빙철 마련',
        mustCheck: false
      }
    ],
    commonMistakes: [
      {
        mistake: '입금된 정책자금을 즉시 개인 통장으로 전액 이체',
        consequence: '보증기관 사후 모니터링 시 정책자금 유용(개인 유용)으로 조기 회수 조치',
        solution: '사업용 계좌에서 사업 관련 거래처나 인건비, 임차료 계좌로 직접 송금하세요.'
      },
      {
        mistake: '이자 납입일 미확인으로 인한 단기 연체 발생',
        consequence: '지자체 이차보전 혜택 즉시 박탈 및 신용도 악영향',
        solution: '자동이체 계좌 잔고를 수시 확인하고 알림 서비스를 등록해 두세요.'
      }
    ]
  }
];

const DEFAULT_REQUIRED_DOCS = [
  '사업자등록증명원 (최근 1개월 이내)',
  '부가가치세과세표준증명원 (최근 1~2개년)',
  '국세 납세증명서 (홈택스 발급)',
  '지방세 납세증명서 (정부24/위택스 발급)',
  '소득금액증명원 (종합소득세/법인세)',
  '4대보험 사업장 가입자명부 (해당 시)',
  '사업장 및 거주지 임대차계약서 사본',
];

const STORAGE_KEY = 'bizmatch_application_trackers_v1';

export const PolicyApplicationTracker: React.FC<PolicyApplicationTrackerProps> = ({
  favorites = [],
  profile,
  onOpenConsultation,
  onOpenPdfChecklist,
  onOpenDocGuide,
  onScheduleCalendar,
}) => {
  // Application Trackers list state with localStorage
  const [trackers, setTrackers] = useState<PolicyApplicationTrackerItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    return [];
  });

  // Save to LocalStorage
  const saveTrackers = (items: PolicyApplicationTrackerItem[]) => {
    setTrackers(items);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch (e) {
      console.error(e);
    }
  };

  // Modal State for adding new tracked application
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedFundIdForAdd, setSelectedFundIdForAdd] = useState<string>('');
  const [customFundTitle, setCustomFundTitle] = useState('');
  const [customAgency, setCustomAgency] = useState('');
  const [customTargetAmount, setCustomTargetAmount] = useState('5,000만원');
  const [customAppNumber, setCustomAppNumber] = useState('');
  const [customBranch, setCustomBranch] = useState('');
  const [customOfficerContact, setCustomOfficerContact] = useState('');
  const [startStage, setStartStage] = useState<ApplicationStage>('DOCS_SUBMITTED');

  // Active expanded item id for editing details
  const [expandedTrackerId, setExpandedTrackerId] = useState<string | null>(null);

  // New Memo input state keyed by tracker id
  const [memoInputs, setMemoInputs] = useState<Record<string, string>>({});

  // Guidance Modal & Tooltip states
  const [isMasterGuideModalOpen, setIsMasterGuideModalOpen] = useState(false);
  const [guideModalStage, setGuideModalStage] = useState<ApplicationStage>('DOCS_SUBMITTED');
  const [activeGuideCardTabs, setActiveGuideCardTabs] = useState<Record<string, 'PREP' | 'MISTAKES'>>({});
  const [activeStepperTooltip, setActiveStepperTooltip] = useState<{ trackerId: string; stageKey: ApplicationStage } | null>(null);

  // Populate first tracker automatically if favorites exist and user has no trackers
  const handleAddSampleTracker = () => {
    const today = new Date().toISOString().split('T')[0];
    const initialFund = favorites.length > 0 
      ? ('title' in favorites[0] ? favorites[0].title : favorites[0].name)
      : '2026년 소상공인 경영안정 바우처 및 특례보증';
    const initialAgency = favorites.length > 0 ? favorites[0].agency : '지역신용보증재단';

    const sampleItem: PolicyApplicationTrackerItem = {
      id: `track-${Date.now()}`,
      fundId: favorites.length > 0 ? ('id' in favorites[0] ? favorites[0].id : favorites[0].name) : 'sample-1',
      fundTitle: initialFund,
      agency: initialAgency,
      stage: 'UNDER_REVIEW',
      appliedDate: today,
      updatedDate: today,
      targetAmount: '5,000만원 (연 2.8% 이차보전)',
      applicationNumber: `APP-${new Date().getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`,
      assignedBranch: '서울신용보증재단 강남지점',
      officerContact: '02-2174-5000 (기업심사팀)',
      submittedDocs: [
        '사업자등록증명원 (최근 1개월 이내)',
        '부가가치세과세표준증명원 (최근 1~2개년)',
        '국세 납세증명서 (홈택스 발급)',
        '지방세 납세증명서 (정부24/위택스 발급)',
      ],
      notes: [
        {
          id: 'n-1',
          date: today,
          content: '온라인 서류 4종 제출 완료. 심사팀 현장 실사 일정 조율 대기 중'
        }
      ],
      expectedApprovalDate: '2026-08-28'
    };

    saveTrackers([sampleItem, ...trackers]);
    setExpandedTrackerId(sampleItem.id);
  };

  // Add from favorites or custom
  const handleCreateTracker = () => {
    let title = customFundTitle;
    let agency = customAgency;
    let fundId = selectedFundIdForAdd || `custom-${Date.now()}`;

    if (selectedFundIdForAdd) {
      const found = favorites.find(f => ('id' in f ? f.id : f.name) === selectedFundIdForAdd);
      if (found) {
        title = 'title' in found ? found.title : found.name;
        agency = found.agency;
      }
    }

    if (!title) {
      alert('신청을 진행할 정책자금을 선택하거나 자금명을 입력해 주세요.');
      return;
    }

    const today = new Date().toISOString().split('T')[0];
    const newItem: PolicyApplicationTrackerItem = {
      id: `track-${Date.now()}`,
      fundId,
      fundTitle: title,
      agency: agency || '중소벤처기업부/소진공',
      stage: startStage,
      appliedDate: today,
      updatedDate: today,
      targetAmount: customTargetAmount || '5,000만원',
      applicationNumber: customAppNumber || `APP-${new Date().getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`,
      assignedBranch: customBranch || `${agency || '소상공인'} 관할 접수센터`,
      officerContact: customOfficerContact,
      submittedDocs: [
        '사업자등록증명원 (최근 1개월 이내)',
        '부가가치세과세표준증명원 (최근 1~2개년)'
      ],
      notes: [
        {
          id: `n-${Date.now()}`,
          date: today,
          content: `신청 단계 [${STAGES_CONFIG.find(s => s.key === startStage)?.shortLabel}]로 신규 등록 완료`
        }
      ]
    };

    saveTrackers([newItem, ...trackers]);
    setIsAddModalOpen(false);
    setSelectedFundIdForAdd('');
    setCustomFundTitle('');
    setCustomAgency('');
    setCustomAppNumber('');
    setExpandedTrackerId(newItem.id);
  };

  // 1-Click Track from a specific favorite fund
  const handleQuickAddFromFavorite = (fund: PolicyFund | SourcePolicy) => {
    const fId = 'id' in fund ? fund.id : fund.name;
    const fTitle = 'title' in fund ? fund.title : fund.name;
    const today = new Date().toISOString().split('T')[0];

    // Check if already tracked
    const existing = trackers.find(t => t.fundTitle === fTitle || t.fundId === fId);
    if (existing) {
      setExpandedTrackerId(existing.id);
      return;
    }

    const newItem: PolicyApplicationTrackerItem = {
      id: `track-${Date.now()}`,
      fundId: fId,
      fundTitle: fTitle,
      agency: fund.agency,
      stage: 'DOCS_SUBMITTED',
      appliedDate: today,
      updatedDate: today,
      targetAmount: 'maxAmount' in fund ? fund.maxAmount : '5,000만원',
      applicationNumber: `APP-${new Date().getFullYear()}-${Math.floor(100000 + Math.random() * 900000)}`,
      assignedBranch: `${fund.agency} 관할지점`,
      submittedDocs: [
        '사업자등록증명원 (최근 1개월 이내)',
        '부가가치세과세표준증명원 (최근 1~2개년)'
      ],
      notes: [
        {
          id: `n-${Date.now()}`,
          date: today,
          content: '즐겨찾기에서 신청 진행 건으로 등록되었습니다. 서류 구비 상태를 점검하세요.'
        }
      ]
    };

    saveTrackers([newItem, ...trackers]);
    setExpandedTrackerId(newItem.id);
  };

  // Update Stage
  const handleUpdateStage = (trackerId: string, newStage: ApplicationStage) => {
    const today = new Date().toISOString().split('T')[0];
    const stageMeta = STAGES_CONFIG.find(s => s.key === newStage);

    const updated = trackers.map(item => {
      if (item.id === trackerId) {
        return {
          ...item,
          stage: newStage,
          updatedDate: today,
          notes: [
            {
              id: `n-${Date.now()}`,
              date: today,
              content: `진행 상태가 [${stageMeta?.shortLabel || newStage}] (으)로 변경되었습니다.`
            },
            ...item.notes
          ]
        };
      }
      return item;
    });

    saveTrackers(updated);
  };

  // Toggle submitted document
  const handleToggleDoc = (trackerId: string, docName: string) => {
    const updated = trackers.map(item => {
      if (item.id === trackerId) {
        const exists = item.submittedDocs.includes(docName);
        const newDocs = exists 
          ? item.submittedDocs.filter(d => d !== docName)
          : [...item.submittedDocs, docName];
        return {
          ...item,
          submittedDocs: newDocs,
          updatedDate: new Date().toISOString().split('T')[0]
        };
      }
      return item;
    });
    saveTrackers(updated);
  };

  // Add Note/Memo
  const handleAddMemo = (trackerId: string) => {
    const content = memoInputs[trackerId]?.trim();
    if (!content) return;

    const today = new Date().toISOString().split('T')[0];
    const updated = trackers.map(item => {
      if (item.id === trackerId) {
        return {
          ...item,
          notes: [
            {
              id: `n-${Date.now()}`,
              date: today,
              content
            },
            ...item.notes
          ]
        };
      }
      return item;
    });

    saveTrackers(updated);
    setMemoInputs({ ...memoInputs, [trackerId]: '' });
  };

  // Delete Tracker
  const handleDeleteTracker = (trackerId: string, title: string) => {
    if (window.confirm(`'${title}' 신청 진행 트래킹을 목록에서 삭제하시겠습니까?`)) {
      saveTrackers(trackers.filter(t => t.id !== trackerId));
      if (expandedTrackerId === trackerId) {
        setExpandedTrackerId(null);
      }
    }
  };

  // Calculate elapsed days
  const getElapsedDays = (dateStr: string) => {
    try {
      const applyDate = new Date(dateStr);
      const now = new Date();
      const diffTime = Math.abs(now.getTime() - applyDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      return diffDays;
    } catch {
      return 1;
    }
  };

  // Summary Metrics
  const stats = useMemo(() => {
    const total = trackers.length;
    const preparing = trackers.filter(t => t.stage === 'PREPARING').length;
    const submitted = trackers.filter(t => t.stage === 'DOCS_SUBMITTED').length;
    const underReview = trackers.filter(t => t.stage === 'UNDER_REVIEW').length;
    const approved = trackers.filter(t => t.stage === 'APPROVED').length;
    const disbursed = trackers.filter(t => t.stage === 'DISBURSED').length;
    const active = submitted + underReview;

    return { total, preparing, submitted, underReview, approved, disbursed, active };
  }, [trackers]);

  // Listen for track fund custom event from other components
  useEffect(() => {
    const handleTrackFundEvent = (e: any) => {
      const fund = e.detail;
      if (fund) {
        handleQuickAddFromFavorite(fund);
        const el = document.getElementById('policy-application-tracker-section');
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }
    };

    window.addEventListener('bizmatch_track_fund' as any, handleTrackFundEvent);
    return () => {
      window.removeEventListener('bizmatch_track_fund' as any, handleTrackFundEvent);
    };
  }, [trackers, favorites]);

  return (
    <div id="policy-application-tracker-section" className="bg-white rounded-3xl p-6 md:p-8 border border-slate-100 shadow-sm space-y-6">
      {/* Tracker Top Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-50 text-emerald-700 rounded-full text-xs font-black mb-2 border border-emerald-100">
            <TrendingUp className="w-3.5 h-3.5" /> 실시간 지원금 신청 모니터링
          </div>
          <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            정책자금 신청 단계별 진행 상황 트래커
          </h2>
          <p className="text-xs text-slate-500 font-medium mt-1">
            즐겨찾기한 자금의 서류 제출부터 심사 대기, 보증서 발급, 최종 자금 수령까지의 전 과정을 실시간으로 관리하세요.
          </p>
        </div>

        <div className="flex items-center gap-2 self-stretch sm:self-center flex-wrap sm:flex-nowrap">
          <button
            onClick={() => {
              setGuideModalStage('DOCS_SUBMITTED');
              setIsMasterGuideModalOpen(true);
            }}
            className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs border border-slate-200"
            title="모든 단계별 핵심 준비사항 및 실수 방지 팁 가이드북 열기"
          >
            <BookOpen className="w-4 h-4 text-indigo-600" />
            <span>단계별 심사 가이드</span>
          </button>

          {trackers.length === 0 ? (
            <button
              onClick={handleAddSampleTracker}
              className="px-3.5 py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-xs rounded-xl transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs"
              title="샘플 트래커 데이터 불러오기"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
              <span>샘플 트래커 등록</span>
            </button>
          ) : null}

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="flex-1 sm:flex-none px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl transition-all shadow-md shadow-emerald-500/20 active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>신청 진행 등록</span>
          </button>
        </div>
      </div>

      {/* Stats Summary Cards Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-center">
          <span className="text-[10px] font-black text-slate-400 block mb-0.5">1단계 신청준비</span>
          <div className="flex items-center justify-center gap-1 text-slate-700 font-black text-base">
            <Square className="w-4 h-4 text-slate-400" />
            <span>{stats.preparing}건</span>
          </div>
        </div>

        <div className="bg-blue-50/70 p-3.5 rounded-2xl border border-blue-100 text-center">
          <span className="text-[10px] font-black text-blue-500 block mb-0.5">2단계 서류제출</span>
          <div className="flex items-center justify-center gap-1 text-blue-700 font-black text-base">
            <Send className="w-4 h-4 text-blue-600" />
            <span>{stats.submitted}건</span>
          </div>
        </div>

        <div className="bg-amber-50/70 p-3.5 rounded-2xl border border-amber-200 text-center ring-1 ring-amber-200/50">
          <span className="text-[10px] font-black text-amber-700 block mb-0.5">3단계 심사대기</span>
          <div className="flex items-center justify-center gap-1 text-amber-900 font-black text-base">
            <Clock className="w-4 h-4 text-amber-600 animate-pulse" />
            <span>{stats.underReview}건</span>
          </div>
        </div>

        <div className="bg-indigo-50/70 p-3.5 rounded-2xl border border-indigo-100 text-center">
          <span className="text-[10px] font-black text-indigo-500 block mb-0.5">4단계 승인완료</span>
          <div className="flex items-center justify-center gap-1 text-indigo-700 font-black text-base">
            <Award className="w-4 h-4 text-indigo-600" />
            <span>{stats.approved}건</span>
          </div>
        </div>

        <div className="col-span-2 sm:col-span-1 bg-emerald-50/80 p-3.5 rounded-2xl border border-emerald-200 text-center">
          <span className="text-[10px] font-black text-emerald-700 block mb-0.5">5단계 자금수령</span>
          <div className="flex items-center justify-center gap-1 text-emerald-900 font-black text-base">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{stats.disbursed}건</span>
          </div>
        </div>
      </div>

      {/* Main Trackers List */}
      {trackers.length === 0 ? (
        /* Empty State */
        <div className="bg-slate-50/70 rounded-3xl p-8 border border-dashed border-slate-200 text-center space-y-4">
          <div className="w-14 h-14 bg-emerald-50 rounded-2xl flex items-center justify-center mx-auto text-emerald-600 shadow-2xs">
            <FileCheck2 className="w-7 h-7" />
          </div>
          <div className="max-w-md mx-auto space-y-1">
            <h3 className="text-base font-black text-slate-900">
              현재 트래킹 중인 정책자금 신청 내역이 없습니다
            </h3>
            <p className="text-xs text-slate-500 font-medium leading-relaxed">
              관심 정책자금의 서류를 접수하셨거나 신청을 준비 중이신가요? 즐겨찾기한 자금을 선택하여 단계별 진행 상황을 실시간으로 추적하세요.
            </p>
          </div>

          {favorites.length > 0 && (
            <div className="pt-2 max-w-xl mx-auto">
              <div className="text-[11px] font-black text-slate-400 mb-2">
                💡 즐겨찾기한 자금 중 원클릭으로 신청 트래킹 시작:
              </div>
              <div className="flex flex-wrap items-center justify-center gap-2">
                {favorites.slice(0, 3).map((f) => {
                  const title = 'title' in f ? f.title : f.name;
                  return (
                    <button
                      key={title}
                      onClick={() => handleQuickAddFromFavorite(f)}
                      className="px-3 py-1.5 bg-white hover:bg-emerald-50 text-slate-800 hover:text-emerald-700 border border-slate-200 hover:border-emerald-300 rounded-xl text-xs font-bold transition-all shadow-2xs flex items-center gap-1.5"
                    >
                      <Plus className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="max-w-[180px] truncate">{title}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Active Trackers List */
        <div className="space-y-6">
          {trackers.map((item) => {
            const currentStageObj = STAGES_CONFIG.find(s => s.key === item.stage) || STAGES_CONFIG[0];
            const currentStep = currentStageObj.step;
            const isExpanded = expandedTrackerId === item.id;
            const elapsedDays = getElapsedDays(item.appliedDate);
            const progressPercent = Math.round((currentStep / 5) * 100);

            return (
              <div
                key={item.id}
                className={`bg-white rounded-3xl border transition-all shadow-xs overflow-hidden ${
                  item.stage === 'APPROVED' || item.stage === 'DISBURSED'
                    ? 'border-emerald-200 ring-1 ring-emerald-100'
                    : item.stage === 'UNDER_REVIEW'
                    ? 'border-amber-200 shadow-sm ring-1 ring-amber-100'
                    : 'border-slate-200 hover:border-slate-300'
                }`}
              >
                {/* Tracker Card Top Banner */}
                <div className="p-5 md:p-6 bg-gradient-to-r from-slate-50/80 via-white to-slate-50/50 border-b border-slate-100">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                    <div className="space-y-1.5">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-[10px] font-black uppercase px-2.5 py-0.5 bg-slate-100 text-slate-700 rounded-lg flex items-center gap-1">
                          <Building2 className="w-3 h-3 text-slate-400" /> {item.agency}
                        </span>
                        {item.applicationNumber && (
                          <span className="text-[10px] font-bold text-slate-400 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                            접수번호: {item.applicationNumber}
                          </span>
                        )}
                        <span className={`text-[11px] font-black px-2.5 py-0.5 rounded-full ${currentStageObj.badgeBg} ${currentStageObj.badgeText} border border-current/20 shadow-2xs`}>
                          {currentStageObj.label}
                        </span>
                      </div>

                      <h3 className="text-lg font-black text-slate-900 leading-snug">
                        {item.fundTitle}
                      </h3>

                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 font-medium">
                        <span>🗓️ 신청일: <strong className="text-slate-700 font-bold">{item.appliedDate}</strong> ({elapsedDays}일차 경과)</span>
                        {item.targetAmount && (
                          <span>💰 목표액: <strong className="text-emerald-700 font-bold">{item.targetAmount}</strong></span>
                        )}
                        {item.assignedBranch && (
                          <span>🏢 관할: <strong className="text-slate-700 font-bold">{item.assignedBranch}</strong></span>
                        )}
                      </div>
                    </div>

                    {/* Progress Percentage Gauge & Expand Toggle */}
                    <div className="flex items-center gap-3 self-end md:self-center">
                      <div className="text-right">
                        <div className="text-base font-black text-slate-900">
                          진행률 <span className="text-emerald-600">{progressPercent}%</span>
                        </div>
                        <div className="text-[10px] font-bold text-slate-400">
                          {currentStep} / 5단계 완료
                        </div>
                      </div>

                      <button
                        onClick={() => setExpandedTrackerId(isExpanded ? null : item.id)}
                        className="px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <span>{isExpanded ? '간략히' : '진행 관리'}</span>
                        {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>

                  {/* 5-Step Visual Stepper Bar */}
                  <div className="mt-5 pt-4 border-t border-slate-100">
                    <div className="relative">
                      {/* Connecting Line */}
                      <div className="absolute top-4 left-4 right-4 h-1 bg-slate-100 -z-0 rounded-full">
                        <div 
                          className="h-full bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-500 rounded-full transition-all duration-500"
                          style={{ width: `${((currentStep - 1) / 4) * 100}%` }}
                        />
                      </div>

                      {/* Step Bubbles */}
                      <div className="grid grid-cols-5 relative z-10">
                        {STAGES_CONFIG.map((stage) => {
                          const isDone = stage.step < currentStep;
                          const isCurrent = stage.step === currentStep;
                          const isFuture = stage.step > currentStep;
                          const isTooltipActive = activeStepperTooltip?.trackerId === item.id && activeStepperTooltip?.stageKey === stage.key;

                          return (
                            <div
                              key={stage.key}
                              className="relative flex flex-col items-center group text-center px-0.5"
                              onMouseEnter={() => setActiveStepperTooltip({ trackerId: item.id, stageKey: stage.key })}
                              onMouseLeave={() => setActiveStepperTooltip(null)}
                            >
                              <button
                                type="button"
                                onClick={() => handleUpdateStage(item.id, stage.key)}
                                className="flex flex-col items-center cursor-pointer focus:outline-none w-full"
                                title={`${stage.label} (클릭하여 이 상태로 변경)`}
                              >
                                <div className={`w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                                  isDone
                                    ? 'bg-emerald-600 text-white shadow-2xs'
                                    : isCurrent
                                    ? 'bg-indigo-600 text-white ring-4 ring-indigo-100 shadow-md scale-110'
                                    : 'bg-white border-2 border-slate-200 text-slate-400 group-hover:border-slate-400'
                                }`}>
                                  {isDone ? (
                                    <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
                                  ) : isCurrent ? (
                                    <Clock className="w-4 h-4 animate-pulse" />
                                  ) : (
                                    <span className="text-xs font-black">{stage.step}</span>
                                  )}
                                </div>

                                <span className={`text-[11px] mt-2 font-black transition-colors ${
                                  isCurrent 
                                    ? 'text-indigo-900 font-black' 
                                    : isDone 
                                    ? 'text-emerald-700' 
                                    : 'text-slate-400 group-hover:text-slate-600'
                                }`}>
                                  {stage.shortLabel}
                                </span>
                                <span className="text-[9px] text-slate-400 hidden sm:inline-block mt-0.5">
                                  {stage.averageDays}
                                </span>
                              </button>

                              {/* Hover / Active Stage Quick Tooltip Popover */}
                              {isTooltipActive && (
                                <div className="absolute top-12 z-40 w-64 p-3.5 bg-slate-900 text-white text-left rounded-2xl shadow-xl border border-slate-700 animate-fade-in pointer-events-auto transform -translate-x-1/2 left-1/2 mt-1">
                                  <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 mb-2">
                                    <span className="text-xs font-black text-emerald-400 flex items-center gap-1">
                                      <Lightbulb className="w-3.5 h-3.5" />
                                      {stage.label}
                                    </span>
                                    <span className="text-[9px] px-1.5 py-0.5 bg-slate-800 text-slate-300 rounded font-bold">
                                      {stage.averageDays}
                                    </span>
                                  </div>

                                  <div className="space-y-2 text-[11px] leading-snug">
                                    <div>
                                      <strong className="text-emerald-300 font-bold block mb-0.5">🎯 핵심 준비사항:</strong>
                                      <p className="text-slate-300 text-[10px] pl-1.5 border-l-2 border-emerald-500/60">
                                        {stage.corePreparations[0]?.title}
                                      </p>
                                    </div>
                                    <div>
                                      <strong className="text-rose-300 font-bold block mb-0.5">⚠️ 흔히 하는 실수:</strong>
                                      <p className="text-slate-300 text-[10px] pl-1.5 border-l-2 border-rose-500/60">
                                        {stage.commonMistakes[0]?.mistake}
                                      </p>
                                    </div>
                                  </div>

                                  <div className="mt-2.5 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px]">
                                    <span className="text-slate-400">클릭 시 단계 변경</span>
                                    <button
                                      type="button"
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        setGuideModalStage(stage.key);
                                        setIsMasterGuideModalOpen(true);
                                      }}
                                      className="text-indigo-400 hover:text-indigo-300 font-bold underline cursor-pointer"
                                    >
                                      가이드북 전체보기 →
                                    </button>
                                  </div>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Expanded Details & Management Tools */}
                {isExpanded && (
                  <div className="p-5 md:p-6 bg-white space-y-6 animate-fade-in border-t border-slate-100">
                    {/* Stage Status Insight Banner */}
                    <div className={`p-4 rounded-2xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs ${
                      currentStep >= 4 
                        ? 'bg-emerald-50/80 border-emerald-200 text-emerald-950'
                        : currentStep === 3
                        ? 'bg-amber-50/80 border-amber-200 text-amber-950'
                        : 'bg-blue-50/80 border-blue-200 text-blue-950'
                    }`}>
                      <div className="flex items-start gap-2.5">
                        <div className="p-1.5 bg-white rounded-xl shadow-2xs shrink-0 mt-0.5">
                          {currentStep >= 4 ? (
                            <Award className="w-4 h-4 text-emerald-600" />
                          ) : currentStep === 3 ? (
                            <Clock className="w-4 h-4 text-amber-600" />
                          ) : (
                            <FileText className="w-4 h-4 text-blue-600" />
                          )}
                        </div>
                        <div className="space-y-0.5">
                          <div className="font-black text-sm">{currentStageObj.label}</div>
                          <p className="font-medium opacity-90">{currentStageObj.description}</p>
                        </div>
                      </div>

                      {/* Quick stage switch buttons */}
                      <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-center">
                        {currentStep > 1 && (
                          <button
                            onClick={() => handleUpdateStage(item.id, STAGES_CONFIG[currentStep - 2].key)}
                            className="px-2.5 py-1 bg-white/80 hover:bg-white text-slate-700 rounded-lg text-xs font-bold border border-slate-200"
                          >
                            ◀ 이전 단계
                          </button>
                        )}
                        {currentStep < 5 && (
                          <button
                            onClick={() => handleUpdateStage(item.id, STAGES_CONFIG[currentStep].key)}
                            className="px-3 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-black shadow-xs"
                          >
                            다음 단계로 갱신 ▶
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Dedicated Stage Core Preparation & Mistake Prevention Card */}
                    <div className="bg-slate-50/90 rounded-2xl p-4 md:p-5 border border-slate-200/80 space-y-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200/80 pb-3">
                        <div className="flex items-center gap-2">
                          <div className="p-1.5 bg-indigo-600 text-white rounded-lg shadow-2xs">
                            <Lightbulb className="w-4 h-4" />
                          </div>
                          <div>
                            <h4 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                              <span>[{currentStageObj.shortLabel}] 핵심 준비 사항 & 실수 방지 가이드</span>
                            </h4>
                            <p className="text-[11px] text-slate-500 font-medium">
                              심사관 감점 요소를 사전에 차단하고 승인률을 높이는 실전 체크포인트입니다.
                            </p>
                          </div>
                        </div>

                        {/* Tabs switch: Preparations vs Mistakes */}
                        <div className="flex items-center bg-white p-1 rounded-xl border border-slate-200 self-start sm:self-center shadow-2xs">
                          <button
                            type="button"
                            onClick={() => setActiveGuideCardTabs({ ...activeGuideCardTabs, [item.id]: 'PREP' })}
                            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                              (activeGuideCardTabs[item.id] || 'PREP') === 'PREP'
                                ? 'bg-indigo-600 text-white shadow-xs'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>핵심 준비 ({currentStageObj.corePreparations.length})</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setActiveGuideCardTabs({ ...activeGuideCardTabs, [item.id]: 'MISTAKES' })}
                            className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                              activeGuideCardTabs[item.id] === 'MISTAKES'
                                ? 'bg-rose-600 text-white shadow-xs'
                                : 'text-slate-600 hover:text-slate-900'
                            }`}
                          >
                            <AlertTriangle className="w-3.5 h-3.5" />
                            <span>흔히 하는 실수 ({currentStageObj.commonMistakes.length})</span>
                          </button>
                        </div>
                      </div>

                      {/* Tab Content 1: Core Preparations Checklist */}
                      {(activeGuideCardTabs[item.id] || 'PREP') === 'PREP' && (
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 animate-fade-in">
                          {currentStageObj.corePreparations.map((prep, idx) => (
                            <div 
                              key={idx} 
                              className="bg-white p-3.5 rounded-xl border border-slate-200/90 space-y-1.5 shadow-2xs hover:border-indigo-200 transition-colors"
                            >
                              <div className="flex items-start justify-between gap-1.5">
                                <span className="text-xs font-black text-slate-900 flex items-center gap-1">
                                  <CheckSquare className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                                  {prep.title}
                                </span>
                                {prep.mustCheck ? (
                                  <span className="text-[9px] font-black px-1.5 py-0.5 bg-rose-50 text-rose-700 border border-rose-200 rounded shrink-0">
                                    필수 확인
                                  </span>
                                ) : (
                                  <span className="text-[9px] font-bold px-1.5 py-0.5 bg-slate-100 text-slate-600 rounded shrink-0">
                                    권장 사항
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-slate-600 font-medium leading-relaxed">
                                {prep.desc}
                              </p>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Tab Content 2: Common Mistakes & Traps */}
                      {activeGuideCardTabs[item.id] === 'MISTAKES' && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 animate-fade-in">
                          {currentStageObj.commonMistakes.map((mistakeItem, idx) => (
                            <div 
                              key={idx} 
                              className="bg-white p-4 rounded-xl border border-rose-200/80 space-y-2.5 shadow-2xs"
                            >
                              <div className="flex items-start gap-2">
                                <div className="p-1 bg-rose-100 text-rose-700 rounded-md shrink-0 mt-0.5">
                                  <ShieldAlert className="w-3.5 h-3.5" />
                                </div>
                                <div className="space-y-0.5">
                                  <span className="text-[10px] font-black text-rose-600 uppercase tracking-wide">
                                    위험 실수 #{idx + 1}
                                  </span>
                                  <h5 className="text-xs font-black text-slate-900 leading-snug">
                                    {mistakeItem.mistake}
                                  </h5>
                                </div>
                              </div>

                              <div className="p-2 bg-rose-50/70 rounded-lg border border-rose-100 text-[11px] text-rose-900 leading-relaxed font-medium">
                                <strong className="font-bold text-rose-950 block mb-0.5">💥 발생 결과 / 불이익:</strong>
                                {mistakeItem.consequence}
                              </div>

                              <div className="p-2 bg-emerald-50/80 rounded-lg border border-emerald-200 text-[11px] text-emerald-950 leading-relaxed font-medium">
                                <strong className="font-bold text-emerald-900 block mb-0.5">🛡️ 해결책 & 사전 대처법:</strong>
                                {mistakeItem.solution}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Pro-tip Footer Bar */}
                      <div className="pt-2 border-t border-slate-200/70 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs">
                        <div className="flex items-center gap-1.5 text-slate-700 font-medium text-[11px]">
                          <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                          <span><strong>심사관 Pro-Tip:</strong> {currentStageObj.proTip}</span>
                        </div>

                        <button
                          type="button"
                          onClick={() => {
                            setGuideModalStage(item.stage);
                            setIsMasterGuideModalOpen(true);
                          }}
                          className="text-[11px] font-black text-indigo-600 hover:text-indigo-800 flex items-center gap-0.5 cursor-pointer ml-auto sm:ml-0"
                        >
                          <span>전체 5단계 종합 가이드북 보기</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    {/* 2-Column: Submitted Documents Tracker & Action Log / Memos */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {/* Left: Required Documents Checklist */}
                      <div className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                            <FileCheck2 className="w-4 h-4 text-emerald-600" />
                            필수 제출 서류 체크리스트 ({item.submittedDocs.length}/{DEFAULT_REQUIRED_DOCS.length})
                          </h4>
                          {onOpenDocGuide && (
                            <button
                              onClick={() => onOpenDocGuide(item.fundTitle)}
                              className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-0.5"
                            >
                              <span>발급 가이드</span>
                              <ExternalLink className="w-3 h-3" />
                            </button>
                          )}
                        </div>

                        <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
                          {DEFAULT_REQUIRED_DOCS.map((docName) => {
                            const isChecked = item.submittedDocs.includes(docName);
                            return (
                              <button
                                key={docName}
                                type="button"
                                onClick={() => handleToggleDoc(item.id, docName)}
                                className={`w-full text-left p-2 rounded-xl text-xs font-medium transition-all flex items-center gap-2 cursor-pointer border ${
                                  isChecked
                                    ? 'bg-emerald-50/80 border-emerald-200 text-emerald-900'
                                    : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                                }`}
                              >
                                {isChecked ? (
                                  <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                                ) : (
                                  <Square className="w-4 h-4 text-slate-300 shrink-0" />
                                )}
                                <span className={isChecked ? 'font-bold line-through opacity-80' : ''}>
                                  {docName}
                                </span>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Right: Memo & Action Logs */}
                      <div className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-100 flex flex-col justify-between">
                        <div className="space-y-2">
                          <h4 className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                            <Edit3 className="w-4 h-4 text-indigo-600" />
                            신청 메모 & 진행 히스토리
                          </h4>

                          {/* Quick Memo Input */}
                          <div className="flex gap-2">
                            <input
                              type="text"
                              value={memoInputs[item.id] || ''}
                              onChange={(e) => setMemoInputs({ ...memoInputs, [item.id]: e.target.value })}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleAddMemo(item.id);
                              }}
                              placeholder="예: 8/20 심사관 통화, 부가세 수정본 팩스 송부 완료"
                              className="flex-1 px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                            />
                            <button
                              onClick={() => handleAddMemo(item.id)}
                              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer shrink-0"
                            >
                              기록
                            </button>
                          </div>

                          {/* Quick preset chips */}
                          <div className="flex flex-wrap items-center gap-1 pt-0.5">
                            {['보완서류 제출완료', '심사관 실사일정 확정', '보증승인 문자수신', '은행대출 약정완료'].map((preset) => (
                              <button
                                key={preset}
                                onClick={() => setMemoInputs({ ...memoInputs, [item.id]: preset })}
                                className="px-2 py-0.5 bg-white hover:bg-indigo-50 text-[10px] text-slate-600 hover:text-indigo-700 border border-slate-200 rounded-md transition-colors"
                              >
                                + {preset}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Logs list */}
                        <div className="space-y-1.5 max-h-36 overflow-y-auto pt-2 border-t border-slate-200/70 pr-1">
                          {item.notes && item.notes.length > 0 ? (
                            item.notes.map((n) => (
                              <div key={n.id} className="p-2 bg-white rounded-lg border border-slate-200/60 text-xs">
                                <div className="flex items-center justify-between text-[10px] font-bold text-slate-400 mb-0.5">
                                  <span>📌 기록</span>
                                  <span>{n.date}</span>
                                </div>
                                <div className="text-slate-700 font-medium leading-relaxed">
                                  {n.content}
                                </div>
                              </div>
                            ))
                          ) : (
                            <div className="text-center py-4 text-xs text-slate-400 font-medium">
                              등록된 메모가 없습니다.
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Bottom Action Buttons Toolbar */}
                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
                      <div className="flex items-center gap-2 flex-wrap">
                        {onOpenConsultation && (
                          <button
                            onClick={() => onOpenConsultation({ title: item.fundTitle, agency: item.agency })}
                            className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <Headphones className="w-3.5 h-3.5 text-indigo-600" />
                            <span>1:1 심사 상담</span>
                          </button>
                        )}

                        {onOpenPdfChecklist && (
                          <button
                            onClick={() => onOpenPdfChecklist({ title: item.fundTitle, agency: item.agency, id: item.fundId })}
                            className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <FileText className="w-3.5 h-3.5 text-blue-600" />
                            <span>공고문 PDF 분석</span>
                          </button>
                        )}

                        {onScheduleCalendar && (
                          <button
                            onClick={() => onScheduleCalendar({ title: item.fundTitle, agency: item.agency })}
                            className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
                          >
                            <Calendar className="w-3.5 h-3.5 text-slate-500" />
                            <span>심사 일정 캘린더</span>
                          </button>
                        )}
                      </div>

                      <button
                        onClick={() => handleDeleteTracker(item.id, item.fundTitle)}
                        className="px-3 py-1.5 text-rose-600 hover:bg-rose-50 rounded-xl font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer ml-auto"
                        title="이 트래커 삭제"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>트래킹 삭제</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Add New Application Tracker Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 md:p-8 shadow-2xl space-y-5 animate-fade-in">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
                  <Plus className="w-4 h-4" />
                </div>
                <h3 className="text-lg font-black text-slate-900">
                  신규 정책자금 신청 트래커 등록
                </h3>
              </div>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 text-sm font-bold"
              >
                닫기
              </button>
            </div>

            <div className="space-y-4 text-xs font-medium text-slate-700">
              {/* Select from Favorites or enter name */}
              {favorites.length > 0 && (
                <div>
                  <label className="block text-slate-900 font-bold mb-1.5">
                    즐겨찾기한 자금에서 선택
                  </label>
                  <select
                    value={selectedFundIdForAdd}
                    onChange={(e) => {
                      setSelectedFundIdForAdd(e.target.value);
                      const f = favorites.find(fav => ('id' in fav ? fav.id : fav.name) === e.target.value);
                      if (f) {
                        setCustomFundTitle('title' in f ? f.title : f.name);
                        setCustomAgency(f.agency);
                      }
                    }}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="">-- 즐겨찾기 자금 중 선택하세요 --</option>
                    {favorites.map((f) => {
                      const id = 'id' in f ? f.id : f.name;
                      const title = 'title' in f ? f.title : f.name;
                      return (
                        <option key={id} value={id}>
                          [{f.agency}] {title}
                        </option>
                      );
                    })}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-slate-900 font-bold mb-1">
                  정책자금명 <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="예: 2026년 소상공인 경영안정 특례보증"
                  value={customFundTitle}
                  onChange={(e) => setCustomFundTitle(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-900 font-bold mb-1">
                    주관 기관
                  </label>
                  <input
                    type="text"
                    placeholder="예: 서울신용보증재단"
                    value={customAgency}
                    onChange={(e) => setCustomAgency(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-slate-900 font-bold mb-1">
                    목표 대출 금액
                  </label>
                  <input
                    type="text"
                    placeholder="예: 5,000만원"
                    value={customTargetAmount}
                    onChange={(e) => setCustomTargetAmount(e.target.value)}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-900 font-bold mb-1">
                  현재 시작 진행 단계
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {STAGES_CONFIG.slice(0, 3).map((st) => (
                    <button
                      key={st.key}
                      type="button"
                      onClick={() => setStartStage(st.key)}
                      className={`p-2.5 rounded-xl border text-center font-bold text-xs transition-all cursor-pointer ${
                        startStage === st.key
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {st.shortLabel}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-900 font-bold mb-1">
                  접수 번호 (선택)
                </label>
                <input
                  type="text"
                  placeholder="예: APP-2026-894120"
                  value={customAppNumber}
                  onChange={(e) => setCustomAppNumber(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
                />
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex gap-2.5">
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="flex-1 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs transition-colors"
              >
                취소
              </button>
              <button
                onClick={handleCreateTracker}
                className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-black text-xs transition-all shadow-md shadow-emerald-500/20"
              >
                트래커 등록 완료
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full 5-Stage Master Guide Modal */}
      {isMasterGuideModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-3xl w-full p-6 md:p-8 shadow-2xl space-y-6 animate-fade-in max-h-[90vh] overflow-y-auto">
            {/* Modal Header */}
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-xs font-black border border-indigo-100">
                  <BookOpen className="w-3.5 h-3.5" /> 정책자금 심사 통과 마스터 가이드
                </div>
                <h3 className="text-xl font-black text-slate-900 flex items-center gap-2">
                  <span>단계별 핵심 준비 사항 & 실수 방지 팁</span>
                </h3>
                <p className="text-xs text-slate-500 font-medium">
                  서류 준비부터 심사 대기, 보증서 승인, 최종 자금 수령까지 심사관 평가 기준과 감점 방지 팁을 한눈에 확인하세요.
                </p>
              </div>

              <button
                onClick={() => setIsMasterGuideModalOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                title="닫기"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* 5-Stage Selector Tabs */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 bg-slate-50 p-1.5 rounded-2xl border border-slate-200">
              {STAGES_CONFIG.map((st) => {
                const isSelected = guideModalStage === st.key;
                return (
                  <button
                    key={st.key}
                    type="button"
                    onClick={() => setGuideModalStage(st.key)}
                    className={`py-2 px-2 rounded-xl text-xs font-black transition-all flex flex-col items-center gap-0.5 cursor-pointer ${
                      isSelected
                        ? 'bg-white text-indigo-900 shadow-sm border border-indigo-100 ring-2 ring-indigo-500/20'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/50'
                    }`}
                  >
                    <span className="text-[10px] text-slate-400 font-bold">{st.step}단계</span>
                    <span className="truncate w-full text-center">{st.shortLabel}</span>
                  </button>
                );
              })}
            </div>

            {/* Selected Stage Detail Content */}
            {(() => {
              const currentGuideStage = STAGES_CONFIG.find(s => s.key === guideModalStage) || STAGES_CONFIG[0];

              return (
                <div className="space-y-6 animate-fade-in">
                  {/* Stage Summary Banner */}
                  <div className={`p-4 rounded-2xl border flex items-start justify-between gap-3 ${currentGuideStage.badgeBg} ${currentGuideStage.badgeText} border-current/20`}>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-black">{currentGuideStage.label}</span>
                        <span className="text-[10px] px-2 py-0.5 bg-white/80 rounded-md font-bold shadow-2xs">
                          {currentGuideStage.averageDays}
                        </span>
                      </div>
                      <p className="text-xs font-medium opacity-90 leading-relaxed">
                        {currentGuideStage.description}
                      </p>
                    </div>
                  </div>

                  {/* 2-Column: Key Preparations vs Common Mistakes */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    {/* Left: Core Preparations */}
                    <div className="space-y-3 bg-slate-50/80 p-4 rounded-2xl border border-slate-200">
                      <h4 className="text-xs font-black text-slate-900 flex items-center gap-1.5 border-b border-slate-200 pb-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>핵심 준비 사항 ({currentGuideStage.corePreparations.length}개)</span>
                      </h4>

                      <div className="space-y-2.5">
                        {currentGuideStage.corePreparations.map((prep, idx) => (
                          <div key={idx} className="bg-white p-3 rounded-xl border border-slate-200/90 space-y-1 shadow-2xs">
                            <div className="flex items-center justify-between gap-1">
                              <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                                <span className="w-4 h-4 rounded-full bg-emerald-100 text-emerald-800 text-[10px] flex items-center justify-center font-bold">
                                  {idx + 1}
                                </span>
                                {prep.title}
                              </span>
                              {prep.mustCheck ? (
                                <span className="text-[9px] font-black px-1.5 py-0.5 bg-rose-50 text-rose-700 border border-rose-200 rounded shrink-0">
                                  필수 확인
                                </span>
                              ) : (
                                <span className="text-[9px] font-bold px-1.5 py-0.5 bg-slate-100 text-slate-600 rounded shrink-0">
                                  권장 사항
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-slate-600 font-medium leading-relaxed pl-5">
                              {prep.desc}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Right: Common Mistakes & Pitfalls */}
                    <div className="space-y-3 bg-rose-50/40 p-4 rounded-2xl border border-rose-100">
                      <h4 className="text-xs font-black text-rose-950 flex items-center gap-1.5 border-b border-rose-200 pb-2">
                        <AlertTriangle className="w-4 h-4 text-rose-600" />
                        <span>흔히 하는 실수 & 감점 방지 팁 ({currentGuideStage.commonMistakes.length}개)</span>
                      </h4>

                      <div className="space-y-3">
                        {currentGuideStage.commonMistakes.map((mistakeItem, idx) => (
                          <div key={idx} className="bg-white p-3.5 rounded-xl border border-rose-200 space-y-2 shadow-2xs">
                            <div className="flex items-start gap-1.5">
                              <span className="text-[10px] font-black px-1.5 py-0.5 bg-rose-100 text-rose-800 rounded shrink-0">
                                실수 #{idx + 1}
                              </span>
                              <h5 className="text-xs font-black text-slate-900 leading-snug">
                                {mistakeItem.mistake}
                              </h5>
                            </div>

                            <div className="p-2 bg-rose-50/70 rounded-lg text-[11px] text-rose-900 leading-relaxed font-medium">
                              <strong className="font-bold text-rose-950 block mb-0.5">💥 발생 불이익:</strong>
                              {mistakeItem.consequence}
                            </div>

                            <div className="p-2 bg-emerald-50/80 rounded-lg text-[11px] text-emerald-950 leading-relaxed font-medium">
                              <strong className="font-bold text-emerald-900 block mb-0.5">🛡️ 해결책:</strong>
                              {mistakeItem.solution}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Golden Pro-Tip Box */}
                  <div className="p-4 bg-gradient-to-r from-amber-50 to-amber-100/50 rounded-2xl border border-amber-200 flex items-start gap-3">
                    <div className="p-2 bg-amber-500 text-white rounded-xl shadow-2xs shrink-0 mt-0.5">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div className="space-y-1 text-xs">
                      <div className="font-black text-amber-950 text-sm">💡 심사관 합격 Pro-Tip</div>
                      <p className="font-medium text-amber-900 leading-relaxed">
                        {currentGuideStage.proTip}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* Modal Bottom Footer */}
            <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
              <div className="text-xs text-slate-500 font-medium">
                💡 중소벤처기업부 및 신용보증재단 실무 심사 기준을 반영하여 상시 갱신됩니다.
              </div>
              <button
                onClick={() => setIsMasterGuideModalOpen(false)}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-black text-xs transition-colors cursor-pointer shadow-xs"
              >
                가이드 닫기
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
