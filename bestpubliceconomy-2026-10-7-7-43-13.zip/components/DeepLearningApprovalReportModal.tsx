import React, { useState, useMemo, useEffect } from 'react';
import { 
  PolicyFund, 
  SourcePolicy, 
  UserProfile, 
  DeepLearningApprovalReport, 
  ApprovalDimensionMetric, 
  ImprovementActionItem,
  ApprovalLikelihoodTier 
} from '../types';
import { 
  X, 
  Sparkles, 
  Award, 
  CheckCircle2, 
  AlertTriangle, 
  TrendingUp, 
  Building2, 
  ShieldCheck, 
  FileText, 
  Clock, 
  ArrowRight, 
  RotateCcw, 
  ChevronRight, 
  Printer, 
  Copy, 
  Check, 
  Loader2, 
  Bot, 
  Lightbulb, 
  Sliders, 
  Percent, 
  Target, 
  CheckSquare, 
  Square, 
  AlertCircle, 
  Zap, 
  Info, 
  BookOpen, 
  MapPin, 
  HelpCircle,
  BarChart3,
  ExternalLink,
  ChevronDown,
  Factory,
  Leaf
} from 'lucide-react';
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  ResponsiveContainer, 
  Tooltip as RechartsTooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Cell
} from 'recharts';
import { generateDeepLearningApprovalReport } from '../services/deepLearningApprovalEngine';
import { generateAiDetailedApprovalDiagnosis } from '../services/geminiService';

interface DeepLearningApprovalReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  fund: PolicyFund | SourcePolicy | null;
  profile?: UserProfile | null;
  allFunds?: (PolicyFund | SourcePolicy)[];
  onSelectFund?: (fund: PolicyFund | SourcePolicy) => void;
}

export const DeepLearningApprovalReportModal: React.FC<DeepLearningApprovalReportModalProps> = ({
  isOpen,
  onClose,
  fund,
  profile,
  allFunds = [],
  onSelectFund
}) => {
  const [selectedFund, setSelectedFund] = useState<PolicyFund | SourcePolicy | null>(fund);

  // Sync selectedFund when prop changes
  useEffect(() => {
    if (fund) {
      setSelectedFund(fund);
    } else if (allFunds.length > 0 && !selectedFund) {
      setSelectedFund(allFunds[0]);
    }
  }, [fund, allFunds]);

  // Generate Base Report from Engine
  const baseReport: DeepLearningApprovalReport | null = useMemo(() => {
    if (!selectedFund) return null;
    return generateDeepLearningApprovalReport(profile, selectedFund);
  }, [profile, selectedFund]);

  // Simulation State: Set of active improvement item IDs
  const [appliedImprovements, setAppliedImprovements] = useState<Record<string, boolean>>({});

  // Reset simulation when switching funds
  useEffect(() => {
    setAppliedImprovements({});
  }, [selectedFund]);

  // AI Chief Examiner Diagnosis State
  const [aiDiagnosis, setAiDiagnosis] = useState<{
    chiefExaminerReview: string;
    threePointStrategy: { step: string; action: string; impact: string }[];
    documentPreparationTips: string[];
    confidentialAuditSummary: string;
  } | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);

  // Reset AI diagnosis when fund changes
  useEffect(() => {
    setAiDiagnosis(null);
  }, [selectedFund]);

  // Copy state
  const [copied, setCopied] = useState(false);

  // Active Tab inside Report: 'DIAGNOSIS' | 'SIMULATOR' | 'RADAR' | 'PEERS'
  const [activeReportTab, setActiveReportTab] = useState<'DIAGNOSIS' | 'SIMULATOR' | 'RADAR' | 'PEERS'>('DIAGNOSIS');

  // Calculate Simulated Score & Tier
  const simulationResult = useMemo(() => {
    if (!baseReport) return { score: 0, tier: 'MODERATE' as ApprovalLikelihoodTier, uplift: 0, label: '보통', color: 'bg-amber-500' };

    let totalUplift = 0;
    baseReport.improvementItems.forEach(item => {
      if (appliedImprovements[item.id]) {
        totalUplift += item.potentialUpliftPercent;
      }
    });

    const simulatedScore = Math.min(99, Math.round(baseReport.overallProbability + totalUplift));
    
    let simTier: ApprovalLikelihoodTier = 'MODERATE';
    let simLabel = '보통';
    let simColor = 'bg-amber-500 text-white';

    if (simulatedScore >= 90) {
      simTier = 'VERY_HIGH';
      simLabel = '매우 높음 (확정권)';
      simColor = 'bg-emerald-600 text-white';
    } else if (simulatedScore >= 75) {
      simTier = 'HIGH';
      simLabel = '높음 (우수)';
      simColor = 'bg-blue-600 text-white';
    } else if (simulatedScore >= 60) {
      simTier = 'MODERATE';
      simLabel = '보통 (경합)';
      simColor = 'bg-amber-500 text-white';
    } else if (simulatedScore >= 40) {
      simTier = 'LOW';
      simLabel = '주의/다소 낮음';
      simColor = 'bg-orange-500 text-white';
    } else {
      simTier = 'VERY_LOW';
      simLabel = '낮음/보완 필수';
      simColor = 'bg-rose-600 text-white';
    }

    return {
      score: simulatedScore,
      tier: simTier,
      uplift: totalUplift,
      label: simLabel,
      color: simColor
    };
  }, [baseReport, appliedImprovements]);

  // Toggle improvement item
  const handleToggleImprovement = (id: string) => {
    setAppliedImprovements(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  // Generate AI Diagnosis on Demand
  const handleFetchAiDiagnosis = async () => {
    if (!baseReport || !selectedFund) return;
    setIsLoadingAi(true);
    try {
      const diagnosis = await generateAiDetailedApprovalDiagnosis(
        profile,
        baseReport.fundTitle,
        baseReport.agency,
        simulationResult.score,
        simulationResult.label
      );
      setAiDiagnosis(diagnosis);
    } catch (err) {
      console.error('Failed to generate AI diagnosis:', err);
    } finally {
      setIsLoadingAi(false);
    }
  };

  // Radar chart formatted data
  const radarData = useMemo(() => {
    if (!baseReport) return [];
    return baseReport.dimensions.map(dim => ({
      dimension: dim.dimensionName.replace(' 및 ', '\n').split(' ')[0],
      fullName: dim.dimensionName,
      내점수: dim.score + (appliedImprovements[dim.id] ? 15 : 0),
      과거승인자평균: dim.cohortBenchmark,
      최소합격선: dim.minPassThreshold
    }));
  }, [baseReport, appliedImprovements]);

  // Copy report summary
  const handleCopyReport = () => {
    if (!baseReport) return;
    const text = `[BizMatch AI 딥러닝 정책자금 승인 가능성 리포트]
- 신청 자금: ${baseReport.fundTitle} (${baseReport.agency})
- 기본 승인 확률: ${baseReport.overallProbability}% (${baseReport.tierLabel})
- 시뮬레이션 적용 후: ${simulationResult.score}% (${simulationResult.label}, +${simulationResult.uplift}%p)
- 심사역 진단의견: ${baseReport.examinerReviewOpinion}
- 핵심 개선 권장 항목:
${baseReport.improvementItems.map((item, i) => ` ${i + 1}. ${item.title} (+${item.potentialUpliftPercent}%p)`).join('\n')}`;

    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Print report
  const handlePrint = () => {
    window.print();
  };

  if (!isOpen || !selectedFund || !baseReport) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 md:p-6 animate-fade-in print:p-0 print:bg-white">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200/90 w-full max-w-5xl max-h-[92vh] flex flex-col overflow-hidden relative print:max-h-none print:shadow-none print:border-none">
        
        {/* Modal Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between border-b border-white/10 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-400/40 flex items-center justify-center text-indigo-400">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-indigo-500/30 text-indigo-300 border border-indigo-400/30">
                  Deep Learning Pattern Engine
                </span>
                <span className="text-xs text-slate-400 font-bold hidden sm:inline">
                  과거 승인 빅데이터 기반 정밀 진단
                </span>
              </div>
              <h2 className="text-lg sm:text-xl font-black text-white tracking-tight">
                정책자금 5단계 승인 가능성 & 개선 솔루션 리포트
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white transition-all text-xs font-bold flex items-center gap-1.5 cursor-pointer hidden sm:flex"
              title="리포트 인쇄 및 PDF 저장"
            >
              <Printer className="w-4 h-4" />
              <span>인쇄/PDF</span>
            </button>
            <button
              type="button"
              onClick={handleCopyReport}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 hover:text-white transition-all text-xs font-bold flex items-center gap-1.5 cursor-pointer"
              title="리포트 요약 복사"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span className="hidden sm:inline">{copied ? '복사됨' : '복사'}</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 hover:bg-rose-600 text-slate-300 hover:text-white transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Fund Selector Bar (If allFunds provided) */}
        {allFunds.length > 1 && (
          <div className="bg-slate-100/90 px-6 py-2.5 border-b border-slate-200 flex items-center gap-3 overflow-x-auto scrollbar-none shrink-0">
            <span className="text-xs font-black text-slate-600 shrink-0 flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5 text-indigo-600" /> 대상 자금 선택:
            </span>
            <div className="flex items-center gap-1.5 flex-nowrap">
              {allFunds.map((f, idx) => {
                const title = 'title' in f ? f.title : f.name;
                const isSelected = selectedFund && ('title' in selectedFund ? selectedFund.title : selectedFund.name) === title;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setSelectedFund(f);
                      if (onSelectFund) onSelectFund(f);
                    }}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1 ${
                      isSelected
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-white text-slate-700 hover:bg-slate-200 border border-slate-200/80'
                    }`}
                  >
                    <span>{title.length > 16 ? title.substring(0, 16) + '...' : title}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Modal Body Scroll Area */}
        <div className="overflow-y-auto p-4 sm:p-6 md:p-8 space-y-6">

          {/* 1. HERO HERO SECTION: 5-Tier Likelihood Gauge & Key Summary */}
          <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 sm:p-7 shadow-lg border border-slate-800 relative overflow-hidden">
            {/* Background Decorative Pattern */}
            <div className="absolute top-0 right-0 -mt-10 -mr-10 w-60 h-60 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
              
              {/* Left Dial & 5-Tier Badge (Col 4) */}
              <div className="lg:col-span-4 flex flex-col items-center justify-center p-4 bg-white/5 rounded-2xl border border-white/10 text-center relative">
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-300 mb-1">
                  딥러닝 예측 승인 가능성
                </span>

                {/* Big Percentage with Circle Ring */}
                <div className="relative my-2 flex items-center justify-center">
                  <div className="w-28 h-28 rounded-full border-4 border-white/10 flex flex-col items-center justify-center bg-slate-950/60 shadow-inner">
                    <span className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                      {simulationResult.score}%
                    </span>
                    {simulationResult.uplift > 0 && (
                      <span className="text-[11px] font-black text-emerald-400 animate-pulse">
                        +{simulationResult.uplift}%p 개선
                      </span>
                    )}
                  </div>
                </div>

                {/* 5-Tier Level Badge */}
                <div className={`px-4 py-1.5 rounded-full text-xs font-black shadow-md uppercase tracking-wide mt-1 ${simulationResult.color}`}>
                  5단계 판정: {simulationResult.label}
                </div>

                <span className="text-[10px] text-slate-400 mt-2 font-medium">
                  과거 유사 1,480+ 소상공인 승인 빅데이터 매칭
                </span>
              </div>

              {/* Middle/Right: 5-Tier Step Scale & Fund Info (Col 8) */}
              <div className="lg:col-span-8 space-y-4">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="px-2.5 py-0.5 bg-white/10 text-indigo-300 rounded-md text-xs font-bold">
                      {baseReport.agency}
                    </span>
                    <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 rounded-md text-xs font-bold">
                      {baseReport.predictedMaxAmount}
                    </span>
                    <span className="px-2.5 py-0.5 bg-amber-500/20 text-amber-300 rounded-md text-xs font-bold">
                      {baseReport.predictedInterestRate}
                    </span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-black text-white mt-1.5 tracking-tight">
                    {baseReport.fundTitle}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-300 mt-1 leading-relaxed">
                    {baseReport.summaryVerdict}
                  </p>
                </div>

                {/* 5-Tier Visual Stepper */}
                <div className="space-y-1.5 pt-2">
                  <div className="flex justify-between text-[11px] font-bold text-slate-400 px-1">
                    <span>1. 낮음(&lt;40%)</span>
                    <span>2. 주의(40~59%)</span>
                    <span>3. 보통(60~74%)</span>
                    <span>4. 높음(75~89%)</span>
                    <span>5. 매우 높음(90%+)</span>
                  </div>

                  {/* 5-Segment Track */}
                  <div className="grid grid-cols-5 gap-1.5 h-3 rounded-full overflow-hidden p-0.5 bg-white/10">
                    <div className={`rounded-l-full transition-all ${simulationResult.score < 40 ? 'bg-rose-500 ring-2 ring-white' : 'bg-rose-500/40'}`} />
                    <div className={`transition-all ${simulationResult.score >= 40 && simulationResult.score < 60 ? 'bg-orange-500 ring-2 ring-white' : 'bg-orange-500/40'}`} />
                    <div className={`transition-all ${simulationResult.score >= 60 && simulationResult.score < 75 ? 'bg-amber-500 ring-2 ring-white' : 'bg-amber-500/40'}`} />
                    <div className={`transition-all ${simulationResult.score >= 75 && simulationResult.score < 90 ? 'bg-blue-500 ring-2 ring-white' : 'bg-blue-500/40'}`} />
                    <div className={`rounded-r-full transition-all ${simulationResult.score >= 90 ? 'bg-emerald-500 ring-2 ring-white shadow-lg' : 'bg-emerald-500/40'}`} />
                  </div>
                </div>

                {/* Examiner Review Summary Banner */}
                <div className="bg-white/5 border border-white/10 rounded-2xl p-3 flex items-start gap-2.5 text-xs text-slate-200">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-emerald-300 block mb-0.5">심사역 핵심 평가 의견:</span>
                    <p className="text-[11px] text-slate-300 leading-relaxed">
                      {baseReport.examinerReviewOpinion}
                    </p>
                  </div>
                </div>
              </div>

            </div>
          </div>

          {/* 2. Sub Navigation Tabs inside Report Modal */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-2xl border border-slate-200/80 overflow-x-auto scrollbar-none">
            <button
              type="button"
              onClick={() => setActiveReportTab('DIAGNOSIS')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeReportTab === 'DIAGNOSIS'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Target className="w-3.5 h-3.5 text-indigo-600" />
              <span>5대 역량 정밀 진단표</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveReportTab('SIMULATOR')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeReportTab === 'SIMULATOR'
                  ? 'bg-white text-emerald-700 shadow-xs ring-1 ring-emerald-200'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Sliders className="w-3.5 h-3.5 text-emerald-600" />
              <span>⚡ 승인율 실시간 시뮬레이터 ({baseReport.improvementItems.length}개 항목)</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveReportTab('RADAR')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeReportTab === 'RADAR'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-blue-600" />
              <span>과거 승인자 벤치마크 레이더</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveReportTab('PEERS')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer whitespace-nowrap ${
                activeReportTab === 'PEERS'
                  ? 'bg-white text-amber-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Award className="w-3.5 h-3.5 text-amber-600" />
              <span>유사 성공 사례 Top 3 ({baseReport.matchedPeers.length})</span>
            </button>
          </div>

          {/* 3. TAB 1: 5대 핵심 평가 역량 정밀 진단표 (DIAGNOSIS) */}
          {activeReportTab === 'DIAGNOSIS' && (
            <div className="space-y-6 animate-fade-in">
              {/* Policy Bonus Point Calibration Card */}
              {baseReport.policyBonusAdjustment && (
                <div className="p-5 bg-gradient-to-br from-indigo-50/80 via-white to-blue-50/60 rounded-2xl border-2 border-indigo-200/90 shadow-xs space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-indigo-100">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="p-1.5 bg-indigo-600 text-white rounded-lg shadow-xs">
                          <Sparkles className="w-4 h-4" />
                        </span>
                        <h4 className="text-sm font-black text-slate-900 tracking-tight flex items-center gap-1.5">
                          정부 정책적 가점(스마트공장·탄소중립 등) 보정 진단 내역
                        </h4>
                      </div>
                      <p className="text-xs text-slate-600">
                        {baseReport.policyBonusAdjustment.examinerCommitteeImpact}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
                      <div className="px-3 py-1.5 bg-indigo-600 text-white rounded-xl text-xs font-black shadow-xs flex items-center gap-1.5">
                        <TrendingUp className="w-3.5 h-3.5 text-indigo-200" />
                        <span>총 가점 보정: +{baseReport.policyBonusAdjustment.totalBonusUplift}%p</span>
                      </div>
                    </div>
                  </div>

                  {baseReport.policyBonusAdjustment.appliedBonuses.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {baseReport.policyBonusAdjustment.appliedBonuses.map((bonus) => (
                        <div key={bonus.id} className="p-3.5 bg-white rounded-xl border border-indigo-100 shadow-xs space-y-1.5">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              {bonus.id.includes('smart') ? (
                                <Factory className="w-4 h-4 text-blue-600" />
                              ) : bonus.id.includes('carbon') ? (
                                <Leaf className="w-4 h-4 text-emerald-600" />
                              ) : (
                                <Award className="w-4 h-4 text-indigo-600" />
                              )}
                              <span className="text-xs font-black text-slate-900">{bonus.name}</span>
                            </div>
                            <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                              +{bonus.points}%p 가산
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-500 leading-snug">{bonus.description}</p>
                          <div className="text-[10px] font-bold text-indigo-700 bg-indigo-50/70 p-2 rounded-lg">
                            기관 우대: {bonus.agencyBenefit}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-800 flex items-center justify-between">
                      <span>현재 적용된 정책적 가점(스마트공장, 탄소중립 실천 등)이 없습니다.</span>
                      <button
                        type="button"
                        onClick={() => setActiveReportTab('SIMULATOR')}
                        className="font-bold underline text-amber-900 hover:text-amber-700"
                      >
                        시뮬레이터에서 가점 추가하기
                      </button>
                    </div>
                  )}
                </div>
              )}

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                    <span>5대 정책자금 심사 평가 차원별 상세 분석</span>
                  </h4>
                  <p className="text-xs text-slate-500 font-medium mt-0.5">
                    공식 신용보증재단 및 소진공 심사평가표 가중치(100%)를 반영한 항목별 점수입니다.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setActiveReportTab('SIMULATOR')}
                  className="px-3.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold border border-emerald-200 transition-all flex items-center gap-1 cursor-pointer"
                >
                  <Sliders className="w-3.5 h-3.5 text-emerald-600" />
                  <span>개선 항목 시뮬레이션 적용하기 &rarr;</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {baseReport.dimensions.map((dim) => {
                  const isExcellent = dim.score >= 80;
                  const isGood = dim.score >= 65 && dim.score < 80;
                  const isCritical = dim.score < 50;

                  return (
                    <div 
                      key={dim.id}
                      className={`p-4 rounded-2xl border transition-all space-y-3 ${
                        isExcellent
                          ? 'bg-emerald-50/40 border-emerald-200/80 hover:border-emerald-300'
                          : isGood
                            ? 'bg-blue-50/40 border-blue-200/80 hover:border-blue-300'
                            : isCritical
                              ? 'bg-rose-50/40 border-rose-200/80 hover:border-rose-300'
                              : 'bg-amber-50/40 border-amber-200/80 hover:border-amber-300'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black text-slate-900">
                            {dim.dimensionName}
                          </span>
                          <span className="text-[10px] font-bold text-slate-500 bg-white px-2 py-0.5 rounded-full border border-slate-200">
                            가중치 {dim.weight}%
                          </span>
                        </div>
                        <span className={`text-[11px] font-black px-2.5 py-0.5 rounded-full ${
                          isExcellent
                            ? 'bg-emerald-600 text-white'
                            : isGood
                              ? 'bg-blue-600 text-white'
                              : isCritical
                                ? 'bg-rose-600 text-white'
                                : 'bg-amber-600 text-white'
                        }`}>
                          {dim.statusLabel} ({dim.score}점)
                        </span>
                      </div>

                      {/* Progress Bar comparison */}
                      <div className="space-y-1">
                        <div className="flex justify-between text-[10px] font-bold text-slate-500">
                          <span>내 점수: <strong className="text-slate-900">{dim.score}점</strong></span>
                          <span>승인자 평균: {dim.cohortBenchmark}점 / 최소통과선: {dim.minPassThreshold}점</span>
                        </div>
                        <div className="h-2.5 w-full bg-slate-200 rounded-full overflow-hidden relative">
                          {/* Min Pass Marker */}
                          <div 
                            className="absolute top-0 bottom-0 w-0.5 bg-slate-400 z-10" 
                            style={{ left: `${dim.minPassThreshold}%` }} 
                            title={`최소 합격선 (${dim.minPassThreshold}점)`}
                          />
                          {/* Cohort Benchmark Marker */}
                          <div 
                            className="absolute top-0 bottom-0 w-1 bg-amber-500 z-10" 
                            style={{ left: `${dim.cohortBenchmark}%` }} 
                            title={`과거 승인자 평균 (${dim.cohortBenchmark}점)`}
                          />
                          {/* User Score Bar */}
                          <div 
                            className={`h-full rounded-full transition-all duration-500 ${
                              isExcellent ? 'bg-emerald-500' : isGood ? 'bg-blue-500' : isCritical ? 'bg-rose-500' : 'bg-amber-500'
                            }`}
                            style={{ width: `${dim.score}%` }}
                          />
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 font-medium leading-relaxed bg-white/80 p-2.5 rounded-xl border border-slate-200/60">
                        💬 {dim.evaluationReason}
                      </p>
                    </div>
                  );
                })}
              </div>

              {/* Bonus Strengths vs Risk Factors */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div className="bg-emerald-50 p-4 rounded-2xl border border-emerald-200/80 space-y-2">
                  <span className="text-xs font-black text-emerald-900 flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    현재 프로필의 심사 강점 요인
                  </span>
                  <ul className="space-y-1.5 text-xs text-emerald-800 font-medium">
                    {baseReport.bonusStrengths.map((str, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-emerald-600 font-bold">•</span>
                        <span>{str}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="bg-amber-50 p-4 rounded-2xl border border-amber-200/80 space-y-2">
                  <span className="text-xs font-black text-amber-900 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    심사 시 주의 및 보완 권장 사항
                  </span>
                  <ul className="space-y-1.5 text-xs text-amber-800 font-medium">
                    {baseReport.keyRiskFactors.map((risk, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-amber-600 font-bold">•</span>
                        <span>{risk}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* 4. TAB 2: 승인율 실시간 시뮬레이터 (SIMULATOR) */}
          {activeReportTab === 'SIMULATOR' && (
            <div className="space-y-6 animate-fade-in">
              {/* Simulator Header Card */}
              <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-blue-50 p-5 rounded-3xl border border-emerald-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 bg-emerald-600 text-white rounded-lg">
                      <Sliders className="w-4 h-4" />
                    </span>
                    <h4 className="text-base font-black text-slate-900">
                      실시간 승인 가능성 상승 시뮬레이터
                    </h4>
                  </div>
                  <p className="text-xs text-slate-600 font-medium">
                    아래 항목을 체크하여 준비 완료 시 승인 확률이 몇 % 상승하는지 실시간으로 확인하세요.
                  </p>
                </div>

                {/* Score Comparison Display */}
                <div className="bg-white p-3.5 rounded-2xl border border-emerald-200/90 shadow-sm flex items-center gap-4 shrink-0">
                  <div className="text-center">
                    <span className="text-[10px] font-bold text-slate-400 block">기본 확률</span>
                    <span className="text-base font-black text-slate-500">{baseReport.overallProbability}%</span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-emerald-500" />
                  <div className="text-center">
                    <span className="text-[10px] font-bold text-emerald-600 block">개선 시 예상</span>
                    <span className="text-xl font-black text-emerald-600">{simulationResult.score}%</span>
                  </div>
                  <div className={`px-2.5 py-1 rounded-xl text-[11px] font-extrabold ${simulationResult.color}`}>
                    {simulationResult.label}
                  </div>
                </div>
              </div>

              {/* Actionable Improvement Checklist */}
              <div className="space-y-3.5">
                {baseReport.improvementItems.map((item) => {
                  const isChecked = Boolean(appliedImprovements[item.id]);

                  return (
                    <div
                      key={item.id}
                      onClick={() => handleToggleImprovement(item.id)}
                      className={`p-4 sm:p-5 rounded-2xl border transition-all cursor-pointer space-y-3 select-none ${
                        isChecked
                          ? 'bg-emerald-50/70 border-emerald-400 shadow-md ring-2 ring-emerald-400/30'
                          : 'bg-white hover:bg-slate-50 border-slate-200/80 hover:border-slate-300 shadow-2xs'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-3">
                          <button
                            type="button"
                            className="mt-0.5 text-slate-400 hover:text-emerald-600 transition-colors"
                          >
                            {isChecked ? (
                              <CheckSquare className="w-5 h-5 text-emerald-600 fill-emerald-100" />
                            ) : (
                              <Square className="w-5 h-5 text-slate-400" />
                            )}
                          </button>
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-xs sm:text-sm font-black text-slate-900">
                                {item.title}
                              </span>
                              <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                                item.priority === 'URGENT' 
                                  ? 'bg-rose-100 text-rose-800 border border-rose-200' 
                                  : 'bg-blue-100 text-blue-800 border border-blue-200'
                              }`}>
                                {item.priority === 'URGENT' ? '최우선 권장' : '가점 항목'}
                              </span>
                              <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                                {item.categoryLabel}
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 font-medium mt-1">
                              현재: <span className="text-slate-700 font-bold">{item.currentStatus}</span> ➔ 권장: <span className="text-indigo-700 font-bold">{item.recommendedTarget}</span>
                            </p>
                          </div>
                        </div>

                        {/* Uplift Badge */}
                        <div className="shrink-0 text-right">
                          <span className={`inline-flex items-center gap-0.5 text-xs font-black px-2.5 py-1 rounded-xl shadow-2xs ${
                            isChecked ? 'bg-emerald-600 text-white' : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                          }`}>
                            <TrendingUp className="w-3.5 h-3.5" />
                            +{item.potentialUpliftPercent}%p 승인율 상승
                          </span>
                          <span className="text-[10px] text-slate-400 font-medium block mt-1">
                            예상 소요: {item.estimatedDays}
                          </span>
                        </div>
                      </div>

                      {/* Action Guide Details */}
                      <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/60 text-xs text-slate-700 leading-relaxed font-medium">
                        <span className="font-bold text-slate-900 block mb-0.5">📌 실전 실행 가이드:</span>
                        {item.actionGuide}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Reset Simulator Button */}
              {Object.values(appliedImprovements).some(Boolean) && (
                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={() => setAppliedImprovements({})}
                    className="text-xs font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>시뮬레이션 초기화</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* 5. TAB 3: 과거 승인자 벤치마크 레이더 (RADAR) */}
          {activeReportTab === 'RADAR' && (
            <div className="space-y-6 animate-fade-in">
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
                {/* Radar Chart Component */}
                <div className="lg:col-span-7 bg-slate-50 p-4 rounded-3xl border border-slate-200 flex flex-col items-center">
                  <div className="text-center mb-2">
                    <h4 className="text-xs sm:text-sm font-black text-slate-900">
                      5대 역량 벤치마크 레이더 차트
                    </h4>
                    <span className="text-[11px] text-slate-500 font-medium">
                      내 점수 vs 과거 동일 자금 승인자 집단 평균(Cohort)
                    </span>
                  </div>

                  <div className="w-full h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <RadarChart cx="50%" cy="50%" outerRadius="75%" data={radarData}>
                        <PolarGrid stroke="#e2e8f0" />
                        <PolarAngleAxis dataKey="dimension" tick={{ fill: '#475569', fontSize: 11, fontWeight: 700 }} />
                        <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                        <Radar name="내 역량 점수" dataKey="내점수" stroke="#4f46e5" fill="#6366f1" fillOpacity={0.4} strokeWidth={2} />
                        <Radar name="승인자 평균" dataKey="과거승인자평균" stroke="#f59e0b" fill="#fbbf24" fillOpacity={0.2} strokeWidth={2} />
                        <Radar name="최소 합격선" dataKey="최소합격선" stroke="#ef4444" fill="none" strokeDasharray="3 3" strokeWidth={1.5} />
                        <RechartsTooltip />
                      </RadarChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="flex items-center gap-4 text-xs font-bold mt-2">
                    <div className="flex items-center gap-1.5">
                      <span className="w-3 h-3 rounded-full bg-indigo-600"></span>
                      <span className="text-slate-700">내 점수</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-3 h-3 rounded-full bg-amber-500"></span>
                      <span className="text-slate-700">과거 승인자 평균</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className="w-3 h-3 rounded-full border-2 border-dashed border-rose-500"></span>
                      <span className="text-slate-700">최소 합격선</span>
                    </div>
                  </div>
                </div>

                {/* Radar Insights Side Panel */}
                <div className="lg:col-span-5 space-y-3">
                  <h4 className="text-xs font-black text-slate-800">
                    💡 레이더 차트 벤치마크 진단 포인트
                  </h4>

                  <div className="bg-indigo-50/70 p-3.5 rounded-2xl border border-indigo-200/80 space-y-1 text-xs">
                    <span className="font-black text-indigo-900 block">1. 우위 영역: 정책 목적 & 업종 적합도</span>
                    <p className="text-indigo-800 leading-relaxed font-medium">
                      현재 대표님의 사업 업종과 자금 사용 목적은 과거 승인자 평균(80점)을 상회하고 있어 정책 취지 부합도에서 높은 기본 점수를 확보하고 있습니다.
                    </p>
                  </div>

                  <div className="bg-amber-50/70 p-3.5 rounded-2xl border border-amber-200/80 space-y-1 text-xs">
                    <span className="font-black text-amber-900 block">2. 보완 영역: 가점 요건 및 부채 증빙</span>
                    <p className="text-amber-800 leading-relaxed font-medium">
                      과거 승인자들은 마이데이터 연동 가점 및 소상공인 교육 수료증을 통해 비금융 배점(74점)을 채웠습니다. 해당 서류를 보강하면 승인율이 85% 이상으로 도약합니다.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleFetchAiDiagnosis}
                    disabled={isLoadingAi}
                    className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-xs transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isLoadingAi ? (
                      <Loader2 className="w-4 h-4 animate-spin text-white" />
                    ) : (
                      <Bot className="w-4 h-4 text-amber-300" />
                    )}
                    <span>🤖 Gemini AI 수석 심사역 심층 분석서 생성하기</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* 6. TAB 4: 유사 성공 사례 Top 3 (PEERS) */}
          {activeReportTab === 'PEERS' && (
            <div className="space-y-4 animate-fade-in">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                    <span>딥러닝 패턴 매칭 1순위 유사 소상공인 성공 사례</span>
                  </h4>
                  <p className="text-xs text-slate-500 font-medium">
                    대표님과 업종, 부채 구조, 매출 규모가 95% 이상 일치하는 실제 선배 대표님들의 승인 데이터입니다.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {baseReport.matchedPeers.map((peer, idx) => (
                  <div
                    key={peer.id || idx}
                    className="bg-slate-50 p-5 rounded-3xl border border-slate-200 space-y-4 flex flex-col justify-between hover:shadow-md hover:bg-white transition-all"
                  >
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-black px-2.5 py-0.5 rounded-full bg-indigo-600 text-white">
                          패턴 일치도 {peer.patternSimilarity}%
                        </span>
                        <span className="text-[10px] font-bold text-slate-400">
                          {peer.location}
                        </span>
                      </div>

                      <h5 className="font-black text-sm text-slate-900">
                        {peer.ownerName} ({peer.businessName})
                      </h5>
                      <span className="text-[11px] font-bold text-slate-500 block">
                        {peer.industryLabel} · {peer.fundName}
                      </span>

                      {/* Approval Benefit Box */}
                      <div className="bg-white p-3 rounded-2xl border border-slate-200 text-xs space-y-1">
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-bold">승인 금액:</span>
                          <span className="font-black text-emerald-600">{peer.approvedAmount}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-slate-400 font-bold">금리 인하:</span>
                          <span className="font-bold text-amber-600">{peer.rateReduction}</span>
                        </div>
                      </div>

                      {/* Key Success Factor */}
                      <div className="space-y-1">
                        <span className="text-[10px] font-black text-indigo-600 uppercase tracking-wider block">
                          💡 핵심 승인 비결:
                        </span>
                        <p className="text-xs text-slate-700 font-medium leading-relaxed">
                          {peer.keySuccessFactor}
                        </p>
                      </div>
                    </div>

                    {/* Similarity Tags */}
                    <div className="flex flex-wrap gap-1 pt-2 border-t border-slate-200">
                      {peer.similarityReasons.map((r, i) => (
                        <span key={i} className="text-[10px] font-bold bg-slate-200 text-slate-700 px-2 py-0.5 rounded-md">
                          ✓ {r}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 7. AI Chief Examiner Detailed Diagnosis Result Box (If generated) */}
          {aiDiagnosis && (
            <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-950 text-white rounded-3xl p-6 border border-indigo-500/30 space-y-5 animate-fade-in">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-amber-400/20 text-amber-300 flex items-center justify-center">
                    <Bot className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-sm font-black text-white">
                      Gemini AI 수석 대출심사역 맞춤형 정밀 소견서
                    </h4>
                    <span className="text-[10px] text-slate-400">
                      공식 중기부 심사관 평가 프레임워크 적용
                    </span>
                  </div>
                </div>
                <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 px-2.5 py-1 rounded-full border border-emerald-500/40">
                  AI 분석 완료
                </span>
              </div>

              {/* Chief Review */}
              <div className="space-y-1.5 bg-white/5 p-4 rounded-2xl border border-white/10">
                <span className="text-[11px] font-black text-amber-300 uppercase tracking-wider block">
                  👨‍⚖️ 수석 심사역 총평 및 승인 로직
                </span>
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium">
                  {aiDiagnosis.chiefExaminerReview}
                </p>
              </div>

              {/* 3 Step Strategy */}
              <div className="space-y-2">
                <span className="text-[11px] font-black text-indigo-300 uppercase tracking-wider block">
                  🚀 3단계 전액 승인 실행 전략
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {aiDiagnosis.threePointStrategy.map((strat, i) => (
                    <div key={i} className="bg-white/5 p-3.5 rounded-2xl border border-white/10 space-y-1.5 text-xs">
                      <span className="text-[10px] font-black text-emerald-400 block">{strat.step}</span>
                      <p className="text-slate-200 font-bold leading-snug">{strat.action}</p>
                      <span className="text-[10px] text-slate-400 block mt-1">효과: {strat.impact}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Document Preparation Tips */}
              <div className="bg-blue-950/40 p-4 rounded-2xl border border-blue-500/30 space-y-2 text-xs">
                <span className="font-black text-blue-300 block">📑 감점 방지 필수 서류 팁:</span>
                <ul className="space-y-1 text-slate-300 font-medium">
                  {aiDiagnosis.documentPreparationTips.map((tip, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="text-blue-400 font-bold">•</span>
                      <span>{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <p className="text-[11px] text-slate-400 italic text-center pt-1">
                "{aiDiagnosis.confidentialAuditSummary}"
              </p>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <Info className="w-4 h-4 text-indigo-600 shrink-0" />
            <span>본 리포트는 공공 심사 기준을 딥러닝 패턴으로 모델링한 예측 정보입니다.</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            {!aiDiagnosis && (
              <button
                type="button"
                onClick={handleFetchAiDiagnosis}
                disabled={isLoadingAi}
                className="flex-1 sm:flex-none px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {isLoadingAi ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Bot className="w-3.5 h-3.5" />}
                <span>AI 심사역 진단서</span>
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="flex-1 sm:flex-none px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
            >
              확인 완료
            </button>
          </div>
        </div>

      </div>
    </div>
  );
};
