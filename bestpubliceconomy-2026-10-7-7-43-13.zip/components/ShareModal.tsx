import React, { useState } from 'react';
import { X, Copy, MessageCircle, Share2, Check } from 'lucide-react';
import { AnalysisResult, UserProfile } from '../types';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: AnalysisResult;
  profile: UserProfile | null;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  result,
  profile
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const generateShareText = () => {
    const title = `[BizMatch AI] ${profile?.businessName || '고객'}님을 위한 맞춤 정책자금 추천\n`;
    const fundList = result.matchedFunds
      .slice(0, 3)
      .map((f, i) => `${i + 1}. ${f.title} (최대 ${f.maxAmount})`)
      .join('\n');
    
    return `${title}\n✅ 추천 정책자금:\n${fundList}\n\n자세한 분석 결과는 BizMatch AI 서비스에서 확인하세요!`;
  };

  const handleCopyClipboard = async () => {
    const text = generateShareText();
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      alert('클립보드 복사에 실패했습니다.');
    }
  };

  const handleKakaoShare = () => {
    const text = generateShareText();
    // Using Web Share API, which natively opens KakaoTalk on mobile devices if installed.
    if (navigator.share) {
      navigator.share({
        title: '정책자금 추천 결과',
        text: text,
        url: window.location.href,
      }).catch((err) => {
        console.log('Share failed:', err);
      });
    } else {
      alert('현재 브라우저에서는 카카오톡 공유가 지원되지 않습니다. 클립보드 복사를 이용해주세요.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm overflow-hidden animate-slide-up relative">
        <div className="p-5 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-indigo-600" />
            <h3 className="font-bold text-slate-800">분석 결과 공유하기</h3>
          </div>
          <button onClick={onClose} className="p-1 hover:bg-slate-100 rounded-lg text-slate-400">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="p-5 space-y-3">
          <button
            onClick={handleKakaoShare}
            className="w-full flex items-center justify-center gap-3 p-3.5 bg-[#FEE500] hover:bg-[#FDD800] text-slate-800 font-bold rounded-xl transition-all"
          >
            <MessageCircle className="w-5 h-5" />
            카카오톡 공유하기
          </button>
          
          <button
            onClick={handleCopyClipboard}
            className="w-full flex items-center justify-center gap-3 p-3.5 bg-slate-50 hover:bg-slate-100 text-slate-700 font-bold rounded-xl border border-slate-200 transition-all"
          >
            {copied ? (
              <>
                <Check className="w-5 h-5 text-green-500" />
                <span className="text-green-600">복사 완료!</span>
              </>
            ) : (
              <>
                <Copy className="w-5 h-5" />
                클립보드 텍스트 복사
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
