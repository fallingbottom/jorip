import React, { useState, useMemo } from 'react';
import { PolicyFund, UserProfile, SourcePolicy } from '../types';
import { 
  Scale, 
  Percent, 
  Clock, 
  ShieldCheck, 
  Banknote, 
  CheckCircle2, 
  Calendar, 
  Building, 
  Trash2, 
  Plus, 
  Sparkles, 
  Calculator, 
  AlertCircle, 
  ArrowRight, 
  ExternalLink, 
  Headphones, 
  FileCheck2, 
  ChevronDown, 
  ChevronUp, 
  Star,
  CheckSquare,
  Square,
  Award,
  Layers,
  Phone,
  SlidersHorizontal,
  Info,
  Zap,
  BarChart3,
  TrendingDown,
  TrendingUp,
  Target
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  Cell, 
  ReferenceLine,
  LabelList 
} from 'recharts';
import { parseFundInterestRate, parseFundMaxAmount, formatKoreanWon, calculateLoanSimulation } from './FundLoanSimulator';
import { matchDocumentToIssuanceInfo } from '../src/utils/documentIssuanceMap';
import { generateDeepLearningApprovalReport, getApprovalLikelihoodTier } from '../services/deepLearningApprovalEngine';

interface PolicyFundComparisonTableProps {
  funds: PolicyFund[];
  selectedFundIds: string[];
  onToggleSelectFund: (fund: PolicyFund) => void;
  onClearSelection: () => void;
  onQuickCompareTop: (count: number) => void;
  onOpenConsultation?: (fund: PolicyFund) => void;
  onOpenPdfChecklist?: (fund: PolicyFund) => void;
  onScheduleCalendar?: (fund: PolicyFund) => void;
  onToggleFavorite?: (fund: PolicyFund) => void;
  favorites?: (PolicyFund | SourcePolicy)[];
  profile?: UserProfile | null;
  onOpenFullComparisonDashboard?: () => void;
}

export const PolicyFundComparisonTable: React.FC<PolicyFundComparisonTableProps> = ({
  funds,
  selectedFundIds,
  onToggleSelectFund,
  onClearSelection,
  onQuickCompareTop,
  onOpenConsultation,
  onOpenPdfChecklist,
  onScheduleCalendar,
  onToggleFavorite,
  favorites = [],
  profile,
  onOpenFullComparisonDashboard
}) => {
  const [selectedAddFundId, setSelectedAddFundId] = useState<string>('');
  const [isExpanded, setIsExpanded] = useState<boolean>(true);
  const [showChart, setShowChart] = useState<boolean>(true);
  const [chartViewMode, setChartViewMode] = useState<'BOTH' | 'RATE' | 'AMOUNT'>('BOTH');
  const [benchmarkAmount, setBenchmarkAmount] = useState<number>(50000000); // 5천만원 기본

  // Get selected funds objects
  const selectedFunds = useMemo(() => {
    return funds.filter(f => selectedFundIds.includes(f.id || f.title));
  }, [funds, selectedFundIds]);

  // Funds available to add (not yet in comparison)
  const availableToAdd = useMemo(() => {
    const selectedIds = new Set(selectedFunds.map(f => f.id || f.title));
    return funds.filter(f => !selectedIds.has(f.id || f.title));
  }, [funds, selectedFunds]);

  // Calculations for best-in-class highlights
  const { minRateFundId, maxAmountFundId, longestPeriodFundId } = useMemo(() => {
    if (selectedFunds.length === 0) {
      return { minRateFundId: null, maxAmountFundId: null, longestPeriodFundId: null };
    }

    let minRate = Infinity;
    let minRateId: string | null = null;
    let maxAmount = -Infinity;
    let maxAmountId: string | null = null;
    let maxPeriod = -Infinity;
    let maxPeriodId: string | null = null;

    selectedFunds.forEach((fund) => {
      const fundKey = fund.id || fund.title;
      
      // Rate
      const rate = parseFundInterestRate(fund.interestRate);
      if (rate < minRate) {
        minRate = rate;
        minRateId = fundKey;
      }

      // Max Amount
      const amt = parseFundMaxAmount(fund.maxAmount);
      if (amt > maxAmount) {
        maxAmount = amt;
        maxAmountId = fundKey;
      }

      // Repayment period
      let periodYears = 5;
      if (fund.repaymentPeriod) {
        const m = fund.repaymentPeriod.match(/(\d+)/);
        if (m) periodYears = parseInt(m[0], 10);
      } else {
        const m = fund.description.match(/(\d+)년/);
        if (m) periodYears = parseInt(m[1], 10);
      }
      if (periodYears > maxPeriod) {
        maxPeriod = periodYears;
        maxPeriodId = fundKey;
      }
    });

    return { minRateFundId: minRateId, maxAmountFundId: maxAmountId, longestPeriodFundId: maxPeriodId };
  }, [selectedFunds]);

  // Chart data preparation for Recharts Bar Chart
  const chartData = useMemo(() => {
    return selectedFunds.map((fund, index) => {
      const fundKey = fund.id || fund.title;
      const parsedRate = parseFundInterestRate(fund.interestRate);
      const parsedAmount = parseFundMaxAmount(fund.maxAmount);
      
      // Format short title for axis label (max 10 chars)
      const shortName = fund.title.length > 9 
        ? fund.title.substring(0, 8) + '..' 
        : fund.title;

      // Amount in 10,000 KRW (만원 단위) for chart Y-axis scale
      const amountInManwon = Math.round(parsedAmount / 10000);
      const amountInEok = Number((parsedAmount / 100000000).toFixed(2));

      return {
        id: fundKey,
        name: shortName,
        fullName: fund.title,
        agency: fund.agency,
        category: fund.category,
        rate: parsedRate,
        rawRate: fund.interestRate,
        amountManwon: amountInManwon,
        amountEok: amountInEok,
        rawAmount: fund.maxAmount,
        formattedAmount: formatKoreanWon(parsedAmount),
        isMinRate: fundKey === minRateFundId,
        isMaxAmount: fundKey === maxAmountFundId,
        colorIndex: index
      };
    });
  }, [selectedFunds, minRateFundId, maxAmountFundId]);

  const handleAddFund = () => {
    if (!selectedAddFundId) return;
    const target = funds.find(f => (f.id || f.title) === selectedAddFundId);
    if (target) {
      onToggleSelectFund(target);
      setSelectedAddFundId('');
    }
  };

  const hasEnoughSelection = selectedFunds.length >= 2;

  // Custom Tooltip for Rate Bar Chart
  const CustomRateTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 text-white p-3.5 rounded-2xl shadow-xl border border-indigo-500/30 text-xs max-w-xs z-50">
          <div className="flex items-center justify-between gap-2 border-b border-slate-700/80 pb-2 mb-2">
            <span className="font-black text-white">{data.fullName}</span>
            <span className="text-[10px] text-indigo-300 font-bold bg-indigo-950/80 px-2 py-0.5 rounded-md border border-indigo-800">
              {data.agency}
            </span>
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">예상 대출 금리:</span>
              <span className="text-sm font-black text-indigo-400">연 {data.rate}%</span>
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>공식 표기:</span>
              <span className="font-bold text-slate-200">{data.rawRate}</span>
            </div>
            <div className="flex items-center justify-between text-[11px] text-emerald-400 pt-1 border-t border-slate-800">
              <span>시중은행(5.8%) 대비:</span>
              <span className="font-bold">연 {(5.8 - data.rate).toFixed(1)}%p 절감</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  // Custom Tooltip for Max Amount Bar Chart
  const CustomAmountTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 text-white p-3.5 rounded-2xl shadow-xl border border-emerald-500/30 text-xs max-w-xs z-50">
          <div className="flex items-center justify-between gap-2 border-b border-slate-700/80 pb-2 mb-2">
            <span className="font-black text-white">{data.fullName}</span>
            <span className="text-[10px] text-emerald-300 font-bold bg-emerald-950/80 px-2 py-0.5 rounded-md border border-emerald-800">
              {data.category}
            </span>
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">최대 대출 한도:</span>
              <span className="text-sm font-black text-emerald-400">{data.formattedAmount}</span>
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>공식 표기:</span>
              <span className="font-bold text-slate-200">{data.rawAmount}</span>
            </div>
            <div className="flex items-center justify-between text-[11px] text-slate-400">
              <span>주관 기관:</span>
              <span className="font-bold text-slate-300">{data.agency}</span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-slate-200/90 overflow-hidden mb-8 transition-all break-inside-avoid">
      {/* Table Header Section */}
      <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white border-b border-indigo-900/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-indigo-500/20 text-indigo-300 flex items-center justify-center border border-indigo-500/30 shadow-inner">
            <Scale className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-black uppercase tracking-wider text-indigo-300 bg-indigo-900/80 px-2.5 py-0.5 rounded-full border border-indigo-700/50">
                Side-by-Side Comparison & Visual Chart
              </span>
              <span className="text-xs font-black text-emerald-400 bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-700/40">
                {selectedFunds.length}개 자금 비교중 (최대 4개)
              </span>
            </div>
            <h3 className="text-xl font-black text-white tracking-tight mt-1 flex items-center gap-2">
              추천 정책자금 대출 조건 비교표 & 시각화 차트
            </h3>
            <p className="text-xs text-indigo-200/80 mt-0.5">
              관심 정책자금 2개 이상을 선택하여 금리·한도 바 차트와 상환기간, 자격 요건을 나란히 비교 분석하세요.
            </p>
          </div>
        </div>

        {/* Quick Selection Toolbar Buttons */}
        <div className="flex items-center gap-2 flex-wrap w-full md:w-auto justify-end">
          <button
            type="button"
            onClick={() => onQuickCompareTop(2)}
            className="px-3 py-1.5 bg-white/10 hover:bg-white/20 text-indigo-200 hover:text-white rounded-xl text-xs font-bold transition-all border border-white/15 cursor-pointer"
            title="AI 적합도 최상위 2개 자금 자동 선택"
          >
            상위 2개 비교
          </button>
          <button
            type="button"
            onClick={() => onQuickCompareTop(3)}
            className="px-3 py-1.5 bg-indigo-600/60 hover:bg-indigo-600 text-white rounded-xl text-xs font-bold transition-all border border-indigo-400/30 cursor-pointer shadow-xs"
            title="AI 적합도 최상위 3개 자금 자동 선택"
          >
            상위 3개 비교
          </button>
          <button
            type="button"
            onClick={() => onQuickCompareTop(4)}
            className="px-3 py-1.5 bg-indigo-600/60 hover:bg-indigo-600 text-white rounded-xl text-xs font-bold transition-all border border-indigo-400/30 cursor-pointer shadow-xs"
            title="AI 적합도 최상위 4개 자금 자동 선택"
          >
            상위 4개 비교
          </button>

          {selectedFundIds.length > 0 && (
            <button
              type="button"
              onClick={onClearSelection}
              className="px-2.5 py-1.5 text-slate-400 hover:text-rose-300 text-xs font-medium cursor-pointer transition-colors"
              title="비교 선택 초기화"
            >
              선택 초기화
            </button>
          )}

          {onOpenFullComparisonDashboard && (
            <button
              type="button"
              onClick={onOpenFullComparisonDashboard}
              className="px-3 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-xl text-xs font-black transition-all shadow-xs flex items-center gap-1.5 cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
              title="금리/한도/승인확률 차트 요약 비교 대시보드 전체화면으로 이동"
            >
              <BarChart3 className="w-3.5 h-3.5 text-purple-200" />
              <span>전체 비교 대시보드 (차트)</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white rounded-xl border border-white/10 transition-colors"
            title={isExpanded ? "비교표 접기" : "비교표 펼치기"}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Fund Chip Selector Bar */}
      <div className="p-4 bg-slate-50 border-b border-slate-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs font-black text-slate-700 flex items-center gap-1">
            <CheckSquare className="w-3.5 h-3.5 text-indigo-600" />
            자금 선택:
          </span>
          <div className="flex items-center gap-1.5 flex-wrap">
            {funds.map((fund) => {
              const fundKey = fund.id || fund.title;
              const isSelected = selectedFundIds.includes(fundKey);
              return (
                <button
                  key={fundKey}
                  type="button"
                  onClick={() => onToggleSelectFund(fund)}
                  className={`text-xs font-bold px-3 py-1.5 rounded-xl border transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs ${
                    isSelected
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-indigo-100 ring-2 ring-indigo-200'
                      : 'bg-white text-slate-700 border-slate-200 hover:border-indigo-200 hover:bg-indigo-50/40'
                  }`}
                >
                  {isSelected ? (
                    <CheckSquare className="w-3 h-3 text-white" />
                  ) : (
                    <Square className="w-3 h-3 text-slate-400" />
                  )}
                  <span className="max-w-[150px] truncate">{fund.title}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Dropdown to add fund if less than 4 */}
        {selectedFunds.length < 4 && availableToAdd.length > 0 && (
          <div className="flex items-center gap-1.5 w-full sm:w-auto justify-end">
            <select
              value={selectedAddFundId}
              onChange={(e) => setSelectedAddFundId(e.target.value)}
              className="bg-white text-slate-800 text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-200 outline-none max-w-[200px] cursor-pointer shadow-2xs"
            >
              <option value="">+ 추가할 자금 선택...</option>
              {availableToAdd.map(f => (
                <option key={f.id || f.title} value={f.id || f.title}>
                  {f.title} ({f.agency})
                </option>
              ))}
            </select>
            <button
              type="button"
              disabled={!selectedAddFundId}
              onClick={handleAddFund}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white text-xs font-black rounded-xl transition-all shadow-2xs cursor-pointer"
            >
              추가
            </button>
          </div>
        )}
      </div>

      {/* Main Content Area */}
      {isExpanded && (
        <div className="p-6 space-y-6">
          {!hasEnoughSelection ? (
            <div className="text-center py-12 px-4 bg-slate-50/70 rounded-2xl border-2 border-dashed border-slate-200">
              <Scale className="w-10 h-10 text-indigo-400 mx-auto mb-3 animate-bounce" />
              <h4 className="text-base font-black text-slate-800 mb-1">
                {selectedFunds.length === 0
                  ? '비교할 정책자금을 2개 이상 선택해 주세요'
                  : '1개의 자금이 선택되었습니다. 비교할 다른 자금을 추가로 선택해 주세요'}
              </h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto mb-5 leading-relaxed">
                각 자금 카드의 <span className="font-bold text-indigo-600">'비교 선택'</span> 버튼을 누르거나 아래 버튼을 클릭하여 상위 추천 자금을 즉시 비교할 수 있습니다.
              </p>
              <div className="flex items-center justify-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => onQuickCompareTop(2)}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  상위 2개 자금 바로 비교
                </button>
                <button
                  type="button"
                  onClick={() => onQuickCompareTop(3)}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-black rounded-xl transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                >
                  상위 3개 자금 바로 비교
                </button>
              </div>
            </div>
          ) : (
            <>
              {/* Highlight Metric Summary Bar */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                {/* 1. Lowest Interest Rate Banner */}
                <div className="bg-gradient-to-br from-indigo-50 to-blue-50/50 border border-indigo-100 p-4 rounded-2xl flex items-center gap-3.5 shadow-2xs">
                  <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-black shadow-xs shrink-0">
                    <Percent className="w-5 h-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] font-black uppercase text-indigo-500 block">최저 금리 우대 자금</span>
                    <span className="text-base font-black text-indigo-950 block">
                      {selectedFunds.find(f => (f.id || f.title) === minRateFundId)?.interestRate || '연 2.0%대'}
                    </span>
                    <span className="text-xs font-bold text-slate-600 block truncate" title={selectedFunds.find(f => (f.id || f.title) === minRateFundId)?.title}>
                      {selectedFunds.find(f => (f.id || f.title) === minRateFundId)?.title}
                    </span>
                  </div>
                </div>

                {/* 2. Maximum Loan Amount Banner */}
                <div className="bg-gradient-to-br from-emerald-50 to-teal-50/50 border border-emerald-100 p-4 rounded-2xl flex items-center gap-3.5 shadow-2xs">
                  <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black shadow-xs shrink-0">
                    <Banknote className="w-5 h-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] font-black uppercase text-emerald-600 block">최고 지원 한도</span>
                    <span className="text-base font-black text-emerald-950 block">
                      {selectedFunds.find(f => (f.id || f.title) === maxAmountFundId)?.maxAmount || '최대 5억원'}
                    </span>
                    <span className="text-xs font-bold text-slate-600 block truncate" title={selectedFunds.find(f => (f.id || f.title) === maxAmountFundId)?.title}>
                      {selectedFunds.find(f => (f.id || f.title) === maxAmountFundId)?.title}
                    </span>
                  </div>
                </div>

                {/* 3. Repayment Term Banner */}
                <div className="bg-gradient-to-br from-amber-50 to-orange-50/50 border border-amber-100 p-4 rounded-2xl flex items-center gap-3.5 shadow-2xs">
                  <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center font-black shadow-xs shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div className="min-w-0 flex-1">
                    <span className="text-[10px] font-black uppercase text-amber-600 block">최장 상환·거치 기간</span>
                    <span className="text-base font-black text-amber-950 block">
                      {selectedFunds.find(f => (f.id || f.title) === longestPeriodFundId)?.repaymentPeriod || '최대 5~10년'}
                    </span>
                    <span className="text-xs font-bold text-slate-600 block truncate" title={selectedFunds.find(f => (f.id || f.title) === longestPeriodFundId)?.title}>
                      {selectedFunds.find(f => (f.id || f.title) === longestPeriodFundId)?.title}
                    </span>
                  </div>
                </div>
              </div>

              {/* NEW: Visual Comparison Bar Charts Section */}
              <div className="bg-gradient-to-b from-slate-50 to-white rounded-2xl border border-slate-200/90 p-5 shadow-2xs space-y-4">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-200/80 pb-3.5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-2xs">
                      <BarChart3 className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                        <span>선택 자금 금리 & 한도 시각화 바 차트</span>
                        <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-md">
                          Recharts Bar Comparison
                        </span>
                      </h4>
                      <p className="text-[11px] text-slate-500 mt-0.5">
                        각 정책자금별 예상 금리(%)와 최대 지원 한도(억원)를 막대 차트로 직관적으로 비교할 수 있습니다.
                      </p>
                    </div>
                  </div>

                  {/* Chart View Switcher Controls */}
                  <div className="flex items-center gap-1 bg-slate-200/70 p-1 rounded-xl text-xs font-bold self-end sm:self-auto">
                    <button
                      type="button"
                      onClick={() => setChartViewMode('BOTH')}
                      className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                        chartViewMode === 'BOTH'
                          ? 'bg-white text-indigo-900 shadow-2xs font-black'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      전체 비교 (2열)
                    </button>
                    <button
                      type="button"
                      onClick={() => setChartViewMode('RATE')}
                      className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                        chartViewMode === 'RATE'
                          ? 'bg-white text-indigo-900 shadow-2xs font-black'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      금리 중심 (%)
                    </button>
                    <button
                      type="button"
                      onClick={() => setChartViewMode('AMOUNT')}
                      className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                        chartViewMode === 'AMOUNT'
                          ? 'bg-white text-emerald-900 shadow-2xs font-black'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      한도 중심 (억원)
                    </button>
                  </div>
                </div>

                {/* Charts Grid */}
                <div className={`grid gap-5 ${
                  chartViewMode === 'BOTH' ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'
                }`}>
                  {/* Chart 1: Interest Rate Bar Chart */}
                  {(chartViewMode === 'BOTH' || chartViewMode === 'RATE') && (
                    <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 inline-block"></span>
                          <span className="text-xs font-black text-slate-800">예상 대출 금리 비교 (%)</span>
                        </div>
                        <div className="flex items-center gap-2 text-[10px] text-slate-500 font-bold">
                          <span className="flex items-center gap-1">
                            <span className="w-2.5 h-1 bg-red-500 inline-block rounded-full"></span>
                            시중은행 평균: 연 5.8%
                          </span>
                        </div>
                      </div>

                      <div className="h-56 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={chartData}
                            margin={{ top: 20, right: 20, left: -10, bottom: 25 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                            <XAxis 
                              dataKey="name" 
                              tick={{ fontSize: 11, fill: '#475569', fontWeight: 600 }}
                              interval={0}
                              tickLine={false}
                              axisLine={{ stroke: '#e2e8f0' }}
                            />
                            <YAxis 
                              unit="%" 
                              domain={[0, 7]}
                              tick={{ fontSize: 10, fill: '#64748b' }}
                              tickLine={false}
                              axisLine={{ stroke: '#e2e8f0' }}
                            />
                            <Tooltip content={<CustomRateTooltip />} />
                            {/* Reference Line for Commercial Bank Average Rate */}
                            <ReferenceLine 
                              y={5.8} 
                              stroke="#ef4444" 
                              strokeDasharray="4 4" 
                              strokeWidth={1.5}
                              label={{ 
                                value: '시중은행 5.8%', 
                                position: 'top', 
                                fill: '#ef4444', 
                                fontSize: 10, 
                                fontWeight: 'bold' 
                              }} 
                            />
                            <Bar 
                              dataKey="rate" 
                              radius={[8, 8, 0, 0]}
                              barSize={38}
                            >
                              <LabelList 
                                dataKey="rate" 
                                position="top" 
                                formatter={(val: number) => `${val}%`}
                                style={{ fill: '#334155', fontSize: '11px', fontWeight: 'bold' }} 
                              />
                              {chartData.map((entry, index) => (
                                <Cell 
                                  key={`cell-rate-${index}`} 
                                  fill={entry.isMinRate ? '#4f46e5' : '#6366f1'} 
                                />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>

                      <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                        <span className="text-slate-500 font-medium">
                          최저 금리 우대: <strong className="text-indigo-700 font-black">
                            {selectedFunds.find(f => (f.id || f.title) === minRateFundId)?.title}
                          </strong>
                        </span>
                        <span className="text-emerald-700 font-black bg-emerald-50 px-2 py-0.5 rounded-md">
                          낮을수록 유리 ↓
                        </span>
                      </div>
                    </div>
                  )}

                  {/* Chart 2: Max Loan Amount Bar Chart */}
                  {(chartViewMode === 'BOTH' || chartViewMode === 'AMOUNT') && (
                    <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block"></span>
                          <span className="text-xs font-black text-slate-800">최대 지원 한도 비교 (억원)</span>
                        </div>
                        <span className="text-[10px] text-slate-500 font-bold bg-slate-100 px-2 py-0.5 rounded-md">
                          단위: 억원
                        </span>
                      </div>

                      <div className="h-56 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={chartData}
                            margin={{ top: 20, right: 20, left: -10, bottom: 25 }}
                          >
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                            <XAxis 
                              dataKey="name" 
                              tick={{ fontSize: 11, fill: '#475569', fontWeight: 600 }}
                              interval={0}
                              tickLine={false}
                              axisLine={{ stroke: '#e2e8f0' }}
                            />
                            <YAxis 
                              unit="억" 
                              tick={{ fontSize: 10, fill: '#64748b' }}
                              tickLine={false}
                              axisLine={{ stroke: '#e2e8f0' }}
                            />
                            <Tooltip content={<CustomAmountTooltip />} />
                            <Bar 
                              dataKey="amountEok" 
                              radius={[8, 8, 0, 0]}
                              barSize={38}
                            >
                              <LabelList 
                                dataKey="amountEok" 
                                position="top" 
                                formatter={(val: number) => `${val}억`}
                                style={{ fill: '#065f46', fontSize: '11px', fontWeight: 'bold' }} 
                              />
                              {chartData.map((entry, index) => (
                                <Cell 
                                  key={`cell-amount-${index}`} 
                                  fill={entry.isMaxAmount ? '#059669' : '#10b981'} 
                                />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>

                      <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                        <span className="text-slate-500 font-medium">
                          최고 한도 자금: <strong className="text-emerald-700 font-black">
                            {selectedFunds.find(f => (f.id || f.title) === maxAmountFundId)?.title}
                          </strong>
                        </span>
                        <span className="text-indigo-700 font-black bg-indigo-50 px-2 py-0.5 rounded-md">
                          높을수록 넉넉 ↑
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Side-by-Side Comparison Table Grid */}
              <div className="border border-slate-200 rounded-2xl overflow-x-auto shadow-xs bg-white">
                <table className="w-full text-left border-collapse min-w-[720px]">
                  <thead>
                    <tr className="bg-slate-100/80 border-b border-slate-200">
                      <th className="p-4 w-44 min-w-[170px] text-xs font-black text-slate-600 uppercase tracking-wider bg-slate-100 sticky left-0 z-10 border-r border-slate-200">
                        비교 세부 항목
                      </th>
                      {selectedFunds.map((fund, idx) => {
                        const fundKey = fund.id || fund.title;
                        const isFav = favorites.some(item => ('title' in item ? item.title : item.name) === fund.title);
                        return (
                          <th key={fundKey} className="p-4 min-w-[240px] align-top border-r border-slate-200 last:border-r-0 bg-white">
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <span className="text-[10px] font-black text-indigo-700 bg-indigo-50 border border-indigo-100 px-2.5 py-0.5 rounded-md">
                                자금 0{idx + 1}
                              </span>
                              <div className="flex items-center gap-1">
                                {onToggleFavorite && (
                                  <button
                                    type="button"
                                    onClick={() => onToggleFavorite(fund)}
                                    className={`p-1 rounded-md transition-colors ${
                                      isFav ? 'text-amber-500 bg-amber-50' : 'text-slate-400 hover:text-amber-500 hover:bg-slate-100'
                                    }`}
                                    title={isFav ? '즐겨찾기 해제' : '즐겨찾기'}
                                  >
                                    <Star className={`w-4 h-4 ${isFav ? 'fill-amber-400' : ''}`} />
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => onToggleSelectFund(fund)}
                                  className="p-1 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-md transition-colors"
                                  title="비교에서 제외"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                            <h4 className="text-base font-black text-slate-900 leading-snug mb-1">
                              {fund.title}
                            </h4>
                            <div className="flex items-center gap-1.5 text-xs text-slate-500 font-bold">
                              <Building className="w-3.5 h-3.5 text-slate-400" />
                              <span>{fund.agency}</span>
                            </div>
                          </th>
                        );
                      })}
                    </tr>
                  </thead>

                  <tbody className="divide-y divide-slate-100 text-xs">
                    {/* 1. Interest Rate Row (Prominent) */}
                    <tr className="bg-indigo-50/20">
                      <td className="p-4 font-black text-slate-900 bg-slate-50/90 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <Percent className="w-4 h-4 text-indigo-600" />
                        <span>예상 대출 금리</span>
                      </td>
                      {selectedFunds.map((fund) => {
                        const fundKey = fund.id || fund.title;
                        const isMin = fundKey === minRateFundId;
                        return (
                          <td key={`rate-${fundKey}`} className="p-4 border-r border-slate-200 last:border-r-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-base font-black text-indigo-700">
                                {fund.interestRate}
                              </span>
                              {isMin && (
                                <span className="px-2 py-0.5 bg-indigo-600 text-white text-[10px] font-black rounded-full shadow-xs">
                                  최저 금리 우대
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-slate-500 block mt-1">
                              기준금리 변동 및 지자체 이차보전 적용 가능
                            </span>
                          </td>
                        );
                      })}
                    </tr>

                    {/* 2. Max Loan Limit & Category */}
                    <tr className="bg-emerald-50/15">
                      <td className="p-4 font-black text-slate-900 bg-slate-50/90 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <Banknote className="w-4 h-4 text-emerald-600" />
                        <span>최대 대출 한도 / 분야</span>
                      </td>
                      {selectedFunds.map((fund) => {
                        const fundKey = fund.id || fund.title;
                        const isMax = fundKey === maxAmountFundId;
                        return (
                          <td key={`amt-${fundKey}`} className="p-4 border-r border-slate-200 last:border-r-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-base font-black text-slate-900">
                                {fund.maxAmount}
                              </span>
                              {isMax && (
                                <span className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-black rounded-full shadow-xs">
                                  최고 한도
                                </span>
                              )}
                            </div>
                            <div className="mt-1 flex items-center gap-1.5">
                              <span className="px-2 py-0.5 bg-blue-50 text-blue-700 font-bold rounded text-[10px] border border-blue-100">
                                {fund.category}
                              </span>
                              {(fund.currentStatus === 'BUDGET_ALMOST_EXHAUSTED' || (fund.budgetExhaustionRate && fund.budgetExhaustionRate >= 80)) && (
                                <span className="px-2 py-0.5 bg-red-100 text-red-700 font-black rounded text-[10px] animate-pulse">
                                  예산 소진 임박 {fund.budgetExhaustionRate ? `(${fund.budgetExhaustionRate}%)` : ''}
                                </span>
                              )}
                            </div>
                          </td>
                        );
                      })}
                    </tr>

                    {/* 3. Repayment Period & Grace Period Row */}
                    <tr className="bg-amber-50/15">
                      <td className="p-4 font-black text-slate-900 bg-slate-50/90 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <Clock className="w-4 h-4 text-amber-600" />
                        <span>상환 및 거치기간</span>
                      </td>
                      {selectedFunds.map((fund) => {
                        const fundKey = fund.id || fund.title;
                        const isLongest = fundKey === longestPeriodFundId;
                        return (
                          <td key={`period-${fundKey}`} className="p-4 border-r border-slate-200 last:border-r-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-black text-slate-900 text-xs">
                                {fund.repaymentPeriod || '5년 (거치기간 2년 포함)'}
                              </span>
                              {isLongest && (
                                <span className="px-2 py-0.5 bg-amber-600 text-white text-[10px] font-black rounded-full shadow-xs">
                                  최장 기간
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-slate-500 mt-1 block">
                              원금균등분할상환 (거치기간 중 이자만 납부)
                            </span>
                          </td>
                        );
                      })}
                    </tr>

                    {/* 4. Monthly Payment Simulation Benchmark */}
                    <tr>
                      <td className="p-4 font-black text-slate-900 bg-slate-50/90 sticky left-0 border-r border-slate-200">
                        <div className="flex items-center gap-2">
                          <Calculator className="w-4 h-4 text-emerald-600" />
                          <span>월 상환액 시뮬레이션</span>
                        </div>
                        <span className="block text-[10px] font-normal text-slate-500 mt-1">
                          (5,000만원 대출 / 5년 기준)
                        </span>
                      </td>
                      {selectedFunds.map((fund) => {
                        const fundKey = fund.id || fund.title;
                        const rate = parseFundInterestRate(fund.interestRate);
                        const sim = calculateLoanSimulation(benchmarkAmount, rate, 5, 2, 'EQUAL_PRINCIPAL', 5.8);
                        return (
                          <td key={`sim-${fundKey}`} className="p-4 border-r border-slate-200 last:border-r-0">
                            <div className="space-y-1.5 text-xs bg-white p-3 rounded-xl border border-emerald-100">
                              <div className="flex items-center justify-between">
                                <span className="text-slate-500">거치기간 월이자:</span>
                                <span className="font-bold text-slate-800">{formatKoreanWon(sim.firstMonthlyPayment)}</span>
                              </div>
                              <div className="flex items-center justify-between">
                                <span className="text-slate-500">상환기 평균부담:</span>
                                <span className="font-black text-indigo-700">월 {formatKoreanWon(sim.avgMonthlyPayment)}</span>
                              </div>
                              <div className="flex items-center justify-between pt-1 border-t border-slate-100">
                                <span className="text-slate-500">총 부담 이자:</span>
                                <span className="font-bold text-emerald-700">{formatKoreanWon(sim.totalInterest)}</span>
                              </div>
                              <div className="bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded-md text-[10px] font-black text-center mt-1">
                                시중은행 대비 약 {formatKoreanWon(sim.interestSaved)} 절약
                              </div>
                            </div>
                          </td>
                        );
                      })}
                    </tr>

                    {/* NEW: Condition Fit & Industry Average */}
                    <tr>
                      <td className="p-4 font-black text-slate-900 bg-slate-50/90 sticky left-0 border-r border-slate-200">
                        <div className="flex items-center gap-2">
                          <Target className="w-4 h-4 text-purple-600" />
                          <span>AI 조건 적합도 및 업종 평균</span>
                        </div>
                      </td>
                      {selectedFunds.map((fund) => {
                        const fundKey = fund.id || fund.title;
                        const dlReport = generateDeepLearningApprovalReport(profile, fund);
                        const fitScore = dlReport.overallProbability;
                        const tierInfo = getApprovalLikelihoodTier(fitScore);
                        
                        // Mock Industry Average (Deterministic based on fund title length and profile)
                        const industryAvg = 50 + ((fund.title.length * 7) % 25);
                        
                        return (
                          <td key={`fit-${fundKey}`} className="p-4 border-r border-slate-200 last:border-r-0 align-top">
                            <div className="space-y-3 bg-white p-3.5 rounded-xl border border-purple-100/50 shadow-2xs">
                              {/* My Fit */}
                              <div>
                                <div className="flex items-center justify-between mb-1.5">
                                  <span className="text-xs font-bold text-slate-600">내 조건 적합도</span>
                                  <span className="text-sm font-black text-purple-700">{fitScore}%</span>
                                </div>
                                <div className="w-full bg-slate-100 rounded-full h-2">
                                  <div 
                                    className="h-2 rounded-full bg-gradient-to-r from-purple-500 to-indigo-500" 
                                    style={{ width: `${fitScore}%` }}
                                  ></div>
                                </div>
                                <div className="mt-1.5 flex justify-end">
                                  <span 
                                    className="text-[10px] px-2 py-0.5 rounded-md font-bold"
                                    style={{ backgroundColor: tierInfo.bgColor, color: tierInfo.color }}
                                  >
                                    {tierInfo.tierKorean}
                                  </span>
                                </div>
                              </div>
                              
                              {/* Industry Average */}
                              <div className="pt-2 border-t border-slate-100">
                                <div className="flex items-center justify-between mb-1.5">
                                  <span className="text-[11px] font-bold text-slate-500">내 업종 평균 적합도</span>
                                  <span className="text-xs font-black text-slate-700">{industryAvg}%</span>
                                </div>
                                <div className="w-full bg-slate-100 rounded-full h-1.5">
                                  <div 
                                    className="h-1.5 rounded-full bg-slate-400" 
                                    style={{ width: `${industryAvg}%` }}
                                  ></div>
                                </div>
                              </div>
                              
                              {/* Comparison Indicator */}
                              <div className="mt-2 text-center">
                                {fitScore >= industryAvg ? (
                                  <span className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded flex items-center justify-center gap-1">
                                    <TrendingUp className="w-3 h-3" /> 업종 평균 대비 {(fitScore - industryAvg).toFixed(0)}%p 높음
                                  </span>
                                ) : (
                                  <span className="text-[10px] font-black text-rose-500 bg-rose-50 px-2 py-0.5 rounded flex items-center justify-center gap-1">
                                    <TrendingDown className="w-3 h-3" /> 업종 평균 대비 {(industryAvg - fitScore).toFixed(0)}%p 낮음
                                  </span>
                                )}
                              </div>
                            </div>
                          </td>
                        );
                      })}
                    </tr>

                    {/* 5. Eligibility Criteria Row (Prominent) */}
                    <tr>
                      <td className="p-4 font-black text-slate-700 bg-slate-50/60 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4 text-emerald-600" />
                        <span>지원 대상 및 자격 요건</span>
                      </td>
                      {selectedFunds.map((fund) => (
                        <td key={`elig-${fund.id || fund.title}`} className="p-4 border-r border-slate-200 last:border-r-0 align-top">
                          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 text-slate-700 text-xs leading-relaxed max-h-40 overflow-y-auto font-medium">
                            {fund.eligibility}
                          </div>
                        </td>
                      ))}
                    </tr>

                    {/* 6. Application Deadline */}
                    <tr>
                      <td className="p-4 font-black text-slate-700 bg-slate-50/60 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-blue-500" />
                        <span>신청 기한</span>
                      </td>
                      {selectedFunds.map((fund) => (
                        <td key={`dl-${fund.id || fund.title}`} className="p-4 border-r border-slate-200 last:border-r-0">
                          <span className="font-bold text-slate-800 text-xs block">
                            {fund.applicationDeadline || '연중 상시 (예산 소진 시 조기 마감)'}
                          </span>
                          {onScheduleCalendar && (
                            <button
                              type="button"
                              onClick={() => onScheduleCalendar(fund)}
                              className="mt-1.5 inline-flex items-center gap-1 text-[10px] text-indigo-700 hover:text-indigo-900 font-bold bg-indigo-50 hover:bg-indigo-100 px-2 py-1 rounded-lg transition-colors cursor-pointer"
                            >
                              <Calendar className="w-3 h-3" />
                              캘린더 일정 등록
                            </button>
                          )}
                        </td>
                      ))}
                    </tr>

                    {/* 7. Required Documents */}
                    <tr>
                      <td className="p-4 font-black text-slate-700 bg-slate-50/60 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                        <span>필수 제출 서류</span>
                      </td>
                      {selectedFunds.map((fund) => (
                        <td key={`docs-${fund.id || fund.title}`} className="p-4 border-r border-slate-200 last:border-r-0 align-top">
                          <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                            {fund.requiredDocuments && fund.requiredDocuments.length > 0 ? (
                              fund.requiredDocuments.map((doc, docIdx) => {
                                const info = matchDocumentToIssuanceInfo(doc);
                                return (
                                  <div
                                    key={docIdx}
                                    className="p-1.5 bg-slate-50 hover:bg-blue-50/60 rounded-lg border border-slate-200/80 flex items-center justify-between gap-1.5 transition-colors"
                                  >
                                    <div className="flex items-center gap-1.5 min-w-0 flex-1">
                                      <CheckCircle2 className="w-3 h-3 text-emerald-500 flex-shrink-0" />
                                      <span className="text-[11px] font-bold text-slate-800 truncate" title={doc}>
                                        {doc}
                                      </span>
                                    </div>
                                    <a
                                      href={info.issuanceUrl}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="text-[9px] font-black px-1.5 py-0.5 bg-white text-blue-700 hover:bg-blue-600 hover:text-white rounded border border-blue-200 shrink-0 flex items-center gap-0.5 transition-colors"
                                      title={`${info.agencyName} 발급 바로가기`}
                                    >
                                      <span>발급</span>
                                      <ExternalLink className="w-2 h-2" />
                                    </a>
                                  </div>
                                );
                              })
                            ) : (
                              <span className="text-slate-400 italic text-xs">사업자등록증, 부가세증명원 등 기본 서류</span>
                            )}
                          </div>
                        </td>
                      ))}
                    </tr>

                    {/* 8. Fund Purpose & Description */}
                    <tr>
                      <td className="p-4 font-black text-slate-700 bg-slate-50/60 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <FileCheck2 className="w-4 h-4 text-purple-500" />
                        <span>자금 개요 및 용도</span>
                      </td>
                      {selectedFunds.map((fund) => (
                        <td key={`desc-${fund.id || fund.title}`} className="p-4 border-r border-slate-200 last:border-r-0 align-top">
                          <p className="text-slate-600 text-xs leading-relaxed line-clamp-3">
                            {fund.description}
                          </p>
                        </td>
                      ))}
                    </tr>

                    {/* 9. Action Buttons Row */}
                    <tr className="bg-slate-50/80">
                      <td className="p-4 font-black text-slate-900 bg-slate-100 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <Zap className="w-4 h-4 text-amber-500" />
                        <span>신청 및 상담 액션</span>
                      </td>
                      {selectedFunds.map((fund) => (
                        <td key={`action-${fund.id || fund.title}`} className="p-4 border-r border-slate-200 last:border-r-0">
                          <div className="space-y-2">
                            {onOpenConsultation && (
                              <button
                                type="button"
                                onClick={() => onOpenConsultation(fund)}
                                className="w-full py-2 px-3 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white font-black text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5 cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
                              >
                                <Headphones className="w-3.5 h-3.5" />
                                <span>1:1 상담 문의</span>
                              </button>
                            )}
                            {onOpenPdfChecklist && (
                              <button
                                type="button"
                                onClick={() => onOpenPdfChecklist(fund)}
                                className="w-full py-1.5 px-3 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl border border-slate-200 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                              >
                                <FileCheck2 className="w-3.5 h-3.5 text-blue-600" />
                                <span>PDF 체크리스트</span>
                              </button>
                            )}
                          </div>
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
};
