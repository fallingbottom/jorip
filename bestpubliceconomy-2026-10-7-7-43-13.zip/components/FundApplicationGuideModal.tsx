import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X,
  ExternalLink,
  FileText,
  CheckCircle2,
  ArrowRight,
  Building2,
  MapPin,
  Sparkles,
  Loader2,
  PenTool,
  HelpCircle,
  Clock,
  ShieldCheck,
  Lightbulb,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  AlertTriangle,
  User,
  Hash,
  Coins
} from 'lucide-react';
import { PolicyFund, UserProfile } from '../types';
import { generateTailoredApplicationGuide } from '../services/geminiService';
import { GovernmentDocumentDraftModal } from './GovernmentDocumentDraftModal';
import { GovernmentDocType } from '../src/types/documentDraft';

interface FundApplicationGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
  fund: PolicyFund | null;
  profile?: UserProfile | null;
}

export const FundApplicationGuideModal: React.FC<FundApplicationGuideModalProps> = ({
  isOpen,
  onClose,
  fund,
  profile
}) => {
  const [modalTab, setModalTab] = useState<'PROCEDURE' | 'DOCUMENTS' | 'WRITING_EXAMPLE' | 'FAQ'>('PROCEDURE');
  const [isGenerating, setIsGenerating] = useState(false);
  const [customGuide, setCustomGuide] = useState<any>(null);
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [expandedFaqIndex, setExpandedFaqIndex] = useState<number | null>(0);
  const [isDraftModalOpen, setIsDraftModalOpen] = useState(false);
  const [draftDocType, setDraftDocType] = useState<GovernmentDocType>('APPLICATION_FORM');

  if (!isOpen || !fund) return null;

  const handleGenerateCustomGuide = async () => {
    setIsGenerating(true);
    try {
      const result = await generateTailoredApplicationGuide(profile || null, fund);
      setCustomGuide(result);
    } catch (error) {
      console.error(error);
      alert('가이드 생성 중 오류가 발생했습니다.');
    } finally {
      setIsGenerating(false);
    }
  };

  const resetModal = () => {
    setCustomGuide(null);
    onClose();
  };

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(key);
    setTimeout(() => setCopiedSection(null), 2000);
  };

  // Fund-specific FAQs
  const fundFaqs = [
    {
      q: `${fund.title}의 신청 자격과 한도는 어떻게 되나요?`,
      a: `지원 한도는 ${fund.maxAmount}이며, 예상 금리는 ${fund.interestRate} 수준입니다. 주관 기관은 ${fund.agency}이며, 소상공인 기준(상시근로자 5인 미만, 제조업/건설업 등 10인 미만)을 충족해야 합니다.`
    },
    {
      q: '신청 시 가장 중요한 필수 서류와 발급처는 어디인가요?',
      a: '사업자등록증명(홈택스), 최근 3개년 부가가치세 과세표준증명원(홈택스), 국세 완납증명서(홈택스), 지방세 납세증명서(정부24)가 공통 필수 서류입니다. 모든 서류는 신청일 기준 1개월 이내 발급분이어야 합니다.'
    },
    {
      q: '신청 후 최종 계좌 입금까지 얼마나 걸리나요?',
      a: '소진공 직접대출의 경우 서류 완비 시 평균 5~7영업일, 보증기관 및 은행을 거치는 대리대출은 보증심사 및 현장실사를 포함하여 통상 2~3주가 소요됩니다.'
    },
    {
      q: '사업계획서 작성 시 주의할 점은 무엇인가요?',
      a: '생활비나 모호한 운영비 목적 대신 구체적인 자금 소요 내역(원자재 대량 구매, 고효율 설비 교체 등)과 견적서를 첨부하고, 월 예상 원리금을 초과하는 순익 창출 및 상환 계획을 명시해야 승인율이 높아집니다.'
    }
  ];

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
          onClick={resetModal}
        />
        
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.95 }}
          className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        >
          {/* Header */}
          <div className="flex-shrink-0 border-b border-slate-100 p-5 sm:p-6 bg-slate-50">
            <div className="flex items-start justify-between gap-4">
              <div>
                <div className="flex flex-wrap items-center gap-2 mb-1.5">
                  <span className="px-2.5 py-1 bg-blue-100 text-blue-700 text-xs font-bold rounded-lg">
                    {fund.agency}
                  </span>
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-lg">
                    {fund.maxAmount}
                  </span>
                  {!customGuide && (
                    <button 
                      onClick={handleGenerateCustomGuide}
                      disabled={isGenerating}
                      className="flex items-center gap-1.5 px-3 py-1 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-bold hover:bg-indigo-100 transition-colors disabled:opacity-50 cursor-pointer"
                    >
                      {isGenerating ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-indigo-500" />}
                      {isGenerating ? 'AI 맞춤 가이드 생성 중...' : 'AI 맞춤 가이드 생성하기'}
                    </button>
                  )}
                </div>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900">{fund.title}</h2>
                <p className="text-slate-500 text-xs sm:text-sm mt-0.5">상세 신청 절차, 필수 서류 목록, 작성 예시 및 FAQ 종합 안내</p>
              </div>
              <button
                onClick={resetModal}
                className="p-2 text-slate-400 hover:bg-slate-200 hover:text-slate-600 rounded-full transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Internal Tabs */}
            <div className="flex items-center gap-1.5 mt-4 pt-3 border-t border-slate-200/60 overflow-x-auto pb-0.5">
              <button
                type="button"
                onClick={() => setModalTab('PROCEDURE')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
                  modalTab === 'PROCEDURE' ? 'bg-slate-900 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200/70'
                }`}
              >
                <MapPin className="w-3.5 h-3.5" />
                <span>1. 신청 절차</span>
              </button>

              <button
                type="button"
                onClick={() => setModalTab('DOCUMENTS')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
                  modalTab === 'DOCUMENTS' ? 'bg-slate-900 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200/70'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>2. 필수 서류 ({fund.requiredDocuments?.length || 4})</span>
              </button>

              <button
                type="button"
                onClick={() => setModalTab('WRITING_EXAMPLE')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
                  modalTab === 'WRITING_EXAMPLE' ? 'bg-slate-900 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200/70'
                }`}
              >
                <PenTool className="w-3.5 h-3.5" />
                <span>3. 서류 작성 예시</span>
              </button>

              <button
                type="button"
                onClick={() => setModalTab('FAQ')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
                  modalTab === 'FAQ' ? 'bg-slate-900 text-white shadow-xs' : 'bg-slate-100 text-slate-600 hover:bg-slate-200/70'
                }`}
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>4. 전용 FAQ</span>
              </button>
            </div>
          </div>

          {/* Scrollable Content */}
          <div className="flex-1 overflow-y-auto p-5 sm:p-6 bg-slate-50 space-y-5">
            {/* Profile Auto-fill Preview Card */}
            <div className="p-4 bg-white rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3.5">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2 text-xs">
                  <span className="flex items-center gap-1.5 text-emerald-700 font-semibold">
                    <span className="w-2 h-2 rounded-full bg-emerald-500" />
                    프로필 자동 완성 연동
                  </span>
                  <span aria-hidden="true" className="text-slate-300">·</span>
                  <span className="text-slate-500">
                    신청서 및 계획서 서식 즉시 반영
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-x-3.5 gap-y-1 text-xs text-slate-600">
                  <span>상호: <strong className="text-slate-900 font-bold">{profile?.businessName || '대한상사'}</strong></span>
                  <span aria-hidden="true" className="text-slate-300">·</span>
                  <span>대표: <strong className="text-slate-900 font-bold">{profile?.name || '홍길동'}</strong></span>
                  <span aria-hidden="true" className="text-slate-300">·</span>
                  <span>등록번호: <strong className="text-slate-900 font-bold font-mono">{profile?.businessRegistrationNumber || '123-45-67890'}</strong></span>
                  <span aria-hidden="true" className="text-slate-300">·</span>
                  <span>소재지: <strong className="text-slate-900 font-bold">{profile?.businessAddress || profile?.location || '서울 영등포구'}</strong></span>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setDraftDocType('APPLICATION_FORM');
                    setIsDraftModalOpen(true);
                  }}
                  className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer active:scale-95"
                >
                  <Sparkles className="w-3.5 h-3.5 text-indigo-300" />
                  <span>신청서 자동 입력 열기</span>
                </button>
              </div>
            </div>

            {/* Custom AI Guide if Generated */}
            {customGuide && (
              <div className="mb-6 p-4 bg-indigo-50/80 rounded-2xl border border-indigo-200 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <Sparkles className="w-5 h-5 text-indigo-600 shrink-0" />
                  <span className="text-xs font-black text-indigo-900">
                    {profile?.businessName || '내 사업장'} 맞춤 AI 정밀 가이드가 적용되었습니다.
                  </span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-200 text-indigo-800">
                  AI 생성 완료
                </span>
              </div>
            )}

            {/* TAB 1: PROCEDURE */}
            {modalTab === 'PROCEDURE' && (
              <div className="space-y-6">
                {customGuide ? (
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
                    <h3 className="text-base font-black text-slate-900 mb-5 flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-indigo-600" />
                      AI 맞춤형 단계별 신청 로드맵
                    </h3>
                    <div className="relative">
                      <div className="absolute left-5 top-4 bottom-4 w-0.5 bg-indigo-100" />
                      <div className="space-y-6">
                        {customGuide.customProcedure.map((step: any, idx: number) => (
                          <div key={idx} className="relative flex items-start gap-4">
                            <div className="w-10 h-10 rounded-full bg-indigo-50 border-4 border-white shadow-xs flex items-center justify-center text-indigo-600 font-black z-10 shrink-0 text-sm">
                              {step.step || idx + 1}
                            </div>
                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex-1 space-y-1">
                              <div className="flex items-center justify-between">
                                <h4 className="font-bold text-slate-800 text-sm">{step.title}</h4>
                                <span className="text-[11px] font-bold text-indigo-600 bg-indigo-100 px-2 py-0.5 rounded-full">
                                  소요: {step.estimatedDays}
                                </span>
                              </div>
                              <p className="text-slate-600 text-xs leading-relaxed">{step.detail}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-5">
                    <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                      <MapPin className="w-5 h-5 text-blue-600" />
                      기본 신청 및 심사 4단계 절차
                    </h3>
                    <div className="relative">
                      <div className="absolute left-5 top-4 bottom-4 w-0.5 bg-blue-100" />
                      <div className="space-y-6">
                        {(fund.applicationProcedure && fund.applicationProcedure.length > 0 ? fund.applicationProcedure : [
                          '소상공인24 또는 소진공 정책자금 누리집 온라인 자가진단 및 신청 접수',
                          '정책자금 지원대상 확인서 발급 및 구비서류 전산 확인',
                          '지역신용보증재단/신보 보증심사 및 사업장 현장 실사',
                          '취급 시중은행 대출 약정 체결 및 최종 자금 입금(실행)'
                        ]).map((step, idx) => (
                          <div key={idx} className="relative flex items-start gap-4">
                            <div className="w-10 h-10 rounded-full bg-blue-50 border-4 border-white shadow-xs flex items-center justify-center text-blue-600 font-black z-10 shrink-0 text-sm">
                              {idx + 1}
                            </div>
                            <div className="pt-2 flex-1">
                              <h4 className="font-bold text-slate-800 text-sm">{step}</h4>
                              <p className="text-xs text-slate-500 mt-1">
                                {idx === 0 && '공동인증서/간편인증 로그인 후 사업장 기본 매출 및 고용 인원 입력'}
                                {idx === 1 && '공단 시스템에서 적격 여부 확인 후 정책자금 지원대상 확인서 발급'}
                                {idx === 2 && '사업장 간판, 임대차계약서, 현장 정상 영업 여부 확인'}
                                {idx === 3 && '은행 모바일 또는 영업점 창구에서 대출 약정서 서명 후 통장 입금'}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: DOCUMENTS */}
            {modalTab === 'DOCUMENTS' && (
              <div className="space-y-4">
                <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                      <FileText className="w-5 h-5 text-indigo-600" />
                      {fund.title} 필수 구비 서류 목록
                    </h3>
                    <span className="text-xs font-bold text-slate-500">
                      신청일 기준 1개월 이내 발급분
                    </span>
                  </div>

                  <div className="space-y-3">
                    {(customGuide ? customGuide.documentChecklist : (fund.requiredDocuments || [])).map((doc: any, idx: number) => {
                      const docName = typeof doc === 'string' ? doc : doc.name;
                      const issuePlace = typeof doc === 'object' ? doc.issuePlace : '국세청 홈택스 / 정부24';
                      const tip = typeof doc === 'object' ? doc.tip : '인터넷 무료 즉시 발급 가능 (주민번호 전체 공개)';

                      return (
                        <div key={idx} className="p-3.5 bg-slate-50 rounded-xl border border-slate-100 flex items-start justify-between gap-3">
                          <div className="flex items-start gap-2.5">
                            <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                            <div>
                              <span className="text-xs font-black text-slate-900 block">{docName}</span>
                              <span className="text-[11px] text-slate-500 mt-0.5 block">
                                발급처: {issuePlace} · {tip}
                              </span>
                            </div>
                          </div>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 shrink-0">
                            필수
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="p-4 bg-indigo-50/70 rounded-2xl border border-indigo-200 text-xs text-indigo-900 flex items-start gap-2">
                  <Lightbulb className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    <strong>발급 팁:</strong> 홈택스 및 정부24에서 발급 시 "주민등록번호 13자리 전체 공개" 및 "관공서/금융기관 제출용"을 선택해야 은행에서 재발급 요청을 받지 않습니다.
                  </p>
                </div>

                {/* Instant Government Form Auto-generation Banner */}
                <div className="p-5 bg-gradient-to-r from-blue-600 via-indigo-600 to-indigo-700 text-white rounded-2xl shadow-md flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-white/20 text-white flex items-center justify-center shrink-0">
                      <Sparkles className="w-5 h-5 text-amber-300" />
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-white">
                        {profile?.businessName || '내 사업체'} 정보로 신청 서류 자동 생성
                      </h4>
                      <p className="text-xs text-blue-100 mt-0.5">
                        {fund.title} 맞춤 정책자금 융자신청서 및 기업현황표를 원클릭으로 작성·인쇄하세요.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <button
                      type="button"
                      onClick={() => {
                        setDraftDocType('APPLICATION_FORM');
                        setIsDraftModalOpen(true);
                      }}
                      className="flex-1 sm:flex-none px-4 py-2.5 bg-white text-indigo-700 hover:bg-blue-50 text-xs font-black rounded-xl transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <FileText className="w-3.5 h-3.5" />
                      <span>융자신청서 자동 생성</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setDraftDocType('BUSINESS_PLAN');
                        setIsDraftModalOpen(true);
                      }}
                      className="flex-1 sm:flex-none px-4 py-2.5 bg-indigo-500/80 hover:bg-indigo-500 text-white text-xs font-black rounded-xl transition-all border border-white/20 flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <PenTool className="w-3.5 h-3.5" />
                      <span>사업계획서 생성</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* TAB 3: WRITING EXAMPLE */}
            {modalTab === 'WRITING_EXAMPLE' && (
              <div className="space-y-4">
                <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                      <PenTool className="w-5 h-5 text-emerald-600" />
                      사업계획서 및 자금소요계획서 모범 작성 예시
                    </h3>
                  </div>

                  <div className="space-y-3">
                    <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-slate-900">💡 1. 사업 개요 및 현황 (모범 예시)</span>
                        <button
                          type="button"
                          onClick={() => handleCopy(
                            customGuide?.writingExample?.businessOverview || 
                            "2021년 개업 이래 지역 밀착형 한식 요식업을 운영 중이며, 배달 앱 평점 4.9점 및 단골 고객 38% 재방문율 유지. 최근 스마트 오더 도입 및 자체 밀키트 3종 개발로 월 매출이 전년 동기 대비 16.5% 안정 성장 추세임.",
                            'OVERVIEW'
                          )}
                          className="text-[11px] font-bold text-slate-600 hover:text-emerald-600 flex items-center gap-1 cursor-pointer"
                        >
                          {copiedSection === 'OVERVIEW' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                          <span>복사</span>
                        </button>
                      </div>
                      <p className="text-xs text-slate-700 leading-relaxed font-mono bg-white p-3 rounded-lg border border-slate-200">
                        "{customGuide?.writingExample?.businessOverview || 
                          "2021년 개업 이래 지역 밀착형 한식 요식업을 운영 중이며, 배달 앱 평점 4.9점 및 단골 고객 38% 재방문율 유지. 최근 스마트 오더 도입 및 자체 밀키트 3종 개발로 월 매출이 전년 동기 대비 16.5% 안정 성장 추세임."}"
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-slate-900">💡 2. 자금 소요 계획 (항목별 비용 산출)</span>
                        <button
                          type="button"
                          onClick={() => handleCopy(
                            customGuide?.writingExample?.usagePlan || 
                            "신청 금액 5,000만원: ① 원부자재 산지 대량구매로 원가 12% 절감(1,500만원 견적서 첨부) ② 고효율 주방설비 교체(1,500만원 견적서 첨부) ③ 청년 고용 유지 및 임차료(2,000만원).",
                            'USAGE'
                          )}
                          className="text-[11px] font-bold text-slate-600 hover:text-emerald-600 flex items-center gap-1 cursor-pointer"
                        >
                          {copiedSection === 'USAGE' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                          <span>복사</span>
                        </button>
                      </div>
                      <p className="text-xs text-slate-700 leading-relaxed font-mono bg-white p-3 rounded-lg border border-slate-200">
                        "{customGuide?.writingExample?.usagePlan || 
                          "신청 금액 5,000만원: ① 원부자재 산지 대량구매로 원가 12% 절감(1,500만원 견적서 첨부) ② 고효율 주방설비 교체(1,500만원 견적서 첨부) ③ 청년 고용 유지 및 임차료(2,000만원)."}"
                      </p>
                    </div>

                    <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-slate-900">💡 3. 매출 전망 및 원리금 상환 계획</span>
                        <button
                          type="button"
                          onClick={() => handleCopy(
                            customGuide?.writingExample?.repaymentPlan || 
                            "설비 개선으로 월 추가 매출 420만원(순익 160만원) 창출. 월 상환액 90만원 대비 1.7배 상회(DSCR > 1.7). 매월 카드 매출 입금액 중 100만원을 '상환 전용 통장'으로 자동 적립하여 리스크를 원천 차단함.",
                            'REPAYMENT'
                          )}
                          className="text-[11px] font-bold text-slate-600 hover:text-emerald-600 flex items-center gap-1 cursor-pointer"
                        >
                          {copiedSection === 'REPAYMENT' ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                          <span>복사</span>
                        </button>
                      </div>
                      <p className="text-xs text-slate-700 leading-relaxed font-mono bg-white p-3 rounded-lg border border-slate-200">
                        "{customGuide?.writingExample?.repaymentPlan || 
                          "설비 개선으로 월 추가 매출 420만원(순익 160만원) 창출. 월 상환액 90만원 대비 1.7배 상회(DSCR > 1.7). 매월 카드 매출 입금액 중 100만원을 '상환 전용 통장'으로 자동 적립하여 리스크를 원천 차단함."}"
                      </p>
                    </div>
                  </div>
                </div>

                {/* Instant Draft Button Card in Writing Tab */}
                <div className="p-4 bg-emerald-50/80 rounded-2xl border border-emerald-200 flex flex-col sm:flex-row items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <PenTool className="w-5 h-5 text-emerald-600 shrink-0" />
                    <div>
                      <span className="text-xs font-black text-emerald-950 block">
                        예시를 내 사업장 데이터에 맞게 바로 문서로 완성하기
                      </span>
                      <span className="text-[11px] text-emerald-700">
                        {fund.title} 표준 사업계획서·자금소요계획서 초안을 AI로 완성하고 PDF/인쇄하세요.
                      </span>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setDraftDocType('BUSINESS_PLAN');
                      setIsDraftModalOpen(true);
                    }}
                    className="w-full sm:w-auto px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>사업계획서 초안 생성기 열기</span>
                  </button>
                </div>
              </div>
            )}

            {/* TAB 4: FAQ */}
            {modalTab === 'FAQ' && (
              <div className="space-y-3">
                {fundFaqs.map((faq, idx) => {
                  const isExpanded = expandedFaqIndex === idx;
                  return (
                    <div
                      key={idx}
                      className="bg-white rounded-2xl border border-slate-200 overflow-hidden"
                    >
                      <button
                        type="button"
                        onClick={() => setExpandedFaqIndex(isExpanded ? null : idx)}
                        className="w-full p-4 text-left flex items-start justify-between gap-3 cursor-pointer"
                      >
                        <div className="flex items-start gap-2.5">
                          <span className="w-5 h-5 rounded-md bg-amber-100 text-amber-800 flex items-center justify-center font-black text-xs shrink-0 mt-0.5">
                            Q
                          </span>
                          <span className="text-xs sm:text-sm font-black text-slate-900 leading-snug">
                            {faq.q}
                          </span>
                        </div>
                        {isExpanded ? (
                          <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                        )}
                      </button>

                      {isExpanded && (
                        <div className="px-4 pb-4 pt-1 border-t border-slate-100 bg-slate-50/60">
                          <div className="flex items-start gap-2 text-xs text-slate-700 leading-relaxed">
                            <span className="w-5 h-5 rounded-md bg-blue-600 text-white flex items-center justify-center font-black text-[10px] shrink-0 mt-0.5">
                              A
                            </span>
                            <p className="flex-1">{faq.a}</p>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Footer with Apply Button */}
          <div className="flex-shrink-0 border-t border-slate-100 p-4 sm:p-6 bg-white">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="text-xs text-slate-500 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-slate-400" />
                <span>문의처: <strong className="text-slate-800">{fund.contactInfo || '1357 (중소기업통합콜센터)'}</strong></span>
              </div>
              
              <a 
                href={fund.applicationUrl || 'https://ols.semas.or.kr'} 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-full sm:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-lg shadow-blue-600/20 transition-all flex items-center justify-center gap-2 text-xs sm:text-sm"
              >
                <span>온라인 공식 신청 페이지로 이동</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Government Document Draft Modal for Instant PDF & Form Generation */}
      <GovernmentDocumentDraftModal
        isOpen={isDraftModalOpen}
        onClose={() => setIsDraftModalOpen(false)}
        fund={fund}
        profile={profile || undefined}
        initialDocType={draftDocType}
      />
    </AnimatePresence>
  );
};
