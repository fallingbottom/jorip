import React, { useState, useEffect } from 'react';
import { Check, Clock, FileText, Send, Building2, Award } from 'lucide-react';

interface FavoriteFundProgressProps {
  fundId: string;
}

const STEPS = [
  { id: 'prep', label: '서류 준비', icon: FileText },
  { id: 'submit', label: '접수 완료', icon: Send },
  { id: 'review', label: '심사 중', icon: Building2 },
  { id: 'approve', label: '승인 완료', icon: Award }
];

export const FavoriteFundProgress: React.FC<FavoriteFundProgressProps> = ({ fundId }) => {
  const [currentStepIndex, setCurrentStepIndex] = useState(-1);

  useEffect(() => {
    try {
      const saved = localStorage.getItem(`bizmatch_progress_${fundId}`);
      if (saved !== null) {
        setCurrentStepIndex(Number(saved));
      }
    } catch (e) {
      // ignore
    }
  }, [fundId]);

  const handleStepClick = (index: number) => {
    // If clicking the current step, maybe allow deselecting (going back one step)
    const newIndex = currentStepIndex === index ? index - 1 : index;
    setCurrentStepIndex(newIndex);
    try {
      localStorage.setItem(`bizmatch_progress_${fundId}`, String(newIndex));
    } catch (e) {
      // ignore
    }
  };

  return (
    <div className="mt-4 bg-slate-50 border border-slate-200 rounded-2xl p-4">
      <h4 className="text-xs font-black text-slate-700 mb-3 flex items-center gap-1.5">
        <Check className="w-3.5 h-3.5 text-slate-400" />
        진행 상황 체크
      </h4>
      <div className="relative z-0">
        <div className="absolute top-3.5 left-4 right-4 h-0.5 bg-slate-200 -z-10"></div>
        <div 
          className="absolute top-3.5 left-4 h-0.5 bg-blue-500 -z-10 transition-all duration-300"
          style={{ width: currentStepIndex > 0 ? `calc(${(currentStepIndex / (STEPS.length - 1)) * 100}% - 2rem)` : '0%' }}
        ></div>
        <div className="flex items-center justify-between">
          {STEPS.map((step, idx) => {
            const isCompleted = idx <= currentStepIndex;
            const isCurrent = idx === currentStepIndex;
            const Icon = step.icon;
            
            return (
              <button
                key={step.id}
                onClick={() => handleStepClick(idx)}
                className="flex flex-col items-center gap-1.5 group focus:outline-none relative z-10"
              >
                <div 
                  className={`w-7 h-7 rounded-full flex items-center justify-center transition-all shadow-sm border-2 ${
                    isCompleted 
                      ? 'bg-blue-500 border-blue-500 text-white' 
                      : 'bg-white border-slate-200 text-slate-400 hover:border-blue-300'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                </div>
                <span className={`text-[10px] font-bold ${
                  isCompleted ? 'text-blue-600' : 'text-slate-500 group-hover:text-slate-700'
                }`}>
                  {step.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
