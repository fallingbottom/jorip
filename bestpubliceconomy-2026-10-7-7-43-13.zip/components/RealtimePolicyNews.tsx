import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { UserProfile, PolicyNewsItem, PolicyNewsResponse, Industry, BusinessType } from '../types';
import { fetchRealtimePolicyNews } from '../services/geminiService';
import { 
  Globe, 
  RefreshCw, 
  ExternalLink, 
  Sparkles, 
  Search, 
  Filter, 
  Tag, 
  Building2, 
  Calendar, 
  AlertCircle, 
  CheckCircle2, 
  ArrowUpRight, 
  Share2, 
  Layers, 
  Zap, 
  Landmark, 
  FileText, 
  Info,
  Clock,
  MapPin,
  Briefcase,
  ChevronRight,
  TrendingUp,
  Bookmark,
  Check
} from 'lucide-react';

interface RealtimePolicyNewsProps {
  profile?: UserProfile | null;
  className?: string;
}

export const RealtimePolicyNews: React.FC<RealtimePolicyNewsProps> = ({ profile, className = '' }) => {
  const [newsData, setNewsData] = useState<PolicyNewsResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [searchKeyword, setSearchKeyword] = useState<string>('');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const regionName = useMemo(() => profile?.location || '전국', [profile?.location]);
  
  const industryName = useMemo(() => {
    switch (profile?.industry) {
      case Industry.MANUFACTURING: return '제조업';
      case Industry.IT_SOFTWARE: return 'IT/소프트웨어';
      case Industry.RETAIL: return '도소매업';
      case Industry.SERVICE: return '서비스업';
      case Industry.RESTAURANT: return '음식점업';
      default: return '소상공인 전체';
    }
  }, [profile?.industry]);

  const businessTypeName = useMemo(() => {
    switch (profile?.businessType) {
      case BusinessType.PRE_STARTUP: return '예비창업자';
      case BusinessType.INDIVIDUAL: return '개인사업자';
      case BusinessType.CORPORATION: return '법인사업자';
      default: return '소상공인';
    }
  }, [profile?.businessType]);

  const isFetchingRef = useRef(false);

  // Load news with caching by location & industry
  const loadNews = useCallback(async (forceRefresh: boolean = false) => {
    const cacheKey = `bizmatch_news_${regionName}_${industryName}`;
    
    if (!forceRefresh) {
      try {
        const cached = localStorage.getItem(cacheKey);
        if (cached) {
          const parsed: { timestamp: number; data: PolicyNewsResponse } = JSON.parse(cached);
          // Cache valid for 30 minutes
          if (Date.now() - parsed.timestamp < 30 * 60 * 1000) {
            setNewsData(parsed.data);
            setIsLoading(false);
            return;
          }
        }
      } catch (err) {
        console.warn('Failed to read news cache', err);
      }
    }

    if (isFetchingRef.current) {
      return;
    }
    isFetchingRef.current = true;

    if (forceRefresh) {
      setIsRefreshing(true);
    } else {
      setIsLoading(true);
    }
    setError(null);

    try {
      const response = await fetchRealtimePolicyNews(profile);
      setNewsData(response);
      
      try {
        localStorage.setItem(cacheKey, JSON.stringify({
          timestamp: Date.now(),
          data: response,
        }));
      } catch (saveErr) {
        console.warn('Failed to save news cache', saveErr);
      }
    } catch (err: any) {
      console.warn('Notice in policy news fetch:', err);
      // Even on unexpected error, keep existing data or graceful state
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
      isFetchingRef.current = false;
    }
  }, [profile?.location, profile?.industry, profile?.businessType, profile?.businessName, regionName, industryName]);

  useEffect(() => {
    loadNews(false);
  }, [loadNews]);

  const handleCopyLink = (item: PolicyNewsItem) => {
    const url = item.sourceUrl || window.location.href;
    navigator.clipboard.writeText(`${item.title}\n${url}`);
    setCopiedId(item.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Filtered news items
  const filteredNews = useMemo(() => {
    if (!newsData || !newsData.newsItems) return [];
    
    return newsData.newsItems.filter(item => {
      // Category filter
      const matchesCategory = selectedCategory === 'ALL' || item.category === selectedCategory;
      
      // Keyword search
      const query = searchKeyword.toLowerCase().trim();
      const matchesKeyword = !query || 
        item.title.toLowerCase().includes(query) ||
        item.summary.toLowerCase().includes(query) ||
        item.agency.toLowerCase().includes(query) ||
        (item.keyBenefits && item.keyBenefits.toLowerCase().includes(query)) ||
        (item.businessImpactTip && item.businessImpactTip.toLowerCase().includes(query));

      return matchesCategory && matchesKeyword;
    });
  }, [newsData, selectedCategory, searchKeyword]);

  const getCategoryBadge = (category: PolicyNewsItem['category']) => {
    switch (category) {
      case 'FINANCE':
        return { label: '금융·대출', bg: 'bg-blue-50 text-blue-700 border-blue-200', dot: 'bg-blue-600' };
      case 'SUBSIDY':
        return { label: '보조금·바우처', bg: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-600' };
      case 'LOCAL':
        return { label: '지자체 특화', bg: 'bg-purple-50 text-purple-700 border-purple-200', dot: 'bg-purple-600' };
      case 'TAX_REGULATION':
        return { label: '세제·제도개선', bg: 'bg-amber-50 text-amber-700 border-amber-200', dot: 'bg-amber-600' };
      default:
        return { label: '일반 정책', bg: 'bg-slate-50 text-slate-700 border-slate-200', dot: 'bg-slate-600' };
    }
  };

  const quickKeywordPills = [
    { label: '전체', value: '' },
    { label: '이차보전/이자지원', value: '이차보전' },
    { label: '대환대출', value: '대환' },
    { label: '스마트상점/바우처', value: '스마트' },
    { label: '전기요금/공과금', value: '전기요금' },
    { label: `${regionName} 특화`, value: regionName },
  ];

  return (
    <div id="realtime-policy-news-section" className={`bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-100 mb-8 overflow-hidden relative ${className}`}>
      {/* Decorative Accent Background Glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-blue-50/70 via-indigo-50/40 to-transparent rounded-full blur-3xl -z-10 pointer-events-none" />

      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
        <div>
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white text-[11px] font-black rounded-full shadow-xs">
              <Globe className="w-3.5 h-3.5 animate-pulse" />
              <span>Google Search 실시간 연동</span>
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 text-slate-700 text-[11px] font-bold rounded-full">
              <MapPin className="w-3 h-3 text-slate-500" />
              {regionName}
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 text-slate-700 text-[11px] font-bold rounded-full">
              <Briefcase className="w-3 h-3 text-slate-500" />
              {industryName}
            </span>
            {businessTypeName && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-100 text-slate-700 text-[11px] font-bold rounded-full">
                {businessTypeName}
              </span>
            )}
          </div>
          <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            실시간 지역·업종 맞춤 정책 뉴스 & 공고
          </h3>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 font-medium">
            <span className="text-blue-600 font-bold">{regionName}</span> 지역 및 <span className="text-blue-600 font-bold">{industryName}</span> 소상공인을 위해 웹에서 실시간 검색된 지원 소식과 행동 가이드를 제공합니다.
          </p>
        </div>

        {/* Refresh & Last Updated Button */}
        <div className="flex items-center gap-3 self-start md:self-center">
          {newsData?.lastFetchedAt && (
            <span className="text-[11px] text-slate-400 font-medium hidden sm:inline-block">
              {newsData.lastFetchedAt} 기준
            </span>
          )}
          <button
            type="button"
            onClick={() => loadNews(true)}
            disabled={isRefreshing || isLoading}
            className="flex items-center gap-2 px-3.5 py-2 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all border border-slate-200/80 shadow-2xs disabled:opacity-50 cursor-pointer"
            title="실시간 검색 갱신"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-blue-600 ${isRefreshing ? 'animate-spin text-blue-600' : ''}`} />
            <span>{isRefreshing ? '검색 갱신 중...' : '실시간 새로고침'}</span>
          </button>
        </div>
      </div>

      {/* AI Search Summary Briefing */}
      {newsData?.searchSummary && !isLoading && (
        <div className="mt-6 p-4.5 bg-gradient-to-r from-blue-50/80 via-indigo-50/50 to-slate-50 border border-blue-100 rounded-2xl flex items-start gap-3.5">
          <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center flex-shrink-0 shadow-xs mt-0.5">
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xs font-black text-blue-900">AI 실시간 정책 동향 브리핑</span>
              <span className="text-[10px] bg-blue-200/70 text-blue-800 font-bold px-2 py-0.5 rounded-full">
                맞춤 요약
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-medium">
              {newsData.searchSummary}
            </p>
          </div>
        </div>
      )}

      {/* Category Tabs & Search Bar */}
      <div className="mt-6 space-y-3">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {[
              { id: 'ALL', label: '전체 소식' },
              { id: 'FINANCE', label: '대출·금융' },
              { id: 'SUBSIDY', label: '보조금·바우처' },
              { id: 'LOCAL', label: '지자체 특화' },
              { id: 'TAX_REGULATION', label: '세제·제도' },
            ].map(tab => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setSelectedCategory(tab.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all whitespace-nowrap cursor-pointer ${
                  selectedCategory === tab.id
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Keyword Search Input */}
          <div className="relative min-w-[200px] sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-slate-400" />
            <input
              type="text"
              placeholder="뉴스·공고 검색..."
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
              className="w-full pl-9 pr-8 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-900 focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-100 outline-none transition-all font-medium"
            />
            {searchKeyword && (
              <button
                type="button"
                onClick={() => setSearchKeyword('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ×
              </button>
            )}
          </div>
        </div>

        {/* Quick Tag Recommendations */}
        <div className="flex items-center gap-1.5 flex-wrap pt-1">
          <span className="text-[11px] font-bold text-slate-400 flex items-center gap-1 mr-1">
            <Tag className="w-3 h-3" /> 추천 키워드:
          </span>
          {quickKeywordPills.map((pill, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => setSearchKeyword(pill.value)}
              className={`text-[11px] px-2.5 py-0.5 rounded-lg border font-medium transition-all cursor-pointer ${
                searchKeyword === pill.value && pill.value !== ''
                  ? 'bg-blue-50 text-blue-700 border-blue-200 font-bold'
                  : 'bg-white text-slate-500 hover:text-slate-800 border-slate-200 hover:border-slate-300'
              }`}
            >
              #{pill.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="mt-6">
        {isLoading ? (
          /* Skeleton Loading Cards */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[1, 2, 3, 4].map(n => (
              <div key={n} className="p-5 rounded-2xl border border-slate-100 bg-slate-50/60 animate-pulse space-y-3">
                <div className="flex items-center justify-between">
                  <div className="h-4 w-20 bg-slate-200 rounded-full" />
                  <div className="h-3 w-16 bg-slate-200 rounded" />
                </div>
                <div className="h-5 w-4/5 bg-slate-200 rounded" />
                <div className="space-y-2 pt-2">
                  <div className="h-3.5 w-full bg-slate-200 rounded" />
                  <div className="h-3.5 w-3/4 bg-slate-200 rounded" />
                </div>
                <div className="h-10 bg-slate-200/80 rounded-xl mt-4" />
              </div>
            ))}
          </div>
        ) : error ? (
          /* Error State */
          <div className="p-8 text-center bg-red-50/50 rounded-2xl border border-red-100">
            <AlertCircle className="w-10 h-10 text-red-500 mx-auto mb-3" />
            <h4 className="text-sm font-bold text-red-900 mb-1">실시간 정책 뉴스 로딩 중 문제 발생</h4>
            <p className="text-xs text-red-600 max-w-md mx-auto mb-4">{error}</p>
            <button
              type="button"
              onClick={() => loadNews(true)}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl transition-all shadow-sm cursor-pointer"
            >
              다시 시도하기
            </button>
          </div>
        ) : filteredNews.length === 0 ? (
          /* Empty Search Result State */
          <div className="p-10 text-center bg-slate-50 rounded-2xl border border-slate-100">
            <Search className="w-10 h-10 text-slate-300 mx-auto mb-2" />
            <h4 className="text-sm font-bold text-slate-700 mb-1">조건에 맞는 정책 뉴스가 없습니다</h4>
            <p className="text-xs text-slate-400 mb-3">검색어를 초기화하거나 다른 카테고리를 선택해 보세요.</p>
            <button
              type="button"
              onClick={() => { setSelectedCategory('ALL'); setSearchKeyword(''); }}
              className="px-3.5 py-1.5 bg-slate-900 text-white text-xs font-bold rounded-xl cursor-pointer"
            >
              필터 전체 초기화
            </button>
          </div>
        ) : (
          /* News Items Grid */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredNews.map((item) => {
              const categoryBadge = getCategoryBadge(item.category);
              const isCopied = copiedId === item.id;

              return (
                <div
                  key={item.id}
                  className="bg-white hover:bg-slate-50/50 p-5 rounded-2xl border border-slate-200 hover:border-blue-300 transition-all shadow-2xs hover:shadow-md flex flex-col justify-between group"
                >
                  <div>
                    {/* Top Badges & Agency */}
                    <div className="flex items-center justify-between gap-2 mb-3">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black border ${categoryBadge.bg}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${categoryBadge.dot}`} />
                          {categoryBadge.label}
                        </span>
                        {item.locationScope && (
                          <span className="text-[10px] font-bold bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full">
                            {item.locationScope}
                          </span>
                        )}
                        {item.isOfficialAnnouncement && (
                          <span className="text-[10px] font-bold bg-indigo-50 text-indigo-700 border border-indigo-200 px-2 py-0.5 rounded-full flex items-center gap-0.5">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            공식공고
                          </span>
                        )}
                      </div>

                      <span className="text-[11px] text-slate-400 font-medium flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {item.publishedDate}
                      </span>
                    </div>

                    {/* Agency info */}
                    <div className="text-[11px] font-bold text-slate-500 mb-1.5 flex items-center gap-1">
                      <Landmark className="w-3 h-3 text-slate-400" />
                      <span>{item.agency}</span>
                    </div>

                    {/* Title */}
                    <h4 className="text-sm font-black text-slate-900 group-hover:text-blue-600 transition-colors leading-snug mb-2.5">
                      {item.title}
                    </h4>

                    {/* Summary */}
                    <p className="text-xs text-slate-600 leading-relaxed line-clamp-3 mb-3 font-medium">
                      {item.summary}
                    </p>

                    {/* Key Benefits Tag */}
                    {item.keyBenefits && (
                      <div className="mb-3 p-2.5 bg-emerald-50/70 border border-emerald-200/80 rounded-xl flex items-start gap-2">
                        <span className="text-[10px] font-black text-emerald-800 bg-emerald-200/80 px-1.5 py-0.5 rounded flex-shrink-0 mt-0.5">
                          주요 혜택
                        </span>
                        <span className="text-xs font-bold text-emerald-900 leading-tight">
                          {item.keyBenefits}
                        </span>
                      </div>
                    )}

                    {/* Business Impact Tip (Personalized AI Tip) */}
                    {item.businessImpactTip && (
                      <div className="mb-4 p-3 bg-blue-50/60 border border-blue-100 rounded-xl flex items-start gap-2">
                        <div className="w-5 h-5 rounded-lg bg-blue-600 text-white flex items-center justify-center flex-shrink-0 text-[10px] font-black mt-0.5 shadow-2xs">
                          TIP
                        </div>
                        <div>
                          <span className="text-[10px] font-black text-blue-900 block mb-0.5">
                            내 사업장 실무 활용 포인트
                          </span>
                          <p className="text-[11px] text-slate-700 leading-relaxed font-medium">
                            {item.businessImpactTip}
                          </p>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Card Bottom Actions */}
                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2 mt-auto">
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => handleCopyLink(item)}
                        className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors text-xs font-medium flex items-center gap-1 cursor-pointer"
                        title="소식 정보 복사"
                      >
                        {isCopied ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                            <span className="text-[10px] font-bold text-emerald-600">복사완료</span>
                          </>
                        ) : (
                          <>
                            <Share2 className="w-3.5 h-3.5" />
                            <span className="text-[10px]">공유</span>
                          </>
                        )}
                      </button>
                    </div>

                    {item.sourceUrl && (
                      <a
                        href={item.sourceUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        referrerPolicy="no-referrer"
                        className="inline-flex items-center gap-1 px-3 py-1.5 bg-slate-900 hover:bg-blue-600 text-white rounded-xl text-[11px] font-bold transition-all shadow-2xs hover:shadow-xs group-hover:bg-blue-600"
                      >
                        <span>원문 공고 확인</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Google Search Grounding Sources Footnote */}
      {newsData?.groundingSources && newsData.groundingSources.length > 0 && !isLoading && (
        <div className="mt-8 pt-5 border-t border-slate-100 bg-slate-50/50 p-4 rounded-2xl">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5 text-blue-600" />
              구글 실시간 검색 검증 출처
            </span>
            <span className="text-[10px] text-slate-400">
              총 {newsData.groundingSources.length}개 웹 소스 참조
            </span>
          </div>
          <div className="flex flex-wrap gap-2">
            {newsData.groundingSources.slice(0, 5).map((source, sIdx) => (
              <a
                key={sIdx}
                href={source.url}
                target="_blank"
                rel="noopener noreferrer"
                referrerPolicy="no-referrer"
                className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-600 hover:text-blue-600 bg-white border border-slate-200/80 hover:border-blue-300 px-2.5 py-1 rounded-lg transition-all shadow-2xs max-w-xs truncate"
                title={source.title}
              >
                <span className="truncate">{source.title}</span>
                <ExternalLink className="w-2.5 h-2.5 flex-shrink-0" />
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
