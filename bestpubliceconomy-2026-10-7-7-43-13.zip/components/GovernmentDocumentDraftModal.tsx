import React, { useState, useEffect, useMemo, useRef } from 'react';
import { UserProfile, PolicyFund } from '../types';
import {
  GovernmentDocType,
  DraftFormData,
  GOVERNMENT_DOC_TEMPLATES,
  StandardDocTemplateMetadata,
  FundUsageItem
} from '../src/types/documentDraft';
import {
  generateStandardDocumentDraftAI,
  enhanceDocumentSectionAI
} from '../services/geminiService';
import {
  X,
  FileText,
  Printer,
  Copy,
  Check,
  Sparkles,
  RefreshCw,
  Download,
  AlertCircle,
  CheckCircle2,
  Building2,
  Calendar,
  Layers,
  HelpCircle,
  ShieldCheck,
  Award,
  ChevronRight,
  ChevronDown,
  ChevronUp,
  Plus,
  Trash2,
  Edit3,
  Eye,
  FileCheck2,
  Lock,
  Stamp,
  UserCheck,
  AlertTriangle,
  ArrowRight,
  ShieldAlert,
  Gauge,
  FileWarning,
  Zap,
  Info,
  CheckSquare,
  TrendingUp,
  Coins,
  Briefcase,
  Sliders,
  Wand2,
  FileCheck,
  Database,
  Search,
  Filter,
  CheckCheck,
  History,
  ArrowUpRight,
  FileSpreadsheet,
  Scale,
  ListFilter,
  Tag,
  Activity,
  ExternalLink,
  RefreshCcw
} from 'lucide-react';

export type FieldSourceType = 
  | 'PROFILE'        // 사용자 프로필 정보 (MyProfile)
  | 'FUND_POLICY'    // 정책자금 공고/기관 요건
  | 'SMART_CALC'     // 스마트 알고리즘 / 재무 모델링 역산
  | 'AI_GENERATED'   // Gemini AI 지능형 문장 생성/첨삭
  | 'SAVED_DRAFT'    // 과거 작성/임시저장 기록
  | 'MANUAL_INPUT';  // 사용자 직접 수정/입력

export interface FieldProvenanceItem {
  id: string;
  fieldKey: string;
  fieldLabel: string;
  tabKey: 'INFO' | 'FINANCE' | 'NARRATIVE' | 'ITEMS' | 'PLEDGE';
  tabLabel: string;
  sourceType: FieldSourceType;
  sourceTypeName: string;
  sourceOrigin: string;
  sourceTracePath: string;
  rawSourceValue: string | number | null;
  currentDisplayValue: string;
  isCustomized: boolean;
  confidenceScore: number;
  reliabilityLevel: 'HIGH' | 'MEDIUM' | 'ESTIMATED';
  formulaOrLogic?: string;
  verified: boolean;
}

interface MissingAuditItem {
  id: string;
  tab: 'INFO' | 'FINANCE' | 'NARRATIVE' | 'ITEMS' | 'PLEDGE';
  tabName: string;
  field: string;
  fieldLabel: string;
  severity: 'CRITICAL' | 'WARNING' | 'RECOMMENDED';
  message: string;
  suggestion: string;
}

interface GovernmentDocumentDraftModalProps {
  isOpen: boolean;
  onClose: () => void;
  fund?: PolicyFund | null;
  profile?: UserProfile | null;
  initialDocType?: GovernmentDocType;
}

// Korean Currency Formatter helper
function formatWonKorean(amount: number): string {
  if (!amount || amount === 0) return '0원';
  const eok = Math.floor(amount / 100000000);
  const man = Math.floor((amount % 100000000) / 10000);
  if (eok > 0 && man > 0) return `${eok}억 ${man.toLocaleString()}만원`;
  if (eok > 0) return `${eok}억원`;
  if (man > 0) return `${man.toLocaleString()}만원`;
  return `${amount.toLocaleString()}원`;
}

export const GovernmentDocumentDraftModal: React.FC<GovernmentDocumentDraftModalProps> = ({
  isOpen,
  onClose,
  fund,
  profile,
  initialDocType = 'APPLICATION_FORM',
}) => {
  const [selectedDocType, setSelectedDocType] = useState<GovernmentDocType>(initialDocType);
  const [activeEditorTab, setActiveEditorTab] = useState<'INFO' | 'FINANCE' | 'NARRATIVE' | 'ITEMS' | 'PLEDGE'>('INFO');
  const [viewMode, setViewMode] = useState<'SPLIT' | 'EDITOR_ONLY' | 'PREVIEW_ONLY' | 'DATA_SOURCES'>('SPLIT');
  
  const [isGeneratingAi, setIsGeneratingAi] = useState<boolean>(false);
  const [polishingSection, setPolishingSection] = useState<string | null>(null);
  const [copiedText, setCopiedText] = useState<boolean>(false);
  const [saveToast, setSaveToast] = useState<string | null>(null);

  // Smart Autofill Modal & Target Tab state
  const [showAutofillModal, setShowAutofillModal] = useState<boolean>(false);
  const [autofillTabTarget, setAutofillTabTarget] = useState<'ALL' | 'INFO' | 'FINANCE' | 'NARRATIVE' | 'ITEMS'>('ALL');

  // Missing alerts expansion & filter states
  const [isMissingAlertExpanded, setIsMissingAlertExpanded] = useState<boolean>(true);
  const [selectedSeverityFilter, setSelectedSeverityFilter] = useState<'ALL' | 'CRITICAL' | 'WARNING'>('ALL');

  // Data Source Review & Provenance States
  const [verifiedFieldKeys, setVerifiedFieldKeys] = useState<string[]>([
    'businessName',
    'businessRegistrationNumber',
    'ceoName',
    'businessType',
    'annualRevenue',
    'employeeCount',
    'requestedAmount',
    'pledgeConfirmed'
  ]);
  const [dataSourceFilter, setDataSourceFilter] = useState<'ALL' | 'PROFILE' | 'SMART_CALC' | 'AI_GENERATED' | 'FUND_POLICY' | 'MANUAL_INPUT'>('ALL');
  const [dataSourceTabFilter, setDataSourceTabFilter] = useState<'ALL' | 'INFO' | 'FINANCE' | 'NARRATIVE' | 'ITEMS' | 'PLEDGE'>('ALL');
  const [dataSourceVerificationFilter, setDataSourceVerificationFilter] = useState<'ALL' | 'VERIFIED' | 'NEEDS_REVIEW'>('ALL');
  const [dataSourceSearchQuery, setDataSourceSearchQuery] = useState<string>('');
  const [selectedProvenanceDetail, setSelectedProvenanceDetail] = useState<FieldProvenanceItem | null>(null);
  const [highlightedFieldKey, setHighlightedFieldKey] = useState<string | null>(null);

  // Form State
  const [formData, setFormData] = useState<DraftFormData>(() => createInitialFormData(selectedDocType, profile, fund));

  // Initialize or reset when docType or profile/fund changes
  useEffect(() => {
    if (initialDocType) {
      setSelectedDocType(initialDocType);
    }
  }, [initialDocType]);

  // Load from LocalStorage if exists for this fund & template, else initialize
  useEffect(() => {
    if (!isOpen) return;

    const storageKey = `bizmatch_gov_draft_${fund?.id || 'general'}_${selectedDocType}`;
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        setFormData(JSON.parse(saved));
        return;
      }
    } catch {
      // ignore
    }

    setFormData(createInitialFormData(selectedDocType, profile, fund));
  }, [isOpen, selectedDocType, fund, profile]);

  function createInitialFormData(
    docType: GovernmentDocType,
    prof?: UserProfile | null,
    f?: PolicyFund | null
  ): DraftFormData {
    const today = new Date();
    const dateStr = `${today.getFullYear()}년 ${String(today.getMonth() + 1).padStart(2, '0')}월 ${String(today.getDate()).padStart(2, '0')}일`;
    const bName = prof?.businessName || '대한상사';
    const cName = prof?.name || '홍길동';
    const fundingNeedWon = prof?.fundingNeed || 50000000;
    const targetAgency = f?.agency || '소상공인시장진흥공단';
    const fundTitle = f?.title || '소상공인 정책자금 융자지원';

    return {
      docType,
      documentNumber: `POL-${today.getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`,
      applicationDate: dateStr,
      targetAgency,
      fundName: fundTitle,
      submissionYear: `${today.getFullYear()}년도`,

      businessName: bName,
      businessRegistrationNumber: prof?.businessRegistrationNumber || '123-45-67890',
      corporateRegistrationNumber: prof?.businessType === 'CORPORATION' ? '110111-1234567' : '해당없음 (개인사업자)',
      ceoName: cName,
      birthDate: '1985.05.15',
      businessType: prof?.businessType === 'CORPORATION' ? '법인사업자' : '개인사업자',
      industryCategory: prof?.industry ? getIndustryText(prof.industry) : '도소매 및 서비스업',
      mainProduct: prof?.industry === 'RESTAURANT' ? '한식 및 즉석식품 조리·판매' : '주요 서비스 및 유통 상품',
      businessAddress: prof?.businessAddress || '서울특별시 영등포구 여의대로 128',
      factoryAddress: '본사 사업장과 동일',
      foundedDate: prof?.foundedYear ? `${prof.foundedYear}.03.01` : '2022.03.01',
      contactPhone: '010-1234-5678',
      email: 'contact@business.co.kr',
      homepage: 'https://bizmatch.co.kr',

      annualRevenue: prof?.annualRevenue || 150000000,
      prevYearRevenue: Math.round((prof?.annualRevenue || 150000000) * 0.85),
      twoYearsAgoRevenue: Math.round((prof?.annualRevenue || 150000000) * 0.7),
      operatingProfit: Math.round((prof?.annualRevenue || 150000000) * ((prof?.expectedProfitMargin || 15) / 100)),
      employeeCount: prof?.employees || 2,
      fullTimeEmployees: Math.max(1, (prof?.employees || 2) - 1),
      primaryBank: 'IBK기업은행',
      existingDebtTotal: ((prof?.debt1Tier || 0) + (prof?.debt2Tier || 0) + (prof?.debtCardLoan || 0) + (prof?.debtOther || 0)) || 20000000,

      requestedAmount: fundingNeedWon,
      fundUsageCategory: '운전+시설자금',
      preferredTerm: f?.repaymentPeriod || '5년 (거치기간 2년 포함)',
      gracePeriodMonths: 24,
      collateralType: '신용보증서',

      businessOverview: `당사는 ${prof?.foundedYear || '2022'}년 창업 이래 지속적인 서비스 혁신과 철저한 고객 맞춤형 대응을 통해 지역 및 온라인 시장에서 신뢰를 쌓아온 우수 소상공인 기업입니다.`,
      marketCompetitiveness: `1. 동종업계 대비 우수한 품질 경쟁력 및 원가 통제력\n2. 온·오프라인 단골 고객망(재방문율 60% 이상) 확보\n3. 디지털 스마트 기술 도입을 통한 운영 효율 극대화.`,
      fundRequirementDetails: `금번 정책자금 신청액(금 ${Math.round(fundingNeedWon / 1000000)}백만원)은 성수기 원부자재 대량 구매를 통한 단가 절감 및 매장 환경 개선, 비대면 판매망 확충에 전액 투입될 예정입니다.`,
      fundUsageSchedule: `대출 승인 즉시 1차 원부자재 발주(50%), 2차 디지털 마케팅 및 사업장 개선(30%), 3차 운영 유동성(20%)으로 순차 집행하며 전자세금계산서 증빙을 철저히 보관하겠습니다.`,
      salesGrowthPlan: `자금 투입 후 원가 8% 절감 및 생산·영업 캐파 증대에 힘입어 차년도 매출액은 전년 대비 25% 이상 성장할 것으로 기대됩니다.`,
      debtRepaymentPlan: `매월 창출되는 안정적인 영업현금흐름(월 평균 600만원 이상)을 기반으로 원리금 상환 전용 통장을 개설하여 연체 없이 성실히 상환하겠습니다.`,
      riskManagementPlan: `다변화된 복수 매입처 확보로 공급망 리스크를 헷지하고, 경기 둔화 시 마케팅 효율화 및 변동비 절감 비상계획을 가동하겠습니다.`,
      ceoExperienceSummary: `대표자(${cName})는 관련 업계에서 8년 이상의 실무 및 총괄 운영 경력을 축적하여 위기 관리 및 영업 역량이 탁월함.`,

      fundUsageItems: [
        {
          id: 'item-1',
          itemName: '주요 원부자재 및 상품 선구매',
          category: '원부자재',
          supplier: '주요 협력 유통사',
          amount: Math.round(fundingNeedWon * 0.45),
          executionMonth: '1개월차',
          notes: '대량구매 단가할인 적용'
        },
        {
          id: 'item-2',
          itemName: '매장/사업장 운영 설비 및 키오스크/포스 교체',
          category: '설비구입',
          supplier: '스마트기기 공급업체',
          amount: Math.round(fundingNeedWon * 0.35),
          executionMonth: '2개월차',
          notes: '스마트상점 전환'
        },
        {
          id: 'item-3',
          itemName: '지역 타겟 온라인 마케팅 및 판로 개척',
          category: '마케팅',
          supplier: '온라인 마케팅 대행사',
          amount: Math.round(fundingNeedWon * 0.2),
          executionMonth: '3개월차',
          notes: '신규 고객 유치'
        }
      ],

      pledgeNoBroker: true,
      pledgeNoTaxDelinquency: true,
      pledgeFactTrue: true,
      pledgeRefundOnFalse: true,
      pledgeCreditInfoConsent: true,

      representativeSignatureName: cName,
      hasStamp: true,
      stampText: '인'
    };
  }

  function getIndustryText(ind: string): string {
    const map: Record<string, string> = {
      MANUFACTURING: '제조업 (부품·가공)',
      IT_SOFTWARE: 'IT / 소프트웨어 개발 및 서비스',
      RETAIL: '도소매업 및 전자상거래',
      SERVICE: '전문 서비스업 및 교육',
      RESTAURANT: '음식점업 및 외식 서비스',
      OTHER: '기타 일반 소상공인',
    };
    return map[ind] || ind;
  }

  const currentTemplate = useMemo(() => {
    return GOVERNMENT_DOC_TEMPLATES.find((t) => t.id === selectedDocType) || GOVERNMENT_DOC_TEMPLATES[0];
  }, [selectedDocType]);

  // Profile-based Smart Autofill Engine (스마트 자동완성 엔진)
  const handleApplySmartAutofill = (targetTab: 'ALL' | 'INFO' | 'FINANCE' | 'NARRATIVE' | 'ITEMS' = 'ALL') => {
    const prof = profile;
    const f = fund;
    const today = new Date();
    const currentYear = today.getFullYear();
    
    // 1. Industry-based mapping (업종 맞춤형 데이터 산출)
    const ind = prof?.industry || 'OTHER';
    let indCategory = '도소매업 및 전자상거래';
    let mainProd = '생활 소비재 및 주요 유통 상품';
    let businessOverviewText = '';
    let competitivenessText = '';

    if (ind === 'IT_SOFTWARE') {
      indCategory = 'IT / 소프트웨어 개발 및 정보서비스업';
      mainProd = '클라우드 기반 B2B SaaS 솔루션 및 모바일 응용 소프트웨어';
      competitivenessText = `1. 독자적인 핵심 소프트웨어 아키텍처 및 특허 기술 보유\n2. 클라우드 기반 신속한 기능 배포 및 높은 고객 유지율(90% 이상)\n3. 전문 개발 인력의 기술 내재화로 경쟁사 대비 빠른 시장 대응력`;
    } else if (ind === 'MANUFACTURING') {
      indCategory = '제조업 (정밀 가공 부품 및 산업 설비 제조)';
      mainProd = '정밀 금형 가공 부품 및 고효율 산업용 자동화 장치';
      competitivenessText = `1. 엄격한 품질 관리(불량률 0.5% 미만) 및 정밀 가공 기술력\n2. 우수 원자재 직거래망을 통한 12% 원가 절감 체계 구축\n3. 국내 주요 1차 협력사와의 장기 공급 계약 기반 안정적 판로`;
    } else if (ind === 'RESTAURANT') {
      indCategory = '음식점업 (한식 및 즉석식품 조리·외식 서비스)';
      mainProd = '시그니처 대표 메뉴 및 포장·배달 밀키트 간편식 상품';
      competitivenessText = `1. 자체 개발 특제 소스 및 표준화 레시피를 통한 균일한 맛과 품질\n2. 로컬 상권 단골 고객 확보(재방문율 58%) 및 SNS 바이럴 마케팅\n3. 테이블오더·키오스크 등 스마트상점 시스템 도입으로 인건비 15% 절감`;
    } else if (ind === 'RETAIL') {
      indCategory = '도소매업 및 전자상거래 유통';
      mainProd = '생활 밀착형 라이프스타일 상품 및 온·오프라인 옴니채널 유통';
      competitivenessText = `1. 직소싱 루트를 통한 유통 마진 최소화 및 가격 경쟁력 우위\n2. 주요 오픈마켓 상위 노출 랭킹 및 충성 고객 리뷰 평점 4.8 이상\n3. 실시간 재고 관리 시스템을 통한 재고 회전율 1.5배 개선`;
    } else if (ind === 'SERVICE') {
      indCategory = '전문 서비스업 및 맞춤형 지식 서비스';
      mainProd = '기업 및 개인 고객 대상 맞춤형 컨설팅 및 전문 교육 솔루션';
      competitivenessText = `1. 10년 이상 경력의 전문 인력진에 의한 고품질 솔루션 제공\n2. 고객 맞춤형 커리큘럼 및 사후 관리 시스템으로 높은 추천율\n3. 디지털 비대면 화상 서비스 구축으로 전국 단위 고객 유치`;
    } else {
      indCategory = prof?.industry ? getIndustryText(prof.industry) : '기타 일반 영리사업';
      mainProd = '주요 서비스 및 우수 유통 제품';
      competitivenessText = `1. 동종 업계 대비 철저한 고객 맞춤 대응 및 품질 신뢰도\n2. 합리적인 가격 정책과 안정적인 거래처 네트워크 확보\n3. 지속적인 서비스 개선과 온·오프라인 마케팅 다변화`;
    }

    // 2. Founded Year & Date mapping (창업일자 및 업력 산출)
    const fYear = String(prof?.foundedYear || '2022');
    let fDate = `${fYear}.03.15`;
    if (fYear.includes('.') || fYear.includes('-')) {
      fDate = fYear.replace(/-/g, '.');
    }
    const foundedYearNum = parseInt(fYear.replace(/[^0-9]/g, '')) || 2022;
    const businessYears = Math.max(1, currentYear - foundedYearNum + 1);

    businessOverviewText = `당사는 ${fYear}년 설립된 ${indCategory} 전문 기업으로, 설립 이래 ${businessYears}년 동안 축적된 전문 기술과 고객 중심 경영을 바탕으로 안정적인 영업 기반을 구축해 온 성장 유망 기업입니다.`;
    const ceoSummary = `대표자(${prof?.name || formData.ceoName || '홍길동'})는 ${fYear}년 창업 이전부터 동종 산업 분야에서 풍부한 현장 실무 및 사업화 노하우를 축적하였으며, 창업 후 ${businessYears}년간 탁월한 리더십과 현장 경영으로 사업을 안정적으로 성장시켜 왔습니다.`;

    // 3. Revenue & Financials mapping (매출 및 재무 산출)
    const revenue = prof?.annualRevenue || 150000000;
    const margin = prof?.expectedProfitMargin || 15;
    const prevRev = Math.round(revenue * 0.85);
    const twoAgoRev = Math.round(revenue * 0.70);
    const opProfit = Math.round(revenue * (margin / 100));
    const targetNextYearRev = Math.round((revenue * 1.25) / 10000000) * 10000000;
    const monthlyOpCash = Math.round((opProfit / 12) / 10000) * 10000;

    const salesGrowth = `금번 정책자금 투입을 통한 원부자재 대량 소싱(단가 8% 절감) 및 생산·판매 인프라 확충에 힘입어, 차년도 매출액은 전년(${formatWonKorean(revenue)}) 대비 25% 이상 성장한 약 ${formatWonKorean(targetNextYearRev)} 달성을 목표로 추진하고 있습니다.`;
    const debtRepay = `당사는 연간 약 ${formatWonKorean(opProfit)}(월 환산 약 ${monthlyOpCash.toLocaleString()}원)의 건전한 영업현금흐름을 지속 창출하고 있습니다. 정책자금 대출 승인 즉시 '원리금 상환 전용 통장'을 분리 개설하여 매월 안정적으로 원리금을 분할 상환하겠습니다.`;

    // 4. Funding & Items mapping (신청자금 및 소요명세표 산출)
    const fundingNeed = prof?.fundingNeed || formData.requestedAmount || 50000000;
    const item1Amount = Math.round((fundingNeed * 0.45) / 10000) * 10000;
    const item2Amount = Math.round((fundingNeed * 0.35) / 10000) * 10000;
    const item3Amount = fundingNeed - item1Amount - item2Amount; // Exact remainder to guarantee 100% sum!

    const smartUsageItems: FundUsageItem[] = [
      {
        id: `smart-item-1-${Date.now()}`,
        itemName: ind === 'MANUFACTURING' ? '핵심 원자재(금속·가공재) 선구매' : ind === 'RESTAURANT' ? '식음료 식자재 및 포장재 선구매' : ind === 'IT_SOFTWARE' ? '클라우드 인프라 서버 및 개발 라이선스' : '주요 원부자재 및 핵심 유통 상품 매입',
        category: ind === 'IT_SOFTWARE' ? '운전자금' : '원부자재',
        supplier: '주요 협력 유통·공급사',
        amount: item1Amount,
        executionMonth: '1개월차',
        notes: '대량 소싱을 통한 단가 절감'
      },
      {
        id: `smart-item-2-${Date.now()}`,
        itemName: ind === 'IT_SOFTWARE' ? '보안 솔루션 및 테스트베드 장비 도입' : ind === 'MANUFACTURING' ? '생산 가공 정밀 기계 부품 교체 및 정비' : ind === 'RESTAURANT' ? '주방 조리기기 현대화 및 스마트 주문 단말기' : '매장·사업장 시설 개선 및 스마트 장비',
        category: '설비구입',
        supplier: '설비 전문 제작사',
        amount: item2Amount,
        executionMonth: '2개월차',
        notes: '생산 효율 및 품질 고도화'
      },
      {
        id: `smart-item-3-${Date.now()}`,
        itemName: '신규 고객 유치 온라인 마케팅 및 판로 확대',
        category: '마케팅',
        supplier: '온라인 마케팅 대행사',
        amount: item3Amount,
        executionMonth: '3개월차',
        notes: '매출 확대 및 신규 거래처 개척'
      }
    ];

    const debtsTotal = ((prof?.debt1Tier || 0) + (prof?.debt2Tier || 0) + (prof?.debtCardLoan || 0) + (prof?.debtOther || 0)) || 20000000;

    setFormData((prev) => {
      const next = { ...prev };

      if (targetTab === 'ALL' || targetTab === 'INFO') {
        if (prof?.businessName) next.businessName = prof.businessName;
        if (prof?.businessRegistrationNumber) next.businessRegistrationNumber = prof.businessRegistrationNumber;
        next.corporateRegistrationNumber = prof?.businessType === 'CORPORATION' ? (prev.corporateRegistrationNumber || '110111-1234567') : '해당없음 (개인사업자)';
        if (prof?.name) next.ceoName = prof.name;
        next.businessType = prof?.businessType === 'CORPORATION' ? '법인사업자' : '개인사업자';
        next.industryCategory = indCategory;
        next.mainProduct = mainProd;
        if (prof?.businessAddress) next.businessAddress = prof.businessAddress;
        next.foundedDate = fDate;
        next.representativeSignatureName = prof?.name || prev.ceoName;
      }

      if (targetTab === 'ALL' || targetTab === 'FINANCE') {
        next.annualRevenue = revenue;
        next.prevYearRevenue = prevRev;
        next.twoYearsAgoRevenue = twoAgoRev;
        next.operatingProfit = opProfit;
        next.employeeCount = prof?.employees || prev.employeeCount;
        next.fullTimeEmployees = Math.max(1, (prof?.employees || 2) - 1);
        next.existingDebtTotal = debtsTotal;
        next.requestedAmount = fundingNeed;
      }

      if (targetTab === 'ALL' || targetTab === 'NARRATIVE') {
        next.businessOverview = businessOverviewText;
        next.marketCompetitiveness = competitivenessText;
        next.fundRequirementDetails = `금번 정책자금 신청액(금 ${formatWonKorean(fundingNeed)})은 성수기 원부자재 대량 구매 및 핵심 시설 보강, 온·오프라인 판로 확대를 위한 운전자금으로 전액 투입될 예정입니다.`;
        next.fundUsageSchedule = `대출 승인 즉시 1차 원부자재/상품 발주(45%), 2차 생산 설비 보강 및 디지털화(35%), 3차 마케팅 및 판로 개척(20%)으로 순차 집행하며 전자세금계산서 증빙을 철저히 보관하겠습니다.`;
        next.salesGrowthPlan = salesGrowth;
        next.debtRepaymentPlan = debtRepay;
        next.ceoExperienceSummary = ceoSummary;
      }

      if (targetTab === 'ALL' || targetTab === 'ITEMS') {
        next.requestedAmount = fundingNeed;
        next.fundUsageItems = smartUsageItems;
      }

      return next;
    });

    const targetTabNames: Record<string, string> = {
      ALL: '서식 전체 (22개 필드)',
      INFO: '1. 기업 기본정보',
      FINANCE: '2. 재무 및 자금신청',
      NARRATIVE: '3. 사업계획 6개 문항',
      ITEMS: '4. 소요명세표',
    };

    const toastMsg = targetTab === 'ALL'
      ? `✨ 프로필 정보(업종: ${getIndustryText(ind)}, 연매출: ${formatWonKorean(revenue)}, 창업: ${fYear}년)를 기반으로 서식 전체가 스마트 자동완성되었습니다!`
      : `✨ 프로필 정보 기반으로 [${targetTabNames[targetTab] || targetTab}] 영역이 스마트 자동완성되었습니다!`;

    setSaveToast(toastMsg);
    setTimeout(() => setSaveToast(null), 3500);
    setShowAutofillModal(false);
  };

  // Handle Save to LocalStorage
  const handleSaveDraft = () => {
    const storageKey = `bizmatch_gov_draft_${fund?.id || 'general'}_${selectedDocType}`;
    try {
      localStorage.setItem(storageKey, JSON.stringify(formData));
      setSaveToast('초안이 브라우저에 안전하게 저장되었습니다.');
      setTimeout(() => setSaveToast(null), 2500);
    } catch {
      setSaveToast('저장 실패 (용량 부족)');
      setTimeout(() => setSaveToast(null), 2000);
    }
  };

  // AI Full Generation
  const handleAiGenerateAll = async () => {
    setIsGeneratingAi(true);
    try {
      const generated = await generateStandardDocumentDraftAI(
        currentTemplate.title,
        profile,
        fund,
        `문서 서식: ${currentTemplate.formNumber} (${currentTemplate.title})`
      );

      setFormData((prev) => ({
        ...prev,
        businessOverview: generated.businessOverview || prev.businessOverview,
        marketCompetitiveness: generated.marketCompetitiveness || prev.marketCompetitiveness,
        fundRequirementDetails: generated.fundRequirementDetails || prev.fundRequirementDetails,
        fundUsageSchedule: generated.fundUsageSchedule || prev.fundUsageSchedule,
        salesGrowthPlan: generated.salesGrowthPlan || prev.salesGrowthPlan,
        debtRepaymentPlan: generated.debtRepaymentPlan || prev.debtRepaymentPlan,
        riskManagementPlan: generated.riskManagementPlan || prev.riskManagementPlan,
        ceoExperienceSummary: generated.ceoExperienceSummary || prev.ceoExperienceSummary,
        fundUsageItems: generated.suggestedItems && generated.suggestedItems.length > 0
          ? generated.suggestedItems.map((item, idx) => ({
              id: `item-${Date.now()}-${idx}`,
              itemName: item.itemName,
              category: item.category || '운전자금',
              supplier: item.supplier || '협력업체',
              amount: item.amount || Math.round(prev.requestedAmount / 3),
              executionMonth: item.executionMonth || `${idx + 1}개월차`,
              notes: 'AI 추천 항목'
            }))
          : prev.fundUsageItems
      }));

      setSaveToast('AI가 정부 표준 양식에 맞춘 맞춤형 초안을 생성했습니다!');
      setTimeout(() => setSaveToast(null), 3000);
    } catch (err) {
      console.error('AI Draft generation failed:', err);
    } finally {
      setIsGeneratingAi(false);
    }
  };

  // AI Section Polish
  const handlePolishSection = async (sectionKey: keyof DraftFormData, title: string) => {
    const currentVal = String(formData[sectionKey] || '');
    if (!currentVal) return;

    setPolishingSection(String(sectionKey));
    try {
      const polished = await enhanceDocumentSectionAI(title, currentVal, profile, fund);
      setFormData((prev) => ({
        ...prev,
        [sectionKey]: polished
      }));
    } catch (err) {
      console.error('Section polish failed:', err);
    } finally {
      setPolishingSection(null);
    }
  };

  // Print PDF directly
  const handlePrintPdf = () => {
    window.print();
  };

  // Copy Draft Text for HWP / Word
  const handleCopyFormattedText = () => {
    let text = `【 ${currentTemplate.formNumber} 】 ${currentTemplate.title}\n`;
    text += `문서번호: ${formData.documentNumber} | 접수기관: ${formData.targetAgency} | 신청일자: ${formData.applicationDate}\n\n`;
    text += `1. 기업체 기본 개요\n`;
    text += `- 상호: ${formData.businessName} (사업자등록번호: ${formData.businessRegistrationNumber})\n`;
    text += `- 대표자: ${formData.ceoName} (생년월일: ${formData.birthDate})\n`;
    text += `- 기업유형: ${formData.businessType} | 주요업종: ${formData.industryCategory}\n`;
    text += `- 사업장 주소: ${formData.businessAddress}\n`;
    text += `- 개업일자: ${formData.foundedDate} | 연락처: ${formData.contactPhone}\n\n`;

    text += `2. 재무 및 고용 실태\n`;
    text += `- 당해연도(추정) 매출액: ${formData.annualRevenue.toLocaleString()}원\n`;
    text += `- 전년도 매출액: ${formData.prevYearRevenue.toLocaleString()}원 | 전전년도: ${formData.twoYearsAgoRevenue.toLocaleString()}원\n`;
    text += `- 상시근로자수: ${formData.employeeCount}명 (정규직: ${formData.fullTimeEmployees}명)\n`;
    text += `- 기존 총부채: ${formData.existingDebtTotal.toLocaleString()}원 | 주거래은행: ${formData.primaryBank}\n\n`;

    text += `3. 정책자금 신청 내역\n`;
    text += `- 신청 금액: 금 ${formData.requestedAmount.toLocaleString()}원 (용도: ${formData.fundUsageCategory})\n`;
    text += `- 희망 상환기간: ${formData.preferredTerm} (거치기간: ${formData.gracePeriodMonths}개월)\n`;
    text += `- 담보/보증 구분: ${formData.collateralType}\n\n`;

    text += `4. 사업 개요 및 핵심 경쟁력\n`;
    text += `${formData.businessOverview}\n\n[차별화 경쟁력]\n${formData.marketCompetitiveness}\n\n`;

    text += `5. 자금 소요 내역 및 활용 계획\n`;
    text += `${formData.fundRequirementDetails}\n\n[소요 명세]\n`;
    formData.fundUsageItems.forEach((item, idx) => {
      text += ` (${idx + 1}) ${item.itemName} / ${item.category} / ${item.amount.toLocaleString()}원 / 집행시기: ${item.executionMonth}\n`;
    });
    text += `\n[집행 및 사후관리]\n${formData.fundUsageSchedule}\n\n`;

    text += `6. 매출 증대 효과 및 원리금 상환 계획\n`;
    text += `[매출 증대 계획]\n${formData.salesGrowthPlan}\n\n[상환 계획]\n${formData.debtRepaymentPlan}\n\n[리스크 관리]\n${formData.riskManagementPlan}\n\n`;

    text += `7. 사실확인 및 서약\n`;
    text += `「중소기업기본법」 및 관련 정책자금 융자 규정에 따라 상기 기재사항이 사실과 틀림없음을 확약하며, 허위사실 확인 시 자금 환수 및 제재조치에 일체 이의를 제기하지 아니할 것을 서약합니다.\n\n`;
    text += `${formData.applicationDate}\n신청기업: ${formData.businessName}\n대표자: ${formData.ceoName} (서명 또는 인)\n귀중: ${formData.targetAgency}장`;

    navigator.clipboard.writeText(text);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2500);
  };

  // Add Item to Fund Usage Table
  const handleAddUsageItem = () => {
    setFormData((prev) => ({
      ...prev,
      fundUsageItems: [
        ...prev.fundUsageItems,
        {
          id: `item-${Date.now()}`,
          itemName: '추가 소요 품목',
          category: '운전자금',
          supplier: '거래처명',
          amount: 5000000,
          executionMonth: '2개월차',
          notes: ''
        }
      ]
    }));
  };

  const handleRemoveUsageItem = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      fundUsageItems: prev.fundUsageItems.filter((i) => i.id !== id)
    }));
  };

  const handleUpdateUsageItem = (id: string, field: keyof FundUsageItem, val: any) => {
    setFormData((prev) => ({
      ...prev,
      fundUsageItems: prev.fundUsageItems.map((i) => (i.id === id ? { ...i, [field]: val } : i))
    }));
  };

  const totalFundUsageAmount = useMemo(() => {
    return formData.fundUsageItems.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);
  }, [formData.fundUsageItems]);

  // Completeness and Missing Items Audit Engine
  const completenessAudit = useMemo(() => {
    const missing: MissingAuditItem[] = [];

    // Tab 1: INFO Checks (8 items)
    let infoPassed = 0;
    const infoTotal = 8;

    if (formData.businessName?.trim().length >= 2) {
      infoPassed++;
    } else {
      missing.push({
        id: 'info-businessName',
        tab: 'INFO',
        tabName: '1. 기본 및 기업정보',
        field: 'businessName',
        fieldLabel: '상호(법인명)',
        severity: 'CRITICAL',
        message: '기업 상호명이 입력되지 않았습니다.',
        suggestion: '사업자등록증 상의 정확한 상호(법인명)를 기재해주세요.'
      });
    }

    if (formData.businessRegistrationNumber?.trim().replace(/-/g, '').length === 10) {
      infoPassed++;
    } else {
      missing.push({
        id: 'info-businessRegistrationNumber',
        tab: 'INFO',
        tabName: '1. 기본 및 기업정보',
        field: 'businessRegistrationNumber',
        fieldLabel: '사업자등록번호',
        severity: 'CRITICAL',
        message: '사업자등록번호 10자리 형식이 올바르지 않거나 누락되었습니다.',
        suggestion: '국세청 홈택스에 등록된 10자리 사업자등록번호(예: 123-45-67890)를 입력하세요.'
      });
    }

    if (formData.ceoName?.trim().length >= 2) {
      infoPassed++;
    } else {
      missing.push({
        id: 'info-ceoName',
        tab: 'INFO',
        tabName: '1. 기본 및 기업정보',
        field: 'ceoName',
        fieldLabel: '대표자 성명',
        severity: 'CRITICAL',
        message: '대표자 성명이 누락되었습니다.',
        suggestion: '대표자 실명을 기재해주세요.'
      });
    }

    if (formData.contactPhone?.trim().length >= 9) {
      infoPassed++;
    } else {
      missing.push({
        id: 'info-contactPhone',
        tab: 'INFO',
        tabName: '1. 기본 및 기업정보',
        field: 'contactPhone',
        fieldLabel: '대표 연락처',
        severity: 'CRITICAL',
        message: '심사 안내 및 보완 통지를 수신할 대표 연락처가 누락되었습니다.',
        suggestion: '대표자 휴대폰 또는 사업장 공식 전화번호를 9자리 이상 입력해주세요.'
      });
    }

    if (formData.email?.trim().includes('@') && formData.email?.trim().length >= 6) {
      infoPassed++;
    } else {
      missing.push({
        id: 'info-email',
        tab: 'INFO',
        tabName: '1. 기본 및 기업정보',
        field: 'email',
        fieldLabel: '이메일 주소',
        severity: 'WARNING',
        message: '전자공문 수령 및 심사 보완 요청을 위한 유효한 이메일 주소가 필요합니다.',
        suggestion: '정상적인 이메일 주소(예: contact@company.com)를 입력해주세요.'
      });
    }

    if (formData.businessAddress?.trim().length >= 5) {
      infoPassed++;
    } else {
      missing.push({
        id: 'info-businessAddress',
        tab: 'INFO',
        tabName: '1. 기본 및 기업정보',
        field: 'businessAddress',
        fieldLabel: '사업장 소재지',
        severity: 'CRITICAL',
        message: '사업장 본점 주소가 누락되었습니다.',
        suggestion: '사업자등록증 상의 도로명 주소를 상세히 기재해주세요.'
      });
    }

    if (formData.industryCategory?.trim().length >= 2) {
      infoPassed++;
    } else {
      missing.push({
        id: 'info-industryCategory',
        tab: 'INFO',
        tabName: '1. 기본 및 기업정보',
        field: 'industryCategory',
        fieldLabel: '주요 업종/종목',
        severity: 'RECOMMENDED',
        message: '주요 업종 및 종목이 입력되지 않았습니다.',
        suggestion: '예: 도소매업, IT 소프트웨어 개발, 외식 서비스 등 주력 업종을 명시하세요.'
      });
    }

    if (formData.mainProduct?.trim().length >= 2) {
      infoPassed++;
    } else {
      missing.push({
        id: 'info-mainProduct',
        tab: 'INFO',
        tabName: '1. 기본 및 기업정보',
        field: 'mainProduct',
        fieldLabel: '주요 생산품/서비스',
        severity: 'RECOMMENDED',
        message: '주요 취급 제품 및 서비스 명칭이 누락되었습니다.',
        suggestion: '실제 매출이 발생하는 주력 제품 또는 핵심 서비스를 기재해주세요.'
      });
    }

    // Tab 2: FINANCE Checks (5 items)
    let finPassed = 0;
    const finTotal = 5;

    if (formData.annualRevenue > 0) {
      finPassed++;
    } else {
      missing.push({
        id: 'fin-annualRevenue',
        tab: 'FINANCE',
        tabName: '2. 재무 및 자금신청',
        field: 'annualRevenue',
        fieldLabel: '당해연도(최근) 매출액',
        severity: 'CRITICAL',
        message: '당해연도(최근) 매출액이 0원 또는 미입력 상태입니다.',
        suggestion: '부가가치세 과세표준증명원 또는 결산 재무제표 기준 매출액을 숫자로 기재하세요.'
      });
    }

    if (formData.prevYearRevenue > 0) {
      finPassed++;
    } else {
      missing.push({
        id: 'fin-prevYearRevenue',
        tab: 'FINANCE',
        tabName: '2. 재무 및 자금신청',
        field: 'prevYearRevenue',
        fieldLabel: '전년도 매출액',
        severity: 'WARNING',
        message: '전년도 매출액이 입력되지 않았습니다.',
        suggestion: '성장성 심사를 위해 전년도 매출액을 입력해주세요 (신규 창업자는 0 가능).'
      });
    }

    if (formData.requestedAmount >= 1000000) {
      finPassed++;
    } else {
      missing.push({
        id: 'fin-requestedAmount',
        tab: 'FINANCE',
        tabName: '2. 재무 및 자금신청',
        field: 'requestedAmount',
        fieldLabel: '신청 희망 금액',
        severity: 'CRITICAL',
        message: '정책자금 신청 희망 금액이 100만원 미만이거나 비어있습니다.',
        suggestion: '희망하는 대출/지원 자금 규모(예: 3,000만원, 5,000만원)를 기재해주세요.'
      });
    }

    if (formData.preferredTerm?.trim().length >= 2) {
      finPassed++;
    } else {
      missing.push({
        id: 'fin-preferredTerm',
        tab: 'FINANCE',
        tabName: '2. 재무 및 자금신청',
        field: 'preferredTerm',
        fieldLabel: '희망 대출 기간',
        severity: 'RECOMMENDED',
        message: '희망 상환기간이 지정되지 않았습니다.',
        suggestion: '예: "5년 (거치 2년)" 형식으로 상환 구조를 기재해주세요.'
      });
    }

    if (formData.primaryBank?.trim().length >= 2) {
      finPassed++;
    } else {
      missing.push({
        id: 'fin-primaryBank',
        tab: 'FINANCE',
        tabName: '2. 재무 및 자금신청',
        field: 'primaryBank',
        fieldLabel: '주거래 금융기관',
        severity: 'RECOMMENDED',
        message: '주거래 금융기관이 누락되었습니다.',
        suggestion: '보증서 발급 후 실제 대출을 실행할 주거래 은행을 입력해주세요.'
      });
    }

    // Tab 3: NARRATIVE Checks (5 items)
    let narrativePassed = 0;
    const narrativeTotal = 5;

    if (formData.businessOverview?.trim().length >= 25) {
      narrativePassed++;
    } else {
      missing.push({
        id: 'narrative-businessOverview',
        tab: 'NARRATIVE',
        tabName: '3. 사업 및 상환계획 (AI)',
        field: 'businessOverview',
        fieldLabel: '기업 및 사업 개요',
        severity: 'CRITICAL',
        message: `사업 개요 서술이 너무 짧거나 비어있습니다 (현재 ${formData.businessOverview?.trim().length || 0}자 / 권장 25자 이상).`,
        suggestion: '설립 배경, 주력 비즈니스 모델, 주요 타겟 고객층을 구체적으로 기재하거나 [AI 문구 다듬기]를 활용하세요.'
      });
    }

    if (formData.marketCompetitiveness?.trim().length >= 25) {
      narrativePassed++;
    } else {
      missing.push({
        id: 'narrative-marketCompetitiveness',
        tab: 'NARRATIVE',
        tabName: '3. 사업 및 상환계획 (AI)',
        field: 'marketCompetitiveness',
        fieldLabel: '시장성 및 핵심 경쟁력',
        severity: 'WARNING',
        message: `시장 경쟁력 서술이 부족합니다 (현재 ${formData.marketCompetitiveness?.trim().length || 0}자 / 권장 25자 이상).`,
        suggestion: '동종 업계 대비 차별화 포인트(기술력, 단골 확보율, 가성비 등)를 구체적으로 제시하세요.'
      });
    }

    if (formData.fundRequirementDetails?.trim().length >= 25) {
      narrativePassed++;
    } else {
      missing.push({
        id: 'narrative-fundRequirementDetails',
        tab: 'NARRATIVE',
        tabName: '3. 사업 및 상환계획 (AI)',
        field: 'fundRequirementDetails',
        fieldLabel: '자금 소요 내역 및 산출 근거',
        severity: 'CRITICAL',
        message: `자금 소요 목적 및 산출 근거가 미흡합니다 (현재 ${formData.fundRequirementDetails?.trim().length || 0}자 / 권장 25자 이상).`,
        suggestion: '신청 자금이 어디에 왜 필요한지, 품목별 단가와 도입 수량의 산출 근거를 구체적으로 서술하세요.'
      });
    }

    if (formData.salesGrowthPlan?.trim().length >= 25) {
      narrativePassed++;
    } else {
      missing.push({
        id: 'narrative-salesGrowthPlan',
        tab: 'NARRATIVE',
        tabName: '3. 사업 및 상환계획 (AI)',
        field: 'salesGrowthPlan',
        fieldLabel: '매출 증대 및 사업화 계획',
        severity: 'WARNING',
        message: `자금 투입 후 성장 계획이 부족합니다 (현재 ${formData.salesGrowthPlan?.trim().length || 0}자 / 권장 25자 이상).`,
        suggestion: '자금 수혜 후 예상 매출 성장률(%) 및 신규 판로 개척 전략을 제시하세요.'
      });
    }

    if (formData.debtRepaymentPlan?.trim().length >= 25) {
      narrativePassed++;
    } else {
      missing.push({
        id: 'narrative-debtRepaymentPlan',
        tab: 'NARRATIVE',
        tabName: '3. 사업 및 상환계획 (AI)',
        field: 'debtRepaymentPlan',
        fieldLabel: '원리금 상환 계획',
        severity: 'CRITICAL',
        message: `원리금 상환 계획이 부족합니다 (현재 ${formData.debtRepaymentPlan?.trim().length || 0}자 / 권장 25자 이상).`,
        suggestion: '월 예상 영업이익, 매출채권 회수 계획을 토대로 연체 없는 확실한 상환 재원을 서술하세요.'
      });
    }

    // Tab 4: ITEMS Checks (3 items)
    let itemsPassed = 0;
    const itemsTotal = 3;

    if (formData.fundUsageItems && formData.fundUsageItems.length >= 1) {
      itemsPassed++;
    } else {
      missing.push({
        id: 'items-count',
        tab: 'ITEMS',
        tabName: '4. 소요명세표',
        field: 'fundUsageItems',
        fieldLabel: '소요 품목 등록',
        severity: 'CRITICAL',
        message: '자금 집행 세부 소요 품목이 1개도 등록되지 않았습니다.',
        suggestion: '[항목 추가]를 눌러 구매 예정 품목명, 예상 금액, 공급처를 등록해주세요.'
      });
    }

    const allItemsValid = formData.fundUsageItems.length > 0 && formData.fundUsageItems.every(
      (i) => i.itemName?.trim().length > 0 && Number(i.amount) > 0
    );
    if (allItemsValid) {
      itemsPassed++;
    } else if (formData.fundUsageItems.length > 0) {
      missing.push({
        id: 'items-validity',
        tab: 'ITEMS',
        tabName: '4. 소요명세표',
        field: 'fundUsageItems-valid',
        fieldLabel: '소요 품목 유효성',
        severity: 'WARNING',
        message: '품목명이 비어있거나 금액이 0원인 소요 항목이 존재합니다.',
        suggestion: '등록된 모든 소요 품목의 명칭과 예상 금액을 정확히 기입해주세요.'
      });
    }

    const isAmountBalanced = totalFundUsageAmount > 0 && 
      Math.abs(totalFundUsageAmount - formData.requestedAmount) <= (formData.requestedAmount * 0.05);
    if (isAmountBalanced) {
      itemsPassed++;
    } else if (totalFundUsageAmount > 0 && formData.requestedAmount > 0) {
      const diff = totalFundUsageAmount - formData.requestedAmount;
      missing.push({
        id: 'items-amountBalance',
        tab: 'ITEMS',
        tabName: '4. 소요명세표',
        field: 'fundUsageItems-balance',
        fieldLabel: '소요명세 합계액 일치',
        severity: 'WARNING',
        message: `소요명세표 합계(금 ${totalFundUsageAmount.toLocaleString()}원)와 신청 희망금액(금 ${formData.requestedAmount.toLocaleString()}원)이 ${Math.abs(diff).toLocaleString()}원 차이납니다.`,
        suggestion: '심사관의 정합성 검증을 위해 소요명세 합계액을 신청금액과 일치하도록 조정하세요.'
      });
    }

    // Tab 5: PLEDGE Checks (2 items)
    let pledgePassed = 0;
    const pledgeTotal = 2;

    const allPledgesChecked = formData.pledgeNoBroker &&
      formData.pledgeNoTaxDelinquency &&
      formData.pledgeFactTrue &&
      formData.pledgeRefundOnFalse &&
      formData.pledgeCreditInfoConsent;

    if (allPledgesChecked) {
      pledgePassed++;
    } else {
      missing.push({
        id: 'pledge-checkboxes',
        tab: 'PLEDGE',
        tabName: '5. 사실확인 및 서명',
        field: 'pledges',
        fieldLabel: '법정 서약 5개 조항 동의',
        severity: 'CRITICAL',
        message: '필수 법정 서약 5대 조항(브로커 배제, 체납 없음, 신용정보동의 등) 중 미동의 항목이 있습니다.',
        suggestion: '신청서 접수를 위해 5개 서약 항목의 체크박스를 모두 확인 후 체크해주세요.'
      });
    }

    if (formData.representativeSignatureName?.trim().length >= 2) {
      pledgePassed++;
    } else {
      missing.push({
        id: 'pledge-signature',
        tab: 'PLEDGE',
        tabName: '5. 사실확인 및 서명',
        field: 'representativeSignatureName',
        fieldLabel: '대표자 서명 성명',
        severity: 'CRITICAL',
        message: '서약서 하단 대표자 서명 성명이 누락되었습니다.',
        suggestion: '서약 효력을 위해 대표자 성명을 직접 입력해주세요.'
      });
    }

    const totalPassedChecks = infoPassed + finPassed + narrativePassed + itemsPassed + pledgePassed;
    const totalChecksCount = infoTotal + finTotal + narrativeTotal + itemsTotal + pledgeTotal;

    // Weight based score
    const earnedPoints = (infoPassed * 3) + (finPassed * 4) + (narrativePassed * 6) + (itemsPassed * 4) + (pledgePassed * 5);
    const maxPoints = (infoTotal * 3) + (finTotal * 4) + (narrativeTotal * 6) + (itemsTotal * 4) + (pledgeTotal * 5);
    const score = Math.min(100, Math.max(0, Math.round((earnedPoints / maxPoints) * 100)));

    let statusLabel = '작성 초기 (기초 항목 입력 필요)';
    let statusColor = 'rose';
    if (score === 100) {
      statusLabel = '심사 제출 최적화 완료 (완성도 100%)';
      statusColor = 'emerald';
    } else if (score >= 80) {
      statusLabel = '완성도 우수 (심사 통과 가능 수준)';
      statusColor = 'blue';
    } else if (score >= 50) {
      statusLabel = '작성 진행 중 (필수 누락 보완 필요)';
      statusColor = 'amber';
    }

    return {
      score,
      totalChecks: totalChecksCount,
      passedChecks: totalPassedChecks,
      statusLabel,
      statusColor,
      tabScores: {
        INFO: { score: Math.round((infoPassed / infoTotal) * 100), passed: infoPassed, total: infoTotal },
        FINANCE: { score: Math.round((finPassed / finTotal) * 100), passed: finPassed, total: finTotal },
        NARRATIVE: { score: Math.round((narrativePassed / narrativeTotal) * 100), passed: narrativePassed, total: narrativeTotal },
        ITEMS: { score: Math.round((itemsPassed / itemsTotal) * 100), passed: itemsPassed, total: itemsTotal },
        PLEDGE: { score: Math.round((pledgePassed / pledgeTotal) * 100), passed: pledgePassed, total: pledgeTotal },
      },
      missingItems: missing
    };
  }, [formData, totalFundUsageAmount]);

  const handleJumpToMissingItem = (item: MissingAuditItem) => {
    setActiveEditorTab(item.tab);
    if (viewMode === 'PREVIEW_ONLY') {
      setViewMode('SPLIT');
    }
  };

  const filteredMissingItems = useMemo(() => {
    if (selectedSeverityFilter === 'CRITICAL') {
      return completenessAudit.missingItems.filter((i) => i.severity === 'CRITICAL');
    }
    if (selectedSeverityFilter === 'WARNING') {
      return completenessAudit.missingItems.filter((i) => i.severity === 'WARNING' || i.severity === 'CRITICAL');
    }
    return completenessAudit.missingItems;
  }, [completenessAudit.missingItems, selectedSeverityFilter]);

  // Data Source Provenance Engine (데이터 출처 및 히스토리 역추적 분석)
  const fieldProvenances = useMemo<FieldProvenanceItem[]>(() => {
    const prof = profile;
    const isProf = Boolean(prof);

    return [
      {
        id: 'prov-businessName',
        fieldKey: 'businessName',
        fieldLabel: '상호(법인명)',
        tabKey: 'INFO',
        tabLabel: '1. 기업 기본정보',
        sourceType: isProf && prof?.businessName === formData.businessName ? 'PROFILE' : formData.businessName ? 'MANUAL_INPUT' : 'PROFILE',
        sourceTypeName: isProf && prof?.businessName === formData.businessName ? '사용자 프로필' : '사용자 직접 수정',
        sourceOrigin: '마이프로필 > 회사 기본정보',
        sourceTracePath: '사업자등록증 상의 정식 사업체 상호명 데이터 연동',
        rawSourceValue: prof?.businessName || '대한상사',
        currentDisplayValue: formData.businessName || '(미입력)',
        isCustomized: Boolean(prof?.businessName && formData.businessName !== prof.businessName),
        confidenceScore: 100,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '마이프로필 기업 상호명 1:1 매핑',
        verified: verifiedFieldKeys.includes('businessName')
      },
      {
        id: 'prov-businessRegistrationNumber',
        fieldKey: 'businessRegistrationNumber',
        fieldLabel: '사업자등록번호',
        tabKey: 'INFO',
        tabLabel: '1. 기업 기본정보',
        sourceType: isProf && prof?.businessRegistrationNumber === formData.businessRegistrationNumber ? 'PROFILE' : 'PROFILE',
        sourceTypeName: '사용자 프로필',
        sourceOrigin: '마이프로필 > 세무/사업자 번호',
        sourceTracePath: '국세청 홈택스 사업자등록증 10자리 고유 식별번호 연동',
        rawSourceValue: prof?.businessRegistrationNumber || '123-45-67890',
        currentDisplayValue: formData.businessRegistrationNumber || '(미입력)',
        isCustomized: Boolean(prof?.businessRegistrationNumber && formData.businessRegistrationNumber !== prof.businessRegistrationNumber),
        confidenceScore: 100,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '3-2-5 표준 사업자등록번호 유효성 체계',
        verified: verifiedFieldKeys.includes('businessRegistrationNumber')
      },
      {
        id: 'prov-corporateRegistrationNumber',
        fieldKey: 'corporateRegistrationNumber',
        fieldLabel: '법인등록번호',
        tabKey: 'INFO',
        tabLabel: '1. 기업 기본정보',
        sourceType: 'SMART_CALC',
        sourceTypeName: '스마트 규칙 엔진',
        sourceOrigin: '기업형태 판별 규칙',
        sourceTracePath: prof?.businessType === 'CORPORATION' ? '법인등기부등본 등록번호' : '개인사업자 자동 감지 → 해당없음 처리',
        rawSourceValue: prof?.businessType === 'CORPORATION' ? '법인' : '개인사업자',
        currentDisplayValue: formData.corporateRegistrationNumber || '해당없음',
        isCustomized: false,
        confidenceScore: 98,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '법인 vs 개인사업자 행정 서식 자동 분기 규칙',
        verified: verifiedFieldKeys.includes('corporateRegistrationNumber')
      },
      {
        id: 'prov-ceoName',
        fieldKey: 'ceoName',
        fieldLabel: '대표자 성명',
        tabKey: 'INFO',
        tabLabel: '1. 기업 기본정보',
        sourceType: isProf && prof?.name === formData.ceoName ? 'PROFILE' : 'PROFILE',
        sourceTypeName: '사용자 프로필',
        sourceOrigin: '마이프로필 > 대표자 실명',
        sourceTracePath: '본인 인증 및 사업자등록증 상의 대표자 성명 연동',
        rawSourceValue: prof?.name || '홍길동',
        currentDisplayValue: formData.ceoName || '(미입력)',
        isCustomized: Boolean(prof?.name && formData.ceoName !== prof.name),
        confidenceScore: 100,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '대표자 성명 1:1 매핑',
        verified: verifiedFieldKeys.includes('ceoName')
      },
      {
        id: 'prov-businessType',
        fieldKey: 'businessType',
        fieldLabel: '기업 형태 (법인/개인)',
        tabKey: 'INFO',
        tabLabel: '1. 기업 기본정보',
        sourceType: 'PROFILE',
        sourceTypeName: '사용자 프로필',
        sourceOrigin: '마이프로필 > 사업자 유형',
        sourceTracePath: '개인사업자 / 법인사업자 분류 정보 연동',
        rawSourceValue: prof?.businessType === 'CORPORATION' ? '법인사업자' : '개인사업자',
        currentDisplayValue: formData.businessType,
        isCustomized: false,
        confidenceScore: 100,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '사업자등록 형태 분류 매핑',
        verified: verifiedFieldKeys.includes('businessType')
      },
      {
        id: 'prov-industryCategory',
        fieldKey: 'industryCategory',
        fieldLabel: '주요 업종 및 종목',
        tabKey: 'INFO',
        tabLabel: '1. 기업 기본정보',
        sourceType: 'PROFILE',
        sourceTypeName: '사용자 프로필',
        sourceOrigin: '마이프로필 > 주력 산업군',
        sourceTracePath: `한국표준산업분류(KSIC) 기준 주력 업종명 변환 (${prof?.industry ? getIndustryText(prof.industry) : '도소매업'})`,
        rawSourceValue: prof?.industry ? getIndustryText(prof.industry) : '도소매 및 서비스업',
        currentDisplayValue: formData.industryCategory,
        isCustomized: false,
        confidenceScore: 98,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '표준산업분류 코드 매핑 엔진',
        verified: verifiedFieldKeys.includes('industryCategory')
      },
      {
        id: 'prov-mainProduct',
        fieldKey: 'mainProduct',
        fieldLabel: '주요 생산품/서비스',
        tabKey: 'INFO',
        tabLabel: '1. 기업 기본정보',
        sourceType: 'SMART_CALC',
        sourceTypeName: '스마트 추론',
        sourceOrigin: '업종별 대표 품목 사전 라이브러리',
        sourceTracePath: `등록 업종(${prof?.industry || '기타'}) 특화 대표 품목 모델링`,
        rawSourceValue: prof?.industry || '기타',
        currentDisplayValue: formData.mainProduct,
        isCustomized: false,
        confidenceScore: 92,
        reliabilityLevel: 'MEDIUM',
        formulaOrLogic: '업종 특화 주력 공급 품목 사전 추론',
        verified: verifiedFieldKeys.includes('mainProduct')
      },
      {
        id: 'prov-businessAddress',
        fieldKey: 'businessAddress',
        fieldLabel: '사업장 소재지 (본점 주소)',
        tabKey: 'INFO',
        tabLabel: '1. 기업 기본정보',
        sourceType: 'PROFILE',
        sourceTypeName: '사용자 프로필',
        sourceOrigin: '마이프로필 > 사업장 주소',
        sourceTracePath: '도로명주소 표준 체계 본점 소재지 연동',
        rawSourceValue: prof?.businessAddress || '서울특별시 영등포구 여의대로 128',
        currentDisplayValue: formData.businessAddress,
        isCustomized: Boolean(prof?.businessAddress && formData.businessAddress !== prof.businessAddress),
        confidenceScore: 100,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '본점 사업장 주소 1:1 매핑',
        verified: verifiedFieldKeys.includes('businessAddress')
      },
      {
        id: 'prov-foundedDate',
        fieldKey: 'foundedDate',
        fieldLabel: '개업(창업)연월일',
        tabKey: 'INFO',
        tabLabel: '1. 기업 기본정보',
        sourceType: 'PROFILE',
        sourceTypeName: '사용자 프로필',
        sourceOrigin: '마이프로필 > 창업(설립)연도',
        sourceTracePath: `마이프로필 창업연도(${prof?.foundedYear || 2022}년) 기반 표준 개업일자 변환`,
        rawSourceValue: prof?.foundedYear || 2022,
        currentDisplayValue: formData.foundedDate,
        isCustomized: false,
        confidenceScore: 96,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '창업연도 YYYY.MM.DD 표준 행정 날짜 변환',
        verified: verifiedFieldKeys.includes('foundedDate')
      },
      {
        id: 'prov-annualRevenue',
        fieldKey: 'annualRevenue',
        fieldLabel: '당해연도(최근) 매출액',
        tabKey: 'FINANCE',
        tabLabel: '2. 재무 및 자금신청',
        sourceType: 'PROFILE',
        sourceTypeName: '사용자 프로필',
        sourceOrigin: '마이프로필 > 최근 연간 매출액',
        sourceTracePath: '부가가치세 과세표준증명원 기준 최근 1개년 매출액 데이터',
        rawSourceValue: prof?.annualRevenue || 150000000,
        currentDisplayValue: `${formatWonKorean(formData.annualRevenue)} (${formData.annualRevenue.toLocaleString()}원)`,
        isCustomized: Boolean(prof?.annualRevenue && formData.annualRevenue !== prof.annualRevenue),
        confidenceScore: 100,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '부가세 과표증명원 / 손익계산서 1개년 실적 매핑',
        verified: verifiedFieldKeys.includes('annualRevenue')
      },
      {
        id: 'prov-prevYearRevenue',
        fieldKey: 'prevYearRevenue',
        fieldLabel: '전년도 매출액 (N-1)',
        tabKey: 'FINANCE',
        tabLabel: '2. 재무 및 자금신청',
        sourceType: 'SMART_CALC',
        sourceTypeName: '스마트 재무 모델링',
        sourceOrigin: '스마트 재무 역산 엔진',
        sourceTracePath: `당해 매출액(${formatWonKorean(formData.annualRevenue)}) 기준 85% 역산 추정`,
        rawSourceValue: Math.round(formData.annualRevenue * 0.85),
        currentDisplayValue: `${formatWonKorean(formData.prevYearRevenue)} (${formData.prevYearRevenue.toLocaleString()}원)`,
        isCustomized: false,
        confidenceScore: 92,
        reliabilityLevel: 'ESTIMATED',
        formulaOrLogic: '당해 매출 × 0.85 (과거 3개년 성장 곡선 모델링)',
        verified: verifiedFieldKeys.includes('prevYearRevenue')
      },
      {
        id: 'prov-twoYearsAgoRevenue',
        fieldKey: 'twoYearsAgoRevenue',
        fieldLabel: '전전년도 매출액 (N-2)',
        tabKey: 'FINANCE',
        tabLabel: '2. 재무 및 자금신청',
        sourceType: 'SMART_CALC',
        sourceTypeName: '스마트 재무 모델링',
        sourceOrigin: '스마트 재무 역산 엔진',
        sourceTracePath: `당해 매출액(${formatWonKorean(formData.annualRevenue)}) 기준 70% 역산 추정`,
        rawSourceValue: Math.round(formData.annualRevenue * 0.70),
        currentDisplayValue: `${formatWonKorean(formData.twoYearsAgoRevenue)} (${formData.twoYearsAgoRevenue.toLocaleString()}원)`,
        isCustomized: false,
        confidenceScore: 90,
        reliabilityLevel: 'ESTIMATED',
        formulaOrLogic: '당해 매출 × 0.70 (3개년 연속성 추이 검증)',
        verified: verifiedFieldKeys.includes('twoYearsAgoRevenue')
      },
      {
        id: 'prov-operatingProfit',
        fieldKey: 'operatingProfit',
        fieldLabel: '연간 영업이익',
        tabKey: 'FINANCE',
        tabLabel: '2. 재무 및 자금신청',
        sourceType: 'SMART_CALC',
        sourceTypeName: '스마트 재무 모델링',
        sourceOrigin: '스마트 손익 계산 엔진',
        sourceTracePath: `연매출 × 기대 마진율(${prof?.expectedProfitMargin || 15}%)`,
        rawSourceValue: Math.round((prof?.annualRevenue || 150000000) * ((prof?.expectedProfitMargin || 15) / 100)),
        currentDisplayValue: `${formatWonKorean(formData.operatingProfit)} (${formData.operatingProfit.toLocaleString()}원)`,
        isCustomized: false,
        confidenceScore: 94,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '연매출 × 기대영업이익률 (원리금 상환 가능 영업현금흐름)',
        verified: verifiedFieldKeys.includes('operatingProfit')
      },
      {
        id: 'prov-employeeCount',
        fieldKey: 'employeeCount',
        fieldLabel: '상시 근로자수',
        tabKey: 'FINANCE',
        tabLabel: '2. 재무 및 자금신청',
        sourceType: 'PROFILE',
        sourceTypeName: '사용자 프로필',
        sourceOrigin: '마이프로필 > 4대보험 가입자',
        sourceTracePath: '4대보험 사업장 가입자 명부 기준 상시 근로자 인원수',
        rawSourceValue: prof?.employees || 2,
        currentDisplayValue: `${formData.employeeCount}명`,
        isCustomized: Boolean(prof?.employees && formData.employeeCount !== prof.employees),
        confidenceScore: 100,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '고용보험/국민연금 상시 가입 근로자수 매핑',
        verified: verifiedFieldKeys.includes('employeeCount')
      },
      {
        id: 'prov-fullTimeEmployees',
        fieldKey: 'fullTimeEmployees',
        fieldLabel: '정규직 근로자수',
        tabKey: 'FINANCE',
        tabLabel: '2. 재무 및 자금신청',
        sourceType: 'SMART_CALC',
        sourceTypeName: '스마트 고용 분석',
        sourceOrigin: '정규직 비중 산출 공식',
        sourceTracePath: '상시 근로자수 기준 정규직 비중(N-1) 모델링',
        rawSourceValue: Math.max(1, (prof?.employees || 2) - 1),
        currentDisplayValue: `${formData.fullTimeEmployees}명`,
        isCustomized: false,
        confidenceScore: 95,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '상시 근로자 수 기반 정규직 추정 산출',
        verified: verifiedFieldKeys.includes('fullTimeEmployees')
      },
      {
        id: 'prov-existingDebtTotal',
        fieldKey: 'existingDebtTotal',
        fieldLabel: '기존 금융권 대출 잔액',
        tabKey: 'FINANCE',
        tabLabel: '2. 재무 및 자금신청',
        sourceType: 'PROFILE',
        sourceTypeName: '사용자 프로필',
        sourceOrigin: '마이프로필 > 부채 현황',
        sourceTracePath: '1금융·2금융·카드론·기타 대출 잔액 합계 집계',
        rawSourceValue: ((prof?.debt1Tier || 0) + (prof?.debt2Tier || 0) + (prof?.debtCardLoan || 0) + (prof?.debtOther || 0)) || 20000000,
        currentDisplayValue: `${formatWonKorean(formData.existingDebtTotal)} (${formData.existingDebtTotal.toLocaleString()}원)`,
        isCustomized: false,
        confidenceScore: 98,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '금융기관 대출 총잔액 합산',
        verified: verifiedFieldKeys.includes('existingDebtTotal')
      },
      {
        id: 'prov-requestedAmount',
        fieldKey: 'requestedAmount',
        fieldLabel: '정책자금 신청 희망액',
        tabKey: 'FINANCE',
        tabLabel: '2. 재무 및 자금신청',
        sourceType: 'PROFILE',
        sourceTypeName: '사용자 프로필 & 공고 요건',
        sourceOrigin: '마이프로필 > 자금 희망액 & 공고 한도',
        sourceTracePath: `사용자 희망액(${formatWonKorean(prof?.fundingNeed || 50000000)})과 정책자금 공고 한도 교차 검증`,
        rawSourceValue: prof?.fundingNeed || 50000000,
        currentDisplayValue: `${formatWonKorean(formData.requestedAmount)} (${formData.requestedAmount.toLocaleString()}원)`,
        isCustomized: Boolean(prof?.fundingNeed && formData.requestedAmount !== prof.fundingNeed),
        confidenceScore: 100,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '지원사업 최대 지원한도 내 소요 희망액',
        verified: verifiedFieldKeys.includes('requestedAmount')
      },
      {
        id: 'prov-businessOverview',
        fieldKey: 'businessOverview',
        fieldLabel: '1. 사업 개요 및 주요 품목',
        tabKey: 'NARRATIVE',
        tabLabel: '3. 사업 및 상환계획',
        sourceType: 'AI_GENERATED',
        sourceTypeName: 'Gemini AI & 스마트 서술',
        sourceOrigin: 'Gemini AI / 스마트 룰 엔진',
        sourceTracePath: `창업 ${prof?.foundedYear || 2022}년차 및 업종(${prof?.industry || '기타'}) 기반 심사관 친화형 소개`,
        rawSourceValue: '업종 및 창업연도 기반 프롬프트',
        currentDisplayValue: formData.businessOverview ? (formData.businessOverview.slice(0, 55) + '...') : '(미작성)',
        isCustomized: false,
        confidenceScore: 95,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '정책자금 심사 표준 3단 구성 (설립경위-사업영역-성장기반)',
        verified: verifiedFieldKeys.includes('businessOverview')
      },
      {
        id: 'prov-marketCompetitiveness',
        fieldKey: 'marketCompetitiveness',
        fieldLabel: '2. 기술성 및 시장 경쟁력',
        tabKey: 'NARRATIVE',
        tabLabel: '3. 사업 및 상환계획',
        sourceType: 'AI_GENERATED',
        sourceTypeName: 'Gemini AI & 스마트 서술',
        sourceOrigin: '업종별 핵심 기술 라이브러리',
        sourceTracePath: '업종 특화 3대 핵심 경쟁력 (원가절감·품질관리·판로확보)',
        rawSourceValue: '업종별 경쟁우위 프리셋',
        currentDisplayValue: formData.marketCompetitiveness ? (formData.marketCompetitiveness.slice(0, 55) + '...') : '(미작성)',
        isCustomized: false,
        confidenceScore: 94,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '기술성 평가 3대 항목 (품질·단가·고객망) 구조화',
        verified: verifiedFieldKeys.includes('marketCompetitiveness')
      },
      {
        id: 'prov-fundRequirementDetails',
        fieldKey: 'fundRequirementDetails',
        fieldLabel: '3. 자금 필요성 및 신청 사유',
        tabKey: 'NARRATIVE',
        tabLabel: '3. 사업 및 상환계획',
        sourceType: 'AI_GENERATED',
        sourceTypeName: 'Gemini AI & 스마트 서술',
        sourceOrigin: '자금 소요 산출 근거 엔진',
        sourceTracePath: `신청금액(${formatWonKorean(formData.requestedAmount)}) 투입 명분 및 운전자금 소요 이유`,
        rawSourceValue: '신청금액 연동',
        currentDisplayValue: formData.fundRequirementDetails ? (formData.fundRequirementDetails.slice(0, 55) + '...') : '(미작성)',
        isCustomized: false,
        confidenceScore: 96,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '운전자금 소요 명분 및 매출 연계 효과',
        verified: verifiedFieldKeys.includes('fundRequirementDetails')
      },
      {
        id: 'prov-salesGrowthPlan',
        fieldKey: 'salesGrowthPlan',
        fieldLabel: '5. 기대 효과 및 매출 성장 계획',
        tabKey: 'NARRATIVE',
        tabLabel: '3. 사업 및 상환계획',
        sourceType: 'SMART_CALC',
        sourceTypeName: '스마트 재무 모델링',
        sourceOrigin: '스마트 성장률 시뮬레이터',
        sourceTracePath: `당해 매출(${formatWonKorean(formData.annualRevenue)}) 대비 25% 목표 성장액 계산`,
        rawSourceValue: '매출 25% 성장 모델',
        currentDisplayValue: formData.salesGrowthPlan ? (formData.salesGrowthPlan.slice(0, 55) + '...') : '(미작성)',
        isCustomized: false,
        confidenceScore: 93,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '연매출 × 1.25 및 원가절감(8%) 기반 수익 개선',
        verified: verifiedFieldKeys.includes('salesGrowthPlan')
      },
      {
        id: 'prov-debtRepaymentPlan',
        fieldKey: 'debtRepaymentPlan',
        fieldLabel: '6. 원리금 상환 계획 및 현금흐름',
        tabKey: 'NARRATIVE',
        tabLabel: '3. 사업 및 상환계획',
        sourceType: 'SMART_CALC',
        sourceTypeName: '스마트 재무 모델링',
        sourceOrigin: '스마트 현금흐름 시뮬레이터',
        sourceTracePath: `연간 영업이익(${formatWonKorean(formData.operatingProfit)}) 기반 월 환산 상환 여력 산출`,
        rawSourceValue: '월간 영업현금흐름',
        currentDisplayValue: formData.debtRepaymentPlan ? (formData.debtRepaymentPlan.slice(0, 55) + '...') : '(미작성)',
        isCustomized: false,
        confidenceScore: 95,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '영업현금흐름 / 12개월 분할 상환 전용 통장 약정',
        verified: verifiedFieldKeys.includes('debtRepaymentPlan')
      },
      {
        id: 'prov-fundUsageItems',
        fieldKey: 'fundUsageItems',
        fieldLabel: '소요 명세표 세부 품목',
        tabKey: 'ITEMS',
        tabLabel: '4. 소요명세표',
        sourceType: 'SMART_CALC',
        sourceTypeName: '스마트 명세 배분 엔진',
        sourceOrigin: '스마트 소요명세 3대 균형 배분 공식',
        sourceTracePath: `신청금액(${formatWonKorean(formData.requestedAmount)})을 45%(원부자재), 35%(설비), 20%(마케팅)로 100% 분할`,
        rawSourceValue: `${formData.fundUsageItems.length}개 품목 합계 ${formatWonKorean(formData.requestedAmount)}`,
        currentDisplayValue: `${formData.fundUsageItems.length}개 품목 (총액: ${formatWonKorean(formData.fundUsageItems.reduce((s, i) => s + (i.amount || 0), 0))})`,
        isCustomized: false,
        confidenceScore: 98,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '신청금액 = 45% + 35% + 20% (합계 오차 0원 정밀 배분)',
        verified: verifiedFieldKeys.includes('fundUsageItems')
      },
      {
        id: 'prov-pledgeConfirmed',
        fieldKey: 'pledgeConfirmed',
        fieldLabel: '5대 행정 사실 확인 및 성실 서약',
        tabKey: 'PLEDGE',
        tabLabel: '5. 사실확인 및 서명',
        sourceType: 'FUND_POLICY',
        sourceTypeName: '정책공고 요건',
        sourceOrigin: '중소벤처기업부·소상공인시장진흥공단 공고 규정',
        sourceTracePath: '제3자 부당개입(브로커) 배제, 국세·지방세 체납 없음, 신용정보제공 등 5대 필수 서약',
        rawSourceValue: '공식 필수 서약 5종',
        currentDisplayValue: formData.pledgeFactTrue ? '5대 서약 조항 전원 확인 및 동의 완료' : '서약 미완료',
        isCustomized: false,
        confidenceScore: 100,
        reliabilityLevel: 'HIGH',
        formulaOrLogic: '공공재정 부정청구 방지 및 정책자금 운영세칙',
        verified: verifiedFieldKeys.includes('pledgeConfirmed')
      }
    ];
  }, [formData, profile, verifiedFieldKeys]);

  // Provenance Summary Statistics
  const provenanceStats = useMemo(() => {
    const total = fieldProvenances.length;
    const profileCount = fieldProvenances.filter(p => p.sourceType === 'PROFILE').length;
    const smartCalcCount = fieldProvenances.filter(p => p.sourceType === 'SMART_CALC').length;
    const aiCount = fieldProvenances.filter(p => p.sourceType === 'AI_GENERATED').length;
    const policyCount = fieldProvenances.filter(p => p.sourceType === 'FUND_POLICY').length;
    const manualCount = fieldProvenances.filter(p => p.sourceType === 'MANUAL_INPUT').length;
    const verifiedCount = fieldProvenances.filter(p => p.verified).length;
    const verifiedRate = total > 0 ? Math.round((verifiedCount / total) * 100) : 0;
    const customizedCount = fieldProvenances.filter(p => p.isCustomized).length;

    return {
      total,
      profileCount,
      smartCalcCount,
      aiCount,
      policyCount,
      manualCount,
      verifiedCount,
      verifiedRate,
      customizedCount
    };
  }, [fieldProvenances]);

  // Filtered Provenance Items for Data Source Review
  const filteredProvenances = useMemo(() => {
    return fieldProvenances.filter(item => {
      // Source Type Filter
      if (dataSourceFilter !== 'ALL' && item.sourceType !== dataSourceFilter) {
        return false;
      }
      // Tab Filter
      if (dataSourceTabFilter !== 'ALL' && item.tabKey !== dataSourceTabFilter) {
        return false;
      }
      // Verification State Filter
      if (dataSourceVerificationFilter === 'VERIFIED' && !item.verified) {
        return false;
      }
      if (dataSourceVerificationFilter === 'NEEDS_REVIEW' && item.verified) {
        return false;
      }
      // Search Query Filter
      if (dataSourceSearchQuery.trim()) {
        const q = dataSourceSearchQuery.toLowerCase().trim();
        const matchLabel = item.fieldLabel.toLowerCase().includes(q);
        const matchOrigin = item.sourceOrigin.toLowerCase().includes(q);
        const matchTrace = item.sourceTracePath.toLowerCase().includes(q);
        const matchValue = String(item.currentDisplayValue).toLowerCase().includes(q);
        if (!matchLabel && !matchOrigin && !matchTrace && !matchValue) {
          return false;
        }
      }
      return true;
    });
  }, [fieldProvenances, dataSourceFilter, dataSourceTabFilter, dataSourceVerificationFilter, dataSourceSearchQuery]);

  // Toggle Verification for an individual field
  const handleToggleVerifyField = (fieldKey: string) => {
    setVerifiedFieldKeys(prev => {
      if (prev.includes(fieldKey)) {
        return prev.filter(k => k !== fieldKey);
      } else {
        return [...prev, fieldKey];
      }
    });
  };

  // Verify all fields at once
  const handleVerifyAllFields = () => {
    const allKeys = fieldProvenances.map(p => p.fieldKey);
    setVerifiedFieldKeys(allKeys);
    setSaveToast('전체 24개 데이터 항목이 검증 완료 처리되었습니다.');
    setTimeout(() => setSaveToast(null), 2500);
  };

  // Re-sync single field with profile raw value
  const handleResyncFieldWithProfile = (fieldKey: string) => {
    if (!profile) return;
    setFormData(prev => {
      const next = { ...prev };
      if (fieldKey === 'businessName' && profile.businessName) next.businessName = profile.businessName;
      if (fieldKey === 'businessRegistrationNumber' && profile.businessRegistrationNumber) next.businessRegistrationNumber = profile.businessRegistrationNumber;
      if (fieldKey === 'ceoName' && profile.name) next.ceoName = profile.name;
      if (fieldKey === 'businessAddress' && profile.businessAddress) next.businessAddress = profile.businessAddress;
      if (fieldKey === 'annualRevenue' && profile.annualRevenue) next.annualRevenue = profile.annualRevenue;
      if (fieldKey === 'employeeCount' && profile.employees) next.employeeCount = profile.employees;
      if (fieldKey === 'requestedAmount' && profile.fundingNeed) next.requestedAmount = profile.fundingNeed;
      return next;
    });
    setSaveToast(`'${fieldKey}' 항목이 프로필 원본 데이터로 재동기화되었습니다.`);
    setTimeout(() => setSaveToast(null), 2500);
  };

  // Re-sync all profile fields with raw profile values
  const handleResyncAllProfileFields = () => {
    if (!profile) return;
    setFormData(prev => {
      const next = { ...prev };
      if (profile.businessName) next.businessName = profile.businessName;
      if (profile.businessRegistrationNumber) next.businessRegistrationNumber = profile.businessRegistrationNumber;
      if (profile.name) next.ceoName = profile.name;
      if (profile.businessAddress) next.businessAddress = profile.businessAddress;
      if (profile.annualRevenue) next.annualRevenue = profile.annualRevenue;
      if (profile.employees) next.employeeCount = profile.employees;
      if (profile.fundingNeed) next.requestedAmount = profile.fundingNeed;
      return next;
    });
    setSaveToast('프로필 연동 7개 기본 필드가 프로필 원본 데이터로 일괄 복원되었습니다.');
    setTimeout(() => setSaveToast(null), 2500);
  };

  // Export/Copy full audit trail report
  const handleCopyDataSourceAuditReport = () => {
    let report = `【 정부 서식 스마트 데이터 소스 및 출처 검증 리포트 】\n`;
    report += `문서 서식: ${currentTemplate.title} (${currentTemplate.formNumber})\n`;
    report += `발급 기관: ${currentTemplate.authority}\n`;
    report += `일시: ${new Date().toLocaleString()} | 대상 기업: ${formData.businessName || '미지정'}\n`;
    report += `전체 필드: 24개 | 검증 완료: ${provenanceStats.verifiedCount}개 (${provenanceStats.verifiedRate}%)\n\n`;
    report += `[데이터 출처 구성 현황]\n`;
    report += `- 🏢 사용자 프로필 연동: ${provenanceStats.profileCount}개 (${Math.round((provenanceStats.profileCount / provenanceStats.total) * 100)}%)\n`;
    report += `- 📐 스마트 재무/소요 모델링: ${provenanceStats.smartCalcCount}개 (${Math.round((provenanceStats.smartCalcCount / provenanceStats.total) * 100)}%)\n`;
    report += `- ✨ Gemini AI 지능형 서술: ${provenanceStats.aiCount}개 (${Math.round((provenanceStats.aiCount / provenanceStats.total) * 100)}%)\n`;
    report += `- 📋 정책/공고 법정 요건: ${provenanceStats.policyCount}개\n`;
    report += `- ✍️ 사용자 직접 수정/입력: ${provenanceStats.manualCount}개\n\n`;
    report += `[세부 항목별 출처 및 검증 로그]\n`;
    fieldProvenances.forEach((p, idx) => {
      report += `${idx + 1}. [${p.tabLabel}] ${p.fieldLabel}\n`;
      report += `   - 분류: ${p.sourceTypeName} (${p.sourceOrigin})\n`;
      report += `   - 추적 경로: ${p.sourceTracePath}\n`;
      report += `   - 반영값: ${p.currentDisplayValue}\n`;
      report += `   - 검증 상태: ${p.verified ? '✅ 검증 완료' : '⚠️ 검토 필요'}\n`;
      if (p.formulaOrLogic) {
        report += `   - 산출/변환 공식: ${p.formulaOrLogic}\n`;
      }
      report += `\n`;
    });

    navigator.clipboard.writeText(report);
    setSaveToast('데이터 소스 검증 감사 리포트가 클립보드에 복사되었습니다.');
    setTimeout(() => setSaveToast(null), 2500);
  };

  // Jump from Data Source view into Editor with highlighting
  const handleJumpToEditorField = (tabKey: 'INFO' | 'FINANCE' | 'NARRATIVE' | 'ITEMS' | 'PLEDGE', fieldKey: string) => {
    setActiveEditorTab(tabKey);
    setViewMode('SPLIT');
    setHighlightedFieldKey(fieldKey);
    setTimeout(() => {
      setHighlightedFieldKey(null);
    }, 3500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 animate-fade-in print:p-0 print:bg-white print:static">
      <div 
        id="government-pdf-draft-modal-container"
        className="bg-white w-full max-w-7xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[94vh] relative text-slate-900 print:max-h-none print:h-auto print:border-none print:shadow-none print:rounded-none"
      >
        {/* Modal Top Header (Hidden when printing) */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white p-4 sm:p-5 relative flex-shrink-0 print:hidden">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white/80 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="닫기"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-500/20 border border-blue-400/30 text-blue-300 text-xs font-black rounded-full">
              <Stamp className="w-3.5 h-3.5" />
              <span>정부 표준 서식 생성 보조기</span>
            </span>
            <span className="bg-indigo-500/20 border border-indigo-400/30 text-indigo-200 text-xs font-bold px-2.5 py-0.5 rounded-full">
              {currentTemplate.authority}
            </span>
            {profile && (
              <button
                type="button"
                onClick={() => setShowAutofillModal(true)}
                className="bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-amber-200 hover:text-amber-100 text-xs font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1 transition-all cursor-pointer"
                title="프로필(업종·매출·창업일자) 기반 스마트 자동완성 설정 열기"
              >
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                <span>프로필: {getIndustryText(profile.industry || 'OTHER')} · {formatWonKorean(profile.annualRevenue || 150000000)} · {profile.foundedYear || 2022}년 창업</span>
              </button>
            )}
            {saveToast && (
              <span className="bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1 animate-fade-in">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {saveToast}
              </span>
            )}
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pr-10">
            <div>
              <h2 className="text-lg sm:text-xl font-black text-white tracking-tight flex items-center gap-2">
                <span>{currentTemplate.title}</span>
                <span className="text-xs bg-white/15 px-2 py-0.5 rounded-md font-bold text-slate-200">
                  {currentTemplate.formNumber}
                </span>
              </h2>
              <p className="text-xs text-slate-300 mt-0.5">
                기업 정보 및 자금 계획을 입력하면 공공기관 심사 기준에 맞춘 공식 규격 초안 PDF를 즉시 생성 및 인쇄할 수 있습니다.
              </p>
            </div>

            {/* Quick Action Buttons in Header */}
            <div className="flex items-center gap-2 flex-shrink-0 flex-wrap">
              {/* Smart Autofill Primary Button */}
              <button
                type="button"
                onClick={() => setShowAutofillModal(true)}
                className="px-3.5 py-2 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black rounded-xl text-xs transition-all shadow-md shadow-amber-900/30 flex items-center gap-1.5 cursor-pointer hover:scale-[1.02] active:scale-[0.98] border border-amber-300/40 ring-2 ring-amber-400/30"
                title="사용자의 프로필 정보(업종, 매출, 창업일자 등)를 기반으로 서식 입력 필드를 스마트 자동완성합니다."
              >
                <Zap className="w-3.5 h-3.5 fill-slate-950 text-slate-950" />
                <span>⚡ 스마트 자동완성</span>
              </button>

              <button
                type="button"
                onClick={handleAiGenerateAll}
                disabled={isGeneratingAi}
                className="px-3.5 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs font-black transition-all shadow-md flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                title="Gemini AI가 업종 및 신청자금에 맞춘 완성도 높은 표준 초안을 일괄 작성합니다."
              >
                <Sparkles className={`w-3.5 h-3.5 ${isGeneratingAi ? 'animate-spin' : ''}`} />
                <span>{isGeneratingAi ? 'AI 초안 작성 중...' : '✨ AI 초안 일괄 생성'}</span>
              </button>

              <button
                type="button"
                onClick={handleCopyFormattedText}
                className="px-3 py-2 bg-white/10 hover:bg-white/20 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                title="한글(HWP) 및 Word 양식에 바로 붙여넣기할 수 있는 구조화 텍스트 복사"
              >
                {copiedText ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedText ? '복사 완료' : 'HWP 텍스트 복사'}</span>
              </button>

              <button
                type="button"
                onClick={handlePrintPdf}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
                title="정부 표준 양식 규격으로 A4 PDF 저장 또는 인쇄"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>표준 PDF 인쇄/저장</span>
              </button>
            </div>
          </div>
        </div>

        {/* Template Selector Bar (Hidden when printing) */}
        <div className="bg-slate-100/80 border-b border-slate-200 px-4 sm:px-6 py-2.5 flex items-center justify-between gap-2 overflow-x-auto scrollbar-none flex-shrink-0 print:hidden">
          <div className="flex items-center gap-1.5 min-w-max">
            {GOVERNMENT_DOC_TEMPLATES.map((tmpl) => {
              const isSelected = selectedDocType === tmpl.id;
              return (
                <button
                  key={tmpl.id}
                  type="button"
                  onClick={() => setSelectedDocType(tmpl.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-white hover:bg-slate-200/80 text-slate-700 border border-slate-200/80'
                  }`}
                >
                  <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                    isSelected ? 'bg-white/20 text-blue-200' : 'bg-slate-100 text-slate-500'
                  }`}>
                    {tmpl.formNumber}
                  </span>
                  <span>{tmpl.shortTitle}</span>
                </button>
              );
            })}
          </div>

          {/* View Mode Toggle for Desktop/Mobile */}
          <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200/80 text-xs font-bold shadow-2xs">
            <button
              type="button"
              onClick={() => setViewMode('SPLIT')}
              className={`hidden sm:inline-flex items-center gap-1 px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                viewMode === 'SPLIT' ? 'bg-indigo-50 text-indigo-700 font-black shadow-2xs' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <span>분할 보기</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('EDITOR_ONLY')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                viewMode === 'EDITOR_ONLY' ? 'bg-indigo-50 text-indigo-700 font-black shadow-2xs' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <span>작성기</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('PREVIEW_ONLY')}
              className={`px-2.5 py-1 rounded-lg transition-all cursor-pointer ${
                viewMode === 'PREVIEW_ONLY' ? 'bg-indigo-50 text-indigo-700 font-black shadow-2xs' : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <span>공식 서식</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode('DATA_SOURCES')}
              className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                viewMode === 'DATA_SOURCES'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-black shadow-xs'
                  : 'text-indigo-700 bg-indigo-50/80 hover:bg-indigo-100 hover:text-indigo-900 border border-indigo-200/60'
              }`}
              title="스마트 자동완성으로 입력된 24개 데이터 항목의 출처(프로필, 스마트모델링, AI, 공고)를 역추적하고 검증합니다."
            >
              <Database className="w-3.5 h-3.5" />
              <span>데이터 소스 검토</span>
              <span className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full ${
                viewMode === 'DATA_SOURCES' ? 'bg-white/25 text-white' : 'bg-indigo-200 text-indigo-900'
              }`}>
                {provenanceStats.verifiedCount}/{provenanceStats.total}
              </span>
            </button>
          </div>
        </div>

        {/* Document Completeness Progress Bar & Audit Header */}
        <div className="bg-slate-900 border-b border-slate-800 px-4 sm:px-6 py-3 flex-shrink-0 text-white print:hidden">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            {/* Left: Overall Completion Progress */}
            <div className="flex-1 min-w-[280px]">
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                    <Gauge className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-xs font-black text-slate-200">
                    서류 작성 완성도
                  </span>
                  <span
                    className={`text-[11px] font-black px-2 py-0.5 rounded-full ${
                      completenessAudit.score === 100
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : completenessAudit.score >= 80
                        ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                        : completenessAudit.score >= 50
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    }`}
                  >
                    {completenessAudit.statusLabel}
                  </span>
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="text-lg font-black font-mono tracking-tight text-white">
                    {completenessAudit.score}%
                  </span>
                  <span className="text-[10px] text-slate-400 font-medium">
                    ({completenessAudit.passedChecks}/{completenessAudit.totalChecks} 항목 통과)
                  </span>
                </div>
              </div>

              {/* Progress Bar with Gradient and Milestone Markers */}
              <div className="relative w-full h-2.5 bg-slate-800 rounded-full overflow-hidden border border-slate-700/80">
                <div
                  className={`h-full transition-all duration-500 rounded-full ${
                    completenessAudit.score === 100
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                      : completenessAudit.score >= 80
                      ? 'bg-gradient-to-r from-blue-600 via-indigo-500 to-emerald-400'
                      : completenessAudit.score >= 50
                      ? 'bg-gradient-to-r from-amber-600 to-amber-400'
                      : 'bg-gradient-to-r from-rose-600 to-rose-400'
                  }`}
                  style={{ width: `${completenessAudit.score}%` }}
                />
              </div>
            </div>

            {/* Right: Section Breakdown Chips & Alert Panel Toggle */}
            <div className="flex flex-wrap items-center gap-1.5 md:justify-end">
              {[
                { id: 'INFO', label: '기업정보', score: completenessAudit.tabScores.INFO.score },
                { id: 'FINANCE', label: '재무/신청', score: completenessAudit.tabScores.FINANCE.score },
                { id: 'NARRATIVE', label: '사업계획', score: completenessAudit.tabScores.NARRATIVE.score },
                { id: 'ITEMS', label: '소요명세', score: completenessAudit.tabScores.ITEMS.score },
                { id: 'PLEDGE', label: '사실서약', score: completenessAudit.tabScores.PLEDGE.score },
              ].map((sec) => (
                <button
                  key={sec.id}
                  type="button"
                  onClick={() => {
                    setActiveEditorTab(sec.id as any);
                    if (viewMode === 'PREVIEW_ONLY') setViewMode('SPLIT');
                  }}
                  className={`px-2 py-1 rounded-lg text-[11px] font-bold border transition-all cursor-pointer flex items-center gap-1 ${
                    sec.score === 100
                      ? 'bg-emerald-950/60 border-emerald-600/50 text-emerald-300'
                      : sec.score >= 50
                      ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                      : 'bg-rose-950/50 border-rose-700/50 text-rose-300'
                  }`}
                >
                  <span>{sec.label}</span>
                  <span className="font-mono text-[10px] opacity-80">{sec.score}%</span>
                  {sec.score === 100 ? (
                    <Check className="w-2.5 h-2.5 text-emerald-400" />
                  ) : (
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                  )}
                </button>
              ))}

              {/* Toggle Missing Items Alert Drawer */}
              {completenessAudit.missingItems.length > 0 ? (
                <button
                  type="button"
                  onClick={() => setIsMissingAlertExpanded(!isMissingAlertExpanded)}
                  className={`px-2.5 py-1 rounded-lg text-[11px] font-black transition-all cursor-pointer flex items-center gap-1 border ${
                    isMissingAlertExpanded
                      ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-xs'
                      : 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
                  }`}
                >
                  <AlertTriangle className="w-3 h-3 text-amber-400" />
                  <span>보완 필요 {completenessAudit.missingItems.length}건</span>
                  {isMissingAlertExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                </button>
              ) : (
                <span className="px-2.5 py-1 rounded-lg text-[11px] font-black bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  <span>완벽 구비 완료</span>
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Modal Main Workspace: Left Editor + Right Official PDF Preview OR Data Sources Audit View */}
        <div className="flex-1 overflow-hidden grid grid-cols-1 lg:grid-cols-12 min-h-0 print:block">
          {viewMode === 'DATA_SOURCES' ? (
            /* DEDICATED DATA SOURCE VERIFICATION VIEW */
            <div className="col-span-12 flex flex-col bg-slate-100/70 overflow-y-auto p-4 sm:p-6 space-y-5 animate-fade-in print:hidden">
              {/* Header Overview Card */}
              <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-5 sm:p-6 text-white shadow-xl border border-indigo-900/40 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none" />
                <div className="relative z-10 space-y-4">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                        <span className="px-2.5 py-0.5 bg-blue-500/20 text-blue-300 rounded-full text-[11px] font-black border border-blue-400/30 flex items-center gap-1">
                          <Database className="w-3 h-3" />
                          <span>데이터 소스 검토 및 출처 역추적 (Data Provenance & Audit)</span>
                        </span>
                        <span className="px-2.5 py-0.5 bg-emerald-500/20 text-emerald-300 rounded-full text-[11px] font-black border border-emerald-400/30">
                          총 24개 서식 항목 100% 추적 완료
                        </span>
                      </div>
                      <h2 className="text-lg sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
                        <span>스마트 자동완성 데이터 출처 검증 센터</span>
                      </h2>
                      <p className="text-xs text-slate-300 max-w-3xl mt-1 leading-relaxed">
                        사용자 프로필(업종·매출·창업일자), 공공기관 정책자금 공고 기준, 스마트 재무 모델링 역산 알고리즘 및 Gemini AI가 생성한 문장의 
                        <strong> 데이터 원천 출처와 가공 히스토리</strong>를 투명하게 확인하고 검증(Audit)할 수 있습니다.
                      </p>
                    </div>

                    {/* Quick Verification Summary & Bulk Buttons */}
                    <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 flex-shrink-0">
                      <button
                        type="button"
                        onClick={handleVerifyAllFields}
                        className="px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black rounded-xl text-xs transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                        title="전체 24개 항목의 출처를 검증 완료 상태로 일괄 승인합니다."
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>전체 항목 일괄 검증</span>
                      </button>

                      {profile && (
                        <button
                          type="button"
                          onClick={handleResyncAllProfileFields}
                          className="px-3.5 py-2.5 bg-white/15 hover:bg-white/25 text-white font-bold rounded-xl text-xs transition-all border border-white/20 flex items-center justify-center gap-1.5 cursor-pointer"
                          title="프로필 연동 7개 기본 항목을 프로필 원본 데이터로 복원합니다."
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>프로필 원본 재동기화</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={handleCopyDataSourceAuditReport}
                        className="px-3.5 py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold rounded-xl text-xs transition-all border border-white/15 flex items-center justify-center gap-1.5 cursor-pointer"
                        title="전체 데이터 출처 및 검증 상태를 텍스트 리포트로 복사합니다."
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>검증 리포트 복사</span>
                      </button>
                    </div>
                  </div>

                  {/* 5 Provenance Source KPIs */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 pt-2 border-t border-slate-800">
                    <div className="bg-white/5 p-2.5 rounded-2xl border border-white/10">
                      <span className="text-[10px] text-slate-400 font-bold block flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                        <span>검증 완료율</span>
                      </span>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span className="text-base sm:text-lg font-black text-emerald-400 font-mono">
                          {provenanceStats.verifiedRate}%
                        </span>
                        <span className="text-[10px] text-slate-400 font-medium">
                          ({provenanceStats.verifiedCount}/{provenanceStats.total})
                        </span>
                      </div>
                    </div>

                    <div className="bg-white/5 p-2.5 rounded-2xl border border-white/10">
                      <span className="text-[10px] text-blue-300 font-bold block flex items-center gap-1">
                        <Building2 className="w-3 h-3 text-blue-400" />
                        <span>🏢 프로필 연동</span>
                      </span>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span className="text-base sm:text-lg font-black text-white font-mono">
                          {provenanceStats.profileCount}개
                        </span>
                        <span className="text-[10px] text-blue-300/80 font-medium">
                          ({Math.round((provenanceStats.profileCount / provenanceStats.total) * 100)}%)
                        </span>
                      </div>
                    </div>

                    <div className="bg-white/5 p-2.5 rounded-2xl border border-white/10">
                      <span className="text-[10px] text-teal-300 font-bold block flex items-center gap-1">
                        <Sliders className="w-3 h-3 text-teal-400" />
                        <span>📐 스마트 모델링</span>
                      </span>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span className="text-base sm:text-lg font-black text-white font-mono">
                          {provenanceStats.smartCalcCount}개
                        </span>
                        <span className="text-[10px] text-teal-300/80 font-medium">
                          ({Math.round((provenanceStats.smartCalcCount / provenanceStats.total) * 100)}%)
                        </span>
                      </div>
                    </div>

                    <div className="bg-white/5 p-2.5 rounded-2xl border border-white/10">
                      <span className="text-[10px] text-purple-300 font-bold block flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-purple-400" />
                        <span>✨ AI 지능형 서술</span>
                      </span>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span className="text-base sm:text-lg font-black text-white font-mono">
                          {provenanceStats.aiCount}개
                        </span>
                        <span className="text-[10px] text-purple-300/80 font-medium">
                          ({Math.round((provenanceStats.aiCount / provenanceStats.total) * 100)}%)
                        </span>
                      </div>
                    </div>

                    <div className="bg-white/5 p-2.5 rounded-2xl border border-white/10">
                      <span className="text-[10px] text-slate-300 font-bold block flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-slate-400" />
                        <span>📋 공고/법정 서약</span>
                      </span>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span className="text-base sm:text-lg font-black text-white font-mono">
                          {provenanceStats.policyCount}개
                        </span>
                        <span className="text-[10px] text-slate-400 font-medium">
                          ({Math.round((provenanceStats.policyCount / provenanceStats.total) * 100)}%)
                        </span>
                      </div>
                    </div>

                    <div className="bg-white/5 p-2.5 rounded-2xl border border-white/10">
                      <span className="text-[10px] text-amber-300 font-bold block flex items-center gap-1">
                        <Edit3 className="w-3 h-3 text-amber-400" />
                        <span>✍️ 직접 수정</span>
                      </span>
                      <div className="flex items-baseline gap-1 mt-0.5">
                        <span className="text-base sm:text-lg font-black text-amber-300 font-mono">
                          {provenanceStats.manualCount}개
                        </span>
                        <span className="text-[10px] text-amber-300/80 font-medium">
                          {provenanceStats.manualCount > 0 ? '커스텀' : '0%'}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Data Provenance Pipeline Visual Diagram */}
              <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                    <History className="w-4 h-4 text-indigo-600" />
                    <span>데이터 소스 변환 및 서식 기입 파이프라인 (Data Lineage Stream)</span>
                  </span>
                  <span className="text-[11px] text-slate-500">
                    프로필 및 알고리즘 ➔ 행정 서식 필드 매핑 구조
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
                  {/* Stream 1 */}
                  <div className="p-3 bg-blue-50/70 rounded-xl border border-blue-200/80 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-black text-blue-950 flex items-center gap-1">
                        <Building2 className="w-3.5 h-3.5 text-blue-600" />
                        <span>1. 프로필 기본 정보</span>
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 bg-blue-200 text-blue-900 rounded-md font-bold">8개 필드</span>
                    </div>
                    <p className="text-[11px] text-blue-900/90 leading-tight">
                      상호, 사업자번호, 대표자명, 개업일, 매출액, 종업원수, 부채 현황
                    </p>
                    <div className="text-[10px] text-blue-700 bg-white/70 p-1.5 rounded-md font-mono">
                      ↳ 홈택스/회원 DB ➔ 1:1 직결 반영
                    </div>
                  </div>

                  {/* Stream 2 */}
                  <div className="p-3 bg-teal-50/70 rounded-xl border border-teal-200/80 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-black text-teal-950 flex items-center gap-1">
                        <Sliders className="w-3.5 h-3.5 text-teal-600" />
                        <span>2. 스마트 모델링</span>
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 bg-teal-200 text-teal-900 rounded-md font-bold">8개 필드</span>
                    </div>
                    <p className="text-[11px] text-teal-900/90 leading-tight">
                      3개년 매출 역산(85%·70%), 소요명세표(45:35:20) 균형 일치
                    </p>
                    <div className="text-[10px] text-teal-700 bg-white/70 p-1.5 rounded-md font-mono">
                      ↳ 회귀 추정 공식 ➔ 단 1원 오차 0
                    </div>
                  </div>

                  {/* Stream 3 */}
                  <div className="p-3 bg-purple-50/70 rounded-xl border border-purple-200/80 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-black text-purple-950 flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                        <span>3. Gemini AI 서술</span>
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 bg-purple-200 text-purple-900 rounded-md font-bold">4개 필드</span>
                    </div>
                    <p className="text-[11px] text-purple-900/90 leading-tight">
                      업종 특화 사업개요, 기술 경쟁력, 자금필요성 및 상환계획
                    </p>
                    <div className="text-[10px] text-purple-700 bg-white/70 p-1.5 rounded-md font-mono">
                      ↳ 정책자금 심사관 친화 서술
                    </div>
                  </div>

                  {/* Stream 4 */}
                  <div className="p-3 bg-slate-100 rounded-xl border border-slate-300 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <span className="font-black text-slate-950 flex items-center gap-1">
                        <FileCheck className="w-3.5 h-3.5 text-slate-700" />
                        <span>4. 정부 공식 서식 매핑</span>
                      </span>
                      <span className="text-[10px] px-1.5 py-0.2 bg-slate-300 text-slate-900 rounded-md font-bold">A4 PDF 규격</span>
                    </div>
                    <p className="text-[11px] text-slate-700 leading-tight">
                      중기부·신보·소진공 2026년 표준 양식 준수
                    </p>
                    <div className="text-[10px] text-slate-800 bg-white p-1.5 rounded-md font-mono font-bold">
                      ↳ 원본대조필 규격 PDF 즉시 인쇄
                    </div>
                  </div>
                </div>
              </div>

              {/* Filter Controls & Search Bar */}
              <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs space-y-3">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  {/* Real-time Search Input */}
                  <div className="relative flex-1 max-w-md">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={dataSourceSearchQuery}
                      onChange={(e) => setDataSourceSearchQuery(e.target.value)}
                      placeholder="항목명, 원천 출처, 변환 규칙, 반영값 실시간 검색..."
                      className="w-full pl-9 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:bg-white focus:ring-2 focus:ring-blue-500 transition-all"
                    />
                    {dataSourceSearchQuery && (
                      <button
                        type="button"
                        onClick={() => setDataSourceSearchQuery('')}
                        className="w-5 h-5 rounded-full bg-slate-200 hover:bg-slate-300 text-slate-600 flex items-center justify-center absolute right-2.5 top-1/2 -translate-y-1/2 text-xs"
                      >
                        ✕
                      </button>
                    )}
                  </div>

                  {/* Verification Status Filter */}
                  <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs font-bold">
                    <button
                      type="button"
                      onClick={() => setDataSourceVerificationFilter('ALL')}
                      className={`px-3 py-1 rounded-lg transition-all cursor-pointer ${
                        dataSourceVerificationFilter === 'ALL'
                          ? 'bg-white text-slate-900 shadow-2xs'
                          : 'text-slate-500 hover:text-slate-900'
                      }`}
                    >
                      전체 ({provenanceStats.total})
                    </button>
                    <button
                      type="button"
                      onClick={() => setDataSourceVerificationFilter('VERIFIED')}
                      className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                        dataSourceVerificationFilter === 'VERIFIED'
                          ? 'bg-emerald-600 text-white shadow-2xs'
                          : 'text-emerald-700 hover:bg-emerald-50'
                      }`}
                    >
                      <CheckCircle2 className="w-3 h-3" />
                      <span>검증 완료 ({provenanceStats.verifiedCount})</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setDataSourceVerificationFilter('NEEDS_REVIEW')}
                      className={`px-3 py-1 rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                        dataSourceVerificationFilter === 'NEEDS_REVIEW'
                          ? 'bg-amber-600 text-white shadow-2xs'
                          : 'text-amber-700 hover:bg-amber-50'
                      }`}
                    >
                      <AlertTriangle className="w-3 h-3" />
                      <span>검토 필요 ({provenanceStats.total - provenanceStats.verifiedCount})</span>
                    </button>
                  </div>
                </div>

                {/* Source Type Filter Tabs */}
                <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pt-1">
                  {[
                    { id: 'ALL', label: `전체 출처 (${provenanceStats.total})` },
                    { id: 'PROFILE', label: `🏢 프로필 연동 (${provenanceStats.profileCount})` },
                    { id: 'SMART_CALC', label: `📐 스마트 모델링 (${provenanceStats.smartCalcCount})` },
                    { id: 'AI_GENERATED', label: `✨ AI 지능형 서술 (${provenanceStats.aiCount})` },
                    { id: 'FUND_POLICY', label: `📋 공고/규정 (${provenanceStats.policyCount})` },
                    { id: 'MANUAL_INPUT', label: `✍️ 직접 입력 (${provenanceStats.manualCount})` },
                  ].map((srcTab) => (
                    <button
                      key={srcTab.id}
                      type="button"
                      onClick={() => setDataSourceFilter(srcTab.id as any)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                        dataSourceFilter === srcTab.id
                          ? 'bg-slate-900 text-white shadow-xs'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-slate-200/80'
                      }`}
                    >
                      {srcTab.label}
                    </button>
                  ))}
                </div>

                {/* Form Section Filter Tabs */}
                <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pt-1 border-t border-slate-100">
                  <span className="text-[11px] font-bold text-slate-400 pl-1 whitespace-nowrap">서식 분류:</span>
                  {[
                    { id: 'ALL', label: '전체 서식' },
                    { id: 'INFO', label: '1. 기업 기본정보' },
                    { id: 'FINANCE', label: '2. 재무/자금신청' },
                    { id: 'NARRATIVE', label: '3. 사업 및 상환계획' },
                    { id: 'ITEMS', label: '4. 소요명세표' },
                    { id: 'PLEDGE', label: '5. 사실확인 및 서약' },
                  ].map((sectionTab) => (
                    <button
                      key={sectionTab.id}
                      type="button"
                      onClick={() => setDataSourceTabFilter(sectionTab.id as any)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer whitespace-nowrap ${
                        dataSourceTabFilter === sectionTab.id
                          ? 'bg-blue-600 text-white shadow-2xs'
                          : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
                      }`}
                    >
                      {sectionTab.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Data Provenance Items Grid */}
              <div className="space-y-3">
                <div className="flex items-center justify-between px-1">
                  <span className="text-xs font-black text-slate-900">
                    검색 및 필터링된 데이터 항목 ({filteredProvenances.length}건)
                  </span>
                  <span className="text-[11px] text-slate-500">
                    각 항목 우측의 <strong>[검증]</strong> 버튼을 눌러 정확성을 확인할 수 있습니다.
                  </span>
                </div>

                {filteredProvenances.length === 0 ? (
                  <div className="bg-white rounded-2xl p-10 text-center border border-slate-200 space-y-2">
                    <Database className="w-10 h-10 text-slate-300 mx-auto" />
                    <h3 className="font-black text-slate-800 text-sm">해당 조건과 일치하는 데이터 항목이 없습니다.</h3>
                    <p className="text-xs text-slate-500">검색어 또는 필터 조건을 변경하여 다시 시도해 주세요.</p>
                    <button
                      type="button"
                      onClick={() => {
                        setDataSourceFilter('ALL');
                        setDataSourceTabFilter('ALL');
                        setDataSourceVerificationFilter('ALL');
                        setDataSourceSearchQuery('');
                      }}
                      className="mt-2 px-3 py-1.5 bg-blue-600 text-white rounded-xl text-xs font-bold cursor-pointer"
                    >
                      필터 전체 초기화
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    {filteredProvenances.map((item) => (
                      <div
                        key={item.fieldKey}
                        className={`bg-white rounded-2xl p-4 border transition-all shadow-2xs hover:shadow-md space-y-3 ${
                          item.verified
                            ? 'border-slate-200 hover:border-blue-300'
                            : 'border-amber-200 bg-amber-50/20'
                        }`}
                      >
                        {/* Card Header */}
                        <div className="flex items-start justify-between gap-2">
                          <div className="space-y-1">
                            <div className="flex items-center gap-1.5 flex-wrap">
                              {/* Source Type Badge */}
                              <span
                                className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${
                                  item.sourceType === 'PROFILE'
                                    ? 'bg-blue-100 text-blue-800 border-blue-300'
                                    : item.sourceType === 'SMART_CALC'
                                    ? 'bg-teal-100 text-teal-800 border-teal-300'
                                    : item.sourceType === 'AI_GENERATED'
                                    ? 'bg-purple-100 text-purple-800 border-purple-300'
                                    : item.sourceType === 'FUND_POLICY'
                                    ? 'bg-slate-100 text-slate-800 border-slate-300'
                                    : 'bg-amber-100 text-amber-900 border-amber-300'
                                }`}
                              >
                                {item.sourceTypeName}
                              </span>

                              {/* Form Tab Section */}
                              <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                                {item.tabLabel}
                              </span>

                              {/* Reliability / Confidence */}
                              <span
                                className={`text-[10px] font-mono font-bold px-1.5 py-0.2 rounded-md ${
                                  item.reliabilityLevel === 'HIGH'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : item.reliabilityLevel === 'ESTIMATED'
                                    ? 'bg-blue-100 text-blue-800'
                                    : 'bg-amber-100 text-amber-800'
                                }`}
                              >
                                신뢰도 {item.confidenceScore}%
                              </span>
                            </div>

                            <h4 className="font-black text-slate-950 text-sm flex items-center gap-1.5">
                              <span>{item.fieldLabel}</span>
                            </h4>
                          </div>

                          {/* Verification Toggle Action */}
                          <button
                            type="button"
                            onClick={() => handleToggleVerifyField(item.fieldKey)}
                            className={`px-2.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1 cursor-pointer flex-shrink-0 ${
                              item.verified
                                ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200 border border-emerald-300'
                                : 'bg-slate-100 text-slate-600 hover:bg-emerald-600 hover:text-white border border-slate-200'
                            }`}
                            title={item.verified ? '클릭 시 검토 필요 상태로 변경' : '클릭 시 검증 완료 상태로 승인'}
                          >
                            <CheckCircle2 className={`w-3.5 h-3.5 ${item.verified ? 'text-emerald-600' : ''}`} />
                            <span>{item.verified ? '검증 완료' : '검토 승인'}</span>
                          </button>
                        </div>

                        {/* Origin and Trace Path */}
                        <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200/80 text-xs space-y-1">
                          <div className="flex items-center gap-1.5 text-slate-600 text-[11px]">
                            <span className="font-bold text-slate-900 flex-shrink-0">데이터 원천:</span>
                            <span className="font-semibold text-blue-700 bg-blue-50 px-1.5 py-0.2 rounded">
                              {item.sourceOrigin}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-600">
                            <span className="font-bold text-slate-900">추적 경로: </span>
                            <span>{item.sourceTracePath}</span>
                          </div>
                        </div>

                        {/* Comparison Box: Raw Source vs Current Form Value */}
                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div className="p-2 bg-slate-50 rounded-xl border border-slate-200/80">
                            <span className="text-[10px] text-slate-400 font-bold block mb-0.5">
                              원천 수집값 (Raw Origin)
                            </span>
                            <span className="font-bold text-slate-700 line-clamp-2 text-[11px]">
                              {item.rawSourceValue || '자동 모델링 / 연동'}
                            </span>
                          </div>

                          <div className={`p-2 rounded-xl border ${
                            item.isCustomized
                              ? 'bg-amber-50/70 border-amber-200 text-amber-950'
                              : 'bg-blue-50/50 border-blue-200/70 text-slate-900'
                          }`}>
                            <div className="flex items-center justify-between mb-0.5">
                              <span className="text-[10px] font-bold text-blue-900 block">
                                서식 반영값 (Applied)
                              </span>
                              {item.isCustomized && (
                                <span className="text-[9px] font-bold px-1 py-0.2 bg-amber-200 text-amber-900 rounded">
                                  직접수정됨
                                </span>
                              )}
                            </div>
                            <span className="font-black text-[11px] text-blue-950 line-clamp-2">
                              {item.currentDisplayValue}
                            </span>
                          </div>
                        </div>

                        {/* Transformation / Business Formula logic */}
                        {item.formulaOrLogic && (
                          <div className="p-2 bg-teal-50/60 rounded-xl border border-teal-200/70 text-[11px] text-teal-900 space-y-0.5">
                            <span className="font-bold block flex items-center gap-1 text-teal-950">
                              <Sliders className="w-3 h-3 text-teal-700" />
                              <span>산출 근거 및 변환 알고리즘</span>
                            </span>
                            <p className="leading-snug">{item.formulaOrLogic}</p>
                          </div>
                        )}

                        {/* Card Footer Actions */}
                        <div className="flex items-center justify-between gap-2 pt-1 border-t border-slate-100">
                          {item.isCustomized && item.sourceType === 'PROFILE' ? (
                            <button
                              type="button"
                              onClick={() => handleResyncFieldWithProfile(item.fieldKey)}
                              className="text-[11px] text-amber-700 hover:text-amber-900 font-bold flex items-center gap-1 cursor-pointer"
                              title="사용자가 직접 수정한 값을 프로필 원본 데이터로 되돌립니다."
                            >
                              <RefreshCw className="w-3 h-3" />
                              <span>프로필 원본으로 복원</span>
                            </button>
                          ) : (
                            <span className="text-[10px] text-slate-400 font-medium">
                              최종 동기화 완료
                            </span>
                          )}

                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => setSelectedProvenanceDetail(item)}
                              className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                              title="데이터 수집부터 서식 반영까지의 3단계 파이프라인 그래프를 상세 확인합니다."
                            >
                              <Search className="w-3 h-3" />
                              <span>세부 추적 파이프라인</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => handleJumpToEditorField(item.tabKey, item.fieldKey)}
                              className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-600 text-blue-700 hover:text-white rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                              title="서식 작성기 탭으로 즉시 이동하여 해당 항목을 수정합니다."
                            >
                              <Edit3 className="w-3 h-3" />
                              <span>작성기에서 수정</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          ) : (
            <>
              {/* LEFT: Interactive Form Editor Panel */}
              <div
                className={`${
                  viewMode === 'PREVIEW_ONLY' ? 'hidden' : viewMode === 'SPLIT' ? 'lg:col-span-6' : 'lg:col-span-12'
                } flex flex-col border-r border-slate-200/80 bg-slate-50/50 overflow-y-auto print:hidden`}
              >
            {/* Editor Sub Tabs */}
            <div className="px-4 sm:px-6 pt-3 pb-2 bg-white border-b border-slate-200/70 flex items-center gap-1.5 overflow-x-auto scrollbar-none flex-shrink-0">
              {[
                { id: 'INFO', label: '1. 기본 및 기업정보', score: completenessAudit.tabScores.INFO.score },
                { id: 'FINANCE', label: '2. 재무 및 자금신청', score: completenessAudit.tabScores.FINANCE.score },
                { id: 'NARRATIVE', label: '3. 사업 및 상환계획 (AI)', score: completenessAudit.tabScores.NARRATIVE.score },
                { id: 'ITEMS', label: `4. 소요명세표 (${formData.fundUsageItems.length})`, score: completenessAudit.tabScores.ITEMS.score },
                { id: 'PLEDGE', label: '5. 사실확인 및 서명', score: completenessAudit.tabScores.PLEDGE.score },
              ].map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveEditorTab(tab.id as any)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1.5 ${
                    activeEditorTab === tab.id
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 hover:bg-slate-100 bg-slate-50 border border-slate-200/60'
                  }`}
                >
                  <span>{tab.label}</span>
                  <span
                    className={`text-[10px] font-mono px-1.5 py-0.2 rounded-md ${
                      activeEditorTab === tab.id
                        ? 'bg-white/20 text-white'
                        : tab.score === 100
                        ? 'bg-emerald-100 text-emerald-800'
                        : tab.score >= 50
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {tab.score}%
                  </span>
                </button>
              ))}
            </div>

            {/* Editor Form Content Area */}
            <div className="p-4 sm:p-6 space-y-5 overflow-y-auto flex-1">
              {/* Dynamic Missing Items Alert Area (보완 제안 알림 영역) */}
              {completenessAudit.missingItems.length > 0 && isMissingAlertExpanded ? (
                <div className="bg-gradient-to-br from-amber-50/90 to-orange-50/80 border border-amber-200/90 rounded-2xl p-4 shadow-xs space-y-3 animate-fade-in">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-amber-200/60 pb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center flex-shrink-0 shadow-xs">
                        <AlertTriangle className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-black text-amber-950 text-xs sm:text-sm">
                            심사 통과를 위한 입력 누락 및 보완 권장 사항 ({completenessAudit.missingItems.length}건)
                          </h3>
                          <span className="px-2 py-0.5 bg-amber-200/80 text-amber-900 font-bold text-[10px] rounded-full">
                            완성도 {completenessAudit.score}%
                          </span>
                        </div>
                        <p className="text-[11px] text-amber-800/90 mt-0.5">
                          공공기관 심사관 검토 시 감점을 방지하기 위해 아래 항목을 확인하고 보완해주세요.
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 flex-shrink-0 flex-wrap">
                      <button
                        type="button"
                        onClick={() => handleApplySmartAutofill('ALL')}
                        className="px-2.5 py-1.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs rounded-xl transition-all shadow-xs flex items-center gap-1 cursor-pointer border border-amber-300/60"
                        title="사용자 프로필(업종·매출·창업일자)을 기반으로 누락된 서식 필드를 즉시 스마트 자동완성합니다."
                      >
                        <Zap className="w-3.5 h-3.5 fill-slate-950 text-slate-950" />
                        <span>⚡ 프로필 스마트 자동완성</span>
                      </button>

                      <button
                        type="button"
                        onClick={handleAiGenerateAll}
                        disabled={isGeneratingAi}
                        className="px-2.5 py-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black text-xs rounded-xl transition-all shadow-xs flex items-center gap-1 cursor-pointer disabled:opacity-50"
                        title="AI가 누락된 사업계획 및 필수 문항을 자동으로 채워줍니다."
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>AI로 누락 일괄 보완</span>
                      </button>
                    </div>
                  </div>

                  {/* Filter Severity Pills */}
                  <div className="flex items-center justify-between gap-2 pt-0.5">
                    <div className="flex items-center gap-1 text-[11px]">
                      <button
                        type="button"
                        onClick={() => setSelectedSeverityFilter('ALL')}
                        className={`px-2 py-0.5 rounded-lg font-bold transition-all cursor-pointer ${
                          selectedSeverityFilter === 'ALL'
                            ? 'bg-amber-600 text-white'
                            : 'bg-white/80 text-amber-900 hover:bg-white border border-amber-200/80'
                        }`}
                      >
                        전체 ({completenessAudit.missingItems.length})
                      </button>
                      <button
                        type="button"
                        onClick={() => setSelectedSeverityFilter('CRITICAL')}
                        className={`px-2 py-0.5 rounded-lg font-bold transition-all cursor-pointer ${
                          selectedSeverityFilter === 'CRITICAL'
                            ? 'bg-rose-600 text-white'
                            : 'bg-white/80 text-rose-800 hover:bg-white border border-rose-200'
                        }`}
                      >
                        🚨 필수 누락 ({completenessAudit.missingItems.filter((i) => i.severity === 'CRITICAL').length})
                      </button>
                      <button
                        type="button"
                        onClick={() => setSelectedSeverityFilter('WARNING')}
                        className={`px-2 py-0.5 rounded-lg font-bold transition-all cursor-pointer ${
                          selectedSeverityFilter === 'WARNING'
                            ? 'bg-amber-700 text-white'
                            : 'bg-white/80 text-amber-800 hover:bg-white border border-amber-200'
                        }`}
                      >
                        ⚡ 심사 권장 ({completenessAudit.missingItems.filter((i) => i.severity !== 'CRITICAL').length})
                      </button>
                    </div>
                    <span className="text-[10px] text-amber-700/80 hidden sm:inline">
                      클릭 시 해당 입력 탭으로 즉시 이동합니다.
                    </span>
                  </div>

                  {/* Missing Items List */}
                  <div className="grid grid-cols-1 gap-2 max-h-60 overflow-y-auto pr-1">
                    {filteredMissingItems.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => handleJumpToMissingItem(item)}
                        className="bg-white/95 hover:bg-white border border-amber-200/90 hover:border-blue-300 rounded-xl p-2.5 transition-all shadow-2xs hover:shadow-xs cursor-pointer flex items-start justify-between gap-3 group"
                      >
                        <div className="space-y-1 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span
                              className={`text-[10px] font-black px-1.5 py-0.5 rounded-md ${
                                item.severity === 'CRITICAL'
                                  ? 'bg-rose-100 text-rose-800 border border-rose-200'
                                  : item.severity === 'WARNING'
                                  ? 'bg-amber-100 text-amber-800 border border-amber-200'
                                  : 'bg-blue-100 text-blue-800 border border-blue-200'
                              }`}
                            >
                              {item.severity === 'CRITICAL' ? '🚨 필수 누락' : item.severity === 'WARNING' ? '⚡ 심사 감점 주의' : '💡 권장 보완'}
                            </span>
                            <span className="text-[11px] font-bold text-slate-500">[{item.tabName}]</span>
                            <span className="text-xs font-black text-slate-900 group-hover:text-blue-700 transition-colors">
                              {item.fieldLabel}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-700 leading-snug font-medium">
                            {item.message}
                          </p>
                          <p className="text-[10px] text-indigo-700 bg-indigo-50/70 px-2 py-1 rounded-lg font-medium border border-indigo-100/80">
                            💡 <strong>보완 가이드:</strong> {item.suggestion}
                          </p>
                        </div>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleJumpToMissingItem(item);
                          }}
                          className="px-2.5 py-1.5 bg-slate-100 group-hover:bg-blue-600 text-slate-600 group-hover:text-white rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 flex-shrink-0 cursor-pointer shadow-2xs"
                        >
                          <span>수정하기</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              ) : completenessAudit.score === 100 ? (
                <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-4 shadow-xs flex items-start gap-3 animate-fade-in">
                  <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center flex-shrink-0 shadow-xs">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <h3 className="font-black text-emerald-950 text-xs sm:text-sm">
                        서류 작성 완성도 100% 달성! (심사 준비 완벽)
                      </h3>
                      <span className="px-2 py-0.5 bg-emerald-200 text-emerald-900 font-bold text-[10px] rounded-full">
                        검증 완료
                      </span>
                    </div>
                    <p className="text-[11px] text-emerald-800 leading-relaxed">
                      모든 필수 기업정보, 재무/신청 내역, 6대 사업계획 서술, 소요명세표 및 법정 서약이 완벽하게 구비되었습니다. 우측 상단의 <strong>[PDF 인쇄]</strong>를 눌러 공공기관 제출용 서식을 즉시 출력하거나 <strong>[서식 텍스트 복사]</strong>를 이용하세요.
                    </p>
                  </div>
                </div>
              ) : null}
              {/* TAB 1: General Info */}
              {activeEditorTab === 'INFO' && (
                <div className="space-y-4 animate-fade-in text-xs">
                  {/* Smart Autofill Banner for Tab 1 */}
                  {profile && (
                    <div className="bg-gradient-to-r from-blue-50 via-indigo-50 to-amber-50 p-3 rounded-2xl border border-blue-200/80 flex items-center justify-between gap-3 shadow-xs">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-xl bg-blue-600 text-white flex items-center justify-center flex-shrink-0 shadow-xs">
                          <Zap className="w-3.5 h-3.5 fill-white" />
                        </div>
                        <div>
                          <span className="font-black text-blue-950 block text-xs">
                            프로필 기본정보 스마트 연동
                          </span>
                          <span className="text-[11px] text-slate-600">
                            업종: <strong>{getIndustryText(profile.industry || 'OTHER')}</strong> · 개업: <strong>{profile.foundedYear || 2022}년</strong> · 대표: <strong>{profile.name || '홍길동'}</strong>
                          </span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleApplySmartAutofill('INFO')}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl transition-all shadow-xs flex items-center gap-1 cursor-pointer flex-shrink-0"
                      >
                        <Zap className="w-3 h-3" />
                        <span>기본정보 자동채우기</span>
                      </button>
                    </div>
                  )}

                  <div className="bg-blue-50/70 p-3.5 rounded-2xl border border-blue-100 flex items-start gap-2.5">
                    <Building2 className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="font-black text-blue-950 block">기업 기본 정보 및 접수 기관 설정</span>
                      <p className="text-slate-600 text-[11px] mt-0.5">
                        사업자등록증 상의 정보와 일치하도록 작성해 주세요. 프로필 정보로 자동 입력되어 있습니다.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-bold text-slate-700 block">상호(법인명)</label>
                        {profile?.businessName && formData.businessName !== profile.businessName && (
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, businessName: profile.businessName })}
                            className="text-[10px] text-blue-600 font-bold hover:underline flex items-center gap-0.5"
                          >
                            <Zap className="w-2.5 h-2.5" /> 프로필 상호 적용
                          </button>
                        )}
                      </div>
                      <input
                        type="text"
                        value={formData.businessName}
                        onChange={(e) => setFormData({ ...formData, businessName: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-xs font-bold"
                      />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-bold text-slate-700 block">사업자등록번호</label>
                        {profile?.businessRegistrationNumber && formData.businessRegistrationNumber !== profile.businessRegistrationNumber && (
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, businessRegistrationNumber: profile.businessRegistrationNumber })}
                            className="text-[10px] text-blue-600 font-bold hover:underline flex items-center gap-0.5"
                          >
                            <Zap className="w-2.5 h-2.5" /> 프로필 번호 적용
                          </button>
                        )}
                      </div>
                      <input
                        type="text"
                        value={formData.businessRegistrationNumber}
                        onChange={(e) => setFormData({ ...formData, businessRegistrationNumber: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-xs font-mono"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-bold text-slate-700 block">대표자 성명</label>
                        {profile?.name && formData.ceoName !== profile.name && (
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, ceoName: profile.name, representativeSignatureName: profile.name })}
                            className="text-[10px] text-blue-600 font-bold hover:underline flex items-center gap-0.5"
                          >
                            <Zap className="w-2.5 h-2.5" /> 프로필 대표자 적용
                          </button>
                        )}
                      </div>
                      <input
                        type="text"
                        value={formData.ceoName}
                        onChange={(e) => setFormData({ ...formData, ceoName: e.target.value, representativeSignatureName: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-xs font-bold"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">생년월일 (YYYY.MM.DD)</label>
                      <input
                        type="text"
                        value={formData.birthDate || ''}
                        onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-xs"
                        placeholder="1985.05.15"
                      />
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-bold text-slate-700 block">개업연월일</label>
                        {profile?.foundedYear && (
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, foundedDate: `${profile.foundedYear}.03.15` })}
                            className="text-[10px] text-blue-600 font-bold hover:underline flex items-center gap-0.5"
                          >
                            <Zap className="w-2.5 h-2.5" /> 프로필 창업일({profile.foundedYear}년)
                          </button>
                        )}
                      </div>
                      <input
                        type="text"
                        value={formData.foundedDate}
                        onChange={(e) => setFormData({ ...formData, foundedDate: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-xs font-mono font-bold"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">기업 형태</label>
                      <select
                        value={formData.businessType}
                        onChange={(e) => setFormData({ ...formData, businessType: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-xs font-bold"
                      >
                        <option value="개인사업자">개인사업자</option>
                        <option value="법인사업자">법인사업자</option>
                        <option value="예비창업자">예비창업자</option>
                      </select>
                    </div>
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="font-bold text-slate-700 block">주요 업종 및 종목</label>
                        {profile?.industry && (
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, industryCategory: getIndustryText(profile.industry!) })}
                            className="text-[10px] text-blue-600 font-bold hover:underline flex items-center gap-0.5"
                          >
                            <Zap className="w-2.5 h-2.5" /> 프로필 업종 적용
                          </button>
                        )}
                      </div>
                      <input
                        type="text"
                        value={formData.industryCategory}
                        onChange={(e) => setFormData({ ...formData, industryCategory: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="font-bold text-slate-700 block mb-1">주요 취급 제품 및 서비스</label>
                    <input
                      type="text"
                      value={formData.mainProduct}
                      onChange={(e) => setFormData({ ...formData, mainProduct: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-xs"
                    />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-bold text-slate-700 block">사업장 소재지 (본점 주소)</label>
                      {profile?.businessAddress && formData.businessAddress !== profile.businessAddress && (
                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, businessAddress: profile.businessAddress })}
                          className="text-[10px] text-blue-600 font-bold hover:underline flex items-center gap-0.5"
                        >
                          <Zap className="w-2.5 h-2.5" /> 프로필 주소 적용
                        </button>
                      )}
                    </div>
                    <input
                      type="text"
                      value={formData.businessAddress}
                      onChange={(e) => setFormData({ ...formData, businessAddress: e.target.value })}
                      className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-xs"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">대표 연락처</label>
                      <input
                        type="text"
                        value={formData.contactPhone}
                        onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">이메일 주소</label>
                      <input
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-slate-700 block mb-1">제출 접수기관</label>
                      <input
                        type="text"
                        value={formData.targetAgency}
                        onChange={(e) => setFormData({ ...formData, targetAgency: e.target.value })}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-indigo-700"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: Finance & Loan Request */}
              {activeEditorTab === 'FINANCE' && (
                <div className="space-y-4 animate-fade-in text-xs">
                  {/* Smart Autofill Banner for Tab 2 */}
                  {profile && (
                    <div className="bg-gradient-to-r from-indigo-50 via-purple-50 to-emerald-50 p-3 rounded-2xl border border-indigo-200/80 flex items-center justify-between gap-3 shadow-xs">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-xl bg-indigo-600 text-white flex items-center justify-center flex-shrink-0 shadow-xs">
                          <Coins className="w-3.5 h-3.5 fill-white" />
                        </div>
                        <div>
                          <span className="font-black text-indigo-950 block text-xs">
                            프로필 재무·자금 스마트 연동
                          </span>
                          <span className="text-[11px] text-slate-600">
                            연매출: <strong>{formatWonKorean(profile.annualRevenue || 150000000)}</strong> · 직원: <strong>{profile.employees || 2}명</strong> · 신청희망액: <strong>{formatWonKorean(profile.fundingNeed || 50000000)}</strong>
                          </span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleApplySmartAutofill('FINANCE')}
                        className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs rounded-xl transition-all shadow-xs flex items-center gap-1 cursor-pointer flex-shrink-0"
                      >
                        <Zap className="w-3 h-3" />
                        <span>재무·신청금액 자동채우기</span>
                      </button>
                    </div>
                  )}

                  <div className="bg-indigo-50/70 p-3.5 rounded-2xl border border-indigo-100 flex items-start gap-2.5">
                    <Layers className="w-4 h-4 text-indigo-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="font-black text-indigo-950 block">재무 현황 및 정책자금 신청 조건</span>
                      <p className="text-slate-600 text-[11px] mt-0.5">
                        최근 3개년 매출 추이와 대출 희망 금액, 자금 구분(운전/시설)을 기입하세요.
                      </p>
                    </div>
                  </div>

                  <div className="p-4 bg-white rounded-2xl border border-slate-200 space-y-3">
                    <span className="font-black text-slate-900 block text-xs">최근 3개년 매출 실적 및 고용 현황</span>
                    
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="font-bold text-slate-600 block">당해연도(최근) 매출액(원)</label>
                          {profile?.annualRevenue && (
                            <button
                              type="button"
                              onClick={() => {
                                const rev = profile.annualRevenue!;
                                setFormData({
                                  ...formData,
                                  annualRevenue: rev,
                                  prevYearRevenue: Math.round(rev * 0.85),
                                  twoYearsAgoRevenue: Math.round(rev * 0.70)
                                });
                              }}
                              className="text-[10px] text-indigo-600 font-bold hover:underline flex items-center gap-0.5"
                            >
                              <Zap className="w-2.5 h-2.5" /> 3개년 자동연동
                            </button>
                          )}
                        </div>
                        <input
                          type="number"
                          value={formData.annualRevenue}
                          onChange={(e) => setFormData({ ...formData, annualRevenue: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs font-bold"
                        />
                        <span className="text-[10px] text-slate-400 mt-0.5 block">
                          약 {(formData.annualRevenue / 100000000).toFixed(2)}억원
                        </span>
                      </div>
                      <div>
                        <label className="font-bold text-slate-600 block mb-1">전년도 매출액(원)</label>
                        <input
                          type="number"
                          value={formData.prevYearRevenue}
                          onChange={(e) => setFormData({ ...formData, prevYearRevenue: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs"
                        />
                      </div>
                      <div>
                        <label className="font-bold text-slate-600 block mb-1">전전년도 매출액(원)</label>
                        <input
                          type="number"
                          value={formData.twoYearsAgoRevenue}
                          onChange={(e) => setFormData({ ...formData, twoYearsAgoRevenue: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="font-bold text-slate-600 block">상시 근로자수(명)</label>
                          {profile?.employees && (
                            <button
                              type="button"
                              onClick={() => setFormData({ ...formData, employeeCount: profile.employees!, fullTimeEmployees: Math.max(1, profile.employees! - 1) })}
                              className="text-[10px] text-indigo-600 font-bold hover:underline flex items-center gap-0.5"
                            >
                              <Zap className="w-2.5 h-2.5" /> 프로필({profile.employees}명)
                            </button>
                          )}
                        </div>
                        <input
                          type="number"
                          value={formData.employeeCount}
                          onChange={(e) => setFormData({ ...formData, employeeCount: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs font-bold"
                        />
                      </div>
                      <div>
                        <label className="font-bold text-slate-600 block mb-1">정규직 인원(명)</label>
                        <input
                          type="number"
                          value={formData.fullTimeEmployees}
                          onChange={(e) => setFormData({ ...formData, fullTimeEmployees: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-xs"
                        />
                      </div>
                      <div>
                        <label className="font-bold text-slate-600 block mb-1">주거래 금융기관</label>
                        <input
                          type="text"
                          value={formData.primaryBank}
                          onChange={(e) => setFormData({ ...formData, primaryBank: e.target.value })}
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="p-4 bg-white rounded-2xl border border-slate-200 space-y-3">
                    <span className="font-black text-slate-900 block text-xs">정책자금 신청 세부 조건</span>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="font-bold text-slate-700 block">신청 희망 금액(원)</label>
                          {profile?.fundingNeed && (
                            <button
                              type="button"
                              onClick={() => setFormData({ ...formData, requestedAmount: profile.fundingNeed! })}
                              className="text-[10px] text-emerald-700 font-bold hover:underline flex items-center gap-0.5"
                            >
                              <Zap className="w-2.5 h-2.5" /> 프로필 희망금액({formatWonKorean(profile.fundingNeed)})
                            </button>
                          )}
                        </div>
                        <input
                          type="number"
                          value={formData.requestedAmount}
                          onChange={(e) => setFormData({ ...formData, requestedAmount: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-emerald-50/50 border border-emerald-300 rounded-xl font-mono text-xs font-black text-emerald-900"
                        />
                        <span className="text-[10px] text-emerald-700 font-bold mt-0.5 block">
                          금 {(formData.requestedAmount / 10000).toLocaleString()}만원 ({formData.requestedAmount.toLocaleString()}원)
                        </span>
                      </div>
                      <div>
                        <label className="font-bold text-slate-700 block mb-1">자금 구분(용도)</label>
                        <select
                          value={formData.fundUsageCategory}
                          onChange={(e) => setFormData({ ...formData, fundUsageCategory: e.target.value as any })}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-bold text-xs"
                        >
                          <option value="운전자금">운전자금 (원부자재, 인건비, 임차료 등)</option>
                          <option value="시설자금">시설자금 (기계설비, 인테리어, 사업장구입)</option>
                          <option value="운전+시설자금">운전 + 시설 혼합 자금</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                      <div>
                        <label className="font-bold text-slate-600 block mb-1">희망 대출 기간</label>
                        <input
                          type="text"
                          value={formData.preferredTerm}
                          onChange={(e) => setFormData({ ...formData, preferredTerm: e.target.value })}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs"
                          placeholder="5년 (거치 2년)"
                        />
                      </div>
                      <div>
                        <label className="font-bold text-slate-600 block mb-1">희망 거치 기간(개월)</label>
                        <input
                          type="number"
                          value={formData.gracePeriodMonths}
                          onChange={(e) => setFormData({ ...formData, gracePeriodMonths: Number(e.target.value) })}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl font-mono text-xs"
                        />
                      </div>
                      <div>
                        <label className="font-bold text-slate-600 block mb-1">담보/보증 방식</label>
                        <select
                          value={formData.collateralType}
                          onChange={(e) => setFormData({ ...formData, collateralType: e.target.value as any })}
                          className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold"
                        >
                          <option value="신용보증서">신용보증재단/기보 보증서</option>
                          <option value="순수신용">공단 직접대출(순수신용)</option>
                          <option value="부동산담보">부동산 담보</option>
                          <option value="기타">기타</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: Narrative & AI Polish */}
              {activeEditorTab === 'NARRATIVE' && (
                <div className="space-y-4 animate-fade-in text-xs">
                  {/* Smart Autofill Banner for Tab 3 */}
                  {profile && (
                    <div className="bg-gradient-to-r from-amber-50 via-orange-50 to-amber-100/70 p-3 rounded-2xl border border-amber-300/80 flex items-center justify-between gap-3 shadow-xs">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-xl bg-amber-600 text-white flex items-center justify-center flex-shrink-0 shadow-xs">
                          <Zap className="w-3.5 h-3.5 fill-white" />
                        </div>
                        <div>
                          <span className="font-black text-amber-950 block text-xs">
                            프로필 기반 6대 사업계획 스마트 맞춤 서술
                          </span>
                          <span className="text-[11px] text-slate-700">
                            <strong>{getIndustryText(profile.industry || 'OTHER')}</strong> 특화 경쟁력 및 매출({formatWonKorean(profile.annualRevenue || 150000000)}) 기반 성장·상환 계획 작성
                          </span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleApplySmartAutofill('NARRATIVE')}
                        className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-black text-xs rounded-xl transition-all shadow-xs flex items-center gap-1 cursor-pointer flex-shrink-0"
                      >
                        <Zap className="w-3 h-3" />
                        <span>사업계획 6개 문항 채우기</span>
                      </button>
                    </div>
                  )}

                  <div className="bg-amber-50/70 p-3.5 rounded-2xl border border-amber-200/80 flex items-start justify-between gap-2.5">
                    <div className="flex items-start gap-2.5">
                      <Sparkles className="w-4 h-4 text-amber-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <span className="font-black text-amber-950 block">사업계획서 본문 서술 및 AI 문장 다듬기</span>
                        <p className="text-slate-700 text-[11px] mt-0.5">
                          심사관이 집중 검토하는 핵심 6대 서술 항목입니다. [AI 문구 다듬기]를 누르면 행정 공문서 어투로 즉시 정제됩니다.
                        </p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={handleAiGenerateAll}
                      disabled={isGeneratingAi}
                      className="px-2.5 py-1.5 bg-amber-600 hover:bg-amber-700 text-white font-black text-xs rounded-xl transition-all shadow-xs flex items-center gap-1 flex-shrink-0 cursor-pointer"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>전체 AI 생성</span>
                    </button>
                  </div>

                  {/* Section 1: Business Overview */}
                  <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="font-black text-slate-900 flex items-center gap-1.5">
                        <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-[10px]">1</span>
                        <span>기업 및 주요 사업 개요</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => handlePolishSection('businessOverview', '기업 및 주요 사업 개요')}
                        disabled={polishingSection === 'businessOverview'}
                        className="px-2 py-1 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-600 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className={`w-3 h-3 text-blue-600 ${polishingSection === 'businessOverview' ? 'animate-spin' : ''}`} />
                        <span>{polishingSection === 'businessOverview' ? '다듬는 중...' : 'AI 문구 다듬기'}</span>
                      </button>
                    </div>
                    <textarea
                      rows={3}
                      value={formData.businessOverview}
                      onChange={(e) => setFormData({ ...formData, businessOverview: e.target.value })}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs leading-relaxed focus:bg-white focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  {/* Section 2: Market Competitiveness */}
                  <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="font-black text-slate-900 flex items-center gap-1.5">
                        <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center text-[10px]">2</span>
                        <span>시장성 및 핵심 차별화 경쟁력</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => handlePolishSection('marketCompetitiveness', '시장성 및 핵심 차별화 경쟁력')}
                        disabled={polishingSection === 'marketCompetitiveness'}
                        className="px-2 py-1 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-600 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className={`w-3 h-3 text-blue-600 ${polishingSection === 'marketCompetitiveness' ? 'animate-spin' : ''}`} />
                        <span>{polishingSection === 'marketCompetitiveness' ? '다듬는 중...' : 'AI 문구 다듬기'}</span>
                      </button>
                    </div>
                    <textarea
                      rows={3}
                      value={formData.marketCompetitiveness}
                      onChange={(e) => setFormData({ ...formData, marketCompetitiveness: e.target.value })}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs leading-relaxed focus:bg-white focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  {/* Section 3: Fund Requirement Details */}
                  <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="font-black text-slate-900 flex items-center gap-1.5">
                        <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-800 flex items-center justify-center text-[10px]">3</span>
                        <span>자금 소요 내역 및 산출 근거</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => handlePolishSection('fundRequirementDetails', '자금 소요 내역 및 산출 근거')}
                        disabled={polishingSection === 'fundRequirementDetails'}
                        className="px-2 py-1 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-600 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className={`w-3 h-3 text-blue-600 ${polishingSection === 'fundRequirementDetails' ? 'animate-spin' : ''}`} />
                        <span>{polishingSection === 'fundRequirementDetails' ? '다듬는 중...' : 'AI 문구 다듬기'}</span>
                      </button>
                    </div>
                    <textarea
                      rows={3}
                      value={formData.fundRequirementDetails}
                      onChange={(e) => setFormData({ ...formData, fundRequirementDetails: e.target.value })}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs leading-relaxed focus:bg-white focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  {/* Section 4: Sales Growth Plan */}
                  <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="font-black text-slate-900 flex items-center gap-1.5">
                        <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-[10px]">4</span>
                        <span>자금 유입 후 매출 증대 및 사업화 계획</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => handlePolishSection('salesGrowthPlan', '매출 증대 및 사업화 계획')}
                        disabled={polishingSection === 'salesGrowthPlan'}
                        className="px-2 py-1 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-600 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className={`w-3 h-3 text-blue-600 ${polishingSection === 'salesGrowthPlan' ? 'animate-spin' : ''}`} />
                        <span>{polishingSection === 'salesGrowthPlan' ? '다듬는 중...' : 'AI 문구 다듬기'}</span>
                      </button>
                    </div>
                    <textarea
                      rows={3}
                      value={formData.salesGrowthPlan}
                      onChange={(e) => setFormData({ ...formData, salesGrowthPlan: e.target.value })}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs leading-relaxed focus:bg-white focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  {/* Section 5: Repayment Plan */}
                  <div className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="font-black text-slate-900 flex items-center gap-1.5">
                        <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center text-[10px]">5</span>
                        <span>원리금 상환 계획 및 현금흐름 창출 방안</span>
                      </label>
                      <button
                        type="button"
                        onClick={() => handlePolishSection('debtRepaymentPlan', '원리금 상환 계획 및 현금흐름 창출 방안')}
                        disabled={polishingSection === 'debtRepaymentPlan'}
                        className="px-2 py-1 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-600 rounded-lg text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className={`w-3 h-3 text-blue-600 ${polishingSection === 'debtRepaymentPlan' ? 'animate-spin' : ''}`} />
                        <span>{polishingSection === 'debtRepaymentPlan' ? '다듬는 중...' : 'AI 문구 다듬기'}</span>
                      </button>
                    </div>
                    <textarea
                      rows={3}
                      value={formData.debtRepaymentPlan}
                      onChange={(e) => setFormData({ ...formData, debtRepaymentPlan: e.target.value })}
                      className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs leading-relaxed focus:bg-white focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              )}

              {/* TAB 4: Usage Items Table */}
              {activeEditorTab === 'ITEMS' && (
                <div className="space-y-4 animate-fade-in text-xs">
                  {/* Smart Autofill Banner for Tab 4 */}
                  {profile && (
                    <div className="bg-gradient-to-r from-emerald-50 via-teal-50 to-blue-50 p-3 rounded-2xl border border-emerald-200/80 flex items-center justify-between gap-3 shadow-xs">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-xl bg-emerald-600 text-white flex items-center justify-center flex-shrink-0 shadow-xs">
                          <Sliders className="w-3.5 h-3.5 fill-white" />
                        </div>
                        <div>
                          <span className="font-black text-emerald-950 block text-xs">
                            프로필 신청금액({formatWonKorean(profile.fundingNeed || 50000000)}) 기반 소요명세표 자동 생성
                          </span>
                          <span className="text-[11px] text-slate-600">
                            <strong>{getIndustryText(profile.industry || 'OTHER')}</strong> 업종별 표준 소요 항목(원부자재 45% · 설비 35% · 마케팅 20%)으로 100% 균형 배분
                          </span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => handleApplySmartAutofill('ITEMS')}
                        className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl transition-all shadow-xs flex items-center gap-1 cursor-pointer flex-shrink-0"
                      >
                        <Zap className="w-3 h-3" />
                        <span>명세표 자동산출</span>
                      </button>
                    </div>
                  )}

                  <div className="bg-slate-900 text-white p-3.5 rounded-2xl flex items-center justify-between gap-3">
                    <div>
                      <span className="font-black text-white block">자금 집행 세부 소요 명세표</span>
                      <span className="text-[11px] text-slate-300">
                        합계: <strong className="text-emerald-400 font-bold">{totalFundUsageAmount.toLocaleString()}원</strong> / 신청액: {formData.requestedAmount.toLocaleString()}원
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={handleAddUsageItem}
                      className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl flex items-center gap-1 cursor-pointer shadow-xs"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>항목 추가</span>
                    </button>
                  </div>

                  <div className="space-y-3">
                    {formData.fundUsageItems.map((item, idx) => (
                      <div key={item.id} className="p-3.5 bg-white rounded-2xl border border-slate-200 space-y-2.5">
                        <div className="flex items-center justify-between gap-2">
                          <span className="font-black text-slate-900 flex items-center gap-1.5">
                            <span className="w-5 h-5 rounded-md bg-slate-100 text-slate-700 flex items-center justify-center text-[10px]">
                              {idx + 1}
                            </span>
                            <span>품목 #{idx + 1}</span>
                          </span>
                          <button
                            type="button"
                            onClick={() => handleRemoveUsageItem(item.id)}
                            className="text-slate-400 hover:text-rose-600 p-1 cursor-pointer"
                            title="삭제"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                          <div>
                            <label className="text-[11px] font-bold text-slate-600 block mb-0.5">품목명 / 집행 용도</label>
                            <input
                              type="text"
                              value={item.itemName}
                              onChange={(e) => handleUpdateUsageItem(item.id, 'itemName', e.target.value)}
                              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                            />
                          </div>
                          <div>
                            <label className="text-[11px] font-bold text-slate-600 block mb-0.5">구분</label>
                            <select
                              value={item.category}
                              onChange={(e) => handleUpdateUsageItem(item.id, 'category', e.target.value)}
                              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold"
                            >
                              <option value="원부자재">원부자재 선구매</option>
                              <option value="설비구입">설비/기계/인테리어</option>
                              <option value="인건비">인건비</option>
                              <option value="임차료">사업장 임차료</option>
                              <option value="마케팅">홍보 및 마케팅비</option>
                              <option value="운전자금">기타 일반 운전자금</option>
                            </select>
                          </div>
                        </div>

                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                          <div>
                            <label className="text-[11px] font-bold text-slate-600 block mb-0.5">소요 금액(원)</label>
                            <input
                              type="number"
                              value={item.amount}
                              onChange={(e) => handleUpdateUsageItem(item.id, 'amount', Number(e.target.value))}
                              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-mono font-bold"
                            />
                          </div>
                          <div>
                            <label className="text-[11px] font-bold text-slate-600 block mb-0.5">공급(협력)처</label>
                            <input
                              type="text"
                              value={item.supplier}
                              onChange={(e) => handleUpdateUsageItem(item.id, 'supplier', e.target.value)}
                              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                            />
                          </div>
                          <div>
                            <label className="text-[11px] font-bold text-slate-600 block mb-0.5">집행 예정시기</label>
                            <input
                              type="text"
                              value={item.executionMonth}
                              onChange={(e) => handleUpdateUsageItem(item.id, 'executionMonth', e.target.value)}
                              className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                              placeholder="1개월차"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 5: Pledge & Stamp */}
              {activeEditorTab === 'PLEDGE' && (
                <div className="space-y-4 animate-fade-in text-xs">
                  <div className="bg-rose-50/70 p-3.5 rounded-2xl border border-rose-200/80 flex items-start gap-2.5">
                    <ShieldCheck className="w-4 h-4 text-rose-600 mt-0.5 flex-shrink-0" />
                    <div>
                      <span className="font-black text-rose-950 block">법정 신청자격 사실확인 및 서약</span>
                      <p className="text-slate-600 text-[11px] mt-0.5">
                        정부 정책자금 심사 표준 규격 서약 조항입니다. 체크 확인 후 대표자 서명/날인을 완료하세요.
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2.5 bg-white p-4 rounded-2xl border border-slate-200">
                    {[
                      { key: 'pledgeNoBroker', text: '제3자 부당개입(불법 정책자금 브로커) 부존재 서약 및 수수료 지급 사실 없음 확인' },
                      { key: 'pledgeNoTaxDelinquency', text: '국세 및 지방세, 4대 사회보험료 체납 사실이 없음을 확약' },
                      { key: 'pledgeFactTrue', text: '제출하는 모든 신청서 및 첨부 서류의 기재 내용이 진실함을 확약' },
                      { key: 'pledgeRefundOnFalse', text: '허위사실이나 부정한 방법으로 자금 수혜 시 전액 환수 및 제재 조치에 동의' },
                      { key: 'pledgeCreditInfoConsent', text: '신용정보의 이용 및 보호에 관한 법률에 따른 공공기관 신용정보 조회 동의' },
                    ].map((pledge) => (
                      <label
                        key={pledge.key}
                        className="flex items-start gap-3 p-2.5 rounded-xl hover:bg-slate-50 cursor-pointer transition-colors border border-transparent hover:border-slate-200"
                      >
                        <input
                          type="checkbox"
                          checked={Boolean(formData[pledge.key as keyof DraftFormData])}
                          onChange={(e) =>
                            setFormData({
                              ...formData,
                              [pledge.key]: e.target.checked
                            })
                          }
                          className="mt-0.5 w-4 h-4 rounded text-blue-600 border-slate-300 focus:ring-blue-500 cursor-pointer"
                        />
                        <span className="text-xs text-slate-800 font-medium leading-tight">
                          {pledge.text}
                        </span>
                      </label>
                    ))}
                  </div>

                  <div className="p-4 bg-white rounded-2xl border border-slate-200 space-y-3">
                    <span className="font-black text-slate-900 block text-xs">대표자 서명 및 전자 인장 날인 설정</span>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="font-bold text-slate-700 block mb-1">서명인 성명</label>
                        <input
                          type="text"
                          value={formData.representativeSignatureName}
                          onChange={(e) => setFormData({ ...formData, representativeSignatureName: e.target.value })}
                          className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs"
                        />
                      </div>
                      <div>
                        <label className="font-bold text-slate-700 block mb-1">인장 유형</label>
                        <div className="flex items-center gap-2 pt-1">
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, hasStamp: true, stampText: '인' })}
                            className={`px-3 py-1.5 rounded-xl font-bold text-xs border transition-all cursor-pointer ${
                              formData.hasStamp
                                ? 'bg-rose-50 text-rose-700 border-rose-300 shadow-2xs'
                                : 'bg-white text-slate-600 border-slate-200'
                            }`}
                          >
                            🔴 붉은색 직인 날인
                          </button>
                          <button
                            type="button"
                            onClick={() => setFormData({ ...formData, hasStamp: false })}
                            className={`px-3 py-1.5 rounded-xl font-bold text-xs border transition-all cursor-pointer ${
                              !formData.hasStamp
                                ? 'bg-indigo-50 text-indigo-700 border-indigo-300 shadow-2xs'
                                : 'bg-white text-slate-600 border-slate-200'
                            }`}
                          >
                            ✍️ 자필 서명 형식
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Actions in Left Editor */}
            <div className="p-4 bg-white border-t border-slate-200/80 flex items-center justify-between gap-2 flex-shrink-0">
              <button
                type="button"
                onClick={handleSaveDraft}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>임시 저장</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setFormData(createInitialFormData(selectedDocType, profile, fund))}
                  className="px-3 py-2 text-slate-400 hover:text-slate-600 text-xs font-bold cursor-pointer"
                >
                  입력 초기화
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode('PREVIEW_ONLY')}
                  className="lg:hidden px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-black shadow-xs flex items-center gap-1 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>공식 서식 보기</span>
                </button>
              </div>
            </div>
          </div>

          {/* RIGHT: Authentic Official Government Standard Document PDF Layout */}
          <div
            id="government-pdf-print-area"
            className={`${
              viewMode === 'EDITOR_ONLY' ? 'hidden' : viewMode === 'SPLIT' ? 'lg:col-span-6' : 'lg:col-span-12'
            } bg-slate-200/70 p-4 sm:p-8 overflow-y-auto print:p-0 print:bg-white print:overflow-visible print:block`}
          >
            {/* Top Back button on Mobile */}
            <div className="lg:hidden mb-4 print:hidden flex items-center justify-between">
              <button
                type="button"
                onClick={() => setViewMode('EDITOR_ONLY')}
                className="px-3 py-1.5 bg-white text-slate-800 rounded-xl text-xs font-bold border border-slate-300 shadow-xs flex items-center gap-1 cursor-pointer"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>입력창으로 돌아가기</span>
              </button>
              <button
                type="button"
                onClick={handlePrintPdf}
                className="px-3 py-1.5 bg-emerald-600 text-white rounded-xl text-xs font-black shadow-xs flex items-center gap-1 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>PDF 인쇄</span>
              </button>
            </div>

            {/* Official A4 Standard Paper Container */}
            <div className="bg-white mx-auto shadow-2xl rounded-sm p-6 sm:p-10 border border-slate-300/80 max-w-[800px] text-slate-900 font-sans leading-normal print:shadow-none print:border-none print:p-0 print:max-w-none">
              {/* Document Standard Header */}
              <div className="flex items-start justify-between border-b-2 border-slate-900 pb-3 mb-4">
                <div>
                  <span className="text-[11px] font-bold text-slate-600 block">
                    ■ {currentTemplate.authority} 소관 정책자금 융자지원 관리규정 [{currentTemplate.formNumber}]
                  </span>
                  <h1 className="text-xl sm:text-2xl font-black text-slate-950 tracking-tight mt-1">
                    {currentTemplate.title}
                  </h1>
                </div>
                <div className="text-right text-[10px] text-slate-500 font-mono">
                  <div>문서번호: {formData.documentNumber}</div>
                  <div>작성일자: {formData.applicationDate}</div>
                  <div className="mt-1 inline-block px-1.5 py-0.5 border border-slate-300 text-slate-600 font-bold">
                    원본대조필
                  </div>
                </div>
              </div>

              {/* Administrative Summary Box */}
              <div className="grid grid-cols-4 border border-slate-400 text-xs mb-5 text-center">
                <div className="bg-slate-100 font-bold p-2 border-r border-b border-slate-300 flex items-center justify-center">
                  신청 자금명
                </div>
                <div className="p-2 border-r border-b border-slate-300 text-left font-bold font-sans col-span-3">
                  {formData.fundName}
                </div>
                <div className="bg-slate-100 font-bold p-2 border-r border-slate-300 flex items-center justify-center">
                  접수 기관
                </div>
                <div className="p-2 border-r border-slate-300 text-left">
                  {formData.targetAgency}
                </div>
                <div className="bg-slate-100 font-bold p-2 border-r border-slate-300 flex items-center justify-center">
                  신청 금액
                </div>
                <div className="p-2 text-left font-black text-blue-950">
                  금 {formData.requestedAmount.toLocaleString()}원정
                </div>
              </div>

              {/* Section 1: Official Company Profile Table */}
              <div className="mb-5">
                <div className="flex items-center gap-1 text-xs font-black text-slate-950 mb-1.5">
                  <div className="w-1.5 h-3 bg-slate-900 mr-1" />
                  <span>1. 신청기업 일반 현황</span>
                </div>
                <table className="w-full border-collapse border border-slate-400 text-[11px]">
                  <tbody>
                    <tr>
                      <td className="w-24 bg-slate-100 border border-slate-300 p-2 font-bold text-center">
                        상 호 (기업명)
                      </td>
                      <td className="border border-slate-300 p-2 font-bold">
                        {formData.businessName}
                      </td>
                      <td className="w-24 bg-slate-100 border border-slate-300 p-2 font-bold text-center">
                        사업자등록번호
                      </td>
                      <td className="border border-slate-300 p-2 font-mono">
                        {formData.businessRegistrationNumber}
                      </td>
                    </tr>
                    <tr>
                      <td className="bg-slate-100 border border-slate-300 p-2 font-bold text-center">
                        대표자 성명
                      </td>
                      <td className="border border-slate-300 p-2 font-bold">
                        {formData.ceoName} ({formData.birthDate || '생년월일'})
                      </td>
                      <td className="bg-slate-100 border border-slate-300 p-2 font-bold text-center">
                        기업 유형
                      </td>
                      <td className="border border-slate-300 p-2">
                        {formData.businessType} (개업일: {formData.foundedDate})
                      </td>
                    </tr>
                    <tr>
                      <td className="bg-slate-100 border border-slate-300 p-2 font-bold text-center">
                        사업장 소재지
                      </td>
                      <td colSpan={3} className="border border-slate-300 p-2">
                        {formData.businessAddress}
                      </td>
                    </tr>
                    <tr>
                      <td className="bg-slate-100 border border-slate-300 p-2 font-bold text-center">
                        주요 업종/종목
                      </td>
                      <td className="border border-slate-300 p-2">
                        {formData.industryCategory}
                      </td>
                      <td className="bg-slate-100 border border-slate-300 p-2 font-bold text-center">
                        주요 취급품목
                      </td>
                      <td className="border border-slate-300 p-2">
                        {formData.mainProduct}
                      </td>
                    </tr>
                    <tr>
                      <td className="bg-slate-100 border border-slate-300 p-2 font-bold text-center">
                        연락처 / 이메일
                      </td>
                      <td colSpan={3} className="border border-slate-300 p-2">
                        Tel: {formData.contactPhone} / E-mail: {formData.email}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Section 2: Financials & Loan Request Table */}
              <div className="mb-5">
                <div className="flex items-center gap-1 text-xs font-black text-slate-950 mb-1.5">
                  <div className="w-1.5 h-3 bg-slate-900 mr-1" />
                  <span>2. 경영 실적 및 자금 신청 내역</span>
                </div>
                <table className="w-full border-collapse border border-slate-400 text-[11px] text-center">
                  <thead>
                    <tr className="bg-slate-100">
                      <th className="border border-slate-300 p-2 font-bold">구분</th>
                      <th className="border border-slate-300 p-2 font-bold">최근연도(당해)</th>
                      <th className="border border-slate-300 p-2 font-bold">전년도</th>
                      <th className="border border-slate-300 p-2 font-bold">전전년도</th>
                      <th className="border border-slate-300 p-2 font-bold">상시근로자</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td className="bg-slate-50 border border-slate-300 p-2 font-bold">매출액(원)</td>
                      <td className="border border-slate-300 p-2 font-mono font-bold text-blue-900">
                        {formData.annualRevenue.toLocaleString()}
                      </td>
                      <td className="border border-slate-300 p-2 font-mono">
                        {formData.prevYearRevenue.toLocaleString()}
                      </td>
                      <td className="border border-slate-300 p-2 font-mono">
                        {formData.twoYearsAgoRevenue.toLocaleString()}
                      </td>
                      <td className="border border-slate-300 p-2 font-bold">
                        {formData.employeeCount}명 (정규직 {formData.fullTimeEmployees}명)
                      </td>
                    </tr>
                  </tbody>
                </table>

                {/* Sub-table: Loan terms */}
                <table className="w-full border-collapse border border-slate-400 text-[11px] mt-2">
                  <tbody>
                    <tr>
                      <td className="w-24 bg-slate-100 border border-slate-300 p-2 font-bold text-center">
                        신청 금액
                      </td>
                      <td className="border border-slate-300 p-2 font-black text-blue-950">
                        금 {formData.requestedAmount.toLocaleString()}원 ({formData.fundUsageCategory})
                      </td>
                      <td className="w-24 bg-slate-100 border border-slate-300 p-2 font-bold text-center">
                        상환 조건
                      </td>
                      <td className="border border-slate-300 p-2">
                        {formData.preferredTerm} / {formData.collateralType}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Section 3: Official Narrative Statements */}
              <div className="space-y-4 mb-5 text-[11px]">
                {/* 3.1 Business Overview & Competitiveness */}
                <div className="border border-slate-300 p-3 rounded-xs bg-white">
                  <div className="font-bold text-slate-900 text-xs border-b border-slate-200 pb-1 mb-2 flex items-center justify-between">
                    <span>3. 기업 및 사업 개요와 차별화 경쟁력</span>
                  </div>
                  <p className="text-slate-800 leading-relaxed whitespace-pre-wrap mb-2">
                    {formData.businessOverview}
                  </p>
                  <div className="bg-slate-50 p-2.5 rounded border border-slate-200 text-slate-700 leading-relaxed whitespace-pre-wrap font-sans">
                    <strong>[핵심 시장성 및 기술/영업 경쟁력]</strong>
                    {'\n'}
                    {formData.marketCompetitiveness}
                  </div>
                </div>

                {/* 3.2 Fund Requirement & Usage Plan */}
                <div className="border border-slate-300 p-3 rounded-xs bg-white">
                  <div className="font-bold text-slate-900 text-xs border-b border-slate-200 pb-1 mb-2 flex items-center justify-between">
                    <span>4. 자금 소요 내역 및 세부 활용 명세</span>
                  </div>
                  <p className="text-slate-800 leading-relaxed whitespace-pre-wrap mb-2.5">
                    {formData.fundRequirementDetails}
                  </p>

                  {/* Fund usage sub-table */}
                  <table className="w-full border-collapse border border-slate-300 text-[10.5px] text-center mb-2">
                    <thead>
                      <tr className="bg-slate-100">
                        <th className="border border-slate-300 p-1.5 font-bold">No.</th>
                        <th className="border border-slate-300 p-1.5 font-bold">품목 및 소요내역</th>
                        <th className="border border-slate-300 p-1.5 font-bold">구분</th>
                        <th className="border border-slate-300 p-1.5 font-bold">소요 금액(원)</th>
                        <th className="border border-slate-300 p-1.5 font-bold">공급업체</th>
                        <th className="border border-slate-300 p-1.5 font-bold">집행시기</th>
                      </tr>
                    </thead>
                    <tbody>
                      {formData.fundUsageItems.map((item, idx) => (
                        <tr key={item.id}>
                          <td className="border border-slate-300 p-1.5">{idx + 1}</td>
                          <td className="border border-slate-300 p-1.5 text-left font-medium">{item.itemName}</td>
                          <td className="border border-slate-300 p-1.5">{item.category}</td>
                          <td className="border border-slate-300 p-1.5 font-mono font-bold text-right pr-2">
                            {item.amount.toLocaleString()}
                          </td>
                          <td className="border border-slate-300 p-1.5">{item.supplier}</td>
                          <td className="border border-slate-300 p-1.5">{item.executionMonth}</td>
                        </tr>
                      ))}
                      <tr className="bg-slate-100 font-bold">
                        <td colSpan={3} className="border border-slate-300 p-1.5 text-center">합 계</td>
                        <td className="border border-slate-300 p-1.5 font-mono text-right pr-2 text-blue-900">
                          {totalFundUsageAmount.toLocaleString()}원
                        </td>
                        <td colSpan={2} className="border border-slate-300 p-1.5 text-slate-500 text-[10px]">
                          전자세금계산서 증빙 일괄 보관
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <p className="text-[10px] text-slate-600 leading-tight">
                    ※ 집행 및 사후관리: {formData.fundUsageSchedule}
                  </p>
                </div>

                {/* 3.3 Sales Growth & Repayment Plan */}
                <div className="border border-slate-300 p-3 rounded-xs bg-white">
                  <div className="font-bold text-slate-900 text-xs border-b border-slate-200 pb-1 mb-2">
                    <span>5. 향후 매출 증대 및 원리금 상환 계획</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div className="bg-slate-50 p-2.5 rounded border border-slate-200">
                      <span className="font-bold text-slate-900 block mb-1">■ 기대 효과 및 매출 성장 계획</span>
                      <p className="text-slate-700 leading-relaxed text-[10.5px] whitespace-pre-wrap">
                        {formData.salesGrowthPlan}
                      </p>
                    </div>
                    <div className="bg-slate-50 p-2.5 rounded border border-slate-200">
                      <span className="font-bold text-slate-900 block mb-1">■ 상환 재원 조달 및 리스크 대책</span>
                      <p className="text-slate-700 leading-relaxed text-[10.5px] whitespace-pre-wrap">
                        {formData.debtRepaymentPlan}
                        {'\n\n'}
                        [리스크 관리] {formData.riskManagementPlan}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Official Legal Declaration & Signature Box */}
              <div className="mt-8 pt-6 border-t-2 border-slate-900 text-center space-y-4">
                <p className="text-xs sm:text-sm font-serif font-bold text-slate-900 leading-relaxed max-w-xl mx-auto">
                  「중소기업진흥에 관한 법률」 및 {currentTemplate.authority} 소관 정책자금 융자지원 관리규정에 따라 위와 같이 사실에 근거하여 신청서를 제출합니다.
                </p>

                <div className="text-xs font-bold text-slate-800 pt-2 font-mono">
                  {formData.applicationDate}
                </div>

                {/* Stamp / Signature Visual Box */}
                <div className="flex items-center justify-end pr-6 pt-2">
                  <div className="flex items-center gap-3 text-right">
                    <div className="text-xs font-bold text-slate-900">
                      <div>신청기업: <span className="font-black">{formData.businessName}</span></div>
                      <div>대 표 자: <span className="font-black">{formData.representativeSignatureName}</span> (서명 또는 인)</div>
                    </div>

                    {/* Visual Stamp Seal */}
                    <div className="w-14 h-14 rounded-full border-2 border-rose-600 flex items-center justify-center text-rose-600 font-serif font-black text-xs relative select-none shadow-2xs rotate-[-6deg] bg-rose-50/40">
                      <div className="text-center leading-tight">
                        <div className="text-[9px] font-sans font-bold">대표자</div>
                        <div className="font-black text-xs">{formData.representativeSignatureName.slice(0, 3)}</div>
                        <div className="text-[9px]">인</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="text-center font-black text-base sm:text-lg text-slate-950 pt-4 tracking-wider">
                  {formData.targetAgency} 귀중
                </div>
              </div>
            </div>
          </div>
            </>
          )}
        </div>

        {/* Modal Bottom Footer (Hidden when printing) */}
        <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200/80 flex items-center justify-between gap-3 flex-shrink-0 print:hidden">
          <div className="flex items-center gap-2 text-slate-500 text-xs font-medium">
            <ShieldCheck className="w-4 h-4 text-blue-600" />
            <span>정부 정책자금 표준 서식 가이드라인(2026년 기준) 준수</span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyFormattedText}
              className="px-3.5 py-2 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold transition-all shadow-2xs flex items-center gap-1.5 cursor-pointer"
            >
              {copiedText ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedText ? '복사 완료' : '텍스트 복사'}</span>
            </button>

            <button
              type="button"
              onClick={handlePrintPdf}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>정부 표준 PDF 인쇄/저장</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-black rounded-xl transition-all shadow-xs cursor-pointer"
            >
              닫기
            </button>
          </div>
        </div>

        {/* Smart Autofill Inspector & Confirmation Modal */}
        {showAutofillModal && (
          <div className="fixed inset-0 z-60 bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in print:hidden">
            <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-scale-up">
              {/* Modal Header */}
              <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 p-5 text-slate-950 flex items-center justify-between flex-shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-slate-950 text-amber-400 flex items-center justify-center flex-shrink-0 shadow-md">
                    <Zap className="w-5 h-5 fill-amber-400" />
                  </div>
                  <div>
                    <h3 className="font-black text-base sm:text-lg tracking-tight text-slate-950">
                      프로필 기반 스마트 자동완성
                    </h3>
                    <p className="text-xs text-slate-900/80 font-medium mt-0.5">
                      사용자의 기본 프로필 정보를 분석하여 정부 표준 서식 각 항목에 최적화된 서술 및 수치를 자동 기입합니다.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowAutofillModal(false)}
                  className="w-8 h-8 rounded-full bg-black/10 hover:bg-black/20 text-slate-950 flex items-center justify-center transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Content */}
              <div className="p-5 sm:p-6 space-y-5 overflow-y-auto flex-1 text-xs">
                {/* Profile Data Sources Card */}
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3">
                  <span className="font-black text-slate-900 block flex items-center gap-1.5">
                    <Briefcase className="w-4 h-4 text-amber-600" />
                    <span>연동 대상 사용자 프로필 데이터 현황</span>
                  </span>
                  
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    <div className="bg-white p-2.5 rounded-xl border border-slate-200/80">
                      <span className="text-[10px] text-slate-500 font-bold block">1. 대표 업종</span>
                      <span className="font-black text-slate-900 text-xs truncate block mt-0.5">
                        {profile?.industry ? getIndustryText(profile.industry) : 'IT / 소프트웨어 개발'}
                      </span>
                    </div>

                    <div className="bg-white p-2.5 rounded-xl border border-slate-200/80">
                      <span className="text-[10px] text-slate-500 font-bold block">2. 연간 매출액</span>
                      <span className="font-black text-emerald-700 text-xs truncate block mt-0.5">
                        {formatWonKorean(profile?.annualRevenue || 150000000)}
                      </span>
                    </div>

                    <div className="bg-white p-2.5 rounded-xl border border-slate-200/80">
                      <span className="text-[10px] text-slate-500 font-bold block">3. 개업(창업)연도</span>
                      <span className="font-black text-indigo-700 text-xs truncate block mt-0.5">
                        {profile?.foundedYear || '2022'}년 (업력 {Math.max(1, new Date().getFullYear() - parseInt(String(profile?.foundedYear || '2022'), 10) + 1)}년차)
                      </span>
                    </div>

                    <div className="bg-white p-2.5 rounded-xl border border-slate-200/80">
                      <span className="text-[10px] text-slate-500 font-bold block">4. 상시 근로자수</span>
                      <span className="font-black text-slate-900 text-xs truncate block mt-0.5">
                        {profile?.employees || 2}명 (정규직 {Math.max(1, (profile?.employees || 2) - 1)}명)
                      </span>
                    </div>

                    <div className="bg-white p-2.5 rounded-xl border border-slate-200/80">
                      <span className="text-[10px] text-slate-500 font-bold block">5. 신청 희망 자금</span>
                      <span className="font-black text-blue-700 text-xs truncate block mt-0.5">
                        {formatWonKorean(profile?.fundingNeed || formData.requestedAmount || 50000000)}
                      </span>
                    </div>

                    <div className="bg-white p-2.5 rounded-xl border border-slate-200/80">
                      <span className="text-[10px] text-slate-500 font-bold block">6. 기업 형태 / 대표</span>
                      <span className="font-black text-slate-900 text-xs truncate block mt-0.5">
                        {profile?.businessType === 'CORPORATION' ? '법인' : '개인'} / {profile?.name || formData.ceoName || '대표자'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Scope Selection Tabs */}
                <div className="space-y-2">
                  <span className="font-black text-slate-900 block">자동완성 적용 범위 선택</span>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {[
                      { id: 'ALL', label: '⚡ 서식 전체 (권장)', desc: '22개 전 항목 일괄 산출' },
                      { id: 'INFO', label: '1. 기업 기본정보', desc: '상호, 사업자번호, 대표, 업종, 주소' },
                      { id: 'FINANCE', label: '2. 재무 및 자금신청', desc: '3개년 매출, 고용, 대출신청액' },
                      { id: 'NARRATIVE', label: '3. 사업계획 6개문항', desc: '개요, 경쟁력, 성장·상환계획' },
                      { id: 'ITEMS', label: '4. 소요명세표', desc: '45%·35%·20% 균형 배분' },
                    ].map((tab) => (
                      <button
                        key={tab.id}
                        type="button"
                        onClick={() => setAutofillTabTarget(tab.id as any)}
                        className={`p-3 rounded-2xl text-left border transition-all cursor-pointer ${
                          autofillTabTarget === tab.id
                            ? 'bg-amber-50 border-amber-400 text-amber-950 ring-2 ring-amber-400/30'
                            : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                        }`}
                      >
                        <div className="font-black text-xs">{tab.label}</div>
                        <div className="text-[10.5px] text-slate-500 mt-0.5 leading-tight">{tab.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Mapping Logic Preview */}
                <div className="p-3.5 bg-amber-50/60 rounded-2xl border border-amber-200/80 space-y-2">
                  <span className="font-black text-amber-950 block flex items-center gap-1.5">
                    <Wand2 className="w-3.5 h-3.5 text-amber-700" />
                    <span>스마트 자동완성 변환 알고리즘 요약</span>
                  </span>
                  <ul className="space-y-1.5 text-[11px] text-amber-900">
                    <li className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mt-0.5 flex-shrink-0" />
                      <span><strong>업종 맞춤형 서술</strong>: 선택된 업종({getIndustryText(profile?.industry || 'OTHER')})에 적합한 대표 제품 및 3대 핵심 경쟁력 문장 자동 구성</span>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mt-0.5 flex-shrink-0" />
                      <span><strong>매출 기반 재무 모델링</strong>: 당해 매출({formatWonKorean(profile?.annualRevenue || 150000000)})을 기준으로 전년(85%), 전전년(70%), 차년도 25% 성장 목표 및 월환산 영업이익 상환 계획 계산</span>
                    </li>
                    <li className="flex items-start gap-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 mt-0.5 flex-shrink-0" />
                      <span><strong>소요명세표 100% 균형 일치</strong>: 신청자금({formatWonKorean(profile?.fundingNeed || formData.requestedAmount || 50000000)})을 원부자재(45%), 설비(35%), 마케팅(20%)으로 단 1원의 오차 없이 정밀 분할</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Modal Footer Actions */}
              <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2 flex-shrink-0">
                <button
                  type="button"
                  onClick={() => setShowAutofillModal(false)}
                  className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold transition-all cursor-pointer"
                >
                  취소
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => handleApplySmartAutofill('ALL')}
                    className="px-5 py-2.5 bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black rounded-xl text-xs transition-all shadow-md flex items-center gap-1.5 cursor-pointer"
                  >
                    <Zap className="w-4 h-4 fill-slate-950" />
                    <span>서식 전체 일괄 자동완성 (22개 필드)</span>
                  </button>
                  {autofillTabTarget !== 'ALL' && (
                    <button
                      type="button"
                      onClick={() => handleApplySmartAutofill(autofillTabTarget)}
                      className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-black rounded-xl text-xs transition-all shadow-xs flex items-center gap-1 cursor-pointer"
                    >
                      <span>선택 영역만 적용</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Deep Provenance Trace Pipeline Detail Inspector Modal */}
        {selectedProvenanceDetail && (
          <div className="fixed inset-0 z-70 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in print:hidden">
            <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] animate-scale-up text-slate-900">
              {/* Modal Header */}
              <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-5 text-white flex items-center justify-between flex-shrink-0">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-md ${
                    selectedProvenanceDetail.sourceType === 'PROFILE'
                      ? 'bg-blue-600 text-white'
                      : selectedProvenanceDetail.sourceType === 'SMART_CALC'
                      ? 'bg-teal-600 text-white'
                      : selectedProvenanceDetail.sourceType === 'AI_GENERATED'
                      ? 'bg-purple-600 text-white'
                      : selectedProvenanceDetail.sourceType === 'FUND_POLICY'
                      ? 'bg-slate-700 text-white'
                      : 'bg-amber-600 text-white'
                  }`}>
                    {selectedProvenanceDetail.sourceType === 'PROFILE' && <Building2 className="w-5 h-5" />}
                    {selectedProvenanceDetail.sourceType === 'SMART_CALC' && <Sliders className="w-5 h-5" />}
                    {selectedProvenanceDetail.sourceType === 'AI_GENERATED' && <Sparkles className="w-5 h-5" />}
                    {selectedProvenanceDetail.sourceType === 'FUND_POLICY' && <ShieldCheck className="w-5 h-5" />}
                    {selectedProvenanceDetail.sourceType === 'MANUAL_INPUT' && <Edit3 className="w-5 h-5" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-white/20 text-white">
                        {selectedProvenanceDetail.sourceTypeName}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full font-bold bg-indigo-500/30 text-indigo-200">
                        {selectedProvenanceDetail.tabLabel}
                      </span>
                    </div>
                    <h3 className="font-black text-base sm:text-lg tracking-tight text-white mt-0.5">
                      {selectedProvenanceDetail.fieldLabel} 데이터 출처 검증
                    </h3>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setSelectedProvenanceDetail(null)}
                  className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Content: 3-Step Data Pipeline */}
              <div className="p-5 sm:p-6 space-y-5 overflow-y-auto flex-1 text-xs">
                {/* Visual Pipeline Graph */}
                <div className="space-y-2">
                  <span className="font-black text-slate-900 block flex items-center gap-1.5">
                    <History className="w-4 h-4 text-indigo-600" />
                    <span>3단계 데이터 추적 파이프라인 (Lineage Stream)</span>
                  </span>

                  <div className="space-y-2 relative before:absolute before:left-4 before:top-4 before:bottom-4 before:w-0.5 before:bg-indigo-200">
                    {/* Step 1: Raw Ingestion */}
                    <div className="relative pl-10">
                      <div className="absolute left-2 top-2 -translate-x-1/2 w-5 h-5 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-black shadow-xs">
                        1
                      </div>
                      <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/80 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-black text-slate-900">데이터 원천 수집 (Raw Origin)</span>
                          <span className="text-[10px] px-1.5 py-0.2 bg-blue-100 text-blue-800 rounded font-bold">
                            {selectedProvenanceDetail.sourceOrigin}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600">
                          <strong>추적 경로:</strong> {selectedProvenanceDetail.sourceTracePath}
                        </p>
                        <div className="bg-white p-2 rounded-xl border border-slate-200 text-slate-700 font-mono text-[11px]">
                          원천 수집값: <strong className="text-slate-900">{selectedProvenanceDetail.rawSourceValue || '(자동 모델링/연동)'}</strong>
                        </div>
                      </div>
                    </div>

                    {/* Step 2: Transformation Engine */}
                    <div className="relative pl-10">
                      <div className="absolute left-2 top-2 -translate-x-1/2 w-5 h-5 rounded-full bg-teal-600 text-white flex items-center justify-center text-[10px] font-black shadow-xs">
                        2
                      </div>
                      <div className="bg-teal-50/70 p-3 rounded-2xl border border-teal-200/80 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-black text-teal-950">스마트 변환 및 비즈니스 알고리즘</span>
                          <span className="text-[10px] px-1.5 py-0.2 bg-teal-200 text-teal-900 rounded font-bold">
                            신뢰도 {selectedProvenanceDetail.confidenceScore}%
                          </span>
                        </div>
                        <p className="text-[11px] text-teal-900/90 leading-snug">
                          {selectedProvenanceDetail.formulaOrLogic || '공공기관 서식 규격에 맞추어 표준 변환 및 데이터 마샬링 수행'}
                        </p>
                      </div>
                    </div>

                    {/* Step 3: Form Binding */}
                    <div className="relative pl-10">
                      <div className="absolute left-2 top-2 -translate-x-1/2 w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center text-[10px] font-black shadow-xs">
                        3
                      </div>
                      <div className="bg-indigo-50/70 p-3 rounded-2xl border border-indigo-200/80 space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="font-black text-indigo-950">서식 필드 바인딩 (Form Field Output)</span>
                          <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                            selectedProvenanceDetail.verified
                              ? 'bg-emerald-200 text-emerald-900'
                              : 'bg-amber-200 text-amber-900'
                          }`}>
                            {selectedProvenanceDetail.verified ? '✅ 검증 승인됨' : '⚠️ 검토 필요'}
                          </span>
                        </div>
                        <p className="text-[11px] text-indigo-900">
                          {currentTemplate.shortTitle} [{selectedProvenanceDetail.tabLabel}] ➔ <strong>{selectedProvenanceDetail.fieldLabel}</strong>
                        </p>
                        <div className="bg-white p-2.5 rounded-xl border border-indigo-200 text-indigo-950 font-bold text-xs">
                          최종 반영값: <span className="text-blue-700">{selectedProvenanceDetail.currentDisplayValue}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Audit Checklist */}
                <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2">
                  <span className="font-black text-slate-900 block flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    <span>행정 서식 심사 기준 검증 체크리스트</span>
                  </span>
                  <ul className="space-y-1 text-[11px] text-slate-700">
                    <li className="flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                      <span>사업자등록증 상 정보와의 일치 여부 확인 완료</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                      <span>공공 정책자금 심사 평가 지침(재무·고용·기술성) 표준 배점 기준 부합</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <Check className="w-3.5 h-3.5 text-emerald-600 flex-shrink-0" />
                      <span>수치 연산 및 소요명세표 총액과의 100% 대차 일치 검증</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2 flex-shrink-0">
                <button
                  type="button"
                  onClick={() => setSelectedProvenanceDetail(null)}
                  className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl text-xs font-bold transition-all cursor-pointer"
                >
                  닫기
                </button>

                <div className="flex items-center gap-2">
                  {selectedProvenanceDetail.isCustomized && selectedProvenanceDetail.sourceType === 'PROFILE' && (
                    <button
                      type="button"
                      onClick={() => {
                        handleResyncFieldWithProfile(selectedProvenanceDetail.fieldKey);
                        setSelectedProvenanceDetail(null);
                      }}
                      className="px-3.5 py-2 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>프로필 원본으로 복원</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      handleToggleVerifyField(selectedProvenanceDetail.fieldKey);
                      setSelectedProvenanceDetail(null);
                    }}
                    className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shadow-xs ${
                      selectedProvenanceDetail.verified
                        ? 'bg-slate-200 text-slate-800 hover:bg-slate-300'
                        : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                    }`}
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{selectedProvenanceDetail.verified ? '검증 취소' : '데이터 출처 검증 승인'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      handleJumpToEditorField(selectedProvenanceDetail.tabKey, selectedProvenanceDetail.fieldKey);
                      setSelectedProvenanceDetail(null);
                    }}
                    className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-black rounded-xl text-xs transition-all shadow-xs flex items-center gap-1 cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>작성기에서 수정하기</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
