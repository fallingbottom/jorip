import React, { useState, useEffect, useRef } from 'react';
import { 
  Headphones, 
  X, 
  Send, 
  Calendar, 
  Clock, 
  Phone, 
  Mail, 
  User, 
  Building2, 
  CheckCircle2, 
  FileText, 
  Sparkles, 
  ShieldCheck, 
  HelpCircle, 
  MessageSquare,
  AlertCircle,
  ChevronRight,
  BadgeCheck,
  PhoneCall,
  Video,
  MessagesSquare,
  DollarSign,
  ClipboardCheck,
  ExternalLink,
  Copy,
  Check,
  RefreshCw,
  SlidersHorizontal,
  Plus,
  FileSpreadsheet,
  Globe
} from 'lucide-react';
import { PolicyFund, UserProfile, SourcePolicy } from '../types';
import { createConsultationIntakeForm, GoogleFormInfo, saveUserConsultation } from '../services/workspaceService';
import { auth } from '../services/firebaseService';

export interface ConsultationRequestData {
  id: string;
  fundTitle: string;
  fundAgency: string;
  fundMaxAmount?: string;
  fundInterestRate?: string;
  applicantName: string;
  businessName: string;
  contactNumber: string;
  email: string;
  preferredChannel: 'CALL' | 'VIDEO' | 'CHAT'; // 전화 상담, 화상(Zoom/Meet) 상담, 1:1 채팅
  preferredDate: string;
  preferredTimeSlot: 'MORNING' | 'AFTERNOON' | 'EVENING' | 'ANYTIME'; // 오전 10-12시, 오후 14-17시, 야간 18-20시, 언제든 가능
  inquiryCategory: 'ELIGIBILITY' | 'DOCUMENTS' | 'REJECTION_PREVENTION' | 'LOAN_LIMIT' | 'BUSINESS_PLAN' | 'OTHER';
  inquiryDetails: string;
  businessAge?: string;
  creditScoreRange?: string;
  agreedPrivacy: boolean;
  createdAt: string;
  status: 'PENDING' | 'ASSIGNED' | 'CONFIRMED';
  assignedExpert?: {
    name: string;
    role: string;
    agencyExperience: string;
  };
}

interface ExpertConsultationModalProps {
  isOpen: boolean;
  onClose: () => void;
  fund: PolicyFund | SourcePolicy | any | null;
  profile?: UserProfile | null;
  token?: string | null;
  onSubmitSuccess?: (requestData: ConsultationRequestData) => void;
}

// Default Official Consultation Google Form URL
const DEFAULT_CONSULTATION_FORM_URL = "https://docs.google.com/forms/d/e/1FAIpQLSd9YV7x8w4r5q1a7X8q-SAMPLE_BIZMATCH/viewform?embedded=true";

// Pre-configured Google Forms Templates
const PRESET_FORMS = [
  {
    id: 'default',
    title: '1:1 비대면 전문상담 접수 폼 (기본)',
    url: 'https://docs.google.com/forms/d/e/1FAIpQLSd9YV7x8w4r5q1a7X8q-SAMPLE_BIZMATCH/viewform?embedded=true',
    desc: '사업자 기본정보, 희망 한도 및 상담 일시 접수'
  },
  {
    id: 'eligibility',
    title: '정책자금 신청 전 자격 자가진단표',
    url: 'https://docs.google.com/forms/d/e/1FAIpQLScX9K8w7r4q3a2b1-SAMPLE_ELIGIBILITY/viewform?embedded=true',
    desc: '신용점수, 국세 완납, 보증재단 이용이력 사전 검증'
  },
  {
    id: 'survey',
    title: '추천 정책자금 만족도 및 종합 설문',
    url: 'https://docs.google.com/forms/d/e/1FAIpQLSeZ1a2b3c4d5e6f7-SAMPLE_FEEDBACK/viewform?embedded=true',
    desc: '알고리즘 추천 결과 및 필요 자금 피드백 수집'
  }
];

export const ExpertConsultationModal: React.FC<ExpertConsultationModalProps> = ({
  isOpen,
  onClose,
  fund,
  profile,
  token,
  onSubmitSuccess
}) => {
  const fundTitle = fund ? ('title' in fund ? fund.title : fund.name) : '';
  const fundAgency = fund ? fund.agency : '정책금융기관';
  const fundMaxAmount = fund ? ('maxAmount' in fund ? fund.maxAmount : '') : '';
  const fundInterestRate = fund ? ('interestRate' in fund ? fund.interestRate : (fund.baseInterestRate || '')) : '';

  // Mode: standard direct form vs embedded Google Form
  const [activeMode, setActiveMode] = useState<'direct' | 'google_forms'>('direct');

  // Form states initialized with user profile data if available
  const [applicantName, setApplicantName] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [email, setEmail] = useState('');
  const [preferredChannel, setPreferredChannel] = useState<'CALL' | 'VIDEO' | 'CHAT'>('CALL');
  
  // Default tomorrow date for preferred date
  const [preferredDate, setPreferredDate] = useState(() => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split('T')[0];
  });
  
  const [preferredTimeSlot, setPreferredTimeSlot] = useState<'MORNING' | 'AFTERNOON' | 'EVENING' | 'ANYTIME'>('AFTERNOON');
  const [inquiryCategory, setInquiryCategory] = useState<'ELIGIBILITY' | 'DOCUMENTS' | 'REJECTION_PREVENTION' | 'LOAN_LIMIT' | 'BUSINESS_PLAN' | 'OTHER'>('ELIGIBILITY');
  const [inquiryDetails, setInquiryDetails] = useState('');
  const [agreedPrivacy, setAgreedPrivacy] = useState(true);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [submittedData, setSubmittedData] = useState<ConsultationRequestData | null>(null);
  const [errorMessage, setErrorMessage] = useState('');

  // Google Forms Embedded iframe states
  const [googleFormUrl, setGoogleFormUrl] = useState<string>(() => {
    try {
      const customUrl = localStorage.getItem('bizmatch_consultation_gform_url');
      return customUrl || DEFAULT_CONSULTATION_FORM_URL;
    } catch {
      return DEFAULT_CONSULTATION_FORM_URL;
    }
  });
  const [customUrlInput, setCustomUrlInput] = useState<string>('');
  const [isEditingUrl, setIsEditingUrl] = useState(false);
  const [urlSuccessToast, setUrlSuccessToast] = useState<string | null>(null);
  const [urlError, setUrlError] = useState<string | null>(null);
  const [isIframeLoading, setIsIframeLoading] = useState(true);
  const [iframeKey, setIframeKey] = useState<number>(1);
  const [isCreatingWorkspaceForm, setIsCreatingWorkspaceForm] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [savedForms, setSavedForms] = useState<GoogleFormInfo[]>([]);

  // Format URL helper to ensure embedded=true & handle raw iframe tags, edit links, responder links
  const normalizeGoogleFormUrl = (rawUrl: string): string => {
    if (!rawUrl) return '';
    let clean = rawUrl.trim();

    // 1. If user pasted an HTML embed tag: <iframe src="https://..."></iframe>
    const srcMatch = clean.match(/src=["']([^"']+)["']/i);
    if (srcMatch && srcMatch[1]) {
      clean = srcMatch[1];
    }

    // 2. If it is an edit link: .../edit or .../edit#responses
    if (clean.includes('/edit')) {
      clean = clean.replace(/\/edit(#.*)?$/, '/viewform');
    }

    // 3. Ensure embedded=true is appended
    if (!clean.includes('embedded=true')) {
      clean += (clean.includes('?') ? '&' : '?') + 'embedded=true';
    }
    return clean;
  };

  const formatEmbedUrl = (url: string) => normalizeGoogleFormUrl(url);

  // Sync profile & saved forms when opened
  useEffect(() => {
    if (isOpen) {
      setIsSubmitted(false);
      setErrorMessage('');
      setIsIframeLoading(true);

      // Load saved forms from localStorage
      try {
        const storedForms = localStorage.getItem('bizmatch_google_forms_history_v1');
        if (storedForms) {
          const list: GoogleFormInfo[] = JSON.parse(storedForms);
          setSavedForms(list);
          // If there's a saved form created recently, offer it
          if (list.length > 0 && googleFormUrl === DEFAULT_CONSULTATION_FORM_URL) {
            setGoogleFormUrl(formatEmbedUrl(list[0].responderUri));
          }
        }
      } catch (e) {
        console.error('Failed to load saved forms', e);
      }

      if (profile) {
        setApplicantName(profile.representativeName || profile.name || '');
        setBusinessName(profile.businessName || '');
        setContactNumber(profile.phoneNumber || profile.contactNumber || '');
        setEmail(profile.email || '');
      }
      // Pre-fill smart inquiry details
      if (!inquiryDetails && fundTitle) {
        setInquiryDetails(`'${fundTitle}' 자금에 대해 당사 업종 및 재무 조건에서 최종 승인 가능성과 필수 서류 구비 요령에 대해 전문 심사역의 비대면 컨설팅을 요청드립니다.`);
      }
    }
  }, [isOpen, profile, fundTitle]);

  if (!isOpen || !fund) return null;

  const handleCopyFormUrl = () => {
    const cleanUrl = googleFormUrl.replace('?embedded=true', '').replace('&embedded=true', '');
    navigator.clipboard.writeText(cleanUrl);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2500);
  };

  const handleApplyCustomUrl = (e?: React.FormEvent, directUrl?: string) => {
    if (e) e.preventDefault();
    setUrlError(null);

    const targetUrl = directUrl !== undefined ? directUrl : customUrlInput;
    if (!targetUrl || !targetUrl.trim()) {
      setUrlError('구글 폼 URL 또는 임베드 코드를 입력해 주세요.');
      return;
    }

    const trimmed = targetUrl.trim();
    if (!trimmed.includes('docs.google.com/forms') && !trimmed.includes('forms.gle')) {
      setUrlError('유효한 Google Forms 주소(docs.google.com/forms 또는 forms.gle)를 입력해 주세요.');
      return;
    }

    const normalized = normalizeGoogleFormUrl(trimmed);
    setGoogleFormUrl(normalized);
    setCustomUrlInput(normalized.replace('?embedded=true', '').replace('&embedded=true', ''));

    try {
      localStorage.setItem('bizmatch_consultation_gform_url', normalized);
    } catch (e) {}

    setIsEditingUrl(false);
    setIsIframeLoading(true);
    setIframeKey(prev => prev + 1);

    setUrlSuccessToast('구글 폼 URL이 성공적으로 저장 및 적용되었습니다.');
    setTimeout(() => setUrlSuccessToast(null), 3000);
  };

  const handleSelectPreset = (url: string) => {
    handleApplyCustomUrl(undefined, url);
  };

  const handleResetToDefault = () => {
    handleApplyCustomUrl(undefined, DEFAULT_CONSULTATION_FORM_URL);
  };

  // 1-Click Generate Google Form into Google Account
  const handleGenerateLiveGoogleForm = async () => {
    if (!token) {
      alert('Google Workspace 연동 계정 로그인이 필요합니다.');
      return;
    }
    setIsCreatingWorkspaceForm(true);
    setUrlError(null);
    try {
      const created = await createConsultationIntakeForm(token, businessName || profile?.businessName || applicantName);
      const embedUrl = normalizeGoogleFormUrl(created.responderUri);
      setGoogleFormUrl(embedUrl);
      try {
        localStorage.setItem('bizmatch_consultation_gform_url', embedUrl);
        const updatedList = [created, ...savedForms.filter(f => f.formId !== created.formId)];
        localStorage.setItem('bizmatch_google_forms_history_v1', JSON.stringify(updatedList));
        setSavedForms(updatedList);
      } catch (e) {}
      setIsIframeLoading(true);
      setIframeKey(prev => prev + 1);
      setUrlSuccessToast(`대표님의 Google 계정에 [${created.title}] 폼이 자동 생성되어 연결되었습니다.`);
      setTimeout(() => setUrlSuccessToast(null), 4000);
    } catch (err: any) {
      setUrlError(`Google Form 자동 생성 실패: ${err.message || err}`);
    } finally {
      setIsCreatingWorkspaceForm(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!applicantName.trim()) {
      setErrorMessage('신청자(대표자) 성함을 입력해 주세요.');
      return;
    }
    if (!contactNumber.trim()) {
      setErrorMessage('상담 안내를 수신할 연락처(휴대폰 번호)를 입력해 주세요.');
      return;
    }
    if (!agreedPrivacy) {
      setErrorMessage('개인정보 수집 및 상담 매칭 이용 약관에 동의해 주세요.');
      return;
    }

    setIsSubmitting(true);

    const newRequest: ConsultationRequestData = {
      id: `consult-${Date.now()}`,
      fundTitle,
      fundAgency,
      fundMaxAmount,
      fundInterestRate,
      applicantName: applicantName.trim(),
      businessName: businessName.trim() || '사업체명 미기재',
      contactNumber: contactNumber.trim(),
      email: email.trim(),
      preferredChannel,
      preferredDate,
      preferredTimeSlot,
      inquiryCategory,
      inquiryDetails: inquiryDetails.trim() || '상세 문의사항 없음',
      businessAge: profile?.businessAge ? `${profile.businessAge}년` : undefined,
      creditScoreRange: profile?.creditScore ? `${profile.creditScore}점` : undefined,
      agreedPrivacy,
      createdAt: new Date().toISOString(),
      status: 'PENDING',
      assignedExpert: {
        name: '정우진 수석 정책지도사',
        role: '중진공·소진공 자금 심사 12년 경력',
        agencyExperience: `${fundAgency} 전담 배정`
      }
    };

    // Save to localStorage
    try {
      const stored = localStorage.getItem('bizmatch_expert_consultations');
      const list: ConsultationRequestData[] = stored ? JSON.parse(stored) : [];
      list.unshift(newRequest);
      localStorage.setItem('bizmatch_expert_consultations', JSON.stringify(list));
    } catch (err) {
      console.error('Failed to save consultation request to localStorage', err);
    }

    // Save to Firestore if user is authenticated
    if (auth.currentUser) {
      saveUserConsultation(auth.currentUser.uid, {
        fundTitle,
        fundAgency,
        fundMaxAmount,
        fundInterestRate,
        applicantName: newRequest.applicantName,
        businessName: newRequest.businessName,
        contactNumber: newRequest.contactNumber,
        email: newRequest.email,
        preferredChannel: newRequest.preferredChannel,
        preferredDate: newRequest.preferredDate,
        preferredTimeSlot: newRequest.preferredTimeSlot,
        inquiryCategory: newRequest.inquiryCategory,
        inquiryDetails: newRequest.inquiryDetails,
        googleFormUrl: '',
        submittedVia: 'direct',
        status: 'PENDING',
        assignedExpert: newRequest.assignedExpert
      }).catch(err => console.warn('Firestore direct consultation save error:', err));
    }

    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
      setSubmittedData(newRequest);
      if (onSubmitSuccess) {
        onSubmitSuccess(newRequest);
      }
    }, 600);
  };

  // Record Google Form Submission to Firestore and localStorage
  const handleRecordGoogleFormSubmission = async () => {
    setIsSubmitting(true);
    const applicant = applicantName.trim() || profile?.businessName || '대표자';
    const business = businessName.trim() || profile?.businessName || '사업체';
    const contact = contactNumber.trim() || '구글 폼 기재';
    const mail = email.trim() || auth.currentUser?.email || '';

    const newRequest: ConsultationRequestData = {
      id: `gform-consult-${Date.now()}`,
      fundTitle,
      fundAgency,
      fundMaxAmount,
      fundInterestRate,
      applicantName: applicant,
      businessName: business,
      contactNumber: contact,
      email: mail,
      preferredChannel: 'CHAT',
      preferredDate: new Date().toISOString().split('T')[0],
      preferredTimeSlot: 'ANYTIME',
      inquiryCategory: 'ELIGIBILITY',
      inquiryDetails: `Google Forms 설문지 제출 완료 (${googleFormUrl})`,
      agreedPrivacy: true,
      createdAt: new Date().toISOString(),
      status: 'PENDING',
      assignedExpert: {
        name: '정우진 수석 정책지도사',
        role: '중진공·소진공 자금 심사 12년 경력',
        agencyExperience: `${fundAgency} 전담 배정`
      }
    };

    // Save to localStorage
    try {
      const stored = localStorage.getItem('bizmatch_expert_consultations');
      const list: ConsultationRequestData[] = stored ? JSON.parse(stored) : [];
      list.unshift(newRequest);
      localStorage.setItem('bizmatch_expert_consultations', JSON.stringify(list));
    } catch (err) {
      console.error('Failed to save Google Forms record to localStorage', err);
    }

    // Save to Firestore if authenticated
    if (auth.currentUser) {
      try {
        await saveUserConsultation(auth.currentUser.uid, {
          fundTitle,
          fundAgency,
          fundMaxAmount,
          fundInterestRate,
          applicantName: applicant,
          businessName: business,
          contactNumber: contact,
          email: mail,
          preferredChannel: 'CHAT',
          preferredDate: newRequest.preferredDate,
          preferredTimeSlot: 'ANYTIME',
          inquiryCategory: 'ELIGIBILITY',
          inquiryDetails: `Google Forms 설문지 제출 완료 (${googleFormUrl})`,
          googleFormUrl,
          submittedVia: 'google_forms',
          status: 'PENDING',
          assignedExpert: newRequest.assignedExpert
        });
      } catch (err) {
        console.warn('Firestore Google Forms consultation save error:', err);
      }
    }

    setIsSubmitting(false);
    setUrlSuccessToast('구글 폼 접수 내역이 Firestore 및 대시보드 [문의 내역]에 저장되었습니다!');
    if (onSubmitSuccess) {
      onSubmitSuccess(newRequest);
    }
    setTimeout(() => {
      setUrlSuccessToast(null);
    }, 4500);
  };

  const timeSlotLabel = {
    MORNING: '오전 10:00 ~ 12:00',
    AFTERNOON: '오후 14:00 ~ 17:00',
    EVENING: '저녁 18:00 ~ 20:00 (야간)',
    ANYTIME: '상담사 가능 시간 (조율)'
  };

  const channelLabel = {
    CALL: '유선 전화 상담',
    VIDEO: '비대면 화상 상담 (Zoom/Meet)',
    CHAT: '1:1 실시간 카카오톡/채팅'
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-900/60 backdrop-blur-xs overflow-y-auto animate-fade-in no-print">
      <div className="relative w-full max-w-3xl bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden my-4 flex flex-col max-h-[92vh]">
        
        {/* Modal Top Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-900 text-white p-5 sm:p-6 relative shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-5 right-5 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all cursor-pointer"
            title="닫기"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-2">
            <span className="px-2.5 py-1 rounded-lg bg-indigo-500/30 border border-indigo-400/40 text-indigo-200 text-xs font-black flex items-center gap-1.5">
              <Headphones className="w-3.5 h-3.5 text-indigo-300" />
              1:1 비대면 정책자금 전문 컨설팅
            </span>
            <span className="text-[11px] text-slate-300 font-bold bg-white/10 px-2.5 py-0.5 rounded-full">
              무료 사전 매칭
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
            전문가에게 상담 문의하기
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 font-medium mt-1 leading-relaxed">
            해당 자금의 실제 심사 통과 요건, 서류 반려 방지 팁, 맞춤 전략에 대해 공인 정책지도사의 1:1 조언을 받으실 수 있습니다.
          </p>

          {/* Selected Fund Summary Pill */}
          <div className="mt-3.5 p-3 rounded-2xl bg-white/10 backdrop-blur-md border border-white/15 flex items-center justify-between gap-3 flex-wrap sm:flex-nowrap">
            <div className="min-w-0">
              <span className="text-[10px] font-black uppercase text-indigo-200 block">
                상담 신청 대상 정책자금
              </span>
              <h3 className="text-sm font-black text-white truncate">
                {fundTitle}
              </h3>
            </div>
            <div className="flex items-center gap-2 shrink-0">
              <span className="text-xs font-black px-2.5 py-1 rounded-xl bg-blue-500/30 text-blue-200 border border-blue-400/30">
                {fundAgency}
              </span>
              {fundMaxAmount && (
                <span className="text-xs font-black px-2.5 py-1 rounded-xl bg-emerald-500/30 text-emerald-200 border border-emerald-400/30">
                  {fundMaxAmount}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Mode Selector Tabs */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 shrink-0">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setActiveMode('direct')}
              className={`py-3.5 px-4 text-xs font-black border-b-2 flex items-center gap-1.5 transition-all cursor-pointer ${
                activeMode === 'direct'
                  ? 'border-indigo-600 text-indigo-700 bg-white shadow-xs'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Send className="w-3.5 h-3.5" />
              <span>간편 상담 신청 (기본)</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveMode('google_forms')}
              className={`py-3.5 px-4 text-xs font-black border-b-2 flex items-center gap-1.5 transition-all cursor-pointer ${
                activeMode === 'google_forms'
                  ? 'border-purple-600 text-purple-700 bg-white shadow-xs'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <ClipboardCheck className="w-4 h-4 text-purple-600" />
              <span className="flex items-center gap-1.5">
                Google Forms 직접 전송 (내장)
                <span className="px-1.5 py-0.2 rounded-md bg-purple-100 text-purple-700 text-[10px] font-extrabold">
                  iframe
                </span>
              </span>
            </button>
          </div>

          {activeMode === 'google_forms' && (
            <div className="hidden sm:flex items-center gap-2 text-xs font-bold text-slate-500">
              <Globe className="w-3.5 h-3.5 text-purple-500" />
              <span>실시간 구글 시트·설문 연동</span>
            </div>
          )}
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-7 overflow-y-auto flex-1">
          
          {/* MODE 1: DIRECT APPLICATION FORM */}
          {activeMode === 'direct' && (
            <>
              {isSubmitted && submittedData ? (
                /* Submission Success View */
                <div className="text-center py-6 space-y-6 animate-fade-in">
                  <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto shadow-inner">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>

                  <div className="space-y-2">
                    <h3 className="text-2xl font-black text-slate-900">
                      비대면 상담 예약이 접수되었습니다!
                    </h3>
                    <p className="text-xs sm:text-sm text-slate-600 font-medium max-w-md mx-auto leading-relaxed">
                      대표님의 사업장 기본 정보와 요청하신 문의 내용을 토대로 <br className="hidden sm:inline" />
                      <strong>{fundAgency} 전문 정책지도사</strong>가 배정되었습니다.
                    </p>
                  </div>

                  {/* Consultation Summary Card */}
                  <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-5 text-left space-y-3.5 text-xs max-w-lg mx-auto">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                      <span className="text-slate-500 font-bold">배정 전문가</span>
                      <div className="text-right">
                        <span className="font-black text-slate-900 block">{submittedData.assignedExpert?.name}</span>
                        <span className="text-[11px] text-indigo-600 font-bold">{submittedData.assignedExpert?.role}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 font-bold">상담 방식</span>
                      <span className="font-black text-slate-900 bg-white px-2.5 py-1 rounded-lg border border-slate-200">
                        {channelLabel[submittedData.preferredChannel]}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 font-bold">희망 일시</span>
                      <span className="font-black text-slate-900">
                        {submittedData.preferredDate} ({timeSlotLabel[submittedData.preferredTimeSlot]})
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 font-bold">안내 연락처</span>
                      <span className="font-black text-blue-700">{submittedData.contactNumber}</span>
                    </div>

                    <div className="pt-2 border-t border-slate-200">
                      <span className="text-slate-500 font-bold block mb-1">요청 문의 요약</span>
                      <p className="text-slate-800 font-medium bg-white p-3 rounded-xl border border-slate-100 leading-relaxed">
                        {submittedData.inquiryDetails}
                      </p>
                    </div>
                  </div>

                  <div className="bg-blue-50/80 border border-blue-200/80 p-4 rounded-2xl text-xs text-blue-900 flex items-start gap-3 max-w-lg mx-auto text-left">
                    <Sparkles className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-black block">향후 진행 안내</span>
                      <p className="mt-0.5 text-blue-800 leading-relaxed">
                        영업일 기준 2시간 이내에 담당 상담역이 사전 서류 검토 안내 메시지(카카오 알림톡/문자)를 발송 후 지정하신 시간에 연락드립니다.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center justify-center gap-3 pt-2">
                    <button
                      type="button"
                      onClick={onClose}
                      className="px-6 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-black text-xs shadow-md transition-all cursor-pointer"
                    >
                      확인 및 닫기
                    </button>
                  </div>
                </div>
              ) : (
                /* Application Form */
                <form onSubmit={handleSubmit} className="space-y-6">
                  {errorMessage && (
                    <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center gap-2 animate-fade-in">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>{errorMessage}</span>
                    </div>
                  )}

                  {/* 1. Applicant & Business Info */}
                  <div className="space-y-3">
                    <label className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-indigo-600" />
                      신청 대표자 및 사업체 기본 정보
                    </label>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] font-bold text-slate-500 block mb-1">
                          대표자 성함 <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="예: 홍길동"
                          value={applicantName}
                          onChange={(e) => setApplicantName(e.target.value)}
                          className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-slate-900"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-bold text-slate-500 block mb-1">
                          상호 / 사업체명
                        </label>
                        <input
                          type="text"
                          placeholder="예: (주)비즈솔루션"
                          value={businessName}
                          onChange={(e) => setBusinessName(e.target.value)}
                          className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-slate-900"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-bold text-slate-500 block mb-1">
                          연락처(휴대폰) <span className="text-rose-500">*</span>
                        </label>
                        <input
                          type="tel"
                          required
                          placeholder="예: 010-1234-5678"
                          value={contactNumber}
                          onChange={(e) => setContactNumber(e.target.value)}
                          className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-slate-900"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-bold text-slate-500 block mb-1">
                          이메일 (안내문 수신용)
                        </label>
                        <input
                          type="email"
                          placeholder="예: ceo@company.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium text-slate-900"
                        />
                      </div>
                    </div>
                  </div>

                  {/* 2. Preferred Consultation Channel & Schedule */}
                  <div className="space-y-3">
                    <label className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-indigo-600" />
                      희망 상담 방식 및 시간대 선택
                    </label>

                    {/* Channels */}
                    <div className="grid grid-cols-3 gap-2.5">
                      {[
                        { id: 'CALL', label: '전화 상담', desc: '담당 심사역 직통 통화', icon: PhoneCall },
                        { id: 'VIDEO', label: '화상 상담', desc: '화면 공유 및 서류 검토', icon: Video },
                        { id: 'CHAT', label: '1:1 채팅', desc: '카카오톡/문자 질의응답', icon: MessagesSquare },
                      ].map((ch) => {
                        const Icon = ch.icon;
                        const isSelected = preferredChannel === ch.id;
                        return (
                          <button
                            key={ch.id}
                            type="button"
                            onClick={() => setPreferredChannel(ch.id as any)}
                            className={`p-3 rounded-2xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                              isSelected
                                ? 'bg-indigo-50/80 border-indigo-500 text-indigo-950 ring-2 ring-indigo-200 shadow-xs'
                                : 'bg-white border-slate-200 text-slate-700 hover:border-slate-300'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-1.5">
                              <Icon className={`w-4 h-4 ${isSelected ? 'text-indigo-600' : 'text-slate-400'}`} />
                              {isSelected && <BadgeCheck className="w-4 h-4 text-indigo-600" />}
                            </div>
                            <div>
                              <span className="text-xs font-black block">{ch.label}</span>
                              <span className="text-[10px] text-slate-500 block mt-0.5 leading-tight">{ch.desc}</span>
                            </div>
                          </button>
                        );
                      })}
                    </div>

                    {/* Schedule Inputs */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                      <div>
                        <label className="text-[11px] font-bold text-slate-500 block mb-1">
                          희망 상담 일자
                        </label>
                        <input
                          type="date"
                          value={preferredDate}
                          onChange={(e) => setPreferredDate(e.target.value)}
                          className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-slate-900"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-bold text-slate-500 block mb-1">
                          희망 상담 시간대
                        </label>
                        <select
                          value={preferredTimeSlot}
                          onChange={(e) => setPreferredTimeSlot(e.target.value as any)}
                          className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-bold text-slate-900 cursor-pointer"
                        >
                          <option value="MORNING">오전 (10:00 ~ 12:00)</option>
                          <option value="AFTERNOON">오후 (14:00 ~ 17:00)</option>
                          <option value="EVENING">저녁 야간 (18:00 ~ 20:00)</option>
                          <option value="ANYTIME">언제든 가능 (빠른 배정)</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* 3. Inquiry Category & Question Detail */}
                  <div className="space-y-3">
                    <label className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                      <HelpCircle className="w-3.5 h-3.5 text-indigo-600" />
                      중점 상담 문의 분야
                    </label>

                    <div className="flex flex-wrap gap-1.5">
                      {[
                        { id: 'ELIGIBILITY', label: '자격 요건 충족 여부' },
                        { id: 'REJECTION_PREVENTION', label: '부결 사유 방지 및 예방' },
                        { id: 'DOCUMENTS', label: '필수 제출 서류 발급 코칭' },
                        { id: 'LOAN_LIMIT', label: '최대 대출 한도 산출' },
                        { id: 'BUSINESS_PLAN', label: '사업계획서 작성 요령' },
                        { id: 'OTHER', label: '기타 종합 문의' },
                      ].map((cat) => (
                        <button
                          key={cat.id}
                          type="button"
                          onClick={() => setInquiryCategory(cat.id as any)}
                          className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition-all cursor-pointer ${
                            inquiryCategory === cat.id
                              ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                              : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
                          }`}
                        >
                          {cat.label}
                        </button>
                      ))}
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-slate-500 block mb-1">
                        상세 문의 내용 및 특이사항
                      </label>
                      <textarea
                        rows={3}
                        placeholder="현재 사업장 상황(업력, 매출, 기대출 건수 등)이나 특히 궁금하신 점을 작성해 주시면 더욱 정확한 솔루션을 준비합니다."
                        value={inquiryDetails}
                        onChange={(e) => setInquiryDetails(e.target.value)}
                        className="w-full px-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 font-medium text-slate-800 leading-relaxed"
                      />
                    </div>
                  </div>

                  {/* 4. Privacy Consent & Benefit Checklist */}
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/70 space-y-2.5">
                    <div className="flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="text-xs font-black text-slate-900">전문가 사전 검토 무료 보증</span>
                    </div>
                    <ul className="text-[11px] text-slate-600 font-medium space-y-1 pl-6 list-disc">
                      <li>상담 신청 시 별도의 컨설팅 수수료나 중개비가 일절 발생하지 않습니다.</li>
                      <li>국가 공인 경영지도사 및 정책금융기관 퇴직 심사역이 1:1 매칭됩니다.</li>
                    </ul>

                    <label className="flex items-center gap-2 pt-2 border-t border-slate-200/80 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={agreedPrivacy}
                        onChange={(e) => setAgreedPrivacy(e.target.checked)}
                        className="w-4 h-4 text-indigo-600 rounded-md border-slate-300 focus:ring-indigo-500 cursor-pointer"
                      />
                      <span className="text-xs font-bold text-slate-700">
                        [필수] 비대면 상담 진행을 위한 개인정보 수집 및 매칭 안내에 동의합니다.
                      </span>
                    </label>
                  </div>

                  {/* Bottom Action Buttons */}
                  <div className="flex items-center justify-end gap-3 pt-2">
                    <button
                      type="button"
                      onClick={onClose}
                      className="px-5 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
                    >
                      취소
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="px-7 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white font-black text-xs shadow-lg shadow-indigo-500/25 transition-all active:scale-95 flex items-center gap-2 cursor-pointer disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <>
                          <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                          <span>신청 접수 중...</span>
                        </>
                      ) : (
                        <>
                          <Send className="w-3.5 h-3.5" />
                          <span>비대면 상담 신청하기</span>
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </>
          )}

          {/* MODE 2: EMBEDDED GOOGLE FORMS IFRAME */}
          {activeMode === 'google_forms' && (
            <div className="space-y-4 animate-fade-in flex flex-col h-full">
              
              {/* Feedback Alerts */}
              {urlSuccessToast && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center justify-between animate-fade-in">
                  <div className="flex items-center gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span>{urlSuccessToast}</span>
                  </div>
                  <button type="button" onClick={() => setUrlSuccessToast(null)} className="text-emerald-500 hover:text-emerald-700">
                    ✕
                  </button>
                </div>
              )}

              {urlError && (
                <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-bold flex items-center justify-between animate-fade-in">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>{urlError}</span>
                  </div>
                  <button type="button" onClick={() => setUrlError(null)} className="text-rose-500 hover:text-rose-700">
                    ✕
                  </button>
                </div>
              )}

              {/* Google Form Controls Bar */}
              <div className="bg-purple-50/80 border border-purple-200/90 rounded-2xl p-3.5 space-y-3 text-xs">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <div className="flex items-center gap-1.5 font-black text-purple-950">
                      <ClipboardCheck className="w-4 h-4 text-purple-600" />
                      <span>내장 구글 폼 (Google Forms)</span>
                    </div>

                    <span className="px-2 py-0.5 rounded-md bg-purple-200/70 text-purple-900 font-bold text-[10px]">
                      실시간 iframe 임베딩
                    </span>
                  </div>

                  {/* Actions Toolbar */}
                  <div className="flex items-center gap-1.5 self-end sm:self-auto flex-wrap">
                    {token && (
                      <button
                        type="button"
                        onClick={handleGenerateLiveGoogleForm}
                        disabled={isCreatingWorkspaceForm}
                        className="px-2.5 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-[11px] font-black flex items-center gap-1 transition-all shadow-xs cursor-pointer disabled:opacity-50"
                        title="Google 계정에 이 자금 전용 설문지 즉시 생성 후 내장"
                      >
                        {isCreatingWorkspaceForm ? (
                          <RefreshCw className="w-3 h-3 animate-spin" />
                        ) : (
                          <Plus className="w-3 h-3" />
                        )}
                        <span>내 계정 폼 자동 생성</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => {
                        setIsEditingUrl(!isEditingUrl);
                        setCustomUrlInput(googleFormUrl.replace('?embedded=true', '').replace('&embedded=true', ''));
                      }}
                      className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer border ${
                        isEditingUrl
                          ? 'bg-purple-600 text-white border-purple-600'
                          : 'bg-white hover:bg-purple-100 text-purple-800 border-purple-200'
                      }`}
                      title="Google Form URL 직접 설정 및 변경"
                    >
                      <SlidersHorizontal className="w-3 h-3" />
                      <span>URL 설정</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleCopyFormUrl}
                      className="px-2.5 py-1.5 bg-white hover:bg-purple-100 text-purple-800 border border-purple-200 rounded-xl text-[11px] font-bold flex items-center gap-1 transition-colors cursor-pointer"
                      title="설문 링크 복사"
                    >
                      {copiedUrl ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3 text-purple-600" />}
                      <span>{copiedUrl ? '복사됨' : '링크 복사'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setIsIframeLoading(true);
                        setIframeKey(k => k + 1);
                      }}
                      className="p-1.5 bg-white hover:bg-purple-100 text-purple-800 border border-purple-200 rounded-xl transition-colors cursor-pointer"
                      title="iframe 새로고침"
                    >
                      <RefreshCw className="w-3.5 h-3.5 text-purple-600" />
                    </button>

                    <a
                      href={googleFormUrl.replace('?embedded=true', '').replace('&embedded=true', '')}
                      target="_blank"
                      rel="noreferrer"
                      className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-[11px] font-bold flex items-center gap-1 transition-colors"
                      title="새 창에서 구글 폼 열기"
                    >
                      <ExternalLink className="w-3 h-3" />
                      <span>새창 열기</span>
                    </a>
                  </div>
                </div>

                {/* Preset Quick Tabs */}
                <div className="flex items-center gap-1.5 flex-wrap pt-1 border-t border-purple-200/60">
                  <span className="text-[11px] font-bold text-purple-900 mr-1">추천 설문 템플릿:</span>
                  {PRESET_FORMS.map((preset) => {
                    const isCurrent = googleFormUrl === preset.url;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => handleSelectPreset(preset.url)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer border ${
                          isCurrent
                            ? 'bg-purple-600 text-white border-purple-600 shadow-xs'
                            : 'bg-white text-purple-800 border-purple-200 hover:bg-purple-100/80'
                        }`}
                        title={preset.desc}
                      >
                        {preset.title}
                      </button>
                    );
                  })}

                  {savedForms.length > 0 && (
                    <select
                      value={googleFormUrl}
                      onChange={(e) => handleApplyCustomUrl(undefined, e.target.value)}
                      className="px-2.5 py-1 bg-white border border-purple-300 rounded-lg text-[11px] font-bold text-purple-900 focus:outline-none focus:ring-1 focus:ring-purple-500 cursor-pointer max-w-[200px] truncate ml-auto"
                    >
                      <option value="" disabled>내 계정 저장 폼 ({savedForms.length}개)</option>
                      {savedForms.map(f => (
                        <option key={f.formId} value={formatEmbedUrl(f.responderUri)}>
                          {f.title}
                        </option>
                      ))}
                    </select>
                  )}
                </div>
              </div>

              {/* Custom URL Input & Dynamic Config Form */}
              {isEditingUrl && (
                <form onSubmit={(e) => handleApplyCustomUrl(e)} className="bg-white border-2 border-purple-300 rounded-2xl p-4 shadow-sm space-y-3 animate-fade-in">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                      <FileSpreadsheet className="w-4 h-4 text-purple-600" />
                      <span>Google Forms URL / 임베드 태그 입력 및 동적 연결</span>
                    </label>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={handleResetToDefault}
                        className="text-[11px] font-bold text-slate-500 hover:text-purple-600 underline cursor-pointer"
                      >
                        기본 폼으로 초기화
                      </button>
                      <button
                        type="button"
                        onClick={() => setIsEditingUrl(false)}
                        className="text-xs text-slate-400 hover:text-slate-600 ml-2"
                      >
                        닫기
                      </button>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                    <input
                      type="text"
                      required
                      placeholder="예: https://docs.google.com/forms/d/e/.../viewform 또는 <iframe src=...></iframe>"
                      value={customUrlInput}
                      onChange={(e) => setCustomUrlInput(e.target.value)}
                      className="flex-1 px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono text-slate-900 focus:bg-white focus:outline-none focus:ring-2 focus:ring-purple-500 font-medium"
                    />
                    <button
                      type="submit"
                      className="px-5 py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-black text-xs rounded-xl transition-all shadow-md shadow-purple-500/20 active:scale-95 cursor-pointer shrink-0"
                    >
                      URL 저장 및 즉시 반영
                    </button>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-[11px] text-slate-600 space-y-1">
                    <p className="font-bold text-slate-800">💡 URL 입력 지원 가이드</p>
                    <ul className="list-disc pl-4 space-y-0.5 text-slate-500">
                      <li>Google 설문지 상단 <strong>[보내기] → [링크]</strong>를 복사해 넣으면 자동으로 <code>?embedded=true</code> 형식으로 변환됩니다.</li>
                      <li><strong>[HTML 삽입 (&lt;&gt;)]</strong> 탭의 <code>&lt;iframe src="..."&gt;</code> 태그 전체를 그대로 붙여넣어도 자동 추출됩니다.</li>
                      <li>설문지 편집 링크(<code>/edit</code>)를 넣어도 실제 응답용 뷰(<code>/viewform</code>)로 자동 전환됩니다.</li>
                    </ul>
                  </div>
                </form>
              )}

              {/* Embedded Google Forms iframe container */}
              <div className="relative w-full rounded-2xl border border-slate-200 bg-slate-50 overflow-hidden min-h-[500px] sm:min-h-[560px] flex flex-col shadow-inner">
                {/* Loading indicator */}
                {isIframeLoading && (
                  <div className="absolute inset-0 bg-slate-50/90 backdrop-blur-xs flex flex-col items-center justify-center gap-3 z-10">
                    <div className="w-9 h-9 border-3 border-purple-600 border-t-transparent rounded-full animate-spin" />
                    <p className="text-xs font-bold text-purple-900">Google Forms 설문지를 안전하게 렌더링하는 중입니다...</p>
                  </div>
                )}

                <iframe
                  key={iframeKey}
                  src={googleFormUrl}
                  width="100%"
                  height="100%"
                  frameBorder="0"
                  marginHeight={0}
                  marginWidth={0}
                  onLoad={() => setIsIframeLoading(false)}
                  className="w-full flex-1 min-h-[500px] sm:min-h-[560px] bg-white"
                  title={`Google Forms - ${fundTitle} 상담 신청`}
                >
                  로드 중...
                </iframe>
              </div>

              {/* Info notice & bottom action */}
              <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3 px-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                <div className="flex items-center gap-2 text-slate-600">
                  <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>
                    Google Forms 설문 제출 후 아래 <strong>[제출 기록 저장]</strong>을 클릭하면 Firestore 및 대시보드 [문의 내역]에 자동 보관됩니다.
                  </span>
                </div>

                <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto justify-end">
                  <button
                    type="button"
                    onClick={handleRecordGoogleFormSubmission}
                    disabled={isSubmitting}
                    className="px-4 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white rounded-xl font-black text-xs transition-all shadow-md shadow-purple-500/20 active:scale-95 cursor-pointer flex items-center gap-1.5 disabled:opacity-50"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-300" />
                    <span>구글 폼 제출 완료 & 내역 저장</span>
                  </button>

                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-black text-xs transition-colors cursor-pointer shrink-0"
                  >
                    닫기
                  </button>
                </div>
              </div>

            </div>
          )}

        </div>
      </div>
    </div>
  );
};

