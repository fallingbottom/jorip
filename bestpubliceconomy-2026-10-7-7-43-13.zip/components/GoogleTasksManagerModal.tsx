import React, { useState, useEffect } from 'react';
import { 
  X, 
  CheckSquare, 
  Square, 
  Plus, 
  Calendar, 
  Trash2, 
  Edit3, 
  Loader2, 
  ListTodo, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  RefreshCw,
  FolderPlus,
  Clock,
  ArrowRight
} from 'lucide-react';
import { 
  fetchGoogleTaskLists, 
  createGoogleTaskList, 
  fetchGoogleTasks, 
  createGoogleTask, 
  updateGoogleTaskStatus, 
  updateGoogleTask, 
  deleteGoogleTask, 
  exportPolicyFundChecklistToGoogleTasks,
  GoogleTaskList, 
  GoogleTask 
} from '../services/workspaceService';
import { PolicyFund, UserProfile } from '../types';

interface GoogleTasksManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  token?: string | null;
  profile?: UserProfile | null;
  targetFund?: PolicyFund | null;
  checklistItems?: string[];
}

export const GoogleTasksManagerModal: React.FC<GoogleTasksManagerModalProps> = ({
  isOpen,
  onClose,
  token,
  profile,
  targetFund,
  checklistItems
}) => {
  const [taskLists, setTaskLists] = useState<GoogleTaskList[]>([]);
  const [selectedListId, setSelectedListId] = useState<string>('@default');
  const [tasks, setTasks] = useState<GoogleTask[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  // New Task form state
  const [isAddFormOpen, setIsAddFormOpen] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskNotes, setNewTaskNotes] = useState('');
  const [newTaskDue, setNewTaskDue] = useState('');
  const [isSubmittingTask, setIsSubmittingTask] = useState(false);

  // Edit Task state
  const [editingTask, setEditingTask] = useState<GoogleTask | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [editNotes, setEditNotes] = useState('');
  const [editDue, setEditDue] = useState('');

  // New List form state
  const [isNewListOpen, setIsNewListOpen] = useState(false);
  const [newListName, setNewListName] = useState('');
  const [isCreatingList, setIsCreatingList] = useState(false);

  // Destructive Delete Confirmation State (MANDATORY per skill directives)
  const [deleteTarget, setDeleteTarget] = useState<GoogleTask | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Fast-track Fund Checklist Export State
  const [isExportingChecklist, setIsExportingChecklist] = useState(false);
  const [feedbackToast, setFeedbackToast] = useState<string | null>(null);

  const loadLists = async () => {
    if (!token) return;
    try {
      const lists = await fetchGoogleTaskLists(token);
      setTaskLists(lists);
      if (lists.length > 0 && selectedListId === '@default') {
        setSelectedListId(lists[0].id);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const loadTasks = async (listId: string) => {
    if (!token) return;
    setIsLoading(true);
    try {
      const data = await fetchGoogleTasks(token, listId);
      setTasks(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && token) {
      loadLists();
    }
  }, [isOpen, token]);

  useEffect(() => {
    if (isOpen && token && selectedListId) {
      loadTasks(selectedListId);
    }
  }, [isOpen, token, selectedListId]);

  const handleToggleTaskStatus = async (task: GoogleTask) => {
    if (!token) return;
    const isNowCompleted = task.status !== 'completed';
    // Optimistic UI update
    setTasks(prev => prev.map(t => t.id === task.id ? { ...t, status: isNowCompleted ? 'completed' : 'needsAction' } : t));
    try {
      await updateGoogleTaskStatus(token, selectedListId, task.id, isNowCompleted);
    } catch (err) {
      console.error(err);
      // Revert on error
      loadTasks(selectedListId);
    }
  };

  const handleCreateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !newTaskTitle.trim()) return;
    setIsSubmittingTask(true);
    try {
      const created = await createGoogleTask(token, selectedListId, {
        title: newTaskTitle.trim(),
        notes: newTaskNotes.trim() || undefined,
        due: newTaskDue || undefined
      });
      setTasks(prev => [created, ...prev]);
      setNewTaskTitle('');
      setNewTaskNotes('');
      setNewTaskDue('');
      setIsAddFormOpen(false);
      setFeedbackToast('할 일이 Google Tasks에 등록되었습니다.');
      setTimeout(() => setFeedbackToast(null), 3000);
    } catch (err: any) {
      alert(err.message || '할 일 등록에 실패했습니다.');
    } finally {
      setIsSubmittingTask(false);
    }
  };

  const handleCreateList = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !newListName.trim()) return;
    setIsCreatingList(true);
    try {
      const created = await createGoogleTaskList(token, newListName.trim());
      setTaskLists(prev => [created, ...prev]);
      setSelectedListId(created.id);
      setNewListName('');
      setIsNewListOpen(false);
      setFeedbackToast(`'${created.title}' 할 일 목록이 생성되었습니다.`);
      setTimeout(() => setFeedbackToast(null), 3000);
    } catch (err: any) {
      alert(err.message || '목록 생성에 실패했습니다.');
    } finally {
      setIsCreatingList(false);
    }
  };

  const handleUpdateTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !editingTask || !editTitle.trim()) return;
    try {
      const updated = await updateGoogleTask(token, selectedListId, editingTask.id, {
        title: editTitle.trim(),
        notes: editNotes.trim() || undefined,
        due: editDue || undefined
      });
      setTasks(prev => prev.map(t => t.id === updated.id ? updated : t));
      setEditingTask(null);
      setFeedbackToast('할 일이 수정되었습니다.');
      setTimeout(() => setFeedbackToast(null), 3000);
    } catch (err: any) {
      alert(err.message || '할 일 수정에 실패했습니다.');
    }
  };

  // Explicit user confirmation for destructive delete
  const handleConfirmDelete = async () => {
    if (!token || !deleteTarget) return;
    setIsDeleting(true);
    try {
      await deleteGoogleTask(token, selectedListId, deleteTarget.id);
      setTasks(prev => prev.filter(t => t.id !== deleteTarget.id));
      setFeedbackToast(`'${deleteTarget.title}' 할 일이 Google Tasks에서 영구 삭제되었습니다.`);
      setDeleteTarget(null);
      setTimeout(() => setFeedbackToast(null), 3000);
    } catch (err: any) {
      alert(err.message || '삭제에 실패했습니다.');
    } finally {
      setIsDeleting(false);
    }
  };

  // One-click Export fund checklist to Google Tasks
  const handleExportFundChecklist = async () => {
    if (!token || !targetFund) return;
    setIsExportingChecklist(true);
    try {
      const fundDocs = targetFund.requiredDocuments || [];
      const defaultTasks = [
        { title: `[${targetFund.title}] 사업자등록증명 및 부가세과세표준증명 발급`, notes: '홈택스에서 최근 3개년 발급' },
        { title: `[${targetFund.title}] 국세·지방세 완납증명서 확인`, notes: '신청 당일 체납 여부 사전 해소 필수' },
        { title: `[${targetFund.title}] 정책자금 융자신청서 및 사업계획서 작성`, notes: '소진공/신보 표준 서식 온라인 작성' },
        { title: `[${targetFund.title}] 대표자 본인인증 및 비대면 서류 접수`, notes: `${targetFund.applicationUrl || '소상공인정책자금 누리집'}` }
      ];

      const customItems = (checklistItems || []).map(name => ({
        title: `[${targetFund.title}] ${name}`,
        notes: `${targetFund.agency} 제출 서류`
      }));

      const finalTasks = customItems.length > 0 ? customItems : defaultTasks;
      const result = await exportPolicyFundChecklistToGoogleTasks(token, targetFund.title, finalTasks);

      await loadLists();
      setSelectedListId(result.taskListId);
      setFeedbackToast(`'${targetFund.title}' 준비 체크리스트 ${result.count}건이 Google Tasks에 동기화되었습니다!`);
      setTimeout(() => setFeedbackToast(null), 3500);
    } catch (err: any) {
      alert(err.message || '체크리스트 내보내기에 실패했습니다.');
    } finally {
      setIsExportingChecklist(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden">
        
        {/* Modal Header */}
        <div className="p-6 bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center text-blue-300 border border-white/10 shadow-inner">
              <CheckSquare className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-black border border-blue-400/30">
                  Google Tasks API 연동
                </span>
                <h2 className="text-xl font-black">Google Tasks 정책자금 할 일 관리</h2>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                구글 계정의 Tasks와 실시간 동기화하여 구비 서류 준비, 마감일 일정, 심사 대응 업무를 체계적으로 체크하세요.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feedback Banner */}
        {feedbackToast && (
          <div className="bg-emerald-50 border-b border-emerald-200 px-6 py-2.5 flex items-center gap-2 text-emerald-800 text-xs font-bold animate-fade-in shrink-0">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{feedbackToast}</span>
          </div>
        )}

        {/* List Selector & Fast Action Bar */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <label className="text-xs font-bold text-slate-600 shrink-0">목록 선택:</label>
            <select
              value={selectedListId}
              onChange={(e) => setSelectedListId(e.target.value)}
              className="px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs font-black text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-2xs"
            >
              {taskLists.map(list => (
                <option key={list.id} value={list.id}>
                  {list.title}
                </option>
              ))}
            </select>

            <button
              onClick={() => setIsNewListOpen(!isNewListOpen)}
              className="p-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-slate-600 hover:text-blue-600 transition-colors cursor-pointer"
              title="새 할 일 목록 만들기"
            >
              <FolderPlus className="w-4 h-4" />
            </button>

            <button
              onClick={() => loadTasks(selectedListId)}
              disabled={isLoading}
              className="p-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-slate-600 transition-colors cursor-pointer"
              title="새로고침"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-blue-600' : ''}`} />
            </button>
          </div>

          <div className="flex items-center gap-2">
            {targetFund && (
              <button
                type="button"
                onClick={handleExportFundChecklist}
                disabled={isExportingChecklist}
                className="px-3 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-black flex items-center gap-1.5 border border-indigo-200 transition-all cursor-pointer shadow-2xs"
              >
                {isExportingChecklist ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5 text-indigo-600" />}
                <span>정책 서류 체크리스트 원클릭 생성</span>
              </button>
            )}

            <button
              type="button"
              onClick={() => setIsAddFormOpen(!isAddFormOpen)}
              className="px-3.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-black flex items-center gap-1.5 shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>새 할 일 등록</span>
            </button>
          </div>
        </div>

        {/* Create New List Dropdown Form */}
        {isNewListOpen && (
          <form onSubmit={handleCreateList} className="p-4 bg-indigo-50/60 border-b border-indigo-100 flex items-center gap-3 animate-fade-in shrink-0">
            <span className="text-xs font-bold text-indigo-900 shrink-0">새 작업 목록:</span>
            <input
              type="text"
              required
              value={newListName}
              onChange={e => setNewListName(e.target.value)}
              placeholder="예: 2026 소진공 직접대출 준비"
              className="flex-1 px-3 py-1.5 bg-white border border-indigo-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-indigo-500"
            />
            <button
              type="submit"
              disabled={isCreatingList}
              className="px-3.5 py-1.5 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-700 cursor-pointer"
            >
              생성
            </button>
            <button
              type="button"
              onClick={() => setIsNewListOpen(false)}
              className="px-2.5 py-1.5 bg-white text-slate-600 text-xs rounded-xl border border-slate-200"
            >
              취소
            </button>
          </form>
        )}

        {/* New Task Inline Form */}
        {isAddFormOpen && (
          <form onSubmit={handleCreateTask} className="p-4 bg-blue-50/60 border-b border-blue-100 space-y-3 animate-fade-in shrink-0 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-black text-blue-950 flex items-center gap-1.5">
                <ListTodo className="w-4 h-4 text-blue-600" />
                Google Tasks 새 작업 추가
              </span>
              <button 
                type="button" 
                onClick={() => setIsAddFormOpen(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <input
                type="text"
                required
                value={newTaskTitle}
                onChange={e => setNewTaskTitle(e.target.value)}
                placeholder="할 일 제목 (예: 국세 완납증명서 발급)"
                className="sm:col-span-2 px-3 py-2 bg-white border border-blue-200 rounded-xl font-medium focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="date"
                value={newTaskDue}
                onChange={e => setNewTaskDue(e.target.value)}
                className="px-3 py-2 bg-white border border-blue-200 rounded-xl font-medium focus:ring-2 focus:ring-blue-500 text-slate-700"
              />
            </div>

            <input
              type="text"
              value={newTaskNotes}
              onChange={e => setNewTaskNotes(e.target.value)}
              placeholder="상세 메모 (예: 홈택스 민원증명 메뉴에서 24시간 즉시 발급)"
              className="w-full px-3 py-2 bg-white border border-blue-200 rounded-xl font-medium focus:ring-2 focus:ring-blue-500"
            />

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsAddFormOpen(false)}
                className="px-3 py-1.5 bg-white text-slate-600 rounded-xl font-bold border border-slate-200"
              >
                취소
              </button>
              <button
                type="submit"
                disabled={isSubmittingTask}
                className="px-4 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-black shadow-xs flex items-center gap-1.5"
              >
                {isSubmittingTask && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <span>Google Tasks에 저장</span>
              </button>
            </div>
          </form>
        )}

        {/* Task List Items Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-3">
          {isLoading && tasks.length === 0 ? (
            <div className="py-20 text-center space-y-3">
              <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto" />
              <p className="text-xs font-bold text-slate-500">Google Tasks 동기화 중...</p>
            </div>
          ) : tasks.length === 0 ? (
            <div className="py-16 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 p-8 space-y-3">
              <CheckSquare className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-sm font-bold text-slate-700">이 목록에 등록된 할 일이 없습니다.</p>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                상단의 [새 할 일 등록] 또는 [정책 서류 체크리스트 원클릭 생성]을 눌러 구글 계정에 작업을 추가해보세요.
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {tasks.map(task => {
                const isCompleted = task.status === 'completed';
                return (
                  <div
                    key={task.id}
                    className={`p-3.5 rounded-2xl border transition-all flex items-start justify-between gap-3 group select-none ${
                      isCompleted 
                        ? 'bg-slate-50/70 border-slate-200 text-slate-400' 
                        : 'bg-white border-slate-200 hover:border-blue-300 hover:shadow-xs'
                    }`}
                  >
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      <button
                        type="button"
                        onClick={() => handleToggleTaskStatus(task)}
                        className="mt-0.5 text-blue-600 hover:text-blue-700 shrink-0 cursor-pointer"
                        title={isCompleted ? '미완료로 변경' : '완료로 표시'}
                      >
                        {isCompleted ? (
                          <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                        ) : (
                          <Square className="w-5 h-5 text-slate-400 hover:text-blue-600" />
                        )}
                      </button>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className={`text-xs font-black truncate block ${isCompleted ? 'line-through text-slate-400' : 'text-slate-900'}`}>
                            {task.title}
                          </span>
                          {task.due && (
                            <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 text-[10px] font-bold border border-amber-200 shrink-0 flex items-center gap-1">
                              <Calendar className="w-3 h-3 text-amber-600" />
                              {new Date(task.due).toLocaleDateString()}
                            </span>
                          )}
                        </div>

                        {task.notes && (
                          <p className={`text-[11px] mt-1 leading-snug line-clamp-2 ${isCompleted ? 'text-slate-400' : 'text-slate-600'}`}>
                            {task.notes}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-1 shrink-0 opacity-80 group-hover:opacity-100">
                      <button
                        onClick={() => {
                          setEditingTask(task);
                          setEditTitle(task.title);
                          setEditNotes(task.notes || '');
                          setEditDue(task.due ? task.due.substring(0, 10) : '');
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors cursor-pointer"
                        title="할 일 수정"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setDeleteTarget(task)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Google Tasks에서 삭제"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-100/80 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>Google 계정 Tasks와 동기화됨 (완료 {tasks.filter(t => t.status === 'completed').length} / 전체 {tasks.length})</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl font-bold cursor-pointer"
          >
            닫기
          </button>
        </div>
      </div>

      {/* Edit Task Modal */}
      {editingTask && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 w-full max-w-md space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
                <Edit3 className="w-5 h-5 text-indigo-600" />
                <span>Google 할 일 수정</span>
              </h3>
              <button 
                onClick={() => setEditingTask(null)}
                className="text-slate-400 hover:text-slate-600 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleUpdateTask} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">제목 (필수) *</label>
                <input
                  type="text"
                  required
                  value={editTitle}
                  onChange={e => setEditTitle(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-blue-500 font-medium"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">마감 기한</label>
                <input
                  type="date"
                  value={editDue}
                  onChange={e => setEditDue(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-blue-500 font-medium text-slate-700"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">메모</label>
                <textarea
                  rows={3}
                  value={editNotes}
                  onChange={e => setEditNotes(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-blue-500 font-medium"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setEditingTask(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold cursor-pointer"
                >
                  취소
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-black shadow-xs cursor-pointer"
                >
                  수정 완료
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MANDATORY Explicit Confirmation Dialog for Destructive Delete */}
      {deleteTarget && (
        <div className="fixed inset-0 z-70 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 shadow-2xl border border-rose-200 w-full max-w-md space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-base font-black text-slate-900">
                Google Task 영구 삭제 확인
              </h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                <strong>'{deleteTarget.title}'</strong> 작업을 Google Tasks에서 영구적으로 삭제하시겠습니까?
              </p>
              <div className="mt-2 p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900 font-medium">
                ⚠️ 이 작업은 Google 클라우드에서 영구 삭제되며 복원할 수 없습니다.
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                disabled={isDeleting}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs cursor-pointer"
              >
                취소 (유지)
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-black text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                {isDeleting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                <span>확인 및 영구 삭제</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
