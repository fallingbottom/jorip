import React, { useState, useMemo } from 'react';
import { UserProfile, PolicyFund } from '../types';
import {
  DocumentIssuanceInfo,
  matchDocumentToIssuanceInfo,
  QUICK_ISSUANCE_PORTALS,
  QuickIssuancePortal
} from '../src/utils/documentIssuanceMap';
import {
  GovernmentDocType,
  GOVERNMENT_DOC_TEMPLATES,
  StandardDocTemplateMetadata
} from '../src/types/documentDraft';
import { GovernmentDocumentDraftModal } from './GovernmentDocumentDraftModal';
import {
  FileText,
  ExternalLink,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Building2,
  Download,
  Copy,
  Check,
  Sparkles,
  ChevronDown,
  ChevronUp,
  Clock,
  ShieldCheck,
  Compass,
  Bookmark,
  Edit3,
  Stamp,
  Printer,
  FileCheck2,
  ArrowRight
} from 'lucide-react';

interface DocumentIssuanceGuideProps {
  documents: string[];
  fundTitle?: string;
  fund?: PolicyFund | null;
  profile?: UserProfile | null;
  className?: string;
  defaultShowPortals?: boolean;
}

export const DocumentIssuanceGuide: React.FC<DocumentIssuanceGuideProps> = ({
  documents = [],
  fundTitle = '정책자금',
  fund = null,
  profile = null,
  className = '',
  defaultShowPortals = false,
}) => {
  // Normalize documents list
  const docList = useMemo(() => {
    if (!documents || documents.length === 0) {
      return [
        '소상공인 정책자금 융자신청서 및 기업현황표 (표준양식)',
        '정책자금 사업계획서 및 자금소요·상환계획서',
        '사업자등록증 사본 또는 사업자등록증명',
        '최근 3개년 표준재무제표증명 (재무상태표, 손익계산서)',
        '부가가치세 과세표준증명원 (최근 3개년)',
        '국세 및 지방세 납세증명서 (완납증명)',
        '중소기업·소상공인확인서',
        '4대사회보험 사업장 가입자명부',
        '신청자격 자가진단 및 사실확인 서약서'
      ];
    }
    return documents;
  }, [documents]);

  const [checkedDocs, setCheckedDocs] = useState<Record<string, boolean>>({});
  const [expandedDocId, setExpandedDocId] = useState<string | null>(null);
  const [showPortalsHub, setShowPortalsHub] = useState<boolean>(defaultShowPortals);
  const [showDraftTemplates, setShowDraftTemplates] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);

  // Government Form Draft Modal State
  const [isDraftModalOpen, setIsDraftModalOpen] = useState<boolean>(false);
  const [activeDraftTemplate, setActiveDraftTemplate] = useState<GovernmentDocType>('APPLICATION_FORM');

  // Map each document to its metadata
  const mappedDocs: (DocumentIssuanceInfo & { originalText: string; draftType: GovernmentDocType | null })[] = useMemo(() => {
    return docList.map((docText) => {
      const info = matchDocumentToIssuanceInfo(docText);
      const draftType = matchDocTextToDraftType(docText);
      return {
        ...info,
        originalText: docText,
        draftType
      };
    });
  }, [docList]);

  // Match document text to relevant government draft template if self-authored
  function matchDocTextToDraftType(text: string): GovernmentDocType | null {
    const clean = text.toLowerCase();
    if (clean.includes('신청서') || clean.includes('융자신청') || clean.includes('기업현황표')) {
      return 'APPLICATION_FORM';
    }
    if (clean.includes('사업계획') || clean.includes('상환계획') || clean.includes('자금소요')) {
      return 'BUSINESS_PLAN';
    }
    if (clean.includes('활용계획') || clean.includes('소요명세') || clean.includes('시설자금사용') || clean.includes('사용계획')) {
      return 'FUND_USAGE_PLAN';
    }
    if (clean.includes('서약서') || clean.includes('확약서') || clean.includes('자가진단') || clean.includes('사실확인')) {
      return 'ASSURANCE_PLEDGE';
    }
    if (clean.includes('대표자이력') || clean.includes('이력서') || clean.includes('사업장현황') || clean.includes('운영현황')) {
      return 'CEO_PROFILE_STATEMENT';
    }
    return null;
  }

  // Calculate readiness completion rate
  const completedCount = useMemo(() => {
    return mappedDocs.filter((d) => checkedDocs[d.originalText]).length;
  }, [mappedDocs, checkedDocs]);

  const progressPercent = mappedDocs.length > 0 ? Math.round((completedCount / mappedDocs.length) * 100) : 0;

  const toggleCheck = (text: string) => {
    setCheckedDocs((prev) => ({
      ...prev,
      [text]: !prev[text]
    }));
  };

  const handleOpenDraftModal = (type: GovernmentDocType = 'APPLICATION_FORM') => {
    setActiveDraftTemplate(type);
    setIsDraftModalOpen(true);
  };

  // Copy document list and links to clipboard
  const handleCopyDocList = () => {
    let text = `[${fundTitle} - 필수 제출 서류 및 온라인 발급 바로가기 목록]\n\n`;
    mappedDocs.forEach((doc, idx) => {
      const isDone = checkedDocs[doc.originalText] ? ' [준비완료]' : ' [미발급]';
      const draftNote = doc.draftType ? ' (※ 시스템 내 정부 표준 양식 초안 PDF 생성 지원)' : '';
      text += `${idx + 1}. ${doc.originalText}${isDone}${draftNote}\n`;
      text += `   - 발급/작성처: ${doc.agencyName} (${doc.costText})\n`;
      text += `   - 발급 바로가기: ${doc.issuanceUrl}\n`;
      text += `   - 발급경로: ${doc.pathGuide}\n`;
      text += `   - 실무팁: ${doc.tip}\n\n`;
    });
    text += `\n※ 서류는 원칙적으로 신청일 기준 최근 1개월 이내 발급분이어야 하며, 국세/지방세 체납이 없어야 합니다.`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className={`space-y-4 text-xs ${className}`}>
      {/* Top Title & Primary Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200/80">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-blue-600 text-white flex items-center justify-center flex-shrink-0 shadow-xs">
              <FileText className="w-4 h-4" />
            </div>
            <span className="font-black text-slate-900 text-sm sm:text-base">
              필수 제출 서류 발급 가이드 & 표준 양식 작성
            </span>
            <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 border border-blue-200">
              총 {mappedDocs.length}종
            </span>
          </div>
          <p className="text-[11px] text-slate-500 font-medium mt-0.5 ml-9">
            공공 포털 무료 발급처 이동 및 정부 제출 표준 양식 초안 PDF를 즉시 생성하실 수 있습니다.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-2 self-start sm:self-center flex-wrap">
          {/* Main Draft Assistant Launcher Button */}
          <button
            type="button"
            onClick={() => handleOpenDraftModal('APPLICATION_FORM')}
            className="px-3.5 py-2 bg-gradient-to-r from-indigo-600 via-indigo-700 to-blue-700 hover:from-indigo-500 hover:to-blue-600 text-white rounded-xl font-black text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-md hover:scale-[1.02] active:scale-[0.98]"
            title="사용자 정보가 자동 입력된 정부 제출 표준 양식 초안 PDF 생성기 열기"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
            <span>정부 표준 서식 초안 생성기</span>
            <span className="text-[9px] bg-white/20 px-1.5 py-0.2 rounded font-bold">AI 보조</span>
          </button>

          <button
            type="button"
            onClick={() => setShowPortalsHub(!showPortalsHub)}
            className={`px-2.5 py-2 rounded-xl font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer border ${
              showPortalsHub
                ? 'bg-slate-900 text-white border-slate-900 shadow-2xs'
                : 'bg-white hover:bg-slate-100 text-slate-700 border-slate-200'
            }`}
          >
            <Compass className="w-3.5 h-3.5 text-blue-500" />
            <span>{showPortalsHub ? '발급 포털 닫기' : '주요 발급처 허브'}</span>
          </button>

          <button
            type="button"
            onClick={handleCopyDocList}
            className="px-2.5 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs"
            title="세무사 전달용 서류 리스트 복사"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? '복사 완료' : '목록 복사'}</span>
          </button>
        </div>
      </div>

      {/* Progress Bar for Document Readiness */}
      <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200/80 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <div className="text-[11px] font-bold text-slate-700">
            서류 준비 현황: <strong className="text-blue-700 font-black">{completedCount}</strong> / {mappedDocs.length}개 준비 완료
          </div>
          <span className="text-[10px] font-black px-2 py-0.5 rounded bg-blue-100 text-blue-800">
            {progressPercent}%
          </span>
        </div>

        <div className="w-full sm:w-64 h-2.5 bg-slate-200 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-blue-500 via-indigo-600 to-emerald-500 transition-all duration-300"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Government Standard Form Draft Assistant Carousel/Banner */}
      <div className="p-4 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 rounded-2xl text-white space-y-3.5 shadow-md">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-indigo-500 text-white flex items-center justify-center flex-shrink-0 shadow-xs">
              <Stamp className="w-3.5 h-3.5" />
            </div>
            <div>
              <span className="font-black text-xs sm:text-sm text-white">
                정부 제출 표준 양식 초안 생성 및 PDF 출력 지원
              </span>
              <span className="hidden sm:inline-block text-[10px] text-slate-300 ml-2">
                (중기부 · 소진공 · 중진공 · 신보 공식 규격 서식 5종)
              </span>
            </div>
          </div>
          <span className="text-[10px] text-indigo-300 font-bold self-start sm:self-auto bg-white/10 px-2 py-0.5 rounded-full">
            💡 클릭 시 맞춤 정보 자동 입력 및 초안 작성
          </span>
        </div>

        {/* 5 Standard Government Templates Quick Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2.5">
          {GOVERNMENT_DOC_TEMPLATES.map((tmpl) => (
            <button
              key={tmpl.id}
              type="button"
              onClick={() => handleOpenDraftModal(tmpl.id)}
              className="p-3 bg-white/10 hover:bg-white/20 border border-white/10 hover:border-indigo-400/50 rounded-xl transition-all flex flex-col justify-between text-left group cursor-pointer hover:translate-y-[-1px] shadow-xs"
            >
              <div>
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className="text-[9px] font-black px-1.5 py-0.2 rounded bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
                    {tmpl.formNumber}
                  </span>
                  <span className="text-[9px] font-bold text-amber-300 bg-amber-400/15 px-1 py-0.2 rounded">
                    {tmpl.badge}
                  </span>
                </div>
                <h4 className="font-black text-white text-xs leading-snug group-hover:text-blue-300 transition-colors mt-1">
                  {tmpl.shortTitle}
                </h4>
                <p className="text-[10px] text-slate-300 leading-tight mt-1 line-clamp-2">
                  {tmpl.description}
                </p>
              </div>

              <div className="mt-2.5 pt-2 border-t border-white/10 flex items-center justify-between text-[10px] font-bold text-indigo-300 group-hover:text-white">
                <span>서식 작성 & PDF</span>
                <ArrowRight className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Quick Issuance Portals Hub Banner (Collapsible) */}
      {showPortalsHub && (
        <div className="p-4 bg-slate-900 rounded-2xl text-white space-y-3 shadow-md animate-fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-blue-400" />
              <span className="font-black text-xs sm:text-sm">정부·공공기관 온라인 서류 발급 원스톱 포털</span>
            </div>
            <span className="text-[10px] text-slate-400">새 탭에서 열림</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
            {QUICK_ISSUANCE_PORTALS.map((portal) => (
              <a
                key={portal.id}
                href={portal.url}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2.5 bg-white/10 hover:bg-white/20 border border-white/10 rounded-xl transition-all flex flex-col justify-between group cursor-pointer"
              >
                <div>
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className="font-black text-white text-xs group-hover:text-blue-300 transition-colors">
                      {portal.name}
                    </span>
                    <ExternalLink className="w-3 h-3 text-slate-400 group-hover:text-white" />
                  </div>
                  <p className="text-[10px] text-slate-300 leading-tight">
                    {portal.description}
                  </p>
                </div>
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-white/15 text-blue-200">
                    {portal.badge}
                  </span>
                  <span className="text-[9px] text-slate-300 font-bold group-hover:underline">
                    바로가기 →
                  </span>
                </div>
              </a>
            ))}
          </div>
        </div>
      )}

      {/* Main Required Documents Card List */}
      <div className="grid grid-cols-1 gap-2.5">
        {mappedDocs.map((doc, idx) => {
          const isDone = checkedDocs[doc.originalText];
          const isExpanded = expandedDocId === doc.originalText;
          const isSelfAuthored = Boolean(doc.draftType);

          return (
            <div
              key={idx}
              className={`p-3.5 rounded-2xl border transition-all ${
                isDone
                  ? 'bg-slate-50/60 border-slate-200 opacity-80'
                  : isSelfAuthored
                  ? 'bg-gradient-to-r from-white via-indigo-50/20 to-blue-50/20 border-indigo-200 hover:border-indigo-400 hover:shadow-xs'
                  : 'bg-white border-slate-200/90 hover:border-blue-300 hover:shadow-xs'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                {/* Left: Checkbox + Name + Agency info */}
                <div className="flex items-start gap-2.5 min-w-0 flex-1">
                  <button
                    type="button"
                    onClick={() => toggleCheck(doc.originalText)}
                    className={`mt-0.5 w-5 h-5 rounded-lg flex items-center justify-center flex-shrink-0 transition-colors cursor-pointer ${
                      isDone
                        ? 'bg-emerald-600 text-white'
                        : 'border-2 border-slate-300 hover:border-blue-500 bg-white'
                    }`}
                    title={isDone ? '준비 완료됨 (클릭하여 취소)' : '클릭하여 준비 완료 체크'}
                  >
                    {isDone && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                  </button>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5 mb-1">
                      <span className={`font-black text-xs sm:text-sm ${
                        isDone ? 'line-through text-slate-400' : 'text-slate-900'
                      }`}>
                        {doc.originalText}
                      </span>
                      
                      <span className={`text-[10px] font-bold px-2 py-0.2 rounded-md border ${doc.badgeColor}`}>
                        {doc.agencyName}
                      </span>

                      <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded">
                        {doc.costText}
                      </span>

                      {isSelfAuthored && (
                        <span className="text-[10px] font-black px-2 py-0.2 rounded-md bg-indigo-100 text-indigo-800 border border-indigo-200 flex items-center gap-1">
                          <Sparkles className="w-3 h-3 text-indigo-600" />
                          <span>표준 초안 PDF 지원</span>
                        </span>
                      )}
                    </div>

                    <div className="text-[11px] text-slate-500 flex flex-wrap items-center gap-x-3 gap-y-0.5 font-medium">
                      <span>※ 권장: {doc.recommendedValidity}</span>
                      <button
                        type="button"
                        onClick={() => setExpandedDocId(isExpanded ? null : doc.originalText)}
                        className="text-blue-600 hover:underline flex items-center gap-0.5 font-bold cursor-pointer"
                      >
                        <span>{isExpanded ? '발급 팁 접기' : '발급 경로 및 실무 팁'}</span>
                        {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Right: Action Buttons (Self-authored PDF generator OR Direct Online Issuance) */}
                <div className="flex items-center gap-2 flex-shrink-0 self-end sm:self-center">
                  {/* If document is self-authored, offer direct draft & PDF generator button */}
                  {isSelfAuthored && doc.draftType && (
                    <button
                      type="button"
                      onClick={() => handleOpenDraftModal(doc.draftType!)}
                      className="px-3 py-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-black text-xs rounded-xl transition-all shadow-xs flex items-center gap-1.5 hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
                      title="정부 표준 양식 초안 작성 및 PDF 생성"
                    >
                      <FileCheck2 className="w-3.5 h-3.5 text-indigo-200" />
                      <span>표준 서식 초안 생성 (PDF)</span>
                    </button>
                  )}

                  {/* Direct Online Issuance Portal Link */}
                  <a
                    href={doc.issuanceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-all shadow-xs flex items-center gap-1.5 hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
                    title={`${doc.agencyName} 발급 페이지로 바로가기`}
                  >
                    <span>{isSelfAuthored ? '공식 포털' : '온라인 발급 바로가기'}</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Collapsible Details: Step-by-Step Path & Practical Tips */}
              {isExpanded && (
                <div className="mt-3 pt-3 border-t border-slate-100 space-y-2 animate-fade-in">
                  <div className="bg-blue-50/60 p-2.5 rounded-xl border border-blue-100/80 text-[11px] text-blue-950 space-y-1">
                    <div className="font-bold flex items-center gap-1 text-blue-800">
                      <Compass className="w-3.5 h-3.5" />
                      <span>웹사이트 상세 발급 경로 / 작성처:</span>
                    </div>
                    <p className="font-mono text-slate-700 leading-relaxed pl-4">
                      {doc.pathGuide}
                    </p>
                  </div>

                  <div className="bg-amber-50/60 p-2.5 rounded-xl border border-amber-100/80 text-[11px] text-amber-950 space-y-1">
                    <div className="font-bold flex items-center gap-1 text-amber-800">
                      <HelpCircle className="w-3.5 h-3.5" />
                      <span>심사관 관점 실무 팁 & 주의사항:</span>
                    </div>
                    <p className="text-slate-700 leading-relaxed pl-4">
                      {doc.tip}
                    </p>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Bottom Disclaimer Notice */}
      <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-slate-500 text-[11px] flex items-start gap-2">
        <AlertCircle className="w-3.5 h-3.5 text-slate-400 mt-0.5 flex-shrink-0" />
        <div>
          <span>
            모든 제출 서류는 공고일 이후 또는 최근 1개월 이내 발급분이어야 하며, 시스템에서 생성된 서식 초안은 중소벤처기업부·소진공·신용보증재단 2026년 표준 양식 규격을 충족합니다.
          </span>
        </div>
      </div>

      {/* Government Document Draft & PDF Generation Modal */}
      <GovernmentDocumentDraftModal
        isOpen={isDraftModalOpen}
        onClose={() => setIsDraftModalOpen(false)}
        fund={fund}
        profile={profile}
        initialDocType={activeDraftTemplate}
      />
    </div>
  );
};
