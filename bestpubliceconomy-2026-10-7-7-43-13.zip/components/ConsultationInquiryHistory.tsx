import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { 
  Headphones, 
  Search, 
  Filter, 
  RefreshCw, 
  CheckCircle2, 
  Clock, 
  FileText, 
  ExternalLink, 
  Copy, 
  Check, 
  Trash2, 
  AlertCircle, 
  Sparkles, 
  Building2, 
  User, 
  Phone, 
  Mail, 
  Calendar, 
  Globe, 
  MessageSquare, 
  PhoneCall, 
  Video, 
  MessagesSquare, 
  ShieldCheck, 
  Cloud, 
  HardDrive, 
  ChevronRight,
  Plus,
  Edit3,
  CalendarCheck
} from 'lucide-react';
import { 
  ConsultationInquiryDoc, 
  fetchUserConsultations, 
  deleteUserConsultation, 
  updateUserConsultationStatus,
  createCalendarEvent
} from '../services/workspaceService';
import { auth } from '../services/firebaseService';
import { PolicyFund, SourcePolicy, UserProfile } from '../types';

interface ConsultationInquiryHistoryProps {
  token?: string | null;
  profile?: UserProfile | null;
  onOpenConsultationModal?: (fund?: any) => void;
  favorites?: (PolicyFund | SourcePolicy)[];
}

export const ConsultationInquiryHistory: React.FC<ConsultationInquiryHistoryProps> = ({
  token,
  profile,
  onOpenConsultationModal,
  favorites = []
}) => {
  const [inquiries, setInquiries] = useState<ConsultationInquiryDoc[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [channelFilter, setChannelFilter] = useState<'ALL' | 'google_forms' | 'direct'>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'PENDING' | 'ASSIGNED' | 'CONFIRMED'>('ALL');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [actionMessage, setActionMessage] = useState<string | null>(null);
  const [isSyncingLocal, setIsSyncingLocal] = useState(false);

  const currentUser = auth.currentUser;

  // Load inquiries from Firestore and localStorage
  const loadInquiries = useCallback(async () => {
    setIsLoading(true);
    setError(null);
    try {
      let firestoreList: ConsultationInquiryDoc[] = [];
      if (currentUser?.uid) {
        try {
          firestoreList = await fetchUserConsultations(currentUser.uid);
        } catch (e: any) {
          console.warn("Firestore fetch notice:", e);
        }
      }

      // Also read from localStorage
      let localList: ConsultationInquiryDoc[] = [];
      try {
        const stored = localStorage.getItem('bizmatch_expert_consultations');
        if (stored) {
          const parsed = JSON.parse(stored);
          localList = parsed.map((item: any) => ({
            id: item.id,
            userId: currentUser?.uid || 'local-user',
            fundTitle: item.fundTitle || '상담 문의 정책자금',
            fundAgency: item.fundAgency || '정책금융기관',
            fundMaxAmount: item.fundMaxAmount,
            fundInterestRate: item.fundInterestRate,
            applicantName: item.applicantName || '신청자',
            businessName: item.businessName || '사업체',
            contactNumber: item.contactNumber || '-',
            email: item.email || '-',
            preferredChannel: item.preferredChannel || 'CALL',
            preferredDate: item.preferredDate || new Date().toISOString().split('T')[0],
            preferredTimeSlot: item.preferredTimeSlot || 'AFTERNOON',
            inquiryCategory: item.inquiryCategory || 'ELIGIBILITY',
            inquiryDetails: item.inquiryDetails || '',
            googleFormUrl: item.googleFormUrl || '',
            submittedVia: item.submittedVia || (item.googleFormUrl ? 'google_forms' : 'direct'),
            status: item.status || 'PENDING',
            assignedExpert: item.assignedExpert,
            createdAt: item.createdAt || new Date().toISOString()
          }));
        }
      } catch (e) {
        console.error("Failed to read local consultations", e);
      }

      // Merge avoiding duplicates by ID or timestamp+title
      const mergedMap = new Map<string, ConsultationInquiryDoc>();
      
      // Add firestore items first
      firestoreList.forEach(item => {
        const key = item.id || `${item.fundTitle}-${item.createdAt}`;
        mergedMap.set(key, item);
      });

      // Add local items if not already present
      localList.forEach(item => {
        const key = item.id || `${item.fundTitle}-${item.createdAt}`;
        if (!mergedMap.has(key)) {
          mergedMap.set(key, item);
        }
      });

      const combined = Array.from(mergedMap.values()).sort((a, b) => {
        const timeA = new Date(a.createdAt?.seconds ? a.createdAt.seconds * 1000 : (a.createdAt || 0)).getTime();
        const timeB = new Date(b.createdAt?.seconds ? b.createdAt.seconds * 1000 : (b.createdAt || 0)).getTime();
        return timeB - timeA;
      });

      setInquiries(combined);
    } catch (err: any) {
      console.error("Failed to load inquiries", err);
      setError(err.message || '문의 내역을 불러오지 못했습니다.');
    } finally {
      setIsLoading(false);
    }
  }, [currentUser]);

  useEffect(() => {
    loadInquiries();
  }, [loadInquiries]);

  // Handle status update
  const handleUpdateStatus = async (item: ConsultationInquiryDoc, newStatus: 'PENDING' | 'ASSIGNED' | 'CONFIRMED') => {
    try {
      if (item.id && currentUser?.uid && !item.id.startsWith('consult-') && !item.id.startsWith('gform-consult-')) {
        await updateUserConsultationStatus(currentUser.uid, item.id, newStatus);
      }
      
      // Update locally
      setInquiries(prev => prev.map(inq => {
        if ((inq.id && inq.id === item.id) || (inq.fundTitle === item.fundTitle && inq.createdAt === item.createdAt)) {
          return { ...inq, status: newStatus };
        }
        return inq;
      }));

      // Update localStorage
      try {
        const stored = localStorage.getItem('bizmatch_expert_consultations');
        if (stored) {
          const list = JSON.parse(stored);
          const updated = list.map((inq: any) => {
            if (inq.id === item.id || (inq.fundTitle === item.fundTitle && inq.createdAt === item.createdAt)) {
              return { ...inq, status: newStatus };
            }
            return inq;
          });
          localStorage.setItem('bizmatch_expert_consultations', JSON.stringify(updated));
        }
      } catch (e) {}

      setActionMessage(`상태가 [${newStatus === 'CONFIRMED' ? '상담 완료' : newStatus === 'ASSIGNED' ? '상담사 배정' : '접수 대기'}] 상태로 변경되었습니다.`);
      setTimeout(() => setActionMessage(null), 3000);
    } catch (err) {
      console.error("Status update error", err);
    }
  };

  // Handle delete inquiry
  const handleDeleteInquiry = async (item: ConsultationInquiryDoc) => {
    if (!window.confirm(`'${item.fundTitle}'에 대한 상담 문의 내역을 삭제하시겠습니까?`)) {
      return;
    }

    try {
      if (item.id && currentUser?.uid && !item.id.startsWith('consult-') && !item.id.startsWith('gform-consult-')) {
        await deleteUserConsultation(currentUser.uid, item.id);
      }

      setInquiries(prev => prev.filter(inq => {
        if (item.id && inq.id) return inq.id !== item.id;
        return !(inq.fundTitle === item.fundTitle && inq.createdAt === item.createdAt);
      }));

      // Remove from localStorage
      try {
        const stored = localStorage.getItem('bizmatch_expert_consultations');
        if (stored) {
          const list = JSON.parse(stored);
          const updated = list.filter((inq: any) => {
            if (item.id && inq.id) return inq.id !== item.id;
            return !(inq.fundTitle === item.fundTitle && inq.createdAt === item.createdAt);
          });
          localStorage.setItem('bizmatch_expert_consultations', JSON.stringify(updated));
        }
      } catch (e) {}

      setActionMessage('상담 문의 내역이 안전하게 삭제되었습니다.');
      setTimeout(() => setActionMessage(null), 3000);
    } catch (err) {
      console.error("Delete inquiry error", err);
    }
  };

  // Copy Google Form URL
  const handleCopyUrl = (url: string, id: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  // Add Calendar Schedule for Consultation
  const handleAddToCalendar = async (item: ConsultationInquiryDoc) => {
    if (!token) {
      alert('구글 캘린더 연동을 위해 상단에서 Google 계정 로그인이 필요합니다.');
      return;
    }

    try {
      const dateStr = item.preferredDate || new Date().toISOString().split('T')[0];
      const startIso = `${dateStr}T14:00:00`;
      const endIso = `${dateStr}T15:00:00`;
      const summary = `[비대면 상담] ${item.fundTitle} 정책자금 전문 컨설팅`;
      const description = `1:1 정책자금 상담 일정\n- 대상 자금: ${item.fundTitle}\n- 주관 기관: ${item.fundAgency}\n- 신청자: ${item.applicantName} (${item.businessName})\n- 접수 방식: ${item.submittedVia === 'google_forms' ? 'Google Forms 설문' : '간편 신청'}\n- 문의 내용: ${item.inquiryDetails || '사전 진단'}\n${item.googleFormUrl ? `- 설문지 주소: ${item.googleFormUrl}` : ''}`;

      await createCalendarEvent(token, summary, description, startIso, endIso);

      setActionMessage(`Google 캘린더에 [${item.fundTitle}] 상담 일정이 등록되었습니다.`);
      setTimeout(() => setActionMessage(null), 4000);
    } catch (err: any) {
      alert(`캘린더 일정 등록 실패: ${err.message || err}`);
    }
  };

  // Filtered inquiries
  const filteredInquiries = useMemo(() => {
    return inquiries.filter(item => {
      // Channel match
      if (channelFilter !== 'ALL' && item.submittedVia !== channelFilter) {
        return false;
      }
      // Status match
      if (statusFilter !== 'ALL' && item.status !== statusFilter) {
        return false;
      }
      // Search term
      if (searchTerm.trim()) {
        const query = searchTerm.toLowerCase();
        const titleMatch = item.fundTitle?.toLowerCase().includes(query);
        const agencyMatch = item.fundAgency?.toLowerCase().includes(query);
        const applicantMatch = item.applicantName?.toLowerCase().includes(query);
        const businessMatch = item.businessName?.toLowerCase().includes(query);
        const detailsMatch = item.inquiryDetails?.toLowerCase().includes(query);
        if (!titleMatch && !agencyMatch && !applicantMatch && !businessMatch && !detailsMatch) {
          return false;
        }
      }
      return true;
    });
  }, [inquiries, channelFilter, statusFilter, searchTerm]);

  // Metric counts
  const totalCount = inquiries.length;
  const gFormsCount = inquiries.filter(i => i.submittedVia === 'google_forms').length;
  const pendingCount = inquiries.filter(i => i.status === 'PENDING').length;
  const confirmedCount = inquiries.filter(i => i.status === 'CONFIRMED').length;

  const formatDate = (dateVal: any) => {
    if (!dateVal) return '-';
    try {
      const d = dateVal.seconds ? new Date(dateVal.seconds * 1000) : new Date(dateVal);
      if (isNaN(d.getTime())) return String(dateVal);
      return `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, '0')}.${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
    } catch {
      return String(dateVal);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Top Banner & Stats */}
      <div className="bg-gradient-to-br from-indigo-950 via-slate-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white border border-indigo-900/40 shadow-xl relative overflow-hidden">
        <div className="absolute -right-10 -top-10 w-80 h-80 bg-indigo-600/15 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 rounded-full text-xs font-bold mb-3">
              <Headphones className="w-3.5 h-3.5" />
              1:1 비대면 전문상담 & Google Forms 접수 보관함
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-3">
              내 상담 문의 내역
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 font-medium max-w-2xl mt-1.5 leading-relaxed">
              Google Forms 및 모달을 통해 신청한 1:1 비대면 정책자금 심사 상담 기록이 Firestore 클라우드에 안전하게 보관됩니다.
            </p>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto flex-wrap">
            {onOpenConsultationModal && (
              <button
                type="button"
                onClick={() => onOpenConsultationModal(favorites[0] || undefined)}
                className="px-5 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl font-bold text-xs sm:text-sm transition-all shadow-lg shadow-indigo-600/30 active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>새 상담 신청하기</span>
              </button>
            )}

            <button
              type="button"
              onClick={loadInquiries}
              disabled={isLoading}
              className="px-4 py-3 bg-white/10 hover:bg-white/20 text-white rounded-2xl font-bold text-xs sm:text-sm transition-all border border-white/15 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              title="새로고침"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
              <span className="hidden sm:inline">동기화</span>
            </button>
          </div>
        </div>

        {/* Sync Status Badge */}
        <div className="mt-4 pt-4 border-t border-white/10 flex items-center justify-between flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-2">
            {currentUser ? (
              <span className="inline-flex items-center gap-1.5 text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
                <Cloud className="w-3.5 h-3.5" />
                Firestore 클라우드 동기화 완료 ({currentUser.email})
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5 text-amber-300 font-bold bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/20">
                <HardDrive className="w-3.5 h-3.5" />
                로컬 저장소 보관 모드 (상단 Google 로그인 시 클라우드 연동)
              </span>
            )}
          </div>
          <span className="text-slate-400 text-[11px]">
            마지막 업데이트: {new Date().toLocaleTimeString()}
          </span>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-6">
          <div className="bg-white/5 backdrop-blur-sm p-4 rounded-2xl border border-white/10">
            <div className="text-slate-400 text-xs font-bold mb-1">총 문의 신청</div>
            <div className="text-2xl font-black text-white">{totalCount}<span className="text-xs text-slate-400 font-bold ml-1">건</span></div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm p-4 rounded-2xl border border-white/10">
            <div className="text-purple-300 text-xs font-bold mb-1 flex items-center gap-1">
              <Globe className="w-3.5 h-3.5" /> Google Forms
            </div>
            <div className="text-2xl font-black text-purple-300">{gFormsCount}<span className="text-xs text-slate-400 font-bold ml-1">건</span></div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm p-4 rounded-2xl border border-white/10">
            <div className="text-amber-300 text-xs font-bold mb-1 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" /> 상담 대기 중
            </div>
            <div className="text-2xl font-black text-amber-300">{pendingCount}<span className="text-xs text-slate-400 font-bold ml-1">건</span></div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm p-4 rounded-2xl border border-white/10">
            <div className="text-emerald-400 text-xs font-bold mb-1 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" /> 완료된 상담
            </div>
            <div className="text-2xl font-black text-emerald-400">{confirmedCount}<span className="text-xs text-slate-400 font-bold ml-1">건</span></div>
          </div>
        </div>
      </div>

      {/* Action Message Toast */}
      {actionMessage && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3.5 px-4 rounded-2xl text-xs font-bold flex items-center gap-2 animate-fade-in shadow-xs">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{actionMessage}</span>
        </div>
      )}

      {/* Filters and Search Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="자금명, 주관기관, 대표자 성함 또는 사업체명 검색..."
            className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-2 flex-wrap">
          {/* Channel Filter */}
          <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-bold">
            <button
              type="button"
              onClick={() => setChannelFilter('ALL')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
                channelFilter === 'ALL' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              전체 접수
            </button>
            <button
              type="button"
              onClick={() => setChannelFilter('google_forms')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                channelFilter === 'google_forms' ? 'bg-purple-600 text-white shadow-xs' : 'text-purple-700 hover:text-purple-900'
              }`}
            >
              <Globe className="w-3 h-3" />
              <span>Google Forms</span>
            </button>
            <button
              type="button"
              onClick={() => setChannelFilter('direct')}
              className={`px-3 py-1.5 rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                channelFilter === 'direct' ? 'bg-indigo-600 text-white shadow-xs' : 'text-indigo-700 hover:text-indigo-900'
              }`}
            >
              <Headphones className="w-3 h-3" />
              <span>간편 상담</span>
            </button>
          </div>

          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
          >
            <option value="ALL">상태: 전체 보기</option>
            <option value="PENDING">대기 중 (Pending)</option>
            <option value="ASSIGNED">상담사 배정 (Assigned)</option>
            <option value="CONFIRMED">상담 완료 (Confirmed)</option>
          </select>
        </div>
      </div>

      {/* Inquiry List */}
      {isLoading && inquiries.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 flex flex-col items-center justify-center gap-3">
          <div className="w-10 h-10 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs font-bold text-slate-600">Firestore에서 상담 문의 내역을 불러오는 중입니다...</p>
        </div>
      ) : filteredInquiries.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200/80 shadow-xs flex flex-col items-center justify-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
            <Headphones className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-black text-slate-900 mb-1">
              {searchTerm || channelFilter !== 'ALL' || statusFilter !== 'ALL'
                ? '조건에 부합하는 상담 문의 내역이 없습니다.'
                : '아직 등록된 상담 문의 내역이 없습니다.'}
            </h3>
            <p className="text-xs text-slate-500 font-medium max-w-md mx-auto leading-relaxed">
              관심 정책자금 상세 화면이나 상단의 <strong>[새 상담 신청하기]</strong> 버튼을 통해 1:1 비대면 정책자금 컨설팅 또는 Google Forms 설문을 제출해 보세요.
            </p>
          </div>

          {onOpenConsultationModal && (
            <button
              type="button"
              onClick={() => onOpenConsultationModal(favorites[0] || undefined)}
              className="mt-2 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-xs transition-all shadow-md active:scale-95 flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>상담 문의 신청하기</span>
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredInquiries.map((item, idx) => {
            const isGForm = item.submittedVia === 'google_forms' || !!item.googleFormUrl;
            const statusBg = item.status === 'CONFIRMED' 
              ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
              : item.status === 'ASSIGNED'
              ? 'bg-blue-50 text-blue-700 border-blue-200'
              : 'bg-amber-50 text-amber-700 border-amber-200';

            const statusLabel = item.status === 'CONFIRMED' 
              ? '상담 완료' 
              : item.status === 'ASSIGNED' 
              ? '지도사 배정됨' 
              : '접수 대기 중';

            return (
              <div 
                key={item.id || `inq-${idx}`}
                className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/90 shadow-xs hover:shadow-md transition-all space-y-4"
              >
                {/* Card Top Row */}
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Channel Tag */}
                    {isGForm ? (
                      <span className="px-2.5 py-1 bg-purple-50 text-purple-700 border border-purple-200 rounded-lg text-[11px] font-black flex items-center gap-1">
                        <Globe className="w-3 h-3 text-purple-600" />
                        Google Forms 접수
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-lg text-[11px] font-black flex items-center gap-1">
                        <Headphones className="w-3 h-3 text-indigo-600" />
                        1:1 간편 접수
                      </span>
                    )}

                    <span className="px-2.5 py-1 bg-slate-100 text-slate-700 rounded-lg text-[11px] font-bold">
                      {item.fundAgency || '정책기관'}
                    </span>

                    {item.fundMaxAmount && (
                      <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 rounded-md text-[10px] font-extrabold border border-emerald-100">
                        최대 {item.fundMaxAmount}
                      </span>
                    )}
                  </div>

                  {/* Status Dropdown & Date */}
                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <span className="text-[11px] text-slate-400 font-medium">
                      {formatDate(item.createdAt)}
                    </span>
                    
                    <select
                      value={item.status}
                      onChange={(e) => handleUpdateStatus(item, e.target.value as any)}
                      className={`px-2.5 py-1 rounded-xl text-xs font-black border cursor-pointer focus:outline-none ${statusBg}`}
                    >
                      <option value="PENDING">대기 중</option>
                      <option value="ASSIGNED">지도사 배정</option>
                      <option value="CONFIRMED">상담 완료</option>
                    </select>
                  </div>
                </div>

                {/* Card Main Info */}
                <div className="space-y-3">
                  <div>
                    <h3 className="text-base sm:text-lg font-black text-slate-900 leading-snug">
                      {item.fundTitle}
                    </h3>
                    {item.inquiryDetails && (
                      <p className="text-xs font-medium text-slate-600 mt-1 bg-slate-50 p-3 rounded-2xl border border-slate-100 leading-relaxed">
                        💬 <strong>문의 내용:</strong> {item.inquiryDetails}
                      </p>
                    )}
                  </div>

                  {/* Detail Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 text-xs text-slate-700 bg-slate-50/70 p-3.5 rounded-2xl border border-slate-100">
                    <div className="flex items-center gap-2">
                      <User className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-bold text-slate-500">신청인:</span>
                      <span className="font-black text-slate-800">{item.applicantName || '대표자'}</span>
                      {item.businessName && (
                        <span className="text-[11px] text-slate-500 truncate">({item.businessName})</span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-bold text-slate-500">연락처:</span>
                      <span className="font-mono font-medium text-slate-800">{item.contactNumber || '-'}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="font-bold text-slate-500">이메일:</span>
                      <span className="font-mono text-[11px] text-slate-800 truncate">{item.email || '-'}</span>
                    </div>

                    {item.preferredDate && (
                      <div className="flex items-center gap-2">
                        <Calendar className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="font-bold text-slate-500">희망 일자:</span>
                        <span className="font-medium text-slate-800">{item.preferredDate}</span>
                      </div>
                    )}

                    {item.preferredChannel && (
                      <div className="flex items-center gap-2">
                        <MessageSquare className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="font-bold text-slate-500">상담 방식:</span>
                        <span className="font-bold text-indigo-700">
                          {item.preferredChannel === 'CALL' ? '유선 전화' : item.preferredChannel === 'VIDEO' ? '화상 미팅' : '실시간 채팅'}
                        </span>
                      </div>
                    )}

                    {item.assignedExpert && (
                      <div className="flex items-center gap-2">
                        <ShieldCheck className="w-3.5 h-3.5 text-indigo-500 shrink-0" />
                        <span className="font-bold text-slate-500">담당자:</span>
                        <span className="font-bold text-slate-800">{item.assignedExpert.name}</span>
                      </div>
                    )}
                  </div>

                  {/* Google Forms URL Section if applicable */}
                  {item.googleFormUrl && (
                    <div className="bg-purple-50/70 border border-purple-200/80 rounded-2xl p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5 text-xs">
                      <div className="flex items-center gap-2 min-w-0 flex-1">
                        <Globe className="w-4 h-4 text-purple-600 shrink-0" />
                        <div className="min-w-0">
                          <span className="text-[10px] font-black text-purple-700 block uppercase">연결된 Google Forms URL</span>
                          <span className="font-mono text-[11px] text-purple-900 truncate block">
                            {item.googleFormUrl}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0 self-end sm:self-auto">
                        <button
                          type="button"
                          onClick={() => handleCopyUrl(item.googleFormUrl!, item.id || `url-${idx}`)}
                          className="px-2.5 py-1.5 bg-white border border-purple-200 hover:bg-purple-100 text-purple-800 rounded-xl text-[11px] font-bold transition-all flex items-center gap-1 cursor-pointer"
                          title="설문지 링크 복사"
                        >
                          {copiedId === (item.id || `url-${idx}`) ? (
                            <>
                              <Check className="w-3 h-3 text-emerald-600" />
                              <span className="text-emerald-600">복사됨</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>URL 복사</span>
                            </>
                          )}
                        </button>

                        <a
                          href={item.googleFormUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-1.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-[11px] font-black transition-all flex items-center gap-1 cursor-pointer shadow-xs"
                        >
                          <span>설문지 열기</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>
                  )}
                </div>

                {/* Card Actions Footer */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between flex-wrap gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    {onOpenConsultationModal && (
                      <button
                        type="button"
                        onClick={() => onOpenConsultationModal({
                          title: item.fundTitle,
                          agency: item.fundAgency,
                          maxAmount: item.fundMaxAmount,
                          interestRate: item.fundInterestRate
                        })}
                        className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl font-bold transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <Headphones className="w-3.5 h-3.5 text-indigo-600" />
                        <span>다시 문의하기</span>
                      </button>
                    )}

                    {token && (
                      <button
                        type="button"
                        onClick={() => handleAddToCalendar(item)}
                        className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200/60 rounded-xl font-bold transition-colors flex items-center gap-1 cursor-pointer"
                        title="Google 캘린더에 상담 일정 추가"
                      >
                        <CalendarCheck className="w-3.5 h-3.5 text-blue-600" />
                        <span>캘린더 등록</span>
                      </button>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={() => handleDeleteInquiry(item)}
                    className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all cursor-pointer"
                    title="상담 내역 삭제"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>
      )}

    </div>
  );
};
