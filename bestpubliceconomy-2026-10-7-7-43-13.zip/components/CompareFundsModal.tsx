import React, { useState, useMemo } from 'react';
import { PolicyFund, SourcePolicy } from '../types';
import { 
  X, 
  Scale, 
  Star, 
  Calendar, 
  CheckCircle2, 
  FileText, 
  Building, 
  Banknote, 
  Percent, 
  Clock, 
  ShieldCheck, 
  Printer, 
  Plus, 
  Trash2, 
  AlertCircle,
  Phone,
  ArrowRight,
  TrendingDown,
  Sparkles,
  Award,
  Calculator,
  ExternalLink,
  Headphones,
  BarChart3
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Cell, 
  ReferenceLine,
  LabelList 
} from 'recharts';
import { calculateLoanSimulation, parseFundInterestRate, parseFundMaxAmount, formatKoreanWon } from './FundLoanSimulator';
import { matchDocumentToIssuanceInfo } from '../src/utils/documentIssuanceMap';

interface CompareFundsModalProps {
  isOpen: boolean;
  onClose: () => void;
  allFunds: PolicyFund[];
  selectedFunds: PolicyFund[];
  onToggleSelect: (fund: PolicyFund) => void;
  onRemoveFund: (fundId: string) => void;
  onScheduleCalendar?: (fund: PolicyFund) => void;
  favorites?: (PolicyFund | SourcePolicy)[];
  onToggleFavorite?: (fund: PolicyFund) => void;
  onOpenConsultation?: (fund: PolicyFund) => void;
}

// 금액 파싱 헬퍼 (억원 단위 산출)
const parseAmountValue = (str: string): number => {
  if (!str) return 0;
  const cleanStr = str.replace(/,/g, '').replace(/\s/g, '');
  let total = 0;
  const eokMatch = cleanStr.match(/(\d+(\.\d+)?)억/);
  if (eokMatch) total += parseFloat(eokMatch[1]) * 100000000;
  const manPart = cleanStr.includes('억') ? cleanStr.split('억')[1] : cleanStr;
  const manMatch = manPart ? manPart.match(/(\d+(\.\d+)?)만/) : null;
  if (manMatch) total += parseFloat(manMatch[1]) * 10000;
  else if (!cleanStr.includes('억') && !cleanStr.includes('만')) {
    const rawMatch = cleanStr.match(/\d+/);
    if (rawMatch) total = parseInt(rawMatch[0]);
  }
  return total;
};

// 금리 파싱 헬퍼 (최저 수치 산출)
const parseRateValue = (str: string): number => {
  if (!str) return 10;
  const match = str.match(/(\d+(\.\d+)?)/);
  return match ? parseFloat(match[0]) : 10;
};

export const CompareFundsModal: React.FC<CompareFundsModalProps> = ({
  isOpen,
  onClose,
  allFunds,
  selectedFunds,
  onToggleSelect,
  onRemoveFund,
  onScheduleCalendar,
  favorites = [],
  onToggleFavorite,
  onOpenConsultation,
}) => {
  const [selectedAddFundId, setSelectedAddFundId] = useState<string>('');
  const [chartViewMode, setChartViewMode] = useState<'BOTH' | 'RATE' | 'AMOUNT'>('BOTH');

  // Find min rate and max amount among compared funds for highlighting
  const { minRateFundId, maxAmountFundId } = useMemo(() => {
    if (selectedFunds.length === 0) return { minRateFundId: null, maxAmountFundId: null };

    let minRate = Infinity;
    let minRateId: string | null = null;
    let maxAmount = -Infinity;
    let maxAmountId: string | null = null;

    selectedFunds.forEach((fund) => {
      const rate = parseRateValue(fund.interestRate);
      if (rate < minRate) {
        minRate = rate;
        minRateId = fund.id || fund.title;
      }
      const amt = parseAmountValue(fund.maxAmount);
      if (amt > maxAmount) {
        maxAmount = amt;
        maxAmountId = fund.id || fund.title;
      }
    });

    return { minRateFundId: minRateId, maxAmountFundId: maxAmountId };
  }, [selectedFunds]);

  // Chart data for visual comparison in modal
  const chartData = useMemo(() => {
    return selectedFunds.map((fund, index) => {
      const fundKey = fund.id || fund.title;
      const parsedRate = parseFundInterestRate(fund.interestRate);
      const parsedAmount = parseFundMaxAmount(fund.maxAmount);
      
      const shortName = fund.title.length > 9 
        ? fund.title.substring(0, 8) + '..' 
        : fund.title;

      const amountInEok = Number((parsedAmount / 100000000).toFixed(2));

      return {
        id: fundKey,
        name: shortName,
        fullName: fund.title,
        agency: fund.agency,
        category: fund.category,
        rate: parsedRate,
        rawRate: fund.interestRate,
        amountEok: amountInEok,
        rawAmount: fund.maxAmount,
        formattedAmount: formatKoreanWon(parsedAmount),
        isMinRate: fundKey === minRateFundId,
        isMaxAmount: fundKey === maxAmountFundId,
      };
    });
  }, [selectedFunds, minRateFundId, maxAmountFundId]);

  // Funds available to add (not yet in comparison)
  const availableToAdd = useMemo(() => {
    const selectedIds = new Set(selectedFunds.map(f => f.id || f.title));
    return allFunds.filter(f => !selectedIds.has(f.id || f.title));
  }, [allFunds, selectedFunds]);

  const handleAddFund = () => {
    if (!selectedAddFundId) return;
    const target = allFunds.find(f => (f.id || f.title) === selectedAddFundId);
    if (target) {
      onToggleSelect(target);
      setSelectedAddFundId('');
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-fade-in"
      onClick={onClose}
    >
      <div 
        className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-7xl max-h-[92vh] flex flex-col overflow-hidden my-auto animate-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="px-6 py-5 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between flex-wrap gap-4 border-b border-indigo-900/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-widest text-indigo-300 bg-indigo-900/60 px-2 py-0.5 rounded-full border border-indigo-700/50">
                  Side-by-Side Comparison & Visual Chart
                </span>
                <span className="text-xs text-indigo-200 font-bold">
                  ({selectedFunds.length}/4개 선택됨)
                </span>
              </div>
              <h2 className="text-xl font-black text-white tracking-tight mt-0.5">
                정책자금 맞춤 대출 조건 상세 비교 & 차트
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Add Fund Selector if under 4 */}
            {selectedFunds.length < 4 && availableToAdd.length > 0 && (
              <div className="hidden sm:flex items-center gap-1.5 bg-white/10 p-1 rounded-xl border border-white/15">
                <select
                  value={selectedAddFundId}
                  onChange={(e) => setSelectedAddFundId(e.target.value)}
                  className="bg-slate-900/90 text-white text-xs font-bold px-2.5 py-1.5 rounded-lg border border-slate-700 outline-none max-w-[200px]"
                >
                  <option value="">+ 비교 자금 추가...</option>
                  {availableToAdd.map(f => (
                    <option key={f.id || f.title} value={f.id || f.title}>
                      {f.title} ({f.agency})
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  disabled={!selectedAddFundId}
                  onClick={handleAddFund}
                  className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 text-white text-xs font-black rounded-lg transition-colors"
                >
                  추가
                </button>
              </div>
            )}

            <button
              type="button"
              onClick={handlePrint}
              className="px-3 py-2 bg-white/10 hover:bg-white/20 text-white text-xs font-bold rounded-xl border border-white/15 flex items-center gap-1.5 transition-colors"
              title="비교표 인쇄"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden md:inline">인쇄</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors ml-1"
              title="닫기"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body / Comparison Area */}
        <div className="p-6 overflow-y-auto overflow-x-auto flex-1 space-y-6">
          {selectedFunds.length === 0 ? (
            <div className="text-center py-16 px-4">
              <Scale className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h3 className="text-lg font-bold text-slate-800 mb-1">비교할 정책자금이 선택되지 않았습니다</h3>
              <p className="text-sm text-slate-500 mb-6">
                추천 목록에서 2개 이상의 정책자금을 '비교 선택' 하신 후 비교표를 확인해보세요.
              </p>
              {allFunds.length > 0 && (
                <div className="flex justify-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      allFunds.slice(0, Math.min(3, allFunds.length)).forEach(f => onToggleSelect(f));
                    }}
                    className="px-4 py-2 bg-indigo-600 text-white text-xs font-black rounded-xl hover:bg-indigo-700 transition-colors shadow-sm"
                  >
                    상위 추천 3개 자금 바로 비교하기
                  </button>
                </div>
              )}
            </div>
          ) : (
            <>
              {/* Highlight Metric Banner */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-indigo-50/60 border border-indigo-100 p-3.5 rounded-2xl flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-black">
                    <Percent className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-indigo-500 block">최저 금리 우대</span>
                    <span className="text-sm font-black text-indigo-950">
                      {selectedFunds.find(f => (f.id || f.title) === minRateFundId)?.interestRate || '연 2.0%대'}
                    </span>
                    <span className="text-[11px] text-slate-500 block truncate max-w-[170px]">
                      {selectedFunds.find(f => (f.id || f.title) === minRateFundId)?.title}
                    </span>
                  </div>
                </div>

                <div className="bg-emerald-50/60 border border-emerald-100 p-3.5 rounded-2xl flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-black">
                    <Banknote className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-emerald-500 block">최대 한도 지원</span>
                    <span className="text-sm font-black text-emerald-950">
                      {selectedFunds.find(f => (f.id || f.title) === maxAmountFundId)?.maxAmount || '최대 5억원'}
                    </span>
                    <span className="text-[11px] text-slate-500 block truncate max-w-[170px]">
                      {selectedFunds.find(f => (f.id || f.title) === maxAmountFundId)?.title}
                    </span>
                  </div>
                </div>

                <div className="bg-amber-50/60 border border-amber-100 p-3.5 rounded-2xl flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-amber-600 text-white flex items-center justify-center font-black">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-[10px] font-bold uppercase text-amber-500 block">상환 및 거치기간</span>
                    <span className="text-sm font-black text-amber-950">최대 5년~10년</span>
                    <span className="text-[11px] text-slate-500 block">원금분할 및 거치기간 우대</span>
                  </div>
                </div>
              </div>

              {/* Visual Comparison Bar Charts inside Modal */}
              <div className="bg-slate-50 rounded-2xl border border-slate-200/90 p-4.5 space-y-3">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-200/80 pb-2.5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-indigo-600 text-white flex items-center justify-center">
                      <BarChart3 className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs font-black text-slate-900">
                      금리 & 한도 시각화 바 차트
                    </span>
                  </div>

                  <div className="flex items-center gap-1 bg-slate-200 p-0.5 rounded-lg text-[11px] font-bold">
                    <button
                      type="button"
                      onClick={() => setChartViewMode('BOTH')}
                      className={`px-2 py-0.5 rounded-md transition-all ${
                        chartViewMode === 'BOTH' ? 'bg-white text-indigo-900 font-black shadow-xs' : 'text-slate-600'
                      }`}
                    >
                      전체
                    </button>
                    <button
                      type="button"
                      onClick={() => setChartViewMode('RATE')}
                      className={`px-2 py-0.5 rounded-md transition-all ${
                        chartViewMode === 'RATE' ? 'bg-white text-indigo-900 font-black shadow-xs' : 'text-slate-600'
                      }`}
                    >
                      금리 (%)
                    </button>
                    <button
                      type="button"
                      onClick={() => setChartViewMode('AMOUNT')}
                      className={`px-2 py-0.5 rounded-md transition-all ${
                        chartViewMode === 'AMOUNT' ? 'bg-white text-emerald-900 font-black shadow-xs' : 'text-slate-600'
                      }`}
                    >
                      한도 (억원)
                    </button>
                  </div>
                </div>

                <div className={`grid gap-4 ${
                  chartViewMode === 'BOTH' ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'
                }`}>
                  {(chartViewMode === 'BOTH' || chartViewMode === 'RATE') && (
                    <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[11px] font-black text-slate-800 flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-indigo-600 inline-block"></span>
                          예상 대출 금리 (%)
                        </span>
                        <span className="text-[10px] text-red-500 font-bold">
                          시중은행 5.8%
                        </span>
                      </div>
                      <div className="h-44 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={chartData} margin={{ top: 15, right: 15, left: -15, bottom: 20 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                            <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#475569', fontWeight: 600 }} tickLine={false} />
                            <YAxis unit="%" domain={[0, 7]} tick={{ fontSize: 9, fill: '#64748b' }} tickLine={false} />
                            <Tooltip content={({ active, payload }) => {
                              if (active && payload && payload.length) {
                                const d = payload[0].payload;
                                return (
                                  <div className="bg-slate-900 text-white p-2.5 rounded-xl text-[11px] shadow-lg border border-indigo-500/30">
                                    <p className="font-bold text-white mb-1">{d.fullName}</p>
                                    <p className="text-indigo-300 font-black">금리: 연 {d.rate}% ({d.rawRate})</p>
                                    <p className="text-emerald-400 text-[10px]">시중은행 대비 {(5.8 - d.rate).toFixed(1)}%p 절감</p>
                                  </div>
                                );
                              }
                              return null;
                            }} />
                            <ReferenceLine y={5.8} stroke="#ef4444" strokeDasharray="3 3" />
                            <Bar dataKey="rate" radius={[6, 6, 0, 0]} barSize={32}>
                              <LabelList dataKey="rate" position="top" formatter={(v: number) => `${v}%`} style={{ fill: '#334155', fontSize: '10px', fontWeight: 'bold' }} />
                              {chartData.map((entry, index) => (
                                <Cell key={`modal-cell-rate-${index}`} fill={entry.isMinRate ? '#4f46e5' : '#6366f1'} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  )}

                  {(chartViewMode === 'BOTH' || chartViewMode === 'AMOUNT') && (
                    <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-2xs">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[11px] font-black text-slate-800 flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-600 inline-block"></span>
                          최대 지원 한도 (억원)
                        </span>
                      </div>
                      <div className="h-44 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={chartData} margin={{ top: 15, right: 15, left: -15, bottom: 20 }}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                            <XAxis dataKey="name" tick={{ fontSize: 10, fill: '#475569', fontWeight: 600 }} tickLine={false} />
                            <YAxis unit="억" tick={{ fontSize: 9, fill: '#64748b' }} tickLine={false} />
                            <Tooltip content={({ active, payload }) => {
                              if (active && payload && payload.length) {
                                const d = payload[0].payload;
                                return (
                                  <div className="bg-slate-900 text-white p-2.5 rounded-xl text-[11px] shadow-lg border border-emerald-500/30">
                                    <p className="font-bold text-white mb-1">{d.fullName}</p>
                                    <p className="text-emerald-300 font-black">한도: {d.formattedAmount}</p>
                                    <p className="text-slate-400 text-[10px]">{d.agency}</p>
                                  </div>
                                );
                              }
                              return null;
                            }} />
                            <Bar dataKey="amountEok" radius={[6, 6, 0, 0]} barSize={32}>
                              <LabelList dataKey="amountEok" position="top" formatter={(v: number) => `${v}억`} style={{ fill: '#065f46', fontSize: '10px', fontWeight: 'bold' }} />
                              {chartData.map((entry, index) => (
                                <Cell key={`modal-cell-amt-${index}`} fill={entry.isMaxAmount ? '#059669' : '#10b981'} />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Side-by-Side Comparison Table */}
              <div className="border border-slate-200 rounded-2xl overflow-x-auto shadow-xs bg-white">
                <table className="w-full text-left border-collapse min-w-[700px]">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200">
                      <th className="p-4 w-44 min-w-[170px] text-xs font-black text-slate-500 uppercase tracking-wider bg-slate-100/70 sticky left-0 z-10 border-r border-slate-200">
                        비교 항목
                      </th>
                      {selectedFunds.map((fund, idx) => {
                        const fundKey = fund.id || fund.title;
                        const isFav = favorites.some(item => ('title' in item ? item.title : item.name) === fund.title);
                        return (
                          <th key={fundKey} className="p-4 min-w-[240px] align-top border-r border-slate-200 last:border-r-0">
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <span className="text-[10px] font-black text-indigo-700 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-md">
                                자금 0{idx + 1}
                              </span>
                              <div className="flex items-center gap-1">
                                {onToggleFavorite && (
                                  <button
                                    type="button"
                                    onClick={() => onToggleFavorite(fund)}
                                    className={`p-1 rounded-md transition-colors ${
                                      isFav ? 'text-amber-500 bg-amber-50' : 'text-slate-400 hover:text-amber-500 hover:bg-slate-100'
                                    }`}
                                    title={isFav ? '즐겨찾기 해제' : '즐겨찾기'}
                                  >
                                    <Star className={`w-4 h-4 ${isFav ? 'fill-amber-400' : ''}`} />
                                  </button>
                                )}
                                <button
                                  type="button"
                                  onClick={() => onRemoveFund(fundKey)}
                                  className="p-1 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-md transition-colors"
                                  title="비교에서 제외"
                                >
                                  <Trash2 className="w-4 h-4" />
                                </button>
                              </div>
                            </div>
                            <h4 className="text-base font-black text-slate-900 leading-snug mb-1">
                              {fund.title}
                            </h4>
                            <div className="flex items-center gap-1.5 text-xs text-slate-500 font-bold">
                              <Building className="w-3.5 h-3.5 text-slate-400" />
                              <span>{fund.agency}</span>
                            </div>
                          </th>
                        );
                      })}
                    </tr>
                  </thead>

                  <tbody className="divide-y divide-slate-100 text-xs">
                    {/* 1. Interest Rate Row */}
                    <tr className="bg-indigo-50/20">
                      <td className="p-4 font-black text-slate-900 bg-slate-50/90 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <Percent className="w-4 h-4 text-indigo-600" />
                        <span>예상 대출 금리</span>
                      </td>
                      {selectedFunds.map((fund) => {
                        const fundKey = fund.id || fund.title;
                        const isMin = fundKey === minRateFundId;
                        return (
                          <td key={`rate-${fundKey}`} className="p-4 border-r border-slate-200 last:border-r-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-base font-black text-indigo-700">
                                {fund.interestRate}
                              </span>
                              {isMin && (
                                <span className="px-2 py-0.5 bg-indigo-600 text-white text-[10px] font-black rounded-full shadow-xs">
                                  최저 금리 우대
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-slate-500 block mt-1">
                              기준금리 변동 및 지자체 이차보전 적용 가능
                            </span>
                          </td>
                        );
                      })}
                    </tr>

                    {/* 2. Max Amount Limit */}
                    <tr className="bg-emerald-50/20">
                      <td className="p-4 font-black text-slate-900 bg-slate-50/90 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <Banknote className="w-4 h-4 text-emerald-600" />
                        <span>최대 대출 한도</span>
                      </td>
                      {selectedFunds.map((fund) => {
                        const fundKey = fund.id || fund.title;
                        const isMax = fundKey === maxAmountFundId;
                        return (
                          <td key={`amt-${fundKey}`} className="p-4 border-r border-slate-200 last:border-r-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-base font-black text-slate-900">
                                {fund.maxAmount}
                              </span>
                              {isMax && (
                                <span className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-black rounded-full shadow-xs">
                                  최고 한도
                                </span>
                              )}
                            </div>
                            <span className="text-[11px] text-slate-500 mt-1 block">
                              신용등급 및 담보력 심사에 따라 차등 지원
                            </span>
                          </td>
                        );
                      })}
                    </tr>

                    {/* 3. Repayment Period & Grace Period */}
                    <tr>
                      <td className="p-4 font-black text-slate-700 bg-slate-50/60 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <Clock className="w-4 h-4 text-amber-600" />
                        <span>상환 및 거치기간</span>
                      </td>
                      {selectedFunds.map((fund) => (
                        <td key={`period-${fund.id || fund.title}`} className="p-4 border-r border-slate-200 last:border-r-0">
                          <span className="font-black text-slate-900 text-xs block">
                            {fund.repaymentPeriod || '5년 (거치기간 2년 포함)'}
                          </span>
                          <span className="text-[11px] text-slate-500 mt-1 block">
                            원금균등분할상환 (거치기간 중 이자만 납부)
                          </span>
                        </td>
                      ))}
                    </tr>

                    {/* 4. Monthly Repayment Simulation (50M KRW Benchmark) */}
                    <tr className="bg-slate-50/50">
                      <td className="p-4 font-black text-slate-700 bg-slate-100/70 sticky left-0 border-r border-slate-200">
                        <div className="flex items-center gap-2">
                          <Calculator className="w-4 h-4 text-indigo-600" />
                          <span>월 상환액 시뮬레이션</span>
                        </div>
                        <span className="block text-[10px] font-normal text-slate-500 mt-1">
                          (5,000만원 대출 / 5년 기준)
                        </span>
                      </td>
                      {selectedFunds.map((fund) => {
                        const rate = parseFundInterestRate(fund.interestRate);
                        const sim = calculateLoanSimulation(50000000, rate, 5, 2, 'EQUAL_PRINCIPAL', 5.8);
                        return (
                          <td key={`sim-${fund.id || fund.title}`} className="p-4 border-r border-slate-200 last:border-r-0">
                            <div className="space-y-1 text-xs">
                              <div className="flex items-center justify-between text-slate-600">
                                <span>거치기 월이자:</span>
                                <span className="font-bold text-slate-900">{formatKoreanWon(sim.firstMonthlyPayment)}</span>
                              </div>
                              <div className="flex items-center justify-between text-slate-600">
                                <span>상환기 평균부담:</span>
                                <span className="font-black text-indigo-700">월 {formatKoreanWon(sim.avgMonthlyPayment)}</span>
                              </div>
                              <div className="flex items-center justify-between text-[11px] text-emerald-700 font-bold pt-1 border-t border-slate-200">
                                <span>시중은행 대비 절약:</span>
                                <span>약 {formatKoreanWon(sim.interestSaved)}</span>
                              </div>
                            </div>
                          </td>
                        );
                      })}
                    </tr>

                    {/* 5. Eligibility Criteria */}
                    <tr>
                      <td className="p-4 font-black text-slate-700 bg-slate-50/60 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <ShieldCheck className="w-4 h-4 text-emerald-600" />
                        <span>지원 대상 및 자격 요건</span>
                      </td>
                      {selectedFunds.map((fund) => (
                        <td key={`elig-${fund.id || fund.title}`} className="p-4 border-r border-slate-200 last:border-r-0 align-top">
                          <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 text-slate-700 text-xs leading-relaxed max-h-36 overflow-y-auto">
                            {fund.eligibility}
                          </div>
                        </td>
                      ))}
                    </tr>

                    {/* 6. Application Deadline */}
                    <tr>
                      <td className="p-4 font-black text-slate-700 bg-slate-50/60 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <Calendar className="w-4 h-4 text-blue-500" />
                        <span>신청 기한</span>
                      </td>
                      {selectedFunds.map((fund) => (
                        <td key={`dl-${fund.id || fund.title}`} className="p-4 border-r border-slate-200 last:border-r-0">
                          <span className="font-bold text-slate-800 text-xs block">
                            {fund.applicationDeadline || '연중 상시 (예산 소진 시 조기 마감)'}
                          </span>
                          {onScheduleCalendar && (
                            <button
                              type="button"
                              onClick={() => onScheduleCalendar(fund)}
                              className="mt-1.5 inline-flex items-center gap-1 text-[10px] text-indigo-600 hover:text-indigo-800 font-bold bg-indigo-50 px-2 py-1 rounded-md transition-colors"
                            >
                              <Calendar className="w-3 h-3" />
                              캘린더 일정 등록
                            </button>
                          )}
                        </td>
                      ))}
                    </tr>

                    {/* 7. Required Documents */}
                    <tr>
                      <td className="p-4 font-black text-slate-700 bg-slate-50/60 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                        <span>필수 제출 서류</span>
                      </td>
                      {selectedFunds.map((fund) => (
                        <td key={`docs-${fund.id || fund.title}`} className="p-4 border-r border-slate-200 last:border-r-0 align-top">
                          <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                            {fund.requiredDocuments && fund.requiredDocuments.length > 0 ? (
                              fund.requiredDocuments.map((doc, docIdx) => {
                                const info = matchDocumentToIssuanceInfo(doc);
                                return (
                                  <div
                                    key={docIdx}
                                    className="p-1.5 bg-slate-50 hover:bg-blue-50/60 rounded-lg border border-slate-200/80 flex items-center justify-between gap-1.5 transition-colors"
                                  >
                                    <div className="flex items-center gap-1.5 min-w-0 flex-1">
                                      <CheckCircle2 className="w-3 h-3 text-emerald-500 flex-shrink-0" />
                                      <span className="text-[11px] font-bold text-slate-800 truncate" title={doc}>
                                        {doc}
                                      </span>
                                    </div>
                                    <a
                                      href={info.issuanceUrl}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="text-[9px] font-black px-1.5 py-0.5 bg-white text-blue-700 hover:bg-blue-600 hover:text-white rounded border border-blue-200 shrink-0 flex items-center gap-0.5 transition-colors"
                                      title={`${info.agencyName} 발급 바로가기`}
                                    >
                                      <span>발급</span>
                                      <ExternalLink className="w-2 h-2" />
                                    </a>
                                  </div>
                                );
                              })
                            ) : (
                              <span className="text-slate-400 italic text-xs">사업자등록증, 부가세증명원 등 기본 서류</span>
                            )}
                          </div>
                        </td>
                      ))}
                    </tr>

                    {/* 8. Fund Purpose & Description */}
                    <tr>
                      <td className="p-4 font-black text-slate-700 bg-slate-50/60 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <FileText className="w-4 h-4 text-purple-500" />
                        <span>자금 개요 및 용도</span>
                      </td>
                      {selectedFunds.map((fund) => (
                        <td key={`desc-${fund.id || fund.title}`} className="p-4 border-r border-slate-200 last:border-r-0 align-top">
                          <p className="text-slate-600 text-xs leading-relaxed line-clamp-3">
                            {fund.description}
                          </p>
                        </td>
                      ))}
                    </tr>

                    {/* 9. Action Buttons */}
                    <tr className="bg-slate-50">
                      <td className="p-4 font-black text-slate-900 bg-slate-100/70 sticky left-0 border-r border-slate-200 flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-amber-500" />
                        <span>전문 상담 신청</span>
                      </td>
                      {selectedFunds.map((fund) => (
                        <td key={`act-${fund.id || fund.title}`} className="p-4 border-r border-slate-200 last:border-r-0">
                          {onOpenConsultation && (
                            <button
                              type="button"
                              onClick={() => {
                                onClose();
                                onOpenConsultation(fund);
                              }}
                              className="w-full py-2 px-3 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white font-black text-xs rounded-xl shadow-xs transition-all flex items-center justify-center gap-1.5"
                            >
                              <Headphones className="w-3.5 h-3.5" />
                              <span>1:1 비대면 상담 문의</span>
                            </button>
                          )}
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between flex-wrap gap-3">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <AlertCircle className="w-4 h-4 text-slate-400" />
            <span>비교 정보는 지자체 및 공단 고시 기준이며, 실제 심사 결과에 따라 한도와 금리가 달라질 수 있습니다.</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-black rounded-xl transition-colors ml-auto shadow-sm"
          >
            닫기
          </button>
        </div>
      </div>
    </div>
  );
};
