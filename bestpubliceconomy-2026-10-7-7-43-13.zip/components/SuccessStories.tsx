import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { UserProfile, Industry, FounderAdviceItem, AiFaqItem } from '../types';
import { 
  Quote, 
  TrendingDown, 
  TrendingUp, 
  CheckCircle2, 
  Building2, 
  Sparkles, 
  Award, 
  ChevronRight, 
  ChevronDown, 
  Star, 
  Users, 
  ShieldCheck, 
  ArrowUpRight, 
  Coffee, 
  Laptop, 
  Factory, 
  ShoppingBag, 
  Briefcase, 
  Store, 
  BarChart3, 
  DollarSign, 
  Percent, 
  Compass, 
  ArrowRight, 
  Filter, 
  CheckCircle, 
  Clock, 
  Zap, 
  Target, 
  MapPin, 
  RotateCcw, 
  Navigation,
  Search,
  MessageSquare,
  Send,
  Loader2,
  ThumbsUp,
  Copy,
  Check,
  Lightbulb,
  FileText,
  CheckCheck,
  HelpCircle,
  BookOpen,
  Maximize2,
  Minimize2,
  ExternalLink,
  ArrowLeft
} from 'lucide-react';
import { 
  SUCCESS_STORIES, 
  SuccessStory, 
  PROVINCES, 
  DISTRICTS_MAP, 
  INDUSTRY_STATISTICS 
} from './successStoriesData';
import { askSuccessStoryAi } from '../services/geminiService';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

export type { SuccessStory };
export { SUCCESS_STORIES };

interface SuccessStoriesProps {
  profile?: UserProfile | null;
  onSelectFund?: (fundName: string) => void;
  className?: string;
  onOpenNewPage?: () => void;
  isStandalonePage?: boolean;
}

export const SuccessStories: React.FC<SuccessStoriesProps> = ({
  profile,
  onSelectFund,
  className = '',
  onOpenNewPage,
  isStandalonePage = false
}) => {
  const [isFullScreenModal, setIsFullScreenModal] = useState(false);
  // Map user profile industry to category key
  const profileIndustryCategory = useMemo((): 'ALL' | 'FOOD' | 'TECH' | 'MANUFACTURING' | 'RETAIL' | 'SERVICE' | 'OTHER' => {
    if (!profile?.industry) return 'ALL';
    switch (profile.industry) {
      case Industry.RESTAURANT:
        return 'FOOD';
      case Industry.IT_SOFTWARE:
        return 'TECH';
      case Industry.MANUFACTURING:
        return 'MANUFACTURING';
      case Industry.RETAIL:
        return 'RETAIL';
      case Industry.SERVICE:
        return 'SERVICE';
      default:
        return 'OTHER';
    }
  }, [profile?.industry]);

  // Extract user's parsed province and district from profile
  const userRegionInfo = useMemo(() => {
    const rawLoc = (profile?.location || profile?.businessAddress || '').trim();
    if (!rawLoc) return { raw: '', province: '', district: '', displayText: '내 지역 미설정' };

    let foundProv = '';
    let foundDist = '';

    if (rawLoc.includes('서울')) foundProv = '서울';
    else if (rawLoc.includes('경기')) foundProv = '경기';
    else if (rawLoc.includes('인천')) foundProv = '인천';
    else if (rawLoc.includes('부산')) foundProv = '부산';
    else if (rawLoc.includes('대구')) foundProv = '대구';
    else if (rawLoc.includes('대전')) foundProv = '대전';
    else if (rawLoc.includes('광주')) foundProv = '광주';
    else if (rawLoc.includes('충남') || rawLoc.includes('충청남도') || rawLoc.includes('천안')) foundProv = '충남';
    else if (rawLoc.includes('제주')) foundProv = '제주';

    // Parse district
    const parts = rawLoc.split(' ');
    for (const p of parts) {
      if (p.endsWith('구') || p.endsWith('시') || p.endsWith('군')) {
        if (p !== '서울' && p !== '인천' && p !== '부산' && p !== '대구' && p !== '대전' && p !== '광주' && p !== '제주') {
          foundDist = p;
          break;
        }
      }
    }

    const displayText = foundProv && foundDist 
      ? `${foundProv} ${foundDist}` 
      : foundProv 
        ? foundProv 
        : rawLoc.substring(0, 10);

    return { raw: rawLoc, province: foundProv, district: foundDist, displayText };
  }, [profile?.location, profile?.businessAddress]);

  const [selectedCategory, setSelectedCategory] = useState<'ALL' | 'FOOD' | 'TECH' | 'MANUFACTURING' | 'RETAIL' | 'SERVICE' | 'OTHER'>(
    profileIndustryCategory !== 'ALL' ? profileIndustryCategory : 'ALL'
  );

  // Region Filter States
  const [selectedProvince, setSelectedProvince] = useState<string>('전체 지역');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('전체');
  const [onlyMyRegionFilter, setOnlyMyRegionFilter] = useState<boolean>(false);

  // Sync selectedCategory when profile changes
  useEffect(() => {
    if (profileIndustryCategory !== 'ALL') {
      setSelectedCategory(profileIndustryCategory);
    }
  }, [profileIndustryCategory]);

  const [selectedNeedFilter, setSelectedNeedFilter] = useState<'ALL' | 'DEBT_REFINANCE' | 'WORKING_CAPITAL' | 'FACILITY_EXPANSION' | 'DIGITAL_TRANSFORM'>('ALL');
  const [onlyProfileMatch, setOnlyProfileMatch] = useState<boolean>(false);
  const [expandedStoryId, setExpandedStoryId] = useState<string | null>(null);
  
  // Top Level Mode Tabs
  const [activeTab, setActiveTab] = useState<'STORIES' | 'ADVICE' | 'FAQ' | 'STATISTICS' | 'ROADMAP'>('STORIES');

  // Inner Card Tab View per story: 'STORY' | 'ADVICE' | 'FAQ'
  const [storyInnerTabMap, setStoryInnerTabMap] = useState<Record<string, 'STORY' | 'ADVICE' | 'FAQ'>>({});

  // FAQ Feedback & Helpful Vote Counter State
  const [helpfulVotes, setHelpfulVotes] = useState<Record<string, number>>({});
  const [userVotedMap, setUserVotedMap] = useState<Record<string, boolean>>({});

  // Copy Feedback State
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Interactive Custom AI Question State per Story
  const [customFaqMap, setCustomFaqMap] = useState<Record<string, { id: string; question: string; answer: string; keyTakeaway: string; date: string }[]>>({});
  const [askQuestionInput, setAskQuestionInput] = useState<Record<string, string>>({});
  const [isAskingAiMap, setIsAskingAiMap] = useState<Record<string, boolean>>({});

  // Global FAQ Hub Search & Category Filters
  const [faqSearchQuery, setFaqSearchQuery] = useState<string>('');
  const [faqCategoryFilter, setFaqCategoryFilter] = useState<string>('ALL');

  // Handle "내 지역(시/군/구) 원클릭 필터"
  const handleToggleMyRegion = () => {
    if (!onlyMyRegionFilter) {
      if (userRegionInfo.province) {
        setSelectedProvince(userRegionInfo.province);
        if (userRegionInfo.district) {
          setSelectedDistrict(userRegionInfo.district);
        } else {
          setSelectedDistrict('전체');
        }
      }
      setOnlyMyRegionFilter(true);
    } else {
      setOnlyMyRegionFilter(false);
      setSelectedProvince('전체 지역');
      setSelectedDistrict('전체');
    }
  };

  // Compute similarity score & region match bonus for each story based on profile
  const scoredStories = useMemo(() => {
    return SUCCESS_STORIES.map(story => {
      let score = 70; // base score
      let matchReasons: string[] = [];

      if (profile) {
        // Industry match (+15)
        if (profileIndustryCategory === story.industryCategory) {
          score += 15;
          matchReasons.push('업종 동일');
        }

        // Region match (+10 for exact district, +6 for province)
        if (userRegionInfo.province && story.province === userRegionInfo.province) {
          if (userRegionInfo.district && story.district.includes(userRegionInfo.district)) {
            score += 10;
            matchReasons.push(`내 지역(${story.location}) 일치`);
          } else {
            score += 6;
            matchReasons.push(`지자체(${story.province}) 권역`);
          }
        }

        // Debt structure match (+5)
        const hasHighDebt = (profile.debt2Tier || 0) > 0 || (profile.debtCardLoan || 0) > 0;
        if (hasHighDebt && story.fundingNeedType === 'DEBT_REFINANCE') {
          score += 5;
          matchReasons.push('고금리 부채 구조 일치');
        }

        // Funding need match (+5)
        if (profile.fundingNeed && profile.fundingNeed >= 30000000 && story.approvedAmountNumber >= 40000000) {
          score += 4;
          matchReasons.push('희망 자금 규모 일치');
        }

        // Revenue size match (+3)
        if (profile.annualRevenue && profile.annualRevenue > 100000000) {
          score += 3;
          matchReasons.push('매출 구간 유사');
        }
      }

      const isMyRegionExact = Boolean(
        userRegionInfo.province &&
        story.province === userRegionInfo.province &&
        (!userRegionInfo.district || story.district.includes(userRegionInfo.district))
      );

      const isMyProvince = Boolean(
        userRegionInfo.province &&
        story.province === userRegionInfo.province
      );

      const matchPercent = Math.min(score, 99);

      return {
        ...story,
        matchPercent,
        isMyRegionExact,
        isMyProvince,
        matchReasons: matchReasons.length > 0 ? matchReasons : ['유사 소상공인 프로필']
      };
    });
  }, [profile, profileIndustryCategory, userRegionInfo]);

  // Filtered stories based on Industry + Region + Funding Need + Profile Filters
  const filteredStories = useMemo(() => {
    return scoredStories.filter(story => {
      // Category filter
      if (selectedCategory !== 'ALL' && story.industryCategory !== selectedCategory) {
        return false;
      }
      // Need filter
      if (selectedNeedFilter !== 'ALL' && story.fundingNeedType !== selectedNeedFilter) {
        return false;
      }
      // Only profile industry match filter
      if (onlyProfileMatch && profileIndustryCategory !== 'ALL' && story.industryCategory !== profileIndustryCategory) {
        return false;
      }

      // Province filter
      if (selectedProvince !== '전체 지역' && story.province !== selectedProvince) {
        return false;
      }

      // District filter
      if (selectedDistrict !== '전체' && selectedDistrict !== '전체 구' && selectedDistrict !== '전체 시/군' && selectedDistrict !== '전체 시') {
        if (!story.district.includes(selectedDistrict)) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => b.matchPercent - a.matchPercent);
  }, [scoredStories, selectedCategory, selectedNeedFilter, onlyProfileMatch, profileIndustryCategory, selectedProvince, selectedDistrict]);

  // Set default expanded story
  useEffect(() => {
    if (filteredStories.length > 0 && (!expandedStoryId || !filteredStories.some(s => s.id === expandedStoryId))) {
      setExpandedStoryId(filteredStories[0].id);
    }
  }, [filteredStories, expandedStoryId]);

  // Current stats object
  const currentStats = useMemo(() => {
    return INDUSTRY_STATISTICS[selectedCategory] || INDUSTRY_STATISTICS.ALL;
  }, [selectedCategory]);

  // Available districts for the currently selected province
  const availableDistricts = useMemo(() => {
    if (selectedProvince === '전체 지역') return [];
    return DISTRICTS_MAP[selectedProvince] || [];
  }, [selectedProvince]);

  // Render icon helper
  const renderIcon = (name: string, className = 'w-5 h-5') => {
    switch (name) {
      case 'Coffee': return <Coffee className={className} />;
      case 'Laptop': return <Laptop className={className} />;
      case 'Factory': return <Factory className={className} />;
      case 'ShoppingBag': return <ShoppingBag className={className} />;
      case 'Briefcase': return <Briefcase className={className} />;
      case 'Store': return <Store className={className} />;
      default: return <Building2 className={className} />;
    }
  };

  // Copy to clipboard helper
  const handleCopyText = (id: string, text: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  // Upvote helpful FAQ helper
  const handleHelpfulVote = (faqId: string) => {
    if (userVotedMap[faqId]) return;
    setHelpfulVotes(prev => ({
      ...prev,
      [faqId]: (prev[faqId] || 0) + 1
    }));
    setUserVotedMap(prev => ({
      ...prev,
      [faqId]: true
    }));
  };

  // Ask AI about this specific success case
  const handleAskAiAboutStory = async (story: SuccessStory) => {
    const question = askQuestionInput[story.id]?.trim();
    if (!question || isAskingAiMap[story.id]) return;

    setIsAskingAiMap(prev => ({ ...prev, [story.id]: true }));
    try {
      const aiResult = await askSuccessStoryAi(
        {
          ownerName: story.ownerName,
          businessName: story.businessName,
          fundName: story.fundName,
          agency: story.agency,
          approvedAmount: story.approvedAmount,
          rateReduction: story.rateReduction,
          keySuccessFactor: story.keySuccessFactor,
          beforeSituation: story.beforeSituation,
          growthStory: story.growthStory,
          location: story.location,
          industryLabel: story.industryLabel
        },
        question,
        profile
      );

      const newEntry = {
        id: `custom-faq-${story.id}-${Date.now()}`,
        question,
        answer: aiResult.answer,
        keyTakeaway: aiResult.keyTakeaway,
        date: '방금 생성됨'
      };

      setCustomFaqMap(prev => ({
        ...prev,
        [story.id]: [newEntry, ...(prev[story.id] || [])]
      }));

      // Clear input
      setAskQuestionInput(prev => ({ ...prev, [story.id]: '' }));
    } catch (err) {
      console.error('Failed to ask AI:', err);
    } finally {
      setIsAskingAiMap(prev => ({ ...prev, [story.id]: false }));
    }
  };

  // Aggregated all FAQs across stories for global FAQ Tab
  const allAggregatedFaqs = useMemo(() => {
    const list: {
      story: SuccessStory;
      faq: AiFaqItem;
    }[] = [];

    SUCCESS_STORIES.forEach(story => {
      story.aiFaqSummary.forEach(faq => {
        list.push({ story, faq });
      });
    });

    return list.filter(({ story, faq }) => {
      // Category filter
      if (faqCategoryFilter !== 'ALL' && faq.category !== faqCategoryFilter) {
        return false;
      }
      // Search query
      if (faqSearchQuery.trim()) {
        const query = faqSearchQuery.toLowerCase();
        const matchesQ = faq.question.toLowerCase().includes(query);
        const matchesA = faq.aiSummaryAnswer.toLowerCase().includes(query);
        const matchesTakeaway = faq.keyTakeaway.toLowerCase().includes(query);
        const matchesFund = story.fundName.toLowerCase().includes(query);
        const matchesLocation = story.location.toLowerCase().includes(query);
        if (!matchesQ && !matchesA && !matchesTakeaway && !matchesFund && !matchesLocation) {
          return false;
        }
      }
      return true;
    });
  }, [faqCategoryFilter, faqSearchQuery]);

  return (
    <section 
      id="similar-industry-success-stories-section"
      className={`bg-white rounded-3xl p-6 sm:p-8 md:p-10 border border-slate-100 shadow-sm space-y-8 my-8 break-inside-avoid animate-fade-in ${className}`}
    >
      {/* 1. Header Section */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-6 border-b border-slate-100 pb-6">
        <div className="space-y-2">
          <div className="flex items-center gap-2 flex-wrap">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-emerald-50 to-teal-50 text-emerald-800 rounded-full text-xs font-black border border-emerald-200/70 shadow-2xs">
              <Award className="w-3.5 h-3.5 text-emerald-600" />
              <span>비슷한 업종 & 내 지역 소상공인 실전 성공 사례</span>
            </div>
            {profile?.industry && (
              <span className="bg-emerald-600 text-white px-2.5 py-0.5 rounded-full text-[11px] font-bold">
                {profile.industry} 맞춤
              </span>
            )}
            {userRegionInfo.displayText && userRegionInfo.displayText !== '내 지역 미설정' && (
              <span className="bg-indigo-600 text-white px-2.5 py-0.5 rounded-full text-[11px] font-bold flex items-center gap-1">
                <MapPin className="w-3 h-3" />
                {userRegionInfo.displayText}
              </span>
            )}

            {/* Action: Navigate to Dedicated Page */}
            {!isStandalonePage && (
              <button
                type="button"
                id="btn-navigate-success-stories-page"
                onClick={() => {
                  if (onOpenNewPage) {
                    onOpenNewPage();
                  } else {
                    setIsFullScreenModal(true);
                  }
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black bg-slate-900 hover:bg-slate-800 text-white shadow-sm transition-all hover:scale-105 active:scale-95 cursor-pointer ml-auto border border-slate-700"
                title="성공사례 전용 단독 페이지로 이동"
              >
                <ExternalLink className="w-3.5 h-3.5 text-emerald-400" />
                <span>새 페이지로 이동</span>
              </button>
            )}
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            대표님과 유사한 소상공인의 정책자금 성장 스토리 & 지역별 분석
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 font-medium max-w-2xl leading-relaxed">
            동일 업종과 <strong>내 지역(시/군/구)</strong>의 선배 대표님들이 어떤 정책자금을 활용해 <strong>고금리 채무를 해소하고 매출을 도약</strong>시켰는지 실제 승인 데이터, <strong>창업자의 3대 성공 조언</strong> 및 <strong>AI 실전 FAQ 카드</strong>를 확인하세요.
          </p>
        </div>

        {/* Highlight Stats Cards */}
        <div className="grid grid-cols-3 gap-2.5 sm:gap-3 shrink-0">
          <div className="bg-slate-50 p-3 sm:p-3.5 rounded-2xl border border-slate-100 text-center min-w-[95px] sm:min-w-[105px]">
            <span className="text-[10px] font-bold text-slate-400 block mb-0.5">평균 지원 한도</span>
            <span className="text-sm sm:text-base md:text-lg font-black text-blue-600">{currentStats.avgAmount}</span>
          </div>
          <div className="bg-slate-50 p-3 sm:p-3.5 rounded-2xl border border-slate-100 text-center min-w-[95px] sm:min-w-[105px]">
            <span className="text-[10px] font-bold text-slate-400 block mb-0.5">평균 금리 인하</span>
            <span className="text-sm sm:text-base md:text-lg font-black text-emerald-600">{currentStats.avgRateDrop}</span>
          </div>
          <div className="bg-slate-50 p-3 sm:p-3.5 rounded-2xl border border-slate-100 text-center min-w-[95px] sm:min-w-[105px]">
            <span className="text-[10px] font-bold text-slate-400 block mb-0.5">1년 내 매출 신장</span>
            <span className="text-sm sm:text-base md:text-lg font-black text-amber-600">{currentStats.avgRevenueIncrease}</span>
          </div>
        </div>
      </div>

      {/* 2. Mode Tabs & Multi-Dimensional Filters */}
      <div className="space-y-4">
        {/* Navigation Top Tabs (Enhanced with Advice and FAQ Hub) */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-2xl border border-slate-200/60 flex-wrap">
            <button
              type="button"
              onClick={() => setActiveTab('STORIES')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'STORIES'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Quote className="w-3.5 h-3.5 text-emerald-600" />
              <span>성공 사례 목록 ({filteredStories.length})</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('ADVICE')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'ADVICE'
                  ? 'bg-white text-amber-600 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
              <span>💡 창업자 핵심 조언 3가지</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('FAQ')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'FAQ'
                  ? 'bg-white text-blue-600 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5 text-blue-500" />
              <span>🤖 실전 FAQ AI 요약집 ({allAggregatedFaqs.length})</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('STATISTICS')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'STATISTICS'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5 text-indigo-600" />
              <span>업종별 자금 점유율</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('ROADMAP')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'ROADMAP'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              <Compass className="w-3.5 h-3.5 text-purple-600" />
              <span>자금 로드맵</span>
            </button>
          </div>

          {/* Quick Action Toggles: "내 지역 필터" & "내 업종 필터" */}
          <div className="flex items-center gap-2 flex-wrap">
            <button
              type="button"
              onClick={handleToggleMyRegion}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 border cursor-pointer ${
                onlyMyRegionFilter
                  ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm ring-2 ring-indigo-300'
                  : 'bg-indigo-50 text-indigo-800 border-indigo-200 hover:bg-indigo-100'
              }`}
              title="내 사업장 소재지(시/군/구) 기준 성공 사례 필터링"
            >
              <MapPin className={`w-3.5 h-3.5 ${onlyMyRegionFilter ? 'text-amber-300 animate-bounce' : 'text-indigo-600'}`} />
              <span>내 지역({userRegionInfo.displayText}) 필터 {onlyMyRegionFilter ? 'ON' : 'OFF'}</span>
            </button>

            {profile && (
              <button
                type="button"
                onClick={() => setOnlyProfileMatch(!onlyProfileMatch)}
                className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 border cursor-pointer ${
                  onlyProfileMatch
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                    : 'bg-emerald-50 text-emerald-800 border-emerald-200 hover:bg-emerald-100'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>내 업종({profile.industry || '현재 사업장'}) 우선 {onlyProfileMatch ? 'ON' : 'OFF'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Region Filter Bar (시/도 & 시/군/구 정밀 선택) */}
        <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80 space-y-3">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs font-black text-slate-800 shrink-0">
              <Navigation className="w-4 h-4 text-indigo-600" />
              <span>지역별(시/군/구) 사례 필터링</span>
              <span className="text-[10px] font-bold text-slate-400">
                (지자체 보증재단 & 이차보전 특례 사례)
              </span>
            </div>

            {/* Reset Region Filter */}
            {(selectedProvince !== '전체 지역' || selectedDistrict !== '전체') && (
              <button
                onClick={() => {
                  setSelectedProvince('전체 지역');
                  setSelectedDistrict('전체');
                  setOnlyMyRegionFilter(false);
                }}
                className="text-[11px] font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>지역 필터 초기화</span>
              </button>
            )}
          </div>

          {/* Province Chips & District Select */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-bold text-slate-500 shrink-0">시/도:</span>
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
              {PROVINCES.map((prov) => {
                const isSelected = selectedProvince === prov;
                const isUserProv = userRegionInfo.province === prov;

                return (
                  <button
                    key={prov}
                    type="button"
                    onClick={() => {
                      setSelectedProvince(prov);
                      setSelectedDistrict('전체');
                      if (prov === userRegionInfo.province) {
                        setOnlyMyRegionFilter(true);
                      } else {
                        setOnlyMyRegionFilter(false);
                      }
                    }}
                    className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                      isSelected
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <span>{prov}</span>
                    {isUserProv && (
                      <span className={`w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-amber-300' : 'bg-indigo-600'}`}></span>
                    )}
                  </button>
                );
              })}
            </div>

            {/* Sub-District Selector if Province is selected */}
            {selectedProvince !== '전체 지역' && availableDistricts.length > 0 && (
              <div className="flex items-center gap-1.5 ml-auto shrink-0 pt-1 sm:pt-0">
                <span className="text-[11px] font-bold text-slate-500">세부 시/군/구:</span>
                <select
                  value={selectedDistrict}
                  onChange={(e) => setSelectedDistrict(e.target.value)}
                  className="bg-white border border-slate-200 text-slate-800 font-bold text-xs rounded-xl px-3 py-1 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer shadow-2xs"
                >
                  <option value="전체">전체 ({selectedProvince})</option>
                  {availableDistricts.filter(d => !d.startsWith('전체')).map((dist) => (
                    <option key={dist} value={dist}>
                      {dist} {userRegionInfo.district === dist ? '★ 내 지역' : ''}
                    </option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </div>

        {/* Industry Category Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <button
            type="button"
            onClick={() => setSelectedCategory('ALL')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              selectedCategory === 'ALL'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            전체 업종 ({SUCCESS_STORIES.length})
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('FOOD')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              selectedCategory === 'FOOD'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'bg-amber-50 text-amber-900 border border-amber-200/80 hover:bg-amber-100'
            }`}
          >
            <Coffee className="w-3.5 h-3.5" />
            외식/카페
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('TECH')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              selectedCategory === 'TECH'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-blue-50 text-blue-900 border border-blue-200/80 hover:bg-blue-100'
            }`}
          >
            <Laptop className="w-3.5 h-3.5" />
            IT/소프트웨어
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('MANUFACTURING')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              selectedCategory === 'MANUFACTURING'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-indigo-50 text-indigo-900 border border-indigo-200/80 hover:bg-indigo-100'
            }`}
          >
            <Factory className="w-3.5 h-3.5" />
            제조/뿌리기업
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('RETAIL')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              selectedCategory === 'RETAIL'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'bg-purple-50 text-purple-900 border border-purple-200/80 hover:bg-purple-100'
            }`}
          >
            <ShoppingBag className="w-3.5 h-3.5" />
            도소매/유통
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('SERVICE')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
              selectedCategory === 'SERVICE'
                ? 'bg-teal-600 text-white shadow-xs'
                : 'bg-teal-50 text-teal-900 border border-teal-200/80 hover:bg-teal-100'
            }`}
          >
            <Briefcase className="w-3.5 h-3.5" />
            전문서비스/교육
          </button>
        </div>
      </div>

      {/* 3. TAB 1: Main Stories List */}
      {activeTab === 'STORIES' && (
        <div className="space-y-6">
          {filteredStories.length === 0 ? (
            <div className="p-12 text-center bg-slate-50 rounded-3xl border border-dashed border-slate-200 space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-slate-200 text-slate-400 flex items-center justify-center mx-auto">
                <Search className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-800">선택하신 조건에 부합하는 사례가 없습니다</h4>
                <p className="text-xs text-slate-500 mt-1">지역 또는 업종 필터 조건을 변경하여 더 많은 사례를 확인해 보세요.</p>
              </div>
              <div className="flex justify-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setSelectedProvince('전체 지역');
                    setSelectedDistrict('전체');
                    setOnlyMyRegionFilter(false);
                  }}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-sm cursor-pointer"
                >
                  전체 지역 사례 보기
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedCategory('ALL');
                    setSelectedNeedFilter('ALL');
                  }}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-bold transition-all cursor-pointer"
                >
                  업종/목적 조건 초기화
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {filteredStories.map((story) => {
                const isExpanded = expandedStoryId === story.id;
                const innerTab = storyInnerTabMap[story.id] || 'STORY';
                const customFaqs = customFaqMap[story.id] || [];
                const isAsking = isAskingAiMap[story.id] || false;

                return (
                  <div
                    key={story.id}
                    className={`p-6 rounded-3xl border transition-all space-y-5 relative overflow-hidden flex flex-col justify-between ${
                      isExpanded
                        ? 'bg-slate-900 text-white border-slate-800 shadow-xl ring-2 ring-emerald-500/30'
                        : 'bg-slate-50/80 hover:bg-white text-slate-800 border-slate-200/80 hover:border-slate-300 hover:shadow-md'
                    }`}
                  >
                    {/* Card Top: Owner Profile & Match Similarity Badge */}
                    <div className="space-y-3">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${
                            isExpanded ? 'bg-white/10 text-white' : 'bg-white text-slate-800 shadow-xs border border-slate-100'
                          }`}>
                            {renderIcon(story.iconName, 'w-6 h-6 text-emerald-500')}
                          </div>
                          <div>
                            <div className="flex items-center gap-2 flex-wrap">
                              <h3 className={`text-sm font-black ${isExpanded ? 'text-white' : 'text-slate-900'}`}>
                                {story.ownerName}
                              </h3>

                              {/* Region Tag with MapPin */}
                              <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                                story.isMyRegionExact
                                  ? 'bg-indigo-500 text-white shadow-xs animate-pulse'
                                  : isExpanded
                                    ? 'bg-indigo-950 text-indigo-300 border border-indigo-700'
                                    : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                              }`}>
                                <MapPin className="w-2.5 h-2.5" />
                                {story.location} {story.isMyRegionExact ? '★ 내 지역' : ''}
                              </span>

                              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                isExpanded 
                                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                                  : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                              }`}>
                                {story.badge}
                              </span>
                              <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                                isExpanded
                                  ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                                  : 'bg-blue-50 text-blue-700 border border-blue-200'
                              }`}>
                                <Sparkles className="w-2.5 h-2.5 text-amber-400" />
                                프로필 유사도 {story.matchPercent}%
                              </span>
                            </div>
                            <p className={`text-xs font-medium mt-0.5 ${isExpanded ? 'text-slate-400' : 'text-slate-500'}`}>
                              {story.businessName} · {story.businessAge} · {story.annualRevenue}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-0.5 text-amber-400 shrink-0">
                          {Array.from({ length: story.rating }).map((_, i) => (
                            <Star key={i} className="w-3.5 h-3.5 fill-amber-400" />
                          ))}
                        </div>
                      </div>

                      {/* Match Reasons Tags */}
                      <div className="flex flex-wrap gap-1.5 pt-1">
                        {story.matchReasons.map((reason, idx) => (
                          <span 
                            key={idx}
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                              isExpanded ? 'bg-white/10 text-slate-300' : 'bg-slate-200/70 text-slate-700'
                            }`}
                          >
                            ✓ {reason}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Key Metrics Summary Bar */}
                    <div className={`p-4 rounded-2xl border grid grid-cols-2 gap-3 text-xs ${
                      isExpanded
                        ? 'bg-white/5 border-white/10 text-slate-200'
                        : 'bg-white border-slate-200/90 text-slate-800 shadow-2xs'
                    }`}>
                      <div>
                        <span className={`text-[10px] font-bold block ${isExpanded ? 'text-slate-400' : 'text-slate-400'}`}>
                          선정 자금 및 승인액
                        </span>
                        <span className={`font-black text-xs block truncate ${isExpanded ? 'text-emerald-400' : 'text-slate-900'}`}>
                          {story.fundName}
                        </span>
                        <span className={`text-[11px] font-extrabold block ${isExpanded ? 'text-emerald-300' : 'text-blue-600'}`}>
                          {story.approvedAmount} ({story.agency})
                        </span>
                      </div>
                      <div>
                        <span className={`text-[10px] font-bold block ${isExpanded ? 'text-slate-400' : 'text-slate-400'}`}>
                          금리 혜택 및 성장 성과
                        </span>
                        <span className={`font-black text-xs block ${isExpanded ? 'text-amber-300' : 'text-amber-700'}`}>
                          {story.rateReduction}
                        </span>
                        <span className={`text-[11px] font-bold block ${isExpanded ? 'text-slate-300' : 'text-emerald-600'}`}>
                          {story.revenueGrowth}
                        </span>
                      </div>
                    </div>

                    {/* Quote / Testimonial Box */}
                    <div className="relative space-y-2">
                      <Quote className={`w-5 h-5 ${isExpanded ? 'text-emerald-400/40' : 'text-slate-300'}`} />
                      <p className={`text-xs md:text-sm font-medium leading-relaxed italic ${
                        isExpanded ? 'text-slate-200' : 'text-slate-700'
                      }`}>
                        "{story.testimonial}"
                      </p>
                    </div>

                    {/* Expandable Case Study Details */}
                    {isExpanded && (
                      <div className="space-y-4 pt-3 border-t border-white/10 text-xs animate-fade-in">
                        {/* Sub Tab Buttons inside the Card */}
                        <div className="flex items-center gap-1.5 bg-white/5 p-1 rounded-xl border border-white/10">
                          <button
                            type="button"
                            onClick={() => setStoryInnerTabMap(prev => ({ ...prev, [story.id]: 'STORY' }))}
                            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-black transition-all flex items-center justify-center gap-1 cursor-pointer ${
                              innerTab === 'STORY'
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            <FileText className="w-3.5 h-3.5" />
                            <span>성장 스토리</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setStoryInnerTabMap(prev => ({ ...prev, [story.id]: 'ADVICE' }))}
                            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-black transition-all flex items-center justify-center gap-1 cursor-pointer ${
                              innerTab === 'ADVICE'
                                ? 'bg-amber-600 text-white shadow-xs'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            <Lightbulb className="w-3.5 h-3.5 text-amber-300" />
                            <span>💡 대표님 핵심 조언 (3)</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setStoryInnerTabMap(prev => ({ ...prev, [story.id]: 'FAQ' }))}
                            className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-black transition-all flex items-center justify-center gap-1 cursor-pointer ${
                              innerTab === 'FAQ'
                                ? 'bg-blue-600 text-white shadow-xs'
                                : 'text-slate-400 hover:text-white'
                            }`}
                          >
                            <MessageSquare className="w-3.5 h-3.5 text-blue-300" />
                            <span>🤖 AI FAQ 카드 ({story.aiFaqSummary.length + customFaqs.length})</span>
                          </button>
                        </div>

                        {/* SUB-VIEW 1: Overview & Growth Timeline */}
                        {innerTab === 'STORY' && (
                          <div className="space-y-4 animate-fade-in">
                            {/* Before & After Situation */}
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                              <div className="bg-white/5 p-3 rounded-xl border border-white/10 space-y-1">
                                <span className="text-[10px] font-black text-rose-400 uppercase tracking-wider block">
                                  ⚠️ 지원 신청 전 위기 상황
                                </span>
                                <p className="text-slate-300 text-[11px] font-medium leading-relaxed">{story.beforeSituation}</p>
                              </div>
                              <div className="bg-emerald-950/40 p-3 rounded-xl border border-emerald-500/20 space-y-1">
                                <span className="text-[10px] font-black text-emerald-400 uppercase tracking-wider block">
                                  🚀 자금 수혈 후 성장 스토리
                                </span>
                                <p className="text-emerald-200 text-[11px] font-medium leading-relaxed">{story.growthStory}</p>
                              </div>
                            </div>

                            {/* Key Success Factor */}
                            <div className="space-y-1 bg-white/5 p-3 rounded-xl border border-white/10">
                              <span className="text-[10px] font-black text-amber-300 uppercase tracking-wider block flex items-center gap-1">
                                <Sparkles className="w-3 h-3 text-amber-300" /> AI 매칭 및 승인 성공 핵심 공략 비결
                              </span>
                              <p className="text-slate-200 font-bold text-xs leading-relaxed">{story.keySuccessFactor}</p>
                            </div>

                            {/* Growth Timeline Steps */}
                            {story.growthTimeline && story.growthTimeline.length > 0 && (
                              <div className="space-y-2 pt-1">
                                <span className="text-[10px] font-black text-slate-400 uppercase tracking-wider block">
                                  📈 단계별 성장 타임라인
                                </span>
                                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                                  {story.growthTimeline.map((step, idx) => (
                                    <div key={idx} className="bg-white/5 p-2.5 rounded-xl border border-white/10 text-[11px]">
                                      <span className="text-[10px] font-black text-indigo-400 block mb-0.5">{step.stage}</span>
                                      <span className="text-slate-300 font-medium leading-snug">{step.description}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}

                            {/* Application Tip */}
                            <div className="bg-blue-950/40 border border-blue-500/30 p-3 rounded-xl flex items-start gap-2.5">
                              <Zap className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                              <div>
                                <span className="text-[10px] font-black text-blue-300 block">선배 대표님의 실전 신청 팁</span>
                                <p className="text-[11px] text-blue-200 font-medium mt-0.5 leading-relaxed">
                                  {story.applicationTip}
                                </p>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* SUB-VIEW 2: Founder's 3 Key Success Factors (창업자가 직접 조언하는 핵심 성공 요인 3가지) */}
                        {innerTab === 'ADVICE' && (
                          <div className="space-y-3.5 animate-fade-in">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
                                <h4 className="text-xs font-black text-amber-300">
                                  {story.ownerName}이 직접 전하는 "승인 & 성장 핵심 요인 3가지"
                                </h4>
                              </div>
                              <button
                                type="button"
                                onClick={() => {
                                  const textToCopy = `[${story.ownerName} 대표님의 3대 성공 조언]\n` + 
                                    story.founderAdvice.map(a => `${a.number}. ${a.title}\n- ${a.detail}\n- 핵심: ${a.actionMetric || a.highlightTag}`).join('\n\n');
                                  handleCopyText(`advice-all-${story.id}`, textToCopy);
                                }}
                                className="text-[10px] font-bold text-slate-400 hover:text-amber-300 flex items-center gap-1 cursor-pointer"
                              >
                                {copiedId === `advice-all-${story.id}` ? (
                                  <Check className="w-3 h-3 text-emerald-400" />
                                ) : (
                                  <Copy className="w-3 h-3" />
                                )}
                                <span>{copiedId === `advice-all-${story.id}` ? '조언 전체 복사됨' : '조언 3가지 복사'}</span>
                              </button>
                            </div>

                            <div className="space-y-2.5">
                              {story.founderAdvice.map((advice) => {
                                const adviceKey = `advice-${story.id}-${advice.number}`;
                                return (
                                  <div
                                    key={advice.number}
                                    className="bg-white/5 hover:bg-white/10 p-3.5 rounded-2xl border border-white/10 transition-all space-y-2 relative group"
                                  >
                                    <div className="flex items-start justify-between gap-2">
                                      <div className="flex items-center gap-2">
                                        <span className="w-6 h-6 rounded-lg bg-amber-500/20 border border-amber-500/30 text-amber-300 text-xs font-black flex items-center justify-center shrink-0">
                                          0{advice.number}
                                        </span>
                                        <h5 className="font-black text-xs text-white leading-snug">
                                          {advice.title}
                                        </h5>
                                      </div>

                                      <button
                                        type="button"
                                        onClick={() => handleCopyText(adviceKey, `${advice.title}\n${advice.detail}`)}
                                        className="opacity-60 group-hover:opacity-100 text-slate-400 hover:text-white p-1 rounded-md transition-all cursor-pointer"
                                        title="이 조언 복사"
                                      >
                                        {copiedId === adviceKey ? (
                                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                                        ) : (
                                          <Copy className="w-3.5 h-3.5" />
                                        )}
                                      </button>
                                    </div>

                                    <p className="text-[11px] text-slate-300 font-medium leading-relaxed pl-8">
                                      "{advice.detail}"
                                    </p>

                                    <div className="flex items-center justify-between gap-2 pl-8 pt-1 text-[10px]">
                                      <span className="font-extrabold text-amber-400/90">
                                        {advice.highlightTag}
                                      </span>
                                      {advice.actionMetric && (
                                        <span className="bg-emerald-950/80 text-emerald-300 px-2 py-0.5 rounded-full font-bold border border-emerald-500/30">
                                          ✓ {advice.actionMetric}
                                        </span>
                                      )}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}

                        {/* SUB-VIEW 3: AI-Summarized FAQ Cards for Similar Situations */}
                        {innerTab === 'FAQ' && (
                          <div className="space-y-3.5 animate-fade-in">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2">
                                <span className="w-2 h-2 rounded-full bg-blue-400"></span>
                                <h4 className="text-xs font-black text-blue-300">
                                  비슷한 상황 소상공인 자주 묻는 질문 (AI 요약 답변)
                                </h4>
                              </div>
                              <span className="text-[10px] text-slate-400 font-bold">
                                공식 심사기준 기반 AI 요약
                              </span>
                            </div>

                            {/* Standard Pre-Summarized FAQs */}
                            <div className="space-y-2.5">
                              {story.aiFaqSummary.map((faq) => {
                                const currentVotes = (faq.helpfulCount || 0) + (helpfulVotes[faq.id] || 0);
                                const isVoted = userVotedMap[faq.id];
                                const copyKey = `faq-card-${faq.id}`;

                                return (
                                  <div
                                    key={faq.id}
                                    className="bg-white/5 p-3.5 rounded-2xl border border-white/10 space-y-2.5 transition-all"
                                  >
                                    {/* Question Title & Badges */}
                                    <div className="flex items-start justify-between gap-2">
                                      <div className="flex items-start gap-2">
                                        <span className="px-2 py-0.5 bg-blue-500/20 text-blue-300 text-[10px] font-black rounded-md shrink-0 mt-0.5 border border-blue-500/30">
                                          {faq.categoryLabel}
                                        </span>
                                        <h5 className="font-black text-xs text-white leading-snug">
                                          Q. {faq.question}
                                        </h5>
                                      </div>

                                      <div className="flex items-center gap-1 shrink-0">
                                        <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 px-1.5 py-0.5 rounded border border-emerald-500/30">
                                          신뢰도 {faq.confidenceScore}%
                                        </span>
                                        <button
                                          type="button"
                                          onClick={() => handleCopyText(copyKey, `Q: ${faq.question}\nA: ${faq.aiSummaryAnswer}\n${faq.keyTakeaway}`)}
                                          className="text-slate-400 hover:text-white p-1 rounded transition-all cursor-pointer"
                                          title="답변 복사"
                                        >
                                          {copiedId === copyKey ? (
                                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                                          ) : (
                                            <Copy className="w-3.5 h-3.5" />
                                          )}
                                        </button>
                                      </div>
                                    </div>

                                    {/* AI Summarized Answer */}
                                    <div className="bg-slate-950/60 p-3 rounded-xl border border-white/5 space-y-1.5">
                                      <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-400">
                                        <Sparkles className="w-3 h-3 text-blue-400" />
                                        <span>BizMatch AI 실전 요약 답변</span>
                                        <span className="text-slate-600">|</span>
                                        <span className="text-slate-400">기준: {faq.verifiedAgency}</span>
                                      </div>
                                      <p className="text-[11px] text-slate-200 font-medium leading-relaxed">
                                        {faq.aiSummaryAnswer}
                                      </p>
                                    </div>

                                    {/* Key Takeaway & Helpful Upvote */}
                                    <div className="flex items-center justify-between gap-2 pt-0.5 text-[10px]">
                                      <span className="font-extrabold text-amber-300">
                                        {faq.keyTakeaway}
                                      </span>

                                      <button
                                        type="button"
                                        onClick={() => handleHelpfulVote(faq.id)}
                                        className={`flex items-center gap-1 px-2 py-0.5 rounded-full border transition-all cursor-pointer ${
                                          isVoted
                                            ? 'bg-emerald-600 text-white border-emerald-500'
                                            : 'bg-white/5 text-slate-300 border-white/10 hover:bg-white/10'
                                        }`}
                                      >
                                        <ThumbsUp className="w-2.5 h-2.5" />
                                        <span>도움돼요 {currentVotes > 0 ? currentVotes : ''}</span>
                                      </button>
                                    </div>
                                  </div>
                                );
                              })}

                              {/* Custom Asked Questions by User via AI */}
                              {customFaqs.map((cf) => (
                                <div
                                  key={cf.id}
                                  className="bg-indigo-950/40 p-3.5 rounded-2xl border border-indigo-500/30 space-y-2.5"
                                >
                                  <div className="flex items-start justify-between gap-2">
                                    <div className="flex items-start gap-2">
                                      <span className="px-2 py-0.5 bg-indigo-500/30 text-indigo-300 text-[10px] font-black rounded-md shrink-0 mt-0.5 border border-indigo-500/40">
                                        내 실시간 질문
                                      </span>
                                      <h5 className="font-black text-xs text-white leading-snug">
                                        Q. {cf.question}
                                      </h5>
                                    </div>
                                    <span className="text-[10px] text-indigo-400 font-bold">{cf.date}</span>
                                  </div>

                                  <div className="bg-slate-950/70 p-3 rounded-xl border border-indigo-500/20 space-y-1.5">
                                    <div className="flex items-center gap-1.5 text-[10px] font-bold text-indigo-300">
                                      <Sparkles className="w-3 h-3 text-amber-300" />
                                      <span>AI 실시간 맞춤 분석 답변</span>
                                    </div>
                                    <p className="text-[11px] text-slate-200 font-medium leading-relaxed">
                                      {cf.answer}
                                    </p>
                                  </div>

                                  <div className="text-[10px] font-extrabold text-amber-300">
                                    {cf.keyTakeaway}
                                  </div>
                                </div>
                              ))}
                            </div>

                            {/* Interactive Ask AI Question Box */}
                            <div className="bg-white/5 p-3 rounded-2xl border border-white/10 space-y-2">
                              <div className="flex items-center gap-1.5 text-[11px] font-bold text-slate-300">
                                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                                <span>이 성공 사례에 대해 궁금한 점 AI에게 질문하기</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <input
                                  type="text"
                                  value={askQuestionInput[story.id] || ''}
                                  onChange={(e) => setAskQuestionInput(prev => ({ ...prev, [story.id]: e.target.value }))}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') {
                                      handleAskAiAboutStory(story);
                                    }
                                  }}
                                  placeholder="예: 제 신용점수가 720점인데 이 자금 대환 승인 확률이 얼마나 될까요?"
                                  className="flex-1 bg-slate-950/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
                                />
                                <button
                                  type="button"
                                  disabled={isAsking || !askQuestionInput[story.id]?.trim()}
                                  onClick={() => handleAskAiAboutStory(story)}
                                  className="px-3 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer shrink-0"
                                >
                                  {isAsking ? (
                                    <>
                                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                                      <span>AI 분석 중...</span>
                                    </>
                                  ) : (
                                    <>
                                      <Send className="w-3.5 h-3.5" />
                                      <span>질문</span>
                                    </>
                                  )}
                                </button>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Bottom Action Footer */}
                        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/10 text-[11px] text-slate-400 font-bold">
                          <span>연간 절감액: <strong className="text-emerald-400">{story.annualSavings}</strong></span>
                          <div className="flex items-center gap-2">
                            {onSelectFund && (
                              <button
                                type="button"
                                onClick={() => onSelectFund(story.fundName)}
                                className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-black transition-all flex items-center gap-1 cursor-pointer"
                              >
                                <span>이 자금 공고 확인</span>
                                <ArrowUpRight className="w-3 h-3" />
                              </button>
                            )}
                            <span className="text-slate-500">{story.date}</span>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Toggle Details Button */}
                    <button
                      type="button"
                      onClick={() => setExpandedStoryId(isExpanded ? null : story.id)}
                      className={`w-full py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer mt-2 ${
                        isExpanded
                          ? 'bg-white/10 text-white hover:bg-white/20'
                          : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
                      }`}
                    >
                      <span>{isExpanded ? '상세 분석 및 조언 접기' : '창업자 조언 3가지 & AI FAQ 카드 보기'}</span>
                      <ChevronDown className={`w-3.5 h-3.5 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 4. TAB 2: Founder's Advice TOP (창업자 핵심 성공 요인 3가지 전체 모아보기) */}
      {activeTab === 'ADVICE' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-gradient-to-r from-amber-500/10 via-orange-500/5 to-amber-500/10 p-5 rounded-3xl border border-amber-200/80 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-amber-100 text-amber-900 rounded-full text-[10px] font-black border border-amber-200">
                <Lightbulb className="w-3 h-3 text-amber-600" />
                <span>16인 창업자 실전 경험 비결 총람</span>
              </div>
              <h3 className="text-base sm:text-lg font-black text-slate-900">
                선배 창업자들이 입을 모아 강조하는 정책자금 조달 & 성장 3대 성공 요인
              </h3>
              <p className="text-xs text-slate-600 font-medium">
                서류 미비 방지, 신용점수 극복, 지자체 가점 획득 등 현장에서 직접 체득한 생생한 조언을 업종별로 확인하세요.
              </p>
            </div>
            <div className="px-3.5 py-2 bg-white rounded-2xl border border-amber-200 shadow-2xs text-center shrink-0">
              <span className="text-[10px] text-slate-400 font-bold block">등록된 실전 조언</span>
              <span className="text-sm font-black text-amber-600">총 48개 핵심 팁</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredStories.map((story) => (
              <div
                key={story.id}
                className="bg-slate-50 hover:bg-white p-6 rounded-3xl border border-slate-200/80 hover:border-amber-300 hover:shadow-md transition-all space-y-4 flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-3 border-b border-slate-200/60 pb-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center shrink-0">
                        {renderIcon(story.iconName, 'w-5 h-5 text-amber-600')}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-black text-sm text-slate-900">{story.ownerName}</h4>
                          <span className="text-[10px] font-bold px-2 py-0.5 bg-amber-100 text-amber-800 rounded-full">
                            {story.industryLabel}
                          </span>
                        </div>
                        <p className="text-xs text-slate-500 font-medium">
                          {story.businessName} · {story.location}
                        </p>
                      </div>
                    </div>
                    <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-xl border border-emerald-200">
                      {story.approvedAmount}
                    </span>
                  </div>

                  {/* 3 Advice Cards */}
                  <div className="space-y-2.5">
                    {story.founderAdvice.map((advice) => {
                      const adviceKey = `top-adv-${story.id}-${advice.number}`;
                      return (
                        <div
                          key={advice.number}
                          className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-2xs space-y-1.5"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center gap-2">
                              <span className="w-5 h-5 rounded-md bg-amber-500 text-white text-[10px] font-black flex items-center justify-center shrink-0">
                                {advice.number}
                              </span>
                              <h5 className="font-bold text-xs text-slate-900 leading-snug">
                                {advice.title}
                              </h5>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleCopyText(adviceKey, `${advice.title}\n${advice.detail}`)}
                              className="text-slate-400 hover:text-slate-700 p-0.5 rounded cursor-pointer"
                              title="복사"
                            >
                              {copiedId === adviceKey ? (
                                <Check className="w-3.5 h-3.5 text-emerald-600" />
                              ) : (
                                <Copy className="w-3.5 h-3.5" />
                              )}
                            </button>
                          </div>
                          <p className="text-[11px] text-slate-600 font-medium leading-relaxed pl-7">
                            {advice.detail}
                          </p>
                          <div className="flex items-center justify-between pl-7 pt-1 text-[10px]">
                            <span className="font-extrabold text-amber-600">
                              {advice.highlightTag}
                            </span>
                            {advice.actionMetric && (
                              <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                                {advice.actionMetric}
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-xs font-bold text-slate-500">
                  <span>수혜 자금: <strong className="text-slate-800">{story.fundName}</strong></span>
                  {onSelectFund && (
                    <button
                      type="button"
                      onClick={() => onSelectFund(story.fundName)}
                      className="text-emerald-600 hover:text-emerald-700 flex items-center gap-0.5 cursor-pointer font-black"
                    >
                      <span>공고 확인</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 5. TAB 3: Global AI FAQ Hub (소상공인 실전 FAQ AI 요약집) */}
      {activeTab === 'FAQ' && (
        <div className="space-y-6 animate-fade-in">
          {/* FAQ Search & Category Filter Bar */}
          <div className="bg-slate-50 p-5 rounded-3xl border border-slate-200/80 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
                  <MessageSquare className="w-5 h-5 text-blue-600" />
                  <span>비슷한 상황 소상공인들이 가장 많이 묻는 실전 질문 AI 요약집</span>
                </h3>
                <p className="text-xs text-slate-500 font-medium mt-0.5">
                  신용점수, 2금융 부채 대환, 서류 준비, 심사 기간, 금리 혜택까지 AI가 핵심만 명쾌하게 정리했습니다.
                </p>
              </div>
              <span className="px-3 py-1 bg-blue-100 text-blue-800 text-xs font-black rounded-xl shrink-0">
                총 {allAggregatedFaqs.length}개 FAQ 카드
              </span>
            </div>

            {/* Search Input */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={faqSearchQuery}
                onChange={(e) => setFaqSearchQuery(e.target.value)}
                placeholder="궁금한 키워드를 검색해 보세요 (예: 신용점수 700점, 카드론 대환, 거치기간, 서류, 보증료)"
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 shadow-2xs"
              />
              {faqSearchQuery && (
                <button
                  type="button"
                  onClick={() => setFaqSearchQuery('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400 hover:text-slate-700"
                >
                  지우기
                </button>
              )}
            </div>

            {/* Category Chips */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {[
                { key: 'ALL', label: '전체 질문' },
                { key: 'CREDIT', label: '신용·부채 조건' },
                { key: 'DOCS', label: '필수 서류·소명' },
                { key: 'PERIOD', label: '심사 기간·승인' },
                { key: 'LIMIT_RATE', label: '한도·금리 혜택' },
                { key: 'STRATEGY', label: '실전 전략·가점' }
              ].map((cat) => (
                <button
                  key={cat.key}
                  type="button"
                  onClick={() => setFaqCategoryFilter(cat.key)}
                  className={`px-3 py-1 rounded-xl text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                    faqCategoryFilter === cat.key
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* FAQ Cards Grid */}
          {allAggregatedFaqs.length === 0 ? (
            <div className="p-12 text-center bg-slate-50 rounded-3xl border border-dashed border-slate-200 space-y-3">
              <HelpCircle className="w-8 h-8 text-slate-400 mx-auto" />
              <h4 className="text-sm font-bold text-slate-800">검색 조건에 맞는 FAQ가 없습니다</h4>
              <p className="text-xs text-slate-500">다른 검색어를 입력하거나 카테고리 필터를 초기화해 보세요.</p>
              <button
                type="button"
                onClick={() => {
                  setFaqSearchQuery('');
                  setFaqCategoryFilter('ALL');
                }}
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                FAQ 필터 초기화
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {allAggregatedFaqs.map(({ story, faq }) => {
                const currentVotes = (faq.helpfulCount || 0) + (helpfulVotes[faq.id] || 0);
                const isVoted = userVotedMap[faq.id];
                const copyKey = `hub-faq-${faq.id}`;

                return (
                  <div
                    key={faq.id}
                    className="bg-slate-50 hover:bg-white p-5 rounded-3xl border border-slate-200/80 hover:border-blue-300 hover:shadow-md transition-all space-y-3 flex flex-col justify-between"
                  >
                    <div className="space-y-2.5">
                      {/* Top Story Info & Tag */}
                      <div className="flex items-center justify-between gap-2 border-b border-slate-200/60 pb-2">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 bg-blue-50 text-blue-700 text-[10px] font-black rounded-md border border-blue-200">
                            {faq.categoryLabel}
                          </span>
                          <span className="text-[11px] font-bold text-slate-500">
                            {story.businessName} ({story.location})
                          </span>
                        </div>
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                          신뢰도 {faq.confidenceScore}%
                        </span>
                      </div>

                      {/* Question */}
                      <h4 className="text-xs sm:text-sm font-black text-slate-900 leading-snug">
                        Q. {faq.question}
                      </h4>

                      {/* AI Answer Box */}
                      <div className="bg-white p-3.5 rounded-2xl border border-slate-200/90 shadow-2xs space-y-1.5">
                        <div className="flex items-center gap-1.5 text-[10px] font-black text-blue-600">
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>BizMatch AI 실전 요약 답변</span>
                          <span className="text-slate-300">|</span>
                          <span className="text-slate-500 font-medium">기준: {faq.verifiedAgency}</span>
                        </div>
                        <p className="text-xs text-slate-700 font-medium leading-relaxed">
                          {faq.aiSummaryAnswer}
                        </p>
                      </div>

                      {/* Key Takeaway */}
                      <div className="text-[11px] font-extrabold text-amber-700 bg-amber-50/80 p-2.5 rounded-xl border border-amber-200/60">
                        {faq.keyTakeaway}
                      </div>
                    </div>

                    {/* Bottom Actions */}
                    <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-xs font-bold">
                      <button
                        type="button"
                        onClick={() => handleCopyText(copyKey, `Q: ${faq.question}\nA: ${faq.aiSummaryAnswer}\n${faq.keyTakeaway}`)}
                        className="text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer text-[11px]"
                      >
                        {copiedId === copyKey ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                        <span>{copiedId === copyKey ? '복사 완료' : '답변 복사'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleHelpfulVote(faq.id)}
                        className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs transition-all cursor-pointer ${
                          isVoted
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-200/70 text-slate-700 hover:bg-slate-300'
                        }`}
                      >
                        <ThumbsUp className="w-3 h-3" />
                        <span>도움돼요 {currentVotes > 0 ? currentVotes : ''}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* 6. TAB 4: Statistics & Market Share Chart */}
      {activeTab === 'STATISTICS' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-slate-50 rounded-3xl p-6 border border-slate-200/80 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-indigo-600" />
                  <span>{selectedCategory === 'ALL' ? '전체 업종' : `${selectedCategory} 업종`} 소상공인 정책자금 선택 비율 TOP 4</span>
                </h3>
                <p className="text-xs text-slate-500 font-medium mt-1">
                  실제 승인을 받은 10,000+ 소상공인의 정책자금 유치 포트폴리오 빅데이터 분포
                </p>
              </div>
              <div className="px-3 py-1.5 bg-white rounded-xl border border-slate-200 text-xs font-bold text-slate-700 shadow-2xs">
                평균 승인률: <span className="text-emerald-600 font-black">{currentStats.approvalRate}</span>
              </div>
            </div>

            {/* Recharts Bar Chart */}
            <div className="h-64 w-full bg-white p-4 rounded-2xl border border-slate-200/60 shadow-2xs">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  layout="vertical"
                  data={currentStats.topFunds}
                  margin={{ top: 10, right: 40, left: 10, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                  <XAxis 
                    type="number" 
                    tick={{ fill: '#64748b', fontSize: 11, fontWeight: 700 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(v) => `${v}%`}
                  />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    tick={{ fill: '#1e293b', fontSize: 12, fontWeight: 700 }}
                    axisLine={false} 
                    tickLine={false} 
                    width={180}
                  />
                  <Tooltip 
                    cursor={{ fill: '#f8fafc' }}
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl text-xs space-y-1 border border-slate-800">
                            <div className="font-black text-sm text-emerald-400">{data.name}</div>
                            <div className="text-slate-300">선택 점유율: <strong className="text-white">{data.share}%</strong></div>
                            <div className="text-slate-300">평균 적용 금리: <strong className="text-amber-300">{data.avgRate}</strong></div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="share" radius={[0, 8, 8, 0]} barSize={22}>
                    {currentStats.topFunds.map((_, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={index === 0 ? '#10b981' : index === 1 ? '#3b82f6' : index === 2 ? '#6366f1' : '#8b5cf6'} 
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Strategic Recommendation Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
              {currentStats.topFunds.map((fund, idx) => (
                <div key={idx} className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-2">
                  <div className="flex items-center justify-between">
                    <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                      idx === 0 ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-700'
                    }`}>
                      {idx + 1}위 자금
                    </span>
                    <span className="text-xs font-black text-slate-900">{fund.share}% 점유</span>
                  </div>
                  <h4 className="font-bold text-xs text-slate-900 leading-snug truncate" title={fund.name}>
                    {fund.name}
                  </h4>
                  <div className="text-[11px] font-bold text-blue-600 pt-1 border-t border-slate-100">
                    평균 금리 {fund.avgRate}
                  </div>
                </div>
              ))}
            </div>

            {/* Core Strategy Tip Box */}
            <div className="bg-indigo-50 border border-indigo-100 p-4 rounded-2xl flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-black text-indigo-950">
                  {selectedCategory === 'ALL' ? '소상공인 공통 승인 필승 전략' : `${selectedCategory} 업종 최적 승인 전략`}
                </h4>
                <p className="text-xs text-indigo-900 font-medium mt-0.5 leading-relaxed">
                  {currentStats.primaryStrategy}을(를) 활용하면 심사 점수를 10~15점 추가 확보하여 보증 승인율을 95% 이상으로 끌어올릴 수 있습니다.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 7. TAB 5: Growth Lifecycle Pathway */}
      {activeTab === 'ROADMAP' && (
        <div className="space-y-6 animate-fade-in">
          <div className="bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 space-y-6 shadow-lg">
            <div className="space-y-1">
              <span className="text-[10px] font-black uppercase tracking-widest text-emerald-400">
                Business Growth Fund Lifecycle
              </span>
              <h3 className="text-lg sm:text-xl font-black text-white">
                소상공인 성장 단계별 최적 정책자금 활용 로드맵
              </h3>
              <p className="text-xs text-slate-300">
                선배 대표님들이 업력과 규모에 따라 단계별로 수혈받아 회사를 성장시킨 표준 자금 유치 코스입니다.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
              {/* Stage 1 */}
              <div className="bg-white/10 rounded-2xl p-5 border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 rounded-lg text-xs font-black border border-emerald-500/30">
                    1단계: 창업·초기 (1~3년)
                  </span>
                  <Target className="w-4 h-4 text-emerald-400" />
                </div>
                <h4 className="text-sm font-black text-white">운전자금 확보 & 생존 기반 구축</h4>
                <p className="text-xs text-slate-300 leading-relaxed font-medium">
                  창업 초기 매출 변동성에 대비한 지역신보 특례보증(3천~5천만원) 및 청년/창업 전용 초저금리(2%대) 자금을 우선 확보합니다.
                </p>
                <div className="pt-2 border-t border-white/10 text-[11px] text-emerald-300 font-bold">
                  추천: 창업유망 특례보증, 청년창업 특별자금
                </div>
              </div>

              {/* Stage 2 */}
              <div className="bg-white/10 rounded-2xl p-5 border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 bg-blue-500/20 text-blue-300 rounded-lg text-xs font-black border border-blue-500/30">
                    2단계: 성장·안정 (3~5년)
                  </span>
                  <TrendingUp className="w-4 h-4 text-blue-400" />
                </div>
                <h4 className="text-sm font-black text-white">금융비용 절감 & 체질 개선</h4>
                <p className="text-xs text-slate-300 leading-relaxed font-medium">
                  기존 고금리 대출을 3%대 소진공 대환대출로 전액 전환하여 월 고정비를 획기적으로 낮추고 영업이익률을 극대화합니다.
                </p>
                <div className="pt-2 border-t border-white/10 text-[11px] text-blue-300 font-bold">
                  추천: 소상공인 대환대출, 긴급경영안정자금
                </div>
              </div>

              {/* Stage 3 */}
              <div className="bg-white/10 rounded-2xl p-5 border border-white/10 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 bg-purple-500/20 text-purple-300 rounded-lg text-xs font-black border border-purple-500/30">
                    3단계: 확장·도약 (5년 이상)
                  </span>
                  <Zap className="w-4 h-4 text-purple-400" />
                </div>
                <h4 className="text-sm font-black text-white">시설 증설 & 스마트화 스케일업</h4>
                <p className="text-xs text-slate-300 leading-relaxed font-medium">
                  최대 2~5억원 한도의 성장촉진 시설자금과 스마트상점 보급 자금을 결합하여 2호점 개원 또는 자동화 공정을 완성합니다.
                </p>
                <div className="pt-2 border-t border-white/10 text-[11px] text-purple-300 font-bold">
                  추천: 성장촉진 특별시설자금, 스마트상점 지원
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 8. Bottom Trust & Action Banner */}
      <div className="bg-gradient-to-r from-blue-50 via-indigo-50 to-emerald-50 border border-blue-100 rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-2xl bg-blue-600 text-white flex items-center justify-center shrink-0 shadow-sm">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-black text-slate-900">
              대표님의 사업장도 지금 바로 최적 정책자금 승인 가능성을 확인할 수 있습니다
            </h4>
            <p className="text-[11px] text-slate-500 font-medium mt-0.5">
              공공 마이데이터 연동 및 AI 정밀 분석으로 조건에 맞는 실시간 공고를 100% 무료로 매칭해 드립니다.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <span className="text-[11px] font-extrabold text-blue-700 bg-white px-3.5 py-2 rounded-xl border border-blue-200 shadow-2xs">
            100% 무료 AI 정밀 매칭
          </span>
        </div>
      </div>

      {/* Full-Screen Dedicated Page Modal if opened in modal context */}
      {!isStandalonePage && isFullScreenModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-sm overflow-y-auto p-2 sm:p-4 md:p-8 flex flex-col animate-fade-in">
          <div className="bg-slate-50 rounded-3xl w-full max-w-7xl mx-auto shadow-2xl border border-slate-200 overflow-hidden flex flex-col my-auto">
            <div className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200 px-6 py-4 flex items-center justify-between shadow-xs">
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setIsFullScreenModal(false)}
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-black transition-all cursor-pointer hover:scale-105 active:scale-95"
                >
                  <ArrowLeft className="w-4 h-4" />
                  <span>이전 화면으로</span>
                </button>
                <div className="hidden sm:flex items-center gap-2 text-xs font-black text-slate-800 border-l border-slate-200 pl-3">
                  <Award className="w-4 h-4 text-emerald-600" />
                  <span>소상공인 정책자금 실전 성공사례 단독 전용 페이지</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsFullScreenModal(false)}
                className="px-3 py-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 rounded-xl hover:bg-slate-100 transition-colors cursor-pointer"
              >
                닫기 ✕
              </button>
            </div>
            <div className="p-4 sm:p-6 md:p-8">
              <SuccessStories 
                profile={profile}
                onSelectFund={(fundName) => {
                  setIsFullScreenModal(false);
                  onSelectFund?.(fundName);
                }}
                isStandalonePage={true}
              />
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
