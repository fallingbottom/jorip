import React, { useState, useEffect, useCallback } from 'react';
import { 
  MessageSquare, 
  Send, 
  Plus, 
  RefreshCw, 
  ExternalLink, 
  Users, 
  CheckCircle2, 
  AlertCircle, 
  Building2, 
  Share2, 
  Sparkles, 
  ShieldCheck, 
  MessageCircle, 
  Layers, 
  Clock, 
  ArrowRight,
  DollarSign,
  Tag,
  Search,
  Check
} from 'lucide-react';
import { 
  GoogleChatSpace, 
  GoogleChatMessage, 
  fetchGoogleChatSpaces, 
  createGoogleChatSpace, 
  fetchGoogleChatMessages, 
  sendGoogleChatMessage, 
  sendPolicyShareToGoogleChat 
} from '../services/workspaceService';
import { PolicyFund, SourcePolicy, UserProfile } from '../types';

interface GoogleChatHubProps {
  token: string | null;
  profile: UserProfile | null;
  favorites?: (PolicyFund | SourcePolicy)[];
  onGoogleLogin?: () => void;
  initialSelectedPolicy?: PolicyFund | SourcePolicy | null;
}

export const GoogleChatHub: React.FC<GoogleChatHubProps> = ({
  token,
  profile,
  favorites = [],
  onGoogleLogin,
  initialSelectedPolicy = null
}) => {
  // Spaces state
  const [spaces, setSpaces] = useState<GoogleChatSpace[]>([]);
  const [selectedSpace, setSelectedSpace] = useState<GoogleChatSpace | null>(null);
  const [isLoadingSpaces, setIsLoadingSpaces] = useState(false);
  const [spacesError, setSpacesError] = useState<string | null>(null);

  // Messages state
  const [messages, setMessages] = useState<GoogleChatMessage[]>([]);
  const [isLoadingMessages, setIsLoadingMessages] = useState(false);
  const [messagesError, setMessagesError] = useState<string | null>(null);
  const [messageInput, setMessageInput] = useState('');
  const [isSending, setIsSending] = useState(false);

  // Create Space Modal
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newSpaceName, setNewSpaceName] = useState(
    profile?.businessName ? `[${profile.businessName}] 정책자금 협업방` : '[소상공인] 정책자금 실시간 상담방'
  );
  const [newSpaceDesc, setNewSpaceDesc] = useState('BizMatch AI 정책자금 상담 및 실시간 심사 공유 채널');
  const [isCreatingSpace, setIsCreatingSpace] = useState(false);

  // Policy Sharing Modal / Section
  const [showShareModal, setShowShareModal] = useState(false);
  const [selectedPolicyToShare, setSelectedPolicyToShare] = useState<PolicyFund | SourcePolicy | null>(
    initialSelectedPolicy || (favorites.length > 0 ? favorites[0] : null)
  );
  const [shareNote, setShareNote] = useState('');
  const [isSharingPolicy, setIsSharingPolicy] = useState(false);

  // Action toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Load Google Chat Spaces
  const loadSpaces = useCallback(async () => {
    if (!token) return;
    setIsLoadingSpaces(true);
    setSpacesError(null);
    try {
      const list = await fetchGoogleChatSpaces(token);
      setSpaces(list);
      if (list.length > 0 && !selectedSpace) {
        setSelectedSpace(list[0]);
      }
    } catch (err: any) {
      console.error('Failed to load Google Chat spaces', err);
      setSpacesError(err.message || 'Google Chat 스페이스 목록을 불러오지 못했습니다.');
    } finally {
      setIsLoadingSpaces(false);
    }
  }, [token, selectedSpace]);

  // Load Messages for the selected space
  const loadMessages = useCallback(async (space: GoogleChatSpace) => {
    if (!token || !space.name) return;
    setIsLoadingMessages(true);
    setMessagesError(null);
    try {
      const msgList = await fetchGoogleChatMessages(token, space.name);
      setMessages(msgList);
    } catch (err: any) {
      console.error('Failed to load messages', err);
      setMessagesError(err.message || '메시지 목록을 불러오지 못했습니다.');
    } finally {
      setIsLoadingMessages(false);
    }
  }, [token]);

  // Initial load
  useEffect(() => {
    if (token) {
      loadSpaces();
    }
  }, [token, loadSpaces]);

  // When selected space changes
  useEffect(() => {
    if (selectedSpace) {
      loadMessages(selectedSpace);
    } else {
      setMessages([]);
    }
  }, [selectedSpace, loadMessages]);

  // Handle Create Space
  const handleCreateSpace = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    if (!newSpaceName.trim()) {
      alert('스페이스 이름을 입력해 주세요.');
      return;
    }

    if (!window.confirm(`Google Chat에 새로운 스페이스 '${newSpaceName}'을(를) 생성하시겠습니까?`)) {
      return;
    }

    setIsCreatingSpace(true);
    try {
      const created = await createGoogleChatSpace(token, newSpaceName, newSpaceDesc);
      setSpaces(prev => [created, ...prev]);
      setSelectedSpace(created);
      setShowCreateModal(false);
      showToast(`Google Chat 스페이스 [${created.displayName || newSpaceName}]이(가) 성공적으로 생성되었습니다.`);
    } catch (err: any) {
      alert(`스페이스 생성 실패: ${err.message}`);
    } finally {
      setIsCreatingSpace(false);
    }
  };

  // Handle Send Message (With user confirmation per Workspace API guidelines)
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !selectedSpace?.name || !messageInput.trim()) return;

    const confirmed = window.confirm(
      `[${selectedSpace.displayName || 'Google Chat'}] 스페이스에 다음 메시지를 전송하시겠습니까?\n\n"${messageInput.trim()}"`
    );
    if (!confirmed) return;

    setIsSending(true);
    try {
      const sentMsg = await sendGoogleChatMessage(token, selectedSpace.name, messageInput.trim());
      setMessages(prev => [...prev, sentMsg]);
      setMessageInput('');
      showToast('메시지가 Google Chat으로 전송되었습니다.');
    } catch (err: any) {
      alert(`메시지 전송 실패: ${err.message}`);
    } finally {
      setIsSending(false);
    }
  };

  // Handle Share Policy to Space
  const handleSharePolicy = async () => {
    if (!token || !selectedSpace?.name || !selectedPolicyToShare) return;

    const title = (selectedPolicyToShare as any).title || (selectedPolicyToShare as any).policy_name || '정책자금';
    const agency = (selectedPolicyToShare as any).agency || (selectedPolicyToShare as any).managing_agency || '정책기관';
    const maxAmount = (selectedPolicyToShare as any).maxAmount || ((selectedPolicyToShare as any).support_scale ? `${(selectedPolicyToShare as any).support_scale}원` : undefined);
    const interestRate = (selectedPolicyToShare as any).interestRate || (selectedPolicyToShare as any).rate;
    const applyUrl = (selectedPolicyToShare as any).applyUrl || (selectedPolicyToShare as any).original_url;

    const confirmed = window.confirm(
      `[${selectedSpace.displayName || 'Google Chat'}] 스페이스에 '${title}' 정책자금 정보를 공유하시겠습니까?`
    );
    if (!confirmed) return;

    setIsSharingPolicy(true);
    try {
      const sentMsg = await sendPolicyShareToGoogleChat(token, selectedSpace.name, {
        title,
        agency,
        maxAmount,
        interestRate,
        applyUrl,
        businessName: profile?.businessName,
        note: shareNote.trim() || undefined
      });

      setMessages(prev => [...prev, sentMsg]);
      setShowShareModal(false);
      setShareNote('');
      showToast(`'${title}' 공고가 Google Chat에 성공적으로 공유되었습니다.`);
    } catch (err: any) {
      alert(`정책 공유 실패: ${err.message}`);
    } finally {
      setIsSharingPolicy(false);
    }
  };

  // Quick message template insertion
  const handleInsertTemplate = (text: string) => {
    setMessageInput(text);
  };

  if (!token) {
    return (
      <div className="bg-white rounded-3xl p-8 sm:p-12 border border-slate-200 shadow-sm text-center space-y-6">
        <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-emerald-500 to-teal-500 text-white flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
          <MessageSquare className="w-8 h-8" />
        </div>
        
        <div className="max-w-md mx-auto space-y-2">
          <h3 className="text-xl font-black text-slate-900">Google Chat 정책자금 협업 및 실시간 알림</h3>
          <p className="text-xs sm:text-sm text-slate-600 font-medium leading-relaxed">
            Google 계정으로 로그인하여 팀원 및 정책지도사와 함께 실시간 정책자금 상담방을 개설하고, 맞춤 공고를 원클릭으로 공유해 보세요.
          </p>
        </div>

        {onGoogleLogin ? (
          <button
            type="button"
            onClick={onGoogleLogin}
            className="px-6 py-3.5 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-bold text-xs sm:text-sm transition-all shadow-md active:scale-95 inline-flex items-center gap-2 cursor-pointer"
          >
            <Users className="w-4 h-4 text-emerald-400" />
            <span>Google 계정으로 로그인하고 Google Chat 연동하기</span>
          </button>
        ) : (
          <p className="text-xs text-amber-600 font-bold bg-amber-50 py-2 px-4 rounded-xl inline-block border border-amber-200">
            상단 메뉴의 Google 로그인 버튼을 통해 인증을 완료해 주세요.
          </p>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fade-in">
      
      {/* Top Banner */}
      <div className="bg-gradient-to-br from-teal-950 via-slate-900 to-slate-900 rounded-3xl p-6 sm:p-8 text-white border border-teal-900/40 shadow-xl relative overflow-hidden">
        <div className="absolute -right-10 -top-10 w-80 h-80 bg-teal-600/15 rounded-full blur-3xl pointer-events-none" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-teal-500/20 text-teal-300 border border-teal-400/30 rounded-full text-xs font-bold mb-3">
              <MessageCircle className="w-3.5 h-3.5" />
              Google Workspace • Google Chat REST API 연동
            </div>
            <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-3">
              Google Chat 실시간 협업 & 상담
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 font-medium max-w-2xl mt-1.5 leading-relaxed">
              Google Chat의 전용 스페이스(Spaces)를 통해 맞춤 정책자금 공고 카드를 팀원에게 공유하고, 전문 지도사와 비대면 질의응답을 실시간으로 주고받을 수 있습니다.
            </p>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto flex-wrap">
            <button
              type="button"
              onClick={() => setShowCreateModal(true)}
              className="px-5 py-3 bg-teal-600 hover:bg-teal-500 text-white rounded-2xl font-bold text-xs sm:text-sm transition-all shadow-lg shadow-teal-600/30 active:scale-95 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>새 스페이스 생성</span>
            </button>

            <button
              type="button"
              onClick={() => setShowShareModal(true)}
              disabled={!selectedSpace}
              className="px-4 py-3 bg-white/10 hover:bg-white/20 text-white rounded-2xl font-bold text-xs sm:text-sm transition-all border border-white/15 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40"
            >
              <Share2 className="w-4 h-4 text-teal-300" />
              <span>정책 공고 공유</span>
            </button>

            <button
              type="button"
              onClick={loadSpaces}
              disabled={isLoadingSpaces}
              className="p-3 bg-white/10 hover:bg-white/20 text-white rounded-2xl font-bold transition-all border border-white/15 flex items-center justify-center cursor-pointer disabled:opacity-50"
              title="새로고침"
            >
              <RefreshCw className={`w-4 h-4 ${isLoadingSpaces ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>
      </div>

      {/* Toast */}
      {toastMessage && (
        <div className="bg-teal-50 border border-teal-200 text-teal-800 p-3.5 px-4 rounded-2xl text-xs font-bold flex items-center gap-2 animate-fade-in shadow-xs">
          <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main 2-Column Chat Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Spaces List (4 cols) */}
        <div className="lg:col-span-4 bg-white rounded-3xl border border-slate-200/90 p-5 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-teal-600" />
              <h3 className="text-sm font-black text-slate-900">내 Google Chat 스페이스</h3>
            </div>
            <span className="text-[11px] font-bold text-slate-400">
              {spaces.length}개 발견
            </span>
          </div>

          {isLoadingSpaces && spaces.length === 0 ? (
            <div className="py-8 text-center space-y-2">
              <div className="w-6 h-6 border-2 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto" />
              <p className="text-xs text-slate-500 font-medium">스페이스 목록 불러오는 중...</p>
            </div>
          ) : spacesError ? (
            <div className="bg-red-50 p-4 rounded-2xl border border-red-200 text-xs text-red-700 space-y-2">
              <div className="flex items-center gap-1.5 font-bold">
                <AlertCircle className="w-4 h-4" />
                <span>조회 오류</span>
              </div>
              <p className="leading-relaxed">{spacesError}</p>
              <button
                type="button"
                onClick={loadSpaces}
                className="text-[11px] font-bold text-red-800 underline cursor-pointer"
              >
                다시 시도
              </button>
            </div>
          ) : spaces.length === 0 ? (
            <div className="py-8 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-teal-50 text-teal-600 flex items-center justify-center mx-auto">
                <MessageSquare className="w-6 h-6" />
              </div>
              <div>
                <p className="text-xs font-black text-slate-800">참여 중인 스페이스가 없습니다</p>
                <p className="text-[11px] text-slate-500 mt-1">상단의 [새 스페이스 생성]을 클릭하여 첫 상담 채널을 개설해 보세요.</p>
              </div>
              <button
                type="button"
                onClick={() => setShowCreateModal(true)}
                className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                스페이스 만들기
              </button>
            </div>
          ) : (
            <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1">
              {spaces.map((space) => {
                const isSelected = selectedSpace?.name === space.name;
                const displayName = space.displayName || (space.type === 'DIRECT_MESSAGE' ? '1:1 다이렉트 메시지' : 'Google Chat Space');
                
                return (
                  <button
                    key={space.name}
                    type="button"
                    onClick={() => setSelectedSpace(space)}
                    className={`w-full text-left p-3 rounded-2xl transition-all border cursor-pointer flex items-center justify-between gap-3 ${
                      isSelected
                        ? 'bg-teal-50 border-teal-300 text-teal-950 shadow-xs'
                        : 'bg-slate-50/70 border-slate-200/70 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5">
                        <MessageSquare className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-teal-600' : 'text-slate-400'}`} />
                        <span className="font-black text-xs truncate block">
                          {displayName}
                        </span>
                      </div>
                      {space.spaceDetails?.description && (
                        <p className="text-[11px] text-slate-500 truncate mt-0.5 pl-5">
                          {space.spaceDetails.description}
                        </p>
                      )}
                    </div>

                    <ArrowRight className={`w-3.5 h-3.5 shrink-0 ${isSelected ? 'text-teal-600' : 'text-slate-300'}`} />
                  </button>
                );
              })}
            </div>
          )}

          {/* Direct link to Google Chat Web */}
          <div className="pt-2 border-t border-slate-100">
            <a
              href="https://chat.google.com"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-2.5 px-3 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>Google Chat 웹앱에서 열기</span>
              <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
            </a>
          </div>
        </div>

        {/* Right Column: Active Space Messages & Interactive Chat (8 cols) */}
        <div className="lg:col-span-8 bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-6 shadow-xs flex flex-col min-h-[560px]">
          
          {selectedSpace ? (
            <>
              {/* Active Space Header */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                    <h3 className="text-base sm:text-lg font-black text-slate-900">
                      {selectedSpace.displayName || 'Google Chat Space'}
                    </h3>
                  </div>
                  {selectedSpace.spaceDetails?.description && (
                    <p className="text-xs text-slate-500 font-medium mt-0.5">
                      {selectedSpace.spaceDetails.description}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto">
                  <button
                    type="button"
                    onClick={() => setShowShareModal(true)}
                    className="px-3 py-1.5 bg-teal-50 hover:bg-teal-100 text-teal-700 border border-teal-200 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                    <span>정책 카드 전송</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => loadMessages(selectedSpace)}
                    disabled={isLoadingMessages}
                    className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-xl transition-colors cursor-pointer"
                    title="메시지 새로고침"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isLoadingMessages ? 'animate-spin' : ''}`} />
                  </button>
                </div>
              </div>

              {/* Messages Body */}
              <div className="flex-1 my-4 space-y-3 overflow-y-auto max-h-[380px] p-2 bg-slate-50/50 rounded-2xl border border-slate-100">
                {isLoadingMessages && messages.length === 0 ? (
                  <div className="py-16 text-center space-y-2">
                    <div className="w-6 h-6 border-2 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto" />
                    <p className="text-xs text-slate-500 font-medium">메시지를 불러오는 중입니다...</p>
                  </div>
                ) : messagesError ? (
                  <div className="bg-red-50 p-4 rounded-xl text-xs text-red-700 border border-red-200">
                    <p className="font-bold">메시지 불러오기 실패:</p>
                    <p>{messagesError}</p>
                  </div>
                ) : messages.length === 0 ? (
                  <div className="py-16 text-center space-y-2">
                    <MessageSquare className="w-8 h-8 text-slate-300 mx-auto" />
                    <p className="text-xs font-black text-slate-700">등록된 대화 내용이 없습니다.</p>
                    <p className="text-[11px] text-slate-500">하단 입력창을 통해 첫 메시지나 정책자금 카드를 전송해 보세요.</p>
                  </div>
                ) : (
                  messages.map((msg, idx) => {
                    const senderName = msg.sender?.displayName || '사용자';
                    const timeStr = msg.createTime 
                      ? new Date(msg.createTime).toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' })
                      : '';
                    const isBot = msg.sender?.type === 'BOT';

                    return (
                      <div key={msg.name || `msg-${idx}`} className="bg-white p-3.5 rounded-2xl border border-slate-200/70 shadow-2xs space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <div className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black text-white ${
                              isBot ? 'bg-indigo-600' : 'bg-teal-600'
                            }`}>
                              {senderName.charAt(0)}
                            </div>
                            <span className="font-black text-slate-800">{senderName}</span>
                            {isBot && (
                              <span className="text-[10px] bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded-md font-bold">BOT</span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-400 font-mono">{timeStr}</span>
                        </div>

                        {/* Message Content */}
                        <div className="text-xs text-slate-700 whitespace-pre-wrap leading-relaxed pl-7">
                          {msg.text}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Quick Template Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-2">
                <span className="text-[11px] font-black text-slate-400 shrink-0 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-500" /> 빠른 질의:
                </span>
                <button
                  type="button"
                  onClick={() => handleInsertTemplate('소상공인 정책자금 신청 시 필요한 준비 서류 목록 안내를 부탁드립니다.')}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-bold shrink-0 transition-colors cursor-pointer"
                >
                  필요 서류 문의
                </button>
                <button
                  type="button"
                  onClick={() => handleInsertTemplate(`[${profile?.businessName || '사업체'}] 신용점수 및 매출 요건 기반 적합 정책자금 진단 요청드립니다.`)}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-bold shrink-0 transition-colors cursor-pointer"
                >
                  요건 심사 진단 요청
                </button>
                <button
                  type="button"
                  onClick={() => handleInsertTemplate('대출 금리 인하 우대 조건과 거치기간 연장 가능 여부가 궁금합니다.')}
                  className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg text-[11px] font-bold shrink-0 transition-colors cursor-pointer"
                >
                  우대금리/거치기간 문의
                </button>
              </div>

              {/* Message Input Form */}
              <form onSubmit={handleSendMessage} className="mt-2 flex items-center gap-2">
                <input
                  type="text"
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  placeholder={`[${selectedSpace.displayName || 'Google Chat'}] 스페이스에 메시지 입력...`}
                  className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-medium text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500 transition-all"
                  disabled={isSending}
                />

                <button
                  type="submit"
                  disabled={isSending || !messageInput.trim()}
                  className="px-5 py-3 bg-teal-600 hover:bg-teal-500 text-white rounded-2xl font-black text-xs transition-all shadow-md shadow-teal-600/20 active:scale-95 flex items-center gap-1.5 disabled:opacity-40 cursor-pointer shrink-0"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>전송</span>
                </button>
              </form>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-8 space-y-3">
              <MessageSquare className="w-12 h-12 text-slate-300" />
              <h4 className="text-base font-black text-slate-800">선택된 스페이스가 없습니다</h4>
              <p className="text-xs text-slate-500 max-w-sm">
                왼쪽 목록에서 대화할 Google Chat 스페이스를 선택하거나, 새로운 협업 스페이스를 생성해 주세요.
              </p>
            </div>
          )}

        </div>

      </div>

      {/* Modal: Create New Google Chat Space */}
      {showCreateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-md w-full shadow-2xl border border-slate-100 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
                  <Plus className="w-4 h-4" />
                </div>
                <h3 className="text-base font-black text-slate-900">새 Google Chat 스페이스 생성</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg text-xs"
              >
                닫기
              </button>
            </div>

            <form onSubmit={handleCreateSpace} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  스페이스 이름 <span className="text-teal-600">*</span>
                </label>
                <input
                  type="text"
                  value={newSpaceName}
                  onChange={(e) => setNewSpaceName(e.target.value)}
                  placeholder="예: [BizMatch] 소상공인 정책자금 상담방"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  스페이스 설명 (선택)
                </label>
                <textarea
                  value={newSpaceDesc}
                  onChange={(e) => setNewSpaceDesc(e.target.value)}
                  rows={2}
                  placeholder="스페이스의 목적 및 상담 주제를 입력하세요."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div className="bg-teal-50 p-3 rounded-xl border border-teal-100 text-[11px] text-teal-800 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span>Google Workspace 정책에 따라 생성된 스페이스는 본인 및 초대된 구성원에게만 안전하게 공유됩니다.</span>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold"
                >
                  취소
                </button>
                <button
                  type="submit"
                  disabled={isCreatingSpace}
                  className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-black transition-all shadow-md flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                >
                  {isCreatingSpace ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Plus className="w-3.5 h-3.5" />
                  )}
                  <span>스페이스 개설하기</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Share Policy Fund to Google Chat */}
      {showShareModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 sm:p-8 max-w-lg w-full shadow-2xl border border-slate-100 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-600 flex items-center justify-center">
                  <Share2 className="w-4 h-4" />
                </div>
                <h3 className="text-base font-black text-slate-900">Google Chat에 정책자금 카드 공유</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowShareModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg text-xs"
              >
                닫기
              </button>
            </div>

            <div className="space-y-4">
              {/* Target Space info */}
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 text-xs">
                <span className="text-[10px] font-black text-slate-400 uppercase block">전송 대상 스페이스</span>
                <span className="font-black text-teal-900 text-sm">{selectedSpace?.displayName || '선택된 스페이스 없음'}</span>
              </div>

              {/* Policy Selector */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  공유할 정책자금 선택
                </label>
                {favorites.length === 0 ? (
                  <div className="p-3 bg-amber-50 rounded-xl text-xs text-amber-800 border border-amber-200">
                    스크랩된 관심 정책자금이 없습니다. 자금 추천 목록에서 스크랩 후 공유하거나 아래에서 직접 선택하세요.
                  </div>
                ) : (
                  <select
                    value={(selectedPolicyToShare as any)?.id || (selectedPolicyToShare as any)?.title || ''}
                    onChange={(e) => {
                      const found = favorites.find(f => ((f as any).id || (f as any).title) === e.target.value);
                      if (found) setSelectedPolicyToShare(found);
                    }}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:ring-2 focus:ring-teal-500 cursor-pointer"
                  >
                    {favorites.map((fav, idx) => {
                      const title = (fav as any).title || (fav as any).policy_name;
                      const agency = (fav as any).agency || (fav as any).managing_agency;
                      return (
                        <option key={(fav as any).id || `fav-${idx}`} value={(fav as any).id || (fav as any).title}>
                          [{agency}] {title}
                        </option>
                      );
                    })}
                  </select>
                )}
              </div>

              {/* Note input */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  추가 전달 메시지 / 질문 (선택)
                </label>
                <textarea
                  value={shareNote}
                  onChange={(e) => setShareNote(e.target.value)}
                  rows={2}
                  placeholder="예: 이번 분기 우리 기업에 가장 적합한 조건인지 검토 부탁드립니다."
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowShareModal(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold"
                >
                  취소
                </button>
                <button
                  type="button"
                  onClick={handleSharePolicy}
                  disabled={isSharingPolicy || !selectedPolicyToShare}
                  className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-black transition-all shadow-md flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                >
                  {isSharingPolicy ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Send className="w-3.5 h-3.5" />
                  )}
                  <span>Google Chat으로 카드 전송</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
