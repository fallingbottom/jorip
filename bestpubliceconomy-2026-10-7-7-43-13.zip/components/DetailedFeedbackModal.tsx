import React, { useState } from 'react';
import { PolicyFund, ReanalysisFeedback } from '../types';
import {
  X,
  Sparkles,
  ThumbsUp,
  ThumbsDown,
  Star,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  Sliders,
  FileQuestion,
  TrendingDown,
  Building2,
  ChevronRight,
  ShieldCheck,
  RotateCcw,
  Check
} from 'lucide-react';

interface DetailedFeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  matchedFunds: PolicyFund[];
  onSaveFeedbackOnly: (feedback: ReanalysisFeedback) => void;
  onReanalyze: (feedback: ReanalysisFeedback) => Promise<void>;
  isReanalyzing?: boolean;
}

const COMMON_REASONS = [
  { id: 'rate_high', label: '금리가 생각보다 높음 (초저금리/이차보전 희망)', icon: '📉' },
  { id: 'industry_mismatch', label: '업종 특성 및 사업 모델 불일치', icon: '🏢' },
  { id: 'amount_insufficient', label: '대출 한도가 부족함 (더 큰 한도 필요)', icon: '💰' },
  { id: 'complex_docs', label: '신청 자격/구비 서류 요건이 너무 까다로움', icon: '📑' },
  { id: 'direct_loan_pref', label: '보증서(신보/재단) 대신 공단 직접대출 선호', icon: '🏛️' },
  { id: 'deadline_urgent', label: '접수 마감 임박 / 상시 신청 가능 자금 희망', icon: '⏳' },
  { id: 'grace_period', label: '거치 기간(이자만 납부)이 긴 상품 필요', icon: '📅' },
  { id: 'online_simple', label: '비대면·간편 신청 위주 상품 희망', icon: '📱' },
];

const INTEREST_OPTIONS = [
  { value: 0, label: '제한 없음 (전체)' },
  { value: 2.0, label: '연 2.0% 이하 (초저금리)' },
  { value: 2.5, label: '연 2.5% 이하' },
  { value: 3.0, label: '연 3.0% 이하' },
  { value: 3.5, label: '연 3.5% 이하' },
];

const FUND_CATEGORY_OPTIONS = [
  { value: 'ALL', label: '전체 유형' },
  { value: '운전자금 (경영안정/원자재/인건비)', label: '운전자금' },
  { value: '시설자금 (사업장 매입/설비/인테리어)', label: '시설자금' },
  { value: '공단 직접대출 (소진공/중진공 직접융자)', label: '직접대출' },
  { value: '이차보전지원 (시중은행 금리 2~3%p 지원)', label: '이차보전' },
  { value: '신용보증재단 보증서 대출', label: '보증서대출' },
];

const AGENCY_OPTIONS = [
  { value: 'ALL', label: '전체 기관' },
  { value: '소상공인시장진흥공단 (소진공)', label: '소진공' },
  { value: '중소벤처기업진흥공단 (중진공)', label: '중진공' },
  { value: '지역신용보증재단 (신보재단)', label: '신용보증재단' },
  { value: '신용보증기금 / 기술보증기금', label: '신보/기보' },
  { value: '지자체 (시·도청 중소기업육성자금)', label: '지자체' },
];

export const DetailedFeedbackModal: React.FC<DetailedFeedbackModalProps> = ({
  isOpen,
  onClose,
  matchedFunds = [],
  onSaveFeedbackOnly,
  onReanalyze,
  isReanalyzing = false,
}) => {
  const [rating, setRating] = useState<number>(3);
  const [isHelpful, setIsHelpful] = useState<boolean>(true);
  const [selectedReasons, setSelectedReasons] = useState<string[]>([]);
  
  // Specific Fund Exclusion State: { [fundId]: isExcluded }
  const [excludedFunds, setExcludedFunds] = useState<Record<string, boolean>>({});
  const [excludedReasons, setExcludedReasons] = useState<Record<string, string>>({});
  
  // Re-analysis Preferences
  const [preferredRateMax, setPreferredRateMax] = useState<number>(0);
  const [preferredCategory, setPreferredCategory] = useState<string>('ALL');
  const [preferredAgency, setPreferredAgency] = useState<string>('ALL');
  const [customPrompt, setCustomPrompt] = useState<string>('');

  if (!isOpen) return null;

  const toggleReason = (label: string) => {
    setSelectedReasons((prev) =>
      prev.includes(label) ? prev.filter((r) => r !== label) : [...prev, label]
    );
  };

  const toggleFundExclusion = (fundKey: string) => {
    setExcludedFunds((prev) => ({
      ...prev,
      [fundKey]: !prev[fundKey],
    }));
  };

  const handleFundExcludeReason = (fundKey: string, reason: string) => {
    setExcludedReasons((prev) => ({
      ...prev,
      [fundKey]: reason,
    }));
  };

  const constructFeedbackPayload = (): ReanalysisFeedback => {
    const excludedList = Object.entries(excludedFunds)
      .filter(([_, isExc]) => isExc)
      .map(([fundKey]) => fundKey);

    return {
      satisfactionRating: rating,
      isHelpful,
      selectedReasons,
      excludedFundIds: excludedList,
      excludedFundReasons: excludedReasons,
      preferredInterestRateMax: preferredRateMax > 0 ? preferredRateMax : undefined,
      preferredFundCategory: preferredCategory,
      preferredAgency: preferredAgency,
      userCustomPrompt: customPrompt.trim() || undefined,
      createdAt: new Date().toISOString(),
    };
  };

  const handleSaveOnly = () => {
    const payload = constructFeedbackPayload();
    onSaveFeedbackOnly(payload);
    onClose();
  };

  const handleTriggerReanalysis = async () => {
    const payload = constructFeedbackPayload();
    await onReanalyze(payload);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-fade-in">
      <div
        className="relative bg-white rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden border border-slate-200 flex flex-col max-h-[92vh] animate-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-900 text-white flex items-start justify-between relative shrink-0">
          <div className="space-y-1.5 pr-8">
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-blue-500/30 border border-blue-400/30 text-blue-300">
                <Sliders className="w-4 h-4" />
              </span>
              <h3 className="text-base sm:text-lg font-black tracking-tight">
                AI 추천 피드백 및 조건 재분석
              </h3>
            </div>
            <p className="text-xs text-blue-100/90 leading-relaxed">
              추천 결과 중 마음에 들지 않거나 부적합한 항목을 알려주시면, 대표님의 의견을 100% 반영하여 AI가 더 유리한 조건으로 즉시 다시 분석합니다.
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            disabled={isReanalyzing}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Modal Content */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto flex-1 text-slate-800">
          {/* Section 1: Overall Satisfaction & Stars */}
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                1. 이번 AI 추천 결과는 어떠셨나요?
              </span>

              {/* Thumbs & Rating */}
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map((starVal) => (
                    <button
                      key={starVal}
                      type="button"
                      onClick={() => {
                        setRating(starVal);
                        setIsHelpful(starVal >= 4);
                      }}
                      className="p-1 transition-transform hover:scale-125 cursor-pointer"
                    >
                      <Star
                        className={`w-5 h-5 ${
                          starVal <= rating
                            ? 'text-amber-400 fill-amber-400'
                            : 'text-slate-300'
                        }`}
                      />
                    </button>
                  ))}
                  <span className="text-xs font-bold text-slate-600 ml-1">
                    {rating}점
                  </span>
                </div>

                <div className="h-4 w-[1px] bg-slate-300" />

                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setIsHelpful(true)}
                    className={`px-2 py-1 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-all ${
                      isHelpful
                        ? 'bg-blue-600 text-white shadow-2xs'
                        : 'bg-white text-slate-600 border border-slate-200'
                    }`}
                  >
                    <ThumbsUp className="w-3.5 h-3.5" />
                    <span>만족</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsHelpful(false)}
                    className={`px-2 py-1 rounded-lg text-xs font-bold flex items-center gap-1 cursor-pointer transition-all ${
                      !isHelpful
                        ? 'bg-rose-600 text-white shadow-2xs'
                        : 'bg-white text-slate-600 border border-slate-200'
                    }`}
                  >
                    <ThumbsDown className="w-3.5 h-3.5" />
                    <span>개선 필요</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Dissatisfaction / Improvement Reasons (Multi-select) */}
          <div className="space-y-2.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                2. 개선 또는 불만족 사유를 선택해 주세요 (다중 선택 가능)
              </label>
              <span className="text-[11px] text-slate-400 font-medium">
                선택 항목: {selectedReasons.length}개
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {COMMON_REASONS.map((reason) => {
                const isSelected = selectedReasons.includes(reason.label);
                return (
                  <button
                    key={reason.id}
                    type="button"
                    onClick={() => toggleReason(reason.label)}
                    className={`p-3 rounded-xl text-left text-xs font-bold border transition-all flex items-center gap-2 cursor-pointer ${
                      isSelected
                        ? 'bg-blue-50/80 border-blue-500 text-blue-900 shadow-2xs scale-[1.01]'
                        : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                    }`}
                  >
                    <span className="text-sm shrink-0">{reason.icon}</span>
                    <span className="flex-1 leading-snug">{reason.label}</span>
                    {isSelected && (
                      <Check className="w-4 h-4 text-blue-600 shrink-0 stroke-[3]" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Section 3: Exclude specific funds from current recommendation */}
          {matchedFunds && matchedFunds.length > 0 && (
            <div className="space-y-2.5">
              <label className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                <FileQuestion className="w-4 h-4 text-indigo-600" />
                3. 이번 재분석에서 제외할 정책자금 선택 (선택 시 다른 자금으로 교체)
              </label>

              <div className="space-y-2">
                {matchedFunds.map((fund) => {
                  const fundKey = fund.id || fund.title;
                  const isExcluded = !!excludedFunds[fundKey];
                  const currentReason = excludedReasons[fundKey] || '';

                  return (
                    <div
                      key={fundKey}
                      className={`p-3 rounded-xl border transition-all ${
                        isExcluded
                          ? 'bg-rose-50/60 border-rose-300 opacity-90'
                          : 'bg-white border-slate-200/90'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-3">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-slate-100 text-slate-700">
                              {fund.agency}
                            </span>
                            <span
                              className={`text-xs font-black truncate ${
                                isExcluded
                                  ? 'line-through text-rose-800'
                                  : 'text-slate-900'
                              }`}
                            >
                              {fund.title}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2">
                            <span>금리: {fund.interestRate}</span>
                            <span>•</span>
                            <span>한도: {fund.maxAmount}</span>
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => toggleFundExclusion(fundKey)}
                          className={`px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer shrink-0 ${
                            isExcluded
                              ? 'bg-rose-600 text-white shadow-2xs'
                              : 'bg-slate-100 hover:bg-rose-50 hover:text-rose-700 text-slate-600 border border-slate-200'
                          }`}
                        >
                          {isExcluded ? '✕ 재분석 시 제외됨' : '이 자금 제외하기'}
                        </button>
                      </div>

                      {/* Quick reason if excluded */}
                      {isExcluded && (
                        <div className="mt-2.5 pt-2 border-t border-rose-200/60 flex items-center gap-1.5 flex-wrap animate-fade-in">
                          <span className="text-[10px] text-rose-700 font-bold">
                            제외 사유:
                          </span>
                          {['금리 불만', '업종 불일치', '신청 불가/마감', '자격 미달'].map(
                            (r) => (
                              <button
                                key={r}
                                type="button"
                                onClick={() => handleFundExcludeReason(fundKey, r)}
                                className={`text-[10px] px-2 py-0.5 rounded font-bold cursor-pointer transition-colors ${
                                  currentReason === r
                                    ? 'bg-rose-700 text-white'
                                    : 'bg-white text-rose-700 border border-rose-200 hover:bg-rose-100'
                                }`}
                              >
                                {r}
                              </button>
                            )
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Section 4: Target Re-analysis Tuning (Filters & Custom Prompt) */}
          <div className="space-y-3 pt-1">
            <label className="text-xs font-black text-slate-900 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-blue-600" />
              4. 재분석 정밀 조건 맞춤 튜닝
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              {/* Interest Rate Option */}
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-slate-600">
                  희망 최대 금리
                </span>
                <select
                  value={preferredRateMax}
                  onChange={(e) => setPreferredRateMax(parseFloat(e.target.value))}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all cursor-pointer"
                >
                  {INTEREST_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Fund Category Option */}
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-slate-600">
                  선호 자금 유형
                </span>
                <select
                  value={preferredCategory}
                  onChange={(e) => setPreferredCategory(e.target.value)}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all cursor-pointer"
                >
                  {FUND_CATEGORY_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Preferred Agency */}
              <div className="space-y-1">
                <span className="text-[11px] font-bold text-slate-600">
                  선호 주관 기관
                </span>
                <select
                  value={preferredAgency}
                  onChange={(e) => setPreferredAgency(e.target.value)}
                  className="w-full text-xs font-bold p-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all cursor-pointer"
                >
                  {AGENCY_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Custom Notes / Prompt Textarea */}
            <div className="space-y-1 pt-1">
              <span className="text-[11px] font-bold text-slate-600 flex items-center justify-between">
                <span>AI에게 직접 전달할 추가 요청 사항 (자유 작성)</span>
                <span className="text-[10px] text-slate-400 font-normal">
                  선택 사항
                </span>
              </span>
              <textarea
                value={customPrompt}
                onChange={(e) => setCustomPrompt(e.target.value)}
                placeholder="예: 제조업이 아닌 온라인 쇼핑몰/유통업에 적합한 단기 운전자금 위주로 추천해 주세요. 최소 1년 이상 거치 기간이 있는 상품을 우선적으로 찾아주세요."
                rows={3}
                className="w-full text-xs p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all resize-none text-slate-800 placeholder:text-slate-400"
              />
            </div>
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <button
            type="button"
            onClick={handleSaveOnly}
            disabled={isReanalyzing}
            className="w-full sm:w-auto px-4 py-2.5 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs rounded-xl border border-slate-300 transition-all cursor-pointer"
          >
            피드백만 저장하기
          </button>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              disabled={isReanalyzing}
              className="w-1/3 sm:w-auto px-4 py-2.5 text-slate-500 hover:text-slate-700 font-bold text-xs transition-colors cursor-pointer"
            >
              취소
            </button>

            <button
              type="button"
              onClick={handleTriggerReanalysis}
              disabled={isReanalyzing}
              className="flex-1 sm:flex-none px-6 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black text-xs sm:text-sm rounded-xl shadow-lg shadow-blue-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {isReanalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>AI 맞춤 조건 재분석 진행 중...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-amber-300" />
                  <span>조건 반영하여 즉시 재분석 ⚡</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
