import React, { useState, useEffect } from 'react';
import { Users, FileText, CheckCircle, XCircle, TrendingUp, Landmark } from 'lucide-react';
import { getCustomers, getApplications } from '../../services/crmService';
import { getAnnouncements } from '../../services/announcementService';
import { CrmCustomer, CrmApplication, PolicyAnnouncement } from '../../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export const AdminDashboardStats: React.FC = () => {
  const [customers, setCustomers] = useState<CrmCustomer[]>([]);
  const [applications, setApplications] = useState<CrmApplication[]>([]);
  const [announcements, setAnnouncements] = useState<PolicyAnnouncement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        const custData = await getCustomers();
        setCustomers(custData);
        
        let allApps: CrmApplication[] = [];
        for (const cust of custData) {
          const apps = await getApplications(cust.id);
          allApps = [...allApps, ...apps];
        }
        setApplications(allApps);

        const anns = getAnnouncements();
        setAnnouncements(anns);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    loadData();
  }, []);

  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();

  const thisMonthApps = applications.filter(a => {
    const d = new Date(a.applyDate);
    return d.getMonth() === currentMonth && d.getFullYear() === currentYear;
  });

  const approvals = thisMonthApps.filter(a => a.status === '승인');
  const rejections = thisMonthApps.filter(a => a.status === '부결');
  
  const approvalRate = thisMonthApps.length > 0 ? (approvals.length / thisMonthApps.length) * 100 : 0;
  
  const directApps = applications.filter(a => a.applyType === '직접대출').length;
  const indirectApps = applications.filter(a => a.applyType === '대리대출').length;

  const chartDataMap: Record<string, { agency: string, active: number, inactive: number }> = {};
  announcements.forEach(a => {
    if (!chartDataMap[a.agency]) {
      chartDataMap[a.agency] = { agency: a.agency, active: 0, inactive: 0 };
    }
    if (a.isActive) {
      chartDataMap[a.agency].active += 1;
    } else {
      chartDataMap[a.agency].inactive += 1;
    }
  });
  const chartData = Object.values(chartDataMap);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-black text-slate-900">대시보드 요약 (Sheet 5)</h2>
        <p className="text-slate-500 mt-1">월별 정책자금 신청 및 승인 현황</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center text-blue-600">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-500">총 등록 고객수</p>
              <p className="text-2xl font-black text-slate-900">{customers.length}명</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-indigo-100 flex items-center justify-center text-indigo-600">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-500">금월 신청 건수</p>
              <p className="text-2xl font-black text-slate-900">{thisMonthApps.length}건</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center text-green-600">
              <CheckCircle className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-500">금월 승인 건수</p>
              <p className="text-2xl font-black text-slate-900">{approvals.length}건</p>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-red-100 flex items-center justify-center text-red-600">
              <XCircle className="w-6 h-6" />
            </div>
            <div>
              <p className="text-xs font-bold text-slate-500">금월 부결 건수</p>
              <p className="text-2xl font-black text-slate-900">{rejections.length}건</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col justify-center items-center h-48">
          <TrendingUp className="w-8 h-8 text-indigo-400 mb-3" />
          <h3 className="text-sm font-bold text-slate-500">금월 승인률</h3>
          <p className="text-4xl font-black text-slate-900 mt-2">{approvalRate.toFixed(1)}%</p>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 flex flex-col justify-center items-center h-48">
          <Landmark className="w-8 h-8 text-emerald-400 mb-3" />
          <h3 className="text-sm font-bold text-slate-500">직접 vs 대리 비율 (누적)</h3>
          <div className="flex items-center gap-4 mt-2">
            <div className="text-center">
              <p className="text-2xl font-black text-slate-900">{directApps}</p>
              <p className="text-xs font-bold text-slate-500">직접대출</p>
            </div>
            <div className="text-slate-300 font-black text-2xl">:</div>
            <div className="text-center">
              <p className="text-2xl font-black text-slate-900">{indirectApps}</p>
              <p className="text-xs font-bold text-slate-500">대리대출</p>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
        <h3 className="text-lg font-black text-slate-900 mb-6">기관별 정책자금 현황</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
              <XAxis dataKey="agency" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b', fontWeight: 700 }} />
              <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#64748b', fontWeight: 700 }} />
              <Tooltip 
                cursor={{ fill: '#f8fafc' }}
                contentStyle={{ borderRadius: '12px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                labelStyle={{ fontWeight: 900, color: '#0f172a', marginBottom: '4px' }}
              />
              <Legend iconType="circle" wrapperStyle={{ fontSize: '12px', fontWeight: 700, paddingTop: '20px' }} />
              <Bar dataKey="active" stackId="a" name="활성 (Active)" fill="#3b82f6" radius={[0, 0, 4, 4]} maxBarSize={50} />
              <Bar dataKey="inactive" stackId="a" name="비활성 (Inactive)" fill="#cbd5e1" radius={[4, 4, 0, 0]} maxBarSize={50} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
