import React, { useState, useEffect, useMemo } from 'react';
import { 
  Sliders, 
  Sparkles, 
  RotateCcw, 
  Save, 
  Check, 
  Cpu, 
  TrendingUp, 
  ShieldCheck, 
  Zap, 
  Layers, 
  Building2, 
  Leaf, 
  Users, 
  Award, 
  GraduationCap, 
  Globe, 
  HeartHandshake, 
  FileCheck2, 
  SlidersHorizontal, 
  Copy, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle, 
  Info,
  ChevronRight,
  Flame,
  Gauge
} from 'lucide-react';
import { 
  getPolicyBonusWeights, 
  savePolicyBonusWeights, 
  resetPolicyBonusWeights, 
  applyPresetBonusWeights, 
  DEFAULT_BONUS_WEIGHTS, 
  BONUS_WEIGHT_PRESETS,
  PolicyBonusWeights 
} from '../../services/matchingParamService';
import { generateDeepLearningApprovalReport, getApprovalLikelihoodTier } from '../../services/deepLearningApprovalEngine';
import { UserProfile, Industry, BusinessType, PolicyFund } from '../../types';

interface SampleClientCase {
  id: string;
  name: string;
  representative: string;
  industryName: string;
  industry: Industry;
  revenue: number;
  creditScore: number;
  activeBonusesSummary: string[];
  profile: UserProfile;
}

const SAMPLE_CLIENT_CASES: SampleClientCase[] = [
  {
    id: 'case-smart-mfg',
    name: '(주)대호정밀가공',
    representative: '김대호',
    industryName: '정밀기계제조업',
    industry: Industry.MANUFACTURING,
    revenue: 380000000,
    creditScore: 780,
    activeBonusesSummary: ['스마트공방(ERP/공정자동화) 도입', '탄소중립 고효율 모터 교체'],
    profile: {
      businessName: '(주)대호정밀가공',
      name: '김대호',
      businessRegistrationNumber: '134-86-99214',
      businessAddress: '경기 안산시 단원구 산단로 123',
      businessType: BusinessType.CORPORATION,
      industry: Industry.MANUFACTURING,
      foundedYear: '2020',
      annualRevenue: 380000000,
      creditScore: 780,
      employees: 5,
      fundingNeed: 80000000,
      location: '경기 안산 반월공단',
      expectedProfitMargin: 18,
      cashFlowStatus: 72,
      debt1Tier: 80000000,
      debt2Tier: 0,
      debtCardLoan: 0,
      debtOther: 0,
      hasTaxArrears: false,
      hasOverdue: false,
      isMyDataLinked: true,
      policyBonusFactors: {
        hasSmartFactory: true,
        smartFactoryLevel: 'SMART_WORKSHOP',
        hasCarbonNeutrality: true,
        carbonCertType: 'ENERGY_SAVING',
        hasJobCreation: false,
        hasVentureOrInnoBiz: false,
        hasCreditEducation: false
      }
    }
  },
  {
    id: 'case-green-bakery',
    name: '청년그린베이커리',
    representative: '이지은',
    industryName: '제과제빵·요식업',
    industry: Industry.RESTAURANT,
    revenue: 160000000,
    creditScore: 720,
    activeBonusesSummary: ['청년 정규직 2명 신규 채용', '친환경 포장재 탄소중립 실천'],
    profile: {
      businessName: '청년그린베이커리',
      name: '이지은',
      businessRegistrationNumber: '211-12-88741',
      businessAddress: '서울 마포구 포은로 45',
      businessType: BusinessType.INDIVIDUAL,
      industry: Industry.RESTAURANT,
      foundedYear: '2022',
      annualRevenue: 160000000,
      creditScore: 720,
      employees: 3,
      fundingNeed: 40000000,
      location: '서울 마포구',
      expectedProfitMargin: 22,
      cashFlowStatus: 68,
      debt1Tier: 30000000,
      debt2Tier: 0,
      debtCardLoan: 0,
      debtOther: 0,
      hasTaxArrears: false,
      hasOverdue: false,
      isMyDataLinked: true,
      policyBonusFactors: {
        hasSmartFactory: false,
        hasCarbonNeutrality: true,
        carbonCertType: 'PLEDGE',
        hasJobCreation: true,
        hasVentureOrInnoBiz: false,
        hasCreditEducation: true
      }
    }
  },
  {
    id: 'case-tech-venture',
    name: '(주)케이테크바이오',
    representative: '최성민',
    industryName: '바이오·소프트웨어',
    industry: Industry.IT_SOFTWARE,
    revenue: 520000000,
    creditScore: 840,
    activeBonusesSummary: ['벤처기업 인증', '특허 2건 등록', '정책자금 사전교육 이수'],
    profile: {
      businessName: '(주)케이테크바이오',
      name: '최성민',
      businessRegistrationNumber: '119-81-65432',
      businessAddress: '경기 성남시 분당구 판교역로 166',
      businessType: BusinessType.CORPORATION,
      industry: Industry.IT_SOFTWARE,
      foundedYear: '2021',
      annualRevenue: 520000000,
      creditScore: 840,
      employees: 8,
      fundingNeed: 150000000,
      location: '경기 성남 판교',
      expectedProfitMargin: 28,
      cashFlowStatus: 85,
      debt1Tier: 120000000,
      debt2Tier: 0,
      debtCardLoan: 0,
      debtOther: 0,
      hasTaxArrears: false,
      hasOverdue: false,
      isMyDataLinked: true,
      policyBonusFactors: {
        hasSmartFactory: false,
        hasCarbonNeutrality: false,
        hasJobCreation: true,
        hasVentureOrInnoBiz: true,
        hasCreditEducation: true
      }
    }
  },
  {
    id: 'case-general-dining',
    name: '을지로전통골목식당',
    representative: '박영호',
    industryName: '일반음식점업',
    industry: Industry.RESTAURANT,
    revenue: 110000000,
    creditScore: 690,
    activeBonusesSummary: ['기본 가점 미보유 (표준 심사)'],
    profile: {
      businessName: '을지로전통골목식당',
      name: '박영호',
      businessRegistrationNumber: '104-22-33419',
      businessAddress: '서울 중구 을지로 12길 8',
      businessType: BusinessType.INDIVIDUAL,
      industry: Industry.RESTAURANT,
      foundedYear: '2018',
      annualRevenue: 110000000,
      creditScore: 690,
      employees: 2,
      fundingNeed: 30000000,
      location: '서울 중구',
      expectedProfitMargin: 14,
      cashFlowStatus: 58,
      debt1Tier: 40000000,
      debt2Tier: 10000000,
      debtCardLoan: 0,
      debtOther: 0,
      hasTaxArrears: false,
      hasOverdue: false,
      isMyDataLinked: false,
      policyBonusFactors: {
        hasSmartFactory: false,
        hasCarbonNeutrality: false,
        hasJobCreation: false,
        hasVentureOrInnoBiz: false,
        hasCreditEducation: false
      }
    }
  }
];

const SIMULATION_POLICY_TARGETS: PolicyFund[] = [
  {
    id: 'sim-fund-1',
    title: '소진공 소공인특화자금 (스마트제조 직접대출)',
    agency: '소상공인시장진흥공단',
    category: '직접대출',
    maxAmount: '최대 1억원',
    interestRate: '연 3.2%',
    description: '스마트공방 및 공정자동화 구축 소공인 전용 우대자금',
    eligibility: '제조업 소공인',
    applicationDeadline: '연중 상시',
    contactInfo: '1357',
    requiredDocuments: ['사업자등록증명', '공장등록증'],
    applicationProcedure: ['온라인 접수', '현장실사', '직접입금'],
    writingGuide: '공정 자동화 설비 도입 내역을 명시하세요.',
    announcementDate: '2026-01-01',
    startDate: '2026-01-01',
    endDate: '2026-12-31'
  },
  {
    id: 'sim-fund-2',
    title: '정부 녹색금융 탄소중립 특례보증',
    agency: '지역신용보증재단 / 시중은행',
    category: '보증부대출',
    maxAmount: '최대 7,000만원',
    interestRate: '연 2.8%',
    description: '탄소중립 실천 및 고효율 친환경 설비 도입 소상공인 이차보전',
    eligibility: 'ESG 탄소중립 실천 사업자',
    applicationDeadline: '예산 소진 시까지',
    contactInfo: '지역재단 콜센터',
    requiredDocuments: ['사업자등록증명', '탄소서약서'],
    applicationProcedure: ['보증신청', '전자보증서', '은행 대출'],
    writingGuide: '에너지 절감 효과를 기술하세요.',
    announcementDate: '2026-01-01',
    startDate: '2026-01-01',
    endDate: '2026-12-31'
  },
  {
    id: 'sim-fund-3',
    title: '청년고용특별자금 (일자리 창출 우대)',
    agency: '소진공 / 국민은행',
    category: '대리대출',
    maxAmount: '최대 5,000만원',
    interestRate: '연 3.1%',
    description: '청년 대표자 또는 청년 신규 고용 소상공인 금리 우대',
    eligibility: '청년 고용 소상공인',
    applicationDeadline: '매월 초 접수',
    contactInfo: '1357',
    requiredDocuments: ['4대보험 가입자명부'],
    applicationProcedure: ['확인서 발급', '은행 대출'],
    writingGuide: '고용 유지 계획을 기술하세요.',
    announcementDate: '2026-01-01',
    startDate: '2026-01-01',
    endDate: '2026-12-31'
  }
];

export const MatchingEngineTuningPanel: React.FC = () => {
  const [weights, setWeights] = useState<PolicyBonusWeights>(getPolicyBonusWeights());
  const [isSaved, setIsSaved] = useState<boolean>(false);
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [selectedCaseId, setSelectedCaseId] = useState<string>('case-smart-mfg');
  const [selectedFundIndex, setSelectedFundIndex] = useState<number>(0);

  // Sync listener
  useEffect(() => {
    const handleSync = (e: any) => {
      if (e.detail) {
        setWeights(e.detail);
      }
    };
    window.addEventListener('bizmatch_bonus_weights_updated', handleSync);
    return () => window.removeEventListener('bizmatch_bonus_weights_updated', handleSync);
  }, []);

  const selectedCase = useMemo(() => {
    return SAMPLE_CLIENT_CASES.find(c => c.id === selectedCaseId) || SAMPLE_CLIENT_CASES[0];
  }, [selectedCaseId]);

  const selectedFund = useMemo(() => {
    return SIMULATION_POLICY_TARGETS[selectedFundIndex] || SIMULATION_POLICY_TARGETS[0];
  }, [selectedFundIndex]);

  // Handle Save
  const handleSave = () => {
    savePolicyBonusWeights(weights);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  // Handle Reset
  const handleReset = () => {
    const def = resetPolicyBonusWeights();
    setWeights(def);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  // Handle Preset Apply
  const handlePresetApply = (key: string) => {
    const applied = applyPresetBonusWeights(key);
    setWeights(applied);
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2000);
  };

  // Copy Config JSON
  const handleCopyConfig = () => {
    navigator.clipboard.writeText(JSON.stringify(weights, null, 2));
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  // Run live calculation for the selected sample case
  // 1) Baseline with default weights
  const defaultReport = useMemo(() => {
    return generateDeepLearningApprovalReport(selectedCase.profile, selectedFund);
  }, [selectedCase, selectedFund]);

  // 2) Tuned report with current sliders
  const tunedReport = useMemo(() => {
    // Current weights are already saved to state, run calculation
    return generateDeepLearningApprovalReport(selectedCase.profile, selectedFund);
  }, [selectedCase, selectedFund, weights]);

  const scoreDiff = tunedReport.overallProbability - defaultReport.overallProbability;
  const tunedTier = getApprovalLikelihoodTier(tunedReport.overallProbability);
  const defaultTier = getApprovalLikelihoodTier(defaultReport.overallProbability);

  return (
    <div className="space-y-7 animate-fade-in pb-16">
      {/* Top Console Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-slate-900 text-white p-6 sm:p-8 border border-slate-800 shadow-xl">
        <div className="absolute -right-10 -bottom-10 w-72 h-72 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute right-12 top-6 text-white/5 pointer-events-none hidden lg:block">
          <Cpu className="w-56 h-56" />
        </div>

        <div className="relative z-10 space-y-4 max-w-4xl">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="px-3 py-1 bg-amber-400 text-slate-950 font-black rounded-xl flex items-center gap-1.5 shadow-xs">
              <Zap className="w-3.5 h-3.5 fill-slate-950" />
              매칭 엔진 튜닝 모드
            </span>
            <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 font-bold rounded-xl border border-emerald-400/30 flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              실시간 AI 예측 모델 동기화 활성 (Live Synced)
            </span>
            <span className="text-slate-400">
              최근 튜닝: {weights.lastTunedAt || '방금 전'}
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight leading-tight">
            AI 정책자금 가점 가중치 & 승인 예측 알고리즘 튜닝 콘솔
          </h2>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-2xl">
            스마트공장·스마트공방 도입, 탄소중립 실천, 청년 일자리 창출, 기술특허 등 
            <strong className="text-indigo-300"> 정책별 가점 항목의 가중치를 슬라이더로 조절</strong>하여, 
            사용자 진단 및 B2B 심사 샌드박스의 AI 승인 확률에 즉각 반영합니다.
          </p>

          {/* Quick Preset Selector */}
          <div className="pt-2 flex flex-wrap items-center gap-2">
            <span className="text-xs text-slate-400 font-bold mr-1">⚡ 추천 튜닝 프리셋:</span>
            {Object.keys(BONUS_WEIGHT_PRESETS).map(key => {
              const p = BONUS_WEIGHT_PRESETS[key];
              const isActive = weights.activePreset === key;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => handlePresetApply(key)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-indigo-600 text-white shadow-md ring-2 ring-indigo-400/40'
                      : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
                  }`}
                >
                  <span>{p.presetName?.split(' ')[1] || p.presetName}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Action Header Buttons */}
        <div className="mt-6 pt-5 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-3 relative z-10">
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400">
              현재 적용 모드: <strong className="text-amber-300">{weights.presetName}</strong>
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={handleCopyConfig}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition-all border border-slate-700 flex items-center gap-1.5 cursor-pointer"
              title="현재 가중치 JSON 복사"
            >
              {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{isCopied ? '복사됨' : '설정값 복사'}</span>
            </button>

            <button
              type="button"
              onClick={handleReset}
              className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition-all border border-slate-700 flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>기본 가중치 리셋</span>
            </button>

            <button
              type="button"
              onClick={handleSave}
              className="px-5 py-2 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white rounded-xl text-xs sm:text-sm font-black transition-all shadow-md shadow-indigo-600/30 flex items-center gap-2 cursor-pointer active:scale-[0.98]"
            >
              {isSaved ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
              <span>{isSaved ? '엔진 즉각 반영 완료!' : '가중치 저장 및 즉시 배포'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Dual Grid: Sliders Controls (Left 7 Cols) + Realtime Live Sandbox (Right 5 Cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-7">
        {/* Left Column: Sliders for Bonus Factors & Category Multipliers */}
        <div className="lg:col-span-7 space-y-6">
          {/* SECTION 1: 8대 핵심 가점 항목 가중치 조절 슬라이더 */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-5">
            <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold shrink-0">
                  <SlidersHorizontal className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    1. 정책별 가점 항목 기본 배점 슬라이더
                  </h3>
                  <p className="text-xs text-slate-500">
                    각 요건을 충족한 기업에게 부여할 AI 심사 가산점(0 ~ 30점)을 미세 조절합니다.
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-5">
              {/* 1. 스마트공장·스마트공방 도입 */}
              <div className="p-4 bg-slate-50/90 rounded-2xl border border-slate-200/80 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-indigo-600 shrink-0" />
                    <div>
                      <span className="text-xs font-black text-slate-900 block">
                        스마트공장·스마트공방·스마트상점 도입
                      </span>
                      <span className="text-[11px] text-slate-500">
                        ERP, MES, 공정자동화, 스마트상점 키오스크·서빙로봇 도입 기업
                      </span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="px-2.5 py-1 bg-indigo-100 text-indigo-800 text-xs font-black rounded-lg border border-indigo-200 inline-block">
                      +{weights.smartFactoryBasePoints}점
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">기본 권장: 10점</span>
                  </div>
                </div>

                {/* Base Slider */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] text-slate-500">
                    <span>일반 정책자금 기본 가산점</span>
                    <span className="font-bold text-slate-700">{weights.smartFactoryBasePoints}점</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="30"
                    step="1"
                    value={weights.smartFactoryBasePoints}
                    onChange={(e) => setWeights({ ...weights, smartFactoryBasePoints: Number(e.target.value) })}
                    className="w-full accent-indigo-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
                  />
                </div>

                {/* Specialized Booster Slider */}
                <div className="pt-2 border-t border-slate-200/60 space-y-1">
                  <div className="flex justify-between text-[11px] text-indigo-700 font-bold">
                    <span>제조·소공인 전용 특화자금 추가 부스팅 가산</span>
                    <span>+{weights.smartFactorySpecializedBonus}점 (합산: +{weights.smartFactoryBasePoints + weights.smartFactorySpecializedBonus}점)</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="15"
                    step="1"
                    value={weights.smartFactorySpecializedBonus}
                    onChange={(e) => setWeights({ ...weights, smartFactorySpecializedBonus: Number(e.target.value) })}
                    className="w-full accent-indigo-600 cursor-pointer h-2 bg-indigo-100 rounded-lg"
                  />
                </div>
              </div>

              {/* 2. 탄소중립·친환경 ESG 실천 */}
              <div className="p-4 bg-slate-50/90 rounded-2xl border border-slate-200/80 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Leaf className="w-4 h-4 text-emerald-600 shrink-0" />
                    <div>
                      <span className="text-xs font-black text-slate-900 block">
                        탄소중립·친환경 ESG 경영 실천
                      </span>
                      <span className="text-[11px] text-slate-500">
                        탄소중립 실천 서약, 고효율 에너지 절감 설비, 녹색인증 기업 우대
                      </span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-xs font-black rounded-lg border border-emerald-200 inline-block">
                      +{weights.carbonNeutralityPoints}점
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">기본 권장: 8점</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <input
                    type="range"
                    min="0"
                    max="30"
                    step="1"
                    value={weights.carbonNeutralityPoints}
                    onChange={(e) => setWeights({ ...weights, carbonNeutralityPoints: Number(e.target.value) })}
                    className="w-full accent-emerald-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>0점 (미부여)</span>
                    <span>15점 (우수)</span>
                    <span>30점 (최대 우대)</span>
                  </div>
                </div>
              </div>

              {/* 3. 청년 고용 및 신규 일자리 창출 */}
              <div className="p-4 bg-slate-50/90 rounded-2xl border border-slate-200/80 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-blue-600 shrink-0" />
                    <div>
                      <span className="text-xs font-black text-slate-900 block">
                        청년·정규직 신규 일자리 창출
                      </span>
                      <span className="text-[11px] text-slate-500">
                        최근 1년 이내 청년(만 39세 이하) 또는 정규직 신규 채용 기업
                      </span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="px-2.5 py-1 bg-blue-100 text-blue-800 text-xs font-black rounded-lg border border-blue-200 inline-block">
                      +{weights.jobCreationPoints}점
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">기본 권장: 6점</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <input
                    type="range"
                    min="0"
                    max="25"
                    step="1"
                    value={weights.jobCreationPoints}
                    onChange={(e) => setWeights({ ...weights, jobCreationPoints: Number(e.target.value) })}
                    className="w-full accent-blue-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>0점</span>
                    <span>12점</span>
                    <span>25점</span>
                  </div>
                </div>
              </div>

              {/* 4. 기술혁신·이노비즈·특허 보유 */}
              <div className="p-4 bg-slate-50/90 rounded-2xl border border-slate-200/80 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-purple-600 shrink-0" />
                    <div>
                      <span className="text-xs font-black text-slate-900 block">
                        이노비즈·메인비즈·벤처·특허 기술혁신
                      </span>
                      <span className="text-[11px] text-slate-500">
                        중기부 이노비즈/메인비즈, 벤처기업 인증 또는 등록 특허/실용신안 보유
                      </span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="px-2.5 py-1 bg-purple-100 text-purple-800 text-xs font-black rounded-lg border border-purple-200 inline-block">
                      +{weights.ventureInnoBizPoints}점
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">기본 권장: 8점</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <input
                    type="range"
                    min="0"
                    max="30"
                    step="1"
                    value={weights.ventureInnoBizPoints}
                    onChange={(e) => setWeights({ ...weights, ventureInnoBizPoints: Number(e.target.value) })}
                    className="w-full accent-purple-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>0점</span>
                    <span>15점</span>
                    <span>30점</span>
                  </div>
                </div>
              </div>

              {/* 5. 소진공 신용관리 사전교육 수료 */}
              <div className="p-4 bg-slate-50/90 rounded-2xl border border-slate-200/80 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <GraduationCap className="w-4 h-4 text-amber-600 shrink-0" />
                    <div>
                      <span className="text-xs font-black text-slate-900 block">
                        소진공 지식배움터 신용관리 사전교육 수료
                      </span>
                      <span className="text-[11px] text-slate-500">
                        소상공인시장진흥공단 온라인 신용관리 및 정책자금 사전교육 이수
                      </span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="px-2.5 py-1 bg-amber-100 text-amber-800 text-xs font-black rounded-lg border border-amber-200 inline-block">
                      +{weights.creditEducationPoints}점
                    </span>
                    <span className="text-[10px] text-slate-400 block mt-0.5">기본 권장: 5점</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <input
                    type="range"
                    min="0"
                    max="20"
                    step="1"
                    value={weights.creditEducationPoints}
                    onChange={(e) => setWeights({ ...weights, creditEducationPoints: Number(e.target.value) })}
                    className="w-full accent-amber-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
                  />
                </div>
              </div>

              {/* 6. 공공 마이데이터 무서류 즉시 검증 */}
              <div className="p-4 bg-slate-50/90 rounded-2xl border border-slate-200/80 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <FileCheck2 className="w-4 h-4 text-cyan-600 shrink-0" />
                    <div>
                      <span className="text-xs font-black text-slate-900 block">
                        공공 마이데이터 원클릭 즉시 검증
                      </span>
                      <span className="text-[11px] text-slate-500">
                        국세청·건보공단 증빙 서류 마이데이터 자동 스크래핑 제출 우대
                      </span>
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="px-2.5 py-1 bg-cyan-100 text-cyan-800 text-xs font-black rounded-lg border border-cyan-200 inline-block">
                      +{weights.myDataInstantPoints}점
                    </span>
                  </div>
                </div>

                <div className="space-y-1">
                  <input
                    type="range"
                    min="0"
                    max="20"
                    step="1"
                    value={weights.myDataInstantPoints}
                    onChange={(e) => setWeights({ ...weights, myDataInstantPoints: Number(e.target.value) })}
                    className="w-full accent-cyan-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* SECTION 2: 정책 분야별 가점 부스팅 배율 (Category Multipliers) */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-5">
            <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold shrink-0">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    2. 정책 자금 유형별 가점 부스팅 배율 (Multipliers)
                  </h3>
                  <p className="text-xs text-slate-500">
                    자금 특성에 맞춰 가점 점수를 배율(0.5x ~ 3.0x)로 추가 증폭합니다.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* 제조/소공인 특화 자금 배율 */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-black text-slate-800">제조·소공인 특화 자금</span>
                  <span className="font-black text-indigo-600 bg-white px-2 py-0.5 rounded border border-slate-200">
                    {weights.multipliers.manufacturing.toFixed(1)}x
                  </span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="3.0"
                  step="0.1"
                  value={weights.multipliers.manufacturing}
                  onChange={(e) => setWeights({
                    ...weights,
                    multipliers: { ...weights.multipliers, manufacturing: Number(e.target.value) }
                  })}
                  className="w-full accent-indigo-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
                />
                <span className="text-[10px] text-slate-500 block">스마트공장 가점 반영 배율</span>
              </div>

              {/* ESG 녹색금융 자금 배율 */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-black text-slate-800">ESG 녹색금융·탄소중립</span>
                  <span className="font-black text-emerald-700 bg-white px-2 py-0.5 rounded border border-slate-200">
                    {weights.multipliers.esgGreen.toFixed(1)}x
                  </span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="3.0"
                  step="0.1"
                  value={weights.multipliers.esgGreen}
                  onChange={(e) => setWeights({
                    ...weights,
                    multipliers: { ...weights.multipliers, esgGreen: Number(e.target.value) }
                  })}
                  className="w-full accent-emerald-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
                />
                <span className="text-[10px] text-slate-500 block">탄소중립 가점 반영 배율</span>
              </div>

              {/* 청년고용/일자리 자금 배율 */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-black text-slate-800">청년고용·일자리 창출 자금</span>
                  <span className="font-black text-blue-700 bg-white px-2 py-0.5 rounded border border-slate-200">
                    {weights.multipliers.youthEmployment.toFixed(1)}x
                  </span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="3.0"
                  step="0.1"
                  value={weights.multipliers.youthEmployment}
                  onChange={(e) => setWeights({
                    ...weights,
                    multipliers: { ...weights.multipliers, youthEmployment: Number(e.target.value) }
                  })}
                  className="w-full accent-blue-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
                />
                <span className="text-[10px] text-slate-500 block">고용창출 가점 반영 배율</span>
              </div>

              {/* 기술보증/혁신 스타트업 배율 */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-black text-slate-800">기술보증·혁신 스타트업</span>
                  <span className="font-black text-purple-700 bg-white px-2 py-0.5 rounded border border-slate-200">
                    {weights.multipliers.techVenture.toFixed(1)}x
                  </span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="3.0"
                  step="0.1"
                  value={weights.multipliers.techVenture}
                  onChange={(e) => setWeights({
                    ...weights,
                    multipliers: { ...weights.multipliers, techVenture: Number(e.target.value) }
                  })}
                  className="w-full accent-purple-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
                />
                <span className="text-[10px] text-slate-500 block">벤처·특허 가점 반영 배율</span>
              </div>
            </div>
          </div>

          {/* SECTION 3: 글로벌 가점 감도 마스터 슬라이더 */}
          <div className="bg-slate-900 text-white rounded-3xl p-6 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Gauge className="w-5 h-5 text-amber-400" />
                <span className="text-sm font-black">AI 승인 알고리즘 글로벌 가점 감도 (Master Sensitivity)</span>
              </div>
              <span className="text-xs font-black text-amber-300 bg-slate-800 px-3 py-1 rounded-xl border border-slate-700">
                {weights.globalBonusSensitivity.toFixed(2)}x
              </span>
            </div>
            <p className="text-xs text-slate-400">
              전체 가점의 승인 확률 영향력을 일괄 스케일링합니다. (1.0 = 표준, 1.5 = 가점 우대 극대화)
            </p>
            <input
              type="range"
              min="0.5"
              max="2.0"
              step="0.05"
              value={weights.globalBonusSensitivity}
              onChange={(e) => setWeights({ ...weights, globalBonusSensitivity: Number(e.target.value) })}
              className="w-full accent-amber-400 cursor-pointer h-2 bg-slate-800 rounded-lg"
            />
          </div>
        </div>

        {/* Right Column: Live Prediction Simulation Sandbox */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-5 sticky top-6">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-black text-slate-900">
                  실시간 승인 예측 시뮬레이터 (Sandbox)
                </h3>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-indigo-50 text-indigo-700 border border-indigo-200">
                즉시 재계산
              </span>
            </div>

            {/* Client Case Selector */}
            <div className="space-y-2">
              <label className="text-xs font-black text-slate-700 block">
                테스트 대상 표본 고객 선택:
              </label>
              <div className="grid grid-cols-2 gap-2">
                {SAMPLE_CLIENT_CASES.map(c => {
                  const isCurrent = c.id === selectedCaseId;
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => setSelectedCaseId(c.id)}
                      className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        isCurrent
                          ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      <span className="text-xs font-black block truncate">{c.name}</span>
                      <span className={`text-[10px] block truncate ${isCurrent ? 'text-slate-300' : 'text-slate-400'}`}>
                        {c.industryName}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Target Fund Selector */}
            <div className="space-y-2">
              <label className="text-xs font-black text-slate-700 block">
                심사 대상 정책자금:
              </label>
              <select
                value={selectedFundIndex}
                onChange={(e) => setSelectedFundIndex(Number(e.target.value))}
                className="w-full bg-slate-50 text-xs font-bold text-slate-800 p-2.5 rounded-xl border border-slate-200 focus:outline-hidden focus:ring-2 focus:ring-indigo-500"
              >
                {SIMULATION_POLICY_TARGETS.map((f, i) => (
                  <option key={f.id} value={i}>
                    {f.title} ({f.agency})
                  </option>
                ))}
              </select>
            </div>

            {/* Selected Client Active Bonuses Pill List */}
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-1.5">
              <span className="text-[11px] font-bold text-slate-600 block">
                보유 가점 요건:
              </span>
              <div className="flex flex-wrap gap-1">
                {selectedCase.activeBonusesSummary.map((b, idx) => (
                  <span key={idx} className="px-2 py-0.5 rounded-md bg-white text-indigo-700 text-[10px] font-bold border border-indigo-100 shadow-2xs">
                    ✓ {b}
                  </span>
                ))}
              </div>
            </div>

            {/* Before vs After Impact Box */}
            <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-50/80 via-blue-50/60 to-white border border-indigo-200 space-y-4">
              <span className="text-[11px] font-black text-indigo-900 uppercase tracking-wider block">
                가중치 튜닝 전 vs 튜닝 후 AI 승인 확률 비교
              </span>

              <div className="grid grid-cols-2 gap-4">
                {/* Before (Standard Baseline) */}
                <div className="p-3.5 bg-white/90 rounded-xl border border-slate-200 text-center space-y-1">
                  <span className="text-[10px] text-slate-400 font-bold block">표준 기본 가중치</span>
                  <div className="text-2xl font-black text-slate-600">
                    {defaultReport.overallProbability}%
                  </div>
                  <span className="text-[10px] font-bold text-slate-500 block">
                    {defaultTier.tierKorean} ({defaultTier.label.split(' ')[0]})
                  </span>
                </div>

                {/* After (Current Tuned Weights) */}
                <div className="p-3.5 bg-indigo-600 text-white rounded-xl shadow-md text-center space-y-1 ring-2 ring-indigo-400/40">
                  <span className="text-[10px] text-indigo-200 font-bold block">현재 튜닝된 가중치</span>
                  <div className="text-2xl font-black text-white flex items-center justify-center gap-1">
                    <span>{tunedReport.overallProbability}%</span>
                    {scoreDiff !== 0 && (
                      <span className="text-xs px-1.5 py-0.2 rounded-full bg-white/20 text-amber-200 font-black">
                        {scoreDiff > 0 ? `+${scoreDiff}%p` : `${scoreDiff}%p`}
                      </span>
                    )}
                  </div>
                  <span className="text-[10px] font-black text-indigo-100 block">
                    {tunedTier.tierKorean} ({tunedTier.label.split(' ')[0]})
                  </span>
                </div>
              </div>

              {/* Visual Breakdown of Applied Bonuses */}
              <div className="space-y-2 pt-2 border-t border-indigo-100">
                <span className="text-xs font-black text-slate-800 block">
                  실시간 가점 기여도 브레이크다운:
                </span>
                {tunedReport.policyBonusAdjustment?.appliedBonuses && tunedReport.policyBonusAdjustment.appliedBonuses.length > 0 ? (
                  <div className="space-y-1.5">
                    {tunedReport.policyBonusAdjustment.appliedBonuses.map(b => (
                      <div key={b.id} className="flex items-center justify-between text-xs p-2 rounded-lg bg-white border border-slate-100">
                        <span className="text-slate-700 font-bold truncate max-w-[200px]">{b.name}</span>
                        <span className="font-black text-indigo-600 shrink-0">+{b.points}%p</span>
                      </div>
                    ))}
                    <div className="flex items-center justify-between text-xs font-black pt-1 text-indigo-900">
                      <span>총 가산점 기여 합계</span>
                      <span>+{tunedReport.policyBonusAdjustment.totalBonusUplift}%p 승인율 상승</span>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400 italic">
                    해당 고객은 등록된 정책 가점 항목이 없습니다.
                  </p>
                )}
              </div>
            </div>

            {/* AI Examiner Opinion Note */}
            <div className="p-4 bg-slate-900 text-white rounded-2xl space-y-1.5 text-xs">
              <div className="flex items-center gap-1.5 text-amber-300 font-black">
                <Flame className="w-4 h-4" />
                <span>심사관 AI 종합 코멘트 (실시간 모델 추론)</span>
              </div>
              <p className="text-slate-300 leading-relaxed text-[11px]">
                {tunedReport.examinerReviewOpinion || `${selectedCase.name} 대표님의 정책 가점 항목이 현재 튜닝된 가중치 모델에 의해 가산되어 심사관 심사표 상 ${tunedTier.label} 구간에 배치되었습니다.`}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
