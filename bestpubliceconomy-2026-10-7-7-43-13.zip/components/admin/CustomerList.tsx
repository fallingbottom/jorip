import React, { useState, useEffect } from 'react';
import { Plus, Search, ChevronRight, User, Upload, Loader2, Sparkles, DollarSign, ShieldCheck, Trash2, CheckCircle2 } from 'lucide-react';
import { CrmCustomer } from '../../types';
import { getCustomers, addCustomer, addFinancial, deleteCustomer } from '../../services/crmService';
import { extractCrmBusinessInfoFromImage } from '../../services/geminiService';
import { CrmInputAssistant } from './CrmInputAssistant';
import { formatKoreanMoney } from '../../services/crmRecommendationService';

interface CustomerListProps {
  onSelectCustomer: (id: string) => void;
}

export const CustomerList: React.FC<CustomerListProps> = ({ onSelectCustomer }) => {
  const [customers, setCustomers] = useState<CrmCustomer[]>([]);
  const [loading, setLoading] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const [customerToDelete, setCustomerToDelete] = useState<CrmCustomer | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteSuccessNotice, setDeleteSuccessNotice] = useState<string | null>(null);
  
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setIsUploading(true);
      const extracted = await extractCrmBusinessInfoFromImage(file);
      setNewCustomer(prev => ({
        ...prev,
        ceoName: extracted.ceoName || prev.ceoName,
        businessName: extracted.businessName || prev.businessName,
        openDate: extracted.openDate || prev.openDate,
        address: extracted.address || prev.address,
        businessType: extracted.businessType || prev.businessType,
        industryName: extracted.industryName || prev.industryName,
      }));
    } catch (error) {
      console.error('OCR Parsing Error:', error);
      alert('사업자등록증 인식에 실패했습니다. 이미지를 다시 확인해주세요.');
    } finally {
      setIsUploading(false);
    }
  };

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Add Form State
  const initialCustomerForm = {
    ceoName: '',
    businessName: '',
    industryName: '',
    industryCode: '',
    businessType: '개인사업자',
    province: '',
    city: '',
    address: '',
    openDate: '',
    employeeCount: 0,
    phone: '',
    memo: '',
    vatRevenue: 0,
    creditScore: 740,
  };

  const [newCustomer, setNewCustomer] = useState(initialCustomerForm);

  const loadCustomers = async () => {
    setLoading(true);
    try {
      const data = await getCustomers();
      setCustomers(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadCustomers();
  }, []);

  const handleAdd = async () => {
    if (!newCustomer.ceoName || !newCustomer.businessName) {
      alert('대표자명과 상호명은 필수입니다.');
      return;
    }
    try {
      const { vatRevenue, creditScore, ...customerBasic } = newCustomer;
      const created = await addCustomer(customerBasic as any);
      
      // Auto-populate initial financial record if revenue or credit score is provided
      if (created && (vatRevenue > 0 || creditScore > 0)) {
        try {
          await addFinancial(created.id, {
            year: new Date().getFullYear(),
            vatRevenue: Number(vatRevenue) || 0,
            creditScore: Number(creditScore) || 700,
          });
        } catch (finErr) {
          console.error('Initial financial record creation failed:', finErr);
        }
      }

      setIsAddModalOpen(false);
      setNewCustomer(initialCustomerForm);
      loadCustomers();
    } catch (e) {
      console.error(e);
      alert('고객 등록 실패');
    }
  };

  const handleConfirmDelete = async () => {
    if (!customerToDelete) return;
    setIsDeleting(true);
    try {
      const deletedName = customerToDelete.businessName;
      await deleteCustomer(customerToDelete.id);
      setCustomerToDelete(null);
      setDeleteSuccessNotice(`'${deletedName}' 고객 데이터가 정상적으로 삭제되었습니다.`);
      setTimeout(() => setDeleteSuccessNotice(null), 3500);
      await loadCustomers();
    } catch (error) {
      console.error('Customer delete error:', error);
      alert('고객 데이터 삭제 중 오류가 발생했습니다.');
    } finally {
      setIsDeleting(false);
    }
  };

  const filteredCustomers = customers.filter(c => 
    c.businessName.includes(searchTerm) || c.ceoName.includes(searchTerm) || c.displayId.includes(searchTerm)
  );

  return (
    <div className="space-y-6">
      {/* Delete Success Toast Notice */}
      {deleteSuccessNotice && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 px-4 py-3 rounded-2xl flex items-center gap-2.5 text-sm font-bold animate-fade-in shadow-sm">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <span>{deleteSuccessNotice}</span>
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-900">고객 DB 관리</h2>
          <p className="text-slate-500 mt-1">총 {customers.length}명의 고객이 등록되어 있습니다.</p>
        </div>
        <button
          onClick={() => setIsAddModalOpen(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 shadow-sm transition-all"
        >
          <Plus className="w-5 h-5" /> 신규 고객 등록
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex gap-4">
          <div className="relative flex-1 max-w-md">
            <Search className="w-5 h-5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="상호명, 대표자명, 고객ID 검색..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all text-sm font-medium"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100">
                <th className="p-4 text-xs font-bold text-slate-500">고객ID</th>
                <th className="p-4 text-xs font-bold text-slate-500">상호명</th>
                <th className="p-4 text-xs font-bold text-slate-500">대표자명</th>
                <th className="p-4 text-xs font-bold text-slate-500">업종</th>
                <th className="p-4 text-xs font-bold text-slate-500">지역</th>
                <th className="p-4 text-xs font-bold text-slate-500 text-right">관리</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">데이터를 불러오는 중입니다...</td>
                </tr>
              ) : filteredCustomers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-slate-400">등록된 고객이 없습니다.</td>
                </tr>
              ) : (
                filteredCustomers.map(customer => (
                  <tr 
                    key={customer.id} 
                    className="border-b border-slate-50 hover:bg-slate-50/50 transition-colors cursor-pointer group/row"
                    onClick={() => onSelectCustomer(customer.id)}
                  >
                    <td className="p-4 text-sm font-bold text-indigo-600">{customer.displayId}</td>
                    <td className="p-4 text-sm font-bold text-slate-800">{customer.businessName}</td>
                    <td className="p-4 text-sm font-medium text-slate-600 flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center">
                        <User className="w-3 h-3 text-slate-400" />
                      </div>
                      {customer.ceoName}
                    </td>
                    <td className="p-4 text-sm font-medium text-slate-600">{customer.industryName || '-'}</td>
                    <td className="p-4 text-sm font-medium text-slate-600">{customer.province} {customer.city}</td>
                    <td className="p-4 text-right" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => onSelectCustomer(customer.id)}
                          className="px-2.5 py-1 text-xs font-bold text-indigo-600 hover:text-indigo-800 hover:bg-indigo-50 rounded-lg transition-colors flex items-center gap-0.5"
                          title="상세보기 및 심사 상담"
                        >
                          <span>상세</span>
                          <ChevronRight className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => setCustomerToDelete(customer)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors flex items-center gap-1 group/btn"
                          title="고객 데이터 삭제"
                        >
                          <Trash2 className="w-4 h-4 transition-transform group-hover/btn:scale-110" />
                          <span className="text-xs font-bold text-slate-400 group-hover/btn:text-rose-600 hidden sm:inline">삭제</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden animate-slide-up flex flex-col max-h-[92vh]">
            <div className="p-5 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <div>
                <h3 className="font-black text-slate-800 text-lg">신규 고객 등록 (Sheet 1)</h3>
                <p className="text-xs text-slate-500 mt-0.5">기본 기업정보 및 초기 재무·신용 추천 지표 등록</p>
              </div>
              <div className="relative">
                <input 
                  type="file" 
                  accept="image/*" 
                  onChange={handleFileUpload} 
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
                  disabled={isUploading}
                />
                <button className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg text-xs font-bold hover:bg-indigo-100 transition-colors pointer-events-none">
                  {isUploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                  {isUploading ? '분석 중...' : '사업자등록증 업로드'}
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6 overflow-y-auto">
              {/* Section 1: 기업 기본 정보 */}
              <div>
                <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider mb-3">1. 기업 기본 정보</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">상호명 *</label>
                    <input type="text" value={newCustomer.businessName} onChange={e => setNewCustomer({...newCustomer, businessName: e.target.value})} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:border-indigo-500" placeholder="예: (주)한국테크" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">대표자명 *</label>
                    <input type="text" value={newCustomer.ceoName} onChange={e => setNewCustomer({...newCustomer, ceoName: e.target.value})} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:border-indigo-500" placeholder="예: 홍길동" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">업종명</label>
                    <input 
                      type="text" 
                      value={newCustomer.industryName} 
                      onChange={e => setNewCustomer({...newCustomer, industryName: e.target.value})} 
                      className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:border-indigo-500" 
                      placeholder="예: 음식점업, 제조업, IT서비스..." 
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">업종코드</label>
                    <input type="text" value={newCustomer.industryCode} onChange={e => setNewCustomer({...newCustomer, industryCode: e.target.value})} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm" placeholder="예: 552101" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">법인구분</label>
                    <select value={newCustomer.businessType} onChange={e => setNewCustomer({...newCustomer, businessType: e.target.value})} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold">
                      <option value="개인사업자">개인사업자</option>
                      <option value="법인">법인</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">개업일</label>
                    <input type="date" value={newCustomer.openDate} onChange={e => setNewCustomer({...newCustomer, openDate: e.target.value})} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">시도</label>
                    <input type="text" placeholder="예: 서울" value={newCustomer.province} onChange={e => setNewCustomer({...newCustomer, province: e.target.value})} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">시군구</label>
                    <input type="text" placeholder="예: 강남구" value={newCustomer.city} onChange={e => setNewCustomer({...newCustomer, city: e.target.value})} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-500 mb-1">사업장 주소 상세</label>
                    <input type="text" value={newCustomer.address} onChange={e => setNewCustomer({...newCustomer, address: e.target.value})} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm" placeholder="상세 도로명 주소" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">상시근로자 수 (명)</label>
                    <input type="number" value={newCustomer.employeeCount || ''} onChange={e => setNewCustomer({...newCustomer, employeeCount: Number(e.target.value)})} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold" placeholder="0" min="0" />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">연락처</label>
                    <input type="text" placeholder="010-0000-0000" value={newCustomer.phone} onChange={e => setNewCustomer({...newCustomer, phone: e.target.value})} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm" />
                  </div>
                </div>
              </div>

              {/* Section 2: 입력 지원 도우미 & 재무/신용 초기 입력 */}
              <div className="pt-2 border-t border-slate-100">
                <div className="flex items-center justify-between mb-2.5">
                  <h4 className="text-xs font-black text-indigo-950 flex items-center gap-1.5 uppercase tracking-wider">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    2. 재무 및 신용 지표 (입력 지원 도우미)
                  </h4>
                  <span className="text-[11px] text-slate-400 font-medium">
                    업종/법인/인원 기반 실시간 통계 산출
                  </span>
                </div>

                {/* Recommendation Assistant Card */}
                <CrmInputAssistant
                  industryName={newCustomer.industryName}
                  businessType={newCustomer.businessType}
                  province={newCustomer.province}
                  employeeCount={newCustomer.employeeCount}
                  currentRevenue={newCustomer.vatRevenue}
                  currentCredit={newCustomer.creditScore}
                  onApplyRevenue={(rev) => setNewCustomer(prev => ({ ...prev, vatRevenue: rev }))}
                  onApplyCredit={(cred) => setNewCustomer(prev => ({ ...prev, creditScore: cred }))}
                  onApplyBoth={(rev, cred) => setNewCustomer(prev => ({ ...prev, vatRevenue: rev, creditScore: cred }))}
                />

                {/* Target Inputs for Financial & Credit with Live Formatter */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-3.5 p-4 bg-slate-50/80 border border-slate-200/80 rounded-2xl">
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                        <DollarSign className="w-3.5 h-3.5 text-indigo-600" />
                        예상 연간 매출액 (원)
                      </label>
                      {newCustomer.vatRevenue > 0 && (
                        <span className="text-[11px] font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded-md">
                          {formatKoreanMoney(newCustomer.vatRevenue)}
                        </span>
                      )}
                    </div>
                    <input 
                      type="number" 
                      placeholder="예: 150000000"
                      value={newCustomer.vatRevenue || ''} 
                      onChange={e => setNewCustomer({ ...newCustomer, vatRevenue: Number(e.target.value) })} 
                      className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500" 
                      step="10000000"
                    />
                    <div className="flex gap-1.5 mt-2">
                      <button
                        type="button"
                        onClick={() => setNewCustomer(prev => ({ ...prev, vatRevenue: (prev.vatRevenue || 0) + 10000000 }))}
                        className="text-[11px] font-bold px-2 py-1 bg-white border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-100 hover:text-indigo-600 transition-colors"
                      >
                        +1천만
                      </button>
                      <button
                        type="button"
                        onClick={() => setNewCustomer(prev => ({ ...prev, vatRevenue: (prev.vatRevenue || 0) + 50000000 }))}
                        className="text-[11px] font-bold px-2 py-1 bg-white border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-100 hover:text-indigo-600 transition-colors"
                      >
                        +5천만
                      </button>
                      <button
                        type="button"
                        onClick={() => setNewCustomer(prev => ({ ...prev, vatRevenue: (prev.vatRevenue || 0) + 100000000 }))}
                        className="text-[11px] font-bold px-2 py-1 bg-white border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-100 hover:text-indigo-600 transition-colors"
                      >
                        +1억
                      </button>
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                        <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                        예상 대표자 신용점수 (NICE/KCB)
                      </label>
                      {newCustomer.creditScore > 0 && (
                        <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${
                          newCustomer.creditScore >= 750 ? 'bg-emerald-100 text-emerald-700' :
                          newCustomer.creditScore >= 650 ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'
                        }`}>
                          {newCustomer.creditScore}점 ({newCustomer.creditScore >= 750 ? '우량' : newCustomer.creditScore >= 650 ? '양호' : '관리필요'})
                        </span>
                      )}
                    </div>
                    <input 
                      type="number" 
                      placeholder="예: 740"
                      value={newCustomer.creditScore || ''} 
                      onChange={e => setNewCustomer({ ...newCustomer, creditScore: Number(e.target.value) })} 
                      className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500" 
                      min="300" 
                      max="1000"
                    />
                    <div className="flex gap-1.5 mt-2">
                      <button
                        type="button"
                        onClick={() => setNewCustomer(prev => ({ ...prev, creditScore: 680 }))}
                        className="text-[11px] font-bold px-2 py-1 bg-white border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-100 hover:text-blue-600 transition-colors"
                      >
                        680점 (중위)
                      </button>
                      <button
                        type="button"
                        onClick={() => setNewCustomer(prev => ({ ...prev, creditScore: 740 }))}
                        className="text-[11px] font-bold px-2 py-1 bg-white border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-100 hover:text-blue-600 transition-colors"
                      >
                        740점 (평균)
                      </button>
                      <button
                        type="button"
                        onClick={() => setNewCustomer(prev => ({ ...prev, creditScore: 820 }))}
                        className="text-[11px] font-bold px-2 py-1 bg-white border border-slate-200 text-slate-600 rounded-lg hover:bg-slate-100 hover:text-blue-600 transition-colors"
                      >
                        820점 (우량)
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Section 3: 상담 메모 */}
              <div className="pt-2 border-t border-slate-100">
                <label className="block text-xs font-bold text-slate-500 mb-1">상담 메모</label>
                <textarea 
                  value={newCustomer.memo} 
                  onChange={e => setNewCustomer({...newCustomer, memo: e.target.value})} 
                  placeholder="고객 초기 상담 요청사항이나 특이사항을 기록하세요."
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm h-16 focus:border-indigo-500" 
                />
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 flex justify-end gap-3 bg-slate-50">
              <button onClick={() => setIsAddModalOpen(false)} className="px-5 py-2.5 text-slate-600 font-bold hover:bg-slate-200 rounded-xl transition-all">취소</button>
              <button onClick={handleAdd} className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl shadow-sm transition-all flex items-center gap-2">
                <Plus className="w-4 h-4" />
                등록하기
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Customer Delete Confirmation Modal */}
      {customerToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 border border-slate-100">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mb-4">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-black text-slate-900 mb-1">고객 데이터 삭제 확인</h3>
            <p className="text-sm text-slate-600 mb-4 leading-relaxed">
              정말 <span className="font-bold text-slate-900">'{customerToDelete.businessName}'</span> ({customerToDelete.ceoName} 대표) 고객의 DB를 삭제하시겠습니까?
            </p>
            <div className="p-3.5 bg-rose-50/80 rounded-xl border border-rose-100 text-xs text-rose-700 font-medium mb-6">
              ⚠️ <strong>주의:</strong> 삭제 시 고객 기본정보는 물론 등록된 재무제표, 지원신청 현황 및 상담 타임라인 기록이 함께 영구 삭제됩니다.
            </div>
            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setCustomerToDelete(null)}
                disabled={isDeleting}
                className="px-4 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
              >
                취소
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-5 py-2.5 text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition-all shadow-sm flex items-center gap-2"
              >
                {isDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                {isDeleting ? '삭제 중...' : '영구 삭제'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
