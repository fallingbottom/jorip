import React, { useState, useEffect } from 'react';
import { 
  Activity, 
  RefreshCw, 
  Terminal, 
  Sliders, 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Send, 
  Play, 
  RotateCcw, 
  Clock, 
  Server, 
  ShieldCheck, 
  Layers, 
  Cpu, 
  FileCode2, 
  MessageSquareCode,
  SlidersHorizontal,
  Save,
  Check,
  Zap,
  Info,
  ArrowRight
} from 'lucide-react';
import { 
  getMatchingParameters, 
  saveMatchingParameters, 
  DEFAULT_MATCHING_PARAMS, 
  MatchingParameters 
} from '../../services/matchingParamService';
import { AnnouncementCurationManager } from './AnnouncementCurationManager';
import { MatchingEngineTuningPanel } from './MatchingEngineTuningPanel';

interface CrawlerSourceStatus {
  id: string;
  name: string;
  agency: string;
  status: 'healthy' | 'degraded' | 'failed';
  latencyMs: number;
  consecutiveFailures: number;
  lastSuccessAt: string;
  totalRecords: number;
  successRate: number;
  enabled: boolean;
}

interface LogEntry {
  id: string;
  timestamp: string;
  level: 'INFO' | 'WARN' | 'ERROR' | 'SUCCESS';
  source: string;
  message: string;
}

interface WebhookAlert {
  id: string;
  timestamp: string;
  target: 'Workspace Chat' | 'Slack Webhook' | 'Email Notification';
  title: string;
  summary: string;
  status: 'DELIVERED' | 'PENDING' | 'FAILED';
}

export const PipelineMonitorBoard: React.FC = () => {
  const [sources, setSources] = useState<CrawlerSourceStatus[]>([
    {
      id: 'semas-direct',
      name: '소진공 직접대출 수집기',
      agency: '소상공인시장진흥공단',
      status: 'healthy',
      latencyMs: 482,
      consecutiveFailures: 0,
      lastSuccessAt: '방금 전 (14:35:12)',
      totalRecords: 248,
      successRate: 99.4,
      enabled: true,
    },
    {
      id: 'semas-proxy',
      name: '소진공 대리대출/보증 수집기',
      agency: '소상공인시장진흥공단',
      status: 'healthy',
      latencyMs: 615,
      consecutiveFailures: 0,
      lastSuccessAt: '3분 전 (14:32:04)',
      totalRecords: 184,
      successRate: 98.9,
      enabled: true,
    },
    {
      id: 'bizinfo',
      name: '기업마당(중기부) 정책 포털',
      agency: '중소벤처기업부',
      status: 'healthy',
      latencyMs: 842,
      consecutiveFailures: 0,
      lastSuccessAt: '4분 전 (14:31:18)',
      totalRecords: 412,
      successRate: 99.8,
      enabled: true,
    },
    {
      id: 'kodit-kibo',
      name: '신보·기보 보증공고 크롤러',
      agency: '신용보증기금 / 기술보증기금',
      status: 'degraded',
      latencyMs: 1420,
      consecutiveFailures: 1,
      lastSuccessAt: '9분 전 (14:26:00)',
      totalRecords: 129,
      successRate: 94.2,
      enabled: true,
    },
    {
      id: 'kinfa',
      name: '서민금융진흥원 취약자금 크롤러',
      agency: '서민금융진흥원',
      status: 'healthy',
      latencyMs: 512,
      consecutiveFailures: 0,
      lastSuccessAt: '2분 전 (14:33:45)',
      totalRecords: 96,
      successRate: 99.1,
      enabled: true,
    }
  ]);

  const [logs, setLogs] = useState<LogEntry[]>([
    { id: '1', timestamp: '14:35:12', level: 'SUCCESS', source: 'SEMAS_DIRECT', message: '공고 수집 완료 (총 248건 수집, 신규 0건, 정규화 통과 100%)' },
    { id: '2', timestamp: '14:33:45', level: 'INFO', source: 'KINFA_CRAWLER', message: '미소금융 창업·운영자금 NCB 신용구간 규칙 v0.4 정규화 완료' },
    { id: '3', timestamp: '14:31:18', level: 'INFO', source: 'BIZINFO_PORTAL', message: '소진공 예산 소진율 자동 파싱 완료 (평균 소진율 68.4%)' },
    { id: '4', timestamp: '14:26:00', level: 'WARN', source: 'KODIT_KIBO', message: '요청 레이턴시 1,420ms 초과 — 지수 백오프 2회차 재시도 후 수집 성공' },
    { id: '5', timestamp: '14:20:10', level: 'SUCCESS', source: 'SCHEDULER', message: '5분 단위 정기 파이프라인 동기화 사이클 정상 종료' }
  ]);

  const [webhooks, setWebhooks] = useState<WebhookAlert[]>([
    {
      id: 'wh-1',
      timestamp: '14:35:15',
      target: 'Workspace Chat',
      title: '5분 정기 수집 파이프라인 정상',
      summary: '5개 기관 총 1,069건 공고 동기화 완료 (오류 0건)',
      status: 'DELIVERED'
    },
    {
      id: 'wh-2',
      timestamp: '14:26:05',
      target: 'Slack Webhook',
      title: 'KODIT 크롤러 응답 지연 경고',
      summary: '레이턴시 1,420ms 감지되어 모니터링 주의(Degraded)로 전환',
      status: 'DELIVERED'
    },
    {
      id: 'wh-3',
      timestamp: '12:00:00',
      target: 'Workspace Chat',
      title: '일일 정책자금 변동 요약 브리핑',
      summary: '신용취약소상공인자금 예산 소진율 82% 도달 알림 발송',
      status: 'DELIVERED'
    }
  ]);

  // Parameters State
  const [params, setParams] = useState<MatchingParameters>(getMatchingParameters());
  const [isSaved, setIsSaved] = useState(false);
  const [isSyncingAll, setIsSyncingAll] = useState(false);
  const [selectedLogLevel, setSelectedLogLevel] = useState<'ALL' | 'INFO' | 'WARN' | 'ERROR'>('ALL');
  const [subView, setSubView] = useState<'crawler' | 'curation' | 'tuning'>('crawler');

  // Manual Trigger
  const handleTriggerManualSync = (sourceId?: string) => {
    setIsSyncingAll(true);
    const nowStr = new Date().toLocaleTimeString('ko-KR');
    setTimeout(() => {
      setSources(prev => prev.map(s => {
        if (!sourceId || s.id === sourceId) {
          return {
            ...s,
            status: 'healthy',
            latencyMs: Math.floor(Math.random() * 300 + 400),
            consecutiveFailures: 0,
            lastSuccessAt: `수동 동기화 (${nowStr})`
          };
        }
        return s;
      }));

      const newLog: LogEntry = {
        id: Date.now().toString(),
        timestamp: nowStr,
        level: 'SUCCESS',
        source: sourceId ? sourceId.toUpperCase() : 'ALL_SOURCES',
        message: `[수동 트리거] ${sourceId ? sourceId : '전체 파이프라인'} 즉시 동기화 완료 (응답 정상)`
      };
      setLogs(prev => [newLog, ...prev.slice(0, 40)]);
      setIsSyncingAll(false);
    }, 900);
  };

  // Restart Crawler
  const handleRestartCrawler = (sourceId: string) => {
    const target = sources.find(s => s.id === sourceId);
    const nowStr = new Date().toLocaleTimeString('ko-KR');
    setLogs(prev => [
      {
        id: Date.now().toString(),
        timestamp: nowStr,
        level: 'WARN',
        source: target?.name || sourceId,
        message: `관리자에 의해 [크롤러 재시작] 프로세스가 트리거되었습니다 (Worker Node 재기동)`
      },
      ...prev
    ]);
    setTimeout(() => {
      setSources(prev => prev.map(s => s.id === sourceId ? { ...s, status: 'healthy', consecutiveFailures: 0 } : s));
      setLogs(prev => [
        {
          id: (Date.now() + 1).toString(),
          timestamp: new Date().toLocaleTimeString('ko-KR'),
          level: 'SUCCESS',
          source: target?.name || sourceId,
          message: `Worker Node 재초기화 완료. 상태: healthy (정상 가동)`
        },
        ...prev
      ]);
    }, 800);
  };

  // Toggle Source
  const handleToggleSource = (sourceId: string) => {
    setSources(prev => prev.map(s => s.id === sourceId ? { ...s, enabled: !s.enabled } : s));
  };

  // Save Matching Parameters
  const handleSaveParams = () => {
    saveMatchingParameters(params);
    setIsSaved(true);
    const nowStr = new Date().toLocaleTimeString('ko-KR');
    setLogs(prev => [
      {
        id: Date.now().toString(),
        timestamp: nowStr,
        level: 'INFO',
        source: 'MATCH_TUNER',
        message: `매칭 알고리즘 가중치 저장 완료 (예산 소진 가중치: ${params.budgetExhaustionWeight}%, 금리 우대율: ${params.industryPreferenceRate}%p)`
      },
      ...prev
    ]);
    setTimeout(() => setIsSaved(false), 2000);
  };

  const filteredLogs = logs.filter(l => {
    if (selectedLogLevel === 'ALL') return true;
    return l.level === selectedLogLevel;
  });

  return (
    <div className="space-y-8 animate-fade-in pb-12">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-xs font-black text-emerald-600 tracking-wider uppercase">System Controller v0.4</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 flex items-center gap-2.5">
            <Server className="w-6 h-6 text-indigo-600" />
            개발자 & 시스템 관리자 파이프라인 관제탑
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            소진공·중기부 수집 스크래퍼 실시간 감시, 5분 단위 동기화 통제, 장애 무중단 복구 및 공고 규칙 검수·활성화
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => handleTriggerManualSync()}
            disabled={isSyncingAll}
            className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black transition-all shadow-sm hover:shadow active:scale-95 disabled:opacity-60 cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncingAll ? 'animate-spin' : ''}`} />
            <span>{isSyncingAll ? '동기화 수행 중...' : '전체 수집기 즉시 동기화'}</span>
          </button>
        </div>
      </div>

      {/* Subview Toggle Switcher */}
      <div className="flex flex-wrap items-center gap-2 p-1.5 bg-slate-200/60 rounded-2xl w-fit">
        <button
          type="button"
          onClick={() => setSubView('crawler')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
            subView === 'crawler' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Server className="w-4 h-4" />
          <span>크롤러 감시 & 파이프라인</span>
        </button>
        <button
          type="button"
          onClick={() => setSubView('tuning')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
            subView === 'tuning' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Sliders className="w-4 h-4 text-amber-500" />
          <span>매칭 엔진 튜닝 모드</span>
          <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-amber-100 text-amber-800">
            가점 슬라이더
          </span>
        </button>
        <button
          type="button"
          onClick={() => setSubView('curation')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-black transition-all cursor-pointer ${
            subView === 'curation' ? 'bg-white text-indigo-700 shadow-sm' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <FileCode2 className="w-4 h-4" />
          <span>공고수집 현황 및 활성화·검증·삭제 (v0.4)</span>
          <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
        </button>
      </div>

      {subView === 'curation' ? (
        <AnnouncementCurationManager />
      ) : subView === 'tuning' ? (
        <MatchingEngineTuningPanel />
      ) : (
        <>
      {/* 1. 핵심 지표 요약 카드 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[11px] font-bold">전체 동기화 성공률</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-black text-slate-900">99.2%</div>
          <span className="text-[10px] text-emerald-600 font-bold mt-1 inline-block">최근 24시간 무장애 유지</span>
        </div>

        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[11px] font-bold">동기화 주기</span>
            <Clock className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-black text-slate-900">{params.autoSyncIntervalMinutes}분 단위</div>
          <span className="text-[10px] text-blue-600 font-bold mt-1 inline-block">다음 예정: 1분 48초 후</span>
        </div>

        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[11px] font-bold">DB 적재 공고 총계</span>
            <Layers className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-black text-slate-900">1,069건</div>
          <span className="text-[10px] text-indigo-600 font-bold mt-1 inline-block">JSON 규칙 추출 완료 100%</span>
        </div>

        <div className="bg-white p-4.5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1.5">
            <span className="text-[11px] font-bold">평균 레이턴시</span>
            <Zap className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-black text-slate-900">682 ms</div>
          <span className="text-[10px] text-amber-600 font-bold mt-1 inline-block">지연 임계치: 2,500ms</span>
        </div>
      </div>

      {/* 2. 소스별 파이프라인 실행 상태 & 무중단 제어 패널 */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="p-5 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
              <Activity className="w-4 h-4 text-indigo-600" />
              수집기 실행 상태 및 무중단 스위치 패널
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              각 기관 스크래퍼의 실시간 응답 상태를 감시하고, 장애 발생 시 원클릭 재시작 및 수동 트리거를 실행합니다.
            </p>
          </div>
          <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full">
            지수 백오프(Exponential Backoff) 자동 복구 탑재
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-600 font-black">
                <th className="p-4">기관 / 수집기명</th>
                <th className="p-4">상태</th>
                <th className="p-4">레이턴시</th>
                <th className="p-4">성공률</th>
                <th className="p-4">적재 건수</th>
                <th className="p-4">최근 동기화</th>
                <th className="p-4 text-right">무중단 제어 액션</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {sources.map(src => (
                <tr key={src.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="p-4">
                    <div className="font-bold text-slate-900 text-sm">{src.name}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{src.agency}</div>
                  </td>
                  <td className="p-4">
                    {src.status === 'healthy' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 font-bold border border-emerald-200">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                        정상 (Healthy)
                      </span>
                    )}
                    {src.status === 'degraded' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-50 text-amber-800 font-bold border border-amber-300">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                        지연 주의 (Degraded)
                      </span>
                    )}
                    {src.status === 'failed' && (
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-50 text-rose-700 font-bold border border-rose-300">
                        <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                        오류 (Failed)
                      </span>
                    )}
                  </td>
                  <td className="p-4 font-bold">
                    <span className={src.latencyMs > 1000 ? 'text-amber-600' : 'text-slate-800'}>
                      {src.latencyMs} ms
                    </span>
                  </td>
                  <td className="p-4 font-bold text-slate-800">{src.successRate}%</td>
                  <td className="p-4 font-bold text-indigo-600">{src.totalRecords} 건</td>
                  <td className="p-4 text-slate-500">{src.lastSuccessAt}</td>
                  <td className="p-4 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => handleTriggerManualSync(src.id)}
                        className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold text-[11px] transition-all cursor-pointer"
                        title="해당 소스 수동 즉시 동기화"
                      >
                        즉시 수집
                      </button>
                      <button
                        type="button"
                        onClick={() => handleRestartCrawler(src.id)}
                        className="px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded-lg font-bold text-[11px] transition-all cursor-pointer"
                        title="해당 크롤러 Worker Node 재시작"
                      >
                        재시작
                      </button>
                      <button
                        type="button"
                        onClick={() => handleToggleSource(src.id)}
                        className={`px-2.5 py-1.5 rounded-lg font-bold text-[11px] transition-all cursor-pointer ${
                          src.enabled 
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100' 
                            : 'bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100'
                        }`}
                      >
                        {src.enabled ? '활성화' : '일시정지'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. 에러 로그 터미널 뷰어 & 웹훅 알림 트래킹 (2분할) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 왼쪽: 실시간 콘솔 터미널 뷰어 */}
        <div className="bg-slate-950 text-slate-200 rounded-2xl p-5 font-mono text-xs border border-slate-800 shadow-xl flex flex-col h-[400px]">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3 shrink-0">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span className="font-bold text-slate-200">System Pipeline Terminal Log</span>
            </div>
            
            {/* Level Filter */}
            <div className="flex items-center gap-1">
              {(['ALL', 'INFO', 'WARN', 'ERROR'] as const).map(lvl => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => setSelectedLogLevel(lvl)}
                  className={`px-2 py-0.5 rounded text-[10px] font-black cursor-pointer transition-all ${
                    selectedLogLevel === lvl 
                      ? 'bg-slate-700 text-white' 
                      : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  {lvl}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-y-auto flex-1 space-y-2 pr-1 font-mono">
            {filteredLogs.map(log => (
              <div key={log.id} className="leading-relaxed flex items-start gap-2">
                <span className="text-slate-500 shrink-0">[{log.timestamp}]</span>
                <span className={`px-1.5 py-0.2 rounded font-black text-[10px] shrink-0 ${
                  log.level === 'SUCCESS' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800' :
                  log.level === 'WARN' ? 'bg-amber-950 text-amber-400 border border-amber-800' :
                  log.level === 'ERROR' ? 'bg-rose-950 text-rose-400 border border-rose-800' :
                  'bg-blue-950 text-blue-400 border border-blue-800'
                }`}>
                  {log.level}
                </span>
                <span className="text-indigo-400 shrink-0">&lt;{log.source}&gt;</span>
                <span className="text-slate-300 break-all">{log.message}</span>
              </div>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-500 flex items-center justify-between shrink-0">
            <span>Live Stream Mode: Active</span>
            <span>로그 보관: 최근 1,000건 메모리 버퍼</span>
          </div>
        </div>

        {/* 오른쪽: 웹훅 알림 발송 트래커 */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 flex flex-col h-[400px]">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-3 shrink-0">
            <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
              <MessageSquareCode className="w-4 h-4 text-indigo-600" />
              웹훅(Workspace/Slack) 알림 전송 내역
            </h3>
            <span className="text-[11px] font-bold text-slate-400">전송 성공률 100%</span>
          </div>

          <div className="overflow-y-auto flex-1 space-y-3 pr-1">
            {webhooks.map(wh => (
              <div key={wh.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80">
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
                      {wh.target}
                    </span>
                    <span className="text-xs font-black text-slate-800">{wh.title}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-medium">{wh.timestamp}</span>
                </div>
                <p className="text-xs text-slate-600 font-medium leading-relaxed">{wh.summary}</p>
                <div className="mt-2 flex items-center gap-1.5 text-[10px] font-bold text-emerald-600">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>웹훅 엔드포인트 정상 수신 완료 (HTTP 200 OK)</span>
                </div>
              </div>
            ))}
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-slate-500 shrink-0">
            <span>연동 웹훅: Google Chat 1개, Slack 1개</span>
            <span className="text-indigo-600 cursor-pointer hover:underline">웹훅 설정 관리</span>
          </div>
        </div>
      </div>

      {/* AI 정책 가점 가중치 튜닝 모드 바로가기 배너 */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white border border-indigo-900/60 shadow-md flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shrink-0 shadow-sm">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-0.5">
              <h3 className="text-sm font-black text-white">
                AI 승인 예측 매칭 엔진 튜닝 모드 (스마트공장·탄소중립 가점 조절)
              </h3>
              <span className="px-2 py-0.2 rounded-md bg-amber-400 text-slate-950 text-[10px] font-black">
                가점 슬라이더
              </span>
            </div>
            <p className="text-xs text-slate-300">
              스마트공장, 탄소중립, 청년고용, 특허벤처 가점 배점을 슬라이더로 조절하고 실시간 AI 예측 시뮬레이터로 검증하세요.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setSubView('tuning')}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black rounded-xl transition-all shadow-md flex items-center gap-1.5 shrink-0 cursor-pointer active:scale-95"
        >
          <span>엔진 튜닝 모드 열기</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      {/* 4. 백오피스 매칭 로직 파라미터 튜닝 제어판 (코드 수정 없이 튜닝) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4 mb-6">
          <div>
            <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
              <SlidersHorizontal className="w-5 h-5 text-indigo-600" />
              매칭 로직 파라미터 실시간 튜닝 제어판
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              코드 수정이나 서버 재배포 없이, 백오피스에서 지역별 예산 소진율 가중치 및 금리 우대율 등 알고리즘 변수를 즉각 미세 조정합니다.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setParams(DEFAULT_MATCHING_PARAMS)}
              className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all cursor-pointer"
            >
              기본값 복원
            </button>
            <button
              type="button"
              onClick={handleSaveParams}
              className="flex items-center gap-1.5 px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black transition-all shadow-sm cursor-pointer"
            >
              {isSaved ? <Check className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
              <span>{isSaved ? '저장 완료!' : '파라미터 저장 및 적용'}</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* 1. 지역별 예산 소진율 가중치 */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-black text-slate-800">예산 소진율 반영 가중치</label>
              <span className="text-xs font-black text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-200">
                {params.budgetExhaustionWeight}%
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mb-3 leading-relaxed">
              소진율이 높은 자금의 추천 순위를 낮추거나 긴급 마감 뱃지를 부착할 때 적용되는 패널티 가중치입니다.
            </p>
            <input 
              type="range"
              min="0"
              max="100"
              step="5"
              value={params.budgetExhaustionWeight}
              onChange={e => setParams({ ...params, budgetExhaustionWeight: Number(e.target.value) })}
              className="w-full accent-indigo-600 cursor-pointer"
            />
          </div>

          {/* 2. 특정 업종 금리 우대율 */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-black text-slate-800">전략 업종 금리 우대율</label>
              <span className="text-xs font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                {params.industryPreferenceRate}%p
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mb-3 leading-relaxed">
              제조업, 혁신 서비스, 청년 창업 기업 등에 부여되는 정책자금 기본 금리 인하 우대 가산점입니다.
            </p>
            <input 
              type="range"
              min="0.1"
              max="2.0"
              step="0.1"
              value={params.industryPreferenceRate}
              onChange={e => setParams({ ...params, industryPreferenceRate: Number(e.target.value) })}
              className="w-full accent-emerald-600 cursor-pointer"
            />
          </div>

          {/* 3. 저신용 컷오프 임계치 */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-black text-slate-800">신용취약 컷오프 임계치 (NCB)</label>
              <span className="text-xs font-black text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                {params.creditCutoffThreshold}점 이하
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mb-3 leading-relaxed">
              소진공 신용취약소상공인자금 등 특별 경영안정자금의 직접대출 적격 기준 점수입니다.
            </p>
            <input 
              type="range"
              min="700"
              max="900"
              step="5"
              value={params.creditCutoffThreshold}
              onChange={e => setParams({ ...params, creditCutoffThreshold: Number(e.target.value) })}
              className="w-full accent-amber-600 cursor-pointer"
            />
          </div>

          {/* 4. 마감 임박 알림 일수 */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-black text-slate-800">긴급 마감 경고 윈도우</label>
              <span className="text-xs font-black text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                {params.urgentDeadlineWindowDays}일 이내
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mb-3 leading-relaxed">
              공고 마감 D-Day가 이 기준 이하일 경우 카드 상단에 붉은색 긴급 마감 띠를 노출합니다.
            </p>
            <input 
              type="range"
              min="1"
              max="14"
              step="1"
              value={params.urgentDeadlineWindowDays}
              onChange={e => setParams({ ...params, urgentDeadlineWindowDays: Number(e.target.value) })}
              className="w-full accent-rose-600 cursor-pointer"
            />
          </div>

          {/* 5. 지역 예산 쿼터 편향도 */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-black text-slate-800">지역 재단 우선 매칭 가중치</label>
              <span className="text-xs font-black text-purple-700 bg-purple-50 px-2 py-0.5 rounded-md border border-purple-200">
                {params.regionalQuotaBias}%
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mb-3 leading-relaxed">
              대표자 사업장 소재지 관할 신용보증재단 특례보증 자금의 우선 매칭 스코어링 반영률입니다.
            </p>
            <input 
              type="range"
              min="0"
              max="50"
              step="5"
              value={params.regionalQuotaBias}
              onChange={e => setParams({ ...params, regionalQuotaBias: Number(e.target.value) })}
              className="w-full accent-purple-600 cursor-pointer"
            />
          </div>

          {/* 6. 수집기 주기 */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/80">
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-black text-slate-800">공고 자동 동기화 주기</label>
              <span className="text-xs font-black text-slate-800 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                {params.autoSyncIntervalMinutes}분
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mb-3 leading-relaxed">
              백그라운드에서 소진공/중기부 공고 변경 및 예산 소진율을 갱신하는 주기입니다.
            </p>
            <input 
              type="range"
              min="1"
              max="30"
              step="1"
              value={params.autoSyncIntervalMinutes}
              onChange={e => setParams({ ...params, autoSyncIntervalMinutes: Number(e.target.value) })}
              className="w-full accent-slate-800 cursor-pointer"
            />
          </div>
        </div>
      </div>
        </>
      )}
    </div>
  );
};
