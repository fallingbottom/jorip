import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, 
  Users, 
  KeyRound, 
  UserPlus, 
  Trash2, 
  CheckCircle2, 
  AlertCircle, 
  Lock, 
  Unlock, 
  RefreshCw,
  Mail,
  Shield,
  BadgeAlert,
  Save,
  Check
} from 'lucide-react';
import { 
  AdminUser, 
  AdminRole, 
  AdminSettings, 
  getAdminSettings, 
  saveAdminSettings, 
  getAdminUsers, 
  addAdminUser, 
  removeAdminUser, 
  updateMasterPasscode,
  getCurrentAdminSession 
} from '../../services/adminAuthService';

export const AdminAccessSettings: React.FC = () => {
  const [settings, setSettings] = useState<AdminSettings>(getAdminSettings());
  const [users, setUsers] = useState<AdminUser[]>(getAdminUsers());
  const [currentSession, setCurrentSession] = useState<AdminUser | null>(getCurrentAdminSession());

  // Form states
  const [newEmail, setNewEmail] = useState('');
  const [newName, setNewName] = useState('');
  const [newRole, setNewRole] = useState<AdminRole>('CONSULTANT');
  const [newBusiness, setNewBusiness] = useState('');

  // Passcode states
  const [newPasscode, setNewPasscode] = useState('');
  const [confirmPasscode, setConfirmPasscode] = useState('');
  
  // Invitation code state
  const [invitationCode, setInvitationCode] = useState(settings.adminInvitationCode);

  // Status feedback
  const [notice, setNotice] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  useEffect(() => {
    setSettings(getAdminSettings());
    setUsers(getAdminUsers());
    setCurrentSession(getCurrentAdminSession());
  }, []);

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotice({ type, message });
    setTimeout(() => setNotice(null), 3500);
  };

  // Toggle Protection Mode
  const handleToggleProtection = () => {
    const updated = { ...settings, isProtectionEnabled: !settings.isProtectionEnabled };
    saveAdminSettings(updated);
    setSettings(updated);
    showNotification(
      'success',
      updated.isProtectionEnabled 
        ? 'CRM 보안 보호 모드가 활성화되었습니다. (비인가 접근 차단)' 
        : 'CRM 보안 보호 모드가 비활성화되었습니다.'
    );
  };

  // Add new admin user
  const handleAddAdmin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail.trim() || !newEmail.includes('@')) {
      showNotification('error', '올바른 이메일 주소를 입력해주세요.');
      return;
    }
    if (!newName.trim()) {
      showNotification('error', '관리자/심사역 이름을 입력해주세요.');
      return;
    }

    const added = addAdminUser(newEmail, newName, newRole, newBusiness);
    setUsers(getAdminUsers());
    setSettings(getAdminSettings());
    setNewEmail('');
    setNewName('');
    setNewBusiness('');
    showNotification('success', `${added.name}(${added.email}) 계정이 관리자로 등록되었습니다.`);
  };

  // Remove admin user
  const handleRemoveAdmin = (email: string) => {
    if (email.toLowerCase() === 'fujinilove@gmail.com') {
      showNotification('error', '최고 시스템 관리자(fujinilove@gmail.com)는 삭제할 수 없습니다.');
      return;
    }

    if (window.confirm(`정말 ${email} 관리자 계정 권한을 해제하시겠습니까?`)) {
      const ok = removeAdminUser(email);
      if (ok) {
        setUsers(getAdminUsers());
        setSettings(getAdminSettings());
        showNotification('success', `${email} 관리자 권한이 정상 회수되었습니다.`);
      }
    }
  };

  // Update Passcode
  const handlePasscodeChange = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPasscode.length < 4) {
      showNotification('error', '패스코드는 4자리 이상이어야 합니다.');
      return;
    }
    if (newPasscode !== confirmPasscode) {
      showNotification('error', '패스코드 확인이 일치하지 않습니다.');
      return;
    }

    const ok = updateMasterPasscode(newPasscode);
    if (ok) {
      setSettings(getAdminSettings());
      setNewPasscode('');
      setConfirmPasscode('');
      showNotification('success', '마스터 패스코드가 성공적으로 변경되었습니다.');
    }
  };

  // Update Invitation Code
  const handleSaveInvitationCode = (e: React.FormEvent) => {
    e.preventDefault();
    if (!invitationCode.trim()) {
      showNotification('error', '초대 코드를 입력해주세요.');
      return;
    }
    const updated = { ...settings, adminInvitationCode: invitationCode.trim() };
    saveAdminSettings(updated);
    setSettings(updated);
    showNotification('success', '관리자 회원가입 초대 코드가 갱신되었습니다.');
  };

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* Header Banner */}
      <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-600/20">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <div>
            <h1 className="text-xl font-black text-slate-900 flex items-center gap-2">
              관리자 CRM 접근권한 & 보안 설정
            </h1>
            <p className="text-xs text-slate-500 mt-1">
              CRM 관제탑 및 공고 검수 파이프라인 접근 권한과 관리자 계정을 설정합니다.
            </p>
          </div>
        </div>

        {/* Protection Toggle */}
        <div className="flex items-center gap-3 bg-slate-50 p-2.5 px-4 rounded-xl border border-slate-200 self-start md:self-auto">
          <div className="text-right">
            <span className="text-xs font-bold text-slate-800 block">CRM 접근 보호 모드</span>
            <span className="text-[10px] text-slate-500">
              {settings.isProtectionEnabled ? '인가된 관리자만 접속 허용' : '보호 해제 (테스트 모드)'}
            </span>
          </div>
          <button
            onClick={handleToggleProtection}
            className={`w-12 h-7 rounded-full p-1 transition-colors relative ${
              settings.isProtectionEnabled ? 'bg-indigo-600' : 'bg-slate-300'
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full bg-white transition-transform ${
                settings.isProtectionEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
      </div>

      {/* Notification Toast */}
      {notice && (
        <div
          className={`p-4 rounded-xl border flex items-center gap-2.5 text-xs font-bold animate-fade-in ${
            notice.type === 'success' 
              ? 'bg-emerald-50 text-emerald-800 border-emerald-200' 
              : 'bg-red-50 text-red-800 border-red-200'
          }`}
        >
          {notice.type === 'success' ? (
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          ) : (
            <AlertCircle className="w-4 h-4 text-red-600" />
          )}
          <span>{notice.message}</span>
        </div>
      )}

      {/* Current User Session Status */}
      <div className="bg-slate-900 text-white rounded-2xl p-5 shadow-sm border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-800 flex items-center justify-center text-indigo-400 font-bold border border-slate-700">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-400">현재 접속 인증자:</span>
              <span className="text-sm font-black text-white">{currentSession?.name || '슈퍼 관리자 (fujini)'}</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-indigo-500/30 text-indigo-300 border border-indigo-500/40">
                {currentSession?.role || 'SUPER_ADMIN'}
              </span>
            </div>
            <span className="text-xs text-slate-400 font-mono mt-0.5 block">
              {currentSession?.email || 'fujinilove@gmail.com'}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 bg-emerald-950/50 border border-emerald-800/60 px-3.5 py-1.5 rounded-xl">
          <Check className="w-4 h-4" />
          <span>보안 인증 세션 유지 중</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Column 1 & 2: Administrator List & Add Form */}
        <div className="lg:col-span-2 space-y-6">

          {/* Admin Accounts Table */}
          <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-600" />
                <h2 className="text-sm font-black text-slate-900">승인된 관리자 및 심사역 목록</h2>
              </div>
              <span className="text-xs text-slate-500 font-bold">
                총 {users.length}명 등록됨
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {users.map((admin) => {
                const isMaster = admin.email.toLowerCase() === 'fujinilove@gmail.com';
                return (
                  <div key={admin.id} className="p-4 flex items-center justify-between hover:bg-slate-50/80 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-black text-xs ${
                        isMaster ? 'bg-amber-100 text-amber-800 border border-amber-300' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {admin.name.slice(0, 1)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900">{admin.name}</span>
                          {isMaster && (
                            <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-amber-100 text-amber-800 border border-amber-200">
                              최고 관리자 (Master)
                            </span>
                          )}
                          <span className={`px-1.5 py-0.5 rounded text-[9px] font-black ${
                            admin.role === 'SUPER_ADMIN' 
                              ? 'bg-purple-100 text-purple-800' 
                              : admin.role === 'CONSULTANT'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}>
                            {admin.role === 'SUPER_ADMIN' ? '슈퍼 관리자' : admin.role === 'CONSULTANT' ? '수석 심사역' : '공고 검수원'}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-slate-400 mt-0.5 font-mono">
                          <span>{admin.email}</span>
                          {admin.businessName && <span>• {admin.businessName}</span>}
                        </div>
                      </div>
                    </div>

                    {!isMaster ? (
                      <button
                        onClick={() => handleRemoveAdmin(admin.email)}
                        className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        title="관리자 권한 회수"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    ) : (
                      <span className="text-[10px] font-bold text-slate-400 px-2 py-1 bg-slate-100 rounded-md">
                        영구 권한
                      </span>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Add New Admin Account Form */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center gap-2 mb-4">
              <UserPlus className="w-5 h-5 text-indigo-600" />
              <h2 className="text-sm font-black text-slate-900">신규 관리자 / 심사역 추가</h2>
            </div>

            <form onSubmit={handleAddAdmin} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">관리자 이메일</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={newEmail}
                      onChange={e => setNewEmail(e.target.value)}
                      placeholder="admin@bizmatch.ai"
                      className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-600 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">성명 / 직책</label>
                  <input
                    type="text"
                    value={newName}
                    onChange={e => setNewName(e.target.value)}
                    placeholder="김심사 수석심사역"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">권한 등급</label>
                  <select
                    value={newRole}
                    onChange={e => setNewRole(e.target.value as AdminRole)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-600 focus:outline-none"
                  >
                    <option value="CONSULTANT">수석 심사역 (CRM 상담 & 고객 관리)</option>
                    <option value="AUDITOR">공고 검수원 (공고 수집 및 JSON 규칙 검수)</option>
                    <option value="SUPER_ADMIN">슈퍼 관리자 (전체 권한 및 보안 설정)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">소속 기관 / 부서</label>
                  <input
                    type="text"
                    value={newBusiness}
                    onChange={e => setNewBusiness(e.target.value)}
                    placeholder="중소기업정책금융센터"
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-600 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-600/20 transition-all flex items-center gap-1.5"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>관리자 등록 승인</span>
                </button>
              </div>
            </form>
          </div>

        </div>

        {/* Column 3: Passcodes & Security Policies */}
        <div className="space-y-6">

          {/* Master Passcode Box */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center gap-2 mb-3">
              <KeyRound className="w-5 h-5 text-amber-500" />
              <h2 className="text-sm font-black text-slate-900">CRM 마스터 패스코드</h2>
            </div>
            <p className="text-xs text-slate-500 mb-4 leading-relaxed">
              Google 계정이 없거나 비상 시 패스코드만으로 관리자 CRM을 잠금 해제할 수 있습니다.
            </p>

            <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 mb-4 flex items-center justify-between">
              <span className="text-xs text-amber-800 font-bold">현재 설정된 마스터 패스코드:</span>
              <span className="font-mono text-sm font-black text-amber-900 tracking-widest">
                {settings.masterPasscode}
              </span>
            </div>

            <form onSubmit={handlePasscodeChange} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">새 패스코드 (4자리 이상)</label>
                <input
                  type="password"
                  value={newPasscode}
                  onChange={e => setNewPasscode(e.target.value)}
                  placeholder="새 패스코드 입력"
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-600 focus:outline-none font-mono tracking-widest text-center"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">패스코드 확인</label>
                <input
                  type="password"
                  value={confirmPasscode}
                  onChange={e => setConfirmPasscode(e.target.value)}
                  placeholder="다시 한번 입력"
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-600 focus:outline-none font-mono tracking-widest text-center"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-slate-900 hover:bg-black text-white rounded-xl text-xs font-bold shadow-sm transition-all"
              >
                패스코드 변경 저장
              </button>
            </form>
          </div>

          {/* Admin Sign-up Invitation Code */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center gap-2 mb-3">
              <Lock className="w-5 h-5 text-indigo-600" />
              <h2 className="text-sm font-black text-slate-900">회원가입 초대 코드</h2>
            </div>
            <p className="text-xs text-slate-500 mb-4 leading-relaxed">
              신규 심사역이 회원가입 창에서 [심사역 & 관리자]로 가입할 때 검증할 초대 코드입니다.
            </p>

            <form onSubmit={handleSaveInvitationCode} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">초대 코드</label>
                <input
                  type="text"
                  value={invitationCode}
                  onChange={e => setInvitationCode(e.target.value)}
                  placeholder="BIZ-ADMIN-2026"
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-600 focus:outline-none font-mono tracking-wider"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center justify-center gap-1.5"
              >
                <Save className="w-4 h-4" />
                <span>초대 코드 저장</span>
              </button>
            </form>
          </div>

        </div>

      </div>
    </div>
  );
};
