import React, { useState, useEffect, useMemo } from 'react';
import { Sparkles, TrendingUp, ShieldCheck, Zap, ChevronDown, ChevronUp, RefreshCw, BarChart2, Info } from 'lucide-react';
import { 
  FinancialRecommendation, 
  CustomerFinancialPair, 
  calculateFinancialRecommendation, 
  fetchAllCustomerFinancials,
  formatKoreanMoney 
} from '../../services/crmRecommendationService';

interface CrmInputAssistantProps {
  industryName?: string;
  businessType?: string;
  province?: string;
  employeeCount?: number;
  currentRevenue?: number;
  currentCredit?: number;
  onApplyRevenue: (revenue: number) => void;
  onApplyCredit: (creditScore: number) => void;
  onApplyBoth: (revenue: number, creditScore: number) => void;
}

export const CrmInputAssistant: React.FC<CrmInputAssistantProps> = ({
  industryName = '',
  businessType = '개인사업자',
  province = '',
  employeeCount = 0,
  currentRevenue = 0,
  currentCredit = 700,
  onApplyRevenue,
  onApplyCredit,
  onApplyBoth,
}) => {
  const [existingPairs, setExistingPairs] = useState<CustomerFinancialPair[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isExpanded, setIsExpanded] = useState(true);

  const loadData = async (force = false) => {
    setIsLoading(true);
    try {
      const pairs = await fetchAllCustomerFinancials(force);
      setExistingPairs(pairs);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData(false);
  }, []);

  const recommendation: FinancialRecommendation = useMemo(() => {
    return calculateFinancialRecommendation({
      industryName,
      businessType,
      province,
      employeeCount,
      existingPairs,
    });
  }, [industryName, businessType, province, employeeCount, existingPairs]);

  return (
    <div className="bg-gradient-to-br from-indigo-50/90 via-blue-50/50 to-slate-50 border border-indigo-100 rounded-2xl p-4 shadow-xs transition-all">
      {/* Header */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
            <Sparkles className="w-4 h-4 text-amber-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black text-indigo-950">입력 지원 도우미</span>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-700">
                {recommendation.matchedCriteriaText}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5">
              <Info className="w-3 h-3 text-slate-400" />
              {recommendation.sourceNote}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={() => loadData(true)}
            disabled={isLoading}
            className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
            title="기존 고객 데이터 새로고침"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-indigo-600' : ''}`} />
          </button>
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {isExpanded && (
        <div className="mt-3.5 pt-3.5 border-t border-indigo-100/70 space-y-3 animate-fade-in">
          {/* Quick Preset Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 text-xs">
            <span className="text-[11px] font-bold text-slate-500 mr-1 flex items-center gap-1">
              <Zap className="w-3 h-3 text-amber-500" /> 원클릭 자동완성:
            </span>
            <button
              type="button"
              onClick={() => onApplyBoth(recommendation.revenue.avg, recommendation.creditScore.avg)}
              className="px-2.5 py-1 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs hover:shadow transition-all flex items-center gap-1 cursor-pointer active:scale-95"
            >
              <BarChart2 className="w-3 h-3" />
              <span>평균 세트 ({recommendation.revenue.formatted.avg} / {recommendation.creditScore.formatted.avg})</span>
            </button>
            <button
              type="button"
              onClick={() => onApplyBoth(recommendation.revenue.p25, recommendation.creditScore.p25)}
              className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 hover:border-slate-300 text-slate-700 font-bold text-xs shadow-2xs hover:bg-slate-50 transition-all flex items-center gap-1 cursor-pointer active:scale-95"
            >
              <ShieldCheck className="w-3 h-3 text-blue-500" />
              <span>보수적 ({recommendation.revenue.formatted.p25} / {recommendation.creditScore.formatted.p25})</span>
            </button>
            <button
              type="button"
              onClick={() => onApplyBoth(recommendation.revenue.p75, recommendation.creditScore.p75)}
              className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 hover:border-slate-300 text-slate-700 font-bold text-xs shadow-2xs hover:bg-slate-50 transition-all flex items-center gap-1 cursor-pointer active:scale-95"
            >
              <TrendingUp className="w-3 h-3 text-emerald-500" />
              <span>우량 ({recommendation.revenue.formatted.p75} / {recommendation.creditScore.formatted.p75})</span>
            </button>
          </div>

          {/* Detailed Range Guidance */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            {/* Revenue Recommendation Box */}
            <div className="bg-white/90 backdrop-blur-xs border border-indigo-100/80 rounded-xl p-3 shadow-2xs">
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-bold text-slate-700 flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5 text-indigo-600" />
                  추천 연매출액 범위
                </span>
                <span className="text-[10px] font-bold text-indigo-600">
                  권장: {recommendation.revenue.formatted.range}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-1.5 mt-2">
                <button
                  type="button"
                  onClick={() => onApplyRevenue(recommendation.revenue.p25)}
                  className={`p-1.5 rounded-lg border text-center transition-all cursor-pointer ${
                    currentRevenue === recommendation.revenue.p25
                      ? 'border-indigo-600 bg-indigo-50 font-black text-indigo-700'
                      : 'border-slate-200 hover:border-indigo-300 bg-slate-50/60 text-slate-600'
                  }`}
                  title="하위 25% 보수적 기준 적용"
                >
                  <div className="text-[10px] text-slate-400">보수적</div>
                  <div className="font-bold text-[11px] truncate">{recommendation.revenue.formatted.p25}</div>
                </button>
                <button
                  type="button"
                  onClick={() => onApplyRevenue(recommendation.revenue.avg)}
                  className={`p-1.5 rounded-lg border text-center transition-all cursor-pointer relative ${
                    currentRevenue === recommendation.revenue.avg
                      ? 'border-indigo-600 bg-indigo-50 font-black text-indigo-700 ring-2 ring-indigo-500/20'
                      : 'border-indigo-200 hover:border-indigo-400 bg-indigo-50/40 text-indigo-900 font-bold'
                  }`}
                  title="업종 평균값 적용"
                >
                  <span className="absolute -top-1.5 right-1 px-1 py-0.2 bg-amber-400 text-amber-950 text-[8px] font-black rounded-full">추천</span>
                  <div className="text-[10px] text-indigo-600">평균값</div>
                  <div className="font-black text-[11px] truncate">{recommendation.revenue.formatted.avg}</div>
                </button>
                <button
                  type="button"
                  onClick={() => onApplyRevenue(recommendation.revenue.p75)}
                  className={`p-1.5 rounded-lg border text-center transition-all cursor-pointer ${
                    currentRevenue === recommendation.revenue.p75
                      ? 'border-indigo-600 bg-indigo-50 font-black text-indigo-700'
                      : 'border-slate-200 hover:border-indigo-300 bg-slate-50/60 text-slate-600'
                  }`}
                  title="상위 25% 우량 기준 적용"
                >
                  <div className="text-[10px] text-slate-400">우량</div>
                  <div className="font-bold text-[11px] truncate">{recommendation.revenue.formatted.p75}</div>
                </button>
              </div>
            </div>

            {/* Credit Score Recommendation Box */}
            <div className="bg-white/90 backdrop-blur-xs border border-indigo-100/80 rounded-xl p-3 shadow-2xs">
              <div className="flex items-center justify-between mb-1.5">
                <span className="font-bold text-slate-700 flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
                  추천 신용점수 범위
                </span>
                <span className="text-[10px] font-bold text-blue-600">
                  권장: {recommendation.creditScore.formatted.range}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-1.5 mt-2">
                <button
                  type="button"
                  onClick={() => onApplyCredit(recommendation.creditScore.p25)}
                  className={`p-1.5 rounded-lg border text-center transition-all cursor-pointer ${
                    currentCredit === recommendation.creditScore.p25
                      ? 'border-blue-600 bg-blue-50 font-black text-blue-700'
                      : 'border-slate-200 hover:border-blue-300 bg-slate-50/60 text-slate-600'
                  }`}
                  title="하위 25% 보수적 기준 적용"
                >
                  <div className="text-[10px] text-slate-400">보수적</div>
                  <div className="font-bold text-[11px] truncate">{recommendation.creditScore.formatted.p25}</div>
                </button>
                <button
                  type="button"
                  onClick={() => onApplyCredit(recommendation.creditScore.avg)}
                  className={`p-1.5 rounded-lg border text-center transition-all cursor-pointer relative ${
                    currentCredit === recommendation.creditScore.avg
                      ? 'border-blue-600 bg-blue-50 font-black text-blue-700 ring-2 ring-blue-500/20'
                      : 'border-blue-200 hover:border-blue-400 bg-blue-50/40 text-blue-900 font-bold'
                  }`}
                  title="업종 평균값 적용"
                >
                  <span className="absolute -top-1.5 right-1 px-1 py-0.2 bg-blue-500 text-white text-[8px] font-black rounded-full">추천</span>
                  <div className="text-[10px] text-blue-600">평균값</div>
                  <div className="font-black text-[11px] truncate">{recommendation.creditScore.formatted.avg}</div>
                </button>
                <button
                  type="button"
                  onClick={() => onApplyCredit(recommendation.creditScore.p75)}
                  className={`p-1.5 rounded-lg border text-center transition-all cursor-pointer ${
                    currentCredit === recommendation.creditScore.p75
                      ? 'border-blue-600 bg-blue-50 font-black text-blue-700'
                      : 'border-slate-200 hover:border-blue-300 bg-slate-50/60 text-slate-600'
                  }`}
                  title="상위 25% 우량 기준 적용"
                >
                  <div className="text-[10px] text-slate-400">우량</div>
                  <div className="font-bold text-[11px] truncate">{recommendation.creditScore.formatted.p75}</div>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
