import React, { useState, useEffect, useMemo } from 'react';
import { 
  FileCode2, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  Trash2, 
  Power, 
  Eye, 
  History, 
  Search, 
  Filter, 
  RefreshCw, 
  ChevronRight, 
  ExternalLink, 
  ShieldCheck, 
  Check, 
  X, 
  Sparkles, 
  Tag, 
  ArrowUpDown, 
  Loader2,
  Sliders,
  Layers,
  Award,
  CheckCheck,
  CheckSquare,
  Square,
  MinusSquare,
  Building2,
  Calendar,
  RotateCcw
} from 'lucide-react';
import { PolicyAnnouncement, AnnouncementRule } from '../../types';
import { 
  getAnnouncements, 
  toggleAnnouncementActive, 
  updateAnnouncementReviewStatus, 
  bulkUpdateAnnouncementReviewStatus,
  deleteAnnouncement, 
  updateAnnouncementRule,
  getAnnouncementStats, 
  runCrawlerSyncSimulation,
  AnnouncementStats 
} from '../../services/announcementService';

export interface DeadlineInfo {
  daysLeft: number;
  label: string;
  badgeClass: string;
  isUrgent7d: boolean;
  isUrgent30d: boolean;
  isOpen: boolean;
  isClosed: boolean;
}

export const calculateDeadlineInfo = (endDateStr?: string, status?: string): DeadlineInfo => {
  if (status === 'CLOSED') {
    return {
      daysLeft: -1,
      label: '마감 완료',
      badgeClass: 'bg-slate-100 text-slate-500 border-slate-200',
      isUrgent7d: false,
      isUrgent30d: false,
      isOpen: false,
      isClosed: true
    };
  }

  if (!endDateStr || endDateStr.includes('상시') || endDateStr.includes('소진')) {
    return {
      daysLeft: 999,
      label: '상시 / 예산소진시',
      badgeClass: 'bg-blue-50 text-blue-700 border-blue-200',
      isUrgent7d: false,
      isUrgent30d: false,
      isOpen: true,
      isClosed: false
    };
  }

  const end = new Date(endDateStr);
  if (isNaN(end.getTime())) {
    return {
      daysLeft: 999,
      label: endDateStr,
      badgeClass: 'bg-slate-100 text-slate-600 border-slate-200',
      isUrgent7d: false,
      isUrgent30d: false,
      isOpen: true,
      isClosed: false
    };
  }

  const now = new Date();
  const todayOnly = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const endOnly = new Date(end.getFullYear(), end.getMonth(), end.getDate()).getTime();
  const diffDays = Math.ceil((endOnly - todayOnly) / (1000 * 60 * 60 * 24));

  if (diffDays < 0) {
    return {
      daysLeft: diffDays,
      label: '접수 마감',
      badgeClass: 'bg-rose-50 text-rose-700 border-rose-200',
      isUrgent7d: false,
      isUrgent30d: false,
      isOpen: false,
      isClosed: true
    };
  }

  if (diffDays === 0) {
    return {
      daysLeft: 0,
      label: 'D-Day (오늘마감)',
      badgeClass: 'bg-rose-100 text-rose-800 border-rose-300 font-black animate-pulse',
      isUrgent7d: true,
      isUrgent30d: true,
      isOpen: true,
      isClosed: false
    };
  }

  if (diffDays <= 7) {
    return {
      daysLeft: diffDays,
      label: `D-${diffDays} (마감임박)`,
      badgeClass: 'bg-amber-100 text-amber-800 border-amber-300 font-bold',
      isUrgent7d: true,
      isUrgent30d: true,
      isOpen: true,
      isClosed: false
    };
  }

  if (diffDays <= 30) {
    return {
      daysLeft: diffDays,
      label: `D-${diffDays} (이번달 마감)`,
      badgeClass: 'bg-orange-50 text-orange-700 border-orange-200 font-semibold',
      isUrgent7d: false,
      isUrgent30d: true,
      isOpen: true,
      isClosed: false
    };
  }

  return {
    daysLeft: diffDays,
    label: `D-${diffDays} (접수중)`,
    badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    isUrgent7d: false,
    isUrgent30d: false,
    isOpen: true,
    isClosed: false
  };
};

export const AnnouncementCurationManager: React.FC = () => {
  const [announcements, setAnnouncements] = useState<PolicyAnnouncement[]>([]);
  const [stats, setStats] = useState<AnnouncementStats | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [agencyFilter, setAgencyFilter] = useState<string>('ALL');
  const [deadlineFilter, setDeadlineFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'pending' | 'approved' | 'rejected'>('ALL');
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'ACTIVE' | 'INACTIVE'>('ALL');
  const [sortBy, setSortBy] = useState<'latest' | 'deadline' | 'completeness' | 'exhaustion'>('latest');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncToast, setSyncToast] = useState<string | null>(null);

  // Multi-selection state for Bulk Validation
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isBulkValidating, setIsBulkValidating] = useState(false);

  // Selected announcement for rule modal
  const [selectedAnnouncement, setSelectedAnnouncement] = useState<PolicyAnnouncement | null>(null);
  const [ruleModalMode, setRuleModalMode] = useState<'view' | 'edit'>('view');
  const [editedRuleJson, setEditedRuleJson] = useState<string>('');
  const [jsonError, setJsonError] = useState<string | null>(null);

  // Selected announcement for version history modal
  const [viewingOriginal, setViewingOriginal] = useState<PolicyAnnouncement | null>(null);
  const [historyAnnouncement, setHistoryAnnouncement] = useState<PolicyAnnouncement | null>(null);

  // Deletion state
  const [announcementToDelete, setAnnouncementToDelete] = useState<PolicyAnnouncement | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Load data
  const loadData = () => {
    const list = getAnnouncements();
    setAnnouncements(list);
    setStats(getAnnouncementStats(list));
  };

  useEffect(() => {
    loadData();
  }, []);

  // Unique agencies and agency counts
  const uniqueAgencies = useMemo(() => {
    const set = new Set<string>();
    announcements.forEach(a => {
      if (a.agency && a.agency.trim()) {
        set.add(a.agency.trim());
      }
    });
    return Array.from(set).sort();
  }, [announcements]);

  const agencyCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    announcements.forEach(a => {
      const key = a.agency?.trim() || '기타';
      counts[key] = (counts[key] || 0) + 1;
    });
    return counts;
  }, [announcements]);

  // Deadline categories count
  const deadlineCounts = useMemo(() => {
    let urgent7d = 0;
    let urgent30d = 0;
    let open = 0;
    let closed = 0;

    announcements.forEach(a => {
      const info = calculateDeadlineInfo(a.endDate, a.status);
      if (info.isUrgent7d) urgent7d++;
      if (info.isUrgent30d) urgent30d++;
      if (info.isOpen) open++;
      if (info.isClosed) closed++;
    });

    return { urgent7d, urgent30d, open, closed, total: announcements.length };
  }, [announcements]);

  // Filter and Search logic with Sorting
  const filtered = useMemo(() => {
    const list = announcements.filter(item => {
      // 1. Search Query
      const q = searchQuery.trim().toLowerCase();
      const matchesSearch = !q || (
        item.title.toLowerCase().includes(q) ||
        item.agency.toLowerCase().includes(q) ||
        item.source.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        (item.description && item.description.toLowerCase().includes(q)) ||
        (item.rule?.program_name && item.rule.program_name.toLowerCase().includes(q)) ||
        (item.rule?.tags && item.rule.tags.some(t => t.toLowerCase().includes(q))) ||
        (item.maxAmount && item.maxAmount.toLowerCase().includes(q)) ||
        (item.baseInterestRate && item.baseInterestRate.toLowerCase().includes(q))
      );

      // 2. Agency Filter
      const matchesAgency = agencyFilter === 'ALL' || item.agency.trim() === agencyFilter.trim();

      // 3. Deadline Filter
      const deadlineInfo = calculateDeadlineInfo(item.endDate, item.status);
      let matchesDeadline = true;
      if (deadlineFilter === 'URGENT_7D') {
        matchesDeadline = deadlineInfo.isUrgent7d;
      } else if (deadlineFilter === 'URGENT_30D') {
        matchesDeadline = deadlineInfo.isUrgent30d;
      } else if (deadlineFilter === 'OPEN') {
        matchesDeadline = deadlineInfo.isOpen;
      } else if (deadlineFilter === 'CLOSED') {
        matchesDeadline = deadlineInfo.isClosed;
      }

      // 4. Status Filter
      const matchesStatus = statusFilter === 'ALL' || item.reviewStatus === statusFilter;

      // 5. Active Filter
      const matchesActive = activeFilter === 'ALL' || (activeFilter === 'ACTIVE' ? item.isActive : !item.isActive);

      return matchesSearch && matchesAgency && matchesDeadline && matchesStatus && matchesActive;
    });

    // Apply Sorting
    return list.sort((a, b) => {
      if (sortBy === 'deadline') {
        const aDl = calculateDeadlineInfo(a.endDate, a.status);
        const bDl = calculateDeadlineInfo(b.endDate, b.status);
        if (aDl.isClosed && !bDl.isClosed) return 1;
        if (!aDl.isClosed && bDl.isClosed) return -1;
        return aDl.daysLeft - bDl.daysLeft;
      }
      if (sortBy === 'completeness') {
        return (b.completenessScore || 0) - (a.completenessScore || 0);
      }
      if (sortBy === 'exhaustion') {
        return (b.budgetExhaustionRate || 0) - (a.budgetExhaustionRate || 0);
      }
      // Default: latest updated
      const aDate = new Date(a.lastUpdatedAt || a.collectedAt || 0).getTime();
      const bDate = new Date(b.lastUpdatedAt || b.collectedAt || 0).getTime();
      return bDate - aDate;
    });
  }, [announcements, searchQuery, agencyFilter, deadlineFilter, statusFilter, activeFilter, sortBy]);

  // Check if any filter is active
  const isAnyFilterActive = Boolean(
    searchQuery.trim() !== '' || 
    agencyFilter !== 'ALL' || 
    deadlineFilter !== 'ALL' || 
    statusFilter !== 'ALL' || 
    activeFilter !== 'ALL' ||
    sortBy !== 'latest'
  );

  // Reset all filters
  const handleResetFilters = () => {
    setSearchQuery('');
    setAgencyFilter('ALL');
    setDeadlineFilter('ALL');
    setStatusFilter('ALL');
    setActiveFilter('ALL');
    setSortBy('latest');
  };

  // Toggle activation
  const handleToggleActive = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      const { updated, list } = toggleAnnouncementActive(id);
      setAnnouncements(list);
      setStats(getAnnouncementStats(list));
      setSyncToast(`[${updated.title}] 추천 매칭 ${updated.isActive ? '활성화' : '비활성화'} 완료`);
      setTimeout(() => setSyncToast(null), 3000);
    } catch (err) {
      console.error(err);
    }
  };

  // Review Status update (Approve, Reject, Pending)
  const handleReviewAction = (id: string, newStatus: 'pending' | 'approved' | 'rejected', e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    try {
      const { updated, list } = updateAnnouncementReviewStatus(id, newStatus);
      setAnnouncements(list);
      setStats(getAnnouncementStats(list));
      if (selectedAnnouncement && selectedAnnouncement.id === id) {
        setSelectedAnnouncement(updated);
      }
      setSyncToast(
        newStatus === 'approved' 
          ? `[${updated.title}] 운영 DB 승인 처리되었습니다.` 
          : newStatus === 'rejected' 
          ? `[${updated.title}] 비공식/부적합 공고로 반려 처리되었습니다.` 
          : `[${updated.title}] 검수 대기 상태로 변경되었습니다.`
      );
      setTimeout(() => setSyncToast(null), 3000);
    } catch (err) {
      console.error(err);
    }
  };

  // Multi-selection helper calculations
  const allFilteredIds = filtered.map(item => item.id);
  const isAllFilteredSelected = filtered.length > 0 && allFilteredIds.every(id => selectedIds.includes(id));
  const isSomeFilteredSelected = filtered.some(item => selectedIds.includes(item.id)) && !isAllFilteredSelected;
  const pendingFilteredCount = filtered.filter(item => item.reviewStatus === 'pending').length;

  // Toggle single selection
  const handleToggleSelect = (id: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(itemId => itemId !== id) : [...prev, id]
    );
  };

  // Toggle select all currently filtered announcements
  const handleToggleSelectAll = () => {
    if (isAllFilteredSelected) {
      // Unselect all filtered
      setSelectedIds(prev => prev.filter(id => !allFilteredIds.includes(id)));
    } else {
      // Add all filtered to selection
      setSelectedIds(prev => Array.from(new Set([...prev, ...allFilteredIds])));
    }
  };

  // Select all pending policies in filtered list
  const handleSelectPendingOnly = () => {
    const pendingIds = filtered.filter(item => item.reviewStatus === 'pending').map(item => item.id);
    if (pendingIds.length === 0) {
      setSyncToast('현재 목록에 검수 대기(Pending) 공고가 없습니다.');
      setTimeout(() => setSyncToast(null), 2500);
      return;
    }
    setSelectedIds(pendingIds);
    setSyncToast(`검수 대기 공고 ${pendingIds.length}건이 선택되었습니다. '일괄 검증 완료' 버튼을 클릭하면 즉시 승인됩니다.`);
    setTimeout(() => setSyncToast(null), 3500);
  };

  // Clear all selections
  const handleClearSelection = () => {
    setSelectedIds([]);
  };

  // Single-click bulk validation / review action
  const handleBulkValidate = (status: 'approved' | 'rejected') => {
    if (selectedIds.length === 0) return;
    setIsBulkValidating(true);
    try {
      const res = bulkUpdateAnnouncementReviewStatus(selectedIds, status);
      setAnnouncements(res.list);
      setStats(getAnnouncementStats(res.list));
      
      const count = res.updatedCount;
      const statusText = status === 'approved' 
        ? '검증 완료(운영 DB 승인 및 매칭 풀 활성화)' 
        : '일괄 반려';
      setSyncToast(`[일괄 검증 처리] ${count}건의 정책자금 공고가 ${statusText} 처리되었습니다.`);
      setTimeout(() => setSyncToast(null), 3500);
      setSelectedIds([]);
    } catch (err) {
      console.error(err);
      alert('일괄 검증 처리 중 오류가 발생했습니다.');
    } finally {
      setIsBulkValidating(false);
    }
  };

  // Confirm delete
  const handleConfirmDelete = async () => {
    if (!announcementToDelete) return;
    setIsDeleting(true);
    try {
      const title = announcementToDelete.title;
      const updatedList = deleteAnnouncement(announcementToDelete.id);
      setAnnouncements(updatedList);
      setStats(getAnnouncementStats(updatedList));
      setAnnouncementToDelete(null);
      setSyncToast(`'${title}' 공고가 영구 삭제되었습니다.`);
      setTimeout(() => setSyncToast(null), 3500);
    } catch (err) {
      console.error(err);
      alert('삭제 중 오류가 발생했습니다.');
    } finally {
      setIsDeleting(false);
    }
  };

  // Manual Crawler Sync
  const handleRunSync = async () => {
    setIsSyncing(true);
    try {
      const res = await runCrawlerSyncSimulation();
      loadData();
      setSyncToast(`실시간 공고 수집 완료: ${res.updated}건 동기화 및 소진율 반영`);
      setTimeout(() => setSyncToast(null), 3500);
    } catch (e) {
      console.error(e);
    } finally {
      setIsSyncing(false);
    }
  };

  // Open JSON modal
  const handleOpenRuleModal = (item: PolicyAnnouncement, mode: 'view' | 'edit', e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedAnnouncement(item);
    setRuleModalMode(mode);
    setEditedRuleJson(JSON.stringify(item.rule, null, 2));
    setJsonError(null);
  };

  // Save edited JSON rule
  const handleSaveRule = () => {
    if (!selectedAnnouncement) return;
    try {
      const parsed: AnnouncementRule = JSON.parse(editedRuleJson);
      const { updated, list } = updateAnnouncementRule(selectedAnnouncement.id, parsed);
      setAnnouncements(list);
      setStats(getAnnouncementStats(list));
      setSelectedAnnouncement(updated);
      setRuleModalMode('view');
      setSyncToast(`[${updated.title}] 정책 JSON 규칙이 갱신되었습니다.`);
      setTimeout(() => setSyncToast(null), 3000);
    } catch (e: any) {
      setJsonError(e.message || '올바른 JSON 문법이 아닙니다.');
    }
  };

  return (
    <div className="space-y-6 animate-fade-in pb-12">
      {/* Toast Notice */}
      {syncToast && (
        <div className="bg-slate-900 text-white px-4 py-3 rounded-2xl flex items-center gap-2.5 text-sm font-bold shadow-lg fixed top-6 right-6 z-50 animate-slide-up border border-slate-700">
          <Sparkles className="w-4 h-4 text-indigo-400 shrink-0" />
          <span>{syncToast}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 animate-pulse" />
            <span className="text-xs font-black text-indigo-600 tracking-wider uppercase">Engine v0.4 Pipeline</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 flex items-center gap-2.5">
            <FileCode2 className="w-6 h-6 text-indigo-600" />
            공고 수집 현황 및 검수·규칙 관리
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            수집 원문 정규화 → JSON 규칙 자동 추출 → 완성도 평가 → 관리자 승인/반려 → 추천 알고리즘 활성화
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleRunSync}
            disabled={isSyncing}
            className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black transition-all shadow-sm active:scale-95 disabled:opacity-60 cursor-pointer"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
            <span>{isSyncing ? '수집 동기화 중...' : '공고 재수집·규칙 파싱 실행'}</span>
          </button>
        </div>
      </div>

      {/* Summary KPI Cards (v0.4 stats) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 block mb-1">총 수집 공고</span>
          <div className="text-2xl font-black text-slate-900">{stats?.total || 0}건</div>
          <span className="text-[10px] font-bold text-indigo-600 mt-1 inline-block">수집 소스 {stats?.sourcesCount || 0}개 기관</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 block mb-1">검수 대기 (Pending)</span>
          <div className="text-2xl font-black text-amber-600">{stats?.pending || 0}건</div>
          <span className="text-[10px] font-bold text-amber-500 mt-1 inline-block">관리자 승인 필요</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 block mb-1">운영 승인 (Approved)</span>
          <div className="text-2xl font-black text-emerald-600">{stats?.approved || 0}건</div>
          <span className="text-[10px] font-bold text-emerald-600 mt-1 inline-block">매칭 풀 진입 허가</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 block mb-1">반려 (Rejected)</span>
          <div className="text-2xl font-black text-rose-600">{stats?.rejected || 0}건</div>
          <span className="text-[10px] font-bold text-rose-500 mt-1 inline-block">비공식·오류 배제</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 block mb-1">매칭 활성화 (Active)</span>
          <div className="text-2xl font-black text-blue-600">{stats?.activeCount || 0}건</div>
          <span className="text-[10px] font-bold text-blue-500 mt-1 inline-block">고객 추천 노출 중</span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-[11px] font-bold text-slate-400 block mb-1">규칙 완성도 평균</span>
          <div className="text-2xl font-black text-slate-800">{stats?.averageCompleteness || 0}점</div>
          <span className="text-[10px] font-bold text-slate-500 mt-1 inline-block">100점 만점 기준</span>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
        {/* Top Row: Search Bar & Review Status Tabs */}
        <div className="flex flex-col lg:flex-row gap-3 items-stretch lg:items-center justify-between">
          {/* Enhanced Search Input */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="공고명, 소관기관, 지원분야, 태그(저신용/대환 등), 금액, 금리 검색..."
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Escape') setSearchQuery('');
              }}
              className="w-full pl-9 pr-20 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all placeholder:text-slate-400"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-12 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-600 rounded-md transition-colors"
                title="검색어 지우기 (ESC)"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
            <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
              <span className="text-[10px] font-black text-slate-400 bg-slate-200/60 px-1.5 py-0.5 rounded">
                {filtered.length}건
              </span>
            </div>
          </div>

          {/* Status Filter Tabs & Selection Helpers */}
          <div className="flex items-center gap-2 overflow-x-auto shrink-0 pb-1 lg:pb-0">
            <div className="flex items-center bg-slate-100 p-1 rounded-xl shrink-0">
              <button
                type="button"
                onClick={() => setStatusFilter('ALL')}
                className={`px-3 py-1.5 text-[11px] font-bold rounded-lg transition-all ${statusFilter === 'ALL' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-900'}`}
              >
                전체 ({announcements.length})
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('pending')}
                className={`px-3 py-1.5 text-[11px] font-bold rounded-lg transition-all flex items-center gap-1.5 ${statusFilter === 'pending' ? 'bg-white text-amber-600 shadow-2xs' : 'text-slate-500 hover:text-slate-900'}`}
              >
                <Clock className="w-3 h-3" />
                대기 ({announcements.filter(a => a.reviewStatus === 'pending').length})
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('approved')}
                className={`px-3 py-1.5 text-[11px] font-bold rounded-lg transition-all flex items-center gap-1.5 ${statusFilter === 'approved' ? 'bg-white text-emerald-600 shadow-2xs' : 'text-slate-500 hover:text-slate-900'}`}
              >
                <CheckCircle2 className="w-3 h-3" />
                승인 ({announcements.filter(a => a.reviewStatus === 'approved').length})
              </button>
              <button
                type="button"
                onClick={() => setStatusFilter('rejected')}
                className={`px-3 py-1.5 text-[11px] font-bold rounded-lg transition-all flex items-center gap-1.5 ${statusFilter === 'rejected' ? 'bg-white text-rose-600 shadow-2xs' : 'text-slate-500 hover:text-slate-900'}`}
              >
                <XCircle className="w-3 h-3" />
                반려 ({announcements.filter(a => a.reviewStatus === 'rejected').length})
              </button>
            </div>

            {/* Quick Selection Helpers */}
            {pendingFilteredCount > 0 && (
              <button
                type="button"
                onClick={handleSelectPendingOnly}
                className="px-2.5 py-1.5 text-[11px] font-bold text-amber-800 bg-amber-50 hover:bg-amber-100 border border-amber-200 rounded-xl flex items-center gap-1.5 transition-colors shrink-0 cursor-pointer shadow-2xs"
                title="검수 대기(Pending) 상태인 공고만 모두 선택합니다"
              >
                <CheckSquare className="w-3.5 h-3.5 text-amber-600" />
                <span>대기 선택 ({pendingFilteredCount})</span>
              </button>
            )}

            {selectedIds.length > 0 && (
              <button
                type="button"
                onClick={handleClearSelection}
                className="px-2.5 py-1.5 text-[11px] font-bold text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors shrink-0 cursor-pointer"
              >
                선택 해제 ({selectedIds.length})
              </button>
            )}
          </div>
        </div>

        {/* Second Row: Dropdown Filters (Agency, Deadline, Active, Sort, Reset) */}
        <div className="flex items-center gap-2.5 flex-wrap pt-1">
          {/* Agency Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-500/20 shrink-0">
            <Building2 className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <span className="text-[11px] font-bold text-slate-500 shrink-0">소관기관:</span>
            <select
              value={agencyFilter}
              onChange={e => setAgencyFilter(e.target.value)}
              className="text-[11px] font-bold bg-transparent border-0 focus:outline-none text-slate-800 cursor-pointer max-w-[190px] truncate"
            >
              <option value="ALL">전체 기관 ({announcements.length}건)</option>
              {uniqueAgencies.map(agency => (
                <option key={agency} value={agency}>
                  {agency} ({agencyCounts[agency] || 0}건)
                </option>
              ))}
            </select>
          </div>

          {/* Deadline Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-500/20 shrink-0">
            <Calendar className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <span className="text-[11px] font-bold text-slate-500 shrink-0">접수마감:</span>
            <select
              value={deadlineFilter}
              onChange={e => setDeadlineFilter(e.target.value)}
              className="text-[11px] font-bold bg-transparent border-0 focus:outline-none text-slate-800 cursor-pointer"
            >
              <option value="ALL">전체 마감일정 ({deadlineCounts.total}건)</option>
              <option value="URGENT_7D">⚡ 마감임박 (7일 이내) ({deadlineCounts.urgent7d}건)</option>
              <option value="URGENT_30D">⏳ 이번달 마감 (30일 이내) ({deadlineCounts.urgent30d}건)</option>
              <option value="OPEN">🟢 접수 진행 중 (상시·연말) ({deadlineCounts.open}건)</option>
              <option value="CLOSED">🔴 접수 마감 (종료) ({deadlineCounts.closed}건)</option>
            </select>
          </div>

          {/* Active Status Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-500/20 shrink-0">
            <span className="text-[11px] font-bold text-slate-500 shrink-0">추천 매칭:</span>
            <select
              value={activeFilter}
              onChange={e => setActiveFilter(e.target.value as any)}
              className="text-[11px] font-bold bg-transparent border-0 focus:outline-none text-slate-800 cursor-pointer"
            >
              <option value="ALL">전체</option>
              <option value="ACTIVE">활성 (Active)</option>
              <option value="INACTIVE">비활성 (Inactive)</option>
            </select>
          </div>

          {/* Sort By Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-500/20 shrink-0">
            <ArrowUpDown className="w-3.5 h-3.5 text-slate-500 shrink-0" />
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="text-[11px] font-bold bg-transparent border-0 focus:outline-none text-slate-800 cursor-pointer"
            >
              <option value="latest">정렬: 최신 등록순</option>
              <option value="deadline">정렬: 마감일 임박순</option>
              <option value="completeness">정렬: 규칙 완성도순</option>
              <option value="exhaustion">정렬: 예산 소진율순</option>
            </select>
          </div>

          {/* Reset Filters Button */}
          {isAnyFilterActive && (
            <button
              type="button"
              onClick={handleResetFilters}
              className="flex items-center gap-1.5 px-3 py-1.5 text-[11px] font-bold text-rose-600 bg-rose-50 hover:bg-rose-100 border border-rose-200 rounded-xl transition-colors cursor-pointer shrink-0 ml-auto"
              title="모든 검색어 및 필터 조건을 초기화합니다"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>필터 초기화</span>
            </button>
          )}
        </div>

        {/* Third Row: Active Filter Chips Bar */}
        {isAnyFilterActive && (
          <div className="flex items-center gap-2 flex-wrap pt-2.5 border-t border-slate-100 text-xs">
            <span className="text-[11px] font-bold text-slate-400">적용된 필터:</span>
            
            {searchQuery.trim() && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 border border-indigo-200 text-[11px] font-semibold">
                검색: &ldquo;{searchQuery}&rdquo;
                <button onClick={() => setSearchQuery('')} className="hover:text-indigo-950 p-0.5" title="검색어 제거">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {agencyFilter !== 'ALL' && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 border border-slate-200 text-[11px] font-semibold">
                기관: {agencyFilter}
                <button onClick={() => setAgencyFilter('ALL')} className="hover:text-slate-950 p-0.5" title="기관 필터 제거">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {deadlineFilter !== 'ALL' && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-50 text-amber-800 border border-amber-200 text-[11px] font-semibold">
                마감: {
                  deadlineFilter === 'URGENT_7D' ? '⚡ 7일 이내 마감' :
                  deadlineFilter === 'URGENT_30D' ? '⏳ 30일 이내 마감' :
                  deadlineFilter === 'OPEN' ? '🟢 접수 진행 중' : '🔴 접수 마감'
                }
                <button onClick={() => setDeadlineFilter('ALL')} className="hover:text-amber-950 p-0.5" title="마감일 필터 제거">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {statusFilter !== 'ALL' && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-700 border border-slate-200 text-[11px] font-semibold">
                검수: {statusFilter === 'pending' ? '대기' : statusFilter === 'approved' ? '승인' : '반려'}
                <button onClick={() => setStatusFilter('ALL')} className="hover:text-slate-950 p-0.5" title="검수 상태 필터 제거">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            {activeFilter !== 'ALL' && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-50 text-blue-700 border border-blue-200 text-[11px] font-semibold">
                추천: {activeFilter === 'ACTIVE' ? '활성' : '비활성'}
                <button onClick={() => setActiveFilter('ALL')} className="hover:text-blue-950 p-0.5" title="추천 여부 필터 제거">
                  <X className="w-3 h-3" />
                </button>
              </span>
            )}

            <span className="text-[11px] font-bold text-slate-500 ml-auto">
              조건에 맞는 공고 <strong className="text-indigo-600 font-black">{filtered.length}건</strong> 표시 중
            </span>
          </div>
        )}
      </div>

      {/* Prominent Sticky Bulk Action Bar */}
      {selectedIds.length > 0 && (
        <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-700 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4 animate-slide-up sticky top-4 z-40">
          <div className="flex items-center gap-3.5 w-full md:w-auto">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30 shrink-0">
              <CheckCheck className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-sm text-white">
                  {selectedIds.length}건의 정책자금 공고 선택됨
                </span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  일괄 검증 모드
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                선택한 정책 공고를 원클릭으로 일괄 검증 완료(운영 DB 승인 및 추천 매칭 풀 활성화) 처리합니다.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 w-full md:w-auto justify-end flex-wrap">
            {/* 1-Click Bulk Verification / Approval */}
            <button
              type="button"
              onClick={() => handleBulkValidate('approved')}
              disabled={isBulkValidating}
              className="flex-1 md:flex-none flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white rounded-xl text-xs font-black shadow-lg shadow-emerald-950/40 transition-all cursor-pointer disabled:opacity-50"
              title="선택한 공고를 한 번의 클릭으로 모두 검증 완료(운영 승인) 처리합니다"
            >
              {isBulkValidating ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <ShieldCheck className="w-4 h-4 text-emerald-200" />
              )}
              <span>선택 공고 일괄 검증 완료 (운영 승인)</span>
            </button>

            {/* Bulk Reject */}
            <button
              type="button"
              onClick={() => handleBulkValidate('rejected')}
              disabled={isBulkValidating}
              className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-rose-600/80 hover:bg-rose-600 active:scale-95 text-white rounded-xl text-xs font-bold transition-all cursor-pointer disabled:opacity-50"
              title="선택한 공고를 일괄 반려 처리합니다"
            >
              <XCircle className="w-3.5 h-3.5" />
              <span>일괄 반려</span>
            </button>

            {/* Clear Selection */}
            <button
              type="button"
              onClick={handleClearSelection}
              className="px-3 py-2.5 text-xs font-bold text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-all cursor-pointer"
            >
              선택 취소
            </button>
          </div>
        </div>
      )}

      {/* Main Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 text-[11px] font-black uppercase tracking-wider">
                <th className="p-3.5 pl-4 w-12 text-center" onClick={e => e.stopPropagation()}>
                  <div className="flex items-center justify-center">
                    <input
                      type="checkbox"
                      checked={isAllFilteredSelected}
                      ref={el => {
                        if (el) el.indeterminate = isSomeFilteredSelected;
                      }}
                      onChange={handleToggleSelectAll}
                      className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                      title={isAllFilteredSelected ? '전체 선택 해제' : '현재 목록 전체 선택'}
                    />
                  </div>
                </th>
                <th className="p-3.5 pl-2">공고 정보 & 소관기관</th>
                <th className="p-3.5">접수기간 & 마감일</th>
                <th className="p-3.5">지원한도 및 금리</th>
                <th className="p-3.5 text-center">규칙 완성도</th>
                <th className="p-3.5 text-center">검수 상태 (Review)</th>
                <th className="p-3.5 text-center">추천 활성화 (Active)</th>
                <th className="p-3.5 text-right pr-5">통제 및 관리</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-xs">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-12 text-center text-slate-400">
                    <div className="max-w-xs mx-auto flex flex-col items-center">
                      <Search className="w-8 h-8 text-slate-300 mb-2" />
                      <p className="font-bold text-slate-700 text-sm mb-1">조건에 부합하는 정책자금 공고가 없습니다.</p>
                      <p className="text-xs text-slate-400 mb-4">선택하신 소관기관, 마감일정 또는 검색어를 확인해주세요.</p>
                      {isAnyFilterActive && (
                        <button
                          type="button"
                          onClick={handleResetFilters}
                          className="px-3 py-1.5 text-xs font-bold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 rounded-xl transition-colors cursor-pointer"
                        >
                          모든 필터 초기화
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ) : (
                filtered.map(item => {
                  const isApproved = item.reviewStatus === 'approved';
                  const isPending = item.reviewStatus === 'pending';
                  const isRejected = item.reviewStatus === 'rejected';
                  const isSelected = selectedIds.includes(item.id);

                  return (
                    <tr 
                      key={item.id}
                      className={`transition-colors group cursor-pointer ${
                        isSelected 
                          ? 'bg-indigo-50/80 hover:bg-indigo-100/70 border-l-4 border-l-indigo-600' 
                          : 'hover:bg-slate-50/70'
                      }`}
                      onClick={() => handleOpenRuleModal(item, 'view')}
                    >
                      {/* 0. Row Selection Checkbox */}
                      <td className="p-3.5 pl-4 text-center" onClick={e => e.stopPropagation()}>
                        <div className="flex items-center justify-center">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => handleToggleSelect(item.id)}
                            className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                            title={isSelected ? '선택 해제' : '공고 선택'}
                          />
                        </div>
                      </td>

                      {/* 1. Title & Agency */}
                      <td className="p-3.5 pl-2 max-w-sm">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">
                            {item.source}
                          </span>
                          <span className="text-[10px] font-medium text-slate-400">
                            {item.versions?.[0]?.version || 'v1.0'}
                          </span>
                        </div>
                        <div className="font-black text-slate-900 group-hover:text-indigo-600 transition-colors line-clamp-1 text-sm">
                          {item.title}
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-2">
                          <span>{item.agency}</span>
                          <span>•</span>
                          <span>소진율 {item.budgetExhaustionRate}%</span>
                        </div>
                      </td>

                      {/* 1-1. Deadline & Period */}
                      <td className="p-3.5 whitespace-nowrap">
                        {(() => {
                          const dl = calculateDeadlineInfo(item.endDate, item.status);
                          return (
                            <div className="flex flex-col items-start gap-1">
                              <span className={`inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-md border ${dl.badgeClass}`}>
                                <Calendar className="w-3 h-3 shrink-0" />
                                <span>{dl.label}</span>
                              </span>
                              <div className="text-[11px] text-slate-500 font-medium">
                                {item.startDate || '-'} ~ {item.endDate || '상시'}
                              </div>
                            </div>
                          );
                        })()}
                      </td>

                      {/* 2. Amount & Rate */}
                      <td className="p-3.5">
                        <div className="font-black text-slate-900">{item.maxAmount}</div>
                        <div className="text-[11px] text-indigo-600 font-bold mt-0.5">
                          {item.baseInterestRate}
                        </div>
                        <div className="text-[10px] text-slate-400 mt-0.5">
                          {item.repaymentPeriod}
                        </div>
                      </td>

                      {/* 3. Completeness Score */}
                      <td className="p-3.5 text-center" onClick={e => e.stopPropagation()}>
                        <div className="inline-flex flex-col items-center">
                          <div className="flex items-center gap-1.5">
                            <span className={`text-sm font-black ${
                              item.completenessScore >= 90 ? 'text-emerald-600' :
                              item.completenessScore >= 70 ? 'text-blue-600' : 'text-amber-600'
                            }`}>
                              {item.completenessScore}점
                            </span>
                          </div>
                          <div className="w-16 h-1.5 bg-slate-100 rounded-full overflow-hidden mt-1">
                            <div 
                              className={`h-full rounded-full ${
                                item.completenessScore >= 90 ? 'bg-emerald-500' :
                                item.completenessScore >= 70 ? 'bg-blue-500' : 'bg-amber-500'
                              }`}
                              style={{ width: `${item.completenessScore}%` }}
                            />
                          </div>
                          {item.warnings && item.warnings.length > 0 && (
                            <span className="text-[10px] text-amber-600 font-bold mt-1 flex items-center gap-0.5" title={item.warnings.join(', ')}>
                              <AlertTriangle className="w-3 h-3" />
                              경고 {item.warnings.length}건
                            </span>
                          )}
                        </div>
                      </td>

                      {/* 4. Review Status */}
                      <td className="p-3.5 text-center" onClick={e => e.stopPropagation()}>
                        <div className="inline-flex flex-col items-center gap-1">
                          <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-black ${
                            isApproved 
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                              : isPending 
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : 'bg-rose-50 text-rose-700 border border-rose-200'
                          }`}>
                            {isApproved && <CheckCircle2 className="w-3 h-3" />}
                            {isPending && <Clock className="w-3 h-3" />}
                            {isRejected && <XCircle className="w-3 h-3" />}
                            {isApproved ? '운영 승인' : isPending ? '검수 대기' : '반려됨'}
                          </span>

                          {/* Fast Action Buttons */}
                          <div className="flex items-center gap-1 mt-1">
                            {!isApproved && (
                              <button
                                onClick={(e) => handleReviewAction(item.id, 'approved', e)}
                                className="px-2 py-0.5 text-[10px] font-bold text-emerald-700 bg-emerald-100/70 hover:bg-emerald-200 rounded transition-colors"
                                title="운영 DB 승인"
                              >
                                승인
                              </button>
                            )}
                            {!isRejected && (
                              <button
                                onClick={(e) => handleReviewAction(item.id, 'rejected', e)}
                                className="px-2 py-0.5 text-[10px] font-bold text-rose-700 bg-rose-100/70 hover:bg-rose-200 rounded transition-colors"
                                title="비공식/오류 반려"
                              >
                                반려
                              </button>
                            )}
                            {isRejected && (
                              <button
                                onClick={(e) => handleReviewAction(item.id, 'pending', e)}
                                className="px-2 py-0.5 text-[10px] font-bold text-amber-700 bg-amber-100/70 hover:bg-amber-200 rounded transition-colors"
                                title="재검수 대기"
                              >
                                대기
                              </button>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* 5. Active Toggle */}
                      <td className="p-3.5 text-center" onClick={e => e.stopPropagation()}>
                        <button
                          type="button"
                          onClick={(e) => handleToggleActive(item.id, e)}
                          disabled={item.reviewStatus === 'rejected'}
                          className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none disabled:opacity-30 disabled:cursor-not-allowed ${
                            item.isActive ? 'bg-indigo-600' : 'bg-slate-300'
                          }`}
                          title={item.reviewStatus === 'rejected' ? '반려된 공고는 활성화할 수 없습니다' : item.isActive ? '매칭 비활성화하기' : '매칭 활성화하기'}
                        >
                          <span
                            className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                              item.isActive ? 'translate-x-5' : 'translate-x-0'
                            }`}
                          />
                        </button>
                        <div className="text-[10px] font-bold text-slate-500 mt-1">
                          {item.isActive ? '매칭 활성' : '비활성'}
                        </div>
                      </td>

                      {/* 6. Controls */}
                      <td className="p-3.5 pr-5 text-right" onClick={e => e.stopPropagation()}>
                        <div className="flex items-center justify-end gap-1.5">
                          {item.sourceUrl && (
                            <a
                              href={item.sourceUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="p-1.5 text-slate-400 hover:text-cyan-600 hover:bg-cyan-50 rounded-lg transition-colors"
                              title="공고 웹페이지 바로가기"
                            >
                              <ExternalLink className="w-4 h-4" />
                            </a>
                          )}
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); setViewingOriginal(item); }}
                            className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                            title="공고 원문 보기"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={(e) => handleOpenRuleModal(item, 'view', e)}
                            className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                            title="JSON 정책 규칙 보기/수정"
                          >
                            <FileCode2 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); setHistoryAnnouncement(item); }}
                            className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                            title="공고 변경 이력 스냅샷"
                          >
                            <History className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); setAnnouncementToDelete(item); }}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                            title="공고 영구 삭제"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* JSON Rule Inspector & Editor Modal */}
      {selectedAnnouncement && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden animate-slide-up flex flex-col max-h-[90vh]">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold px-2 py-0.5 rounded bg-indigo-100 text-indigo-700">
                    JSON Rule Engine v0.4
                  </span>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                    selectedAnnouncement.reviewStatus === 'approved' ? 'bg-emerald-100 text-emerald-800' :
                    selectedAnnouncement.reviewStatus === 'pending' ? 'bg-amber-100 text-amber-800' : 'bg-rose-100 text-rose-800'
                  }`}>
                    {selectedAnnouncement.reviewStatus}
                  </span>
                </div>
                <h3 className="text-base font-black text-slate-900 mt-1">
                  {selectedAnnouncement.title}
                </h3>
              </div>

              <div className="flex items-center gap-2">
                {ruleModalMode === 'view' ? (
                  <button
                    onClick={() => setRuleModalMode('edit')}
                    className="px-3 py-1.5 text-xs font-bold text-indigo-600 hover:bg-indigo-50 rounded-xl border border-indigo-200 transition-colors"
                  >
                    규칙 수정
                  </button>
                ) : (
                  <button
                    onClick={() => setRuleModalMode('view')}
                    className="px-3 py-1.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
                  >
                    보기 모드
                  </button>
                )}
                <button
                  onClick={() => setSelectedAnnouncement(null)}
                  className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="p-6 overflow-y-auto space-y-4 flex-1 font-sans">
              {/* Warnings if any */}
              {selectedAnnouncement.warnings && selectedAnnouncement.warnings.length > 0 && (
                <div className="p-3.5 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-800 space-y-1">
                  <div className="font-bold flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    자동 추출 누락 또는 검증 필요 항목
                  </div>
                  <ul className="list-disc list-inside space-y-0.5 text-[11px] text-amber-700 pl-1">
                    {selectedAnnouncement.warnings.map((w, i) => (
                      <li key={i}>{w}</li>
                    ))}
                  </ul>
                </div>
              )}

              {ruleModalMode === 'view' ? (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-slate-500">추출된 정책자금 정규화 규칙 (JSON)</span>
                    <span className="text-xs font-bold text-emerald-600">완성도 점수: {selectedAnnouncement.completenessScore}점</span>
                  </div>
                  <pre className="p-4 bg-slate-900 text-indigo-200 rounded-xl font-mono text-xs overflow-x-auto leading-relaxed border border-slate-800">
                    {JSON.stringify(selectedAnnouncement.rule, null, 2)}
                  </pre>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-700">JSON 규칙 직접 편집</label>
                    <span className="text-[11px] text-slate-400">신용점수, 금리, 한도, 거치기간 수동 보정</span>
                  </div>
                  <textarea
                    value={editedRuleJson}
                    onChange={e => { setEditedRuleJson(e.target.value); setJsonError(null); }}
                    className="w-full h-72 p-3 bg-slate-900 text-emerald-300 font-mono text-xs rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 border border-slate-800"
                  />
                  {jsonError && (
                    <div className="text-xs text-rose-600 font-bold flex items-center gap-1">
                      <XCircle className="w-4 h-4" />
                      {jsonError}
                    </div>
                  )}
                </div>
              )}

              {/* Source Info */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1.5">
                <div className="flex items-center justify-between text-slate-600">
                  <span className="font-bold">원문 출처:</span>
                  <a 
                    href={selectedAnnouncement.sourceUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-indigo-600 hover:underline flex items-center gap-1 font-bold"
                  >
                    <span>공식 고시 페이지 열기</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
                <div className="flex items-center justify-between text-slate-600">
                  <span className="font-bold">접수 기간:</span>
                  <span>{selectedAnnouncement.startDate} ~ {selectedAnnouncement.endDate}</span>
                </div>
                <div className="flex items-center justify-between text-slate-600">
                  <span className="font-bold">문의처:</span>
                  <span>{selectedAnnouncement.contactInfo || '해당 소관 기관 문의'}</span>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleReviewAction(selectedAnnouncement.id, 'approved')}
                  className={`px-3 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 ${
                    selectedAnnouncement.reviewStatus === 'approved' 
                      ? 'bg-emerald-600 text-white' 
                      : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>운영 승인</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleReviewAction(selectedAnnouncement.id, 'rejected')}
                  className={`px-3 py-2 text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 ${
                    selectedAnnouncement.reviewStatus === 'rejected' 
                      ? 'bg-rose-600 text-white' 
                      : 'bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200'
                  }`}
                >
                  <XCircle className="w-4 h-4" />
                  <span>반려 처리</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                {ruleModalMode === 'edit' && (
                  <button
                    type="button"
                    onClick={handleSaveRule}
                    className="px-4 py-2 text-xs font-bold bg-indigo-600 text-white hover:bg-indigo-700 rounded-xl transition-all shadow-sm"
                  >
                    규칙 저장 및 재평가
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setSelectedAnnouncement(null)}
                  className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-200 rounded-xl transition-all"
                >
                  닫기
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Original Announcement Text Modal */}
      {viewingOriginal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl p-6 border border-slate-100 max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Eye className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-black text-slate-900">공고 원문 보기</h3>
                <span className="ml-2 text-xs font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full">
                  {viewingOriginal.agency}
                </span>
              </div>
              <div className="flex items-center gap-2">
                {viewingOriginal.sourceUrl && (
                  <a
                    href={viewingOriginal.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    해당 기관 공고 페이지
                  </a>
                )}
                <button
                  onClick={() => setViewingOriginal(null)}
                  className="p-1 text-slate-400 hover:text-slate-700 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <div className="py-6 overflow-y-auto flex-1 space-y-6">
              <div>
                <h2 className="text-xl font-black text-slate-900 mb-2 leading-tight">
                  {viewingOriginal.title}
                </h2>
                <div className="flex flex-wrap items-center gap-3 text-sm text-slate-500 font-medium">
                  <span className="flex items-center gap-1">
                    <Building2 className="w-4 h-4 text-slate-400" /> {viewingOriginal.source}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4 text-slate-400" /> 수집일: {viewingOriginal.collectedAt.replace('T', ' ')}
                  </span>
                </div>
              </div>

              <div className="p-5 bg-slate-50 rounded-xl border border-slate-100 whitespace-pre-wrap text-sm text-slate-700 leading-relaxed font-medium">
                {viewingOriginal.description ? viewingOriginal.description : "공고 원문 내용이 제공되지 않았습니다."}
              </div>
            </div>
            
            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setViewingOriginal(null)}
                className="px-5 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      )}$

      {/* Version Change History Modal */}
      {historyAnnouncement && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg p-6 border border-slate-100 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-indigo-600" />
                <h3 className="text-base font-black text-slate-900">공고 버전 및 변경 이력</h3>
              </div>
              <button
                onClick={() => setHistoryAnnouncement(null)}
                className="p-1 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 overflow-y-auto space-y-4 flex-1">
              <div className="text-xs text-slate-600 font-bold mb-2">
                {historyAnnouncement.title}
              </div>

              <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                {historyAnnouncement.versions.map((ver, idx) => (
                  <div key={idx} className="relative">
                    <div className="absolute -left-6 top-1 w-3.5 h-3.5 rounded-full bg-indigo-600 ring-4 ring-white" />
                    <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-black text-indigo-700">{ver.version}</span>
                        <span className="text-[11px] text-slate-400">{ver.changedAt.replace('T', ' ')}</span>
                      </div>
                      <div className="text-xs font-bold text-slate-900 mb-1">
                        {ver.snapshotTitle}
                      </div>
                      <p className="text-[11px] text-slate-600 leading-relaxed">
                        {ver.summary}
                      </p>
                      {ver.changedFields && ver.changedFields.length > 0 && (
                        <div className="mt-2 flex flex-wrap gap-1">
                          {ver.changedFields.map((f, fi) => (
                            <span key={fi} className="text-[10px] font-mono px-1.5 py-0.5 bg-indigo-50 text-indigo-700 rounded border border-indigo-100">
                              {f}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button
                onClick={() => setHistoryAnnouncement(null)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {announcementToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 border border-slate-100">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mb-4">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-black text-slate-900 mb-1">공고 데이터 영구 삭제</h3>
            <p className="text-sm text-slate-600 mb-4 leading-relaxed">
              정말 <span className="font-bold text-slate-900">'{announcementToDelete.title}'</span> 공고를 수집 DB에서 완전히 삭제하시겠습니까?
            </p>
            <div className="p-3 bg-rose-50 rounded-xl border border-rose-100 text-xs text-rose-700 font-medium mb-6">
              ⚠️ <strong>주의:</strong> 삭제 시 추출된 JSON 규칙, 버전 변경 이력 및 추천 매칭 연결 정보가 영구적으로 제거됩니다.
            </div>
            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setAnnouncementToDelete(null)}
                disabled={isDeleting}
                className="px-4 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
              >
                취소
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-5 py-2.5 text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition-all shadow-sm flex items-center gap-2"
              >
                {isDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                {isDeleting ? '삭제 중...' : '영구 삭제'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
