import React, { useState, useMemo } from 'react';
import { CrmConsultation } from '../../types';
import { Search, Filter, MessageCircle, Phone, Users, Mail, MessageSquare, AlertCircle } from 'lucide-react';

interface ConsultationTimelineProps {
  consultations: CrmConsultation[];
}

export const ConsultationTimeline: React.FC<ConsultationTimelineProps> = ({ consultations }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedChannel, setSelectedChannel] = useState<string>('all');

  const filteredConsultations = useMemo(() => {
    return consultations.filter(c => {
      const matchesSearch =
        (c.primaryNeeds || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (c.primaryDiagnosis || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (c.importantNote || '').toLowerCase().includes(searchTerm.toLowerCase());
      const matchesChannel = selectedChannel === 'all' || c.channel === selectedChannel;
      return matchesSearch && matchesChannel;
    }).sort((a, b) => new Date(b.consultDate).getTime() - new Date(a.consultDate).getTime());
  }, [consultations, searchTerm, selectedChannel]);

  const getChannelIcon = (channel: string) => {
    switch (channel) {
      case '전화': return <Phone className="w-4 h-4" />;
      case '대면': return <Users className="w-4 h-4" />;
      case '카톡': return <MessageCircle className="w-4 h-4" />;
      case '이메일': return <Mail className="w-4 h-4" />;
      default: return <MessageSquare className="w-4 h-4" />;
    }
  };

  return (
    <div className="flex flex-col space-y-6">
      {/* Filter & Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="니즈, 진단결과, 메모 검색..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
          />
        </div>
        <div className="relative w-full sm:w-48 shrink-0">
          <Filter className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <select
            value={selectedChannel}
            onChange={(e) => setSelectedChannel(e.target.value)}
            className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 appearance-none font-bold text-slate-600 transition-all cursor-pointer"
          >
            <option value="all">모든 채널</option>
            <option value="전화">전화</option>
            <option value="대면">대면</option>
            <option value="카톡">카카오톡</option>
            <option value="이메일">이메일</option>
            <option value="기타">기타</option>
          </select>
        </div>
      </div>

      {/* Timeline */}
      <div className="relative border-l-2 border-slate-100 ml-3 pl-6 space-y-8 mt-4 pb-4">
        {filteredConsultations.length === 0 ? (
          <div className="py-12 text-center">
            <p className="text-slate-400 font-bold">조건에 맞는 상담 기록이 없습니다.</p>
          </div>
        ) : (
          filteredConsultations.map((c) => (
            <div key={c.id} className="relative animate-fade-in">
              {/* Timeline Node */}
              <div className="absolute -left-[35px] top-1 bg-white p-1.5 rounded-full border border-slate-200 text-slate-500 shadow-sm">
                {getChannelIcon(c.channel)}
              </div>
              
              {/* Card */}
              <div className="bg-white border border-slate-100 p-5 rounded-2xl shadow-sm hover:shadow-md hover:border-indigo-100 transition-all group">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex items-center gap-3">
                    <span className="font-black text-slate-900 text-lg">{c.consultDate}</span>
                    <span className="px-2.5 py-1 bg-slate-100 text-slate-600 rounded-lg text-xs font-bold group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                      {c.channel}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-300 font-black tracking-wider uppercase">ID: {c.displayId}</span>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <p className="text-xs font-bold text-slate-400 mb-1">주요 니즈</p>
                    <p className="text-sm font-medium text-slate-800 leading-relaxed">{c.primaryNeeds}</p>
                  </div>
                  
                  <div className="bg-slate-50 p-4 rounded-xl border border-slate-100/50">
                    <p className="text-xs font-bold text-slate-500 mb-1.5 flex items-center gap-1.5">
                      <Search className="w-3.5 h-3.5" /> 1차 진단 결과
                    </p>
                    <p className="text-sm font-medium text-slate-800 leading-relaxed">
                      {c.primaryDiagnosis}
                    </p>
                  </div>
                  
                  <div>
                    <p className="text-xs font-black text-indigo-500 mb-1.5 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span> 
                      다음 단계 (Next Step)
                    </p>
                    <p className="text-sm font-bold text-slate-800 bg-indigo-50/50 p-3 rounded-xl border border-indigo-100/50">
                      {c.nextStep}
                    </p>
                  </div>
                  
                  {c.importantNote && (
                    <div className="mt-2 p-3 bg-rose-50 border border-rose-100 rounded-xl flex items-start gap-2.5">
                      <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
                      <div className="flex-1">
                        <p className="text-xs font-bold text-rose-800 mb-0.5">중요 메모</p>
                        <p className="text-sm text-rose-900 font-medium leading-relaxed">
                          {c.importantNote}
                        </p>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
