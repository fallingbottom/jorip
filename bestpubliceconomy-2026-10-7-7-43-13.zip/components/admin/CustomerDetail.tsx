import React, { useState, useEffect } from 'react';
import { ChevronLeft, Plus, DollarSign, FileText, MessageCircle, Sparkles, Loader2, Trash2 } from 'lucide-react';
import { CrmFinancial, CrmApplication, CrmConsultation } from '../../types';
import { getCustomer, getFinancials, addFinancial, getApplications, addApplication, getConsultations, addConsultation, deleteCustomer } from '../../services/crmService';
import { CrmCustomer, UserProfile, BusinessType, Industry, AnalysisResult } from '../../types';
import // @ts-ignore
{ analyzePolicyMatching } from '../../services/geminiService';
import { fetchLatestPolicyData } from '../../services/fundDataSource';
import { ResultDashboard } from '../ResultDashboard';
import { ConsultationTimeline } from './ConsultationTimeline';
import { CrmInputAssistant } from './CrmInputAssistant';
import { formatKoreanMoney } from '../../services/crmRecommendationService';

interface CustomerDetailProps {
  customerId: string;
  onBack: () => void;
}

export const CustomerDetail: React.FC<CustomerDetailProps> = ({ customerId, onBack }) => {
  const [activeTab, setActiveTab] = useState<'financial' | 'application' | 'consultation' | 'simulation'>('financial');
  const [customer, setCustomer] = useState<CrmCustomer | null>(null);
  
  // Simulation States
  const [simRevenue, setSimRevenue] = useState(0);
  const [simCredit, setSimCredit] = useState(700);
  const [simResult, setSimResult] = useState<AnalysisResult | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);
  
  const [financials, setFinancials] = useState<CrmFinancial[]>([]);
  const [applications, setApplications] = useState<CrmApplication[]>([]);
  const [consultations, setConsultations] = useState<CrmConsultation[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [isDeletingCustomer, setIsDeletingCustomer] = useState(false);

  // States for modals
  const [showFinModal, setShowFinModal] = useState(false);
  const [showAppModal, setShowAppModal] = useState(false);
  const [showConModal, setShowConModal] = useState(false);

  // Forms
  const [newFin, setNewFin] = useState<any>({ year: new Date().getFullYear(), vatRevenue: 0, creditScore: 700 });
  const [newApp, setNewApp] = useState<any>({ applyDate: new Date().toISOString().split('T')[0], applyType: '직접대출', status: '진행중' });
  const [newCon, setNewCon] = useState<any>({ consultDate: new Date().toISOString().split('T')[0], channel: '전화' });

  const loadData = async () => {
    setLoading(true);
    try {
      const [cust, fins, apps, cons] = await Promise.all([
        getCustomer(customerId),
        getFinancials(customerId),
        getApplications(customerId),
        getConsultations(customerId)
      ]);
      if (cust) setCustomer(cust);
      setFinancials(fins);
      if (fins.length > 0) {
        setSimRevenue(fins[0].vatRevenue || 0);
        setSimCredit(fins[0].creditScore || 700);
      }
      setApplications(apps);
      setConsultations(cons);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [customerId]);

  const handleAddFin = async () => {
    await addFinancial(customerId, newFin);
    setShowFinModal(false);
    loadData();
  };

  const handleAddApp = async () => {
    await addApplication(customerId, newApp);
    setShowAppModal(false);
    loadData();
  };

  const handleAddCon = async () => {
    await addConsultation(customerId, newCon);
    setShowConModal(false);
    loadData();
  };


  const handleRunSimulation = async () => {
    if (!customer) return;
    setIsSimulating(true);
    setSimResult(null);
    try {
      const policies = await fetchLatestPolicyData();
      
      const profile: UserProfile = {
        name: customer.ceoName || '고객',
        businessName: customer.businessName || '사업장',
        businessRegistrationNumber: '',
        businessAddress: customer.address || '',
        businessType: customer.businessType === '법인' ? BusinessType.CORPORATION : BusinessType.INDIVIDUAL,
        industry: Industry.SERVICE, // fallback
        location: customer.province || '전국',
        foundedYear: customer.openDate ? customer.openDate.split('-')[0] : new Date().getFullYear().toString(),
        annualRevenue: simRevenue,
        creditScore: simCredit,
        employees: customer.employeeCount || 0,
        fundingNeed: 50000000,
        expectedProfitMargin: 15,
        cashFlowStatus: 70,
        debt1Tier: 0,
        debt2Tier: 0,
        debtCardLoan: 0,
        debtOther: 0,
        isMyDataLinked: true
      };

      const result = await analyzePolicyMatching(profile, policies);
      setSimResult(result);
    } catch (e) {
      console.error(e);
      alert('시뮬레이션 중 오류가 발생했습니다.');
    } finally {
      setIsSimulating(false);
    }
  };

  const handleDeleteCustomer = async () => {
    setIsDeletingCustomer(true);
    try {
      await deleteCustomer(customerId);
      setIsDeleteModalOpen(false);
      onBack();
    } catch (e) {
      console.error(e);
      alert('고객 삭제 중 오류가 발생했습니다.');
    } finally {
      setIsDeletingCustomer(false);
    }
  };

  return (

    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 bg-white rounded-full shadow-sm hover:bg-slate-50 transition-colors border border-slate-200">
            <ChevronLeft className="w-5 h-5 text-slate-600" />
          </button>
          <div>
            <h2 className="text-2xl font-black text-slate-900">
              {customer?.businessName || '고객 상세 관리'}
            </h2>
            <p className="text-slate-500 mt-1 flex items-center gap-2 text-xs">
              <span>고객ID: {customer?.displayId || customerId}</span>
              {customer?.ceoName && <span>• 대표자: {customer.ceoName}</span>}
              {customer?.businessType && <span>• {customer.businessType}</span>}
              {customer?.province && <span>• {customer.province} {customer.city}</span>}
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setIsDeleteModalOpen(true)}
          className="flex items-center gap-2 px-3.5 py-2 text-xs font-bold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-xl transition-colors border border-rose-200 shadow-sm self-start sm:self-center"
          title="고객 데이터 삭제"
        >
          <Trash2 className="w-4 h-4" />
          <span>고객 삭제</span>
        </button>
      </div>

      <div className="flex gap-4 border-b border-slate-200">
        <button
          onClick={() => setActiveTab('financial')}
          className={`pb-4 px-2 font-bold text-sm transition-colors border-b-2 ${activeTab === 'financial' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-800'}`}
        >
          <DollarSign className="w-4 h-4 inline-block mr-2" />
          재무신용정보 (Sheet 2)
        </button>
        <button
          onClick={() => setActiveTab('application')}
          className={`pb-4 px-2 font-bold text-sm transition-colors border-b-2 ${activeTab === 'application' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-800'}`}
        >
          <FileText className="w-4 h-4 inline-block mr-2" />
          정책자금신청이력 (Sheet 3)
        </button>
        <button
          onClick={() => setActiveTab('consultation')}
          className={`pb-4 px-2 font-bold text-sm transition-colors border-b-2 ${activeTab === 'consultation' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-800'}`}
        >
          <MessageCircle className="w-4 h-4 inline-block mr-2" />
          상담기록 (Sheet 4)
        </button>
        <button
          onClick={() => setActiveTab('simulation')}
          className={`pb-4 px-2 font-bold text-sm transition-colors border-b-2 ${activeTab === 'simulation' ? 'border-amber-500 text-amber-600' : 'border-transparent text-slate-500 hover:text-slate-800'}`}
        >
          <Sparkles className="w-4 h-4 inline-block mr-2 text-amber-500" />
          상담원 전용 시뮬레이션
        </button>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
        {loading ? (
          <p className="text-slate-500 text-center py-8">데이터를 불러오는 중입니다...</p>
        ) : (
          <>
            {/* Financial Tab */}
            {activeTab === 'financial' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-bold text-lg text-slate-800">재무 및 신용 이력</h3>
                  <button onClick={() => setShowFinModal(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-indigo-700">
                    <Plus className="w-4 h-4" /> 추가
                  </button>
                </div>
                {financials.length === 0 ? <p className="text-slate-500">데이터가 없습니다.</p> : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead className="bg-slate-50 text-xs text-slate-500 font-bold border-y border-slate-100">
                        <tr>
                          <th className="p-3">기준년도</th>
                          <th className="p-3">부가세매출</th>
                          <th className="p-3">소득금액</th>
                          <th className="p-3">신용점수</th>
                          <th className="p-3">총대출잔액</th>
                          <th className="p-3">연체/체납</th>
                        </tr>
                      </thead>
                      <tbody className="text-sm text-slate-700">
                        {financials.map(f => (
                          <tr key={f.id} className="border-b border-slate-50">
                            <td className="p-3 font-bold">{f.year}</td>
                            <td className="p-3">{f.vatRevenue?.toLocaleString()}원</td>
                            <td className="p-3">{f.incomeAmount?.toLocaleString()}원</td>
                            <td className="p-3">{f.creditScore}점 ({f.creditGrade})</td>
                            <td className="p-3">{f.totalLoanBalance?.toLocaleString()}원</td>
                            <td className="p-3">
                              {f.isOverdue === 'Y' && <span className="text-red-500 font-bold mr-2">연체</span>}
                              {f.isTaxArrears === 'Y' && <span className="text-red-500 font-bold">체납</span>}
                              {f.isOverdue !== 'Y' && f.isTaxArrears !== 'Y' && <span className="text-emerald-500">양호</span>}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* Application Tab */}
            {activeTab === 'application' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-bold text-lg text-slate-800">정책자금 신청 이력</h3>
                  <button onClick={() => setShowAppModal(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-indigo-700">
                    <Plus className="w-4 h-4" /> 추가
                  </button>
                </div>
                {applications.length === 0 ? <p className="text-slate-500">데이터가 없습니다.</p> : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead className="bg-slate-50 text-xs text-slate-500 font-bold border-y border-slate-100">
                        <tr>
                          <th className="p-3">신청일</th>
                          <th className="p-3">유형</th>
                          <th className="p-3">상품명</th>
                          <th className="p-3">신청금액</th>
                          <th className="p-3">상태</th>
                          <th className="p-3">승인금액</th>
                        </tr>
                      </thead>
                      <tbody className="text-sm text-slate-700">
                        {applications.map(a => (
                          <tr key={a.id} className="border-b border-slate-50">
                            <td className="p-3">{a.applyDate}</td>
                            <td className="p-3"><span className="px-2 py-1 bg-slate-100 rounded-md font-bold text-xs">{a.applyType}</span></td>
                            <td className="p-3 font-bold">{a.productName}</td>
                            <td className="p-3">{a.applyAmount?.toLocaleString()}원</td>
                            <td className="p-3">
                              <span className={`px-2 py-1 rounded-md font-bold text-xs ${
                                a.status === '승인' ? 'bg-emerald-100 text-emerald-700' :
                                a.status === '부결' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'
                              }`}>{a.status}</span>
                            </td>
                            <td className="p-3 font-bold text-emerald-600">{a.approvedAmount ? `${a.approvedAmount.toLocaleString()}원` : '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* Consultation Tab */}
            {activeTab === 'consultation' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-bold text-lg text-slate-800">상담 기록</h3>
                  <button onClick={() => setShowConModal(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-indigo-700">
                    <Plus className="w-4 h-4" /> 추가
                  </button>
                </div>
                <ConsultationTimeline consultations={consultations} />
              </div>
            )}
            
            {/* Simulation Tab */}
            {activeTab === 'simulation' && (
              <div className="animate-fade-in">
                <div className="bg-amber-50/70 border border-amber-200 rounded-3xl p-6 mb-8 shadow-xs">
                  <h3 className="text-xl font-black text-amber-900 mb-2 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-amber-500" />
                    AI 정책자금 추천 시뮬레이션
                  </h3>
                  <p className="text-amber-700 text-sm mb-5">
                    현재 고객({customer?.ceoName} / {customer?.businessName})의 예상 매출과 신용점수를 입력하여, 어떤 정책자금이 추천될지 상담 전에 미리 시뮬레이션 테스트해 볼 수 있습니다.
                  </p>

                  {/* Input Assistant for Simulation */}
                  <div className="mb-5">
                    <CrmInputAssistant
                      industryName={customer?.industryName}
                      businessType={customer?.businessType}
                      province={customer?.province}
                      employeeCount={customer?.employeeCount}
                      currentRevenue={simRevenue}
                      currentCredit={simCredit}
                      onApplyRevenue={(rev) => setSimRevenue(rev)}
                      onApplyCredit={(cred) => setSimCredit(cred)}
                      onApplyBoth={(rev, cred) => {
                        setSimRevenue(rev);
                        setSimCredit(cred);
                      }}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                    <div className="bg-white/90 p-3.5 rounded-2xl border border-amber-200/80">
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="block text-xs font-bold text-amber-950">예상 연 매출액 (원)</label>
                        {simRevenue > 0 && (
                          <span className="text-[11px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-md">
                            {formatKoreanMoney(simRevenue)}
                          </span>
                        )}
                      </div>
                      <input 
                        type="number" 
                        value={simRevenue || ''} 
                        onChange={e => setSimRevenue(Number(e.target.value))} 
                        className="w-full p-2.5 rounded-xl border border-amber-200 focus:border-amber-500 focus:ring-amber-500 font-bold text-slate-800 text-sm"
                        step="10000000"
                        placeholder="예: 150000000"
                      />
                    </div>
                    <div className="bg-white/90 p-3.5 rounded-2xl border border-amber-200/80">
                      <div className="flex items-center justify-between mb-1.5">
                        <label className="block text-xs font-bold text-amber-950">예상 신용점수 (NICE/KCB)</label>
                        {simCredit > 0 && (
                          <span className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${
                            simCredit >= 750 ? 'bg-emerald-100 text-emerald-700' :
                            simCredit >= 650 ? 'bg-blue-100 text-blue-700' : 'bg-amber-100 text-amber-700'
                          }`}>
                            {simCredit}점 ({simCredit >= 750 ? '우량' : simCredit >= 650 ? '양호' : '주의'})
                          </span>
                        )}
                      </div>
                      <input 
                        type="number" 
                        value={simCredit || ''} 
                        onChange={e => setSimCredit(Number(e.target.value))} 
                        className="w-full p-2.5 rounded-xl border border-amber-200 focus:border-amber-500 focus:ring-amber-500 font-bold text-slate-800 text-sm"
                        min="300" max="1000"
                        placeholder="예: 740"
                      />
                    </div>
                  </div>
                  
                  <button 
                    onClick={handleRunSimulation}
                    disabled={isSimulating}
                    className="w-full sm:w-auto px-6 py-3 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-colors disabled:opacity-70 shadow-sm"
                  >
                    {isSimulating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
                    {isSimulating ? '시뮬레이션 분석 중...' : '시뮬레이션 실행'}
                  </button>
                </div>

                {simResult && (
                  <div className="border-t border-slate-200 pt-8 mt-8">
                    <h4 className="text-lg font-black text-slate-800 mb-6">시뮬레이션 결과</h4>
                    <div className="scale-95 origin-top">
                      <ResultDashboard 
                        result={simResult} 
                        onReset={() => setSimResult(null)}
                        profile={{
                          name: customer?.ceoName || '고객',
                          businessName: customer?.businessName || '사업장',
                          businessRegistrationNumber: '',
                          businessAddress: customer?.address || '',
                          businessType: customer?.businessType === '법인' ? BusinessType.CORPORATION : BusinessType.INDIVIDUAL,
                          industry: Industry.SERVICE,
                          location: customer?.province || '전국',
                          foundedYear: customer?.openDate ? customer.openDate.split('-')[0] : new Date().getFullYear().toString(),
                          annualRevenue: simRevenue,
                          creditScore: simCredit,
                          employees: customer?.employeeCount || 0,
                          fundingNeed: 50000000,
                          expectedProfitMargin: 15,
                          cashFlowStatus: 70,
                          debt1Tier: 0,
                          debt2Tier: 0,
                          debtCardLoan: 0,
                          debtOther: 0,
                          isMyDataLinked: true
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>

      {/* Modals - Simplified for brevity */}
      {showFinModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl p-6 max-w-xl w-full shadow-2xl animate-slide-up max-h-[90vh] overflow-y-auto">
            <h3 className="font-black text-lg text-slate-900 mb-1">재무 정보 추가 (Sheet 2)</h3>
            <p className="text-xs text-slate-500 mb-4">고객({customer?.ceoName} / {customer?.businessName})의 재무 및 신용 평가 지표를 기록합니다.</p>
            
            {/* Input Assistant */}
            <div className="mb-4">
              <CrmInputAssistant
                industryName={customer?.industryName}
                businessType={customer?.businessType}
                province={customer?.province}
                employeeCount={customer?.employeeCount}
                currentRevenue={newFin.vatRevenue}
                currentCredit={newFin.creditScore}
                onApplyRevenue={(rev) => setNewFin(prev => ({ ...prev, vatRevenue: rev }))}
                onApplyCredit={(cred) => setNewFin(prev => ({ ...prev, creditScore: cred }))}
                onApplyBoth={(rev, cred) => setNewFin(prev => ({ ...prev, vatRevenue: rev, creditScore: cred }))}
              />
            </div>

            <div className="space-y-3.5 bg-slate-50 p-4 rounded-xl border border-slate-200/80">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">기준년도</label>
                <input type="number" placeholder="기준년도 (예: 2025)" value={newFin.year} onChange={e => setNewFin({...newFin, year: Number(e.target.value)})} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold" />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-600">부가세 연매출액 (원)</label>
                  {newFin.vatRevenue > 0 && (
                    <span className="text-[11px] font-bold text-indigo-700 bg-indigo-100 px-2 py-0.5 rounded-md">
                      {formatKoreanMoney(newFin.vatRevenue)}
                    </span>
                  )}
                </div>
                <input type="number" placeholder="부가세매출 (원)" value={newFin.vatRevenue || ''} onChange={e => setNewFin({...newFin, vatRevenue: Number(e.target.value)})} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold" step="10000000" />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-600">대표자 신용점수 (NICE/KCB)</label>
                  {newFin.creditScore > 0 && (
                    <span className="text-[11px] font-bold text-blue-700 bg-blue-100 px-2 py-0.5 rounded-md">
                      {newFin.creditScore}점
                    </span>
                  )}
                </div>
                <input type="number" placeholder="신용점수" value={newFin.creditScore || ''} onChange={e => setNewFin({...newFin, creditScore: Number(e.target.value)})} className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-bold" min="300" max="1000" />
              </div>
            </div>
            <div className="mt-5 flex justify-end gap-3">
              <button onClick={() => setShowFinModal(false)} className="px-4 py-2 text-slate-600 font-bold hover:bg-slate-100 rounded-xl">취소</button>
              <button onClick={handleAddFin} className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold shadow-sm">저장하기</button>
            </div>
          </div>
        </div>
      )}

      {showAppModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full">
            <h3 className="font-black text-lg mb-4">신청 이력 추가</h3>
            <div className="space-y-3">
              <input type="date" value={newApp.applyDate} onChange={e => setNewApp({...newApp, applyDate: e.target.value})} className="w-full p-2 border border-slate-200 rounded-lg" />
              <input type="text" placeholder="상품명" value={newApp.productName || ''} onChange={e => setNewApp({...newApp, productName: e.target.value})} className="w-full p-2 border border-slate-200 rounded-lg" />
              <select value={newApp.status} onChange={e => setNewApp({...newApp, status: e.target.value})} className="w-full p-2 border border-slate-200 rounded-lg">
                <option value="승인">승인</option>
                <option value="부결">부결</option>
                <option value="진행중">진행중</option>
                <option value="보류">보류</option>
              </select>
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <button onClick={() => setShowAppModal(false)} className="px-4 py-2 text-slate-600 font-bold">취소</button>
              <button onClick={handleAddApp} className="px-4 py-2 bg-indigo-600 text-white rounded-lg font-bold">저장</button>
            </div>
          </div>
        </div>
      )}

      {showConModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl p-6 max-w-md w-full">
            <h3 className="font-black text-lg mb-4">상담 기록 추가</h3>
            <div className="space-y-3">
              <input type="date" value={newCon.consultDate} onChange={e => setNewCon({...newCon, consultDate: e.target.value})} className="w-full p-2 border border-slate-200 rounded-lg" />
              <input type="text" placeholder="주요 니즈" value={newCon.primaryNeeds || ''} onChange={e => setNewCon({...newCon, primaryNeeds: e.target.value})} className="w-full p-2 border border-slate-200 rounded-lg" />
              <input type="text" placeholder="진단 결과" value={newCon.primaryDiagnosis || ''} onChange={e => setNewCon({...newCon, primaryDiagnosis: e.target.value})} className="w-full p-2 border border-slate-200 rounded-lg" />
              <input type="text" placeholder="다음 단계" value={newCon.nextStep || ''} onChange={e => setNewCon({...newCon, nextStep: e.target.value})} className="w-full p-2 border border-slate-200 rounded-lg" />
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <button onClick={() => setShowConModal(false)} className="px-4 py-2 text-slate-600 font-bold">취소</button>
              <button onClick={handleAddCon} className="px-4 py-2 bg-indigo-600 text-white rounded-lg font-bold">저장</button>
            </div>
          </div>
        </div>
      )}

      {/* Customer Delete Confirmation Modal */}
      {isDeleteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-6 border border-slate-100">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mb-4">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-black text-slate-900 mb-1">고객 데이터 삭제 확인</h3>
            <p className="text-sm text-slate-600 mb-4 leading-relaxed">
              정말 <span className="font-bold text-slate-900">'{customer?.businessName || customerId}'</span> 고객 데이터를 삭제하시겠습니까?
            </p>
            <div className="p-3.5 bg-rose-50/80 rounded-xl border border-rose-100 text-xs text-rose-700 font-medium mb-6">
              ⚠️ <strong>주의:</strong> 등록된 재무정보, 정책자금 신청이력 및 상담기록이 모두 영구 삭제되며 이전 고객 목록으로 이동합니다.
            </div>
            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={() => setIsDeleteModalOpen(false)}
                disabled={isDeletingCustomer}
                className="px-4 py-2.5 text-sm font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
              >
                취소
              </button>
              <button
                type="button"
                onClick={handleDeleteCustomer}
                disabled={isDeletingCustomer}
                className="px-5 py-2.5 text-sm font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl transition-all shadow-sm flex items-center gap-2"
              >
                {isDeletingCustomer ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                {isDeletingCustomer ? '삭제 중...' : '영구 삭제'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
