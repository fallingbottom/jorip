import React, { useState, useEffect, useMemo } from 'react';
import { 
  Users, 
  Search, 
  AlertTriangle, 
  ShieldAlert, 
  CheckCircle2, 
  Sliders, 
  FileText, 
  Download, 
  Sparkles, 
  ArrowUpRight, 
  Building2, 
  CreditCard, 
  TrendingUp, 
  DollarSign, 
  RefreshCw, 
  Printer, 
  ExternalLink, 
  ChevronRight, 
  Layers, 
  ShieldCheck,
  Check,
  AlertOctagon,
  Info
} from 'lucide-react';
import { CrmCustomer, CrmFinancial, CrmApplication, BusinessType, Industry, AnalysisResult } from '../../types';
import { getCustomers, getFinancials, getApplications } from '../../services/crmService';
// @ts-ignore
import { analyzePolicyMatching } from '../../services/geminiService';
import { fetchLatestPolicyData } from '../../services/fundDataSource';
import { formatKoreanMoney } from '../../services/crmRecommendationService';

interface EnrichedConsultantClient {
  id: string;
  displayId: string;
  ceoName: string;
  businessName: string;
  industry: string;
  province: string;
  openDate: string;
  creditScore: number;
  creditGrade: string;
  vatRevenue: number;
  totalDebt: number;
  activePolicies: string[];
  // 경고 지표
  isTaxArrears: boolean;
  isOverdue: boolean;
  isCapitalImpairment: boolean;
  hasHighCardLoan: boolean;
  recentRejectionCount: number;
  riskSeverity: 'CRITICAL' | 'WARNING' | 'HEALTHY';
  riskReasons: string[];
}

// 기본 데모 컨설팅 고객 (데이터가 비어있을 때 실무자가 바로 쥐고 흔들 수 있도록 제공)
const INITIAL_DEMO_CLIENTS: EnrichedConsultantClient[] = [
  {
    id: 'demo-1',
    displayId: 'C20260001',
    ceoName: '박준형',
    businessName: '(주)한국정밀가공',
    industry: '정밀기계제조업',
    province: '경기 안산',
    openDate: '2021-04-10',
    creditScore: 810,
    creditGrade: '3등급',
    vatRevenue: 340000000,
    totalDebt: 95000000,
    activePolicies: ['중진공 제조혁신자금 (5,000만원)'],
    isTaxArrears: false,
    isOverdue: false,
    isCapitalImpairment: false,
    hasHighCardLoan: false,
    recentRejectionCount: 0,
    riskSeverity: 'HEALTHY',
    riskReasons: ['주요 심사 결격 사유 없음 (양호)']
  },
  {
    id: 'demo-2',
    displayId: 'C20260002',
    ceoName: '이선영',
    businessName: '을지로골목식당',
    industry: '일반음식점업',
    province: '서울 중구',
    openDate: '2019-08-15',
    creditScore: 685,
    creditGrade: '6등급',
    vatRevenue: 125000000,
    totalDebt: 82000000,
    activePolicies: ['신보 특례보증 (2,000만원)'],
    isTaxArrears: true, // 국세 체납 감지
    isOverdue: false,
    isCapitalImpairment: false,
    hasHighCardLoan: true, // 카드론 과다
    recentRejectionCount: 1,
    riskSeverity: 'CRITICAL',
    riskReasons: ['국세 체납 내역 존재 (납세증명 발급 불가)', '2금융 카드론/대부업 잔액 3,500만원 초과']
  },
  {
    id: 'demo-3',
    displayId: 'C20260003',
    ceoName: '김태우',
    businessName: '넥스트소프트랩',
    industry: '소프트웨어 개발',
    province: '경기 성남 판교',
    openDate: '2023-11-01',
    creditScore: 745,
    creditGrade: '4등급',
    vatRevenue: 85000000,
    totalDebt: 30000000,
    activePolicies: [],
    isTaxArrears: false,
    isOverdue: false,
    isCapitalImpairment: true, // 자본잠식 주의
    hasHighCardLoan: false,
    recentRejectionCount: 0,
    riskSeverity: 'WARNING',
    riskReasons: ['초기 R&D 누적 손실로 인한 부분 자본잠식 우려']
  },
  {
    id: 'demo-4',
    displayId: 'C20260004',
    ceoName: '정명자',
    businessName: '성동물류유통',
    industry: '도소매/물류',
    province: '서울 성동구',
    openDate: '2017-02-20',
    creditScore: 620,
    creditGrade: '7등급',
    vatRevenue: 410000000,
    totalDebt: 210000000,
    activePolicies: ['소진공 일반경영안정 (4,000만원)'],
    isTaxArrears: false,
    isOverdue: true, // 최근 연체 이력
    isCapitalImpairment: false,
    hasHighCardLoan: true,
    recentRejectionCount: 2,
    riskSeverity: 'CRITICAL',
    riskReasons: ['최근 90일 이내 단기 연체 이력 감지', '최근 6개월 내 보증재단 2회 부결']
  }
];

export const ConsultantDashboard: React.FC = () => {
  const [clients, setClients] = useState<EnrichedConsultantClient[]>(INITIAL_DEMO_CLIENTS);
  const [selectedClient, setSelectedClient] = useState<EnrichedConsultantClient>(INITIAL_DEMO_CLIENTS[0]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRisk, setFilterRisk] = useState<'ALL' | 'CRITICAL' | 'WARNING' | 'HEALTHY'>('ALL');
  
  // 샌드박스 가상 시뮬레이션 상태
  const [simRevenueDeltaPercent, setSimRevenueDeltaPercent] = useState<number>(15); // 가결산 매출 변동 +15%
  const [simCreditBoost, setSimCreditBoost] = useState<number>(40); // 신용점수 상승 가상 +40점
  const [simDebtRepayment, setSimDebtRepayment] = useState<number>(20000000); // 부채 2,000만원 상환 가정
  const [isSimulating, setIsSimulating] = useState(false);
  const [simResult, setSimResult] = useState<any>(null);

  // 원클릭 리포트 발급 모달
  const [showReportModal, setShowReportModal] = useState(false);
  const [reportNotes, setReportNotes] = useState(
    '대표자 면담 결과, 최근 부채 상환 계획이 구체적이며 매출 회복세에 진입함. 1차 소진공 직접대출 신청 후 2차 재단 대환 특례보증 순차 진행 추천.'
  );
  const [reportType, setReportType] = useState<'BANK_SUBMISSION' | 'CLIENT_BRIEFING'>('BANK_SUBMISSION');
  const [isReportSaved, setIsReportSaved] = useState(false);

  // 고객 목록 필터링
  const filteredClients = useMemo(() => {
    return clients.filter(c => {
      const matchesSearch = c.businessName.includes(searchTerm) || c.ceoName.includes(searchTerm) || c.displayId.includes(searchTerm);
      const matchesRisk = filterRisk === 'ALL' || c.riskSeverity === filterRisk;
      return matchesSearch && matchesRisk;
    });
  }, [clients, searchTerm, filterRisk]);

  // 가상 샌드박스 즉시 재계산
  const handleRecalculateSandbox = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const baseScore = selectedClient.creditScore;
      const newScore = Math.min(1000, baseScore + simCreditBoost);
      const newRevenue = Math.round(selectedClient.vatRevenue * (1 + simRevenueDeltaPercent / 100));
      const newDebt = Math.max(0, selectedClient.totalDebt - simDebtRepayment);

      // 모의 승인 가능성 산출
      let approvalLikelihood = '높음 (High)';
      let badgeColor = 'text-emerald-700 bg-emerald-50 border-emerald-200';
      let expectedLimit = 70000000;
      let expectedRate = '3.2% (기준 + 0.4%p)';

      if (newScore < 650 || selectedClient.isTaxArrears) {
        approvalLikelihood = '주의/보완 요망';
        badgeColor = 'text-rose-700 bg-rose-50 border-rose-200';
        expectedLimit = 20000000;
        expectedRate = '4.8%';
      } else if (newScore < 750) {
        approvalLikelihood = '보통 (Moderate)';
        badgeColor = 'text-amber-700 bg-amber-50 border-amber-200';
        expectedLimit = 40000000;
        expectedRate = '3.9%';
      }

      setSimResult({
        simulatedScore: newScore,
        simulatedRevenue: newRevenue,
        simulatedDebt: newDebt,
        approvalLikelihood,
        badgeColor,
        expectedLimit,
        expectedRate,
        recommendedFunds: [
          { name: '소진공 신용취약소상공인 특별자금 (직접대출)', limit: '3,000만원', rate: '정책기준 + 1.6%p' },
          { name: '지역신용보증재단 저금리 대환 특례보증', limit: '5,000만원', rate: '연 4.5% 고정' },
          { name: '중진공 성장유망 청년소상공인 융자', limit: '7,000만원', rate: '정책기준금리' }
        ]
      });
      setIsSimulating(false);
    }, 600);
  };

  useEffect(() => {
    handleRecalculateSandbox();
  }, [selectedClient, simRevenueDeltaPercent, simCreditBoost, simDebtRepayment]);

  // 원클릭 리포트 발급 및 백업 저장
  const handleSaveAndPrintReport = () => {
    setIsReportSaved(true);
    setTimeout(() => {
      window.print();
      setIsReportSaved(false);
    }, 400);
  };

  return (
    <div className="space-y-8 animate-fade-in pb-16">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="w-2.5 h-2.5 rounded-full bg-indigo-600" />
            <span className="text-xs font-black text-indigo-600 tracking-wider uppercase">B2B Consultant CRM</span>
          </div>
          <h2 className="text-2xl font-black text-slate-900 flex items-center gap-2.5">
            <Users className="w-6 h-6 text-indigo-600" />
            통합 고객 심사 대시보드 & 샌드박스 시뮬레이터
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            신용점수, 체납·연체 결격사유 즉각 경고, 가상 가결산/신용도 시나리오 재계산 및 원클릭 리포트 발급
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => setShowReportModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black transition-all shadow-sm hover:shadow cursor-pointer active:scale-95"
          >
            <FileText className="w-4 h-4" />
            <span>원클릭 리포트 발급 (PDF)</span>
          </button>
        </div>
      </div>

      {/* 1. 고밀도 통합 고객 심사 그리드 (Grid View) + 시각적 경고 시스템 */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden">
        {/* 검색 & 필터 바 */}
        <div className="p-4 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50">
          <div className="relative flex-1 min-w-[240px] max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input 
              type="text"
              placeholder="상호명, 대표자명, 고객 ID 검색..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
            />
          </div>

          <div className="flex items-center gap-1.5">
            <span className="text-xs font-bold text-slate-500 mr-1">결격 경고 필터:</span>
            {(['ALL', 'CRITICAL', 'WARNING', 'HEALTHY'] as const).map(rk => (
              <button
                key={rk}
                type="button"
                onClick={() => setFilterRisk(rk)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  filterRisk === rk 
                    ? rk === 'CRITICAL' ? 'bg-rose-600 text-white shadow-xs' :
                      rk === 'WARNING' ? 'bg-amber-500 text-white shadow-xs' :
                      rk === 'HEALTHY' ? 'bg-emerald-600 text-white shadow-xs' :
                      'bg-slate-900 text-white shadow-xs'
                    : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                }`}
              >
                {rk === 'ALL' ? '전체' :
                 rk === 'CRITICAL' ? '🚨 결격 경고' :
                 rk === 'WARNING' ? '⚠️ 주의 감지' : '정상'}
              </button>
            ))}
          </div>
        </div>

        {/* 고밀도 테이블 */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50/80 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider">
                <th className="p-3.5">고객 ID</th>
                <th className="p-3.5">상호 / 대표자</th>
                <th className="p-3.5">업종 / 지역</th>
                <th className="p-3.5">신용점수 (NICE/KCB)</th>
                <th className="p-3.5">부가세 연매출</th>
                <th className="p-3.5">기대출 총액</th>
                <th className="p-3.5">이용 중인 정책자금</th>
                <th className="p-3.5 text-center">결격사유 시각적 경고</th>
                <th className="p-3.5 text-right">상세/시뮬</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {filteredClients.map(client => {
                const isSelected = selectedClient.id === client.id;
                return (
                  <tr 
                    key={client.id}
                    onClick={() => setSelectedClient(client)}
                    className={`cursor-pointer transition-colors ${
                      isSelected ? 'bg-indigo-50/70 font-semibold' : 'hover:bg-slate-50/60'
                    }`}
                  >
                    <td className="p-3.5 font-mono text-[11px] font-bold text-slate-500">{client.displayId}</td>
                    <td className="p-3.5">
                      <div className="font-black text-slate-900 text-xs">{client.businessName}</div>
                      <div className="text-[11px] text-slate-500">{client.ceoName} 대표</div>
                    </td>
                    <td className="p-3.5">
                      <div>{client.industry}</div>
                      <div className="text-[11px] text-slate-400">{client.province}</div>
                    </td>
                    <td className="p-3.5">
                      <span className={`px-2 py-0.5 rounded-md font-black text-xs ${
                        client.creditScore >= 750 ? 'bg-emerald-100 text-emerald-800' :
                        client.creditScore >= 650 ? 'bg-amber-100 text-amber-800' :
                        'bg-rose-100 text-rose-800'
                      }`}>
                        {client.creditScore}점 ({client.creditGrade})
                      </span>
                    </td>
                    <td className="p-3.5 font-bold text-slate-900">
                      {formatKoreanMoney(client.vatRevenue)}
                    </td>
                    <td className="p-3.5 font-bold text-slate-600">
                      {formatKoreanMoney(client.totalDebt)}
                    </td>
                    <td className="p-3.5">
                      {client.activePolicies.length > 0 ? (
                        <div className="space-y-1">
                          {client.activePolicies.map((p, idx) => (
                            <span key={idx} className="block text-[11px] text-indigo-700 bg-indigo-50/80 px-2 py-0.5 rounded font-bold truncate max-w-[160px]">
                              {p}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <span className="text-[11px] text-slate-400">없음</span>
                      )}
                    </td>

                    {/* 시각적 경고 시스템 (Visual Warning System) */}
                    <td className="p-3.5 text-center">
                      {client.riskSeverity === 'CRITICAL' && (
                        <div className="inline-flex items-center gap-1 px-2.5 py-1 bg-rose-50 border border-rose-200 text-rose-700 rounded-full font-black text-[11px] shadow-2xs">
                          <AlertOctagon className="w-3.5 h-3.5 text-rose-600 shrink-0" />
                          <span>결격 사유 경고</span>
                        </div>
                      )}
                      {client.riskSeverity === 'WARNING' && (
                        <div className="inline-flex items-center gap-1 px-2.5 py-1 bg-amber-50 border border-amber-200 text-amber-800 rounded-full font-black text-[11px]">
                          <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                          <span>주의 관찰</span>
                        </div>
                      )}
                      {client.riskSeverity === 'HEALTHY' && (
                        <div className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-full font-bold text-[11px]">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>정상 적격</span>
                        </div>
                      )}
                    </td>

                    <td className="p-3.5 text-right">
                      <span className={`inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-lg transition-all ${
                        isSelected ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-700'
                      }`}>
                        선택됨
                        <ChevronRight className="w-3.5 h-3.5" />
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* 선택된 고객의 결격 사유 알림 뱃지 안내 바 */}
        {selectedClient.riskSeverity !== 'HEALTHY' && (
          <div className="p-4 bg-rose-50/70 border-t border-rose-100 flex items-start gap-3">
            <div className="p-1.5 bg-rose-100 text-rose-700 rounded-lg shrink-0 mt-0.5">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-black text-rose-800">
                  [{selectedClient.businessName}] 심사관 즉각 주의 경고 시스템 발령
                </span>
                <span className="text-[10px] bg-rose-200 text-rose-900 px-1.5 py-0.5 rounded font-bold">
                  {selectedClient.riskSeverity === 'CRITICAL' ? '치명적 결격 사유' : '주의 검토'}
                </span>
              </div>
              <ul className="mt-1 space-y-0.5">
                {selectedClient.riskReasons.map((r, i) => (
                  <li key={i} className="text-xs text-rose-700 font-medium list-disc list-inside">
                    {r}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}
      </div>

      {/* 2. 가상 시뮬레이션 모드 (Sandbox) - Dual Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* 왼쪽: 가상 시나리오 튜닝 컨트롤 (가결산 추정, 신용점수 변동 등) */}
        <div className="lg:col-span-5 bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 space-y-5">
          <div className="border-b border-slate-100 pb-3">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-indigo-600" />
                가상 시뮬레이션 샌드박스
              </h3>
              <span className="text-[10px] font-black px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded-full border border-indigo-200">
                실시간 Recalculate
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              현재 선택된 <strong className="text-slate-800">{selectedClient.businessName}</strong>의 재무·신용 개선 시나리오를 적용해 승인 변동을 테스트합니다.
            </p>
          </div>

          {/* 슬라이더 1: 가결산 매출 변동율 */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700">가결산 추정 매출 변동율</label>
              <span className={`text-xs font-black px-2 py-0.5 rounded ${
                simRevenueDeltaPercent >= 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
              }`}>
                {simRevenueDeltaPercent >= 0 ? `+${simRevenueDeltaPercent}%` : `${simRevenueDeltaPercent}%`}
              </span>
            </div>
            <input 
              type="range"
              min="-40"
              max="60"
              step="5"
              value={simRevenueDeltaPercent}
              onChange={e => setSimRevenueDeltaPercent(Number(e.target.value))}
              className="w-full accent-indigo-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>기존: {formatKoreanMoney(selectedClient.vatRevenue)}</span>
              <span className="font-bold text-indigo-600">
                시뮬레이션: {formatKoreanMoney(Math.round(selectedClient.vatRevenue * (1 + simRevenueDeltaPercent / 100)))}
              </span>
            </div>
          </div>

          {/* 슬라이더 2: 신용점수 상승 가정 */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700">신용점수 회복/상승 가정</label>
              <span className="text-xs font-black text-blue-700 bg-blue-100 px-2 py-0.5 rounded">
                +{simCreditBoost} 점 상승
              </span>
            </div>
            <input 
              type="range"
              min="0"
              max="150"
              step="10"
              value={simCreditBoost}
              onChange={e => setSimCreditBoost(Number(e.target.value))}
              className="w-full accent-blue-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>기존: {selectedClient.creditScore}점</span>
              <span className="font-bold text-blue-600">
                목표치: {Math.min(1000, selectedClient.creditScore + simCreditBoost)}점
              </span>
            </div>
          </div>

          {/* 슬라이더 3: 고금리 채무 상환/대환 규모 */}
          <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/80">
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700">카드론/고금리 대출 선제 상환액</label>
              <span className="text-xs font-black text-purple-700 bg-purple-100 px-2 py-0.5 rounded">
                {formatKoreanMoney(simDebtRepayment)}
              </span>
            </div>
            <input 
              type="range"
              min="0"
              max={Math.max(50000000, selectedClient.totalDebt)}
              step="5000000"
              value={simDebtRepayment}
              onChange={e => setSimDebtRepayment(Number(e.target.value))}
              className="w-full accent-purple-600 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>기존 총부채: {formatKoreanMoney(selectedClient.totalDebt)}</span>
              <span className="font-bold text-purple-600">
                상환 후: {formatKoreanMoney(Math.max(0, selectedClient.totalDebt - simDebtRepayment))}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={handleRecalculateSandbox}
            disabled={isSimulating}
            className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSimulating ? 'animate-spin' : ''}`} />
            <span>{isSimulating ? '시뮬레이션 재계산 중...' : '즉시 재계산 (Recalculate)'}</span>
          </button>
        </div>

        {/* 오른쪽: 샌드박스 결과 리포트 패널 (Before vs After) */}
        <div className="lg:col-span-7 bg-white rounded-2xl border border-slate-200 shadow-2xs p-5 flex flex-col justify-between space-y-5">
          <div className="space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  시뮬레이션 승인 변동 예측 결과
                </h3>
                <span className="text-xs text-slate-400">
                  신용 회복 및 가결산 시나리오 적용 시 금융기관 예상 심사 결과
                </span>
              </div>
              {simResult && (
                <span className={`px-3 py-1 rounded-full text-xs font-black border ${simResult.badgeColor}`}>
                  {simResult.approvalLikelihood}
                </span>
              )}
            </div>

            {/* Before vs After 카드 */}
            {simResult && (
              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/70">
                  <span className="text-[11px] font-bold text-slate-400 uppercase">현재 상태 (Before)</span>
                  <div className="mt-2 space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-500">신용점수:</span>
                      <strong className="text-slate-800">{selectedClient.creditScore}점</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">연매출:</span>
                      <strong className="text-slate-800">{formatKoreanMoney(selectedClient.vatRevenue)}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">기대출:</span>
                      <strong className="text-slate-800">{formatKoreanMoney(selectedClient.totalDebt)}</strong>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-indigo-50/50 border border-indigo-200/80">
                  <span className="text-[11px] font-black text-indigo-600 uppercase">시뮬레이션 결과 (After)</span>
                  <div className="mt-2 space-y-1.5 text-xs">
                    <div className="flex justify-between">
                      <span className="text-slate-500">예상 신용:</span>
                      <strong className="text-indigo-700 font-black">{simResult.simulatedScore}점 (+{simCreditBoost})</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">가결산 매출:</span>
                      <strong className="text-indigo-700 font-black">{formatKoreanMoney(simResult.simulatedRevenue)}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">추정 총한도:</span>
                      <strong className="text-emerald-700 font-black">{formatKoreanMoney(simResult.expectedLimit)}</strong>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* 추천 타겟 정책자금 목록 */}
            {simResult && (
              <div>
                <h4 className="text-xs font-black text-slate-800 mb-2 flex items-center gap-1.5">
                  <Building2 className="w-3.5 h-3.5 text-indigo-600" />
                  타겟 정책자금 시뮬레이션 매칭
                </h4>
                <div className="space-y-2">
                  {simResult.recommendedFunds.map((f: any, i: number) => (
                    <div key={i} className="p-3 bg-slate-50/90 rounded-xl border border-slate-200/80 flex items-center justify-between text-xs">
                      <div>
                        <span className="font-black text-slate-800">{f.name}</span>
                        <div className="text-[11px] text-slate-500 mt-0.5">예상 금리: {f.rate}</div>
                      </div>
                      <div className="text-right">
                        <span className="font-black text-indigo-700 text-sm">{f.limit}</span>
                        <span className="block text-[10px] text-emerald-600 font-bold">승인 유력</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">
              * 본 시뮬레이션은 내부 자문위원 검토용으로 산출된 예측치입니다.
            </span>
            <button
              type="button"
              onClick={() => setShowReportModal(true)}
              className="flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>본 시뮬레이션 결과로 리포트 생성</span>
            </button>
          </div>
        </div>
      </div>

      {/* 3. 원클릭 리포트 발급 모달 (금융기관 제출용 / 고객 브리핑용) */}
      {showReportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-2xl w-full shadow-2xl border border-slate-100 max-h-[90vh] overflow-y-auto animate-slide-up">
            <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-4">
              <div>
                <span className="text-xs font-black text-indigo-600 uppercase">Consulting Report Generator</span>
                <h3 className="text-xl font-black text-slate-900">
                  정책자금 심층 진단 & 컨설팅 종합 리포트
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowReportModal(false)}
                className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg"
              >
                ✕
              </button>
            </div>

            {/* 리포트 유형 선택 */}
            <div className="flex gap-3 mb-4">
              <button
                type="button"
                onClick={() => setReportType('BANK_SUBMISSION')}
                className={`flex-1 p-3 rounded-xl border text-left transition-all ${
                  reportType === 'BANK_SUBMISSION'
                    ? 'border-indigo-600 bg-indigo-50/50 text-indigo-900 font-bold'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <div className="text-xs font-black">금융기관 제출용 심층 보고서</div>
                <div className="text-[11px] text-slate-500 mt-0.5">소진공·보증재단 심사관 제출 규격</div>
              </button>
              <button
                type="button"
                onClick={() => setReportType('CLIENT_BRIEFING')}
                className={`flex-1 p-3 rounded-xl border text-left transition-all ${
                  reportType === 'CLIENT_BRIEFING'
                    ? 'border-indigo-600 bg-indigo-50/50 text-indigo-900 font-bold'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <div className="text-xs font-black">고객 브리핑용 맞춤 진단서</div>
                <div className="text-[11px] text-slate-500 mt-0.5">대표자 맞춤 한도·금리 로드맵</div>
              </button>
            </div>

            {/* 리포트 미리보기 본문 */}
            <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 text-xs space-y-4 font-sans text-slate-800">
              <div className="flex justify-between items-start border-b border-slate-200 pb-3">
                <div>
                  <div className="text-base font-black text-slate-900">{selectedClient.businessName}</div>
                  <div className="text-slate-500">대표자: {selectedClient.ceoName} | 업종: {selectedClient.industry}</div>
                </div>
                <div className="text-right text-[11px] text-slate-400">
                  <div>문서번호: RPT-2026-{selectedClient.displayId}</div>
                  <div>발급일시: {new Date().toLocaleDateString('ko-KR')}</div>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 py-1 bg-white p-3 rounded-xl border border-slate-200/80">
                <div>
                  <span className="text-[10px] text-slate-400 font-bold">신용점수(NICE/KCB)</span>
                  <div className="text-sm font-black text-slate-900">{selectedClient.creditScore}점</div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-bold">신고 연매출</span>
                  <div className="text-sm font-black text-slate-900">{formatKoreanMoney(selectedClient.vatRevenue)}</div>
                </div>
                <div>
                  <span className="text-[10px] text-slate-400 font-bold">체납/결격 여부</span>
                  <div className={`text-sm font-black ${selectedClient.isTaxArrears ? 'text-rose-600' : 'text-emerald-600'}`}>
                    {selectedClient.isTaxArrears ? '체납 감지' : '체납 없음(양호)'}
                  </div>
                </div>
              </div>

              {/* 자문위원 특이사항 및 종합 의견 */}
              <div>
                <label className="block text-xs font-black text-slate-700 mb-1.5">
                  전문 자문위원 심사 특이사항 및 소견 (직접 편집 가능)
                </label>
                <textarea
                  rows={4}
                  value={reportNotes}
                  onChange={e => setReportNotes(e.target.value)}
                  className="w-full p-3 bg-white border border-slate-200 rounded-xl text-xs font-medium focus:border-indigo-500 focus:outline-none"
                  placeholder="특이사항 및 실행 로드맵 작성..."
                />
              </div>

              <div className="p-3 bg-indigo-50/70 border border-indigo-200/80 rounded-xl">
                <span className="font-bold text-indigo-900 block mb-1">매칭 추천 솔루션:</span>
                <span className="text-indigo-800">
                  1순위 소진공 신용취약자금(3,000만원) 직대 접수 → 2순위 지역보증재단 대환 특례보증(5,000만원) 약정 진행
                </span>
              </div>
            </div>

            <div className="flex items-center justify-between mt-6 pt-4 border-t border-slate-100">
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                <span>클라우드 Vault 자동 백업 폴더 연동됨</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowReportModal(false)}
                  className="px-4 py-2 text-slate-600 font-bold text-xs hover:bg-slate-100 rounded-xl"
                >
                  취소
                </button>
                <button
                  type="button"
                  onClick={handleSaveAndPrintReport}
                  className="flex items-center gap-1.5 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black transition-all shadow-sm cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>{isReportSaved ? '백업 및 인쇄 준비 중...' : '원클릭 PDF 발급 및 백업'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
