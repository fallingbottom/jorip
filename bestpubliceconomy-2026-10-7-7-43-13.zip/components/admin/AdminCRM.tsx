import React, { useState, useEffect } from 'react';
import { Users, BarChart3, LogOut, Activity, Server, Sliders, ShieldCheck, Briefcase, FileCode2, ArrowLeft, KeyRound, Menu, X } from 'lucide-react';
import { CustomerList } from './CustomerList';
import { CustomerDetail } from './CustomerDetail';
import { AdminDashboardStats } from './AdminDashboardStats';
import { ConsultantDashboard } from './ConsultantDashboard';
import { PipelineMonitorBoard } from './PipelineMonitorBoard';
import { AnnouncementCurationManager } from './AnnouncementCurationManager';
import { AdminAccessSettings } from './AdminAccessSettings';
import { MatchingEngineTuningPanel } from './MatchingEngineTuningPanel';
import { logout } from '../../services/firebaseService';
import { getCurrentAdminSession, clearAdminSession, AdminUser } from '../../services/adminAuthService';

interface AdminCRMProps {
  onExitToMainApp?: () => void;
}

export const AdminCRM: React.FC<AdminCRMProps> = ({ onExitToMainApp }) => {
  const [activeTab, setActiveTab] = useState<'consultant' | 'customers' | 'tuning' | 'announcements' | 'pipeline' | 'dashboard' | 'access'>('consultant');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [currentAdmin, setCurrentAdmin] = useState<AdminUser | null>(getCurrentAdminSession());
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    setCurrentAdmin(getCurrentAdminSession());
  }, []);

  const handleLogout = async () => {
    clearAdminSession();
    await logout();
    if (onExitToMainApp) {
      onExitToMainApp();
    } else {
      window.location.reload();
    }
  };

  const handleTabClick = (tab: typeof activeTab) => {
    setActiveTab(tab);
    setSelectedCustomerId(null);
    setIsMobileMenuOpen(false); // Close menu on mobile when a tab is clicked
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row overflow-hidden relative">
      {/* Mobile Topbar */}
      <div className="md:hidden bg-slate-900 text-white flex items-center justify-between p-4 shrink-0 z-40">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-indigo-400" />
          <h1 className="font-black text-lg">BizMatch Pro</h1>
        </div>
        <button 
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 bg-slate-800 rounded-lg text-slate-300 hover:text-white transition-colors"
        >
          {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-40 md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-slate-900 text-slate-300 flex flex-col shrink-0 transform transition-transform duration-300 ease-in-out md:relative md:translate-x-0 ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-5 border-b border-slate-800/80 hidden md:block">
          {onExitToMainApp && (
            <button
              onClick={onExitToMainApp}
              className="mb-3 inline-flex items-center gap-1.5 text-xs text-indigo-300 hover:text-white font-bold transition-colors py-1 px-2.5 rounded-lg bg-indigo-950/60 hover:bg-indigo-900 border border-indigo-800/50 w-full"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>사용자 화면으로 복귀</span>
            </button>
          )}
          <h1 className="text-white font-black text-xl flex items-center gap-2">
            <Activity className="w-6 h-6 text-indigo-400" />
            BizMatch Pro
          </h1>
          <p className="text-xs text-slate-400 mt-1">B2B 컨설팅 & 관리자 관제센터</p>
        </div>

        {/* Persona Categories */}
        <div className="px-4 pt-4 pb-1 mt-4 md:mt-0">
          <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-2 px-2">
            컨설팅용 B2B 워크스페이스
          </span>
        </div>
        <nav className="px-3 space-y-1">
          <button
            onClick={() => handleTabClick('consultant')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-all font-bold text-xs ${
              activeTab === 'consultant' ? 'bg-indigo-600 text-white shadow-sm' : 'hover:bg-slate-800 hover:text-white text-slate-400'
            }`}
          >
            <Briefcase className="w-4 h-4 text-indigo-400" />
            <span>통합 심사 & 샌드박스</span>
          </button>
          <button
            onClick={() => handleTabClick('customers')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-all font-bold text-xs ${
              activeTab === 'customers' ? 'bg-indigo-600 text-white shadow-sm' : 'hover:bg-slate-800 hover:text-white text-slate-400'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>고객 DB 관리</span>
          </button>
        </nav>

        <div className="px-4 pt-6 pb-1">
          <span className="text-[10px] font-black text-slate-500 uppercase tracking-wider block mb-2 px-2">
            개발자 & 관리자 관제탑
          </span>
        </div>
        <nav className="px-3 space-y-1 overflow-y-auto flex-1">
          <button
            onClick={() => handleTabClick('announcements')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all font-bold text-xs ${
              activeTab === 'announcements' ? 'bg-indigo-600 text-white shadow-sm' : 'hover:bg-slate-800 hover:text-white text-slate-400'
            }`}
          >
            <div className="flex items-center gap-3">
              <FileCode2 className="w-4 h-4 text-indigo-400" />
              <span>공고 수집·검수 관리</span>
            </div>
            <span className="px-1.5 py-0.5 text-[9px] font-black rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
              v0.4
            </span>
          </button>
          <button
            onClick={() => handleTabClick('tuning')}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all font-bold text-xs ${
              activeTab === 'tuning' ? 'bg-indigo-600 text-white shadow-sm' : 'hover:bg-slate-800 hover:text-white text-slate-400'
            }`}
          >
            <div className="flex items-center gap-3">
              <Sliders className="w-4 h-4 text-amber-400" />
              <span>매칭 엔진 튜닝 모드</span>
            </div>
            <span className="px-1.5 py-0.5 text-[9px] font-black rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
              AI 튜닝
            </span>
          </button>
          <button
            onClick={() => handleTabClick('pipeline')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-all font-bold text-xs ${
              activeTab === 'pipeline' ? 'bg-indigo-600 text-white shadow-sm' : 'hover:bg-slate-800 hover:text-white text-slate-400'
            }`}
          >
            <Server className="w-4 h-4 text-emerald-400" />
            <span>파이프라인 & 알고리즘</span>
          </button>
          <button
            onClick={() => handleTabClick('dashboard')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-all font-bold text-xs ${
              activeTab === 'dashboard' ? 'bg-indigo-600 text-white shadow-sm' : 'hover:bg-slate-800 hover:text-white text-slate-400'
            }`}
          >
            <BarChart3 className="w-4 h-4" />
            <span>운영 대시보드 통계</span>
          </button>
          <button
            onClick={() => handleTabClick('access')}
            className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl transition-all font-bold text-xs ${
              activeTab === 'access' ? 'bg-indigo-600 text-white shadow-sm' : 'hover:bg-slate-800 hover:text-white text-slate-400'
            }`}
          >
            <KeyRound className="w-4 h-4 text-amber-400" />
            <span>접근권한 설정 & 보안</span>
          </button>
        </nav>

        <div className="mt-auto p-4 border-t border-slate-800 shrink-0 bg-slate-900">
          <div className="px-3 py-2 bg-slate-800/60 rounded-xl mb-3 border border-slate-800">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span className="text-[11px] font-bold text-slate-300">
                {currentAdmin?.name || '관리자 인증 세션'}
              </span>
            </div>
            <span className="text-[10px] text-slate-500 block mt-0.5 truncate">
              {currentAdmin?.email || 'fujinilove@gmail.com'}
            </span>
          </div>
          <button
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-all font-bold text-xs"
          >
            <LogOut className="w-4 h-4" />
            로그아웃
          </button>
          
          {onExitToMainApp && (
            <button
              onClick={onExitToMainApp}
              className="mt-3 md:hidden flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-indigo-300 hover:text-white bg-indigo-950/60 hover:bg-indigo-900 border border-indigo-800/50 transition-all font-bold text-xs w-full"
            >
              <ArrowLeft className="w-4 h-4" />
              사용자 화면으로 복귀
            </button>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto bg-slate-50 relative z-0 h-[calc(100vh-60px)] md:h-screen w-full">
        <div className="p-4 md:p-6 lg:p-8 max-w-7xl mx-auto pb-24">
          {activeTab === 'consultant' && <ConsultantDashboard />}
          {activeTab === 'tuning' && <MatchingEngineTuningPanel />}
          {activeTab === 'announcements' && <AnnouncementCurationManager />}
          {activeTab === 'pipeline' && <PipelineMonitorBoard />}
          {activeTab === 'dashboard' && <AdminDashboardStats />}
          {activeTab === 'access' && <AdminAccessSettings />}
          {activeTab === 'customers' && !selectedCustomerId && (
            <CustomerList onSelectCustomer={setSelectedCustomerId} />
          )}
          {activeTab === 'customers' && selectedCustomerId && (
            <CustomerDetail 
              customerId={selectedCustomerId} 
              onBack={() => setSelectedCustomerId(null)} 
            />
          )}
        </div>
      </main>
    </div>
  );
};

