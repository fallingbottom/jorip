import React, { useState, useEffect, useMemo, useRef } from 'react';
import { PolicyFund, UserProfile, FundPdfAnalysis, ChecklistItem } from '../types';
import { analyzeFundPdfChecklist } from '../services/geminiService';
import { matchDocumentToIssuanceInfo } from '../src/utils/documentIssuanceMap';
import {
  X,
  FileText,
  CheckCircle2,
  AlertTriangle,
  Sparkles,
  Upload,
  Printer,
  Calendar,
  Building2,
  Layers,
  HelpCircle,
  ExternalLink,
  Phone,
  Clock,
  ShieldCheck,
  Award,
  AlertCircle,
  ArrowRight,
  RefreshCw,
  Copy,
  Check,
  FileCheck2,
  ChevronRight,
  Download,
  Info
} from 'lucide-react';

interface FundPdfChecklistModalProps {
  isOpen: boolean;
  onClose: () => void;
  fund: PolicyFund | null;
  profile?: UserProfile | null;
}

export const FundPdfChecklistModal: React.FC<FundPdfChecklistModalProps> = ({
  isOpen,
  onClose,
  fund,
  profile,
}) => {
  const [analysis, setAnalysis] = useState<FundPdfAnalysis | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isUploadingPdf, setIsUploadingPdf] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [checkedIds, setCheckedIds] = useState<Record<string, boolean>>({});
  const [activeTab, setActiveTab] = useState<'ALL' | 'ELIGIBILITY' | 'DOCUMENTS' | 'BONUS_RISKS' | 'ROADMAP'>('ALL');
  const [copiedLink, setCopiedLink] = useState(false);
  const [customFileName, setCustomFileName] = useState<string | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const storageKey = useMemo(() => {
    if (!fund) return '';
    return `bizmatch_checklist_v2_${fund.id || fund.title}`;
  }, [fund]);

  // Load analysis when modal opens or fund changes
  useEffect(() => {
    if (!isOpen || !fund) return;

    let isMounted = true;
    setIsLoading(true);
    setError(null);
    setCustomFileName(null);

    // Load saved checklist states
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        setCheckedIds(JSON.parse(saved));
      } else {
        setCheckedIds({});
      }
    } catch {
      setCheckedIds({});
    }

    analyzeFundPdfChecklist(fund, profile)
      .then((res) => {
        if (isMounted) {
          setAnalysis(res);
          setIsLoading(false);
        }
      })
      .catch((err) => {
        if (isMounted) {
          console.error('Error analyzing fund PDF checklist:', err);
          setError('원문 공고 분석 중 문제가 발생했습니다. 다시 시도해 주세요.');
          setIsLoading(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen, fund, profile, storageKey]);

  // Handle custom PDF upload for deeper analysis
  const handleCustomPdfUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !fund) return;

    setIsUploadingPdf(true);
    setError(null);
    setCustomFileName(file.name);

    try {
      const customAnalysis = await analyzeFundPdfChecklist(fund, profile, file);
      setAnalysis(customAnalysis);
    } catch (err: any) {
      console.error('Custom PDF upload analysis error:', err);
      setError(err?.message || '공고문 파일 분석 중 오류가 발생했습니다.');
    } finally {
      setIsUploadingPdf(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleToggleCheck = (id: string) => {
    setCheckedIds((prev) => {
      const updated = { ...prev, [id]: !prev[id] };
      try {
        localStorage.setItem(storageKey, JSON.stringify(updated));
      } catch (err) {
        console.warn('Failed to save checklist state', err);
      }
      return updated;
    });
  };

  const handleResetChecklist = () => {
    setCheckedIds({});
    try {
      localStorage.removeItem(storageKey);
    } catch (err) {
      console.warn('Failed to remove checklist state', err);
    }
  };

  // Calculate completion stats
  const stats = useMemo(() => {
    if (!analysis) return { total: 0, checked: 0, percent: 0, docsChecked: 0, docsTotal: 0 };

    const allItems = [...analysis.eligibilityChecklist, ...analysis.documentChecklist];
    const total = allItems.length;
    const checked = allItems.filter((i) => !!checkedIds[i.id]).length;
    const percent = total > 0 ? Math.round((checked / total) * 100) : 0;

    const docsTotal = analysis.documentChecklist.length;
    const docsChecked = analysis.documentChecklist.filter((i) => !!checkedIds[i.id]).length;

    return { total, checked, percent, docsChecked, docsTotal };
  }, [analysis, checkedIds]);

  const handlePrint = () => {
    window.print();
  };

  const handleCopyChecklistText = () => {
    if (!analysis || !fund) return;
    let text = `[${fund.title} - 핵심 체크리스트]\n주관: ${fund.agency} | 한도: ${fund.maxAmount} | 금리: ${fund.interestRate}\n\n`;
    text += `■ 필수 자격요건 점검:\n`;
    analysis.eligibilityChecklist.forEach((item) => {
      text += `${checkedIds[item.id] ? '[V]' : '[ ]'} ${item.title}: ${item.description}\n`;
    });
    text += `\n■ 필수 준비 서류 목록:\n`;
    analysis.documentChecklist.forEach((doc) => {
      text += `${checkedIds[doc.id] ? '[V]' : '[ ]'} ${doc.title} (발급처: ${doc.issuingAgency || '공공포털'})\n`;
    });
    text += `\n■ 신청 로드맵:\n`;
    analysis.applicationRoadmap.forEach((step) => {
      text += `단계 ${step.step}: ${step.title} (${step.duration}) - ${step.details}\n`;
    });

    navigator.clipboard.writeText(text);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  if (!isOpen || !fund) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6 animate-fade-in">
      <div 
        id="pdf-checklist-modal-card"
        className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[92vh] relative text-slate-900"
      >
        {/* Modal Top Header */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 text-white p-6 sm:p-7 relative flex-shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-5 right-5 w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white/80 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
            aria-label="닫기"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex flex-wrap items-center gap-2 mb-2.5">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-500/20 border border-blue-400/30 text-blue-300 text-xs font-black rounded-full">
              <FileCheck2 className="w-3.5 h-3.5" />
              <span>원문 공고문 AI 정밀 분석</span>
            </span>
            <span className="bg-white/10 text-slate-200 text-xs font-bold px-2.5 py-0.5 rounded-full">
              {fund.agency}
            </span>
            {analysis?.targetFitScore && (
              <span className="bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-black px-2.5 py-0.5 rounded-full flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-emerald-400" />
                적합도 {analysis.targetFitScore}%
              </span>
            )}
          </div>

          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight leading-snug pr-10">
            {fund.title} 핵심 체크리스트
          </h2>

          <p className="text-xs sm:text-sm text-slate-300 mt-1 font-medium">
            {analysis?.announcementTitle || `${fund.agency} 공식 시행계획 공고문`}을 기반으로 추출한 필수 자격요건 및 구비서류 체크리스트입니다.
          </p>

          {/* Quick Metrics Banner */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-5 pt-4 border-t border-white/10 text-xs">
            <div className="bg-white/5 backdrop-blur-xs p-2.5 rounded-xl border border-white/5">
              <span className="text-[10px] text-slate-400 font-bold block">최대 지원 한도</span>
              <span className="text-sm font-black text-white">{fund.maxAmount}</span>
            </div>
            <div className="bg-white/5 backdrop-blur-xs p-2.5 rounded-xl border border-white/5">
              <span className="text-[10px] text-slate-400 font-bold block">적용 예상 금리</span>
              <span className="text-sm font-black text-emerald-400">{fund.interestRate}</span>
            </div>
            <div className="bg-white/5 backdrop-blur-xs p-2.5 rounded-xl border border-white/5">
              <span className="text-[10px] text-slate-400 font-bold block">접수 마감 기한</span>
              <span className="text-sm font-bold text-slate-200 truncate block">
                {fund.applicationDeadline || '별도 공지 시'}
              </span>
            </div>
            <div className="bg-white/5 backdrop-blur-xs p-2.5 rounded-xl border border-white/5">
              <span className="text-[10px] text-slate-400 font-bold block">준비 달성률</span>
              <span className="text-sm font-black text-indigo-300">
                {stats.checked}/{stats.total} 완료 ({stats.percent}%)
              </span>
            </div>
          </div>
        </div>

        {/* Readiness Progress Bar */}
        <div className="bg-slate-50 border-b border-slate-200/80 px-6 py-3 flex flex-wrap items-center justify-between gap-3 flex-shrink-0">
          <div className="flex items-center gap-3 flex-1 min-w-[200px]">
            <div className="w-8 h-8 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-black text-xs flex-shrink-0">
              {stats.percent}%
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between text-xs font-bold mb-1">
                <span className="text-slate-700">신청 서류 및 요건 준비 진행도</span>
                <span className="text-indigo-600">{stats.checked} / {stats.total} 항목 확인됨</span>
              </div>
              <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full transition-all duration-500"
                  style={{ width: `${stats.percent}%` }}
                />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleCopyChecklistText}
              className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold transition-all shadow-2xs flex items-center gap-1 cursor-pointer"
              title="텍스트로 체크리스트 복사"
            >
              {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedLink ? '복사 완료' : '체크리스트 복사'}</span>
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold transition-all shadow-2xs flex items-center gap-1 cursor-pointer"
              title="인쇄용 체크리스트 출력"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>체크리스트 인쇄</span>
            </button>
          </div>
        </div>

        {/* Modal Navigation Tabs & Custom PDF Analysis Trigger */}
        <div className="px-6 pt-3 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white flex-shrink-0">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 sm:pb-0 scrollbar-none">
            {[
              { id: 'ALL', label: '전체 요약' },
              { id: 'ELIGIBILITY', label: `자격 요건 (${analysis?.eligibilityChecklist.length || 0})` },
              { id: 'DOCUMENTS', label: `필수 서류 (${analysis?.documentChecklist.length || 0})` },
              { id: 'BONUS_RISKS', label: '가점 및 결격주의' },
              { id: 'ROADMAP', label: '신청 로드맵' },
            ].map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all cursor-pointer whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Custom PDF Upload Trigger */}
          <div className="pb-2 sm:pb-0 flex items-center gap-2">
            <input
              type="file"
              ref={fileInputRef}
              accept=".pdf,image/*"
              onChange={handleCustomPdfUpload}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploadingPdf}
              className="px-3 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
              title="보유하신 정책자금 공식 PDF 파일을 업로드하면 AI가 실시간으로 재분석합니다."
            >
              <Upload className={`w-3.5 h-3.5 ${isUploadingPdf ? 'animate-bounce' : ''}`} />
              <span>{isUploadingPdf ? 'PDF 정밀 분석 중...' : customFileName ? `재분석: ${customFileName.slice(0, 10)}...` : '내 공고문 PDF 직접 업로드'}</span>
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {isLoading || isUploadingPdf ? (
            <div className="py-16 text-center space-y-4">
              <div className="w-12 h-12 border-3 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto" />
              <div>
                <h4 className="text-base font-black text-slate-900">
                  {isUploadingPdf ? '업로드된 PDF 공고문을 정밀 분석하고 있습니다' : '공식 공고문 기준 핵심 체크리스트를 생성하는 중...'}
                </h4>
                <p className="text-xs text-slate-500 mt-1">
                  신청 자격 요건, 필수 구비서류 발급처, 심사 가점 및 탈락 위험 요소를 점검 중입니다.
                </p>
              </div>
            </div>
          ) : error ? (
            <div className="p-8 text-center bg-red-50 rounded-2xl border border-red-100">
              <AlertCircle className="w-10 h-10 text-red-500 mx-auto mb-2" />
              <h4 className="text-sm font-bold text-red-900 mb-1">분석 로드 중 문제 발생</h4>
              <p className="text-xs text-red-600 mb-4">{error}</p>
              <button
                type="button"
                onClick={() => {
                  setIsLoading(true);
                  analyzeFundPdfChecklist(fund, profile).then(setAnalysis).finally(() => setIsLoading(false));
                }}
                className="px-4 py-2 bg-red-600 text-white text-xs font-bold rounded-xl shadow-xs"
              >
                다시 시도
              </button>
            </div>
          ) : analysis ? (
            <>
              {/* Executive Summary Card */}
              {(activeTab === 'ALL' || activeTab === 'ELIGIBILITY') && (
                <div className="bg-gradient-to-r from-blue-50/90 via-indigo-50/60 to-slate-50 p-5 rounded-2xl border border-blue-100/80">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center flex-shrink-0 shadow-xs mt-0.5">
                      <Sparkles className="w-4 h-4" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="text-sm font-black text-blue-950">공고문 핵심 취지 및 맞춤 가이드</h4>
                        {analysis.extractedFromCustomPdf && (
                          <span className="text-[10px] bg-indigo-200 text-indigo-900 font-bold px-2 py-0.5 rounded-full">
                            사용자 첨부 PDF 분석본
                          </span>
                        )}
                      </div>
                      <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-medium">
                        {analysis.pdfSummary}
                      </p>
                    </div>
                  </div>

                  {/* Key Deadlines Timeline */}
                  {analysis.keyDeadlines && analysis.keyDeadlines.length > 0 && (
                    <div className="mt-4 pt-4 border-t border-blue-100/80 grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                      {analysis.keyDeadlines.map((dl, dIdx) => (
                        <div key={dIdx} className="bg-white/80 p-3 rounded-xl border border-blue-100 text-xs">
                          <span className="text-[10px] font-black text-blue-700 block mb-0.5">
                            {dl.phase}
                          </span>
                          <span className="font-bold text-slate-900 block">{dl.date}</span>
                          <span className="text-[11px] text-slate-500 mt-0.5 block leading-tight">
                            {dl.description}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Section 1: Eligibility Checklist */}
              {(activeTab === 'ALL' || activeTab === 'ELIGIBILITY') && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-blue-600" />
                      1. 핵심 자격 요건 자가진단
                    </h3>
                    <span className="text-xs text-slate-400 font-medium">
                      클릭하여 요건 충족 여부를 체크하세요
                    </span>
                  </div>

                  <div className="space-y-2.5">
                    {analysis.eligibilityChecklist.map((item) => {
                      const isChecked = !!checkedIds[item.id];
                      return (
                        <div
                          key={item.id}
                          onClick={() => handleToggleCheck(item.id)}
                          className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-start gap-3.5 ${
                            isChecked
                              ? 'bg-emerald-50/70 border-emerald-200'
                              : 'bg-white hover:bg-slate-50/80 border-slate-200'
                          }`}
                        >
                          <div className="mt-0.5 flex-shrink-0">
                            <div
                              className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all ${
                                isChecked
                                  ? 'bg-emerald-600 border-emerald-600 text-white'
                                  : 'border-slate-300 bg-white'
                              }`}
                            >
                              {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                            </div>
                          </div>

                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1 flex-wrap">
                              <span className={`text-xs font-black ${isChecked ? 'text-emerald-950 line-through opacity-80' : 'text-slate-900'}`}>
                                {item.title}
                              </span>
                              {item.priority === 'HIGH' && (
                                <span className="text-[10px] font-black bg-rose-50 text-rose-700 border border-rose-200 px-1.5 py-0.2 rounded">
                                  필수
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-slate-600 leading-relaxed font-medium">
                              {item.description}
                            </p>
                            {item.tip && (
                              <p className="text-[11px] text-blue-700 bg-blue-50/70 rounded-lg px-2.5 py-1 mt-2 inline-block font-medium border border-blue-100">
                                💡 <strong>확인 팁:</strong> {item.tip}
                              </p>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Section 2: Mandatory Documents Checklist */}
              {(activeTab === 'ALL' || activeTab === 'DOCUMENTS') && (
                <div className="space-y-3 pt-2">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                      <FileText className="w-4 h-4 text-indigo-600" />
                      2. 필수 제출 서류 및 발급처 가이드
                    </h3>
                    <span className="text-xs font-bold text-indigo-600">
                      준비 완료 {stats.docsChecked} / {stats.docsTotal}
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {analysis.documentChecklist.map((doc) => {
                      const isChecked = !!checkedIds[doc.id];
                      const issuanceInfo = matchDocumentToIssuanceInfo(doc.title);
                      const targetAgency = doc.issuingAgency || issuanceInfo.agencyName;
                      const targetUrl = issuanceInfo.issuanceUrl;

                      return (
                        <div
                          key={doc.id}
                          onClick={() => handleToggleCheck(doc.id)}
                          className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                            isChecked
                              ? 'bg-emerald-50/60 border-emerald-200 shadow-2xs'
                              : 'bg-white hover:bg-slate-50 border-slate-200 hover:border-indigo-200 shadow-2xs'
                          }`}
                        >
                          <div>
                            <div className="flex items-start justify-between gap-2 mb-2">
                              <div className="flex items-center gap-1.5 flex-wrap">
                                <span className="text-[11px] font-bold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md flex items-center gap-1">
                                  <Building2 className="w-3 h-3 text-slate-500" />
                                  {targetAgency}
                                </span>
                                <span className="text-[10px] font-semibold text-slate-500 bg-slate-50 border border-slate-200 px-1.5 py-0.2 rounded">
                                  {issuanceInfo.costText}
                                </span>
                              </div>
                              <div
                                className={`w-5 h-5 rounded-lg border flex items-center justify-center transition-all flex-shrink-0 ${
                                  isChecked
                                    ? 'bg-emerald-600 border-emerald-600 text-white'
                                    : 'border-slate-300 bg-white'
                                }`}
                              >
                                {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                              </div>
                            </div>

                            <h4 className={`text-xs font-black leading-snug mb-1.5 ${isChecked ? 'text-emerald-950 line-through opacity-80' : 'text-slate-900'}`}>
                              {doc.title}
                            </h4>

                            <p className="text-[11px] text-slate-500 leading-relaxed">
                              {doc.description}
                            </p>
                          </div>

                          <div className="mt-3 pt-2.5 border-t border-slate-100 space-y-2">
                            {doc.tip && (
                              <div className="text-[11px] text-indigo-700 bg-indigo-50/50 p-2 rounded-xl font-medium leading-tight">
                                {doc.tip}
                              </div>
                            )}

                            <div className="flex items-center justify-between pt-1">
                              <span className="text-[10px] text-slate-400 font-medium">
                                유효: {issuanceInfo.recommendedValidity}
                              </span>
                              <a
                                href={targetUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                onClick={(e) => e.stopPropagation()}
                                className="px-2.5 py-1 bg-blue-50 hover:bg-blue-600 hover:text-white text-blue-700 font-bold text-[11px] rounded-lg transition-all flex items-center gap-1"
                              >
                                <span>발급 바로가기</span>
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Section 3: Bonus Points & Disqualification Risks */}
              {(activeTab === 'ALL' || activeTab === 'BONUS_RISKS') && (
                <div className="space-y-5 pt-2">
                  {/* Bonus Points */}
                  <div className="space-y-3">
                    <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                      <Award className="w-4 h-4 text-amber-500" />
                      3. 심사관 관점 가점 및 우대사항
                    </h3>
                    <div className="space-y-2.5">
                      {analysis.bonusPointTips.map((bonus, bIdx) => (
                        <div key={bIdx} className="bg-amber-50/60 border border-amber-200/80 p-3.5 rounded-2xl flex items-start gap-3">
                          <span className="text-[10px] font-black bg-amber-200 text-amber-900 px-2 py-0.5 rounded-full flex-shrink-0 mt-0.5">
                            {bonus.points}
                          </span>
                          <div className="flex-1">
                            <span className="text-xs font-black text-amber-950 block mb-0.5">
                              {bonus.criterion}
                            </span>
                            <p className="text-[11px] text-slate-700 font-medium">
                              {bonus.howToPrepare}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Disqualification Risks */}
                  <div className="space-y-3">
                    <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-500" />
                      4. 사전 점검: 주요 탈락 위험 및 결격 사유
                    </h3>
                    <div className="space-y-2.5">
                      {analysis.disqualificationRisks.map((risk, rIdx) => (
                        <div
                          key={rIdx}
                          className={`p-3.5 rounded-2xl border flex items-start gap-3 ${
                            risk.severity === 'CRITICAL'
                              ? 'bg-rose-50/70 border-rose-200'
                              : 'bg-orange-50/70 border-orange-200'
                          }`}
                        >
                          <AlertCircle
                            className={`w-4 h-4 mt-0.5 flex-shrink-0 ${
                              risk.severity === 'CRITICAL' ? 'text-rose-600' : 'text-orange-600'
                            }`}
                          />
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-0.5">
                              <span className="text-xs font-black text-slate-900">
                                {risk.risk}
                              </span>
                              <span
                                className={`text-[10px] font-black px-1.5 py-0.2 rounded ${
                                  risk.severity === 'CRITICAL'
                                    ? 'bg-rose-200 text-rose-900'
                                    : 'bg-orange-200 text-orange-900'
                                }`}
                              >
                                {risk.severity === 'CRITICAL' ? '탈락 주의' : '사전 확인'}
                              </span>
                            </div>
                            <p className="text-[11px] text-slate-700 font-medium">
                              <strong>해결 방안:</strong> {risk.solution}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Section 4: Application Roadmap */}
              {(activeTab === 'ALL' || activeTab === 'ROADMAP') && (
                <div className="space-y-3 pt-2">
                  <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-purple-600" />
                    5. 단계별 실행 신청 로드맵
                  </h3>
                  <div className="space-y-2.5">
                    {analysis.applicationRoadmap.map((step) => (
                      <div
                        key={step.step}
                        className="bg-slate-50 border border-slate-200 p-3.5 rounded-2xl flex items-start gap-3"
                      >
                        <div className="w-6 h-6 rounded-full bg-purple-600 text-white flex items-center justify-center font-black text-xs flex-shrink-0 mt-0.5">
                          {step.step}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between gap-2 mb-0.5">
                            <span className="text-xs font-black text-slate-900">{step.title}</span>
                            <span className="text-[10px] font-bold bg-purple-100 text-purple-700 px-2 py-0.5 rounded-md">
                              {step.duration}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-600 font-medium">{step.details}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Official Contact & Inquiry Footer */}
              {analysis.officialContact && (
                <div className="bg-slate-900 text-white p-4 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold block">공식 문의처 및 접수처</span>
                    <span className="text-sm font-black text-white">{analysis.officialContact.department}</span>
                    <span className="text-slate-300 ml-2 font-bold">Tel: {analysis.officialContact.phone}</span>
                  </div>
                  {analysis.officialContact.website && (
                    <a
                      href={analysis.officialContact.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      referrerPolicy="no-referrer"
                      className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black flex items-center gap-1 transition-all shadow-xs"
                    >
                      <span>공식 접수 포털 방문</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>
              )}
            </>
          ) : null}
        </div>

        {/* Modal Bottom Footer Actions */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200/80 flex items-center justify-between gap-3 flex-shrink-0">
          <button
            type="button"
            onClick={handleResetChecklist}
            className="text-xs font-bold text-slate-400 hover:text-slate-600 px-3 py-2 cursor-pointer"
          >
            체크 상태 초기화
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-black rounded-xl transition-all shadow-md cursor-pointer"
            >
              체크리스트 확인 완료
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
