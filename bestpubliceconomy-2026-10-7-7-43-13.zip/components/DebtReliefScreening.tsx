import React, { useState } from 'react';
import { DebtReliefInput, ScreeningResult, ScreeningStatus } from '../debtReliefTypes';
import { runDebtReliefScreening } from '../services/debtReliefService';
import { ShieldAlert, AlertCircle, CheckCircle2, ChevronRight, XCircle, Search, HelpCircle, Briefcase, Calculator } from 'lucide-react';

export const DebtReliefScreening: React.FC = () => {
  const [input, setInput] = useState<DebtReliefInput>({
    isBusiness: false,
    isClosedBusiness: false,
    daysPastDue: 0,
    unsecuredDebtAmount: 0,
    securedDebtAmount: 0,
    recentDebtRatioOver30: null
  });
  const [results, setResults] = useState<ScreeningResult[] | null>(null);

  const handleScreening = (e: React.FormEvent) => {
    e.preventDefault();
    const evaluated = runDebtReliefScreening(input);
    setResults(evaluated);
  };

  const getStatusBadge = (status: ScreeningStatus) => {
    switch (status) {
      case 'CANDIDATE':
        return <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-700 px-2 py-1 rounded-md text-[10px] font-black"><CheckCircle2 className="w-3 h-3" /> CANDIDATE</span>;
      case 'BLOCKED_BY_OFFICIAL_RULE':
        return <span className="inline-flex items-center gap-1 bg-red-100 text-red-700 px-2 py-1 rounded-md text-[10px] font-black"><XCircle className="w-3 h-3" /> BLOCKED</span>;
      case 'VERIFY_REQUIRED':
        return <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-700 px-2 py-1 rounded-md text-[10px] font-black"><AlertCircle className="w-3 h-3" /> VERIFY REQUIRED</span>;
      case 'HANDOFF':
        return <span className="inline-flex items-center gap-1 bg-indigo-100 text-indigo-700 px-2 py-1 rounded-md text-[10px] font-black"><ChevronRight className="w-3 h-3" /> HANDOFF (LEGAL)</span>;
      default:
        return null;
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-slate-900 rounded-3xl p-6 md:p-8 shadow-xl text-white">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 bg-rose-500/20 text-rose-400 rounded-xl flex items-center justify-center">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-black">채무조정 사전 스크리닝 (Debt Relief Screening)</h2>
            <p className="text-sm font-medium text-slate-400">공식근거 기반 경로 선별 (Phase 10c Slice)</p>
          </div>
        </div>
        <p className="text-xs text-rose-300 font-bold bg-rose-950/50 p-3 rounded-lg border border-rose-900">
          * 주의: 본 진단은 공식 기준에 따른 단순 경로 안내이며, 승인 여부나 감면율, 월 변제액, 법원 절차 적합성 등을 자동 확정하지 않습니다.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* INPUT FORM */}
        <div className="lg:col-span-1 bg-white p-6 rounded-3xl shadow-sm border border-slate-100 h-fit">
          <h3 className="font-black text-slate-800 mb-4 flex items-center gap-2"><Calculator className="w-4 h-4 text-indigo-600"/> 부채 및 상태 입력</h3>
          <form onSubmit={handleScreening} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">사업자 여부</label>
              <div className="flex gap-2 text-sm font-bold">
                <label className="flex-1 flex items-center gap-2 p-2 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                  <input type="radio" checked={input.isBusiness} onChange={() => setInput(prev => ({...prev, isBusiness: true}))} className="text-indigo-600" />
                  사업자
                </label>
                <label className="flex-1 flex items-center gap-2 p-2 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                  <input type="radio" checked={!input.isBusiness} onChange={() => setInput(prev => ({...prev, isBusiness: false}))} className="text-indigo-600" />
                  비사업자
                </label>
              </div>
            </div>

            {input.isBusiness && (
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">현재 영업 상태</label>
                <div className="flex gap-2 text-sm font-bold">
                  <label className="flex-1 flex items-center gap-2 p-2 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                    <input type="radio" checked={!input.isClosedBusiness} onChange={() => setInput(prev => ({...prev, isClosedBusiness: false}))} className="text-indigo-600" />
                    영업중
                  </label>
                  <label className="flex-1 flex items-center gap-2 p-2 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50">
                    <input type="radio" checked={input.isClosedBusiness} onChange={() => setInput(prev => ({...prev, isClosedBusiness: true}))} className="text-indigo-600" />
                    폐업
                  </label>
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">최장 연체 일수</label>
              <input 
                type="number" 
                min="0"
                value={input.daysPastDue} 
                onChange={(e) => setInput(prev => ({...prev, daysPastDue: parseInt(e.target.value) || 0}))} 
                className="w-full p-2 border border-slate-200 rounded-lg text-sm font-bold focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">무담보 채무액 (원)</label>
              <input 
                type="number" 
                min="0"
                step="1000000"
                value={input.unsecuredDebtAmount} 
                onChange={(e) => setInput(prev => ({...prev, unsecuredDebtAmount: parseInt(e.target.value) || 0}))} 
                className="w-full p-2 border border-slate-200 rounded-lg text-sm font-bold focus:border-indigo-500"
              />
              <p className="text-[10px] text-slate-400 mt-1">예: 300,000,000</p>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">담보 채무액 (원)</label>
              <input 
                type="number" 
                min="0"
                step="1000000"
                value={input.securedDebtAmount} 
                onChange={(e) => setInput(prev => ({...prev, securedDebtAmount: parseInt(e.target.value) || 0}))} 
                className="w-full p-2 border border-slate-200 rounded-lg text-sm font-bold focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">최근 6개월 신규채무 30% 이상 여부</label>
              <select 
                className="w-full p-2 border border-slate-200 rounded-lg text-sm font-bold focus:border-indigo-500"
                value={input.recentDebtRatioOver30 === null ? "unknown" : input.recentDebtRatioOver30 ? "yes" : "no"}
                onChange={(e) => {
                  const val = e.target.value;
                  setInput(prev => ({...prev, recentDebtRatioOver30: val === "unknown" ? null : val === "yes"}));
                }}
              >
                <option value="unknown">모름 / 확인 필요</option>
                <option value="yes">30% 이상 (최근 대출 많음)</option>
                <option value="no">30% 미만</option>
              </select>
            </div>

            <button type="submit" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black text-sm py-3 rounded-xl transition-all shadow-md">
              공식 기준 스크리닝 실행
            </button>
          </form>
        </div>

        {/* RESULTS AREA */}
        <div className="lg:col-span-2 bg-white rounded-3xl shadow-sm border border-slate-100 p-6 h-fit">
          <h3 className="font-black text-slate-800 mb-4 flex items-center gap-2"><Search className="w-4 h-4 text-indigo-600"/> 스크리닝 결과</h3>
          
          {!results ? (
            <div className="text-center py-12 border-2 border-dashed border-slate-100 rounded-2xl">
              <Briefcase className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-slate-500 font-bold text-sm">입력값을 작성하고 스크리닝을 실행하세요.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {results.map((res) => (
                <div key={res.programCode} className="p-4 rounded-2xl border border-slate-200 bg-slate-50 hover:border-slate-300 transition-colors">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <span className="text-[10px] font-black text-indigo-500 bg-indigo-50 px-2 py-0.5 rounded-full">{res.agencyName}</span>
                      <h4 className="font-black text-slate-900 mt-1">{res.programName}</h4>
                    </div>
                    {getStatusBadge(res.status)}
                  </div>
                  
                  <div className="space-y-3 mt-3">
                    {res.reasons.length > 0 && (
                      <div className="text-xs bg-white p-2.5 rounded-lg border border-slate-100">
                        <span className="font-bold text-slate-700 block mb-1">판단 근거:</span>
                        <ul className="list-disc pl-4 text-slate-600 space-y-0.5">
                          {res.reasons.map((r, i) => <li key={i}>{r}</li>)}
                        </ul>
                      </div>
                    )}
                    
                    {res.missingInformation.length > 0 && (
                      <div className="text-xs bg-amber-50/50 p-2.5 rounded-lg border border-amber-100">
                        <span className="font-bold text-amber-800 flex items-center gap-1 mb-1"><HelpCircle className="w-3 h-3"/> 확인 필요 (VERIFY_REQUIRED):</span>
                        <ul className="list-disc pl-4 text-amber-700 space-y-0.5">
                          {res.missingInformation.map((m, i) => <li key={i}>{m}</li>)}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              
              {/* LEGAL HANDOFF */}
              <div className="p-4 rounded-2xl border border-indigo-100 bg-indigo-50">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <span className="text-[10px] font-black text-indigo-500 bg-white px-2 py-0.5 rounded-full border border-indigo-100">관할 법원</span>
                    <h4 className="font-black text-slate-900 mt-1">개인회생 / 개인파산</h4>
                  </div>
                  {getStatusBadge('HANDOFF')}
                </div>
                <div className="text-xs bg-white/60 p-2.5 rounded-lg border border-indigo-100 mt-2 text-indigo-900">
                  계속적 수입 유무 및 지급불능 여부에 따른 개인회생·파산 적합성은 법원의 심사 영역입니다. 자동 판단을 제한하며, 법률구조공단 또는 서민금융진흥원 연계를 안내합니다.
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
