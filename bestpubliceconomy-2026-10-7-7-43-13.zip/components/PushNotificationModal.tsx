import React, { useState, useEffect, useMemo } from 'react';
import { 
  Bell, 
  BellRing, 
  CheckCircle2, 
  AlertTriangle, 
  Clock, 
  FileText, 
  PlusCircle, 
  Sparkles, 
  X, 
  Check, 
  Smartphone, 
  ShieldCheck, 
  Trash2, 
  Settings2, 
  RefreshCw, 
  Send, 
  Calendar, 
  ExternalLink,
  ChevronRight,
  Info,
  Layers,
  Volume2,
  Sliders
} from 'lucide-react';
import { 
  getNotificationPermission, 
  requestNotificationPermission, 
  triggerPushNotification,
  loadPushSubscriptions, 
  savePushSubscriptions, 
  loadNotificationHistory, 
  saveNotificationHistory,
  triggerEventPushNotification,
  PushNotificationSubscription, 
  NotificationHistoryItem, 
  NotificationPermissionState,
  calculateDaysRemaining
} from '../services/notificationService';
import { PolicyFund, SourcePolicy, SimilarFundRecommendation } from '../types';

interface PushNotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  favorites: (PolicyFund | SourcePolicy | SimilarFundRecommendation)[];
  initialSelectedFund?: PolicyFund | SourcePolicy | SimilarFundRecommendation | null;
  onSelectFundDetails?: (fund: any) => void;
}

export const PushNotificationModal: React.FC<PushNotificationModalProps> = ({
  isOpen,
  onClose,
  favorites,
  initialSelectedFund,
  onSelectFundDetails
}) => {
  const [activeTab, setActiveTab] = useState<'SETTINGS' | 'HISTORY' | 'SIMULATION'>('SETTINGS');
  const [permState, setPermState] = useState<NotificationPermissionState>('default');
  const [subscriptions, setSubscriptions] = useState<Record<string, PushNotificationSubscription>>({});
  const [historyList, setHistoryList] = useState<NotificationHistoryItem[]>([]);
  const [testLogMessage, setTestLogMessage] = useState<string | null>(null);

  // Simulation test state
  const [simType, setSimType] = useState<'DEADLINE_URGENT' | 'NEW_ANNOUNCEMENT' | 'DOCUMENT_UPDATE'>('DEADLINE_URGENT');
  const [simSelectedFundTitle, setSimSelectedFundTitle] = useState<string>('');

  // Global toggle state
  const [globalDeadline, setGlobalDeadline] = useState<boolean>(true);
  const [globalNewAnnouncement, setGlobalNewAnnouncement] = useState<boolean>(true);
  const [globalDocUpdate, setGlobalDocUpdate] = useState<boolean>(true);
  const [globalThresholdDays, setGlobalThresholdDays] = useState<number>(3);

  // Initialize data on modal open
  useEffect(() => {
    if (isOpen) {
      setPermState(getNotificationPermission());
      const loadedSubs = loadPushSubscriptions();
      const loadedHistory = loadNotificationHistory();
      setSubscriptions(loadedSubs);
      setHistoryList(loadedHistory);

      if (favorites.length > 0) {
        const firstTitle = initialSelectedFund
          ? ('title' in initialSelectedFund ? initialSelectedFund.title : initialSelectedFund.name)
          : ('title' in favorites[0] ? favorites[0].title : favorites[0].name);
        setSimSelectedFundTitle(firstTitle);
      }
    }
  }, [isOpen, favorites, initialSelectedFund]);

  // Sync subscriptions for new favorites automatically
  useEffect(() => {
    if (!isOpen || favorites.length === 0) return;

    setSubscriptions((prev) => {
      let updated = false;
      const next = { ...prev };

      favorites.forEach((item) => {
        const id = 'id' in item ? item.id : item.name;
        const title = 'title' in item ? item.title : item.name;
        const agency = item.agency;
        const endDate = 'endDate' in item ? item.endDate : ('applicationDeadline' in item ? item.applicationDeadline : '');

        if (!next[id] && !next[title]) {
          next[id] = {
            id,
            fundTitle: title,
            agency,
            deadlineDate: endDate || '2026-12-31',
            notifyOnDeadline: true,
            notifyOnNewAnnouncement: true,
            notifyOnDocumentUpdate: true,
            deadlineThresholdDays: 3,
            subscribedAt: new Date().toISOString().split('T')[0]
          };
          updated = true;
        }
      });

      if (updated) {
        savePushSubscriptions(next);
      }
      return updated ? next : prev;
    });
  }, [isOpen, favorites]);

  // Request browser permission handler
  const handleRequestPermission = async () => {
    const perm = await requestNotificationPermission();
    setPermState(perm);

    if (perm === 'granted') {
      triggerPushNotification('🔔 [BizMatch AI] 브라우저 알림이 설정되었습니다', {
        body: '관심 등록한 정책자금의 마감 임박, 추가 공고, 서류 업데이트 소식을 실시간으로 알려드립니다.',
      });
      setTestLogMessage('브라우저 알림 권한이 성공적으로 승인되었습니다.');
    } else if (perm === 'denied') {
      setTestLogMessage('브라우저 알림 권한이 차단되어 있습니다. 브라우저 주소창 좌측의 설정에서 알림을 허용해 주세요.');
    }
  };

  // Update a single subscription rule
  const handleToggleSubRule = (
    fundId: string, 
    key: 'notifyOnDeadline' | 'notifyOnNewAnnouncement' | 'notifyOnDocumentUpdate'
  ) => {
    setSubscriptions((prev) => {
      const target = prev[fundId];
      if (!target) return prev;
      const next = {
        ...prev,
        [fundId]: {
          ...target,
          [key]: !target[key]
        }
      };
      savePushSubscriptions(next);
      return next;
    });
  };

  // Update threshold days for a subscription
  const handleChangeThreshold = (fundId: string, days: number) => {
    setSubscriptions((prev) => {
      const target = prev[fundId];
      if (!target) return prev;
      const next = {
        ...prev,
        [fundId]: {
          ...target,
          deadlineThresholdDays: days
        }
      };
      savePushSubscriptions(next);
      return next;
    });
  };

  // Apply all toggles to all favorited funds
  const handleApplyToAll = (
    key: 'notifyOnDeadline' | 'notifyOnNewAnnouncement' | 'notifyOnDocumentUpdate',
    value: boolean
  ) => {
    setSubscriptions((prev) => {
      const next = { ...prev };
      Object.keys(next).forEach((k) => {
        next[k] = { ...next[k], [key]: value };
      });
      savePushSubscriptions(next);
      return next;
    });
  };

  // Set threshold to all
  const handleApplyThresholdToAll = (days: number) => {
    setGlobalThresholdDays(days);
    setSubscriptions((prev) => {
      const next = { ...prev };
      Object.keys(next).forEach((k) => {
        next[k] = { ...next[k], deadlineThresholdDays: days };
      });
      savePushSubscriptions(next);
      return next;
    });
  };

  // Mark all history as read
  const handleMarkAllAsRead = () => {
    const updated = historyList.map(h => ({ ...h, read: true }));
    setHistoryList(updated);
    saveNotificationHistory(updated);
  };

  // Clear history
  const handleClearHistory = () => {
    setHistoryList([]);
    saveNotificationHistory([]);
    setTestLogMessage('알림 수신 내역이 모두 초기화되었습니다.');
  };

  // Trigger test simulation push notification
  const handleSendTestPush = (type: 'DEADLINE_URGENT' | 'NEW_ANNOUNCEMENT' | 'DOCUMENT_UPDATE') => {
    if (permState !== 'granted') {
      handleRequestPermission();
      return;
    }

    const selectedFund = favorites.find(f => 
      ('title' in f ? f.title : f.name) === simSelectedFundTitle
    ) || favorites[0];

    const fundTitle = selectedFund 
      ? ('title' in selectedFund ? selectedFund.title : selectedFund.name)
      : (simSelectedFundTitle || '소상공인 맞춤 정책자금');
    const agency = selectedFund ? selectedFund.agency : '소상공인시장진흥공단';

    const result = triggerEventPushNotification(type, fundTitle, agency);
    if (result.success) {
      setTestLogMessage(`[${getEventTypeName(type)}] 실시간 브라우저 푸시 알림을 성공적으로 발송했습니다.`);
      setHistoryList(loadNotificationHistory());
    } else {
      setTestLogMessage('푸시 알림 발송에 실패했습니다. 브라우저 알림 권한 상태를 확인하세요.');
    }
  };

  const getEventTypeName = (type: string) => {
    switch (type) {
      case 'DEADLINE_URGENT': return '신청 기간 임박';
      case 'NEW_ANNOUNCEMENT': return '추가 공고 발생';
      case 'DOCUMENT_UPDATE': return '제출 서류 업데이트';
      default: return '시스템 알림';
    }
  };

  const unreadCount = useMemo(() => historyList.filter(h => !h.read).length, [historyList]);

  if (!isOpen) return null;

  return (
    <div 
      id="push-notification-manager-modal-backdrop"
      className="fixed inset-0 bg-slate-900/70 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div 
        id="push-notification-manager-modal"
        className="bg-white rounded-3xl w-full max-w-4xl max-h-[92vh] flex flex-col shadow-2xl border border-slate-100 overflow-hidden"
      >
        {/* Modal Top Header */}
        <div className="bg-slate-900 text-white p-5 sm:p-6 flex items-center justify-between gap-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-400">
              <BellRing className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg sm:text-xl font-black text-white tracking-tight">
                  정책자금 브라우저 푸시 알림 설정
                </h2>
                <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                  permState === 'granted'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : permState === 'denied'
                    ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                }`}>
                  {permState === 'granted' ? '● 알림 수신 활성화' : permState === 'denied' ? '✕ 알림 차단됨' : '▲ 권한 설정 필요'}
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium mt-0.5">
                관심 정책자금의 <strong>신청 기간 임박, 추가 공고 발생, 제출 서류 업데이트</strong>를 놓치지 않도록 실시간 브라우저 푸시를 수신합니다.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Permission Banner if not granted */}
        {permState !== 'granted' && (
          <div className="bg-amber-50 border-b border-amber-200/80 p-3 sm:p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-amber-900 text-xs">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>
                <strong>브라우저 알림 권한 허용이 필요합니다.</strong> 권한을 허용하시면 창을 닫아두어도 마감 일정과 서류 변동 사항을 즉시 수신할 수 있습니다.
              </span>
            </div>
            <button
              type="button"
              onClick={handleRequestPermission}
              className="px-4 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-black text-xs transition-all shadow-xs shrink-0 cursor-pointer flex items-center gap-1.5"
            >
              <Bell className="w-3.5 h-3.5" />
              <span>지금 알림 허용</span>
            </button>
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex items-center justify-between border-b border-slate-100 px-6 pt-3 bg-slate-50/50 shrink-0">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('SETTINGS')}
              className={`px-4 py-2.5 text-xs font-black border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'SETTINGS'
                  ? 'border-indigo-600 text-indigo-700 bg-white rounded-t-xl shadow-2xs'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>관심 자금별 알림 트리거 설정 ({favorites.length})</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('HISTORY')}
              className={`px-4 py-2.5 text-xs font-black border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'HISTORY'
                  ? 'border-indigo-600 text-indigo-700 bg-white rounded-t-xl shadow-2xs'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>알림 수신 이력</span>
              {unreadCount > 0 && (
                <span className="bg-rose-500 text-white text-[10px] px-1.5 py-0.2 rounded-full font-black">
                  {unreadCount}
                </span>
              )}
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('SIMULATION')}
              className={`px-4 py-2.5 text-xs font-black border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
                activeTab === 'SIMULATION'
                  ? 'border-indigo-600 text-indigo-700 bg-white rounded-t-xl shadow-2xs'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              <span>푸시 알림 테스트 & 시뮬레이션</span>
            </button>
          </div>
        </div>

        {/* Modal Body Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">

          {/* 1. SETTINGS TAB */}
          {activeTab === 'SETTINGS' && (
            <div className="space-y-6">
              {/* Global Quick Batch Controls */}
              <div className="bg-gradient-to-r from-slate-50 to-indigo-50/50 p-4 sm:p-5 rounded-2xl border border-slate-200/80 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <Settings2 className="w-4 h-4 text-indigo-600" />
                    <span className="text-xs font-black text-slate-900">전체 관심 자금 일괄 알림 설정</span>
                  </div>
                  <span className="text-[11px] font-bold text-slate-500">
                    현재 관심 등록된 <strong className="text-indigo-600">{favorites.length}개</strong> 정책자금에 일괄 적용됩니다.
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Global 1: 신청 기간 임박 */}
                  <div className="bg-white p-3 rounded-xl border border-slate-200/90 shadow-2xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-amber-500" /> 신청 기간 임박
                      </span>
                      <input
                        type="checkbox"
                        checked={globalDeadline}
                        onChange={(e) => {
                          setGlobalDeadline(e.target.checked);
                          handleApplyToAll('notifyOnDeadline', e.target.checked);
                        }}
                        className="w-4 h-4 text-indigo-600 rounded cursor-pointer accent-indigo-600"
                      />
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-slate-500">
                      <span>알림 시점:</span>
                      <select
                        value={globalThresholdDays}
                        onChange={(e) => handleApplyThresholdToAll(Number(e.target.value))}
                        className="bg-slate-50 border border-slate-200 text-slate-800 font-bold text-[11px] rounded-lg px-2 py-0.5 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                      >
                        <option value={1}>D-1 (1일 전)</option>
                        <option value={3}>D-3 (3일 전)</option>
                        <option value={5}>D-5 (5일 전)</option>
                        <option value={7}>D-7 (7일 전)</option>
                      </select>
                    </div>
                  </div>

                  {/* Global 2: 추가 공고 발생 */}
                  <div className="bg-white p-3 rounded-xl border border-slate-200/90 shadow-2xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                        <PlusCircle className="w-3.5 h-3.5 text-blue-500" /> 추가 공고 발생
                      </span>
                      <input
                        type="checkbox"
                        checked={globalNewAnnouncement}
                        onChange={(e) => {
                          setGlobalNewAnnouncement(e.target.checked);
                          handleApplyToAll('notifyOnNewAnnouncement', e.target.checked);
                        }}
                        className="w-4 h-4 text-indigo-600 rounded cursor-pointer accent-indigo-600"
                      />
                    </div>
                    <p className="text-[10px] text-slate-500 leading-snug">
                      2차 추경 예산 배정 및 연장 모집 공고 발생 시 즉시 발송
                    </p>
                  </div>

                  {/* Global 3: 제출 서류 업데이트 */}
                  <div className="bg-white p-3 rounded-xl border border-slate-200/90 shadow-2xs space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                        <FileText className="w-3.5 h-3.5 text-emerald-500" /> 제출 서류 업데이트
                      </span>
                      <input
                        type="checkbox"
                        checked={globalDocUpdate}
                        onChange={(e) => {
                          setGlobalDocUpdate(e.target.checked);
                          handleApplyToAll('notifyOnDocumentUpdate', e.target.checked);
                        }}
                        className="w-4 h-4 text-indigo-600 rounded cursor-pointer accent-indigo-600"
                      />
                    </div>
                    <p className="text-[10px] text-slate-500 leading-snug">
                      사업계획서/신청서 양식 개정 및 필수 구비서류 변동 시 발송
                    </p>
                  </div>
                </div>
              </div>

              {/* Fund-by-Fund Detailed Settings List */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5 text-indigo-600" />
                    관심 자금 개별 알림 규칙 설정
                  </h3>
                  <span className="text-[11px] font-bold text-slate-400">
                    자금별로 원하는 알림 항목을 자유롭게 켜고 끌 수 있습니다.
                  </span>
                </div>

                {favorites.length === 0 ? (
                  <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 space-y-2">
                    <Bell className="w-8 h-8 text-slate-300 mx-auto" />
                    <p className="text-xs font-bold text-slate-600">아직 즐겨찾기(관심 등록)된 정책자금이 없습니다.</p>
                    <p className="text-[11px] text-slate-400">대시보드 또는 추천 목록에서 별표(★)를 눌러 관심 자금을 추가해 보세요.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {favorites.map((item) => {
                      const id = 'id' in item ? item.id : item.name;
                      const title = 'title' in item ? item.title : item.name;
                      const agency = item.agency;
                      const endDate = 'endDate' in item ? item.endDate : ('applicationDeadline' in item ? item.applicationDeadline : '');
                      const daysLeft = calculateDaysRemaining(endDate);
                      const sub = subscriptions[id] || subscriptions[title] || {
                        id,
                        fundTitle: title,
                        agency,
                        deadlineDate: endDate || '2026-12-31',
                        notifyOnDeadline: true,
                        notifyOnNewAnnouncement: true,
                        notifyOnDocumentUpdate: true,
                        deadlineThresholdDays: 3,
                        subscribedAt: '2026-08-19'
                      };

                      return (
                        <div 
                          key={id}
                          className="bg-white p-4 rounded-2xl border border-slate-200/90 hover:border-indigo-200 hover:shadow-xs transition-all space-y-3"
                        >
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="text-[10px] font-black px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md">
                                  {agency}
                                </span>
                                <h4 className="text-xs sm:text-sm font-black text-slate-900 truncate">
                                  {title}
                                </h4>
                                {daysLeft >= 0 && daysLeft <= 14 && (
                                  <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                                    daysLeft <= 3 ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-800'
                                  }`}>
                                    {daysLeft === 0 ? '오늘 마감' : `D-${daysLeft}`}
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-slate-400 font-medium mt-0.5">
                                마감일정: {endDate || '공고문 일정 참조'}
                              </p>
                            </div>

                            {onSelectFundDetails && (
                              <button
                                type="button"
                                onClick={() => {
                                  onSelectFundDetails(item);
                                  onClose();
                                }}
                                className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-0.5 shrink-0 self-end sm:self-auto cursor-pointer"
                              >
                                <span>공고 상세 보기</span>
                                <ChevronRight className="w-3 h-3" />
                              </button>
                            )}
                          </div>

                          {/* 3 Major Push Notification Triggers Switchers */}
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
                            {/* Trigger 1: 신청 기간 임박 */}
                            <label className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                              sub.notifyOnDeadline
                                ? 'bg-amber-50/70 border-amber-200 text-amber-950 font-bold'
                                : 'bg-slate-50 border-slate-200 text-slate-400'
                            }`}>
                              <div className="flex items-center gap-2">
                                <Clock className={`w-3.5 h-3.5 ${sub.notifyOnDeadline ? 'text-amber-600' : 'text-slate-400'}`} />
                                <span className="text-[11px]">신청 기간 임박</span>
                              </div>
                              <input
                                type="checkbox"
                                checked={sub.notifyOnDeadline}
                                onChange={() => handleToggleSubRule(id, 'notifyOnDeadline')}
                                className="w-3.5 h-3.5 text-indigo-600 rounded cursor-pointer accent-amber-600"
                              />
                            </label>

                            {/* Trigger 2: 추가 공고 발생 */}
                            <label className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                              sub.notifyOnNewAnnouncement
                                ? 'bg-blue-50/70 border-blue-200 text-blue-950 font-bold'
                                : 'bg-slate-50 border-slate-200 text-slate-400'
                            }`}>
                              <div className="flex items-center gap-2">
                                <PlusCircle className={`w-3.5 h-3.5 ${sub.notifyOnNewAnnouncement ? 'text-blue-600' : 'text-slate-400'}`} />
                                <span className="text-[11px]">추가 공고 발생</span>
                              </div>
                              <input
                                type="checkbox"
                                checked={sub.notifyOnNewAnnouncement}
                                onChange={() => handleToggleSubRule(id, 'notifyOnNewAnnouncement')}
                                className="w-3.5 h-3.5 text-indigo-600 rounded cursor-pointer accent-blue-600"
                              />
                            </label>

                            {/* Trigger 3: 제출 서류 업데이트 */}
                            <label className={`p-2.5 rounded-xl border flex items-center justify-between cursor-pointer transition-all ${
                              sub.notifyOnDocumentUpdate
                                ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950 font-bold'
                                : 'bg-slate-50 border-slate-200 text-slate-400'
                            }`}>
                              <div className="flex items-center gap-2">
                                <FileText className={`w-3.5 h-3.5 ${sub.notifyOnDocumentUpdate ? 'text-emerald-600' : 'text-slate-400'}`} />
                                <span className="text-[11px]">제출 서류 변동</span>
                              </div>
                              <input
                                type="checkbox"
                                checked={sub.notifyOnDocumentUpdate}
                                onChange={() => handleToggleSubRule(id, 'notifyOnDocumentUpdate')}
                                className="w-3.5 h-3.5 text-indigo-600 rounded cursor-pointer accent-emerald-600"
                              />
                            </label>
                          </div>

                          {/* Trigger 1 Options when active */}
                          {sub.notifyOnDeadline && (
                            <div className="flex items-center justify-between bg-slate-50 px-3 py-1.5 rounded-xl text-[11px] text-slate-600">
                              <span className="font-semibold">마감 알림 주기:</span>
                              <div className="flex items-center gap-1.5">
                                {[1, 3, 5, 7].map((d) => (
                                  <button
                                    key={d}
                                    type="button"
                                    onClick={() => handleChangeThreshold(id, d)}
                                    className={`px-2 py-0.5 rounded-md font-black text-[10px] cursor-pointer transition-colors ${
                                      sub.deadlineThresholdDays === d
                                        ? 'bg-indigo-600 text-white'
                                        : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                                    }`}
                                  >
                                    D-{d}일 전
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 2. HISTORY TAB */}
          {activeTab === 'HISTORY' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <h3 className="text-xs font-black text-slate-900 uppercase tracking-wider">
                    수신된 정책자금 브라우저 푸시 알림 로그 ({historyList.length})
                  </h3>
                </div>
                <div className="flex items-center gap-2">
                  {historyList.length > 0 && (
                    <>
                      <button
                        type="button"
                        onClick={handleMarkAllAsRead}
                        className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer"
                      >
                        모두 읽음 처리
                      </button>
                      <span className="text-slate-300">|</span>
                      <button
                        type="button"
                        onClick={handleClearHistory}
                        className="text-[11px] font-bold text-slate-400 hover:text-rose-600 cursor-pointer"
                      >
                        기록 전체 삭제
                      </button>
                    </>
                  )}
                </div>
              </div>

              {historyList.length === 0 ? (
                <div className="p-10 text-center bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                  <Clock className="w-8 h-8 text-slate-300 mx-auto" />
                  <p className="text-xs font-bold text-slate-600">수신된 알림 이력이 없습니다.</p>
                  <p className="text-[11px] text-slate-400">[푸시 알림 테스트 & 시뮬레이션] 탭에서 테스트 알림을 발송해 보세요.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {historyList.map((item) => {
                    const isDeadline = item.type === 'DEADLINE_URGENT';
                    const isNew = item.type === 'NEW_ANNOUNCEMENT';
                    const isDoc = item.type === 'DOCUMENT_UPDATE';

                    return (
                      <div 
                        key={item.id}
                        className={`p-4 rounded-2xl border transition-all space-y-2 ${
                          !item.read
                            ? 'bg-indigo-50/40 border-indigo-200 shadow-2xs'
                            : 'bg-white border-slate-200/80'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                              isDeadline
                                ? 'bg-amber-100 text-amber-800'
                                : isNew
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-emerald-100 text-emerald-800'
                            }`}>
                              {getEventTypeName(item.type)}
                            </span>
                            <span className="text-xs font-black text-slate-900">
                              {item.title}
                            </span>
                          </div>
                          <span className="text-[10px] font-semibold text-slate-400 shrink-0">
                            {item.timestamp}
                          </span>
                        </div>

                        <p className="text-xs text-slate-600 font-medium leading-relaxed">
                          {item.message}
                        </p>

                        <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-100">
                          <span>대상 자금: <strong className="text-slate-700">{item.fundTitle}</strong> {item.agency && `(${item.agency})`}</span>
                          {!item.read && (
                            <span className="text-[10px] font-bold text-indigo-600">
                              ● 신규 알림
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* 3. SIMULATION TAB */}
          {activeTab === 'SIMULATION' && (
            <div className="space-y-6">
              <div className="bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 space-y-4">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  <h3 className="text-xs sm:text-sm font-black text-white">
                    3대 실시간 이벤트별 브라우저 푸시 알림 즉시 체험
                  </h3>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed font-medium">
                  실제 정책자금 기관에서 공고 변동이 발생했을 때 브라우저 화면 우측 상단/시스템 알림 영역으로 전송되는 푸시 메시지를 즉시 시뮬레이션합니다.
                </p>

                {/* Target Fund Dropdown */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-300 block">시뮬레이션 대상 정책자금 선택:</label>
                  <select
                    value={simSelectedFundTitle}
                    onChange={(e) => setSimSelectedFundTitle(e.target.value)}
                    className="w-full bg-slate-800 border border-slate-700 text-white font-bold text-xs rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-indigo-500 cursor-pointer"
                  >
                    {favorites.map((f) => {
                      const t = 'title' in f ? f.title : f.name;
                      return <option key={t} value={t}>{t} ({f.agency})</option>;
                    })}
                  </select>
                </div>

                {/* Simulation Action Buttons Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                  {/* Button 1: 신청 기간 임박 */}
                  <button
                    type="button"
                    onClick={() => handleSendTestPush('DEADLINE_URGENT')}
                    className="p-4 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 rounded-2xl text-left transition-all group cursor-pointer active:scale-95 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <Clock className="w-5 h-5 text-amber-400" />
                      <Send className="w-3.5 h-3.5 text-amber-300 opacity-60 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-amber-300">① 신청 기간 임박</h4>
                      <p className="text-[10px] text-slate-300 mt-0.5 leading-snug">
                        마감 D-3일 예산 소진 임박 알림 발송
                      </p>
                    </div>
                  </button>

                  {/* Button 2: 추가 공고 발생 */}
                  <button
                    type="button"
                    onClick={() => handleSendTestPush('NEW_ANNOUNCEMENT')}
                    className="p-4 bg-blue-500/20 hover:bg-blue-500/30 border border-blue-500/40 rounded-2xl text-left transition-all group cursor-pointer active:scale-95 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <PlusCircle className="w-5 h-5 text-blue-400" />
                      <Send className="w-3.5 h-3.5 text-blue-300 opacity-60 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-blue-300">② 추가 공고 발생</h4>
                      <p className="text-[10px] text-slate-300 mt-0.5 leading-snug">
                        2차 추경 예산 및 신규 차수 개시 알림
                      </p>
                    </div>
                  </button>

                  {/* Button 3: 제출 서류 업데이트 */}
                  <button
                    type="button"
                    onClick={() => handleSendTestPush('DOCUMENT_UPDATE')}
                    className="p-4 bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 rounded-2xl text-left transition-all group cursor-pointer active:scale-95 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <FileText className="w-5 h-5 text-emerald-400" />
                      <Send className="w-3.5 h-3.5 text-emerald-300 opacity-60 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div>
                      <h4 className="text-xs font-black text-emerald-300">③ 제출 서류 업데이트</h4>
                      <p className="text-[10px] text-slate-300 mt-0.5 leading-snug">
                        사업계획서 표준 양식 개정 알림 발송
                      </p>
                    </div>
                  </button>
                </div>
              </div>

              {/* Status & Feedback Info */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2">
                <div className="flex items-center gap-2 text-xs font-bold text-slate-800">
                  <Info className="w-4 h-4 text-indigo-600" />
                  <span>푸시 알림 수신 안내 사항</span>
                </div>
                <ul className="text-xs text-slate-600 space-y-1 list-disc list-inside font-medium leading-relaxed">
                  <li>브라우저 최소화 또는 다른 탭 이용 중에도 윈도우/macOS 시스템 알림 트레이를 통해 푸시가 전달됩니다.</li>
                  <li>모바일 기기(Chrome/Safari PWA)의 경우 홈 화면에 추가 후 네이티브 푸시 알림을 수신할 수 있습니다.</li>
                  <li>스마트폰 및 PC의 <strong>[방해금지 모드]</strong> 또는 <strong>[집중 모드]</strong>가 켜져 있으면 팝업이 무음으로 전달될 수 있습니다.</li>
                </ul>
              </div>
            </div>
          )}

          {/* Test log message display */}
          {testLogMessage && (
            <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-xl text-xs font-bold text-indigo-900 flex items-center justify-between gap-2 animate-fade-in">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>{testLogMessage}</span>
              </div>
              <button
                type="button"
                onClick={() => setTestLogMessage(null)}
                className="text-indigo-400 hover:text-indigo-800 text-[10px] font-black cursor-pointer"
              >
                닫기
              </button>
            </div>
          )}
        </div>

        {/* Modal Bottom Footer */}
        <div className="bg-slate-50 px-6 py-4 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-500 font-semibold">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>설정한 알림 규칙은 브라우저 로컬 저장소에 안전하게 자동 저장됩니다.</span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:w-auto px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black transition-all cursor-pointer shadow-xs"
            >
              설정 완료 및 닫기
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
