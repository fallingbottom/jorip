import React, { useState, useMemo, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  FileText,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Building2,
  HelpCircle,
  Search,
  ExternalLink,
  Copy,
  Check,
  Printer,
  Sparkles,
  BookOpen,
  MapPin,
  Clock,
  ShieldCheck,
  Download,
  PenTool,
  ChevronDown,
  ChevronUp,
  ThumbsUp,
  Lightbulb,
  AlertCircle,
  Bookmark,
  Share2,
  Calendar,
  Layers,
  ArrowUpRight,
  TrendingUp,
  CheckCircle,
  FileCheck2,
  Info,
  User,
  Hash,
  Coins,
  Phone,
  CheckCheck,
  RefreshCw,
  Laptop,
  Award,
  Zap,
  CheckSquare,
  Square,
  Scale,
  Stamp,
  SlidersHorizontal,
  Database,
  Workflow,
  FileSpreadsheet,
  Edit3
} from 'lucide-react';
import { PolicyFund, UserProfile, SourcePolicy } from '../types';
import { getDefaultPolicyData } from '../services/fundDataSource';
import { QUICK_ISSUANCE_PORTALS } from '../src/utils/documentIssuanceMap';
import { GovernmentDocumentDraftModal } from './GovernmentDocumentDraftModal';
import { GovernmentDocType } from '../src/types/documentDraft';
import { 
  POLICY_FUND_DETAILED_GUIDES, 
  getDetailedGuideByFundKey, 
  DetailedFundGuideItem 
} from '../services/policyFundDetailedGuideData';

interface PolicyApplicationGuideViewProps {
  profile?: UserProfile | null;
  matchedFunds?: PolicyFund[];
  onOpenChecklistModal?: (fundTitle: string) => void;
  onNavigateToMatch?: () => void;
  initialSelectedFund?: PolicyFund | null;
}

// 12 실전 핵심 FAQ 데이터
interface FaqItem {
  id: string;
  category: 'ELIGIBILITY' | 'PROCEDURE' | 'DOCUMENTS' | 'REJECTION';
  categoryLabel: string;
  question: string;
  answer: string;
  keyPoints: string[];
  agencyTarget?: string;
  tip?: string;
}

const FAQ_DATABASE: FaqItem[] = [
  {
    id: 'faq-1',
    category: 'PROCEDURE',
    categoryLabel: '신청 및 절차',
    question: '소진공 "직접대출"과 "대리대출"의 차이점은 무엇이며, 어떤 것이 더 유리한가요?',
    answer: '직접대출은 소상공인시장진흥공단(소진공)이 직접 자격 심사를 진행하고 자체 재원으로 대출금을 계좌에 직접 입금해 주는 방식입니다. 반면, 대리대출은 소진공에서 "정책자금 지원대상 확인서"를 발급받은 후, 지역신용보증재단/신보 등에서 보증서를 발급받아 시중은행(국민, 신한 등)을 통해 대출을 실행하는 3단계 방식입니다.',
    keyPoints: [
      '직접대출: 금리가 가장 낮고(기준금리 수준), 은행 방문 불필요, 비대면 처리 가능 (신용취약·청년·혁신형 등)',
      '대리대출: 일반 경영안정자금의 대표 방식, 보증서 발급료(연 0.8~1%)가 추가되나 취급 규모가 큼',
      '유리한 선택: 소진공 직접대출 대상(업력 3년 미만, 저신용 특례, 스마트상점 등)에 해당하면 직접대출이 무조건 1순위입니다.'
    ],
    agencyTarget: '소상공인시장진흥공단 / 지역신용보증재단',
    tip: '직접대출은 매월 초(1~5일) 접수 개시 후 당일 조기 마감되므로 개시일 오전 9시 정각 접수가 필수입니다.'
  },
  {
    id: 'faq-2',
    category: 'ELIGIBILITY',
    categoryLabel: '자격 및 조건',
    question: '신용점수가 700점대 이하(NICE/KCB 중·저신용)여도 정책자금 신청이 가능한가요?',
    answer: '네, 가능합니다. 정부는 고신용자 중심의 시중은행 대출에서 소외된 차주를 위해 "신용취약 소상공인 자금", "희망플러스 특례보증", "새출발기금 연계자금" 등을 별도로 편성하고 있습니다. 특히 NICE 744점 이하(구 6등급 이하)만을 전용 지원하는 트랙이 존재합니다.',
    keyPoints: [
      'NICE 평점 744점 이하 또는 KCB 700점 이하 전용 저신용 특례자금 존재',
      '신용점수가 낮아도 사업성 및 매출 흐름이 확인되면 심사 우대',
      '단, 현재 30일 이상 금융 연체 중이거나 국세·지방세 체납이 있는 경우는 즉시 부결됩니다.'
    ],
    agencyTarget: '소진공 직접대출 / 신용보증재단',
    tip: '신용점수 조회 시 신용점수는 하락하지 않으므로 사전에 KCB/NICE 점수를 정확히 확인 후 전용 자금으로 신청하세요.'
  },
  {
    id: 'faq-3',
    category: 'REJECTION',
    categoryLabel: '부결 및 재신청',
    question: '최근에 정책자금 또는 보증 심사에서 부결되었는데, 언제 다시 신청할 수 있나요?',
    answer: '공식 규정상 동일 기관, 동일 자금 상품에 대해서는 부결일(또는 반려일)로부터 6개월간 재신청이 제한됩니다. 그러나 단순 서류 미비로 인한 반려는 서류 보완 후 즉시 재접수가 가능하며, 다른 기관의 정책자금(예: 신보 부결 후 소진공 직접대출 신청)은 6개월 제한을 받지 않습니다.',
    keyPoints: [
      '동일 기관 동일 상품: 부결 통보일로부터 6개월 경과 후 재신청 가능',
      '타 기관 상품: 요건이 다를 경우 즉시 신청 가능 (예: 지역신보 부결 시 소진공 직접대출 검토)',
      '서류 미비/단순 반려: 당월 내 즉시 서류 보완 후 재접수 가능'
    ],
    agencyTarget: '전 보증기관 및 금융기관 공통',
    tip: '부결 시 반드시 심사 담당자에게 "정확한 부결 사유(부채비율 초과인지, 보증한도 소진인지 등)"를 유선으로 확인하고 우회 전략을 세워야 합니다.'
  },
  {
    id: 'faq-4',
    category: 'ELIGIBILITY',
    categoryLabel: '자격 및 조건',
    question: '지역신용보증재단, 신용보증기금(신보), 기술보증기금(기보)에 동시 중복 신청이 가능한가요?',
    answer: '원칙적으로 불가합니다. 우리나라 보증기관들은 전국 전산망으로 보증 내역을 실시간 공유하며 "동일 차주 중복보증 제한" 규정을 적용합니다. 신보, 기보, 지역신보 중 하나의 기관에서만 주보증을 받는 것이 원칙이며, 동시 접수 시 전산상 이중 접수로 자동 반려됩니다.',
    keyPoints: [
      '중복 보증 금지: 신보·기보·지역신보 간 동시 진행 불가',
      '소상공인·자영업자 1순위: 지역신용보증재단 (가장 친화적이고 승인율 높음)',
      '제조업·소공인 1순위: 소진공 소공인특화자금 또는 신용보증기금(KODIT)',
      '기술기반·특허보유 스타트업 1순위: 기술보증기금(KIBO)'
    ],
    agencyTarget: '신용보증재단중앙회 / 신보 / 기보',
    tip: '기존에 다른 기관 보증잔액이 있더라도 잔여 보증한도가 남아 있다면 대환 또는 추가보증이 일부 가능할 수 있습니다.'
  },
  {
    id: 'faq-5',
    category: 'ELIGIBILITY',
    categoryLabel: '자격 및 조건',
    question: '카드론, 현금서비스, 제2금융권 대출이 있으면 무조건 심사에서 탈락하나요?',
    answer: '무조건 탈락은 아니지만 심사 감점의 가장 큰 요인입니다. 연간 매출액 대비 총부채비율이 100%를 초과하거나, 30일 이내 카드론·현금서비스 건수가 3건 이상이면 보증 한도가 대폭 삭감되거나 심사 보류될 수 있습니다. 고금리 다중채무를 보유 중인 경우 "소상공인 저금리 대환대출"을 먼저 신청하는 것이 정답입니다.',
    keyPoints: [
      '부채비율 100% 이하: 정상 승인 및 한도 우대',
      '부채비율 100%~200%: 한도 감액(50~70% 수준 승인) 또는 조건부 승인',
      '단기 카드론/현금서비스: 신청 전 최소 1~2개월 전 상환하거나 정리 권장',
      '해결책: 소진공 고금리 대환자금(연 7% 이상 대출을 연 3~4%대로 전환)'
    ],
    agencyTarget: '신용평가사 / 금융기관 공통',
    tip: '신청 전 소액 카드론 잔액을 우선 상환하여 신용평가사 다중채무 건수를 줄이면 신용평점 즉각 회복 효과가 있습니다.'
  },
  {
    id: 'faq-6',
    category: 'DOCUMENTS',
    categoryLabel: '서류 및 심사',
    question: '국세나 지방세 체납이 있는 경우, 분납 중이어도 정책자금 신청이 가능한가요?',
    answer: '원칙적으로 체납이 1원이라도 있으면 정부 정책자금은 시스템상 접수 자체가 불가능합니다. "국세 완납증명서" 및 "지방세 납세증명서"에 "체납 없음"으로 표기되어야 합니다. 단, 관할 세무서로부터 정식 "체납처분 유예 승인"을 받고 유예 사실이 증명서에 명시된 특별한 예외를 제외하고는 사전 완납이 필수입니다.',
    keyPoints: [
      '체납 시 접수 원천 차단: 정책자금 공통 결격 요건 1순위',
      '홈택스 및 위택스에서 국세·지방세 완납증명서 사전 시험 발급 필수',
      '소액 체납의 경우 즉시 납부 후 1~2시간 뒤 홈택스에서 완납 증명 출력 가능'
    ],
    agencyTarget: '국세청 / 지방자치단체',
    tip: '국세 체납은 분납 중이더라도 완납 증명서가 발급되지 않는 경우가 대부분이므로, 지인 차입 등을 통해 세금부터 정리해야 합니다.'
  },
  {
    id: 'faq-7',
    category: 'PROCEDURE',
    categoryLabel: '신청 및 절차',
    question: '신용보증서 발급 시 발생하는 "보증료"는 얼마이며, 어떻게 납부하나요?',
    answer: '신용보증재단 보증서 발급 시 보증금액에 대해 연 0.5%~1.2% 수준의 신용보증료가 부과됩니다. 예컨대 3,000만원 보증서 발급 시 연 약 24만~30만원 수준입니다. 통상 은행에서 대출금이 통장으로 입금될 때 1년치 보증료가 원천 선공제되거나, 전자서명 약정 시 가상계좌로 납부하게 됩니다.',
    keyPoints: [
      '보증료율: 연 0.5% ~ 1.2% (정책 특례에 따라 0.2~0.5%p 감면 혜택 다수)',
      '납부 시점: 보증서 발급 약정 시 선납 또는 은행 대출 실행 시 자동 차감',
      '환급 가능: 중도에 대출을 전액 조기상환하면 남은 기간의 보증료는 일할 계산되어 환급됩니다.'
    ],
    agencyTarget: '지역신용보증재단',
    tip: '중기부 착한가격업소, 백년가게, 여성/청년 기업 등 우대 대상은 보증료 0.2%p 추가 인하 혜택이 적용됩니다.'
  },
  {
    id: 'faq-8',
    category: 'PROCEDURE',
    categoryLabel: '신청 및 절차',
    question: '신청 접수 후 실제 사업자 통장으로 입금(실행)되기까지 얼마나 걸리나요?',
    answer: '신청 방식에 따라 차이가 있습니다. 소진공 비대면 직접대출은 서류 완비 시 평균 5~7영업일 내에 입금됩니다. 반면 지역신보 보증서 대리대출은 [소진공 확인서 1~2일 + 보증재단 심사 및 현장실사 7~10일 + 은행 대출 약정 2~3일]로 총 2주~3주가 소요됩니다. 분기 초 접수 폭주 시 4주까지 걸릴 수 있습니다.',
    keyPoints: [
      '소진공 비대면 직접대출: 5 ~ 7영업일 (초고속)',
      '지역신보 보증부 대리대출: 약 2 ~ 3주 (현장실사 포함)',
      '시중은행 일반 정책자금 대환: 약 1 ~ 2주',
      '자금 소요 시점 최소 1개월 전 미리 신청 준비 착수가 안전합니다.'
    ],
    agencyTarget: '전 금융기관',
    tip: '마이데이터 서류 일괄 제출 및 모바일 비대면 전자약정을 이용하면 오프라인 대면 방문 대비 처리 일수를 4~5일 단축할 수 있습니다.'
  },
  {
    id: 'faq-9',
    category: 'DOCUMENTS',
    categoryLabel: '서류 및 심사',
    question: '사업계획서(자금소요계획서) 작성 시 심사관이 가장 먼저 확인하는 3대 핵심 포인트는?',
    answer: '심사관은 수많은 신청서를 빠르게 평가하기 때문에 긴 문장보다는 다음 세 가지를 중점적으로 봅니다: ① 자금 소요의 구체성(견적서나 세금계산서 증빙 여부), ② 매출 증대 및 비용 절감 효과(현실적인 계산), ③ 원리금 상환 확실성(월 상환액 대비 순영업이익의 여유분, DSCR).',
    keyPoints: [
      '1. 구체적 견적 명세: "운영비 3천만원" 대신 "식자재 공동구매 1.5천만 + 키오스크 설비 1.5천만" 명시',
      '2. 세무 신고 데이터 일치: 부가세 과세표준증명원 상 매출과 사업계획서상 수치가 정확히 일치해야 함',
      '3. 상환 리스크 대책: "매월 카드 매출의 10%를 상환 전용 통장에 유보하여 상환 확실성 확보" 명시'
    ],
    agencyTarget: '소진공 / 신용보증재단 / 시중은행',
    tip: '장황한 사업 설명보다 항목별 비용 표와 6개월간의 월별 예상 손익계산표 1장을 첨부하는 것이 훨씬 높은 점수를 받습니다.'
  },
  {
    id: 'faq-10',
    category: 'ELIGIBILITY',
    categoryLabel: '자격 및 조건',
    question: '전년도 대비 매출이 감소했는데, 정책자금 신청 시 심사에 불리하게 작용하나요?',
    answer: '일반 은행 대출에서는 매출 감소가 결격 사유이지만, 정책자금에서는 오히려 장점이 될 수 있습니다! 정부는 매출 감소 소상공인을 지원하기 위해 "경영위기 극복자금", "일시적 경영애로자금", "희망리턴 패키지" 등을 별도 트랙으로 운영합니다. 부가세 과표상 전년 대비 10% 이상 감소한 사업자는 우선 지원 대상이 됩니다.',
    keyPoints: [
      '매출 감소(10%~20% 이상) 증빙 시: "경영위기 극복 특례자금" 우대 배정',
      '우대 금리(0.2~0.4%p) 지원 및 보증비율 90~100% 전액 보증 적용',
      '단, 단순 매출 감소에 그치지 않고 자금 지원을 통해 반등할 수 있는 회복 계획서 제출이 필요'
    ],
    agencyTarget: '중소벤처기업부 / 소진공',
    tip: '매출 감소가 확인되는 "부가가치세과세표준증명"을 2023년 vs 2024년 비교 자료로 제출하여 위기극복자금으로 우회 접수하세요.'
  },
  {
    id: 'faq-11',
    category: 'DOCUMENTS',
    categoryLabel: '서류 및 심사',
    question: '모든 제출 서류의 "유효기간"은 어떻게 되며, 인터넷 발급 시 주의사항은?',
    answer: '정부 정책자금 및 보증기관에 제출하는 모든 관공서 증명 서류는 원칙적으로 "신청일 기준 최근 1개월(30일) 이내 발급분"이어야 합니다. 특히 홈택스나 정부24에서 인터넷 발급 시 주민등록번호 뒷자리 전체 공개(13자리 표시) 옵션을 반드시 선택해야 반려되지 않습니다.',
    keyPoints: [
      '유효기간: 신청 접수일 기준 1개월 이내 발급 서류만 유효 인정',
      '주민등록번호: 반드시 13자리 전체 공개(****** 가림 처리 시 은행 반려)',
      '제출용 용도 선택: 홈택스 발급 시 "관공서 제출용" 또는 "금융기관 제출용" 선택',
      '컬러 출력 권장: 전자 직인(관인)이 선명하게 보이도록 출력'
    ],
    agencyTarget: '홈택스 / 정부24 / 주민센터',
    tip: '정부24 및 홈택스 발급 시 "전자문서지갑"으로 전송하면 스캔 없이 기관으로 다이렉트 자동 연계 제출이 가능합니다.'
  },
  {
    id: 'faq-12',
    category: 'REJECTION',
    categoryLabel: '부결 및 대환대출',
    question: '정책자금으로 받은 돈으로 기존의 고금리 대출이나 카드론을 갚아도 법적으로 괜찮나요?',
    answer: '목적에 맞게 신청하셔야 합니다. "일반 운영자금"이나 "시설자금"으로 배정받은 자금을 기존 타 금융기관 대출 상환에 유용할 경우 목적 외 사용으로 적발되어 자금 회수 및 정책자금 참여 제한(최대 3년) 조치를 당할 수 있습니다. 기존 고금리 채무 정리가 목적이라면 반드시 "소상공인 대환대출(저금리 대환)" 전용 상품으로 신청하셔야 합법적으로 은행 간 자동 대환 처리가 완료됩니다.',
    keyPoints: [
      '일반 운영자금: 사업장 운영 경비(인건비, 재료비, 임차료 등)로만 집행 필수',
      '고금리 채무 상환 목적: 반드시 "소진공 고금리 대환대출" 또는 "신보 특례대환"으로 신청',
      '대환대출 특징: 차주 통장으로 현금이 들어오지 않고, 기존 고금리 대출 기관으로 대출금이 직접 송금되어 채무가 상쇄됨'
    ],
    agencyTarget: '소상공인시장진흥공단 / 신용보증기금',
    tip: '연 7% 이상의 은행·2금융권 대출을 보유 중이라면 소진공 대환대출 신청 시 연 3.5~4.5% 고정금리로 갈아탈 수 있습니다.'
  }
];

// 표준 필수 구비 서류 마스터 데이터
export interface StandardDocumentItem {
  id: string;
  category: 'BUSINESS' | 'FINANCIAL' | 'TAX' | 'EMPLOYMENT' | 'POLICY_SPECIAL';
  categoryLabel: string;
  name: string;
  agency: string;
  portalUrl: string;
  isFree: boolean;
  validity: string;
  isOnlineInstant: boolean;
  isMyDataAutoScrapable: boolean; // 공공 마이데이터 자동 스크래핑 제출 지원 여부
  submissionType: 'MYDATA_AUTO' | 'OFFICIAL_PORTAL' | 'SELF_AUTHORED';
  tip: string;
  samplePath: string;
}

const REQUIRED_DOCUMENTS_MASTER: StandardDocumentItem[] = [
  // 1. 사업자 기본 서류
  {
    id: 'doc-1',
    category: 'BUSINESS',
    categoryLabel: '사업자 기본 서류',
    name: '사업자등록증명원 (최근 1개월 이내)',
    agency: '국세청 홈택스 / 정부24',
    portalUrl: 'https://www.hometax.go.kr',
    isFree: true,
    validity: '발급일로부터 1개월',
    isOnlineInstant: true,
    isMyDataAutoScrapable: true,
    submissionType: 'MYDATA_AUTO',
    tip: '사업자등록증 사본 대신 반드시 "사업자등록증명" 공적 문서를 발급받아야 현재 계속사업자임이 증명됩니다. (온라인 접수 시 마이데이터로 10초 만에 자동 전송)',
    samplePath: '홈택스 > 국세증명·사업자등록·세금신고 > 즉시발급증명 > 사업자등록증명'
  },
  {
    id: 'doc-2',
    category: 'BUSINESS',
    categoryLabel: '사업자 기본 서류',
    name: '주민등록표등본 및 초본 (대표자 본인)',
    agency: '행정안전부 정부24',
    portalUrl: 'https://www.gov.kr',
    isFree: true,
    validity: '발급일로부터 1개월',
    isOnlineInstant: true,
    isMyDataAutoScrapable: true,
    submissionType: 'MYDATA_AUTO',
    tip: '대표자 실거주지 및 부양가족 확인용. 주민번호 뒷자리 포함 출력 권장. 마이데이터 동의 시 자동 연동됩니다.',
    samplePath: '정부24 > 주민등록표등본(초본) 교부 > 온라인 즉시 발급'
  },
  {
    id: 'doc-3',
    category: 'BUSINESS',
    categoryLabel: '사업자 기본 서류',
    name: '사업장 임대차계약서 사본 (자가인 경우 건물·토지 등기사항증명서)',
    agency: '자체 보관 / 대법원 인터넷등기소',
    portalUrl: 'http://www.iros.go.kr',
    isFree: false,
    validity: '계약 유효기간 내',
    isOnlineInstant: true,
    isMyDataAutoScrapable: false,
    submissionType: 'OFFICIAL_PORTAL',
    tip: '확정일자 또는 전입신고 필수. 사업장 실제 위치와 사업자등록증 주소가 100% 일치해야 실사 시 문제가 없습니다. (스캔 PDF 직접 업로드 필요)',
    samplePath: '자가 건물일 경우 대법원 인터넷등기소에서 등기사항전부증명서(말소사항 포함) 발급'
  },

  // 2. 재무 및 매출 증빙
  {
    id: 'doc-4',
    category: 'FINANCIAL',
    categoryLabel: '재무 및 매출 증빙',
    name: '부가가치세 과세표준증명원 (최근 3개년)',
    agency: '국세청 홈택스',
    portalUrl: 'https://www.hometax.go.kr',
    isFree: true,
    validity: '발급일로부터 1개월',
    isOnlineInstant: true,
    isMyDataAutoScrapable: true,
    submissionType: 'MYDATA_AUTO',
    tip: '소상공인의 실질 매출을 심사관이 판단하는 절대적인 서류입니다. 면세사업자는 "면세사업자 수입금액증명"을 제출합니다. 마이데이터로 일괄 자동 수집됩니다.',
    samplePath: '홈택스 > 국세증명 > 부가가치세 과세표준증명 (최근 3년 분기별 체크)'
  },
  {
    id: 'doc-5',
    category: 'FINANCIAL',
    categoryLabel: '재무 및 매출 증빙',
    name: '표준재무제표증명 (재무상태표, 손익계산서 최근 3년)',
    agency: '국세청 홈택스 (세무대리인)',
    portalUrl: 'https://www.hometax.go.kr',
    isFree: true,
    validity: '발급일로부터 1개월',
    isOnlineInstant: true,
    isMyDataAutoScrapable: true,
    submissionType: 'MYDATA_AUTO',
    tip: '법인사업자 필수. 개인 복식부기의무자 필수. 간편장부 대상자인 경우 소득금액증명으로 대체 가능합니다.',
    samplePath: '홈택스 > 국세증명 > 표준재무제표증명'
  },
  {
    id: 'doc-6',
    category: 'FINANCIAL',
    categoryLabel: '재무 및 매출 증빙',
    name: '소득금액증명원 (최근 1~2개년 종합소득세 신고분)',
    agency: '국세청 홈택스 / 정부24',
    portalUrl: 'https://www.hometax.go.kr',
    isFree: true,
    validity: '발급일로부터 1개월',
    isOnlineInstant: true,
    isMyDataAutoScrapable: true,
    submissionType: 'MYDATA_AUTO',
    tip: '개인사업자 대표자의 실제 사업소득 및 상환 능력을 산정하는 핵심 기준입니다. 금융기관 제출용 선택 필수.',
    samplePath: '홈택스 > 국세증명 > 소득금액증명 (종합소득세 신고자용 선택)'
  },
  {
    id: 'doc-7',
    category: 'FINANCIAL',
    categoryLabel: '재무 및 매출 증빙',
    name: '주거래은행 통장 최근 6개월 거래내역서',
    agency: '주거래 시중은행 인터넷뱅킹',
    portalUrl: '',
    isFree: true,
    validity: '신청일 기준 최근 6개월',
    isOnlineInstant: true,
    isMyDataAutoScrapable: false,
    submissionType: 'OFFICIAL_PORTAL',
    tip: '카드 매출 입금 실적 및 임차료/공과금 정상 납부 흐름을 증명합니다. 인터넷뱅킹에서 엑셀 또는 PDF로 다운로드 첨부.',
    samplePath: '거래은행 인터넷뱅킹 > 조회 > 거래내역조회 (최근 6개월) > 인쇄/PDF 저장'
  },

  // 3. 납세 및 사회보험 완납
  {
    id: 'doc-8',
    category: 'TAX',
    categoryLabel: '납세 및 체납 확인',
    name: '국세 납세증명서 (국세 완납 증명)',
    agency: '국세청 홈택스 / 손택스',
    portalUrl: 'https://www.hometax.go.kr',
    isFree: true,
    validity: '발급일로부터 30일 (유효기간 명시)',
    isOnlineInstant: true,
    isMyDataAutoScrapable: true,
    submissionType: 'MYDATA_AUTO',
    tip: '증명서 상단에 "체납액 없음" 또는 유효기간이 살아 있어야 합니다. 국세 체납이 1원이라도 있으면 무조건 즉시 부결됩니다.',
    samplePath: '홈택스 > 국세증명 > 납세증명서(국세완납증명)'
  },
  {
    id: 'doc-9',
    category: 'TAX',
    categoryLabel: '납세 및 체납 확인',
    name: '지방세 납세증명서 (시·군·구세 완납)',
    agency: '정부24 / 위택스 (WeTax)',
    portalUrl: 'https://www.gov.kr',
    isFree: true,
    validity: '발급일로부터 30일',
    isOnlineInstant: true,
    isMyDataAutoScrapable: true,
    submissionType: 'MYDATA_AUTO',
    tip: '재산세, 주민세, 자동차세 등 지방세 체납 유무 확인용. 전국 지자체 체납 여부가 통합 조회됩니다.',
    samplePath: '정부24 검색창 > "지방세 납세증명" 검색 후 온라인 즉시 발급'
  },
  {
    id: 'doc-10',
    category: 'TAX',
    categoryLabel: '납세 및 체납 확인',
    name: '4대사회보험료 완납증명서 (사업장 체납 유무)',
    agency: '국민건강보험공단 사회보험통합징수포털',
    portalUrl: 'https://si4n.nhis.or.kr',
    isFree: true,
    validity: '발급일로부터 1개월',
    isOnlineInstant: true,
    isMyDataAutoScrapable: true,
    submissionType: 'MYDATA_AUTO',
    tip: '국민연금, 건강보험료 체납 시 정책자금 지원이 전면 제한되므로 사전 완납이 필수입니다.',
    samplePath: '사회보험통합징수포털 > 제증명발급 > 완납증명서 발급'
  },

  // 4. 고용 및 소상공인 규모
  {
    id: 'doc-11',
    category: 'EMPLOYMENT',
    categoryLabel: '고용 및 규모 확인',
    name: '중소기업·소상공인확인서',
    agency: '중소기업현황정보시스템 (sminfo)',
    portalUrl: 'https://sminfo.mss.go.kr',
    isFree: true,
    validity: '매년 3월 말 갱신 (유효기간 내)',
    isOnlineInstant: true,
    isMyDataAutoScrapable: true,
    submissionType: 'MYDATA_AUTO',
    tip: '정부지원 정책자금 가산점 및 소상공인 기준(5인 미만/제조10인 미만)을 법적으로 증명하는 핵심 문서입니다.',
    samplePath: 'sminfo.mss.go.kr > 회원가입 > 온라인 자료 제출(홈택스 자료 연동) 후 즉시 출력'
  },
  {
    id: 'doc-12',
    category: 'EMPLOYMENT',
    categoryLabel: '고용 및 규모 확인',
    name: '4대사회보험 사업장 가입자명부 (직원 보유 시)',
    agency: '4대사회보험 정보연계센터',
    portalUrl: 'https://www.4insure.or.kr',
    isFree: true,
    validity: '발급일로부터 1개월',
    isOnlineInstant: true,
    isMyDataAutoScrapable: true,
    submissionType: 'MYDATA_AUTO',
    tip: '상시 근로자 5인 미만(소상공인) 요건 확인용. 직원이 없는 1인 단독 사업자는 "건강보험 자격득실확인서"로 대체 가능합니다.',
    samplePath: '4insure.or.kr > 증명서 발급 > 4대사회보험 사업장 가입자명부 신청'
  },

  // 5. 정책자금 전용 법정 서식 (본 시스템 템플릿 생성기 지원)
  {
    id: 'doc-13',
    category: 'POLICY_SPECIAL',
    categoryLabel: '정책자금 전용 서식',
    name: '[별지 제1호 서식] 소상공인 정책자금 융자신청서 및 기업현황표',
    agency: '소진공 포털 / 본 시스템 자동 완성',
    portalUrl: 'https://ols.semas.or.kr',
    isFree: true,
    validity: '신청 당월',
    isOnlineInstant: true,
    isMyDataAutoScrapable: false,
    submissionType: 'SELF_AUTHORED',
    tip: '온라인 신청 시 시스템에 직접 입력하며, 공단 현장 접수 시 표준 양식으로 작성합니다. 본 시스템 [4. 템플릿 생성기]에서 내 정보가 자동 채워진 초안을 즉시 생성/인쇄할 수 있습니다.',
    samplePath: '본 시스템 [4. 온라인 신청 템플릿 생성기] > [별지 제1호 서식] 원클릭 생성'
  },
  {
    id: 'doc-14',
    category: 'POLICY_SPECIAL',
    categoryLabel: '정책자금 전용 서식',
    name: '[별지 제2호 서식] 정책자금 표준 사업계획서 및 자금소요·상환계획서',
    agency: '자체 작성 / 본 시스템 모범 템플릿',
    portalUrl: '',
    isFree: true,
    validity: '신청 시점 작성',
    isOnlineInstant: true,
    isMyDataAutoScrapable: false,
    submissionType: 'SELF_AUTHORED',
    tip: '심사관을 설득하는 핵심 서류. 매출 증대 산출근거, 비용 절감 효과, 월 원리금 상환 계획(DSCR > 1.5)이 구체적 숫자로 명시되어야 승인율이 급상승합니다.',
    samplePath: '본 시스템 [4. 온라인 신청 템플릿 생성기] > [별지 제2호 서식] 즉시 복사'
  },
  {
    id: 'doc-15',
    category: 'POLICY_SPECIAL',
    categoryLabel: '정책자금 전용 서식',
    name: '[별지 제3호 서식] 시설·운전자금 세부 활용계획서 및 견적 명세표',
    agency: '자체 작성 / 공급업체 견적서 첨부',
    portalUrl: '',
    isFree: true,
    validity: '신청 시점 작성',
    isOnlineInstant: true,
    isMyDataAutoScrapable: false,
    submissionType: 'SELF_AUTHORED',
    tip: '신청 금액과 원부자재/설비 구입 견적서의 합계액이 1원 단위까지 일치해야 합니다. 사후 세금계산서 증빙 필수 품목 명시.',
    samplePath: '본 시스템 [4. 온라인 신청 템플릿 생성기] > [별지 제3호 서식] 작성'
  },
  {
    id: 'doc-16',
    category: 'POLICY_SPECIAL',
    categoryLabel: '정책자금 전용 서식',
    name: '[별지 제4호 서식] 정책자금 신청자격 자가진단 및 사실확인 서약서',
    agency: '소진공 / 중진공 / 신보 표준 서식',
    portalUrl: '',
    isFree: true,
    validity: '신청 당월',
    isOnlineInstant: true,
    isMyDataAutoScrapable: false,
    submissionType: 'SELF_AUTHORED',
    tip: '제3자 부당개입(불법 브로커 수수료) 배제, 고의 부도/허위신청 시 융자금 전액 환수 및 법적 처벌 확약. 서명/직인 날인 필수.',
    samplePath: '본 시스템 [4. 온라인 신청 템플릿 생성기] > [별지 제4호 서식] 생성'
  }
];

export const PolicyApplicationGuideView: React.FC<PolicyApplicationGuideViewProps> = ({
  profile,
  matchedFunds = [],
  onOpenChecklistModal,
  onNavigateToMatch,
  initialSelectedFund
}) => {
  // Navigation Tabs
  const [activeTab, setActiveTab] = useState<'FUND_SPECIFIC' | 'PROCEDURE' | 'DOCUMENTS' | 'WRITING_EXAMPLE' | 'FAQ'>('FUND_SPECIFIC');

  // Available Policies for Selection: combine matched funds with detailed guides master list
  const allPolicyOptions: PolicyFund[] = useMemo(() => {
    const list: PolicyFund[] = [];
    const seenTitles = new Set<string>();

    if (matchedFunds && matchedFunds.length > 0) {
      matchedFunds.forEach(f => {
        seenTitles.add(f.title.trim().toLowerCase());
        list.push(f);
      });
    }

    // Add detailed guide items as options so all primary policy funds are accessible
    POLICY_FUND_DETAILED_GUIDES.forEach(g => {
      const cleanTitle = g.title.trim().toLowerCase();
      if (!seenTitles.has(cleanTitle)) {
        seenTitles.add(cleanTitle);
        list.push({
          id: g.id,
          title: g.title,
          agency: g.agency,
          category: g.category,
          maxAmount: g.maxAmount,
          interestRate: g.interestRate,
          description: `${g.targetAudience} 대상 ${g.category} 정책자금`,
          eligibility: g.targetAudience,
          applicationDeadline: g.applicationPeriod.schedule,
          contactInfo: g.applicationMethods.offline.phone,
          requiredDocuments: g.requiredDocuments.common.map(d => d.name),
          applicationUrl: g.applicationMethods.online.url,
          applicationProcedure: g.expectedScreeningTimeline.stages.map(s => `${s.stepNumber}단계: ${s.stageName} (${s.duration})`),
          writingGuide: g.underwritingCriteria[0]?.strategyTip || '신청 사유와 상환 계획을 구체적인 숫자로 기술하세요.',
          announcementDate: '2026-01-01',
          startDate: '2026-01-01',
          endDate: '2026-12-31'
        });
      }
    });

    return list;
  }, [matchedFunds]);

  // Selected Target Fund for contextual guidance
  const [selectedFundId, setSelectedFundId] = useState<string>(
    initialSelectedFund?.id || initialSelectedFund?.title || (allPolicyOptions.length > 0 ? allPolicyOptions[0].id : '')
  );

  useEffect(() => {
    if (initialSelectedFund) {
      setSelectedFundId(initialSelectedFund.id || initialSelectedFund.title);
      setActiveTab('FUND_SPECIFIC');
    }
  }, [initialSelectedFund]);

  const selectedFund = useMemo(() => {
    return allPolicyOptions.find(f => f.id === selectedFundId || f.title === selectedFundId) || allPolicyOptions[0] || null;
  }, [allPolicyOptions, selectedFundId]);

  // Retrieve Detailed Fund Guide Data
  const detailedGuide: DetailedFundGuideItem = useMemo(() => {
    return getDetailedGuideByFundKey(selectedFund?.title || '');
  }, [selectedFund]);

  // Document Checklist Checked State
  const [checkedDocIds, setCheckedDocIds] = useState<Record<string, boolean>>({});
  const [selectedDocCategory, setSelectedDocCategory] = useState<string>('ALL');
  const [docMethodFilter, setDocMethodFilter] = useState<'ALL' | 'MYDATA' | 'PORTAL' | 'TEMPLATE'>('ALL');

  // Interactive Online Template Hub State
  const [selectedTemplateKey, setSelectedTemplateKey] = useState<string>('APPLICATION_FORM');
  const [showOfficialStamp, setShowOfficialStamp] = useState<boolean>(true);
  const [templateCustomFields, setTemplateCustomFields] = useState<Record<string, string>>({});

  // Summary counts by method
  const myDataDocsCount = useMemo(() => REQUIRED_DOCUMENTS_MASTER.filter(d => d.isMyDataAutoScrapable).length, []);
  const manualDocsCount = useMemo(() => REQUIRED_DOCUMENTS_MASTER.filter(d => d.submissionType === 'OFFICIAL_PORTAL').length, []);
  const templateDocsCount = useMemo(() => REQUIRED_DOCUMENTS_MASTER.filter(d => d.submissionType === 'SELF_AUTHORED').length, []);

  // FAQ Search & Filter State
  const [faqSearchQuery, setFaqSearchQuery] = useState<string>('');
  const [selectedFaqCategory, setSelectedFaqCategory] = useState<string>('ALL');
  const [expandedFaqId, setExpandedFaqId] = useState<string | null>('faq-1');
  const [helpfulFaqVotes, setHelpfulFaqVotes] = useState<Record<string, boolean>>({});

  // Writing Example & Template Modal State
  const [copiedSection, setCopiedSection] = useState<string | null>(null);
  const [isDraftModalOpen, setIsDraftModalOpen] = useState<boolean>(false);
  const [draftType, setDraftType] = useState<GovernmentDocType>('APPLICATION_FORM');

  // Toggle Checkbox for Document
  const toggleDocCheck = (id: string) => {
    setCheckedDocIds(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  // Document checklist completion calculation
  const totalDocsCount = REQUIRED_DOCUMENTS_MASTER.length;
  const checkedDocsCount = useMemo(() => {
    return Object.values(checkedDocIds).filter(Boolean).length;
  }, [checkedDocIds]);
  const docProgressPercent = Math.round((checkedDocsCount / totalDocsCount) * 100);

  // Copy helper
  const handleCopyText = (text: string, sectionKey: string) => {
    navigator.clipboard.writeText(text);
    setCopiedSection(sectionKey);
    setTimeout(() => {
      setCopiedSection(null);
    }, 2000);
  };

  // Filtered FAQs
  const filteredFaqs = useMemo(() => {
    return FAQ_DATABASE.filter(item => {
      const matchCat = selectedFaqCategory === 'ALL' || item.category === selectedFaqCategory;
      const query = faqSearchQuery.toLowerCase().trim();
      const matchQuery = !query || 
        item.question.toLowerCase().includes(query) || 
        item.answer.toLowerCase().includes(query) ||
        item.keyPoints.some(kp => kp.toLowerCase().includes(query));
      return matchCat && matchQuery;
    });
  }, [selectedFaqCategory, faqSearchQuery]);

  // Filtered Documents by Category and Submission Method
  const filteredDocs = useMemo(() => {
    return REQUIRED_DOCUMENTS_MASTER.filter(item => {
      const matchCat = selectedDocCategory === 'ALL' || item.category === selectedDocCategory;
      let matchMethod = true;
      if (docMethodFilter === 'MYDATA') matchMethod = item.isMyDataAutoScrapable;
      else if (docMethodFilter === 'PORTAL') matchMethod = item.submissionType === 'OFFICIAL_PORTAL';
      else if (docMethodFilter === 'TEMPLATE') matchMethod = item.submissionType === 'SELF_AUTHORED';
      return matchCat && matchMethod;
    });
  }, [selectedDocCategory, docMethodFilter]);

  return (
    <div className="space-y-8 animate-fade-in pb-16">
      {/* 1. Header Banner & Intro */}
      <div className="relative overflow-hidden rounded-3xl bg-slate-900 text-white p-6 sm:p-8 shadow-xl border border-slate-800">
        <div className="absolute -right-12 -bottom-12 w-64 h-64 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none" />
        <div className="absolute right-10 top-8 text-white/5 pointer-events-none hidden lg:block">
          <BookOpen className="w-48 h-48" />
        </div>

        <div className="relative z-10 max-w-3xl space-y-4">
          <div className="flex items-center gap-2 text-xs text-slate-400 font-medium">
            <span className="flex items-center gap-1.5 text-indigo-400 font-semibold">
              <ShieldCheck className="w-4 h-4" />
              2026 정부지원 소상공인 정책자금 실무 로드맵
            </span>
            <span aria-hidden="true" className="text-slate-600">·</span>
            <span className="text-slate-300">
              {profile ? `${profile.businessName || '내 사업장'} 맞춤 지원` : '전국 소상공인 공통'}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight leading-tight text-white">
            정책자금 승인율을 높이는 <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-300 via-indigo-200 to-sky-300">
              신청 절차 · 서류 자동 작성 · 실전 가이드
            </span>
          </h1>

          <p className="text-sm sm:text-base text-slate-300 font-normal leading-relaxed">
            신청 시작부터 은행 대출 입금까지 단계별 행동 요령, 관공서 무료 온라인 즉시 발급 링크,
            심사관의 마음을 움직이는 사업계획서 합격 예시 및 부결 방지 핵심 FAQ를 원스톱으로 확인하세요.
          </p>

          {/* Quick Target Policy Selector */}
          <div className="pt-2">
            <div className="bg-white/5 backdrop-blur-md p-3.5 rounded-2xl border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <Building2 className="w-5 h-5 text-indigo-400 shrink-0" />
                <div>
                  <span className="text-xs text-slate-400 font-medium block">가이드 기준 정책자금 선택</span>
                  <span className="text-sm font-bold text-white">
                    {selectedFund ? selectedFund.title : '기본 정책자금'}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <select
                  value={selectedFundId}
                  onChange={(e) => setSelectedFundId(e.target.value)}
                  className="bg-slate-800 text-white text-xs font-semibold px-3 py-2 rounded-xl border border-slate-700 focus:outline-hidden focus:ring-2 focus:ring-indigo-400 cursor-pointer"
                >
                  {allPolicyOptions.map(f => (
                    <option key={f.id} value={f.id}>
                      {f.title} ({f.agency})
                    </option>
                  ))}
                </select>

                {selectedFund?.applicationUrl && (
                  <a
                    href={selectedFund.applicationUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl transition-all flex items-center gap-1.5 shrink-0 shadow-xs"
                  >
                    <span>공식 신청처</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 1.5. Profile Pre-fill & Document Auto-Fill Card (프로필 정보 기반 신청서 자동 입력 및 서식 프리필) */}
      <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200/90 shadow-sm space-y-5">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-indigo-50 border border-indigo-100/80 text-indigo-600 flex items-center justify-center font-bold shrink-0 shadow-2xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 text-xs text-slate-500 font-medium mb-1">
                <span className="flex items-center gap-1.5 text-emerald-700 font-semibold">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  프로필 연동 완료
                </span>
                <span aria-hidden="true" className="text-slate-300">·</span>
                <span>신청 서류 자동 프리필 시스템</span>
              </div>
              <h2 className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
                대표님 프로필 정보로 정책자금 신청서 원클릭 자동 완성
              </h2>
              <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                입력해 두신 사업자등록번호, 상호, 소재지, 매출액 데이터가 공문서 양식에 100% 자동 기입됩니다.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => {
                setDraftType('APPLICATION_FORM');
                setIsDraftModalOpen(true);
              }}
              className="flex-1 sm:flex-none px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-bold rounded-xl transition-all shadow-xs flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
            >
              <FileCheck2 className="w-4 h-4 text-indigo-300" />
              <span>융자신청서 자동 완성</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setDraftType('BUSINESS_PLAN');
                setIsDraftModalOpen(true);
              }}
              className="flex-1 sm:flex-none px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200/80 text-xs sm:text-sm font-bold rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.98]"
            >
              <PenTool className="w-3.5 h-3.5 text-slate-600" />
              <span>사업계획서 초안 작성</span>
            </button>
          </div>
        </div>

        {/* 6 Pre-filled Profile Fields Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
          {/* 1. 상호명 */}
          <div className="p-3.5 bg-slate-50/80 hover:bg-slate-100/80 rounded-2xl border border-slate-200/70 transition-colors space-y-1">
            <div className="flex items-center gap-1.5 text-slate-500 text-xs font-medium">
              <Building2 className="w-3.5 h-3.5 text-indigo-600" />
              <span>사업자 상호</span>
            </div>
            <p className="text-sm font-bold text-slate-900 truncate" title={profile?.businessName || '대한상사'}>
              {profile?.businessName || '대한상사'}
            </p>
            <span className="text-[11px] text-indigo-600 font-semibold block">✓ 서식 자동 반영</span>
          </div>

          {/* 2. 대표자명 */}
          <div className="p-3.5 bg-slate-50/80 hover:bg-slate-100/80 rounded-2xl border border-slate-200/70 transition-colors space-y-1">
            <div className="flex items-center gap-1.5 text-slate-500 text-xs font-medium">
              <User className="w-3.5 h-3.5 text-indigo-600" />
              <span>대표자 성명</span>
            </div>
            <p className="text-sm font-bold text-slate-900 truncate" title={profile?.name || '홍길동'}>
              {profile?.name || '홍길동'}
            </p>
            <span className="text-[11px] text-indigo-600 font-semibold block">✓ 서식 자동 반영</span>
          </div>

          {/* 3. 사업자등록번호 */}
          <div className="p-3.5 bg-slate-50/80 hover:bg-slate-100/80 rounded-2xl border border-slate-200/70 transition-colors space-y-1">
            <div className="flex items-center gap-1.5 text-slate-500 text-xs font-medium">
              <Hash className="w-3.5 h-3.5 text-indigo-600" />
              <span>사업자등록번호</span>
            </div>
            <p className="text-sm font-bold text-slate-900 truncate font-mono" title={profile?.businessRegistrationNumber || '123-45-67890'}>
              {profile?.businessRegistrationNumber || '123-45-67890'}
            </p>
            <span className="text-[11px] text-indigo-600 font-semibold block">✓ 서식 자동 반영</span>
          </div>

          {/* 4. 사업장 주소 */}
          <div className="p-3.5 bg-slate-50/80 hover:bg-slate-100/80 rounded-2xl border border-slate-200/70 transition-colors space-y-1">
            <div className="flex items-center gap-1.5 text-slate-500 text-xs font-medium">
              <MapPin className="w-3.5 h-3.5 text-indigo-600" />
              <span>사업장 소재지</span>
            </div>
            <p className="text-sm font-bold text-slate-900 truncate" title={profile?.businessAddress || profile?.location || '서울 영등포구 여의대로 128'}>
              {profile?.businessAddress || profile?.location || '서울 영등포구 여의대로 128'}
            </p>
            <span className="text-[11px] text-indigo-600 font-semibold block">✓ 서식 자동 반영</span>
          </div>

          {/* 5. 연 매출액 */}
          <div className="p-3.5 bg-slate-50/80 hover:bg-slate-100/80 rounded-2xl border border-slate-200/70 transition-colors space-y-1">
            <div className="flex items-center gap-1.5 text-slate-500 text-xs font-medium">
              <Coins className="w-3.5 h-3.5 text-indigo-600" />
              <span>기준 연매출</span>
            </div>
            <p className="text-sm font-bold text-slate-900 truncate">
              {profile?.annualRevenue ? `${(profile.annualRevenue / 100000000).toFixed(1)}억원` : '1.5억원'}
            </p>
            <span className="text-[11px] text-emerald-700 font-semibold block">재무표 자동 계산</span>
          </div>

          {/* 6. 희망 신청 금액 */}
          <div className="p-3.5 bg-slate-50/80 hover:bg-slate-100/80 rounded-2xl border border-slate-200/70 transition-colors space-y-1">
            <div className="flex items-center gap-1.5 text-slate-500 text-xs font-medium">
              <Clock className="w-3.5 h-3.5 text-indigo-600" />
              <span>신청 희망액</span>
            </div>
            <p className="text-sm font-bold text-slate-900 truncate">
              {profile?.fundingNeed ? `${(profile.fundingNeed / 10000000).toFixed(0)}천만원` : '5천만원'}
            </p>
            <span className="text-[11px] text-emerald-700 font-semibold block">자금명세 자동 역산</span>
          </div>
        </div>

        {/* Status notice */}
        <div className="pt-3 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-slate-400 shrink-0" />
            <span>
              현재 선택 자금: <strong className="text-slate-800 font-bold">{selectedFund?.title || '소상공인 정책자금'}</strong> ({selectedFund?.agency || '소진공'})
            </span>
          </div>
          <span className="text-slate-400 text-[11px]">
            ※ 공문서 양식에서 직접 수정할 수 있으며 한글(HWP) 및 PDF 양식으로 바로 인쇄 가능합니다.
          </span>
        </div>
      </div>

      {/* 2. Primary Navigation Tabs */}
      <div className="bg-white p-1.5 rounded-2xl border border-slate-200/80 shadow-xs">
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-1.5">
          <button
            type="button"
            onClick={() => setActiveTab('FUND_SPECIFIC')}
            className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'FUND_SPECIFIC'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Building2 className="w-4 h-4 text-indigo-400 shrink-0" />
            <span className="truncate">1. 정책별 상세 요강</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('PROCEDURE')}
            className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'PROCEDURE'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Workflow className="w-4 h-4 text-blue-400 shrink-0" />
            <span className="truncate">2. 온라인 간소화 가이드</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('DOCUMENTS')}
            className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer relative ${
              activeTab === 'DOCUMENTS'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <FileText className="w-4 h-4 text-emerald-500 shrink-0" />
            <span className="truncate">3. 필수 구비 서류 목록</span>
            {checkedDocsCount > 0 && (
              <span className={`text-[10px] px-1.5 py-0.2 rounded-md font-bold ${
                activeTab === 'DOCUMENTS' ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
              }`}>
                {checkedDocsCount}/{totalDocsCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('WRITING_EXAMPLE')}
            className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'WRITING_EXAMPLE'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
            <span className="truncate">4. 온라인 신청 템플릿 생성기</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('FAQ')}
            className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'FAQ'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <HelpCircle className="w-4 h-4 text-amber-500 shrink-0" />
            <span className="truncate">5. 실전 FAQ (12문)</span>
          </button>
        </div>
      </div>

      {/* 3. TAB CONTENT */}

      {/* ========================================================================= */}
      {/* TAB 0: 정책자금별 상세 요강 (자금별 서류·신청기간·온·오프라인 방법·심사기간) */}
      {/* ========================================================================= */}
      {activeTab === 'FUND_SPECIFIC' && (
        <div className="space-y-7 animate-fade-in">
          {/* Fund Chip Selector Bar */}
          <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-sm space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Building2 className="w-4 h-4 text-indigo-600" />
                <h3 className="text-sm font-black text-slate-900">
                  확인할 정책자금 선택 (주요 6대 정부지원금 및 맞춤 진단 자금)
                </h3>
              </div>
              <span className="text-xs text-slate-400">
                원클릭으로 자금별 서류, 기간, 온·오프라인 신청처, 심사기간을 확인하세요.
              </span>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto pb-1.5 pt-1 scrollbar-thin">
              {allPolicyOptions.map((f) => {
                const isSelected = selectedFund?.id === f.id || selectedFund?.title === f.title;
                const isDirect = f.category === '직접대출' || f.agency?.includes('직접');
                return (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setSelectedFundId(f.id)}
                    className={`px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-2 border text-left ${
                      isSelected
                        ? 'bg-slate-900 text-white border-slate-900 shadow-md ring-2 ring-indigo-500/30'
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <span className={`px-1.5 py-0.5 rounded-md text-[10px] font-black shrink-0 ${
                      isSelected
                        ? isDirect ? 'bg-amber-400 text-slate-950' : 'bg-indigo-400 text-slate-950'
                        : isDirect ? 'bg-amber-100 text-amber-800' : 'bg-indigo-100 text-indigo-800'
                    }`}>
                      {isDirect ? '직접대출' : '대리대출'}
                    </span>
                    <span className="font-extrabold max-w-[160px] truncate">{f.title}</span>
                    <span className={`text-[10px] shrink-0 ${isSelected ? 'text-slate-300' : 'text-slate-400'}`}>
                      {f.maxAmount}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Selected Fund Master Hero Banner */}
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white p-6 sm:p-8 border border-indigo-900/40 shadow-xl">
            <div className="absolute right-0 top-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

            <div className="relative z-10 space-y-5">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-3 py-1 bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-xs">
                      {detailedGuide.badge}
                    </span>
                    <span className="px-3 py-1 bg-white/10 text-indigo-200 font-bold text-xs rounded-xl border border-white/10">
                      {detailedGuide.category}
                    </span>
                    <span className="text-xs text-slate-300 font-medium">
                      소관: {detailedGuide.agency}
                    </span>
                  </div>

                  <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                    {detailedGuide.title}
                  </h2>

                  <p className="text-xs sm:text-sm text-slate-300 max-w-2xl leading-relaxed">
                    🎯 <strong className="text-indigo-200">지원 대상:</strong> {detailedGuide.targetAudience}
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-2.5 shrink-0">
                  {detailedGuide.applicationMethods.online.url && (
                    <a
                      href={detailedGuide.applicationMethods.online.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs sm:text-sm font-black rounded-xl transition-all shadow-md shadow-indigo-600/30 flex items-center gap-2 cursor-pointer active:scale-[0.98]"
                    >
                      <span>공식 신청 누리집 바로가기</span>
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      setDraftType('APPLICATION_FORM');
                      setIsDraftModalOpen(true);
                    }}
                    className="px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white text-xs sm:text-sm font-bold rounded-xl transition-all border border-white/15 flex items-center gap-2 cursor-pointer active:scale-[0.98]"
                  >
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>서류 초안 자동 완성</span>
                  </button>
                </div>
              </div>

              {/* 4 Key Specs Metric Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xs space-y-1">
                  <span className="text-[11px] font-bold text-slate-400 block">💰 최대 대출 한도</span>
                  <p className="text-lg sm:text-xl font-black text-white">{detailedGuide.maxAmount}</p>
                  <span className="text-[10px] text-indigo-300">기업당 운전·시설 한도</span>
                </div>

                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xs space-y-1">
                  <span className="text-[11px] font-bold text-slate-400 block">📉 적용 정책 금리</span>
                  <p className="text-lg sm:text-xl font-black text-amber-300">{detailedGuide.interestRate.split('(')[0]}</p>
                  <span className="text-[10px] text-slate-300 truncate block">{detailedGuide.interestRate.includes('(') ? `(${detailedGuide.interestRate.split('(')[1]}` : '분기별 변동금리'}</span>
                </div>

                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xs space-y-1">
                  <span className="text-[11px] font-bold text-slate-400 block">🗓️ 상환 기간 및 방식</span>
                  <p className="text-base sm:text-lg font-black text-white leading-tight">{detailedGuide.repaymentPeriod.split('(')[0]}</p>
                  <span className="text-[10px] text-slate-300 truncate block">{detailedGuide.repaymentPeriod.includes('(') ? `(${detailedGuide.repaymentPeriod.split('(')[1]}` : '거치 후 분할상환'}</span>
                </div>

                <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold text-slate-400">⏱️ 예상 심사 기간</span>
                    {detailedGuide.expectedScreeningTimeline.isFastTrack && (
                      <span className="px-1.5 py-0.2 bg-emerald-500/20 text-emerald-300 text-[10px] font-black rounded-md border border-emerald-400/30">
                        Fast-Track
                      </span>
                    )}
                  </div>
                  <p className="text-lg sm:text-xl font-black text-emerald-300">{detailedGuide.expectedScreeningTimeline.totalDuration}</p>
                  <span className="text-[10px] text-slate-300">서류 완비 기준</span>
                </div>
              </div>
            </div>
          </div>

          {/* SECTION 1: 신청 기간 및 접수 일정 (Application Schedule) */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-5">
            <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-bold shrink-0">
                  <Calendar className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-slate-900">
                    1. 신청 기간 및 접수 일정 안내
                  </h3>
                  <p className="text-xs text-slate-500">
                    연간 예산 배분 일정과 다음 접수 개시일을 확인하고 적시에 신청하세요.
                  </p>
                </div>
              </div>

              <span className="px-3 py-1 bg-blue-50 text-blue-700 text-xs font-black rounded-xl border border-blue-200">
                2026년 공고 기준
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 space-y-1.5">
                <span className="text-[11px] font-bold text-slate-500 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-blue-600" />
                  연간 접수 일정
                </span>
                <p className="text-sm font-black text-slate-900">
                  {detailedGuide.applicationPeriod.schedule}
                </p>
                <span className="text-[11px] text-slate-500 block">
                  공고 주기: {detailedGuide.applicationPeriod.announcementCycle}
                </span>
              </div>

              <div className="p-4 bg-emerald-50/70 rounded-2xl border border-emerald-200 space-y-1.5">
                <span className="text-[11px] font-bold text-emerald-700 flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-emerald-600" />
                  다음 신청 개시일
                </span>
                <p className="text-sm font-black text-emerald-900">
                  {detailedGuide.applicationPeriod.nextOpenDate}
                </p>
                <span className="text-[11px] text-emerald-700 block">
                  {detailedGuide.applicationPeriod.timeNotice}
                </span>
              </div>

              <div className="p-4 bg-indigo-50/70 rounded-2xl border border-indigo-200 space-y-1.5 sm:col-span-2 lg:col-span-1">
                <span className="text-[11px] font-bold text-indigo-700 flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-indigo-600" />
                  신청 준비 골든타임
                </span>
                <p className="text-xs font-bold text-indigo-950 leading-relaxed">
                  개시 당일 오전 09:00 정각 접수를 위해 최소 2일 전 회원가입 및 마이데이터 정보제공 동의를 완료해야 합니다.
                </p>
              </div>
            </div>

            {/* Urgency Tip Banner */}
            <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 flex items-start gap-3 text-xs">
              <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="space-y-1 flex-1">
                <h4 className="font-black text-amber-900">
                  조기 마감 경고 및 신청 행동 요령 (필독)
                </h4>
                <p className="text-amber-800 leading-relaxed">
                  {detailedGuide.applicationPeriod.urgencyTip}
                </p>
              </div>
            </div>
          </div>

          {/* SECTION 2: 신청 방법 (온라인 vs 오프라인 비교 안내) */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-5">
            <div className="flex items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold shrink-0">
                  <Laptop className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-slate-900">
                    2. 신청 방법: 온라인 비대면 접수 vs 오프라인 현장 방문 접수
                  </h3>
                  <p className="text-xs text-slate-500">
                    편리한 온라인 24시간 접수를 권장하며, 온라인 취약 차주는 관할 센터 방문 접수가 가능합니다.
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Online Method */}
              <div className="p-6 rounded-3xl bg-gradient-to-b from-blue-50/60 to-white border border-blue-200 space-y-4 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center justify-between gap-2 pb-3 border-b border-blue-100">
                    <div className="flex items-center gap-2">
                      <span className="p-2 rounded-xl bg-blue-600 text-white font-black text-xs">
                        온라인
                      </span>
                      <div>
                        <h4 className="text-sm font-black text-slate-900">
                          {detailedGuide.applicationMethods.online.portalName}
                        </h4>
                        <span className="text-[11px] text-slate-500">
                          운영시간: {detailedGuide.applicationMethods.online.operatingHours}
                        </span>
                      </div>
                    </div>

                    {detailedGuide.applicationMethods.online.url && (
                      <a
                        href={detailedGuide.applicationMethods.online.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-all shadow-xs flex items-center gap-1 shrink-0"
                      >
                        <span>신청 바로가기</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>

                  {/* Auth Requirement */}
                  <div className="p-3 bg-white rounded-xl border border-blue-100 flex items-center gap-2 text-xs">
                    <ShieldCheck className="w-4 h-4 text-blue-600 shrink-0" />
                    <span className="text-slate-600">
                      <strong>필수 인증:</strong> {detailedGuide.applicationMethods.online.requiredAuth}
                    </span>
                  </div>

                  {/* Steps */}
                  <div className="space-y-2">
                    <span className="text-xs font-black text-slate-800 block">
                      📌 온라인 신청 진행 순서 (5단계)
                    </span>
                    <ol className="space-y-2 text-xs">
                      {detailedGuide.applicationMethods.online.steps.map((step, idx) => (
                        <li key={idx} className="flex items-start gap-2.5 p-2.5 rounded-xl bg-white border border-slate-100">
                          <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-800 flex items-center justify-center font-black text-[11px] shrink-0 mt-0.5">
                            {idx + 1}
                          </span>
                          <span className="text-slate-700 leading-snug font-medium">{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>

                {/* Key Tip */}
                <div className="p-3 bg-blue-100/70 rounded-xl text-xs text-blue-900 flex items-start gap-2 mt-2">
                  <Lightbulb className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    <strong>온라인 꿀팁:</strong> {detailedGuide.applicationMethods.online.keyTips}
                  </p>
                </div>
              </div>

              {/* Offline Method */}
              <div className="p-6 rounded-3xl bg-gradient-to-b from-slate-50 to-white border border-slate-200 space-y-4 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-200">
                    <div className="flex items-center gap-2">
                      <span className="p-2 rounded-xl bg-slate-800 text-white font-black text-xs">
                        오프라인
                      </span>
                      <div>
                        <h4 className="text-sm font-black text-slate-900">
                          {detailedGuide.applicationMethods.offline.locationName}
                        </h4>
                        <span className="text-[11px] text-slate-500">
                          운영시간: {detailedGuide.applicationMethods.offline.operatingHours}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 bg-white px-3 py-1.5 rounded-xl border border-slate-200">
                      <Phone className="w-3.5 h-3.5 text-indigo-600" />
                      <span>{detailedGuide.applicationMethods.offline.phone}</span>
                    </div>
                  </div>

                  {/* Reservation notice */}
                  <div className="p-3 bg-white rounded-xl border border-slate-200 flex items-center gap-2 text-xs">
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
                    <span className="text-slate-600">
                      <strong>방문 요건:</strong> {detailedGuide.applicationMethods.offline.reservationNotice} (전화 사전 예약 권장)
                    </span>
                  </div>

                  {/* Steps */}
                  <div className="space-y-2">
                    <span className="text-xs font-black text-slate-800 block">
                      📌 현장 방문 접수 절차
                    </span>
                    <ol className="space-y-2 text-xs">
                      {detailedGuide.applicationMethods.offline.steps.map((step, idx) => (
                        <li key={idx} className="flex items-start gap-2.5 p-2.5 rounded-xl bg-white border border-slate-200">
                          <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-800 flex items-center justify-center font-black text-[11px] shrink-0 mt-0.5">
                            {idx + 1}
                          </span>
                          <span className="text-slate-700 leading-snug font-medium">{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>

                  {/* Bring items */}
                  <div className="space-y-1.5 pt-1">
                    <span className="text-xs font-black text-slate-800 block">
                      💼 방문 시 필수 지참물 목록:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {detailedGuide.applicationMethods.offline.bringItems.map((item, idx) => (
                        <span key={idx} className="px-2.5 py-1 bg-white border border-slate-200 text-slate-800 text-[11px] font-bold rounded-lg shadow-2xs">
                          ✓ {item}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Key Tip */}
                <div className="p-3 bg-slate-100 rounded-xl text-xs text-slate-800 flex items-start gap-2 mt-2">
                  <Lightbulb className="w-4 h-4 text-slate-700 shrink-0 mt-0.5" />
                  <p className="leading-relaxed">
                    <strong>현장 상담 팁:</strong> {detailedGuide.applicationMethods.offline.keyTips}
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* SECTION 3: 예상 심사 기간 & 단계별 심사 프로세스 타임라인 */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-slate-900">
                    3. 예상 심사 기간 및 단계별 심사 프로세스
                  </h3>
                  <p className="text-xs text-slate-500">
                    접수부터 통장 입금(대출 실행)까지의 전 심사 단계와 기관별 소요 시간을 파악하세요.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 font-bold">총 소요 예상:</span>
                <span className="px-3 py-1 bg-emerald-100 text-emerald-900 font-black text-xs rounded-xl border border-emerald-200">
                  {detailedGuide.expectedScreeningTimeline.totalDuration}
                </span>
              </div>
            </div>

            {/* Stages timeline cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {detailedGuide.expectedScreeningTimeline.stages.map((stage, idx) => (
                <div key={idx} className="p-5 rounded-3xl bg-slate-50 border border-slate-200/80 hover:border-indigo-300 transition-all space-y-3 flex flex-col justify-between">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="w-8 h-8 rounded-xl bg-indigo-600 text-white font-black text-xs flex items-center justify-center shadow-xs">
                        {stage.stepNumber}
                      </span>
                      <span className="px-2.5 py-0.5 rounded-lg bg-indigo-50 text-indigo-700 text-[10px] font-black border border-indigo-200">
                        {stage.institution}
                      </span>
                    </div>

                    <h4 className="text-sm font-black text-slate-900 leading-snug">
                      {stage.stageName}
                    </h4>

                    <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-bold">
                      <Clock className="w-3.5 h-3.5" />
                      <span>소요 기간: {stage.duration}</span>
                    </div>

                    <p className="text-xs text-slate-600 leading-relaxed">
                      {stage.description}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-200/80">
                    <span className="text-[11px] font-black text-slate-800 block mb-0.5">
                      신청자 행동 지침:
                    </span>
                    <span className="text-[11px] text-indigo-700 font-bold bg-white px-2 py-1 rounded-lg border border-slate-200 block truncate">
                      👉 {stage.actionRequired}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* SECTION 4: 이 정책자금 전용 필수 구비 서류 목록 (Required Documents Checklist) */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold shrink-0">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-black text-slate-900">
                    4. {detailedGuide.title} 제출 필수 서류 목록
                  </h3>
                  <p className="text-xs text-slate-500">
                    공통 기본 서류와 함께 본 자금 전용 특화 서류를 빠짐없이 구비하세요.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setDraftType('APPLICATION_FORM');
                    setIsDraftModalOpen(true);
                  }}
                  className="px-3.5 py-1.5 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition-colors flex items-center gap-1.5 cursor-pointer shadow-xs"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>신청서 서식 초안 생성</span>
                </button>
              </div>
            </div>

            {/* A. 자금별 특화 필수 서류 (Specific Documents) */}
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-lg bg-amber-100 text-amber-900 font-black text-xs">
                  본 자금 전용 특화 서류
                </span>
                <span className="text-xs text-slate-500">
                  해당 요건을 입증하기 위해 반드시 추가 제출해야 하는 필수 서류입니다.
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {detailedGuide.requiredDocuments.specific.map((doc) => {
                  const isChecked = !!checkedDocIds[doc.id];
                  return (
                    <div
                      key={doc.id}
                      onClick={() => toggleDocCheck(doc.id)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer select-none space-y-2 ${
                        isChecked
                          ? 'bg-emerald-50/50 border-emerald-300 shadow-2xs'
                          : 'bg-white border-amber-200/80 hover:border-amber-400 shadow-xs'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}}
                            className="w-4 h-4 rounded-md text-emerald-600 focus:ring-emerald-500 cursor-pointer mt-0.5"
                          />
                          <div>
                            <span className={`text-xs font-black block ${isChecked ? 'text-slate-400 line-through' : 'text-slate-900'}`}>
                              {doc.name}
                            </span>
                            <span className="text-[10px] text-slate-500">
                              발급처: {doc.issuanceAgency}
                            </span>
                          </div>
                        </div>

                        <span className={`px-2 py-0.5 rounded-md text-[10px] font-black shrink-0 ${
                          doc.mandatory ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {doc.mandatory ? '필수 제출' : '해당시 제출'}
                        </span>
                      </div>

                      <p className="text-[11px] text-slate-600 bg-slate-50 p-2 rounded-xl border border-slate-100 leading-snug">
                        <strong>제출 목적:</strong> {doc.purpose}
                      </p>

                      <p className="text-[11px] text-amber-800 bg-amber-50/80 p-2 rounded-xl border border-amber-100 leading-snug">
                        💡 <strong>작성 팁:</strong> {doc.tip}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* B. 공통 기본 필수 서류 (Common Documents) */}
            <div className="space-y-3 pt-4 border-t border-slate-100">
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-1 rounded-lg bg-blue-100 text-blue-900 font-black text-xs">
                  공통 기본 필수 서류 (전국 공통)
                </span>
                <span className="text-xs text-slate-500">
                  모든 정책자금에 공통으로 요구되는 관공서 증명서입니다.
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {detailedGuide.requiredDocuments.common.map((doc) => {
                  const isChecked = !!checkedDocIds[doc.id];
                  return (
                    <div
                      key={doc.id}
                      onClick={() => toggleDocCheck(doc.id)}
                      className={`p-4 rounded-2xl border transition-all cursor-pointer select-none space-y-2 ${
                        isChecked
                          ? 'bg-emerald-50/50 border-emerald-300 shadow-2xs'
                          : 'bg-white border-slate-200 hover:border-blue-300 shadow-xs'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}}
                            className="w-4 h-4 rounded-md text-emerald-600 focus:ring-emerald-500 cursor-pointer mt-0.5"
                          />
                          <div>
                            <span className={`text-xs font-black block ${isChecked ? 'text-slate-400 line-through' : 'text-slate-900'}`}>
                              {doc.name}
                            </span>
                            <span className="text-[10px] text-slate-500">
                              발급처: {doc.agency} · 유효기간: {doc.validity}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-1">
                          {doc.isFree && (
                            <span className="px-1.5 py-0.5 bg-blue-50 text-blue-700 text-[10px] font-bold rounded-md">
                              무료
                            </span>
                          )}
                          {doc.portalUrl && (
                            <a
                              href={doc.portalUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              onClick={(e) => e.stopPropagation()}
                              className="p-1 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-indigo-600"
                              title="발급처 바로가기"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                            </a>
                          )}
                        </div>
                      </div>

                      <p className="text-[11px] text-slate-600 bg-slate-50 p-2 rounded-xl border border-slate-100 leading-snug">
                        💡 <strong>실무 발급 팁:</strong> {doc.tip}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* SECTION 5: 심사관 언더라이팅 평가 기준 (Underwriting Criteria) */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <div className="w-10 h-10 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold shrink-0">
                <Scale className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-slate-900">
                  5. 심사관 핵심 언더라이팅 평가 기준 및 합격 전략
                </h3>
                <p className="text-xs text-slate-500">
                  심사역이 서류 심사와 현장 실사에서 가중치를 두어 검토하는 핵심 지표입니다.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {detailedGuide.underwritingCriteria.map((item, idx) => (
                <div key={idx} className="p-4 rounded-2xl bg-purple-50/40 border border-purple-100 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-slate-900">
                      {item.criterion}
                    </span>
                    <span className={`px-2 py-0.5 rounded-md text-[10px] font-black ${
                      item.importance === '최고'
                        ? 'bg-rose-100 text-rose-800'
                        : item.importance === '높음'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-slate-200 text-slate-700'
                    }`}>
                      중요도: {item.importance}
                    </span>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    <strong>심사 기준:</strong> {item.standard}
                  </p>

                  <p className="text-[11px] text-purple-900 bg-white p-2.5 rounded-xl border border-purple-100 leading-snug">
                    🎯 <strong>합격 공략 팁:</strong> {item.strategyTip}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* SECTION 6: 신청 과정 애로사항 및 부결 대책 (Troubleshooting Guide) */}
          <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
              <div className="w-10 h-10 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold shrink-0">
                <AlertCircle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-slate-900">
                  6. 정책자금 신청 시 자주 겪는 애로사항 및 해결 솔루션
                </h3>
                <p className="text-xs text-slate-500">
                  신청 과정에서 차주들이 가장 많이 부딪히는 문제와 즉각적인 해결 방안입니다.
                </p>
              </div>
            </div>

            <div className="space-y-3">
              {detailedGuide.troubleshootingGuide.map((item, idx) => (
                <div key={idx} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                  <div className="flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                      !
                    </span>
                    <h4 className="text-xs sm:text-sm font-black text-rose-900">
                      문제: {item.problem}
                    </h4>
                  </div>

                  <p className="text-xs text-slate-600 pl-7 leading-relaxed">
                    <strong>발생 원인:</strong> {item.cause}
                  </p>

                  <div className="ml-7 p-3 bg-white rounded-xl border border-emerald-200 flex items-start gap-2 text-xs text-emerald-900 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-emerald-800">즉각 해결 솔루션:</strong> {item.actionableSolution}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 1: 5단계 상세 신청 절차 & 온라인 간소화 가이드 (Fast-Track Roadmap) */}
      {/* ========================================================================= */}
      {activeTab === 'PROCEDURE' && (
        <div className="space-y-6 animate-fade-in">
          {/* Target Fund Banner */}
          {selectedFund && (
            <div className="p-4 sm:p-5 bg-gradient-to-r from-blue-50 via-indigo-50 to-white rounded-3xl border border-blue-200/80 shadow-xs flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="flex items-center gap-3.5">
                <span className="p-3 bg-blue-600 text-white rounded-2xl font-black text-sm shadow-md shadow-blue-600/20">
                  {selectedFund.category || '정책자금'}
                </span>
                <div>
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <h3 className="text-base sm:text-lg font-black text-slate-900">{selectedFund.title}</h3>
                    <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-[10px] font-black rounded-md">
                      {selectedFund.agency}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600">
                    한도: <strong className="text-slate-900 font-bold">{selectedFund.maxAmount}</strong> · 예상 금리: <strong className="text-blue-700 font-bold">{selectedFund.interestRate}</strong> · 접수 방식: 온라인 원스톱 접수 및 보증기관 연계
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2.5">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600 bg-white/80 px-3 py-1.5 rounded-xl border border-slate-200">
                  <Clock className="w-3.5 h-3.5 text-blue-600" />
                  <span>예상 소요: 약 2~3주 (마이데이터 활용 시 1주일 단축)</span>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('WRITING_EXAMPLE');
                  }}
                  className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  <span>온라인 신청 템플릿 생성</span>
                </button>
              </div>
            </div>
          )}

          {/* ONLINE FAST-TRACK GUIDE SECTION: 온라인 신청 초간소화 5대 가이드라인 */}
          <div className="bg-gradient-to-br from-indigo-900 via-slate-900 to-blue-950 text-white rounded-3xl p-6 sm:p-7 shadow-xl border border-indigo-800/80 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shrink-0 shadow-md">
                  <Zap className="w-5 h-5 fill-slate-950" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-amber-400/20 text-amber-300 text-[10px] font-black border border-amber-400/30">
                      초스피드 승인 비법
                    </span>
                    <h3 className="text-base sm:text-lg font-black text-white">
                      온라인 신청 절차를 10배 빠르게 끝내는 초간소화 5대 가이드라인
                    </h3>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5">
                    서류 발급 방문 없이, 공공 마이데이터와 비대면 전자약정으로 신청부터 대출 실행까지 당일 원스톱 처리하는 실무 팁입니다.
                  </p>
                </div>
              </div>

              <span className="text-[11px] font-bold text-indigo-300 bg-white/10 px-3 py-1.5 rounded-xl border border-white/10 self-start sm:self-auto shrink-0">
                ⏱️ 서류 준비 시간: 기존 3일 → <strong>3분 단축</strong>
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Card 1: 마이데이터 스크래핑 */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-400/40 transition-all space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-lg bg-amber-400 text-slate-950 flex items-center justify-center text-xs font-black">
                    1
                  </span>
                  <span className="text-[10px] font-black px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    종이 서류 0건
                  </span>
                </div>
                <h4 className="text-sm font-black text-white">
                  공공 마이데이터(MyData) 원스톱 스크래핑
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  홈택스·정부24 일일이 발급받아 스캔하지 마세요. 온라인 신청 화면에서 <strong>'간편인증(카카오/PASS/토스)' 1회 동의</strong>만 하면 국세청·건보공단 7대 핵심 서류가 30초 만에 공단 전산으로 자동 전송됩니다.
                </p>
                <div className="pt-2 border-t border-white/10 text-[11px] text-amber-300 font-medium">
                  💡 자동연동: 사업자등록, 부가세, 소득금액, 국세/지방세 완납
                </div>
              </div>

              {/* Card 2: 사전 환경 세팅 */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-400/40 transition-all space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-lg bg-indigo-500 text-white flex items-center justify-center text-xs font-black">
                    2
                  </span>
                  <span className="text-[10px] font-black px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                    사전 준비
                  </span>
                </div>
                <h4 className="text-sm font-black text-white">
                  접수 포털(소진공/중진공) 사전 환경 세팅
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  접수 당일 브라우저 팝업 차단이나 인증서 오류로 튕기면 접수가 마감됩니다. <strong>Chrome 또는 Edge 브라우저</strong>에서 전날 포털 회원가입과 보안 모듈을 미리 설치하고, <strong>대표자 개인 공동인증서</strong>를 등록해 두세요.
                </p>
                <div className="pt-2 border-t border-white/10 text-[11px] text-indigo-300 font-medium">
                  💡 개인사업자는 대표자 개인인증서, 법인은 법인 범용인증서 필수
                </div>
              </div>

              {/* Card 3: 5분컷 광클 신청 */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-400/40 transition-all space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-lg bg-rose-500 text-white flex items-center justify-center text-xs font-black">
                    3
                  </span>
                  <span className="text-[10px] font-black px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30">
                    선착순 마감 대응
                  </span>
                </div>
                <h4 className="text-sm font-black text-white">
                  오픈일 9시 정각 '5분 컷' 온라인 신청 비법
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  인기 정책자금은 접수 개시 10~30분 만에 권역별 예산이 소진됩니다. 본 시스템의 <strong>[4. 템플릿 생성기]에서 작성된 사업계획서 텍스트를 메모장에 미리 복사</strong>해 두고, 접수창이 열리자마자 붙여넣기(Ctrl+V)로 5분 안에 접수를 끝내세요.
                </p>
                <div className="pt-2 border-t border-white/10 text-[11px] text-rose-300 font-medium">
                  💡 사업장 임대차계약서는 10MB 이하 단일 PDF로 사전 압축
                </div>
              </div>

              {/* Card 4: 무방문 비대면 전자약정 */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-400/40 transition-all space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500 text-white flex items-center justify-center text-xs font-black">
                    4
                  </span>
                  <span className="text-[10px] font-black px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    무방문 원스톱
                  </span>
                </div>
                <h4 className="text-sm font-black text-white">
                  센터·은행 무방문 100% 모바일 전자약정
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  지역재단이나 은행 지점에 찾아갈 필요가 없습니다. 심사 승인 후 <strong>카카오톡/PASS 알림톡 링크를 통해 모바일로 전자서명 및 보증료 계좌이체</strong>를 완료하면, 전자보증서가 선택 은행으로 즉시 자동 송부되어 당일 입금됩니다.
                </p>
                <div className="pt-2 border-t border-white/10 text-[11px] text-emerald-300 font-medium">
                  💡 주거래 은행 모바일 앱(KB스타뱅킹, 신한SOL 등)으로 약정 체결
                </div>
              </div>

              {/* Card 5: 사전 1분 자가진단 */}
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 hover:border-amber-400/40 transition-all space-y-2">
                <div className="flex items-center justify-between">
                  <span className="w-6 h-6 rounded-lg bg-amber-500 text-white flex items-center justify-center text-xs font-black">
                    5
                  </span>
                  <span className="text-[10px] font-black px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                    부결 방지
                  </span>
                </div>
                <h4 className="text-sm font-black text-white">
                  신청 직전 1분 자가진단 체크 (즉시 부결 방지)
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  온라인 시스템은 <strong>체납 또는 신용 연체가 있으면 1초 만에 자동 반려</strong>합니다. 신청 당일 홈택스에서 국세 체납이 0원인지, 10일 이내에 단기 카드론·현금서비스를 새로 받지 않았는지 반드시 확인 후 접수 버튼을 클릭하세요.
                </p>
                <div className="pt-2 border-t border-white/10 text-[11px] text-amber-300 font-medium">
                  💡 소진공 직접대출 최근 6개월 부결 이력 차주는 대리대출로 우회
                </div>
              </div>

              {/* Card 6: 템플릿 연동 바로가기 */}
              <div className="p-4 rounded-2xl bg-indigo-950/80 border border-indigo-700/60 flex flex-col justify-between space-y-3">
                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-indigo-300 uppercase tracking-wider block">
                    One-Click Template Hub
                  </span>
                  <h4 className="text-sm font-black text-white">
                    내 사업장 맞춤 6대 정부 표준 서식 즉시 생성
                  </h4>
                  <p className="text-xs text-indigo-200 leading-relaxed">
                    상호명, 대표자명, 연매출, 희망금액이 자동으로 주입된 융자신청서, 사업계획서, 소요명세서를 즉시 생성할 수 있습니다.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setActiveTab('WRITING_EXAMPLE')}
                  className="w-full py-2.5 px-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 font-black rounded-xl text-xs transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 fill-slate-950" />
                  <span>표준 템플릿 생성기 열기</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* 5-Step Visual Timeline Header */}
          <div className="flex items-center justify-between pt-2">
            <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-600" />
              정책자금 신청 5단계 표준 진행 로드맵 & 단계별 심사 전략
            </h4>
            <span className="text-xs text-slate-500">
              총 소요 기간: 평균 2~3주 (직접대출 기준)
            </span>
          </div>

          {/* 5-Step Visual Timeline */}
          <div className="space-y-4">
            {/* Step 1 */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:border-blue-300 transition-all">
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 pb-4 border-b border-slate-100">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-black text-lg shrink-0 shadow-md shadow-blue-600/20">
                    01
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-black text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md border border-blue-200">
                        1단계 (온라인 접수)
                      </span>
                      <span className="text-xs text-slate-400 font-bold flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" /> 소요: 당일 즉시 (온라인 24시간)
                      </span>
                    </div>
                    <h4 className="text-lg font-black text-slate-900">
                      소상공인24 또는 소진공 포털 사전 자가진단 및 신청 접수
                    </h4>
                    <p className="text-xs text-slate-500 mt-1">
                      주관 플랫폼: 소상공인24 (sbiz24.kr) 또는 소상공인정책자금 누리집 (ols.semas.or.kr)
                    </p>
                  </div>
                </div>

                <a
                  href="https://ols.semas.or.kr"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-slate-100 hover:bg-blue-50 text-slate-700 hover:text-blue-700 rounded-xl text-xs font-bold transition-all border border-slate-200 flex items-center gap-1.5 self-start shrink-0"
                >
                  <span>소진공 접수처 바로가기</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 text-xs">
                <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-1.5">
                  <span className="font-black text-slate-800 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-600" /> 핵심 행동 요령
                  </span>
                  <p className="text-slate-600 leading-relaxed">
                    공동인증서(또는 간편인증)로 로그인 후, 기본 사업장 현황(매출, 상시근로자 수, 업종)을 입력하고 자격 자가진단표를 작성합니다.
                  </p>
                </div>

                <div className="p-3.5 bg-rose-50/70 rounded-2xl border border-rose-100 space-y-1.5">
                  <span className="font-black text-rose-800 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-600" /> 흔히 범하는 치명적 실수
                  </span>
                  <p className="text-rose-700 leading-relaxed">
                    공고 개시일 오전 접속자가 폭주하여 당일 예산이 조기 소진될 수 있습니다. 신청 당일 전 회원가입과 본인인증을 미리 완료해두지 않으면 기회를 놓칩니다.
                  </p>
                </div>

                <div className="p-3.5 bg-blue-50/70 rounded-2xl border border-blue-100 space-y-1.5">
                  <span className="font-black text-blue-800 flex items-center gap-1.5">
                    <Lightbulb className="w-4 h-4 text-blue-600" /> 전문가 합격 꿀팁
                  </span>
                  <p className="text-blue-700 leading-relaxed">
                    "공공 마이데이터 정보 제공 동의"를 체크하면 국세청·건보공단 서류 10여 종이 자동 스크래핑 제출되어 별도 업로드 번거로움이 없습니다.
                  </p>
                </div>
              </div>
            </div>

            {/* Step 2 */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:border-blue-300 transition-all">
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 pb-4 border-b border-slate-100">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-black text-lg shrink-0 shadow-md shadow-indigo-600/20">
                    02
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-black text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-200">
                        2단계 (적격 심사)
                      </span>
                      <span className="text-xs text-slate-400 font-bold flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" /> 소요: 즉시 ~ 2영업일
                      </span>
                    </div>
                    <h4 className="text-lg font-black text-slate-900">
                      정책자금 지원대상 확인서 발급 (대리대출) 또는 공단 자체심사 (직접대출)
                    </h4>
                    <p className="text-xs text-slate-500 mt-1">
                      주관 기관: 소상공인시장진흥공단 지역센터 및 전산망
                    </p>
                  </div>
                </div>

                <div className="text-xs font-bold text-slate-500 bg-slate-50 px-3 py-2 rounded-xl border border-slate-200 self-start">
                  유효기간: 발급일로부터 60일
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 text-xs">
                <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-1.5">
                  <span className="font-black text-slate-800 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-600" /> 핵심 행동 요령
                  </span>
                  <p className="text-slate-600 leading-relaxed">
                    대리대출의 경우 공단 시스템에서 "정책자금 지원대상 확인서"가 전자 발급됩니다. PDF를 저장하고 전자문서 지갑 번호를 확인합니다.
                  </p>
                </div>

                <div className="p-3.5 bg-rose-50/70 rounded-2xl border border-rose-100 space-y-1.5">
                  <span className="font-black text-rose-800 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-600" /> 흔히 범하는 치명적 실수
                  </span>
                  <p className="text-rose-700 leading-relaxed">
                    확인서는 "자금 추천서"일 뿐 최종 대출 승인이 아닙니다. 확인서만 받고 보증재단/은행 접수를 미루다 60일 유효기간이 지나 취소되는 사례가 많습니다.
                  </p>
                </div>

                <div className="p-3.5 bg-indigo-50/70 rounded-2xl border border-indigo-100 space-y-1.5">
                  <span className="font-black text-indigo-800 flex items-center gap-1.5">
                    <Lightbulb className="w-4 h-4 text-indigo-600" /> 전문가 합격 꿀팁
                  </span>
                  <p className="text-indigo-700 leading-relaxed">
                    직접대출 상품은 이 단계에서 공단 심사관이 배정되어 서류 보완 요청을 보낼 수 있으므로, 문자와 알림톡을 실시간 모니터링하세요.
                  </p>
                </div>
              </div>
            </div>

            {/* Step 3 */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:border-blue-300 transition-all">
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 pb-4 border-b border-slate-100">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-sky-600 text-white flex items-center justify-center font-black text-lg shrink-0 shadow-md shadow-sky-600/20">
                    03
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-black text-sky-600 bg-sky-50 px-2 py-0.5 rounded-md border border-sky-200">
                        3단계 (보증 심사 & 실사)
                      </span>
                      <span className="text-xs text-slate-400 font-bold flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" /> 소요: 약 5 ~ 10영업일
                      </span>
                    </div>
                    <h4 className="text-lg font-black text-slate-900">
                      신용보증재단/신보 신용보증 심사 및 사업장 현장 실사
                    </h4>
                    <p className="text-xs text-slate-500 mt-1">
                      주관 기관: 사업장 관할 지역신용보증재단 지점 (또는 신용보증기금 지점)
                    </p>
                  </div>
                </div>

                <span className="text-xs font-black text-sky-800 bg-sky-50 px-3 py-1.5 rounded-xl border border-sky-200 self-start">
                  승인율을 좌우하는 핵심 관문
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 text-xs">
                <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-1.5">
                  <span className="font-black text-slate-800 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-600" /> 핵심 행동 요령
                  </span>
                  <p className="text-slate-600 leading-relaxed">
                    지역신보 모바일 앱(또는 방문)으로 보증 신청서를 제출하고, 대표자 신용평가 및 사업장 현장 실사에 성실히 응대합니다.
                  </p>
                </div>

                <div className="p-3.5 bg-rose-50/70 rounded-2xl border border-rose-100 space-y-1.5">
                  <span className="font-black text-rose-800 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-600" /> 흔히 범하는 치명적 실수
                  </span>
                  <p className="text-rose-700 leading-relaxed">
                    실사 담당자가 사전 연락 없이 불시에 방문했을 때 사업장 문이 닫혀 있거나, 상호 간판이 사업자등록증과 다르면 실격 사유가 됩니다.
                  </p>
                </div>

                <div className="p-3.5 bg-sky-50/70 rounded-2xl border border-sky-100 space-y-1.5">
                  <span className="font-black text-sky-800 flex items-center gap-1.5">
                    <Lightbulb className="w-4 h-4 text-sky-600" /> 전문가 합격 꿀팁
                  </span>
                  <p className="text-sky-700 leading-relaxed">
                    사업장 내 사업자등록증 정위치 비치, 카드 단말기 최근 전표 보관, 현장 실사 시 지속적인 영업 의지와 구체적 매출처를 차분히 설명하세요.
                  </p>
                </div>
              </div>
            </div>

            {/* Step 4 */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:border-blue-300 transition-all">
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 pb-4 border-b border-slate-100">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black text-lg shrink-0 shadow-md shadow-emerald-600/20">
                    04
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                        4단계 (보증서 발급)
                      </span>
                      <span className="text-xs text-slate-400 font-bold flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" /> 소요: 1 ~ 2영업일
                      </span>
                    </div>
                    <h4 className="text-lg font-black text-slate-900">
                      신용보증서(전자보증서) 발급 및 보증료 납부
                    </h4>
                    <p className="text-xs text-slate-500 mt-1">
                      주관 기관: 지역신용보증재단 → 취급 시중은행 전산망 연계
                    </p>
                  </div>
                </div>

                <div className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-2 rounded-xl border border-emerald-200 self-start">
                  보증료율: 연 0.5% ~ 1.2% 수준
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 text-xs">
                <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-1.5">
                  <span className="font-black text-slate-800 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-600" /> 핵심 행동 요령
                  </span>
                  <p className="text-slate-600 leading-relaxed">
                    보증 승인 알림톡을 확인하고 모바일 전자약정 체결 후 보증료를 지정 계좌로 납부합니다. 전자보증서가 선택한 은행으로 자동 전송됩니다.
                  </p>
                </div>

                <div className="p-3.5 bg-rose-50/70 rounded-2xl border border-rose-100 space-y-1.5">
                  <span className="font-black text-rose-800 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-600" /> 흔히 범하는 치명적 실수
                  </span>
                  <p className="text-rose-700 leading-relaxed">
                    보증 승인 기한 내(통상 3영업일) 전자서명이나 보증료 납부를 마치지 않으면 보증 승인이 자동 철회되어 처음부터 다시 접수해야 합니다.
                  </p>
                </div>

                <div className="p-3.5 bg-emerald-50/70 rounded-2xl border border-emerald-100 space-y-1.5">
                  <span className="font-black text-emerald-800 flex items-center gap-1.5">
                    <Lightbulb className="w-4 h-4 text-emerald-600" /> 전문가 합격 꿀팁
                  </span>
                  <p className="text-emerald-700 leading-relaxed">
                    보증서가 발급되면 지체 없이 사전에 조율된 대출 실행 은행 지점(주거래 은행) 담당자에게 "보증서 발급 완료"를 유선으로 알리세요.
                  </p>
                </div>
              </div>
            </div>

            {/* Step 5 */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:border-blue-300 transition-all">
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 pb-4 border-b border-slate-100">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-amber-600 text-white flex items-center justify-center font-black text-lg shrink-0 shadow-md shadow-amber-600/20">
                    05
                  </div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs font-black text-amber-600 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
                        5단계 (최종 대출 실행)
                      </span>
                      <span className="text-xs text-slate-400 font-bold flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5" /> 소요: 2 ~ 3영업일
                      </span>
                    </div>
                    <h4 className="text-lg font-black text-slate-900">
                      은행 대출 약정 체결 및 최종 자금 입금 (대출 실행)
                    </h4>
                    <p className="text-xs text-slate-500 mt-1">
                      주관 기관: 취급 시중은행 (KB국민, 신한, 하나, 우리, NH농협, IBK기업, DGB대구, BNK부산 등)
                    </p>
                  </div>
                </div>

                <span className="text-xs font-black text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200 self-start flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> 대출금 계좌 입금 완료
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 text-xs">
                <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-1.5">
                  <span className="font-black text-slate-800 flex items-center gap-1.5">
                    <CheckCircle className="w-4 h-4 text-emerald-600" /> 핵심 행동 요령
                  </span>
                  <p className="text-slate-600 leading-relaxed">
                    은행 영업점 방문 또는 은행 모바일 뱅킹 앱을 통해 대출 약정서에 서명하고, 우대금리 요건(가맹점 결제계좌, 자동이체 등)을 등록합니다.
                  </p>
                </div>

                <div className="p-3.5 bg-rose-50/70 rounded-2xl border border-rose-100 space-y-1.5">
                  <span className="font-black text-rose-800 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-rose-600" /> 흔히 범하는 치명적 실수
                  </span>
                  <p className="text-rose-700 leading-relaxed">
                    보증서가 나왔더라도 은행 최종 심사 시점에 신규 카드론이나 연체 이력이 발생하면 은행 내규에 의해 대출 실행이 최종 거절될 수 있습니다.
                  </p>
                </div>

                <div className="p-3.5 bg-amber-50/70 rounded-2xl border border-amber-100 space-y-1.5">
                  <span className="font-black text-amber-800 flex items-center gap-1.5">
                    <Lightbulb className="w-4 h-4 text-amber-600" /> 전문가 합격 꿀팁
                  </span>
                  <p className="text-amber-700 leading-relaxed">
                    지자체 이차보전(이자 1.0~2.5%p 지원) 연계 상품인지 창구에서 확인하세요. 실부담 금리가 연 1~2%대로 대폭 낮아집니다.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: 필수 제출 서류 목록 & 발급처 (Required Documents Checklist) */}
      {/* ========================================================================= */}
      {activeTab === 'DOCUMENTS' && (
        <div className="space-y-6 animate-fade-in">
          {/* Progress Gauge Card */}
          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <span className="text-xs font-black text-indigo-600 uppercase tracking-wider block">
                  Document Readiness Tracker
                </span>
                <h3 className="text-lg font-black text-slate-900">
                  필수 제출 서류 준비 진행도
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  신청 전 서류를 완비해 두면 심사 소요 기간이 5일 이상 단축됩니다.
                </p>
              </div>

              <div className="flex items-center gap-3">
                <span className="text-xl font-black text-indigo-600">
                  {checkedDocsCount} / {totalDocsCount}건 완료
                </span>
                <span className="text-xs font-black px-3 py-1 rounded-xl bg-indigo-50 text-indigo-700 border border-indigo-200">
                  {docProgressPercent}%
                </span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-500 via-indigo-600 to-emerald-500 transition-all duration-500 rounded-full"
                style={{ width: `${docProgressPercent}%` }}
              />
            </div>

            {/* Quick Actions */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const allTrue = REQUIRED_DOCUMENTS_MASTER.reduce((acc, d) => ({ ...acc, [d.id]: true }), {});
                    setCheckedDocIds(allTrue);
                  }}
                  className="text-xs font-bold text-slate-600 hover:text-indigo-600 bg-slate-50 hover:bg-indigo-50 px-3 py-1.5 rounded-lg transition-colors cursor-pointer border border-slate-200"
                >
                  모두 완료 처리
                </button>
                <button
                  type="button"
                  onClick={() => setCheckedDocIds({})}
                  className="text-xs font-bold text-slate-600 hover:text-rose-600 bg-slate-50 hover:bg-rose-50 px-3 py-1.5 rounded-lg transition-colors cursor-pointer border border-slate-200"
                >
                  선택 초기화
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    let text = `[정부지원 소상공인 정책자금 필수 제출 서류 목록]\n\n`;
                    REQUIRED_DOCUMENTS_MASTER.forEach((d, i) => {
                      const done = checkedDocIds[d.id] ? '[완료]' : '[미발급]';
                      text += `${i + 1}. ${d.name} ${done}\n`;
                      text += `   - 발급처: ${d.agency} (${d.portalUrl || '현장/자체'})\n`;
                      text += `   - 유효기간: ${d.validity} / 발급비용: ${d.isFree ? '무료' : '유료'}\n`;
                      text += `   - 발급경로: ${d.samplePath}\n\n`;
                    });
                    handleCopyText(text, 'DOCS_LIST');
                  }}
                  className="text-xs font-bold text-slate-700 hover:text-indigo-600 bg-white px-3 py-1.5 rounded-lg transition-colors cursor-pointer border border-slate-200 flex items-center gap-1.5"
                >
                  {copiedSection === 'DOCS_LIST' ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>서류 목록 텍스트 복사</span>
                </button>

                <button
                  type="button"
                  onClick={() => window.print()}
                  className="text-xs font-bold text-slate-700 hover:text-indigo-600 bg-white px-3 py-1.5 rounded-lg transition-colors cursor-pointer border border-slate-200 flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>인쇄하기</span>
                </button>
              </div>
            </div>
          </div>

          {/* MyData vs Direct Prep 3-Way Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            <div 
              onClick={() => setDocMethodFilter(docMethodFilter === 'MYDATA' ? 'ALL' : 'MYDATA')}
              className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                docMethodFilter === 'MYDATA' 
                  ? 'bg-blue-50/90 border-blue-400 ring-2 ring-blue-400/20 shadow-sm' 
                  : 'bg-white border-slate-200 hover:border-blue-300 shadow-2xs'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-black text-blue-700 flex items-center gap-1.5">
                  <Zap className="w-4 h-4 fill-blue-600 text-blue-600" />
                  공공 마이데이터 자동제출
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-blue-100 text-blue-800">
                  {myDataDocsCount}종 (무서류)
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                간편인증 1회로 국세청·행안부·건보공단 전산에서 10초 만에 자동 수집 전송
              </p>
              <span className="text-[10px] text-blue-600 font-bold block mt-2">
                클릭하여 마이데이터 서류만 보기 →
              </span>
            </div>

            <div 
              onClick={() => setDocMethodFilter(docMethodFilter === 'PORTAL' ? 'ALL' : 'PORTAL')}
              className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                docMethodFilter === 'PORTAL' 
                  ? 'bg-amber-50/90 border-amber-400 ring-2 ring-amber-400/20 shadow-sm' 
                  : 'bg-white border-slate-200 hover:border-amber-300 shadow-2xs'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-black text-amber-700 flex items-center gap-1.5">
                  <ExternalLink className="w-4 h-4 text-amber-600" />
                  대표자 직접 발급·첨부
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-800">
                  {manualDocsCount}종 필수
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                사업장 임대차계약서 및 거래은행 통장내역 등 스캔 파일 직접 업로드
              </p>
              <span className="text-[10px] text-amber-600 font-bold block mt-2">
                클릭하여 직접 준비 서류만 보기 →
              </span>
            </div>

            <div 
              onClick={() => setDocMethodFilter(docMethodFilter === 'TEMPLATE' ? 'ALL' : 'TEMPLATE')}
              className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                docMethodFilter === 'TEMPLATE' 
                  ? 'bg-purple-50/90 border-purple-400 ring-2 ring-purple-400/20 shadow-sm' 
                  : 'bg-white border-slate-200 hover:border-purple-300 shadow-2xs'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-black text-purple-700 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  시스템 템플릿 자동 생성
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-purple-100 text-purple-800">
                  {templateDocsCount}종 지원
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                [4. 템플릿 생성기]에서 내 정보가 입력된 융자신청서·사업계획서 원클릭 생성
              </p>
              <span className="text-[10px] text-purple-600 font-bold block mt-2">
                클릭하여 정책 표준서식만 보기 →
              </span>
            </div>
          </div>

          {/* Quick Issuance Portals Hub */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-indigo-600" />
              공식 인터넷 발급 포털 원클릭 바로가기
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {QUICK_ISSUANCE_PORTALS.slice(0, 4).map(portal => (
                <a
                  key={portal.id}
                  href={portal.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-indigo-300 hover:shadow-md transition-all group flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-black text-slate-900 group-hover:text-indigo-600 transition-colors">
                        {portal.name}
                      </span>
                      <ArrowUpRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                    </div>
                    <p className="text-[11px] text-slate-500 line-clamp-2">
                      {portal.description}
                    </p>
                  </div>
                  <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700">
                      {portal.badge}
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">바로가기</span>
                  </div>
                </a>
              ))}
            </div>
          </div>

          {/* Two-tier Filter: Category + Submission Method */}
          <div className="space-y-2">
            {/* Category Filter */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {[
                { id: 'ALL', label: `전체 서류 (${REQUIRED_DOCUMENTS_MASTER.length})` },
                { id: 'BUSINESS', label: '사업자 기본' },
                { id: 'FINANCIAL', label: '재무 및 매출 증빙' },
                { id: 'TAX', label: '국세·지방세 완납' },
                { id: 'EMPLOYMENT', label: '고용 및 규모' },
                { id: 'POLICY_SPECIAL', label: '정책자금 전용 서식' }
              ].map(cat => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedDocCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                    selectedDocCategory === cat.id
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>

            {/* Method Filter Pills */}
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-[11px] font-bold text-slate-400 mr-1">제출 방식 필터:</span>
              <button
                type="button"
                onClick={() => setDocMethodFilter('ALL')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  docMethodFilter === 'ALL'
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                전체보기
              </button>
              <button
                type="button"
                onClick={() => setDocMethodFilter('MYDATA')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                  docMethodFilter === 'MYDATA'
                    ? 'bg-blue-600 text-white'
                    : 'bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200/60'
                }`}
              >
                <Zap className="w-3 h-3 fill-current" />
                <span>마이데이터 자동제출 ({myDataDocsCount})</span>
              </button>
              <button
                type="button"
                onClick={() => setDocMethodFilter('PORTAL')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  docMethodFilter === 'PORTAL'
                    ? 'bg-amber-600 text-white'
                    : 'bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200/60'
                }`}
              >
                직접 첨부 필수 ({manualDocsCount})
              </button>
              <button
                type="button"
                onClick={() => setDocMethodFilter('TEMPLATE')}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  docMethodFilter === 'TEMPLATE'
                    ? 'bg-purple-600 text-white'
                    : 'bg-purple-50 text-purple-700 hover:bg-purple-100 border border-purple-200/60'
                }`}
              >
                정책 표준 템플릿 ({templateDocsCount})
              </button>
            </div>
          </div>

          {/* Documents Master Checklist */}
          <div className="space-y-3">
            {filteredDocs.map((doc) => {
              const isChecked = !!checkedDocIds[doc.id];
              return (
                <div
                  key={doc.id}
                  onClick={() => toggleDocCheck(doc.id)}
                  className={`p-4 sm:p-5 rounded-2xl border transition-all cursor-pointer select-none flex flex-col sm:flex-row sm:items-start justify-between gap-4 ${
                    isChecked
                      ? 'bg-emerald-50/40 border-emerald-300 shadow-2xs'
                      : 'bg-white border-slate-200 hover:border-slate-300 shadow-xs'
                  }`}
                >
                  <div className="flex items-start gap-3.5 flex-1">
                    <div className="pt-0.5">
                      <input
                        type="checkbox"
                        checked={isChecked}
                        onChange={() => {}} // handled by parent onClick
                        className="w-5 h-5 rounded-md text-emerald-600 focus:ring-emerald-500 cursor-pointer"
                      />
                    </div>

                    <div className="space-y-2 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`text-xs sm:text-sm font-black ${isChecked ? 'text-slate-500 line-through' : 'text-slate-900'}`}>
                          {doc.name}
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                          {doc.categoryLabel}
                        </span>

                        {/* Submission Method Badge */}
                        {doc.isMyDataAutoScrapable ? (
                          <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 flex items-center gap-1">
                            <Zap className="w-3 h-3 fill-blue-700" />
                            마이데이터 자동제출
                          </span>
                        ) : doc.submissionType === 'SELF_AUTHORED' ? (
                          <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-purple-100 text-purple-800 flex items-center gap-1">
                            <Sparkles className="w-3 h-3 text-purple-700" />
                            시스템 템플릿 지원
                          </span>
                        ) : (
                          <span className="text-[10px] font-black px-2 py-0.5 rounded-md bg-amber-100 text-amber-800">
                            직접 파일첨부
                          </span>
                        )}

                        {doc.isFree && (
                          <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-slate-100 text-slate-600">
                            무료
                          </span>
                        )}
                        <span className="text-[10px] text-slate-400 font-medium">
                          유효기간: {doc.validity}
                        </span>
                      </div>

                      <p className="text-xs text-slate-600 leading-relaxed">
                        <strong className="text-indigo-600">발급처:</strong> {doc.agency} · {doc.samplePath}
                      </p>

                      <div className="text-[11px] text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100 leading-snug">
                        💡 <strong className="text-slate-800">실무 발급 팁:</strong> {doc.tip}
                      </div>
                    </div>
                  </div>

                  <div className="flex sm:flex-col items-center sm:items-end gap-2 shrink-0">
                    {doc.submissionType === 'SELF_AUTHORED' ? (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setActiveTab('WRITING_EXAMPLE');
                        }}
                        className="px-3 py-1.5 rounded-xl bg-purple-50 hover:bg-purple-100 text-purple-700 border border-purple-200 text-xs font-black transition-colors flex items-center gap-1"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-purple-600" />
                        <span>템플릿 바로가기</span>
                      </button>
                    ) : doc.portalUrl ? (
                      <a
                        href={doc.portalUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 border border-slate-200 text-xs font-bold transition-colors flex items-center gap-1"
                      >
                        <span>발급처 바로가기</span>
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    ) : null}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Government Form Draft Notice Card */}
          <div className="p-5 bg-gradient-to-r from-indigo-50 to-blue-50 rounded-2xl border border-indigo-200 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                <FileCheck2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-black text-slate-900">
                  정부 표준 정책자금 신청서 & 사업계획서 초안 자동 생성
                </h4>
                <p className="text-xs text-slate-600 mt-0.5">
                  입력된 내 사업장 데이터를 바탕으로 융자신청서 및 기업현황표 PDF를 시스템에서 즉시 초안으로 생성할 수 있습니다.
                </p>
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                setDraftType('APPLICATION_FORM');
                setIsDraftModalOpen(true);
              }}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl transition-all shadow-md shadow-indigo-600/20 flex items-center gap-1.5 shrink-0 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>정부 표준 서식 초안 생성하기</span>
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: 온라인 신청 표준 템플릿 생성기 & 서류 작성 합격 가이드 */}
      {/* ========================================================================= */}
      {activeTab === 'WRITING_EXAMPLE' && (
        <div className="space-y-7 animate-fade-in">
          {/* Top Advice Banner */}
          <div className="p-5 bg-gradient-to-r from-purple-50 via-indigo-50 to-blue-50 rounded-3xl border border-indigo-200/80 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <div className="w-10 h-10 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-black shrink-0 shadow-md shadow-indigo-600/20">
                <Sparkles className="w-5 h-5 text-amber-300" />
              </div>
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 text-[10px] font-black rounded-md">
                    원클릭 공문서 생성기
                  </span>
                  <h4 className="text-base sm:text-lg font-black text-slate-900">
                    온라인 정책자금 표준 서식 템플릿 생성기
                  </h4>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  대표님의 사업장 기본 데이터(<strong>{profile?.businessName || '(주)대호정밀가공'}</strong>, 대표자: <strong>{profile?.name || '김대호'}</strong>, 연매출, 신청희망액)가 공문서 양식에 자동 입력되어 있습니다. 인라인으로 직접 수정하거나 한글/Word 서식으로 복사, A4 인쇄할 수 있습니다.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => {
                  setDraftType('APPLICATION_FORM');
                  setIsDraftModalOpen(true);
                }}
                className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black rounded-xl transition-all shadow-md shadow-indigo-600/20 flex items-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>AI 지능형 서식 생성기 열기</span>
              </button>
            </div>
          </div>

          {/* TEMPLATE STUDIO INTERACTIVE BOX */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden space-y-0">
            {/* Template Selector Pills Bar */}
            <div className="p-4 bg-slate-900 text-white border-b border-slate-800">
              <div className="flex items-center justify-between gap-3 mb-3">
                <span className="text-xs font-black text-slate-300 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-indigo-400" />
                  생성할 정책 표준 공문서 서식 선택:
                </span>
                <span className="text-[11px] text-amber-300 font-bold hidden sm:inline">
                  ⚡ 대표님 프로필 실시간 자동 연동 중
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
                {[
                  { key: 'APPLICATION_FORM', num: '별지 1호', name: '융자신청서 & 기업현황표' },
                  { key: 'BUSINESS_PLAN', num: '별지 2호', name: '표준 사업계획서' },
                  { key: 'FUND_USAGE_PLAN', num: '별지 3호', name: '자금세부활용계획서' },
                  { key: 'ASSURANCE_PLEDGE', num: '별지 4호', name: '신청자격 확인서약서' },
                  { key: 'CEO_PROFILE_STATEMENT', num: '별지 5호', name: '대표자 이력소명서' },
                  { key: 'MYDATA_CONSENT', num: '간소화', name: '마이데이터 제출확인서' }
                ].map(item => (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => setSelectedTemplateKey(item.key)}
                    className={`p-2.5 rounded-xl text-left transition-all cursor-pointer flex flex-col justify-between ${
                      selectedTemplateKey === item.key
                        ? 'bg-indigo-600 text-white shadow-md ring-2 ring-indigo-400/40'
                        : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700/60'
                    }`}
                  >
                    <span className={`text-[10px] font-black px-1.5 py-0.2 rounded self-start mb-1 ${
                      selectedTemplateKey === item.key ? 'bg-white/20 text-white' : 'bg-slate-700 text-slate-300'
                    }`}>
                      {item.num}
                    </span>
                    <span className="text-xs font-bold truncate">{item.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Template Toolbar */}
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-bold text-slate-700">
                  문서 규격: <strong className="text-indigo-600">중소벤처기업부·소진공 2026 표준 공문서 서식</strong>
                </span>
                <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-black">
                  수정 가능 (인라인 편집)
                </span>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {/* Stamp Toggle */}
                <button
                  type="button"
                  onClick={() => setShowOfficialStamp(!showOfficialStamp)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 cursor-pointer ${
                    showOfficialStamp
                      ? 'bg-rose-50 text-rose-700 border-rose-200'
                      : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                  }`}
                  title="대표자 공식 직인 도장 날인 토글"
                >
                  <Stamp className="w-3.5 h-3.5 text-rose-600" />
                  <span>{showOfficialStamp ? '대표자 직인 날인됨' : '도장 날인 켜기'}</span>
                </button>

                {/* Copy Formatted Text */}
                <button
                  type="button"
                  onClick={() => {
                    const bName = profile?.businessName || '(주)대호정밀가공';
                    const cName = profile?.name || '김대호';
                    const bReg = profile?.businessRegistrationNumber || '134-86-99214';
                    const bAddr = profile?.businessAddress || '경기 안산시 단원구 산단로 123';
                    const rev = profile?.annualRevenue ? (profile.annualRevenue).toLocaleString() + '원' : '3억 8,000만원';
                    const fundReq = profile?.fundingNeed ? (profile.fundingNeed).toLocaleString() + '원' : '5,000만원';
                    const fTitle = selectedFund?.title || '소상공인 정책자금';
                    const fAgency = selectedFund?.agency || '소상공인시장진흥공단';
                    
                    let txt = '';
                    if (selectedTemplateKey === 'APPLICATION_FORM') {
                      txt = `[별지 제1호 서식] 소상공인 정책자금 융자신청서 및 기업현황표\n\n1. 신청기업 현황\n- 상호명: ${bName}\n- 대표자명: ${cName}\n- 사업자등록번호: ${bReg}\n- 사업장 주소: ${bAddr}\n- 업종: ${profile?.industry || '제조업 / 소공인'}\n- 개업일: ${profile?.foundedYear || '2021'}년 / 상시근로자: ${profile?.employees || 3}명\n\n2. 융자 신청 내역\n- 신청 자금명: ${fTitle} (${fAgency})\n- 신청 희망금액: ${fundReq}\n- 자금 용도: 운전자금 (원부자재 구매 및 운영 경비)\n- 상환 조건: 2년 거치 3년 분할상환 (총 5년)\n\n3. 재무 현황\n- 최근 연간 매출액: ${rev}\n- 국세/지방세 체납: 없음, 금융기관 연체: 없음\n\n본인은 상기 기재 사항이 사실과 틀림없음을 확인하며 소상공인 정책자금을 신청합니다.\n2026년 10월  신청인: ${cName} (인)`;
                    } else if (selectedTemplateKey === 'BUSINESS_PLAN') {
                      txt = `[별지 제2호 서식] 정책자금 표준 사업계획서 및 자금소요·상환계획서\n\n1. 기업 개요 및 주요 품목\n당사(${bName})는 ${profile?.foundedYear || '2021'}년 개업 이래 ${profile?.industry || '제조업'} 분야에서 우수한 품질 관리와 지속적인 단골 고객 확보를 통해 안정적인 연매출(${rev})을 시현하고 있습니다.\n\n2. 시장 경쟁력 및 비즈니스 강점\n- 단골 고객 재방문율 38% 유지 및 스마트 발주 시스템 운용으로 원가 절감 달성.\n- 최근 수요 확대에 맞춰 신제품 론칭을 통한 매출 다변화 추진 중.\n\n3. 세부 자금 소요 내역 (총 ${fundReq})\n- 원부자재 산지 대량구매: 2,000만원 (견적서 첨부, 원가 12% 절감)\n- 고효율 공정 자동화 설비 도입: 1,500만원 (전력비 및 인건비 절감)\n- 청년 고용 유지 및 필수 운영 경비: 1,500만원\n\n4. 매출 증대 및 원리금 상환 계획\n- 설비 도입 후 월 순영업이익 160만원 추가 창출 예상.\n- 월 예상 상환액(약 90만원) 대비 1.7배 상회(DSCR > 1.7)하여 상환 여력 충분.\n- 매월 카드 매출 입금액 중 100만원을 '상환 전용 계좌'로 자동 적립하여 리스크를 원천 차단합니다.`;
                    } else if (selectedTemplateKey === 'FUND_USAGE_PLAN') {
                      txt = `[별지 제3호 서식] 시설·운전자금 세부 활용계획서 및 견적 명세표\n\n신청 자금: ${fTitle} | 신청 금액: ${fundReq}\n\n[품목별 소요 명세표]\n1. 원부자재 산지 대량구매 자금: 20,000,000원 (공급처: 협력업체 정식 견적서 첨부)\n2. 고효율 공정 자동화 설비 도입: 15,000,000원 (공급처: 설비 제조사 견적서 첨부)\n3. 청년 고용 유지 및 필수 운영비: 15,000,000원 (4대보험 급여대장 연계)\n합계: ${fundReq} (신청 희망 금액과 100% 일치)\n\n* 사후 관리: 자금 수령 후 3개월 이내 전자세금계산서 및 이체확인증을 관할 센터에 성실히 제출할 것을 확약합니다.`;
                    } else if (selectedTemplateKey === 'ASSURANCE_PLEDGE') {
                      txt = `[별지 제4호 서식] 정책자금 신청자격 자가진단 및 사실확인 서약서\n\n본인(${cName}, ${bName})은 정책자금을 신청함에 있어 아래 사실을 엄숙히 서약합니다.\n1. 불법 제3자(브로커) 부당개입 금지: 대출 대행 수수료를 지급한 사실이 없으며, 자력으로 신청함.\n2. 세금 체납 및 금융 연체 부존재: 국세·지방세 체납 및 금융기관 연체 이력이 일절 없음.\n3. 목적 외 유용 금지: 본 자금을 도박, 사적 채무 상환, 부동산 투기 등 목적 외로 사용하지 않음.\n4. 위반 시 조치 동의: 허위자료 제출 적발 시 자금 전액 즉시 환수 및 향후 3년간 정부 정책자금 참여 제한에 동의함.\n2026년 10월  서약자: ${cName} (인)`;
                    } else if (selectedTemplateKey === 'MYDATA_CONSENT') {
                      txt = `[온라인 간소화 서식] 공공 마이데이터(MyData) 일괄 스크래핑 및 원스톱 서류제출 확인서\n\n본인(${cName})은 ${fAgency} 정책자금 온라인 신청에 필요한 8대 공적 서류(사업자등록증명, 부가세과표증명, 소득금액증명, 국세완납증명, 지방세완납증명, 4대보험완납증명, 소상공인확인서, 주민등록등본)를 공공 마이데이터 망을 통해 심사기관으로 직접 전자 전송하는 것에 동의합니다.\n- 전산 제출 일시: 2026년 10월\n- 동의인: ${cName} (간편인증 전자서명 완료)`;
                    } else {
                      txt = `[별지 제5호 서식] 대표자 사업장 운영 현황 및 융자 목적 설명서\n\n1. 대표자 이력: ${cName} (동종업계 경력 ${profile?.foundedYear ? 2026 - parseInt(profile.foundedYear) + 3 : 5}년 보유, 전문 자격 및 현장 노하우 완비)\n2. 사업장 현황: ${bAddr} 소재, 상시근로자 ${profile?.employees || 3}명 근무 중\n3. 융자 목적: 저금리 정책자금(${fundReq})을 통해 고비용 구조를 개선하고 고용을 유지하여 지역 경제에 기여하고자 함.\n4. 현장 실사 지원 확약: 심사역 현장 실사 시 장부, 거래처 계약서, 설비 가동 내역을 투명하게 공개할 것을 확인합니다.`;
                    }
                    handleCopyText(txt, `TEMPLATE_${selectedTemplateKey}`);
                  }}
                  className="px-3.5 py-1.5 bg-white hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold transition-all border border-slate-200 flex items-center gap-1.5 cursor-pointer"
                >
                  {copiedSection === `TEMPLATE_${selectedTemplateKey}` ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>{copiedSection === `TEMPLATE_${selectedTemplateKey}` ? '복사 완료!' : 'HWP/워드 텍스트 복사'}</span>
                </button>

                {/* Print Button */}
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-3.5 py-1.5 bg-white hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-bold transition-all border border-slate-200 flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>A4 양식 인쇄</span>
                </button>
              </div>
            </div>

            {/* Document Render Area (A4 Paper Aesthetic) */}
            <div className="p-6 sm:p-10 bg-slate-100 flex justify-center">
              <div className="w-full max-w-3xl bg-white border border-slate-300 shadow-lg rounded-2xl p-6 sm:p-10 text-slate-800 space-y-6 font-sans">
                {/* Official Form Header */}
                <div className="border-b-2 border-slate-900 pb-4 flex items-start justify-between">
                  <div>
                    <span className="text-[11px] font-black text-slate-500 uppercase tracking-wider block">
                      {selectedTemplateKey === 'APPLICATION_FORM' && '[별지 제1호 서식] (앞쪽)'}
                      {selectedTemplateKey === 'BUSINESS_PLAN' && '[별지 제2호 서식]'}
                      {selectedTemplateKey === 'FUND_USAGE_PLAN' && '[별지 제3호 서식]'}
                      {selectedTemplateKey === 'ASSURANCE_PLEDGE' && '[별지 제4호 서식]'}
                      {selectedTemplateKey === 'CEO_PROFILE_STATEMENT' && '[별지 제5호 서식]'}
                      {selectedTemplateKey === 'MYDATA_CONSENT' && '[온라인 간소화 표준 서식]'}
                    </span>
                    <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-1">
                      {selectedTemplateKey === 'APPLICATION_FORM' && '소상공인 정책자금 융자신청서 및 기업현황표'}
                      {selectedTemplateKey === 'BUSINESS_PLAN' && '정책자금 표준 사업계획서 및 자금소요·상환계획서'}
                      {selectedTemplateKey === 'FUND_USAGE_PLAN' && '시설·운전자금 세부 활용계획서 및 견적 명세표'}
                      {selectedTemplateKey === 'ASSURANCE_PLEDGE' && '정책자금 신청자격 자가진단 및 사실확인 서약서'}
                      {selectedTemplateKey === 'CEO_PROFILE_STATEMENT' && '대표자 사업장 운영 현황 및 융자 목적 상세 소명서'}
                      {selectedTemplateKey === 'MYDATA_CONSENT' && '공공 마이데이터 일괄 스크래핑 및 원스톱 서류제출 확인서'}
                    </h3>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-[10px] text-slate-400 font-bold block">처리기간</span>
                    <span className="text-xs font-black text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                      14영업일 이내
                    </span>
                  </div>
                </div>

                {/* TEMPLATE 1: APPLICATION_FORM */}
                {selectedTemplateKey === 'APPLICATION_FORM' && (
                  <div className="space-y-5 text-xs">
                    <div>
                      <h4 className="font-black text-slate-900 mb-2 flex items-center gap-1.5 text-xs">
                        <span className="w-4 h-4 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px]">1</span>
                        신청 기업 및 대표자 기본 현황
                      </h4>
                      <table className="w-full border-collapse border border-slate-300 text-slate-700">
                        <tbody>
                          <tr>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2 w-1/4">상호명(법인명)</td>
                            <td className="border border-slate-300 p-2 font-bold w-1/4">{profile?.businessName || '(주)대호정밀가공'}</td>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2 w-1/4">사업자등록번호</td>
                            <td className="border border-slate-300 p-2 font-mono w-1/4">{profile?.businessRegistrationNumber || '134-86-99214'}</td>
                          </tr>
                          <tr>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2">대표자 성명</td>
                            <td className="border border-slate-300 p-2 font-bold">{profile?.name || '김대호'}</td>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2">기업 형태</td>
                            <td className="border border-slate-300 p-2">{profile?.businessType || '개인사업자 / 소상공인'}</td>
                          </tr>
                          <tr>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2">사업장 소재지</td>
                            <td colSpan={3} className="border border-slate-300 p-2">{profile?.businessAddress || '경기 안산시 단원구 산단로 123'}</td>
                          </tr>
                          <tr>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2">업종 및 주요 품목</td>
                            <td className="border border-slate-300 p-2">{profile?.industry || '정밀 가공 / 금속 가공'}</td>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2">개업연월일 / 근로자</td>
                            <td className="border border-slate-300 p-2">{profile?.foundedYear || '2021'}년 개업 / 상시 {profile?.employees || 3}명</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>

                    <div>
                      <h4 className="font-black text-slate-900 mb-2 flex items-center gap-1.5 text-xs">
                        <span className="w-4 h-4 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px]">2</span>
                        정책자금 융자 신청 내역
                      </h4>
                      <table className="w-full border-collapse border border-slate-300 text-slate-700">
                        <tbody>
                          <tr>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2 w-1/4">신청 자금명</td>
                            <td className="border border-slate-300 p-2 font-black text-indigo-700 w-1/4">{selectedFund?.title || '소진공 일반경영안정자금'}</td>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2 w-1/4">주관 기관</td>
                            <td className="border border-slate-300 p-2 w-1/4">{selectedFund?.agency || '소상공인시장진흥공단'}</td>
                          </tr>
                          <tr>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2">신청 희망 금액</td>
                            <td className="border border-slate-300 p-2 font-black text-base text-slate-900">
                              {profile?.fundingNeed ? `${profile.fundingNeed.toLocaleString()}원` : '50,000,000원'}
                            </td>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2">자금 구분 및 용도</td>
                            <td className="border border-slate-300 p-2">운전자금 (원부자재 구매 및 운영 경비)</td>
                          </tr>
                          <tr>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2">희망 상환 조건</td>
                            <td className="border border-slate-300 p-2">2년 거치 3년 분할상환 (총 5년)</td>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2">취급 희망 은행</td>
                            <td className="border border-slate-300 p-2">IBK기업은행 / KB국민은행</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>

                    <div>
                      <h4 className="font-black text-slate-900 mb-2 flex items-center gap-1.5 text-xs">
                        <span className="w-4 h-4 rounded-full bg-slate-900 text-white flex items-center justify-center text-[10px]">3</span>
                        최근 재무 실적 및 채무 상태 (요약)
                      </h4>
                      <table className="w-full border-collapse border border-slate-300 text-slate-700">
                        <tbody>
                          <tr>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2 w-1/4">연간 매출액</td>
                            <td className="border border-slate-300 p-2 font-bold w-1/4">
                              {profile?.annualRevenue ? `${profile.annualRevenue.toLocaleString()}원` : '380,000,000원'}
                            </td>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2 w-1/4">총 금융 대출 잔액</td>
                            <td className="border border-slate-300 p-2 w-1/4">
                              {profile?.debt1Tier ? `${profile.debt1Tier.toLocaleString()}원` : '80,000,000원'}
                            </td>
                          </tr>
                          <tr>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2">국세 및 지방세 체납</td>
                            <td className="border border-slate-300 p-2 text-emerald-700 font-bold">체납액 없음 (완납 완료)</td>
                            <td className="border border-slate-300 bg-slate-50 font-bold p-2">금융 연체 발생 여부</td>
                            <td className="border border-slate-300 p-2 text-emerald-700 font-bold">연체 내역 없음</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}

                {/* TEMPLATE 2: BUSINESS_PLAN */}
                {selectedTemplateKey === 'BUSINESS_PLAN' && (
                  <div className="space-y-5 text-xs leading-relaxed">
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <span className="font-bold text-slate-900 block mb-1">■ 1. 기업 개요 및 주요 취급 제품</span>
                      <p className="text-slate-700">
                        당사({profile?.businessName || '(주)대호정밀가공'})는 {profile?.foundedYear || '2021'}년 설립되어 {profile?.industry || '정밀가공'} 분야에서 차별화된 품질과 기술력으로 안정적인 매출({profile?.annualRevenue ? (profile.annualRevenue).toLocaleString() + '원' : '3억 8,000만원'})을 시현하고 있습니다. 상시근로자 {profile?.employees || 3}명과 함께 지역 경제 및 일자리 창출에 기여하고 있습니다.
                      </p>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <span className="font-bold text-slate-900 block mb-1">■ 2. 시장 경쟁력 및 비즈니스 강점</span>
                      <p className="text-slate-700">
                        - <strong>높은 재방문율 및 단골 고객층:</strong> 우수한 납기 준수와 철저한 불량률(0.2% 이하) 관리로 거래처 재발주율 85% 이상 유지.<br />
                        - <strong>공정 효율화 및 스마트화:</strong> 공정 관리 프로그램(ERP)과 자동화 장비를 순차 도입하여 동종업계 대비 생산 단가를 14% 절감.
                      </p>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <span className="font-bold text-slate-900 block mb-1">■ 3. 정책자금 소요 내역 ({profile?.fundingNeed ? (profile.fundingNeed).toLocaleString() + '원' : '5,000만원'})</span>
                      <p className="text-slate-700">
                        ① <strong>원부자재 대량 공동구매:</strong> 2,000만원 (원자재 선구매로 구매 단가 12% 절감, 거래처 견적서 첨부)<br />
                        ② <strong>설비 현대화 및 디지털 전환:</strong> 1,500만원 (고효율 모터 및 정밀 검사기 도입)<br />
                        ③ <strong>청년 고용 유지 및 필수 운영경비:</strong> 1,500만원 (숙련 인력 인건비 및 사업장 임차료)
                      </p>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <span className="font-bold text-slate-900 block mb-1">■ 4. 매출 증대 전망 및 원리금 상환 계획</span>
                      <p className="text-slate-700">
                        본 융자금 투입으로 월 평균 순영업이익이 약 160만원 이상 개선될 전망입니다. 월 예상 원리금 상환액(약 90만원) 대비 1.7배 상회하는 충분한 상환 여력(DSCR 1.7배)을 확보하였으며, 매월 15일 매출 입금액 중 100만원을 <strong>'정책자금 상환 전용 통장'</strong>으로 자동 분리 적립하여 연체 리스크를 원천 차단하겠습니다.
                      </p>
                    </div>
                  </div>
                )}

                {/* TEMPLATE 3: FUND_USAGE_PLAN */}
                {selectedTemplateKey === 'FUND_USAGE_PLAN' && (
                  <div className="space-y-4 text-xs">
                    <p className="text-slate-600">
                      신청 자금: <strong>{selectedFund?.title || '소상공인 정책자금'}</strong> | 총 소요 금액: <strong>{profile?.fundingNeed ? `${profile.fundingNeed.toLocaleString()}원` : '50,000,000원'}</strong>
                    </p>
                    <table className="w-full border-collapse border border-slate-300 text-slate-700 text-center">
                      <thead>
                        <tr className="bg-slate-100 font-bold">
                          <th className="border border-slate-300 p-2">구분</th>
                          <th className="border border-slate-300 p-2">품목명 및 사양</th>
                          <th className="border border-slate-300 p-2">공급처(상호/사업자)</th>
                          <th className="border border-slate-300 p-2">금액(원)</th>
                          <th className="border border-slate-300 p-2">집행예정월</th>
                          <th className="border border-slate-300 p-2">증빙자료</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td className="border border-slate-300 p-2 font-bold">원부자재</td>
                          <td className="border border-slate-300 p-2 text-left">가공용 알루미늄/특수강 6개월분</td>
                          <td className="border border-slate-300 p-2">(주)한국금속스틸</td>
                          <td className="border border-slate-300 p-2 font-bold">20,000,000</td>
                          <td className="border border-slate-300 p-2">2026.11</td>
                          <td className="border border-slate-300 p-2">전자세금계산서</td>
                        </tr>
                        <tr>
                          <td className="border border-slate-300 p-2 font-bold">설비도입</td>
                          <td className="border border-slate-300 p-2 text-left">고효율 절삭 정밀 자동화 툴</td>
                          <td className="border border-slate-300 p-2">삼우엔지니어링</td>
                          <td className="border border-slate-300 p-2 font-bold">15,000,000</td>
                          <td className="border border-slate-300 p-2">2026.11</td>
                          <td className="border border-slate-300 p-2">납품확인서/계산서</td>
                        </tr>
                        <tr>
                          <td className="border border-slate-300 p-2 font-bold">운영경비</td>
                          <td className="border border-slate-300 p-2 text-left">청년 정규직 1인 고용 및 운영비</td>
                          <td className="border border-slate-300 p-2">당사 사업장 직접집행</td>
                          <td className="border border-slate-300 p-2 font-bold">15,000,000</td>
                          <td className="border border-slate-300 p-2">2026.12</td>
                          <td className="border border-slate-300 p-2">급여이체/임대료</td>
                        </tr>
                        <tr className="bg-slate-50 font-black">
                          <td colSpan={3} className="border border-slate-300 p-2 text-right">합계 금액</td>
                          <td className="border border-slate-300 p-2 text-indigo-700 font-bold">
                            {profile?.fundingNeed ? `${profile.fundingNeed.toLocaleString()}원` : '50,000,000원'}
                          </td>
                          <td colSpan={2} className="border border-slate-300 p-2 text-emerald-700 text-[11px]">신청액과 100% 일치</td>
                        </tr>
                      </tbody>
                    </table>

                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-600 space-y-1">
                      <span className="font-bold text-slate-900 block">※ 사후 증빙 관리 확약:</span>
                      <p>
                        본인은 대출금 입금 후 3개월 이내에 상기 품목에 대한 집행 증빙(전자세금계산서, 계약서, 은행 계좌이체 확인증)을 성실히 제출할 것을 확약합니다.
                      </p>
                    </div>
                  </div>
                )}

                {/* TEMPLATE 4: ASSURANCE_PLEDGE */}
                {selectedTemplateKey === 'ASSURANCE_PLEDGE' && (
                  <div className="space-y-4 text-xs leading-relaxed text-slate-700">
                    <p className="font-bold text-slate-900">
                      본인({profile?.name || '김대호'}, {profile?.businessName || '(주)대호정밀가공'})은 정책자금을 신청함에 있어 다음 사항을 사실 그대로 확인하며 서약합니다.
                    </p>

                    <div className="space-y-2.5 p-4 bg-slate-50 rounded-2xl border border-slate-200">
                      <div className="flex items-start gap-2">
                        <span className="font-black text-indigo-600">제1조</span>
                        <p><strong>[제3자 부당개입 배제]:</strong> 본 신청 건과 관련하여 어떠한 대출 브로커나 컨설팅 업자에게 수수료(착수금, 성공보수 등)를 지급한 사실이 없으며, 자력으로 신청하였음을 확인합니다.</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="font-black text-indigo-600">제2조</span>
                        <p><strong>[성실 납세 및 금융 질서]:</strong> 국세, 지방세, 4대 사회보험료 체납 사실이 없으며, 금융기관 신용관리대상자(연체자)가 아님을 확인합니다.</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="font-black text-indigo-600">제3조</span>
                        <p><strong>[자금의 목적 내 사용]:</strong> 배정받은 융자금을 사업 목적(운전/시설)에 맞게 사용하며, 부동산 투기, 사적 채무 상환, 유흥비 등에 유용하지 않겠습니다.</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="font-black text-indigo-600">제4조</span>
                        <p><strong>[허위자료 제출 시 제재 동의]:</strong> 위 기재 사항 및 제출 서류가 허위로 판명될 경우 융자금 전액 일시환수 및 향후 3년간 정부 정책자금 참여 제한 등의 행정 조치를 감수하겠습니다.</p>
                      </div>
                    </div>
                  </div>
                )}

                {/* TEMPLATE 5: MYDATA_CONSENT */}
                {selectedTemplateKey === 'MYDATA_CONSENT' && (
                  <div className="space-y-4 text-xs leading-relaxed text-slate-700">
                    <div className="p-4 bg-blue-50/60 rounded-2xl border border-blue-200 space-y-2">
                      <span className="font-black text-blue-900 block text-sm">
                        공공 마이데이터(MyData) 행정정보 공동이용 및 일괄 제출 사전 동의
                      </span>
                      <p className="text-blue-800">
                        본인은 {selectedFund?.agency || '소상공인시장진흥공단'}의 정책자금 심사를 위해 아래 공적 서류를 관련 기관에서 심사기관으로 직접 전자 전송하는 데 동의합니다.
                      </p>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                      <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                        <strong>① 국세청:</strong> 사업자등록증명, 부가세과표, 소득금액, 국세납세증명
                      </div>
                      <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                        <strong>② 행정안전부:</strong> 지방세납세증명서, 주민등록표등본
                      </div>
                      <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                        <strong>③ 국민건강보험공단:</strong> 4대사회보험료 완납증명서, 자격득실확인서
                      </div>
                      <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                        <strong>④ 중소벤처기업부:</strong> 중소기업·소상공인확인서 (sminfo 연동)
                      </div>
                    </div>

                    <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-900 text-[11px]">
                      ✅ <strong>효과:</strong> 종이 서류 발급 비용 및 방문 시간 100% 절감, 심사 기간 평균 5일 단축, 서류 위변조 방지
                    </div>
                  </div>
                )}

                {/* TEMPLATE 6: CEO_PROFILE_STATEMENT */}
                {selectedTemplateKey === 'CEO_PROFILE_STATEMENT' && (
                  <div className="space-y-4 text-xs leading-relaxed text-slate-700">
                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <span className="font-bold text-slate-900 block mb-1">■ 1. 대표자 약력 및 실무 경력</span>
                      <p className="text-slate-700">
                        대표자 {profile?.name || '김대호'}는 동종업계 실무 경력 {profile?.foundedYear ? 2026 - parseInt(profile.foundedYear) + 3 : 5}년 이상을 보유하고 있으며, 기술적 노하우와 철저한 현장 관리를 바탕으로 기업을 경영하고 있습니다.
                      </p>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <span className="font-bold text-slate-900 block mb-1">■ 2. 사업장 운영 현황 및 시설 기반</span>
                      <p className="text-slate-700">
                        사업장({profile?.businessAddress || '경기 안산시 단원구 산단로 123'})은 생산 및 고객 접근성이 우수하며, 핵심 장비와 상시근로자 {profile?.employees || 3}명이 유기적으로 협업하여 안정적인 생산성을 유지하고 있습니다.
                      </p>
                    </div>

                    <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <span className="font-bold text-slate-900 block mb-1">■ 3. 현장 실사 지원 확약</span>
                      <p className="text-slate-700">
                        정책금융 심사역의 현장 실사 방문 시 매출 장부, 전자세금계산서 발행 내역, 거래처 계약서, 주요 생산 설비 가동 상태를 투명하게 공개하고 성실히 소명하겠습니다.
                      </p>
                    </div>
                  </div>
                )}

                {/* Bottom Signature Section with Stamp */}
                <div className="pt-6 border-t-2 border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div className="text-xs text-slate-500 text-center sm:text-left">
                    <span>작성일자: <strong>2026년 10월</strong></span>
                    <span className="block text-[11px] text-slate-400 mt-0.5">
                      제출처: {selectedFund?.agency || '소상공인시장진흥공단 / 신용보증재단'} 이사장 귀하
                    </span>
                  </div>

                  {/* Stamp Graphic */}
                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span className="text-xs text-slate-500 block">신청인(대표자)</span>
                      <span className="text-sm font-black text-slate-900">
                        {profile?.name || '김대호'}
                      </span>
                    </div>

                    {showOfficialStamp ? (
                      <div className="w-14 h-14 rounded-full border-2 border-rose-600 text-rose-600 flex flex-col items-center justify-center font-serif text-[10px] font-black leading-tight rotate-6 select-none bg-rose-50/40 shadow-xs">
                        <span>{(profile?.name || '김대호').slice(0, 1)}</span>
                        <span>{(profile?.name || '김대호').slice(1)}印</span>
                      </div>
                    ) : (
                      <div className="w-14 h-14 rounded-full border border-dashed border-slate-300 text-slate-400 flex items-center justify-center text-[10px] font-bold">
                        (서명/인)
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Section Divider Notice */}
          <div className="flex items-center gap-3 pt-4">
            <div className="h-px bg-slate-200 flex-1" />
            <span className="text-xs font-black text-slate-500 uppercase tracking-wider">
              심사관을 설득하는 정책자금 서류 작성 합격 가이드
            </span>
            <div className="h-px bg-slate-200 flex-1" />
          </div>

          {/* Top Advice Banner */}
          <div className="p-5 bg-emerald-50 rounded-2xl border border-emerald-200 flex items-start gap-3">
            <Lightbulb className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="text-sm font-black text-emerald-900">
                심사관을 설득하는 정책자금 사업계획서 3대 황금률
              </h4>
              <p className="text-xs text-emerald-800 leading-relaxed">
                심사관은 막연한 성공 다짐이나 생계 곤란 호소를 보지 않습니다. 
                <strong> ① 구체적 비용 명세(견적서 일치)</strong>, 
                <strong> ② 매출 증대 및 비용 절감 효과</strong>, 
                <strong> ③ 월별 원리금 상환 확실성(상환 전용 계좌 운용)</strong>의 3요소를 
                아래 실전 모범 예시를 참고하여 작성하세요.
              </p>
            </div>
          </div>

          {/* Example 1: 사업 개요 */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-xs font-black">
                  1
                </span>
                <h4 className="text-base font-black text-slate-900">
                  사업 개요 및 사업장 현황 작성 예시
                </h4>
              </div>
              <button
                type="button"
                onClick={() => {
                  const sample1 = `[사업 개요 및 현황]
2021년 3월 개업 이래 서울 강동구 주택·오피스 복합 상권에서 지역 밀착형 한식 요식업을 안정적으로 영위하고 있습니다.
매장 내 스마트 오더 키오스크와 배달 플랫폼(배민·쿠팡이츠 평점 4.9점 유지)을 체계적으로 운영하여, 단골 고객 재방문율 38%를 유지하고 있습니다.
최근 지역 주민들의 수요에 맞춰 간편 조리 밀키트 제품군 3종을 자체 개발하였으며, 오프라인 매장 매출 외에 테이크아웃 및 배달 매출이 전년 동기 대비 16.5% 성장하는 추세입니다.`;
                  handleCopyText(sample1, 'SAMPLE_1');
                }}
                className="text-xs font-bold text-slate-600 hover:text-emerald-600 bg-slate-50 hover:bg-emerald-50 px-3 py-1.5 rounded-xl transition-colors border border-slate-200 flex items-center gap-1.5 self-start cursor-pointer"
              >
                {copiedSection === 'SAMPLE_1' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>모범 예시 복사</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Bad Example */}
              <div className="p-4 bg-rose-50/70 rounded-2xl border border-rose-200 space-y-2">
                <span className="text-xs font-black text-rose-700 flex items-center gap-1">
                  ❌ 피해야 할 작성 예시 (감점 사유)
                </span>
                <p className="text-xs text-rose-900 leading-relaxed font-mono bg-white/70 p-3 rounded-xl border border-rose-100">
                  "동네에서 3년째 식당을 하고 있습니다. 요즘 원자재 값도 많이 오르고 손님도 줄어 장사가 너무 어렵습니다. 대출을 받아서 식당을 계속 유지하고 싶습니다."
                </p>
                <p className="text-[11px] text-rose-700">
                  ※ 단순 어려움 호소는 상환 불능(부실 위험 차주)으로 판정되어 부결 사유가 됩니다.
                </p>
              </div>

              {/* Good Example */}
              <div className="p-4 bg-emerald-50/70 rounded-2xl border border-emerald-200 space-y-2">
                <span className="text-xs font-black text-emerald-700 flex items-center gap-1">
                  ✅ 승인율 높은 모범 작성 예시 (가점 요인)
                </span>
                <p className="text-xs text-emerald-950 leading-relaxed font-mono bg-white/80 p-3 rounded-xl border border-emerald-100">
                  "2021년 3월 개업 이래 지역 상권 밀착형 한식 요식업을 운영 중이며, 배달 앱 평점 4.9점 및 단골 고객 38% 재방문율을 유지. 최근 스마트 오더 도입 및 자체 밀키트 3종 개발로 월 매출이 전년 동기 대비 16.5% 안정적으로 성장하는 추세입니다."
                </p>
                <p className="text-[11px] text-emerald-700">
                  ※ 업력, 상권 특성, 객관적 평점 및 성장률 지표를 구체적인 수치로 제시했습니다.
                </p>
              </div>
            </div>
          </div>

          {/* Example 2: 자금 소요 계획 */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-xs font-black">
                  2
                </span>
                <h4 className="text-base font-black text-slate-900">
                  자금 소요 계획 (항목별 비용 산출 명세) 작성 예시
                </h4>
              </div>
              <button
                type="button"
                onClick={() => {
                  const sample2 = `[자금 소요 계획서 - 총 5,000만원 신청 기준]
1. 원부자재 산지 대량 공동구매 자금 (1,500만원)
   - 주원료(국내산 고춧가루 및 식자재) 6개월분 선구매로 원가 12% 절감 (견적서 첨부)
2. 친환경 고효율 주방 조리 설비 및 테이블 오더 키오스크 도입 (1,500만원)
   - 노후 냉동고 교체로 전력비 절감 및 홀 인건비 절감 (설비 업체 견적서 첨부)
3. 상반기 청년 조리 인력 고용 유지 및 필수 운영 경비 (2,000만원)
   - 정규직 조리사 1인 급여(4대보험 가입) 및 사업장 임차료 지급 증빙`;
                  handleCopyText(sample2, 'SAMPLE_2');
                }}
                className="text-xs font-bold text-slate-600 hover:text-emerald-600 bg-slate-50 hover:bg-emerald-50 px-3 py-1.5 rounded-xl transition-colors border border-slate-200 flex items-center gap-1.5 self-start cursor-pointer"
              >
                {copiedSection === 'SAMPLE_2' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>모범 예시 복사</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-rose-50/70 rounded-2xl border border-rose-200 space-y-2">
                <span className="text-xs font-black text-rose-700 flex items-center gap-1">
                  ❌ 피해야 할 작성 예시 (감점 사유)
                </span>
                <p className="text-xs text-rose-900 leading-relaxed font-mono bg-white/70 p-3 rounded-xl border border-rose-100">
                  "희망 자금: 5,000만원. 용도: 가게 운영비 및 생활비, 기존 대출 갚는 데 쓸 예정입니다."
                </p>
                <p className="text-[11px] text-rose-700">
                  ※ 생활비나 사적 채무 상환은 정책자금 지원 목적 외 사용으로 즉시 결격 처리됩니다.
                </p>
              </div>

              <div className="p-4 bg-emerald-50/70 rounded-2xl border border-emerald-200 space-y-2">
                <span className="text-xs font-black text-emerald-700 flex items-center gap-1">
                  ✅ 승인율 높은 모범 작성 예시 (가점 요인)
                </span>
                <p className="text-xs text-emerald-950 leading-relaxed font-mono bg-white/80 p-3 rounded-xl border border-emerald-100">
                  "총 5,000만원: ① 원부자재 산지 대량구매(1,500만원/원가 12% 절감 견적서 첨부) ② 고효율 주방설비 및 키오스크 도입(1,500만원/전력·인건비 절감) ③ 청년 고용 유지 및 임차료(2,000만원)."
                </p>
                <p className="text-[11px] text-emerald-700">
                  ※ 금액별 산출 근거와 견적서 증빙을 명확히 제시하여 심사관 신뢰도를 극대화했습니다.
                </p>
              </div>
            </div>
          </div>

          {/* Example 3: 상환 계획 */}
          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center text-xs font-black">
                  3
                </span>
                <h4 className="text-base font-black text-slate-900">
                  매출 증대 전망 및 원리금 상환 계획서 작성 예시
                </h4>
              </div>
              <button
                type="button"
                onClick={() => {
                  const sample3 = `[매출 증대 및 원리금 상환 계획서]
1. 매출 증대 및 수익성 개선 효과
   - 설비 현대화로 피크 시간 테이블 회전율 22% 향상 및 신규 밀키트 론칭을 통해 월 매출 420만원(순영업이익 약 160만원) 추가 창출 예상.
2. 원리금 상환 계획 및 리스크 관리
   - 본 융자금(5,000만원, 5년 분할상환)의 예상 월 원리금은 약 90만원 수준입니다.
   - 예상 추가 순영업이익(160만원)이 월 상환액(90만원)을 1.7배 이상 상회(DSCR 1.7배)하여 상환 여력이 충분합니다.
   - 매월 15일 신용카드 가맹점 결제 입금액 중 100만원을 '정책자금 상환 전용 결제계좌'로 자동 적립하여 연체 발생 가능성을 원천 차단하겠습니다.`;
                  handleCopyText(sample3, 'SAMPLE_3');
                }}
                className="text-xs font-bold text-slate-600 hover:text-emerald-600 bg-slate-50 hover:bg-emerald-50 px-3 py-1.5 rounded-xl transition-colors border border-slate-200 flex items-center gap-1.5 self-start cursor-pointer"
              >
                {copiedSection === 'SAMPLE_3' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>모범 예시 복사</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-rose-50/70 rounded-2xl border border-rose-200 space-y-2">
                <span className="text-xs font-black text-rose-700 flex items-center gap-1">
                  ❌ 피해야 할 작성 예시 (감점 사유)
                </span>
                <p className="text-xs text-rose-900 leading-relaxed font-mono bg-white/70 p-3 rounded-xl border border-rose-100">
                  "자금을 지원해 주시면 성실하게 일해서 5년 동안 꼬박꼬박 갚도록 하겠습니다. 열심히 하겠습니다."
                </p>
                <p className="text-[11px] text-rose-700">
                  ※ 구체적인 상환 재원과 숫자 근거가 결여된 막연한 다짐은 심사관에게 감점 요소입니다.
                </p>
              </div>

              <div className="p-4 bg-emerald-50/70 rounded-2xl border border-emerald-200 space-y-2">
                <span className="text-xs font-black text-emerald-700 flex items-center gap-1">
                  ✅ 승인율 높은 모범 작성 예시 (가점 요인)
                </span>
                <p className="text-xs text-emerald-950 leading-relaxed font-mono bg-white/80 p-3 rounded-xl border border-emerald-100">
                  "설비 개선으로 월 추가 매출 420만원(순익 160만원) 창출. 월 상환액 90만원 대비 1.7배 상회(DSCR &gt; 1.7). 매월 카드 매출 입금액 중 100만원을 '상환 전용 통장'으로 자동 적립하여 리스크를 원천 차단합니다."
                </p>
                <p className="text-[11px] text-emerald-700">
                  ※ 금융기관의 핵심 지표인 부채상환계수(DSCR)와 상환 전용 통장 지정 계획을 명시했습니다.
                </p>
              </div>
            </div>
          </div>

          {/* 5 Golden Rules Checklist */}
          <div className="p-6 bg-slate-900 text-white rounded-3xl space-y-4 shadow-xl">
            <h4 className="text-sm font-black text-white flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" />
              서류 심사 통과를 위한 5대 감점 방지 체크리스트
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="p-3.5 bg-slate-800/80 rounded-xl border border-slate-700 space-y-1">
                <span className="font-bold text-emerald-300">Rule 1. 세무 서류와 100% 일치</span>
                <p className="text-slate-300">
                  사업계획서의 매출액, 근로자 수, 개업일은 부가세 과표 및 사업자등록증명과 오차 없이 일치해야 합니다.
                </p>
              </div>
              <div className="p-3.5 bg-slate-800/80 rounded-xl border border-slate-700 space-y-1">
                <span className="font-bold text-emerald-300">Rule 2. '지원금' 아닌 '융자' 인식</span>
                <p className="text-slate-300">
                  정부 무상 보조금이 아닌 상환 의무가 있는 저금리 대출이므로, '갚을 능력'을 강조해야 승인됩니다.
                </p>
              </div>
              <div className="p-3.5 bg-slate-800/80 rounded-xl border border-slate-700 space-y-1">
                <span className="font-bold text-emerald-300">Rule 3. 견적서 등 증빙 완비</span>
                <p className="text-slate-300">
                  시설자금이나 기계 구매는 거래처에서 정식 견적서나 계산서 발급 계획서를 반드시 첨부하세요.
                </p>
              </div>
              <div className="p-3.5 bg-slate-800/80 rounded-xl border border-slate-700 space-y-1">
                <span className="font-bold text-emerald-300">Rule 4. 공란(빈칸) 절대 금지</span>
                <p className="text-slate-300">
                  해당 사항이 없는 항목이라도 비워두지 말고 '해당없음'으로 명확히 기재해야 서류 미비로 반려되지 않습니다.
                </p>
              </div>
            </div>
          </div>

          {/* Quick Auto-Draft Trigger with Selected Fund and Profile */}
          <div className="p-6 bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 text-white rounded-3xl shadow-lg flex flex-col sm:flex-row items-center justify-between gap-5">
            <div className="space-y-1">
              <span className="text-xs font-black uppercase tracking-wider text-emerald-200 bg-white/10 px-2.5 py-0.5 rounded-full border border-white/20">
                선택 자금 연동 자동 서류 작성기
              </span>
              <h4 className="text-base sm:text-lg font-black text-white">
                {selectedFund?.title || '선택 정책자금'} 맞춤 서류를 지금 바로 자동 작성하시겠습니까?
              </h4>
              <p className="text-xs text-emerald-100 leading-relaxed">
                입력하신 사업장 현황({profile?.businessName || '대표님 사업체'}, 연매출, 고용인원 등)이 양식에 자동 입력되어 즉시 완성본 PDF를 확인할 수 있습니다.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
              <button
                type="button"
                onClick={() => {
                  setDraftType('APPLICATION_FORM');
                  setIsDraftModalOpen(true);
                }}
                className="flex-1 sm:flex-none px-4 py-3 bg-white text-emerald-800 hover:bg-emerald-50 rounded-2xl text-xs font-black transition-all shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <FileText className="w-4 h-4 text-emerald-600" />
                <span>융자신청서 자동 생성</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setDraftType('BUSINESS_PLAN');
                  setIsDraftModalOpen(true);
                }}
                className="flex-1 sm:flex-none px-4 py-3 bg-emerald-800/80 hover:bg-emerald-800 text-white rounded-2xl text-xs font-black transition-all border border-white/30 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <PenTool className="w-4 h-4 text-emerald-300" />
                <span>사업계획서 자동 생성</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: 관련 FAQ 섹션 (Frequently Asked Questions) */}
      {/* ========================================================================= */}
      {activeTab === 'FAQ' && (
        <div className="space-y-6 animate-fade-in">
          {/* Search & Filter Bar */}
          <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={faqSearchQuery}
                  onChange={(e) => setFaqSearchQuery(e.target.value)}
                  placeholder="궁금한 질문 키워드 검색 (예: 직접대출, 신용점수, 부결, 체납, 보증료, 카드론)"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-amber-500 focus:bg-white transition-all"
                />
                {faqSearchQuery && (
                  <button
                    type="button"
                    onClick={() => setFaqSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-slate-400 hover:text-slate-600"
                  >
                    지우기
                  </button>
                )}
              </div>
            </div>

            {/* Category Filter Pills */}
            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {[
                { id: 'ALL', label: '전체 (12)' },
                { id: 'ELIGIBILITY', label: '자격 및 조건' },
                { id: 'PROCEDURE', label: '신청 및 절차' },
                { id: 'DOCUMENTS', label: '서류 및 심사' },
                { id: 'REJECTION', label: '부결 및 재신청' }
              ].map(cat => (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => setSelectedFaqCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                    selectedFaqCategory === cat.id
                      ? 'bg-amber-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* FAQ Accordion List */}
          <div className="space-y-3">
            {filteredFaqs.length === 0 ? (
              <div className="p-12 text-center bg-white rounded-3xl border border-slate-200 space-y-3">
                <HelpCircle className="w-10 h-10 text-slate-300 mx-auto" />
                <h4 className="text-base font-black text-slate-800">
                  검색어와 일치하는 FAQ 질문이 없습니다.
                </h4>
                <p className="text-xs text-slate-500">
                  다른 검색어를 입력하시거나 상단 카테고리를 '전체'로 변경해 보세요.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setFaqSearchQuery('');
                    setSelectedFaqCategory('ALL');
                  }}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
                >
                  검색 조건 초기화
                </button>
              </div>
            ) : (
              filteredFaqs.map((faq, index) => {
                const isExpanded = expandedFaqId === faq.id;
                const isVoted = !!helpfulFaqVotes[faq.id];

                return (
                  <div
                    key={faq.id}
                    className={`rounded-2xl border transition-all overflow-hidden ${
                      isExpanded
                        ? 'bg-white border-amber-300 shadow-sm ring-1 ring-amber-400/20'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    {/* Accordion Header */}
                    <button
                      type="button"
                      onClick={() => setExpandedFaqId(isExpanded ? null : faq.id)}
                      className="w-full p-4 sm:p-5 text-left flex items-start justify-between gap-4 cursor-pointer"
                    >
                      <div className="flex items-start gap-3">
                        <span className="w-6 h-6 rounded-lg bg-amber-100 text-amber-800 flex items-center justify-center font-black text-xs shrink-0 mt-0.5">
                          Q
                        </span>
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                              {faq.categoryLabel}
                            </span>
                            {faq.agencyTarget && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200">
                                {faq.agencyTarget}
                              </span>
                            )}
                          </div>
                          <h4 className="text-sm sm:text-base font-black text-slate-900 leading-snug">
                            {faq.question}
                          </h4>
                        </div>
                      </div>

                      <div className="p-1 rounded-lg text-slate-400 shrink-0">
                        {isExpanded ? (
                          <ChevronUp className="w-5 h-5 text-amber-600" />
                        ) : (
                          <ChevronDown className="w-5 h-5 text-slate-400" />
                        )}
                      </div>
                    </button>

                    {/* Accordion Body */}
                    {isExpanded && (
                      <div className="px-5 pb-5 pt-1 border-t border-slate-100 space-y-4 bg-slate-50/50">
                        {/* Detailed Answer */}
                        <div className="p-4 bg-white rounded-2xl border border-slate-200 space-y-3">
                          <div className="flex items-start gap-2.5">
                            <span className="w-6 h-6 rounded-lg bg-blue-600 text-white flex items-center justify-center font-black text-xs shrink-0 mt-0.5">
                              A
                            </span>
                            <p className="text-xs sm:text-sm text-slate-800 font-medium leading-relaxed">
                              {faq.answer}
                            </p>
                          </div>

                          {/* Key Points Bullet List */}
                          <div className="space-y-1.5 pl-8 pt-1">
                            {faq.keyPoints.map((kp, idx) => (
                              <div key={idx} className="flex items-start gap-2 text-xs text-slate-600">
                                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0 mt-1.5" />
                                <span className="leading-relaxed">{kp}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Pro Tip Box */}
                        {faq.tip && (
                          <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 flex items-start gap-2 text-xs text-amber-900">
                            <Lightbulb className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                            <p className="leading-relaxed">
                              <strong className="font-bold">실무자 직격 팁:</strong> {faq.tip}
                            </p>
                          </div>
                        )}

                        {/* Feedback & Helpful Action */}
                        <div className="flex items-center justify-between pt-1">
                          <span className="text-[11px] text-slate-400">
                            이 답변이 상담이나 신청 준비에 도움이 되셨나요?
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              setHelpfulFaqVotes(prev => ({ ...prev, [faq.id]: !prev[faq.id] }));
                            }}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                              isVoted
                                ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                            }`}
                          >
                            <ThumbsUp className={`w-3.5 h-3.5 ${isVoted ? 'text-emerald-700' : 'text-slate-400'}`} />
                            <span>{isVoted ? '도움됨 표시됨' : '도움이 돼요'}</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* Need More Consultation Notice */}
          <div className="p-6 bg-white rounded-3xl border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
            <div className="space-y-1">
              <h4 className="text-sm font-black text-slate-900">
                찾으시는 질문이나 특이 사유가 없으신가요?
              </h4>
              <p className="text-xs text-slate-500">
                중소기업 통합 콜센터(국번없이 1357) 또는 관할 지역 신용보증재단에서 1:1 유선 무료 상담을 지원합니다.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <a
                href="tel:1357"
                className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black transition-all shadow-xs flex items-center gap-1.5"
              >
                <span>1357 전화 상담</span>
              </a>
              {onNavigateToMatch && (
                <button
                  type="button"
                  onClick={onNavigateToMatch}
                  className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-black transition-all shadow-md shadow-blue-600/20 flex items-center gap-1.5 cursor-pointer"
                >
                  <span>AI 맞춤 매칭 다시 받기</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Government Document Draft Modal for Instant PDF Drafts */}
      <GovernmentDocumentDraftModal
        isOpen={isDraftModalOpen}
        onClose={() => setIsDraftModalOpen(false)}
        initialDocType={draftType}
        profile={profile || undefined}
        fund={selectedFund}
      />
    </div>
  );
};
