import React, { useState, useMemo, useEffect } from 'react';
import { PolicyFund, UserProfile, BusinessType, Industry } from '../types';
import { 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Sparkles, 
  UserCheck, 
  Building, 
  Calendar, 
  TrendingUp, 
  CreditCard, 
  Users, 
  MapPin, 
  ShieldAlert, 
  RotateCcw, 
  CheckSquare, 
  Square, 
  Info,
  ChevronDown,
  ChevronUp,
  FileText,
  HelpCircle,
  ArrowRight
} from 'lucide-react';

export interface EligibilityCheckItem {
  id: string;
  category: 'AGE' | 'BUSINESS_TYPE' | 'INDUSTRY' | 'CREDIT' | 'EMPLOYEES' | 'REVENUE' | 'LOCATION' | 'TAX_DEBT';
  title: string;
  fundCriterion: string;
  userProfileValue: string;
  status: 'QUALIFIED' | 'REVIEW_NEEDED' | 'DISQUALIFIED' | 'BONUS';
  statusText: string;
  explanation: string;
  isChecked: boolean;
  tip?: string;
  iconName: string;
}

interface FundEligibilityChecklistProps {
  fund: PolicyFund;
  profile?: UserProfile | null;
  isPrinting?: boolean;
  onOpenDocumentGuide?: () => void;
  onOpenPdfChecklist?: () => void;
}

const getIndustryLabel = (industry?: Industry): string => {
  if (!industry) return '일반 도소매/서비스';
  switch (industry) {
    case Industry.MANUFACTURING: return '제조업 (뿌리/기술/가공)';
    case Industry.IT_SOFTWARE: return 'IT·소프트웨어·지식서비스';
    case Industry.RESTAURANT: return '음식점업 (식음료/외식)';
    case Industry.RETAIL: return '도소매업 (유통/판매)';
    case Industry.SERVICE: return '서비스업 (교육/생활/기타)';
    case Industry.OTHER: return '기타 영리사업';
    default: return String(industry);
  }
};

const getBusinessTypeLabel = (type?: BusinessType): string => {
  if (!type) return '개인사업자';
  switch (type) {
    case BusinessType.INDIVIDUAL: return '개인사업자';
    case BusinessType.CORPORATION: return '법인사업자';
    case BusinessType.PRE_STARTUP: return '예비창업자';
    default: return String(type);
  }
};

export const FundEligibilityChecklist: React.FC<FundEligibilityChecklistProps> = ({
  fund,
  profile,
  isPrinting = false,
  onOpenDocumentGuide,
  onOpenPdfChecklist,
}) => {
  const [isExpanded, setIsExpanded] = useState(true);
  const [filterType, setFilterType] = useState<'ALL' | 'QUALIFIED' | 'REVIEW_NEEDED'>('ALL');

  // Compute Initial Criteria based on Profile & Fund Data
  const initialCriteria = useMemo<EligibilityCheckItem[]>(() => {
    const currentYear = new Date().getFullYear();
    const foundedYearNum = profile?.foundedYear ? parseInt(profile.foundedYear) : 2023;
    const businessAgeYears = Math.max(1, currentYear - (isNaN(foundedYearNum) ? 2023 : foundedYearNum) + 1);

    const items: EligibilityCheckItem[] = [];
    const fundText = `${fund.title} ${fund.category} ${fund.eligibility} ${fund.description} ${fund.agency}`.toLowerCase();

    // 1. 업력 요건 (Business Age / Years)
    const isYouthOrEarlyStartup = fundText.includes('청년') || fundText.includes('초기') || fundText.includes('3년') || fundText.includes('7년');
    const isMatureGrowth = fundText.includes('성장') || fundText.includes('도약') || fundText.includes('스케일업');

    let ageStatus: 'QUALIFIED' | 'REVIEW_NEEDED' | 'DISQUALIFIED' | 'BONUS' = 'QUALIFIED';
    let ageStatusText = '조건 부합 (적격)';
    let ageExplanation = `대표님 사업장 업력은 ${businessAgeYears}년차로, `;

    if (isYouthOrEarlyStartup) {
      if (businessAgeYears <= 7) {
        ageStatus = 'QUALIFIED';
        ageStatusText = '초기창업 요건 완벽 충족';
        ageExplanation += '창업 7년 이내 초기·도약기 소상공인 지원 기준에 매우 적합합니다.';
      } else {
        ageStatus = 'REVIEW_NEEDED';
        ageStatusText = '업력 기준 확인 요망';
        ageExplanation += '창업 7년 초과 기업인 경우 일반경영안정자금 또는 성숙기 특화 트랙으로 접수 가능 여부 확인이 필요합니다.';
      }
    } else {
      ageStatus = 'QUALIFIED';
      ageStatusText = '업력 제한 없음 (적격)';
      ageExplanation += '본 자금은 업력 제한 없이 영업 중인 모든 소상공인이 신청 가능합니다.';
    }

    items.push({
      id: 'crit-age',
      category: 'AGE',
      title: '사업 영위 기간 (업력 요건)',
      fundCriterion: isYouthOrEarlyStartup ? '창업 7년 이내 초기·도약기 소상공인' : '업력 무관 (영업 중인 소상공인 전원)',
      userProfileValue: `설립 ${profile?.foundedYear || '2023'}년 (업력 ${businessAgeYears}년차)`,
      status: ageStatus,
      statusText: ageStatusText,
      explanation: ageExplanation,
      isChecked: ageStatus === 'QUALIFIED',
      tip: '사업자등록증명원 상의 개업연월일 기준으로 심사됩니다.',
      iconName: 'Calendar'
    });

    // 2. 사업자 형태 (Business Type)
    const businessTypeLabel = getBusinessTypeLabel(profile?.businessType);
    let bTypeStatus: 'QUALIFIED' | 'REVIEW_NEEDED' | 'DISQUALIFIED' | 'BONUS' = 'QUALIFIED';
    let bTypeStatusText = '형태 적합 (적격)';
    let bTypeExp = `현재 ${businessTypeLabel}로 등록되어 있으며, 본 정책자금의 지원 형태 요건과 완벽히 일치합니다.`;

    if (fundText.includes('예비창업') && profile?.businessType !== BusinessType.PRE_STARTUP) {
      bTypeStatus = 'QUALIFIED';
      bTypeStatusText = '기창업자 접수 가능';
      bTypeExp = '기창업 소상공인 및 신규 전환 트랙 모두 접수 가능합니다.';
    } else if (fundText.includes('법인전용') && profile?.businessType !== BusinessType.CORPORATION) {
      bTypeStatus = 'REVIEW_NEEDED';
      bTypeStatusText = '개인사업자 확인 필요';
      bTypeExp = '개인사업자 신청 가능 여부(소진공 일반 트랙)를 지점 접수 전 확인하세요.';
    }

    items.push({
      id: 'crit-btype',
      category: 'BUSINESS_TYPE',
      title: '사업자등록 형태',
      fundCriterion: '개인사업자 및 중소법인 (정상 사업자등록 유지)',
      userProfileValue: businessTypeLabel,
      status: bTypeStatus,
      statusText: bTypeStatusText,
      explanation: bTypeExp,
      isChecked: bTypeStatus === 'QUALIFIED',
      tip: '휴업 또는 폐업 상태가 아닌 정상 가동 사업자여야 합니다.',
      iconName: 'Building'
    });

    // 3. 업종 적합성 및 융자제외업종 배제 (Industry Eligibility)
    const industryLabel = getIndustryLabel(profile?.industry);
    const isManufacturing = profile?.industry === Industry.MANUFACTURING;
    const isTech = profile?.industry === Industry.IT_SOFTWARE;
    const isFood = profile?.industry === Industry.RESTAURANT;
    
    let indStatus: 'QUALIFIED' | 'REVIEW_NEEDED' | 'DISQUALIFIED' | 'BONUS' = 'QUALIFIED';
    let indStatusText = '지원 대상 업종 (적격)';
    let indExp = `대표님의 영위 업종(${industryLabel})은 중기부 정책자금 융자지원 대상 업종입니다.`;

    if (fundText.includes('제조') || fundText.includes('스마트공방')) {
      if (isManufacturing) {
        indStatus = 'BONUS';
        indStatusText = '제조업 특화 우대 (가점)';
        indExp = '제조업 소공인 특화 자금으로 가점 및 한도 우대 대상에 해당합니다.';
      } else {
        indStatus = 'REVIEW_NEEDED';
        indStatusText = '타 업종 적용 확인';
        indExp = '제조 연계 공정 또는 OEM 생산 여부에 따라 소공인 트랙 지원 가능 여부를 확인하세요.';
      }
    } else if (fundText.includes('스마트상점') || fundText.includes('소상공인')) {
      if (isFood || profile?.industry === Industry.RETAIL) {
        indStatus = 'BONUS';
        indStatusText = '골목상권 외식/도소매 우대';
        indExp = '골목상권 활성화 및 물가안정 취약 소상공인 우선 지원 대상입니다.';
      }
    }

    items.push({
      id: 'crit-industry',
      category: 'INDUSTRY',
      title: '영위 업종 및 영리 활동',
      fundCriterion: '소상공인 융자대상 업종 (유흥·사행성·전문투기 제외)',
      userProfileValue: industryLabel,
      status: indStatus,
      statusText: indStatusText,
      explanation: indExp,
      isChecked: indStatus === 'QUALIFIED' || indStatus === 'BONUS',
      tip: '국세청 표준산업분류코드 5자리 기준으로 최종 판정됩니다.',
      iconName: 'TrendingUp'
    });

    // 4. 상시 근로자 수 (소상공인 기본 요건)
    const empCount = profile?.employees ?? 2;
    const maxEmpAllowed = isManufacturing ? 10 : 5;
    const isEmpQualified = empCount < maxEmpAllowed;

    items.push({
      id: 'crit-emp',
      category: 'EMPLOYEES',
      title: '상시 근로자 수 (소상공인 기준)',
      fundCriterion: isManufacturing ? '상시 근로자 10인 미만 (제조·건설·운수)' : '상시 근로자 5인 미만 (도소매·음식·서비스)',
      userProfileValue: `상시 근로자 ${empCount}명`,
      status: isEmpQualified ? 'QUALIFIED' : 'REVIEW_NEEDED',
      statusText: isEmpQualified ? '소상공인 규모 충족' : '소기업 트랙 확인 필요',
      explanation: isEmpQualified
        ? `상시 근로자 수 ${empCount}명으로 ${maxEmpAllowed}인 미만 소상공인 기준을 여유 있게 충족합니다.`
        : `근로자 수가 소상공인 기준(${maxEmpAllowed}인)을 상회하므로 소기업/중진공 융자 트랙으로 접수 권장됩니다.`,
      isChecked: isEmpQualified,
      tip: '4대보험 가입자명부 또는 건강보험 월별고지서로 확인합니다.',
      iconName: 'Users'
    });

    // 5. 신용점수 및 신용관리 (Credit Score)
    const creditScore = profile?.creditScore ?? 820;
    const isLowCreditFund = fundText.includes('저신용') || fundText.includes('재도전') || fundText.includes('희망대출') || fundText.includes('취약');
    
    let creditStatus: 'QUALIFIED' | 'REVIEW_NEEDED' | 'DISQUALIFIED' | 'BONUS' = 'QUALIFIED';
    let creditStatusText = '신용도 우수 (승인 유리)';
    let creditExp = `현재 신용점수 약 ${creditScore}점으로 정책자금 및 보증서 발급 심사에서 우량 등급에 해당합니다.`;

    if (isLowCreditFund) {
      if (creditScore <= 744) {
        creditStatus = 'BONUS';
        creditStatusText = '저신용 특례 전용 적합';
        creditExp = '신용점수 744점 이하 전용 저신용 지원 자금 타겟에 정확히 부합합니다.';
      } else {
        creditStatus = 'REVIEW_NEEDED';
        creditStatusText = '일반 트랙 권장';
        creditExp = '신용점수가 높아 저신용 전용 트랙보다는 일반경영안정 또는 보증재단 우대금리 트랙이 더 유리합니다.';
      }
    } else {
      if (creditScore < 600) {
        creditStatus = 'REVIEW_NEEDED';
        creditStatusText = '보증서 발급 심사 확인';
        creditExp = '신용회복지원 또는 소진공 직접대출(재도전특례) 트랙을 우선 검토하세요.';
      }
    }

    items.push({
      id: 'crit-credit',
      category: 'CREDIT',
      title: '신용점수 및 신용관리 상태',
      fundCriterion: isLowCreditFund ? 'NICE 744점 이하 또는 신용취약 차주' : 'NICE/KCB 600점 이상 및 연체 미보유',
      userProfileValue: `NICE/KCB ${creditScore}점`,
      status: creditStatus,
      statusText: creditStatusText,
      explanation: creditExp,
      isChecked: creditStatus === 'QUALIFIED' || creditStatus === 'BONUS',
      tip: '신용평가사(NICE/KCB) 최근 3개월간 단기연체 이력이 없어야 안전합니다.',
      iconName: 'CreditCard'
    });

    // 6. 연매출 및 규모 요건 (Annual Revenue)
    const revenueWon = profile?.annualRevenue ?? 120000000;
    const revenueDisplay = revenueWon >= 100000000 
      ? `${(revenueWon / 100000000).toFixed(1)}억원` 
      : `${(revenueWon / 10000).toLocaleString()}만원`;

    items.push({
      id: 'crit-rev',
      category: 'REVENUE',
      title: '연간 매출액 및 영리 지속성',
      fundCriterion: '소기업·소상공인 연매출 상한선(업종별 10억~120억 이하)',
      userProfileValue: `연매출 약 ${revenueDisplay}`,
      status: 'QUALIFIED',
      statusText: '매출 규모 적합',
      explanation: `연매출 ${revenueDisplay}으로 소상공인 매출 기준 상한선 내에 안정적으로 포함되며 정상적인 영업 실적이 확인됩니다.`,
      isChecked: true,
      tip: '부가가치세과세표준증명원(최근 1~2개년)을 통해 실적을 증빙합니다.',
      iconName: 'TrendingUp'
    });

    // 7. 지역 관할 및 사업장 주소지 (Location & Jurisdiction)
    const location = profile?.businessAddress || profile?.location || '서울/수도권';
    const isSeoulFund = fundText.includes('서울');
    const isGyeonggiFund = fundText.includes('경기');
    const isLocalSpecific = isSeoulFund || isGyeonggiFund || fundText.includes('부산') || fundText.includes('대구');

    let locStatus: 'QUALIFIED' | 'REVIEW_NEEDED' | 'DISQUALIFIED' | 'BONUS' = 'QUALIFIED';
    let locStatusText = '관할 소재지 일치';
    let locExp = `사업장 소재지(${location})가 정책자금 주관기관(${fund.agency})의 관할 지원 구역에 부합합니다.`;

    if (isLocalSpecific) {
      if (isSeoulFund && !location.includes('서울')) {
        locStatus = 'REVIEW_NEEDED';
        locStatusText = '타 지자체 확인 필요';
        locExp = '서울시 특화 자금이므로 사업장 주소지가 서울 소재인지 확인이 필요합니다.';
      } else if (isGyeonggiFund && !location.includes('경기')) {
        locStatus = 'REVIEW_NEEDED';
        locStatusText = '타 지자체 확인 필요';
        locExp = '경기도 특화 자금이므로 사업장 주소지가 경기도 소재인지 확인이 필요합니다.';
      }
    }

    items.push({
      id: 'crit-loc',
      category: 'LOCATION',
      title: '사업장 소재지 및 관할 구역',
      fundCriterion: isLocalSpecific ? '지자체 관할 구역 내 사업장 보유' : '전국 소상공인 (지역 제한 없음)',
      userProfileValue: location,
      status: locStatus,
      statusText: locStatusText,
      explanation: locExp,
      isChecked: locStatus === 'QUALIFIED',
      tip: '사업자등록증 상 본점/사업장 주소지 관할 지점으로 신청해야 합니다.',
      iconName: 'MapPin'
    });

    // 8. 세금 체납 및 금융 질서 (Tax & Debt Delinquency Self-check)
    items.push({
      id: 'crit-tax-debt',
      category: 'TAX_DEBT',
      title: '국세·지방세 체납 및 연체 결격사유',
      fundCriterion: '국세·지방세 완납 및 금융기관 대출 연체금 미보유',
      userProfileValue: '체납 없음 (자가진단 확인 필요)',
      status: 'QUALIFIED',
      statusText: '필수 결격사유 점검',
      explanation: '국세청 홈택스 및 정부24를 통한 국세·지방세 완납증명서 발급이 가능해야 하며 현재 연체 대출이 없어야 합니다.',
      isChecked: true,
      tip: '신청 당일 유효한 국세·지방세 납세증명서 제출이 필수입니다.',
      iconName: 'ShieldAlert'
    });

    return items;
  }, [fund, profile]);

  // Checklist interactive state with LocalStorage persistence per fund
  const storageKey = `bizmatch_fund_eligibility_${fund.id || fund.title}`;
  const [checkedMap, setCheckedMap] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem(storageKey);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    // Default checked states from initialCriteria
    const defaults: Record<string, boolean> = {};
    initialCriteria.forEach(item => {
      defaults[item.id] = item.isChecked;
    });
    return defaults;
  });

  // Save changes to localStorage
  const handleToggleCheck = (id: string) => {
    const updated = {
      ...checkedMap,
      [id]: !checkedMap[id]
    };
    setCheckedMap(updated);
    try {
      localStorage.setItem(storageKey, JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleCheckAll = (checked: boolean) => {
    const updated: Record<string, boolean> = {};
    initialCriteria.forEach(item => {
      updated[item.id] = checked;
    });
    setCheckedMap(updated);
    try {
      localStorage.setItem(storageKey, JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleResetToAuto = () => {
    const defaults: Record<string, boolean> = {};
    initialCriteria.forEach(item => {
      defaults[item.id] = item.status === 'QUALIFIED' || item.status === 'BONUS';
    });
    setCheckedMap(defaults);
    try {
      localStorage.setItem(storageKey, JSON.stringify(defaults));
    } catch (e) {
      console.error(e);
    }
  };

  // Stats calculation
  const totalCount = initialCriteria.length;
  const checkedCount = initialCriteria.filter(item => checkedMap[item.id]).length;
  const qualifiedCount = initialCriteria.filter(item => item.status === 'QUALIFIED' || item.status === 'BONUS').length;
  const reviewNeededCount = initialCriteria.filter(item => item.status === 'REVIEW_NEEDED').length;
  const matchRate = Math.round((checkedCount / totalCount) * 100);

  // Filter items
  const filteredItems = useMemo(() => {
    if (filterType === 'QUALIFIED') {
      return initialCriteria.filter(item => item.status === 'QUALIFIED' || item.status === 'BONUS');
    }
    if (filterType === 'REVIEW_NEEDED') {
      return initialCriteria.filter(item => item.status === 'REVIEW_NEEDED' || item.status === 'DISQUALIFIED');
    }
    return initialCriteria;
  }, [initialCriteria, filterType]);

  const renderStatusBadge = (status: 'QUALIFIED' | 'REVIEW_NEEDED' | 'DISQUALIFIED' | 'BONUS', text: string) => {
    switch (status) {
      case 'BONUS':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-50 text-amber-700 border border-amber-200">
            <Sparkles className="w-3 h-3 text-amber-500" />
            {text}
          </span>
        );
      case 'QUALIFIED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-50 text-emerald-700 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-500" />
            {text}
          </span>
        );
      case 'REVIEW_NEEDED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-50 text-amber-800 border border-amber-300">
            <AlertTriangle className="w-3 h-3 text-amber-600" />
            {text}
          </span>
        );
      case 'DISQUALIFIED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-rose-50 text-rose-700 border border-rose-200">
            <XCircle className="w-3 h-3 text-rose-500" />
            {text}
          </span>
        );
    }
  };

  return (
    <div className="bg-gradient-to-br from-slate-50/90 via-emerald-50/20 to-indigo-50/30 rounded-2xl border border-emerald-100 p-5 shadow-xs space-y-4 my-4 transition-all">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-emerald-100/80">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
            <UserCheck className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-black text-slate-900 tracking-tight">
                내 프로필 대조 실시간 자격 요건 체크리스트
              </h4>
              <span className="bg-emerald-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full shadow-2xs">
                실시간 진단
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium">
              대표님의 사업장 정보와 정책자금 심사 기준을 1:1 대조하여 자격 충족 여부를 실시간으로 판정합니다.
            </p>
          </div>
        </div>

        {/* Progress & Quick Actions */}
        <div className="flex items-center gap-2 self-end sm:self-center">
          <div className="text-right mr-1">
            <div className="text-xs font-black text-slate-900">
              <span className="text-emerald-600">{checkedCount}</span> / {totalCount}개 충족
            </div>
            <div className="text-[10px] font-bold text-slate-400">
              충족률 {matchRate}%
            </div>
          </div>
          
          {!isPrinting && (
            <button
              type="button"
              onClick={() => setIsExpanded(!isExpanded)}
              className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:bg-slate-50 transition-colors"
              title={isExpanded ? '접기' : '펼치기'}
            >
              {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          )}
        </div>
      </div>

      {/* Realtime Progress Bar & Overall Assessment Banner */}
      <div className="space-y-2">
        <div className="w-full bg-slate-200/80 rounded-full h-2 overflow-hidden">
          <div 
            className={`h-full transition-all duration-500 rounded-full ${
              matchRate === 100 
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500' 
                : matchRate >= 80 
                ? 'bg-gradient-to-r from-indigo-500 to-emerald-500' 
                : 'bg-gradient-to-r from-amber-500 to-indigo-500'
            }`}
            style={{ width: `${matchRate}%` }}
          />
        </div>

        <div className={`p-3 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-xs font-bold ${
          matchRate === 100
            ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
            : matchRate >= 80
            ? 'bg-indigo-50/80 border-indigo-200 text-indigo-900'
            : 'bg-amber-50 border-amber-200 text-amber-900'
        }`}>
          <div className="flex items-center gap-2">
            {matchRate === 100 ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : matchRate >= 80 ? (
              <Sparkles className="w-4 h-4 text-indigo-600 shrink-0" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
            )}
            <span>
              {matchRate === 100
                ? '🎉 대표님의 사업장 프로필이 본 정책자금의 모든 자격 기준을 100% 충족하여 승인 가능성이 매우 높습니다!'
                : matchRate >= 80
                ? `💡 ${totalCount}개 중 ${checkedCount}개 요건이 충족되었습니다. 남은 항목의 자가진단 서류를 확인해 주세요.`
                : '⚠️ 일부 요건에 대해 관할 지점 또는 서류 보완이 필요할 수 있습니다.'}
            </span>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {reviewNeededCount > 0 && (
              <span className="text-[10px] font-black bg-amber-200/70 text-amber-800 px-2 py-0.5 rounded-md">
                확인 요망 {reviewNeededCount}건
              </span>
            )}
          </div>
        </div>
      </div>

      {isExpanded && (
        <>
          {/* Controls toolbar */}
          {!isPrinting && (
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <div className="flex items-center gap-1 text-xs">
                <button
                  type="button"
                  onClick={() => setFilterType('ALL')}
                  className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors ${
                    filterType === 'ALL'
                      ? 'bg-slate-900 text-white'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  전체 ({initialCriteria.length})
                </button>
                <button
                  type="button"
                  onClick={() => setFilterType('QUALIFIED')}
                  className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors ${
                    filterType === 'QUALIFIED'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-emerald-50'
                  }`}
                >
                  충족 항목 ({qualifiedCount})
                </button>
                {reviewNeededCount > 0 && (
                  <button
                    type="button"
                    onClick={() => setFilterType('REVIEW_NEEDED')}
                    className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-colors ${
                      filterType === 'REVIEW_NEEDED'
                        ? 'bg-amber-600 text-white'
                        : 'bg-white text-slate-600 border border-slate-200 hover:bg-amber-50'
                    }`}
                  >
                    확인 필요 ({reviewNeededCount})
                  </button>
                )}
              </div>

              <div className="flex items-center gap-1.5 text-[11px] ml-auto">
                <button
                  type="button"
                  onClick={() => handleCheckAll(true)}
                  className="px-2 py-1 text-slate-600 hover:text-slate-900 bg-white border border-slate-200 rounded-lg font-medium hover:bg-slate-50 transition-colors"
                >
                  전체 체크
                </button>
                <button
                  type="button"
                  onClick={handleResetToAuto}
                  className="px-2 py-1 text-indigo-600 hover:text-indigo-900 bg-indigo-50/60 border border-indigo-200 rounded-lg font-bold hover:bg-indigo-100 transition-colors flex items-center gap-1"
                  title="프로필 기반 자동 판정 상태로 초기화"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>자동 판정값 복원</span>
                </button>
              </div>
            </div>
          )}

          {/* Checklist Items List */}
          <div className="space-y-2.5 pt-1">
            {filteredItems.map((item) => {
              const isChecked = !!checkedMap[item.id];
              return (
                <div
                  key={item.id}
                  className={`p-3.5 rounded-xl border transition-all ${
                    isChecked
                      ? 'bg-white/90 border-emerald-200 shadow-2xs hover:border-emerald-300'
                      : 'bg-white/60 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {/* Checkbox */}
                    <button
                      type="button"
                      onClick={() => handleToggleCheck(item.id)}
                      disabled={isPrinting}
                      className={`mt-0.5 w-5 h-5 rounded-md flex items-center justify-center transition-all cursor-pointer shrink-0 ${
                        isChecked
                          ? 'bg-emerald-600 text-white shadow-2xs hover:bg-emerald-700'
                          : 'border-2 border-slate-300 bg-white hover:border-emerald-500'
                      }`}
                    >
                      {isChecked && <CheckCircle2 className="w-4 h-4 stroke-[3]" />}
                    </button>

                    {/* Content Details */}
                    <div className="flex-grow space-y-1.5">
                      <div className="flex flex-wrap items-center justify-between gap-1.5">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-black text-slate-900">
                            {item.title}
                          </span>
                        </div>
                        <div>
                          {renderStatusBadge(item.status, item.statusText)}
                        </div>
                      </div>

                      {/* Side-by-side comparison table / pill view */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 bg-slate-50/80 p-2.5 rounded-lg border border-slate-100 text-[11px]">
                        <div className="flex items-start gap-1.5">
                          <span className="text-[10px] font-black text-slate-400 uppercase shrink-0 mt-0.5">
                            👤 내 프로필:
                          </span>
                          <span className="font-bold text-slate-800">
                            {item.userProfileValue}
                          </span>
                        </div>
                        <div className="flex items-start gap-1.5 border-t md:border-t-0 md:border-l border-slate-200 pt-1.5 md:pt-0 md:pl-2.5">
                          <span className="text-[10px] font-black text-indigo-400 uppercase shrink-0 mt-0.5">
                            📋 심사 기준:
                          </span>
                          <span className="font-bold text-indigo-950">
                            {item.fundCriterion}
                          </span>
                        </div>
                      </div>

                      {/* Explanation & Action Tip */}
                      <div className="text-[11px] text-slate-600 leading-relaxed font-medium pl-0.5">
                        <p>{item.explanation}</p>
                        {item.tip && (
                          <div className="flex items-center gap-1.5 mt-1 text-[10px] text-slate-500">
                            <Info className="w-3 h-3 text-slate-400 shrink-0" />
                            <span>증빙 팁: {item.tip}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Bottom Guidance Actions */}
          {!isPrinting && (
            <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-emerald-100/60 text-xs">
              <span className="text-[11px] text-slate-500 font-medium">
                💡 체크박스를 직접 클릭하여 실시간 준비 상태를 저장하고 점검할 수 있습니다.
              </span>
              <div className="flex items-center gap-2">
                {onOpenDocumentGuide && (
                  <button
                    type="button"
                    onClick={onOpenDocumentGuide}
                    className="px-2.5 py-1.5 text-xs font-bold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition-colors flex items-center gap-1"
                  >
                    <FileText className="w-3.5 h-3.5 text-indigo-600" />
                    <span>필요 서류 발급 안내</span>
                  </button>
                )}
                {onOpenPdfChecklist && (
                  <button
                    type="button"
                    onClick={onOpenPdfChecklist}
                    className="px-2.5 py-1.5 text-xs font-bold text-blue-700 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors flex items-center gap-1"
                  >
                    <span>공고문 PDF 체크리스트</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
