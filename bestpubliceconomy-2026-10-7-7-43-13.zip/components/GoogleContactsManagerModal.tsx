import React, { useState, useEffect } from 'react';
import { 
  X, 
  Users, 
  Search, 
  Plus, 
  Trash2, 
  Edit3, 
  Mail, 
  Phone, 
  Building2, 
  Briefcase, 
  UserCheck, 
  Sparkles, 
  ExternalLink, 
  Loader2, 
  AlertTriangle, 
  RefreshCw,
  Send,
  CheckCircle2,
  FileText
} from 'lucide-react';
import { 
  fetchGoogleContacts, 
  searchGoogleContacts, 
  createGoogleContact, 
  updateGoogleContact, 
  deleteGoogleContact, 
  GoogleContact 
} from '../services/workspaceService';
import { PolicyFund, UserProfile } from '../types';

interface GoogleContactsManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  token?: string | null;
  profile?: UserProfile | null;
  targetFund?: PolicyFund | null;
  onShareToContact?: (contact: GoogleContact, fund?: PolicyFund | null) => void;
}

export const GoogleContactsManagerModal: React.FC<GoogleContactsManagerModalProps> = ({
  isOpen,
  onClose,
  token,
  profile,
  targetFund,
  onShareToContact
}) => {
  const [contacts, setContacts] = useState<GoogleContact[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<'ALL' | 'CONSULTANT' | 'BANKER' | 'TAX_ACCOUNTANT' | 'PARTNER'>('ALL');
  
  // New / Edit Contact Form State
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingContact, setEditingContact] = useState<GoogleContact | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    organization: '',
    title: '',
    notes: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Destructive Action: Mandatory Confirmation Dialog State
  const [deleteTarget, setDeleteTarget] = useState<GoogleContact | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Success Feedback Toast
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  const loadContacts = async () => {
    if (!token) return;
    setIsLoading(true);
    try {
      const data = await fetchGoogleContacts(token, 100);
      setContacts(data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && token) {
      loadContacts();
    }
  }, [isOpen, token]);

  const handleSearch = async (query: string) => {
    setSearchQuery(query);
    if (!token) return;
    if (query.trim().length > 1) {
      setIsLoading(true);
      try {
        const results = await searchGoogleContacts(token, query);
        setContacts(results);
      } catch (err) {
        console.error(err);
      } finally {
        setIsLoading(false);
      }
    } else if (query.trim().length === 0) {
      loadContacts();
    }
  };

  const handleOpenAddForm = () => {
    setEditingContact(null);
    setFormData({
      name: '',
      email: '',
      phone: '',
      organization: targetFund ? `${targetFund.agency} 상담역` : '',
      title: '정책자금 전담 심사역',
      notes: targetFund ? `관련 정책자금: ${targetFund.title}` : ''
    });
    setFormError(null);
    setIsFormOpen(true);
  };

  const handleOpenEditForm = (contact: GoogleContact) => {
    setEditingContact(contact);
    setFormData({
      name: contact.name,
      email: contact.email || '',
      phone: contact.phone || '',
      organization: contact.organization || '',
      title: contact.title || '',
      notes: contact.notes || ''
    });
    setFormError(null);
    setIsFormOpen(true);
  };

  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    if (!formData.name.trim()) {
      setFormError('이름을 입력해주세요.');
      return;
    }

    setIsSubmitting(true);
    setFormError(null);

    try {
      if (editingContact) {
        // Update contact
        const updated = await updateGoogleContact(
          token,
          editingContact.resourceName,
          editingContact.etag,
          formData
        );
        setContacts(prev => prev.map(c => c.resourceName === updated.resourceName ? updated : c));
        setFeedbackMessage(`'${updated.name}' 연락처가 Google Contacts에 업데이트되었습니다.`);
      } else {
        // Create contact
        const created = await createGoogleContact(token, formData);
        setContacts(prev => [created, ...prev]);
        setFeedbackMessage(`'${created.name}' 님이 Google 연락처에 신규 저장되었습니다.`);
      }
      setIsFormOpen(false);
      setTimeout(() => setFeedbackMessage(null), 3000);
    } catch (err: any) {
      setFormError(err.message || '저장 중 오류가 발생했습니다.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Explicit user confirmation for destructive delete
  const handleConfirmDelete = async () => {
    if (!token || !deleteTarget) return;
    setIsDeleting(true);
    try {
      await deleteGoogleContact(token, deleteTarget.resourceName);
      setContacts(prev => prev.filter(c => c.resourceName !== deleteTarget.resourceName));
      setFeedbackMessage(`'${deleteTarget.name}' 연락처가 Google 계정에서 영구 삭제되었습니다.`);
      setDeleteTarget(null);
      setTimeout(() => setFeedbackMessage(null), 3000);
    } catch (err: any) {
      alert(err.message || '삭제에 실패했습니다.');
    } finally {
      setIsDeleting(false);
    }
  };

  const filteredContacts = contacts.filter(contact => {
    if (activeCategory === 'ALL') return true;
    return contact.category === activeCategory;
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-4xl max-h-[90vh] flex flex-col overflow-hidden">
        
        {/* Modal Header */}
        <div className="p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-white/10 flex items-center justify-center text-blue-300 border border-white/10 shadow-inner">
              <Users className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-black border border-blue-400/30">
                  Google People API 연동
                </span>
                <h2 className="text-xl font-black">Google Contacts 인맥 & 자문단 디렉토리</h2>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                구글 계정의 연락처를 실시간 조회·관리하고, 정책자금 심사역 및 세무·금융 자문위원을 연계하세요.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feedback Banner */}
        {feedbackMessage && (
          <div className="bg-emerald-50 border-b border-emerald-200 px-6 py-2.5 flex items-center gap-2 text-emerald-800 text-xs font-bold animate-fade-in shrink-0">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{feedbackMessage}</span>
          </div>
        )}

        {/* Action Controls & Search Bar */}
        <div className="p-5 border-b border-slate-200 bg-slate-50/70 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              placeholder="이름, 이메일, 전화번호, 소속 검색..."
              className="w-full pl-10 pr-4 py-2 text-xs bg-white rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 font-medium placeholder:text-slate-400 shadow-2xs"
            />
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
            {[
              { id: 'ALL', label: '전체' },
              { id: 'CONSULTANT', label: '자문위원' },
              { id: 'BANKER', label: '금융·은행' },
              { id: 'TAX_ACCOUNTANT', label: '세무·회계' },
              { id: 'PARTNER', label: '협력사' }
            ].map(cat => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  activeCategory === cat.id
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto">
            <button
              onClick={loadContacts}
              disabled={isLoading}
              title="새로고침"
              className="p-2 bg-white hover:bg-slate-100 text-slate-600 border border-slate-200 rounded-xl transition-colors cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-blue-600' : ''}`} />
            </button>

            <button
              onClick={handleOpenAddForm}
              className="flex-1 sm:flex-none px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>연락처 추가</span>
            </button>
          </div>
        </div>

        {/* Contacts Content Area */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {isLoading && contacts.length === 0 ? (
            <div className="py-20 text-center space-y-3">
              <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto" />
              <p className="text-xs font-bold text-slate-500">Google Contacts에서 연락처 동기화 중...</p>
            </div>
          ) : filteredContacts.length === 0 ? (
            <div className="py-16 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 p-8 space-y-3">
              <Users className="w-10 h-10 text-slate-300 mx-auto" />
              <p className="text-sm font-bold text-slate-700">등록된 Google 연락처가 없습니다.</p>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                상단의 [연락처 추가] 버튼을 눌러 정책자금 담당자, 세무사, 금융기관 심사역을 Google Contacts에 저장해보세요.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredContacts.map(contact => (
                <div
                  key={contact.resourceName}
                  className="p-4 bg-white rounded-2xl border border-slate-200 hover:border-blue-300 hover:shadow-md transition-all flex flex-col justify-between space-y-3 group"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      {contact.photoUrl ? (
                        <img 
                          src={contact.photoUrl} 
                          alt={contact.name} 
                          className="w-11 h-11 rounded-2xl object-cover border border-slate-200 shrink-0" 
                        />
                      ) : (
                        <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-blue-500 to-indigo-600 text-white font-black text-sm flex items-center justify-center shrink-0 shadow-xs">
                          {contact.name.slice(0, 1)}
                        </div>
                      )}

                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <h4 className="font-black text-sm text-slate-900 truncate">
                            {contact.name}
                          </h4>
                          {contact.title && (
                            <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded-md truncate">
                              {contact.title}
                            </span>
                          )}
                        </div>
                        {contact.organization && (
                          <p className="text-xs text-slate-500 font-medium truncate flex items-center gap-1 mt-0.5">
                            <Building2 className="w-3 h-3 text-slate-400 shrink-0" />
                            <span>{contact.organization}</span>
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Action Menu */}
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        onClick={() => handleOpenEditForm(contact)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-blue-600 hover:bg-blue-50 transition-colors cursor-pointer"
                        title="연락처 수정"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setDeleteTarget(contact)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                        title="Google 연락처에서 삭제"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Contact Info Items */}
                  <div className="space-y-1.5 text-xs text-slate-600 pt-2 border-t border-slate-100">
                    {contact.phone && (
                      <div className="flex items-center justify-between">
                        <a 
                          href={`tel:${contact.phone}`} 
                          className="flex items-center gap-1.5 hover:text-blue-600 font-medium truncate"
                        >
                          <Phone className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{contact.phone}</span>
                        </a>
                      </div>
                    )}
                    {contact.email && (
                      <div className="flex items-center justify-between">
                        <a 
                          href={`mailto:${contact.email}`} 
                          className="flex items-center gap-1.5 hover:text-blue-600 font-medium truncate"
                        >
                          <Mail className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                          <span className="truncate">{contact.email}</span>
                        </a>
                      </div>
                    )}
                    {contact.notes && (
                      <p className="text-[11px] text-slate-500 bg-slate-50 p-2 rounded-xl line-clamp-2">
                        {contact.notes}
                      </p>
                    )}
                  </div>

                  {/* Quick Share to Contact Button */}
                  {onShareToContact && (
                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          onShareToContact(contact, targetFund);
                          onClose();
                        }}
                        className="w-full py-2 px-3 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                      >
                        <Send className="w-3.5 h-3.5 text-blue-600" />
                        <span>정책자금 리포트 이메일 공유</span>
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-100/80 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500 shrink-0">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>Google 계정과 실시간 양방향 동기화 중 ({contacts.length}개 연락처)</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl font-bold cursor-pointer"
          >
            닫기
          </button>
        </div>
      </div>

      {/* New / Edit Contact Form Modal */}
      {isFormOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 shadow-2xl border border-slate-200 w-full max-w-md space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="font-black text-base text-slate-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-600" />
                <span>{editingContact ? 'Google 연락처 수정' : '새 Google 연락처 등록'}</span>
              </h3>
              <button 
                onClick={() => setIsFormOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {formError && (
              <div className="p-3 bg-rose-50 text-rose-700 text-xs font-bold rounded-xl border border-rose-200 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmitForm} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  이름 (필수) *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={e => setFormData({ ...formData, name: e.target.value })}
                  placeholder="예: 김상담 심사관"
                  className="w-full p-2.5 bg-slate-50 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-blue-500 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    소속 기관 / 회사
                  </label>
                  <input
                    type="text"
                    value={formData.organization}
                    onChange={e => setFormData({ ...formData, organization: e.target.value })}
                    placeholder="예: 신용보증기금 지점"
                    className="w-full p-2.5 bg-slate-50 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-blue-500 font-medium"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    직책 / 담당 업무
                  </label>
                  <input
                    type="text"
                    value={formData.title}
                    onChange={e => setFormData({ ...formData, title: e.target.value })}
                    placeholder="예: 기업금융팀 차장"
                    className="w-full p-2.5 bg-slate-50 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-blue-500 font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    휴대전화 / 직통
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={e => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="010-0000-0000"
                    className="w-full p-2.5 bg-slate-50 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-blue-500 font-medium"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    이메일 주소
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    placeholder="consultant@partner.com"
                    className="w-full p-2.5 bg-slate-50 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-blue-500 font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  메모 / 상담 내역
                </label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={e => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="예: 2026 청년고용연계자금 대출 전문 상담사"
                  className="w-full p-2.5 bg-slate-50 rounded-xl border border-slate-200 focus:bg-white focus:ring-2 focus:ring-blue-500 font-medium"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold cursor-pointer"
                >
                  취소
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-black flex items-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>{editingContact ? '수정 완료' : 'Google 연락처 저장'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MANDATORY Explicit Confirmation Dialog for Destructive Delete */}
      {deleteTarget && (
        <div className="fixed inset-0 z-70 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-fade-in">
          <div className="bg-white rounded-3xl p-6 shadow-2xl border border-rose-200 w-full max-w-md space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div>
              <h3 className="text-base font-black text-slate-900">
                Google 연락처 영구 삭제 확인
              </h3>
              <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                <strong>'{deleteTarget.name}'</strong>({deleteTarget.email || deleteTarget.phone || '상세 정보 없음'}) 연락처를 Google 계정에서 완전히 삭제하시겠습니까?
              </p>
              <div className="mt-2 p-3 bg-amber-50 rounded-xl border border-amber-200 text-[11px] text-amber-900 font-medium">
                ⚠️ 이 작업은 Google Contacts 클라우드에서 영구적으로 삭제되며 되돌릴 수 없습니다.
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                disabled={isDeleting}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs cursor-pointer"
              >
                취소 (유지)
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-black text-xs flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                {isDeleting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                <span>확인 및 영구 삭제</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
