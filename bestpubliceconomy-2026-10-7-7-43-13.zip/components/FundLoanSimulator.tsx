import React, { useState, useMemo, useEffect } from 'react';
import { PolicyFund, UserProfile } from '../types';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as RechartsTooltip,
  Legend,
  ReferenceLine,
  Cell
} from 'recharts';
import {
  Calculator,
  Percent,
  Calendar,
  DollarSign,
  TrendingDown,
  ArrowRight,
  Sparkles,
  Layers,
  HelpCircle,
  Clock,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Download,
  Copy,
  Check,
  Building2,
  PieChart,
  BarChart3,
  AlertCircle,
  CheckCircle2,
  RefreshCw,
  Info,
  Maximize2,
  X,
  Sliders,
  Filter,
  FileSpreadsheet
} from 'lucide-react';

export type RepaymentType = 'EQUAL_PRINCIPAL_AND_INTEREST' | 'EQUAL_PRINCIPAL' | 'BULLET';

export interface ScheduleRow {
  month: number;
  isGracePeriod: boolean;
  principalPayment: number;
  interestPayment: number;
  totalMonthlyPayment: number;
  remainingBalance: number;
}

export interface SimulationResult {
  loanAmount: number;
  annualRate: number;
  totalMonths: number;
  graceMonths: number;
  repaymentType: RepaymentType;
  firstMonthlyPayment: number;
  avgMonthlyPayment: number;
  maxMonthlyPayment: number;
  totalInterest: number;
  totalRepayment: number;
  commercialTotalInterest: number;
  interestSaved: number;
  commercialRate: number;
  schedule: ScheduleRow[];
  burdenRatio?: number;
  burdenStatus?: 'VERY_SAFE' | 'SAFE' | 'CAUTION' | 'HIGH';
}

// Utility: parse interest rate from fund string
export function parseFundInterestRate(rateStr?: string): number {
  if (!rateStr) return 2.5;
  if (rateStr.includes('무이자') || rateStr.includes('0%')) return 0.0;
  
  // Look for decimals like "2.4%", "1.8 ~ 2.5%", "연 2.1%"
  const matches = rateStr.match(/(\d+(?:\.\d+)?)\s*%/g);
  if (matches && matches.length > 0) {
    const nums = matches.map((m) => parseFloat(m.replace('%', '')));
    // Take the lowest rate or the single rate
    return nums[0];
  }
  const generalNum = rateStr.match(/\d+(?:\.\d+)?/);
  if (generalNum) {
    const val = parseFloat(generalNum[0]);
    if (val < 20) return val; // reasonable percentage
  }
  return 2.5;
}

// Utility: parse max amount from fund string
export function parseFundMaxAmount(amountStr?: string): number {
  if (!amountStr) return 50000000;
  
  // Clean string
  const s = amountStr.replace(/,/g, '');
  
  // Check for 억 (100,000,000)
  const eokMatch = s.match(/(\d+(?:\.\d+)?)\s*억/);
  if (eokMatch) {
    return parseFloat(eokMatch[1]) * 100000000;
  }
  
  // Check for 천만 (10,000,000)
  const cheonMatch = s.match(/(\d+(?:\.\d+)?)\s*천만/);
  if (cheonMatch) {
    return parseFloat(cheonMatch[1]) * 10000000;
  }

  // Check for 만원 (10,000)
  const manMatch = s.match(/(\d+(?:\.\d+)?)\s*만/);
  if (manMatch) {
    return parseFloat(manMatch[1]) * 10000;
  }
  
  // Raw numbers in Won
  const rawNum = s.match(/\d+/);
  if (rawNum) {
    const n = parseInt(rawNum[0], 10);
    if (n >= 1000000) return n;
  }

  return 50000000;
}

export function formatKoreanWon(amount: number): string {
  if (amount <= 0) return '0원';
  if (amount >= 100000000) {
    const eok = Math.floor(amount / 100000000);
    const remainder = amount % 100000000;
    const man = Math.floor(remainder / 10000);
    if (man > 0) {
      return `${eok}억 ${man.toLocaleString('ko-KR')}만원`;
    }
    return `${eok}억원`;
  }
  if (amount >= 10000) {
    const man = Math.floor(amount / 10000);
    return `${man.toLocaleString('ko-KR')}만원`;
  }
  return `${Math.round(amount).toLocaleString('ko-KR')}원`;
}

export function calculateLoanSimulation(
  loanAmount: number,
  annualRate: number,
  periodYears: number,
  graceYears: number,
  repaymentType: RepaymentType,
  commercialRate: number = 5.8,
  annualRevenue?: number
): SimulationResult {
  const totalMonths = periodYears * 12;
  const graceMonths = Math.min(graceYears * 12, totalMonths - 1);
  const repayMonths = totalMonths - graceMonths;
  const monthlyRate = (annualRate / 100) / 12;
  const commercialMonthlyRate = (commercialRate / 100) / 12;

  let currentBalance = loanAmount;
  let totalInterest = 0;
  const schedule: ScheduleRow[] = [];

  // Precompute Equal Principal & Interest Monthly Payment during repayment phase
  let equalPmt = 0;
  if (repaymentType === 'EQUAL_PRINCIPAL_AND_INTEREST' && repayMonths > 0) {
    if (monthlyRate > 0) {
      equalPmt = (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, repayMonths)) / (Math.pow(1 + monthlyRate, repayMonths) - 1);
    } else {
      equalPmt = loanAmount / repayMonths;
    }
  }

  // Precompute Equal Principal Monthly Principal
  const equalPrincipalPmt = repayMonths > 0 ? loanAmount / repayMonths : 0;

  for (let m = 1; m <= totalMonths; m++) {
    const isGrace = m <= graceMonths;
    const interest = currentBalance * monthlyRate;
    let principal = 0;
    let totalPmt = 0;

    if (isGrace) {
      principal = 0;
      totalPmt = interest;
    } else {
      if (repaymentType === 'EQUAL_PRINCIPAL_AND_INTEREST') {
        if (m === totalMonths) {
          principal = currentBalance;
          totalPmt = principal + interest;
        } else {
          principal = equalPmt - interest;
          totalPmt = equalPmt;
        }
      } else if (repaymentType === 'EQUAL_PRINCIPAL') {
        principal = Math.min(equalPrincipalPmt, currentBalance);
        totalPmt = principal + interest;
      } else if (repaymentType === 'BULLET') {
        if (m === totalMonths) {
          principal = currentBalance;
          totalPmt = principal + interest;
        } else {
          principal = 0;
          totalPmt = interest;
        }
      }
    }

    currentBalance = Math.max(0, currentBalance - principal);
    totalInterest += interest;

    schedule.push({
      month: m,
      isGracePeriod: isGrace,
      principalPayment: Math.round(principal),
      interestPayment: Math.round(interest),
      totalMonthlyPayment: Math.round(totalPmt),
      remainingBalance: Math.round(currentBalance)
    });
  }

  // Calculate Commercial Bank total interest for comparison
  let commBalance = loanAmount;
  let commercialTotalInterest = 0;
  for (let m = 1; m <= totalMonths; m++) {
    const isGrace = m <= graceMonths;
    const cInterest = commBalance * commercialMonthlyRate;
    commercialTotalInterest += cInterest;
    if (!isGrace) {
      const cPrincipal = loanAmount / repayMonths;
      commBalance = Math.max(0, commBalance - cPrincipal);
    }
  }

  const firstMonthlyPayment = schedule.length > 0 ? schedule[0].totalMonthlyPayment : 0;
  const maxMonthlyPayment = schedule.length > 0 ? Math.max(...schedule.map((s) => s.totalMonthlyPayment)) : 0;
  const avgMonthlyPayment = schedule.length > 0 ? Math.round(schedule.reduce((a, b) => a + b.totalMonthlyPayment, 0) / schedule.length) : 0;
  const totalRepayment = loanAmount + totalInterest;
  const interestSaved = Math.max(0, commercialTotalInterest - totalInterest);

  let burdenRatio: number | undefined;
  let burdenStatus: SimulationResult['burdenStatus'];

  if (annualRevenue && annualRevenue > 0) {
    const monthlyRev = annualRevenue / 12;
    burdenRatio = Math.round((avgMonthlyPayment / monthlyRev) * 1000) / 10; // 1 decimal
    if (burdenRatio < 5) burdenStatus = 'VERY_SAFE';
    else if (burdenRatio <= 15) burdenStatus = 'SAFE';
    else if (burdenRatio <= 30) burdenStatus = 'CAUTION';
    else burdenStatus = 'HIGH';
  }

  return {
    loanAmount,
    annualRate,
    totalMonths,
    graceMonths,
    repaymentType,
    firstMonthlyPayment,
    avgMonthlyPayment,
    maxMonthlyPayment,
    totalInterest: Math.round(totalInterest),
    totalRepayment: Math.round(totalRepayment),
    commercialTotalInterest: Math.round(commercialTotalInterest),
    interestSaved: Math.round(interestSaved),
    commercialRate,
    schedule,
    burdenRatio,
    burdenStatus
  };
}

/**
 * Recharts Custom Tooltip for Monthly and Yearly Amortization Chart
 */
const CustomAmortizationTooltip: React.FC<any> = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-slate-900/95 text-white p-3.5 rounded-2xl shadow-xl border border-slate-700/80 text-xs backdrop-blur-md space-y-2 min-w-[210px] z-50 pointer-events-none animate-fade-in">
        <div className="flex items-center justify-between border-b border-slate-700/90 pb-1.5 gap-2">
          <span className="font-black text-xs sm:text-sm text-slate-100">{data.monthLabel || data.name}</span>
          {data.isGracePeriod !== undefined && (
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
              data.isGracePeriod 
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40' 
                : 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/40'
            }`}>
              {data.isGracePeriod ? '거치기간 (이자만)' : '원금상환기'}
            </span>
          )}
        </div>

        <div className="space-y-1.5 text-[11px]">
          <div className="flex items-center justify-between text-indigo-300 font-bold">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-500 inline-block shadow-xs" />
              상환 원금
            </span>
            <span className="font-mono">{formatKoreanWon(data.principalPayment)}</span>
          </div>

          <div className="flex items-center justify-between text-emerald-300 font-bold">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block shadow-xs" />
              납부 이자
            </span>
            <span className="font-mono">{formatKoreanWon(data.interestPayment)}</span>
          </div>

          <div className="flex items-center justify-between text-white font-black pt-1.5 border-t border-slate-700/80">
            <span>{data.year ? '월 납부 총액' : '연간 납부 총액'}</span>
            <span className="text-amber-300 font-mono text-xs">{formatKoreanWon(data.totalMonthlyPayment)}</span>
          </div>

          <div className="flex items-center justify-between text-slate-400 text-[10px] pt-0.5">
            <span>상환 후 대출 잔액</span>
            <span className="font-mono text-slate-300">{formatKoreanWon(data.remainingBalance)}</span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

/**
 * Recharts Stacked Bar Chart Component for Fund Loan Monthly & Yearly Amortization
 */
export const FundLoanAmortizationChart: React.FC<{
  schedule: ScheduleRow[];
  repaymentType: RepaymentType;
  graceMonths: number;
  totalMonths: number;
  height?: number;
}> = ({ schedule, repaymentType, graceMonths, totalMonths, height = 280 }) => {
  const [viewMode, setChartViewMode] = useState<'MONTHLY' | 'YEARLY'>('MONTHLY');
  const [rangeFilter, setRangeFilter] = useState<string>('ALL');

  // Prepare monthly chart data
  const monthlyData = useMemo(() => {
    return schedule.map((row) => ({
      month: row.month,
      name: `${row.month}회`,
      monthLabel: `${row.month}회차 (${Math.floor((row.month - 1) / 12) + 1}년차 ${(row.month - 1) % 12 + 1}월)`,
      year: Math.floor((row.month - 1) / 12) + 1,
      isGracePeriod: row.isGracePeriod,
      principalPayment: row.principalPayment,
      interestPayment: row.interestPayment,
      totalMonthlyPayment: row.totalMonthlyPayment,
      remainingBalance: row.remainingBalance,
      principalInManwon: Math.round((row.principalPayment / 10000) * 10) / 10,
      interestInManwon: Math.round((row.interestPayment / 10000) * 10) / 10,
      totalInManwon: Math.round((row.totalMonthlyPayment / 10000) * 10) / 10,
    }));
  }, [schedule]);

  // Prepare yearly aggregated chart data
  const yearlyData = useMemo(() => {
    const years: Record<number, { year: number; principal: number; interest: number; total: number; endBalance: number; hasGrace: boolean }> = {};
    schedule.forEach((row) => {
      const yr = Math.floor((row.month - 1) / 12) + 1;
      if (!years[yr]) {
        years[yr] = { year: yr, principal: 0, interest: 0, total: 0, endBalance: row.remainingBalance, hasGrace: false };
      }
      years[yr].principal += row.principalPayment;
      years[yr].interest += row.interestPayment;
      years[yr].total += row.totalMonthlyPayment;
      years[yr].endBalance = row.remainingBalance;
      if (row.isGracePeriod) years[yr].hasGrace = true;
    });

    return Object.values(years).map((y) => ({
      year: y.year,
      name: `${y.year}년차`,
      monthLabel: `${y.year}년차 누적 (${(y.year - 1) * 12 + 1}~${Math.min(y.year * 12, schedule.length)}회차)`,
      isGracePeriod: y.hasGrace,
      principalPayment: y.principal,
      interestPayment: y.interest,
      totalMonthlyPayment: y.total,
      remainingBalance: y.endBalance,
      principalInManwon: Math.round((y.principal / 10000) * 10) / 10,
      interestInManwon: Math.round((y.interest / 10000) * 10) / 10,
      totalInManwon: Math.round((y.total / 10000) * 10) / 10,
    }));
  }, [schedule]);

  // Filter monthly data by selected range
  const displayedData = useMemo(() => {
    if (viewMode === 'YEARLY') return yearlyData;
    if (rangeFilter === '1-24') return monthlyData.filter((d) => d.month <= 24);
    if (rangeFilter === '25-48') return monthlyData.filter((d) => d.month >= 25 && d.month <= 48);
    if (rangeFilter === '49-72') return monthlyData.filter((d) => d.month >= 49 && d.month <= 72);
    if (rangeFilter === '73+') return monthlyData.filter((d) => d.month >= 73);
    return monthlyData;
  }, [viewMode, rangeFilter, monthlyData, yearlyData]);

  const maxPayment = useMemo(() => {
    return Math.max(...displayedData.map((d) => d.totalMonthlyPayment), 1);
  }, [displayedData]);

  return (
    <div className="bg-slate-900 text-white p-4 sm:p-5 rounded-2xl border border-slate-800 shadow-inner space-y-4">
      {/* Chart Control Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center">
            <BarChart3 className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-sm text-slate-100">
                {viewMode === 'MONTHLY' ? '월별 원금·이자 납부액 변화 추이' : '연차별 상환 합계 추이'}
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                Recharts 시각화
              </span>
            </div>
            <p className="text-[11px] text-slate-400">
              {repaymentType === 'EQUAL_PRINCIPAL'
                ? '원금균등상환: 원금은 매월 동일하고 이자가 줄어들어 총 납부액이 점차 감소합니다.'
                : repaymentType === 'EQUAL_PRINCIPAL_AND_INTEREST'
                ? '원리금균등상환: 매월 총 납부액이 일정하며 회차가 지날수록 원금 비중이 늘어납니다.'
                : '만기일시상환: 매월 이자만 납부하다가 만기 최종회차에 원금을 일시 납부합니다.'}
            </p>
          </div>
        </div>

        {/* View Mode Toggle & Range Filter */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <div className="bg-slate-800 p-0.5 rounded-xl border border-slate-700 flex items-center">
            <button
              type="button"
              onClick={() => setChartViewMode('MONTHLY')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                viewMode === 'MONTHLY' ? 'bg-indigo-600 text-white shadow-2xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              월별 변화
            </button>
            <button
              type="button"
              onClick={() => setChartViewMode('YEARLY')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                viewMode === 'YEARLY' ? 'bg-indigo-600 text-white shadow-2xs' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              연차별 합계
            </button>
          </div>

          {viewMode === 'MONTHLY' && totalMonths > 24 && (
            <div className="bg-slate-800 p-0.5 rounded-xl border border-slate-700 flex items-center text-[10px]">
              <button
                type="button"
                onClick={() => setRangeFilter('ALL')}
                className={`px-2 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                  rangeFilter === 'ALL' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                전체
              </button>
              <button
                type="button"
                onClick={() => setRangeFilter('1-24')}
                className={`px-2 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                  rangeFilter === '1-24' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                1~2년
              </button>
              {totalMonths > 24 && (
                <button
                  type="button"
                  onClick={() => setRangeFilter('25-48')}
                  className={`px-2 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                    rangeFilter === '25-48' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  3~4년
                </button>
              )}
              {totalMonths > 48 && (
                <button
                  type="button"
                  onClick={() => setRangeFilter('49-72')}
                  className={`px-2 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                    rangeFilter === '49-72' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  5~6년
                </button>
              )}
              {totalMonths > 72 && (
                <button
                  type="button"
                  onClick={() => setRangeFilter('73+')}
                  className={`px-2 py-1 rounded-lg font-bold transition-all cursor-pointer ${
                    rangeFilter === '73+' ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  7년+
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Chart Legend and Badges */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 font-bold text-indigo-300">
            <span className="w-3 h-3 rounded-md bg-indigo-500 shadow-2xs" />
            상환 원금
          </span>
          <span className="flex items-center gap-1.5 font-bold text-emerald-300">
            <span className="w-3 h-3 rounded-md bg-emerald-400 shadow-2xs" />
            납부 이자
          </span>
        </div>

        <div className="flex items-center gap-2 text-[11px] text-slate-400">
          {graceMonths > 0 && (
            <span className="px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-300 border border-amber-500/30 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              1~{graceMonths}회차: 거치기간 (이자만 납부)
            </span>
          )}
          <span className="hidden sm:inline-block">※ 마우스 오버 시 상세 금액 확인 가능</span>
        </div>
      </div>

      {/* Recharts Stacked Bar Chart */}
      <div className="w-full" style={{ height }}>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={displayedData}
            margin={{ top: 12, right: 12, left: -10, bottom: 0 }}
            barCategoryGap={displayedData.length > 36 ? '15%' : '25%'}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} opacity={0.6} />
            <XAxis
              dataKey="name"
              stroke="#94a3b8"
              fontSize={10}
              tickLine={false}
              axisLine={{ stroke: '#475569' }}
              interval={displayedData.length > 40 ? Math.ceil(displayedData.length / 12) : 0}
            />
            <YAxis
              stroke="#94a3b8"
              fontSize={10}
              tickLine={false}
              axisLine={{ stroke: '#475569' }}
              tickFormatter={(value) => {
                if (value >= 100000000) return `${(value / 100000000).toFixed(1)}억`;
                if (value >= 10000) return `${Math.round(value / 10000)}만`;
                return `${value}`;
              }}
            />
            <RechartsTooltip content={<CustomAmortizationTooltip />} />
            {graceMonths > 0 && viewMode === 'MONTHLY' && (
              <ReferenceLine
                x={`${graceMonths}회`}
                stroke="#f59e0b"
                strokeDasharray="4 4"
                label={{
                  value: '거치종료',
                  fill: '#f59e0b',
                  fontSize: 10,
                  position: 'top',
                  fontWeight: 'bold'
                }}
              />
            )}
            <Bar
              dataKey="principalPayment"
              name="상환 원금"
              stackId="amortization"
              fill="#6366f1"
              radius={[0, 0, 0, 0]}
            />
            <Bar
              dataKey="interestPayment"
              name="납부 이자"
              stackId="amortization"
              fill="#10b981"
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

/**
 * Dedicated Full-Featured Loan Simulator Modal
 */
export const FundLoanSimulatorModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  fund: PolicyFund;
  profile?: UserProfile | null;
}> = ({ isOpen, onClose, fund, profile }) => {
  const defaultParsedRate = useMemo(() => parseFundInterestRate(fund.interestRate), [fund.interestRate]);
  const defaultParsedMaxAmount = useMemo(() => parseFundMaxAmount(fund.maxAmount), [fund.maxAmount]);
  
  const initialLoanAmount = useMemo(() => {
    if (profile?.fundingNeed && profile.fundingNeed > 0) {
      return Math.min(profile.fundingNeed, defaultParsedMaxAmount > 0 ? defaultParsedMaxAmount : profile.fundingNeed);
    }
    return defaultParsedMaxAmount > 0 ? Math.min(defaultParsedMaxAmount, 50000000) : 50000000;
  }, [profile?.fundingNeed, defaultParsedMaxAmount]);

  const [loanAmount, setLoanAmount] = useState<number>(initialLoanAmount);
  const [interestRate, setInterestRate] = useState<number>(defaultParsedRate);
  const [periodYears, setPeriodYears] = useState<number>(5);
  const [graceYears, setGraceYears] = useState<number>(2);
  const [repaymentType, setRepaymentType] = useState<RepaymentType>('EQUAL_PRINCIPAL');
  const [commercialRate, setCommercialRate] = useState<number>(5.8);
  const [showFullSchedule, setShowFullSchedule] = useState<boolean>(true);
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    if (isOpen) {
      setInterestRate(defaultParsedRate);
    }
  }, [isOpen, defaultParsedRate]);

  const result = useMemo(() => {
    return calculateLoanSimulation(
      loanAmount,
      interestRate,
      periodYears,
      graceYears,
      repaymentType,
      commercialRate,
      profile?.annualRevenue
    );
  }, [loanAmount, interestRate, periodYears, graceYears, repaymentType, commercialRate, profile?.annualRevenue]);

  const presetAmounts = [
    { label: '3,000만', value: 30000000 },
    { label: '5,000만', value: 50000000 },
    { label: '1억원', value: 100000000 },
    { label: '2억원', value: 200000000 },
    ...(defaultParsedMaxAmount > 0 && ![30000000, 50000000, 100000000, 200000000].includes(defaultParsedMaxAmount)
      ? [{ label: `최대(${formatKoreanWon(defaultParsedMaxAmount)})`, value: defaultParsedMaxAmount }]
      : [])
  ];

  const handleCopySummary = () => {
    let text = `[${fund.title} - 대출 상환 시뮬레이션 결과]\n`;
    text += `■ 대출 원금: ${formatKoreanWon(result.loanAmount)} (${result.loanAmount.toLocaleString('ko-KR')}원)\n`;
    text += `■ 적용 금리: 연 ${result.annualRate}% (시중은행 평균 ${commercialRate}% 대비)\n`;
    text += `■ 상환 기간: 총 ${periodYears}년 (${graceYears > 0 ? `${graceYears}년 거치 후 ` : ''}${periodYears - graceYears}년 분할상환)\n`;
    text += `■ 상환 방식: ${repaymentType === 'EQUAL_PRINCIPAL_AND_INTEREST' ? '원리금균등분할상환' : repaymentType === 'EQUAL_PRINCIPAL' ? '원금균등분할상환' : '만기일시상환'}\n`;
    text += `----------------------------------------\n`;
    text += `■ 거치 기간 월 이자: 약 ${formatKoreanWon(result.firstMonthlyPayment)}/월\n`;
    text += `■ 분할 상환기 평균 월 납부: 약 ${formatKoreanWon(result.avgMonthlyPayment)}/월\n`;
    text += `■ 총 부담 이자: ${formatKoreanWon(result.totalInterest)} (${result.totalInterest.toLocaleString('ko-KR')}원)\n`;
    text += `■ 총 상환 금액: ${formatKoreanWon(result.totalRepayment)} (${result.totalRepayment.toLocaleString('ko-KR')}원)\n`;
    text += `■ 시중은행 대비 이자 절감액: ★ 약 ${formatKoreanWon(result.interestSaved)} 절약! ★\n`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadCsv = () => {
    const headers = ['회차(월)', '구분', '납부원금(원)', '납부이자(원)', '월총납부액(원)', '대출잔액(원)'];
    const rows = result.schedule.map((r) => [
      `${r.month}회차`,
      r.isGracePeriod ? '거치기간(이자만)' : '상환기간',
      r.principalPayment,
      r.interestPayment,
      r.totalMonthlyPayment,
      r.remainingBalance
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${fund.title.replace(/[\/\s]/g, '_')}_상환스케줄.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="bg-white w-full max-w-5xl rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Modal Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-950 text-white flex items-center justify-between gap-4 border-b border-indigo-900 shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-11 h-11 rounded-2xl bg-indigo-500/20 border border-indigo-400/40 text-amber-300 flex items-center justify-center shadow-inner shrink-0">
              <Calculator className="w-6 h-6" />
            </div>
            <div className="truncate">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-base sm:text-lg font-black text-white truncate">
                  대출 상환 시뮬레이터 & 원리금 변화 분석
                </span>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-400/20 text-emerald-300 border border-emerald-400/30">
                  {fund.agency}
                </span>
              </div>
              <p className="text-xs text-blue-200/80 truncate mt-0.5">
                {fund.title} • 기준 금리 {fund.interestRate}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-all cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body Content (Scrollable) */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 flex-1 text-slate-800 text-xs">
          {/* Top Control Inputs Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 bg-slate-50 p-4 sm:p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
            {/* 1. Loan Amount Input */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="font-black text-slate-700 flex items-center gap-1">
                  <DollarSign className="w-3.5 h-3.5 text-indigo-600" />
                  <span>대출 희망 원금</span>
                </label>
                <span className="text-indigo-600 font-black text-[11px]">
                  {formatKoreanWon(loanAmount)}
                </span>
              </div>
              <div className="relative">
                <input
                  type="number"
                  step="1000000"
                  min="1000000"
                  max="10000000000"
                  value={loanAmount}
                  onChange={(e) => setLoanAmount(Math.max(1000000, Number(e.target.value) || 0))}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold text-slate-900 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all text-xs"
                />
                <span className="absolute right-3 top-2 text-slate-400 font-bold text-[11px]">원</span>
              </div>
              <div className="flex flex-wrap gap-1 pt-1">
                {presetAmounts.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setLoanAmount(p.value)}
                    className={`px-2 py-0.5 rounded-md text-[10px] font-bold transition-colors cursor-pointer ${
                      loanAmount === p.value
                        ? 'bg-indigo-600 text-white shadow-2xs'
                        : 'bg-white hover:bg-slate-200 text-slate-600 border border-slate-200'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            {/* 2. Interest Rate Input */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="font-black text-slate-700 flex items-center gap-1">
                  <Percent className="w-3.5 h-3.5 text-emerald-600" />
                  <span>정책자금 적용 금리</span>
                </label>
                <span className="text-emerald-700 font-black text-[11px]">
                  연 {interestRate}%
                </span>
              </div>
              <div className="relative">
                <input
                  type="number"
                  step="0.1"
                  min="0"
                  max="15"
                  value={interestRate}
                  onChange={(e) => setInterestRate(Math.max(0, Number(e.target.value) || 0))}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold text-slate-900 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all text-xs"
                />
                <span className="absolute right-3 top-2 text-slate-400 font-bold text-[11px]">% (연)</span>
              </div>
              <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                <span>공고 기준: {fund.interestRate}</span>
                <button
                  type="button"
                  onClick={() => setInterestRate(defaultParsedRate)}
                  className="text-indigo-600 font-bold hover:underline"
                >
                  기본값 복원
                </button>
              </div>
            </div>

            {/* 3. Loan Period & Grace Period */}
            <div className="space-y-1.5">
              <label className="font-black text-slate-700 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-blue-600" />
                <span>대출 기간 및 거치기간</span>
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                <div>
                  <select
                    value={periodYears}
                    onChange={(e) => {
                      const newP = Number(e.target.value);
                      setPeriodYears(newP);
                      if (graceYears >= newP) setGraceYears(Math.max(0, newP - 1));
                    }}
                    className="w-full px-2.5 py-2 bg-white border border-slate-300 rounded-xl font-bold text-slate-800 text-xs focus:border-blue-500"
                  >
                    <option value={1}>1년 (12개월)</option>
                    <option value={2}>2년 (24개월)</option>
                    <option value={3}>3년 (36개월)</option>
                    <option value={5}>5년 (60개월)</option>
                    <option value={7}>7년 (84개월)</option>
                    <option value={10}>10년 (120개월)</option>
                  </select>
                </div>
                <div>
                  <select
                    value={graceYears}
                    onChange={(e) => setGraceYears(Number(e.target.value))}
                    className="w-full px-2.5 py-2 bg-white border border-slate-300 rounded-xl font-bold text-slate-800 text-xs focus:border-blue-500"
                  >
                    <option value={0}>거치 없음</option>
                    {periodYears >= 2 && <option value={1}>1년 거치</option>}
                    {periodYears >= 3 && <option value={2}>2년 거치</option>}
                    {periodYears >= 4 && <option value={3}>3년 거치</option>}
                    {periodYears >= 6 && <option value={5}>5년 거치</option>}
                  </select>
                </div>
              </div>
              <p className="text-[10px] text-slate-500 pt-0.5">
                {graceYears > 0 ? `※ ${graceYears}년간 이자만 납부 후 ${periodYears - graceYears}년 원금 분할` : '※ 거치 없이 즉시 원금 분할 상환'}
              </p>
            </div>

            {/* 4. Repayment Method */}
            <div className="space-y-1.5">
              <label className="font-black text-slate-700 flex items-center gap-1">
                <Layers className="w-3.5 h-3.5 text-purple-600" />
                <span>상환 방식 선택</span>
              </label>
              <div className="space-y-1">
                {[
                  { id: 'EQUAL_PRINCIPAL', label: '원금균등 (추천·이자최소)' },
                  { id: 'EQUAL_PRINCIPAL_AND_INTEREST', label: '원리금균등 (매월 일정)' },
                  { id: 'BULLET', label: '만기일시 (만기원금납부)' }
                ].map((type) => (
                  <button
                    key={type.id}
                    type="button"
                    onClick={() => setRepaymentType(type.id as RepaymentType)}
                    className={`w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer flex items-center justify-between ${
                      repaymentType === type.id
                        ? 'bg-purple-100/90 text-purple-900 border border-purple-300 shadow-2xs'
                        : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200'
                    }`}
                  >
                    <span>{type.label}</span>
                    {repaymentType === type.id && <Check className="w-3 h-3 text-purple-700" />}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Results Summary 4 Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
            <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white p-4 rounded-2xl shadow-sm relative overflow-hidden">
              <span className="text-[10px] text-indigo-300 font-bold uppercase block mb-1">
                {graceYears > 0 ? '거치기 / 상환기 월 납부액' : '월 예상 상환액 (평균)'}
              </span>
              <div className="text-lg sm:text-xl font-black text-white">
                {graceYears > 0 ? (
                  <>
                    <span className="text-emerald-300">{formatKoreanWon(result.firstMonthlyPayment)}</span>
                    <span className="text-xs text-slate-400 font-normal"> (거치)</span>
                    <div className="text-sm font-bold text-slate-200 mt-0.5">
                      → 이후 월 {formatKoreanWon(result.avgMonthlyPayment)}
                    </div>
                  </>
                ) : (
                  <>약 {formatKoreanWon(result.avgMonthlyPayment)}</>
                )}
              </div>
              <p className="text-[10px] text-slate-300 mt-1.5">
                {repaymentType === 'EQUAL_PRINCIPAL'
                  ? `첫 달 ${formatKoreanWon(result.schedule[graceYears * 12]?.totalMonthlyPayment || result.firstMonthlyPayment)} → 점차 감소`
                  : repaymentType === 'EQUAL_PRINCIPAL_AND_INTEREST'
                  ? `매월 동일하게 ${formatKoreanWon(result.avgMonthlyPayment)} 납부`
                  : `매월 이자 ${formatKoreanWon(result.firstMonthlyPayment)} 납부`}
              </p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                총 부담 이자 (전체 기간)
              </span>
              <div className="text-lg sm:text-xl font-black text-emerald-600">
                {formatKoreanWon(result.totalInterest)}
              </div>
              <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2 pt-1 border-t border-slate-100">
                <span>원금 대비 총 이자율</span>
                <span className="font-bold text-slate-800">
                  {((result.totalInterest / result.loanAmount) * 100).toFixed(1)}%
                </span>
              </div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                총 상환 금액 (원금 + 이자)
              </span>
              <div className="text-lg sm:text-xl font-black text-slate-900">
                {formatKoreanWon(result.totalRepayment)}
              </div>
              <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2 pt-1 border-t border-slate-100">
                <span>원금 {formatKoreanWon(result.loanAmount)}</span>
                <span className="text-slate-400">+ 이자 {formatKoreanWon(result.totalInterest)}</span>
              </div>
            </div>

            <div className="bg-gradient-to-br from-emerald-50 to-teal-50/60 p-4 rounded-2xl border border-emerald-200 shadow-2xs">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] text-emerald-800 font-bold uppercase">
                  시중은행(연 {commercialRate}%) 대비
                </span>
                <span className="text-[9px] bg-emerald-200 text-emerald-950 px-1.5 py-0.2 rounded font-black">
                  이자 절약
                </span>
              </div>
              <div className="text-lg sm:text-xl font-black text-emerald-700 flex items-center gap-1">
                <TrendingDown className="w-5 h-5 text-emerald-600" />
                <span>{formatKoreanWon(result.interestSaved)} 절약</span>
              </div>
              <p className="text-[10px] text-emerald-800 mt-1 font-medium leading-tight">
                일반 대출 대비 약{' '}
                <strong className="font-black">
                  {Math.round((result.interestSaved / (result.commercialTotalInterest || 1)) * 100)}%
                </strong>{' '}
                이자 비용 절감
              </p>
            </div>
          </div>

          {/* Recharts Amortization Bar Chart */}
          <FundLoanAmortizationChart
            schedule={result.schedule}
            repaymentType={repaymentType}
            graceMonths={graceYears * 12}
            totalMonths={periodYears * 12}
            height={320}
          />

          {/* Action Bar (Download CSV, Copy Summary, Toggle Schedule Table) */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowFullSchedule(!showFullSchedule)}
                className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-black text-xs transition-all shadow-xs flex items-center gap-2 cursor-pointer"
              >
                <Calendar className="w-4 h-4 text-indigo-300" />
                <span>{showFullSchedule ? '월별 상환 스케줄 접기' : '월별 상세 상환 스케줄 보기'}</span>
                {showFullSchedule ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>

              <button
                type="button"
                onClick={handleDownloadCsv}
                className="px-4 py-2.5 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl font-bold text-xs transition-all shadow-2xs flex items-center gap-2 cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
                <span>엑셀(CSV) 다운로드</span>
              </button>
            </div>

            <button
              type="button"
              onClick={handleCopySummary}
              className="px-4 py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl font-bold text-xs transition-all flex items-center gap-2 cursor-pointer"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? '복사 완료!' : '결과 요약 복사'}</span>
            </button>
          </div>

          {/* Full Schedule Table */}
          {showFullSchedule && (
            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm animate-fade-in">
              <div className="p-3.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                <span className="font-black text-slate-900 text-xs flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-indigo-600" />
                  전체 {result.schedule.length}개월 상환 일정표 (원금 + 이자 상세)
                </span>
                <span className="text-[10px] text-slate-400">단위: 원</span>
              </div>

              <div className="max-h-72 overflow-y-auto scrollbar-thin">
                <table className="w-full text-left border-collapse text-[11px]">
                  <thead className="bg-slate-100/90 sticky top-0 z-10 text-slate-600 font-bold border-b border-slate-200">
                    <tr>
                      <th className="py-2.5 px-3.5">회차</th>
                      <th className="py-2.5 px-3.5">구분</th>
                      <th className="py-2.5 px-3.5 text-right">납부 원금</th>
                      <th className="py-2.5 px-3.5 text-right">납부 이자</th>
                      <th className="py-2.5 px-3.5 text-right">월 총 납부액</th>
                      <th className="py-2.5 px-3.5 text-right">대출 잔액</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {result.schedule.map((row) => (
                      <tr
                        key={row.month}
                        className={`hover:bg-indigo-50/40 transition-colors ${
                          row.isGracePeriod ? 'bg-amber-50/20' : row.month % 12 === 0 ? 'bg-slate-50/60 font-semibold' : ''
                        }`}
                      >
                        <td className="py-2 px-3.5 font-mono font-bold text-slate-900">
                          {row.month}회차
                        </td>
                        <td className="py-2 px-3.5">
                          {row.isGracePeriod ? (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-100 text-amber-800">
                              거치(이자만)
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-100 text-indigo-800">
                              원금상환
                            </span>
                          )}
                        </td>
                        <td className="py-2 px-3.5 text-right font-mono">
                          {row.principalPayment.toLocaleString('ko-KR')}원
                        </td>
                        <td className="py-2 px-3.5 text-right font-mono text-emerald-700 font-medium">
                          {row.interestPayment.toLocaleString('ko-KR')}원
                        </td>
                        <td className="py-2 px-3.5 text-right font-mono font-black text-slate-900">
                          {row.totalMonthlyPayment.toLocaleString('ko-KR')}원
                        </td>
                        <td className="py-2 px-3.5 text-right font-mono text-slate-500">
                          {row.remainingBalance.toLocaleString('ko-KR')}원
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="text-[11px] text-slate-500">
            ※ 정책자금 상환 조건 및 금리는 최종 보증 심사 및 집행 은행의 우대금리 적용에 따라 차이가 발생할 수 있습니다.
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-xs transition-all cursor-pointer"
          >
            닫기
          </button>
        </div>
      </div>
    </div>
  );
};

interface FundLoanSimulatorProps {
  fund: PolicyFund;
  profile?: UserProfile | null;
  className?: string;
  defaultExpanded?: boolean;
}

export const FundLoanSimulator: React.FC<FundLoanSimulatorProps> = ({
  fund,
  profile,
  className = '',
  defaultExpanded = false,
}) => {
  const defaultParsedRate = useMemo(() => parseFundInterestRate(fund.interestRate), [fund.interestRate]);
  const defaultParsedMaxAmount = useMemo(() => parseFundMaxAmount(fund.maxAmount), [fund.maxAmount]);
  
  // Calculate initial amount: prefer profile fundingNeed if available and sensible, else parsed fund max
  const initialLoanAmount = useMemo(() => {
    if (profile?.fundingNeed && profile.fundingNeed > 0) {
      return Math.min(profile.fundingNeed, defaultParsedMaxAmount > 0 ? defaultParsedMaxAmount : profile.fundingNeed);
    }
    return defaultParsedMaxAmount > 0 ? Math.min(defaultParsedMaxAmount, 50000000) : 50000000;
  }, [profile?.fundingNeed, defaultParsedMaxAmount]);

  const [isOpen, setIsOpen] = useState<boolean>(defaultExpanded);
  const [isModalOpen, setIsModalOpen] = useState<boolean>(false);
  const [loanAmount, setLoanAmount] = useState<number>(initialLoanAmount);
  const [interestRate, setInterestRate] = useState<number>(defaultParsedRate);
  const [periodYears, setPeriodYears] = useState<number>(5);
  const [graceYears, setGraceYears] = useState<number>(2);
  const [repaymentType, setRepaymentType] = useState<RepaymentType>('EQUAL_PRINCIPAL');
  const [commercialRate, setCommercialRate] = useState<number>(5.8);
  const [showFullSchedule, setShowFullSchedule] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  // Keep state synced if fund changes
  useEffect(() => {
    setInterestRate(defaultParsedRate);
  }, [defaultParsedRate]);

  // Run real-time simulation
  const result = useMemo(() => {
    return calculateLoanSimulation(
      loanAmount,
      interestRate,
      periodYears,
      graceYears,
      repaymentType,
      commercialRate,
      profile?.annualRevenue
    );
  }, [loanAmount, interestRate, periodYears, graceYears, repaymentType, commercialRate, profile?.annualRevenue]);

  // Preset loan amounts
  const presetAmounts = [
    { label: '3,000만', value: 30000000 },
    { label: '5,000만', value: 50000000 },
    { label: '1억원', value: 100000000 },
    { label: '2억원', value: 200000000 },
    ...(defaultParsedMaxAmount > 0 && ![30000000, 50000000, 100000000, 200000000].includes(defaultParsedMaxAmount)
      ? [{ label: `최대(${formatKoreanWon(defaultParsedMaxAmount)})`, value: defaultParsedMaxAmount }]
      : [])
  ];

  // Copy schedule summary to clipboard
  const handleCopySummary = () => {
    let text = `[${fund.title} - 대출 상환 시뮬레이션 결과]\n`;
    text += `■ 대출 원금: ${formatKoreanWon(result.loanAmount)} (${result.loanAmount.toLocaleString('ko-KR')}원)\n`;
    text += `■ 적용 금리: 연 ${result.annualRate}% (시중은행 평균 5.8% 대비)\n`;
    text += `■ 상환 기간: 총 ${periodYears}년 (${graceYears > 0 ? `${graceYears}년 거치 후 ` : ''}${periodYears - graceYears}년 분할상환)\n`;
    text += `■ 상환 방식: ${repaymentType === 'EQUAL_PRINCIPAL_AND_INTEREST' ? '원리금균등분할상환' : repaymentType === 'EQUAL_PRINCIPAL' ? '원금균등분할상환' : '만기일시상환'}\n`;
    text += `----------------------------------------\n`;
    text += `■ 거치 기간 월 이자: 약 ${formatKoreanWon(result.firstMonthlyPayment)}/월\n`;
    text += `■ 분할 상환기 평균 월 납부: 약 ${formatKoreanWon(result.avgMonthlyPayment)}/월\n`;
    text += `■ 총 부담 이자: ${formatKoreanWon(result.totalInterest)} (${result.totalInterest.toLocaleString('ko-KR')}원)\n`;
    text += `■ 총 상환 금액: ${formatKoreanWon(result.totalRepayment)} (${result.totalRepayment.toLocaleString('ko-KR')}원)\n`;
    text += `■ 시중은행 대비 이자 절감액: ★ 약 ${formatKoreanWon(result.interestSaved)} 절약! ★\n`;

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  // Download CSV of monthly schedule
  const handleDownloadCsv = () => {
    const headers = ['회차(월)', '구분', '납부원금(원)', '납부이자(원)', '월총납부액(원)', '대출잔액(원)'];
    const rows = result.schedule.map((r) => [
      `${r.month}회차`,
      r.isGracePeriod ? '거치기간(이자만)' : '상환기간',
      r.principalPayment,
      r.interestPayment,
      r.totalMonthlyPayment,
      r.remainingBalance
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${fund.title.replace(/[\/\s]/g, '_')}_상환스케줄.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <>
      <div className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
        isOpen 
          ? 'bg-gradient-to-b from-indigo-50/40 via-white to-slate-50 border-indigo-200/90 shadow-md' 
          : 'bg-slate-50/70 border-slate-200/70 hover:border-indigo-200 hover:bg-indigo-50/20'
      } ${className}`}>
        {/* Simulator Toggle Header */}
        <div className="w-full p-3.5 sm:p-4 flex items-center justify-between gap-3 text-left transition-colors">
          <button
            type="button"
            onClick={() => setIsOpen(!isOpen)}
            className="flex items-center gap-2.5 min-w-0 flex-1 text-left cursor-pointer"
          >
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 transition-transform ${
              isOpen ? 'bg-indigo-600 text-white shadow-xs scale-105' : 'bg-indigo-100 text-indigo-700'
            }`}>
              <Calculator className="w-4 h-4" />
            </div>
            <div className="truncate">
              <div className="flex items-center gap-2">
                <span className="text-xs sm:text-sm font-black text-slate-900 truncate">
                  상세 대출 시뮬레이터 & 원리금 변화 차트
                </span>
                <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-200">
                  Recharts 연동
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium truncate mt-0.5">
                원금·금리·거치기간별 월 납부액과 <strong className="text-indigo-600 font-black">매월 원금/이자 변화 막대 차트</strong>를 확인하세요
              </p>
            </div>
          </button>

          <div className="flex items-center gap-2 flex-shrink-0">
            <button
              type="button"
              onClick={() => setIsModalOpen(true)}
              className="px-2.5 py-1 bg-white hover:bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-lg text-xs font-black transition-all shadow-2xs flex items-center gap-1 cursor-pointer"
              title="시뮬레이터 모달을 크게 열어 전체화면으로 확인"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">모달로 크게 보기</span>
            </button>

            <button
              type="button"
              onClick={() => setIsOpen(!isOpen)}
              className="w-6 h-6 rounded-full bg-white border border-slate-200 flex items-center justify-center text-slate-500 cursor-pointer"
            >
              {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Expanded Interactive Calculator Panel */}
        {isOpen && (
          <div className="p-4 sm:p-6 pt-1 border-t border-indigo-100/70 space-y-5 animate-fade-in text-slate-800 text-xs">
            {/* Top Control Inputs Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5 bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
              {/* 1. Loan Amount Input */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="font-black text-slate-700 flex items-center gap-1">
                    <DollarSign className="w-3.5 h-3.5 text-indigo-600" />
                    <span>대출 신청 희망액</span>
                  </label>
                  <span className="text-indigo-600 font-black text-[11px]">
                    {formatKoreanWon(loanAmount)}
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="number"
                    step="1000000"
                    min="1000000"
                    max="10000000000"
                    value={loanAmount}
                    onChange={(e) => setLoanAmount(Math.max(1000000, Number(e.target.value) || 0))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:bg-white focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all text-xs"
                  />
                  <span className="absolute right-3 top-2 text-slate-400 font-bold text-[11px]">원</span>
                </div>
                {/* Preset quick buttons */}
                <div className="flex flex-wrap gap-1 pt-1">
                  {presetAmounts.map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setLoanAmount(p.value)}
                      className={`px-2 py-0.5 rounded-md text-[10px] font-bold transition-colors cursor-pointer ${
                        loanAmount === p.value
                          ? 'bg-indigo-600 text-white shadow-2xs'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                      }`}
                    >
                      {p.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* 2. Interest Rate Input */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="font-black text-slate-700 flex items-center gap-1">
                    <Percent className="w-3.5 h-3.5 text-emerald-600" />
                    <span>정책자금 적용 금리</span>
                  </label>
                  <span className="text-emerald-700 font-black text-[11px]">
                    연 {interestRate}%
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    max="15"
                    value={interestRate}
                    onChange={(e) => setInterestRate(Math.max(0, Number(e.target.value) || 0))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-900 focus:bg-white focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all text-xs"
                  />
                  <span className="absolute right-3 top-2 text-slate-400 font-bold text-[11px]">% (연)</span>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1">
                  <span>공고 기준: {fund.interestRate}</span>
                  <button
                    type="button"
                    onClick={() => setInterestRate(defaultParsedRate)}
                    className="text-indigo-600 font-bold hover:underline"
                  >
                    기본값 복원
                  </button>
                </div>
              </div>

              {/* 3. Loan Period & Grace Period */}
              <div className="space-y-1.5">
                <label className="font-black text-slate-700 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-blue-600" />
                  <span>대출 기간 및 거치기간</span>
                </label>
                <div className="grid grid-cols-2 gap-1.5">
                  <div>
                    <select
                      value={periodYears}
                      onChange={(e) => {
                        const newP = Number(e.target.value);
                        setPeriodYears(newP);
                        if (graceYears >= newP) setGraceYears(Math.max(0, newP - 1));
                      }}
                      className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 text-xs focus:bg-white focus:border-blue-500"
                    >
                      <option value={1}>1년 (12개월)</option>
                      <option value={2}>2년 (24개월)</option>
                      <option value={3}>3년 (36개월)</option>
                      <option value={5}>5년 (60개월)</option>
                      <option value={7}>7년 (84개월)</option>
                      <option value={10}>10년 (120개월)</option>
                    </select>
                  </div>
                  <div>
                    <select
                      value={graceYears}
                      onChange={(e) => setGraceYears(Number(e.target.value))}
                      className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl font-bold text-slate-800 text-xs focus:bg-white focus:border-blue-500"
                    >
                      <option value={0}>거치 없음</option>
                      {periodYears >= 2 && <option value={1}>1년 거치</option>}
                      {periodYears >= 3 && <option value={2}>2년 거치</option>}
                      {periodYears >= 4 && <option value={3}>3년 거치</option>}
                      {periodYears >= 6 && <option value={5}>5년 거치</option>}
                    </select>
                  </div>
                </div>
                <p className="text-[10px] text-slate-400 pt-0.5">
                  {graceYears > 0 ? `※ ${graceYears}년간 이자만 납부 후 ${periodYears - graceYears}년 원금 분할` : '※ 거치 없이 즉시 원금 분할 상환'}
                </p>
              </div>

              {/* 4. Repayment Method */}
              <div className="space-y-1.5">
                <label className="font-black text-slate-700 flex items-center gap-1">
                  <Layers className="w-3.5 h-3.5 text-purple-600" />
                  <span>상환 방식 선택</span>
                </label>
                <div className="space-y-1">
                  {[
                    { id: 'EQUAL_PRINCIPAL', label: '원금균등 (추천·이자최소)' },
                    { id: 'EQUAL_PRINCIPAL_AND_INTEREST', label: '원리금균등 (매월 일정)' },
                    { id: 'BULLET', label: '만기일시 (만기원금납부)' }
                  ].map((type) => (
                    <button
                      key={type.id}
                      type="button"
                      onClick={() => setRepaymentType(type.id as RepaymentType)}
                      className={`w-full text-left px-2.5 py-1.5 rounded-lg text-[11px] font-bold transition-all cursor-pointer flex items-center justify-between ${
                        repaymentType === type.id
                          ? 'bg-purple-100/90 text-purple-900 border border-purple-300 shadow-2xs'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border border-transparent'
                      }`}
                    >
                      <span>{type.label}</span>
                      {repaymentType === type.id && <Check className="w-3 h-3 text-purple-700" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Results Summary Dashboard */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {/* Metric 1: Monthly Payment */}
              <div className="bg-gradient-to-br from-indigo-900 to-slate-900 text-white p-4 rounded-2xl shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 p-3 text-white/10">
                  <Calculator className="w-12 h-12" />
                </div>
                <span className="text-[10px] text-indigo-300 font-bold uppercase block mb-1">
                  {graceYears > 0 ? `거치기 / 상환기 월 납부액` : '월 예상 상환액 (평균)'}
                </span>
                <div className="text-lg sm:text-xl font-black text-white">
                  {graceYears > 0 ? (
                    <>
                      <span className="text-emerald-300">{formatKoreanWon(result.firstMonthlyPayment)}</span>
                      <span className="text-xs text-slate-400 font-normal"> (거치)</span>
                      <div className="text-sm font-bold text-slate-200 mt-0.5">
                        → 이후 월 {formatKoreanWon(result.avgMonthlyPayment)}
                      </div>
                    </>
                  ) : (
                    <>약 {formatKoreanWon(result.avgMonthlyPayment)}</>
                  )}
                </div>
                <p className="text-[10px] text-slate-300 mt-1.5">
                  {repaymentType === 'EQUAL_PRINCIPAL'
                    ? `첫 달 ${formatKoreanWon(result.schedule[graceYears * 12]?.totalMonthlyPayment || result.firstMonthlyPayment)} → 점차 감소`
                    : repaymentType === 'EQUAL_PRINCIPAL_AND_INTEREST'
                    ? `매월 동일하게 ${formatKoreanWon(result.avgMonthlyPayment)} 납부`
                    : `매월 이자 ${formatKoreanWon(result.firstMonthlyPayment)} 납부`}
                </p>
              </div>

              {/* Metric 2: Total Interest */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
                <span className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                  총 부담 이자 (전체 기간)
                </span>
                <div className="text-lg sm:text-xl font-black text-emerald-600">
                  {formatKoreanWon(result.totalInterest)}
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2 pt-1 border-t border-slate-100">
                  <span>원금 대비 이자율</span>
                  <span className="font-bold text-slate-800">
                    {((result.totalInterest / result.loanAmount) * 100).toFixed(1)}%
                  </span>
                </div>
              </div>

              {/* Metric 3: Total Repayment */}
              <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs">
                <span className="text-[10px] text-slate-400 font-bold uppercase block mb-1">
                  총 상환 금액 (원금 + 이자)
                </span>
                <div className="text-lg sm:text-xl font-black text-slate-900">
                  {formatKoreanWon(result.totalRepayment)}
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 mt-2 pt-1 border-t border-slate-100">
                  <span>원금: {formatKoreanWon(result.loanAmount)}</span>
                  <span className="text-slate-400">+ 이자 {formatKoreanWon(result.totalInterest)}</span>
                </div>
              </div>

              {/* Metric 4: Comparison with Commercial Bank */}
              <div className="bg-gradient-to-br from-emerald-50 to-teal-50/60 p-4 rounded-2xl border border-emerald-200/80 shadow-2xs">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] text-emerald-800 font-bold uppercase">
                    시중은행(연 {commercialRate}%) 대비
                  </span>
                  <span className="text-[9px] bg-emerald-200 text-emerald-950 px-1.5 py-0.2 rounded font-black">
                    이자 절약
                  </span>
                </div>
                <div className="text-lg sm:text-xl font-black text-emerald-700 flex items-center gap-1">
                  <TrendingDown className="w-5 h-5 text-emerald-600" />
                  <span>{formatKoreanWon(result.interestSaved)} 절약</span>
                </div>
                <p className="text-[10px] text-emerald-800 mt-1 font-medium leading-tight">
                  일반 대출 이자 {formatKoreanWon(result.commercialTotalInterest)} 중 약{' '}
                  <strong className="font-black">
                    {Math.round((result.interestSaved / (result.commercialTotalInterest || 1)) * 100)}%
                  </strong>{' '}
                  이자 비용 절감
                </p>
              </div>
            </div>

            {/* Recharts Monthly & Yearly Amortization Bar Chart */}
            <FundLoanAmortizationChart
              schedule={result.schedule}
              repaymentType={repaymentType}
              graceMonths={graceYears * 12}
              totalMonths={periodYears * 12}
              height={260}
            />

            {/* Visual Ratio Bar & Business Health Check */}
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 space-y-3 shadow-2xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-indigo-600" />
                  <span className="font-black text-slate-900">상환 원금 vs 이자 구성비</span>
                </div>
                <div className="flex items-center gap-4 text-[11px] font-bold">
                  <span className="flex items-center gap-1.5 text-indigo-700">
                    <span className="w-2.5 h-2.5 rounded-full bg-indigo-600" />
                    원금 {formatKoreanWon(result.loanAmount)} ({((result.loanAmount / result.totalRepayment) * 100).toFixed(0)}%)
                  </span>
                  <span className="flex items-center gap-1.5 text-emerald-700">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                    이자 {formatKoreanWon(result.totalInterest)} ({((result.totalInterest / result.totalRepayment) * 100).toFixed(0)}%)
                  </span>
                </div>
              </div>

              {/* Segmented Bar */}
              <div className="h-3.5 w-full bg-slate-100 rounded-full overflow-hidden flex shadow-inner">
                <div
                  className="bg-indigo-600 h-full transition-all duration-500"
                  style={{ width: `${(result.loanAmount / result.totalRepayment) * 100}%` }}
                  title={`원금: ${formatKoreanWon(result.loanAmount)}`}
                />
                <div
                  className="bg-emerald-500 h-full transition-all duration-500"
                  style={{ width: `${(result.totalInterest / result.totalRepayment) * 100}%` }}
                  title={`총 이자: ${formatKoreanWon(result.totalInterest)}`}
                />
              </div>

              {/* Representative Monthly Burden Evaluation */}
              {result.burdenRatio !== undefined && (
                <div className={`p-3 rounded-xl flex items-start gap-2.5 border ${
                  result.burdenStatus === 'VERY_SAFE'
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-950'
                    : result.burdenStatus === 'SAFE'
                    ? 'bg-blue-50 border-blue-200 text-blue-950'
                    : result.burdenStatus === 'CAUTION'
                    ? 'bg-amber-50 border-amber-200 text-amber-950'
                    : 'bg-rose-50 border-rose-200 text-rose-950'
                }`}>
                  <CheckCircle2 className={`w-4 h-4 mt-0.5 flex-shrink-0 ${
                    result.burdenStatus === 'VERY_SAFE' || result.burdenStatus === 'SAFE' ? 'text-emerald-600' : 'text-amber-600'
                  }`} />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-0.5">
                      <span className="font-black text-xs">
                        대표님 월 매출 대비 상환 부담률: {result.burdenRatio}%
                      </span>
                      <span className="text-[10px] font-bold px-2 py-0.2 rounded-md bg-white/80 border">
                        {result.burdenStatus === 'VERY_SAFE' ? '매우 안정' : result.burdenStatus === 'SAFE' ? '적정' : result.burdenStatus === 'CAUTION' ? '상환 관리 요망' : '부담 주의'}
                      </span>
                    </div>
                    <p className="text-[11px] leading-relaxed opacity-90">
                      {result.burdenStatus === 'VERY_SAFE'
                        ? `입력하신 연매출(${formatKoreanWon(profile?.annualRevenue || 0)}) 기준, 월 평균 상환액이 매출의 ${result.burdenRatio}%에 불과하여 재무적 위험 없이 매우 여유롭게 상환 가능합니다.`
                        : result.burdenStatus === 'SAFE'
                        ? `월 매출 대비 약 ${result.burdenRatio}% 수준으로 영업이익 범위 내에서 안정적인 자금 회전이 가능합니다.`
                        : `월 매출 대비 ${result.burdenRatio}%로 다소 비중이 있습니다. 2~3년 거치기간을 활용하여 초기 현금흐름 부담을 줄이는 것을 추천합니다.`}
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Action Bar (Copy summary, Download CSV, Open Full Modal, Toggle schedule table) */}
            <div className="flex flex-wrap items-center justify-between gap-2.5 pt-1">
              <div className="flex items-center gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={() => setShowFullSchedule(!showFullSchedule)}
                  className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-black text-xs transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <Calendar className="w-3.5 h-3.5 text-indigo-300" />
                  <span>{showFullSchedule ? '월별 상환 스케줄 접기' : '월별 상세 상환 스케줄 보기'}</span>
                  {showFullSchedule ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>

                <button
                  type="button"
                  onClick={handleDownloadCsv}
                  className="px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 rounded-xl font-bold text-xs transition-all shadow-2xs flex items-center gap-1.5 cursor-pointer"
                  title="엑셀(CSV) 파일로 전체 상환 스케줄 다운로드"
                >
                  <Download className="w-3.5 h-3.5 text-slate-500" />
                  <span>스케줄 엑셀 다운로드</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsModalOpen(true)}
                  className="px-3 py-2 bg-gradient-to-r from-indigo-50 to-blue-50 hover:from-indigo-100 hover:to-blue-100 text-indigo-700 border border-indigo-200/80 rounded-xl font-black text-xs transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Maximize2 className="w-3.5 h-3.5 text-indigo-600" />
                  <span>모달로 크게 보기</span>
                </button>
              </div>

              <button
                type="button"
                onClick={handleCopySummary}
                className="px-3 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-xl font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer"
                title="계산 결과 요약 텍스트 복사"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? '복사 완료!' : '결과 요약 복사'}</span>
              </button>
            </div>

            {/* Detailed Monthly Amortization Table */}
            {showFullSchedule && (
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm animate-fade-in">
                <div className="p-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                  <span className="font-black text-slate-900 text-xs flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-indigo-600" />
                    전체 {result.schedule.length}개월 상환 일정표 (원금 + 이자)
                  </span>
                  <span className="text-[10px] text-slate-400">
                    단위: 원 (절사 기준)
                  </span>
                </div>

                <div className="max-h-72 overflow-y-auto scrollbar-thin">
                  <table className="w-full text-left border-collapse text-[11px]">
                    <thead className="bg-slate-100/80 sticky top-0 z-10 text-slate-600 font-bold border-b border-slate-200">
                      <tr>
                        <th className="py-2 px-3">회차</th>
                        <th className="py-2 px-3">구분</th>
                        <th className="py-2 px-3 text-right">납부 원금</th>
                        <th className="py-2 px-3 text-right">납부 이자</th>
                        <th className="py-2 px-3 text-right">월 총 납부액</th>
                        <th className="py-2 px-3 text-right">대출 잔액</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-slate-700">
                      {result.schedule.map((row) => (
                        <tr
                          key={row.month}
                          className={`hover:bg-indigo-50/40 transition-colors ${
                            row.isGracePeriod ? 'bg-amber-50/20' : row.month % 12 === 0 ? 'bg-slate-50/60 font-semibold' : ''
                          }`}
                        >
                          <td className="py-2 px-3 font-mono font-bold text-slate-900">
                            {row.month}회차
                          </td>
                          <td className="py-2 px-3">
                            {row.isGracePeriod ? (
                              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-amber-100 text-amber-800">
                                거치(이자만)
                              </span>
                            ) : (
                              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-indigo-100 text-indigo-800">
                                원금상환
                              </span>
                            )}
                          </td>
                          <td className="py-2 px-3 text-right font-mono">
                            {row.principalPayment.toLocaleString('ko-KR')}원
                          </td>
                          <td className="py-2 px-3 text-right font-mono text-emerald-700 font-medium">
                            {row.interestPayment.toLocaleString('ko-KR')}원
                          </td>
                          <td className="py-2 px-3 text-right font-mono font-black text-slate-900">
                            {row.totalMonthlyPayment.toLocaleString('ko-KR')}원
                          </td>
                          <td className="py-2 px-3 text-right font-mono text-slate-500">
                            {row.remainingBalance.toLocaleString('ko-KR')}원
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Simulator Modal */}
      <FundLoanSimulatorModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        fund={fund}
        profile={profile}
      />
    </>
  );
};
