import React, { useState, useMemo, useEffect } from 'react';
import { 
  BrainCircuit, 
  Zap, 
  TrendingUp, 
  CheckCircle2, 
  AlertTriangle, 
  ArrowRight, 
  Headphones, 
  Layers, 
  Sparkles, 
  FileText, 
  Award,
  ChevronRight,
  ShieldCheck,
  Building2,
  Scale,
  Factory,
  Leaf,
  Users,
  Cpu
} from 'lucide-react';
import { PolicyFund, UserProfile, PolicyBonusFactors } from '../types';
import { 
  generateDeepLearningApprovalReport, 
  getApprovalLikelihoodTier,
  APPROVAL_TIERS,
  ApprovalTierDetails
} from '../services/deepLearningApprovalEngine';

interface DeepLearningApprovalHubProps {
  profile: UserProfile | null;
  funds: PolicyFund[];
  onOpenReport: (fund: PolicyFund) => void;
  onOpenConsultation?: (fund: PolicyFund) => void;
  onUpdateBonusFactors?: (factors: PolicyBonusFactors) => void;
}

export const DeepLearningApprovalHub: React.FC<DeepLearningApprovalHubProps> = ({
  profile,
  funds,
  onOpenReport,
  onOpenConsultation,
  onUpdateBonusFactors
}) => {
  const [selectedFundIndex, setSelectedFundIndex] = useState<number>(0);
  const [simulatedActionIds, setSimulatedActionIds] = useState<string[]>([]);
  
  // Real-time Policy Bonus Factors state (synced with profile, interactive on the fly)
  const [bonusFactors, setBonusFactors] = useState<PolicyBonusFactors>(() => profile?.policyBonusFactors || {});

  useEffect(() => {
    if (profile?.policyBonusFactors) {
      setBonusFactors(profile.policyBonusFactors);
    }
  }, [profile?.policyBonusFactors]);

  const activeFund = funds[selectedFundIndex] || funds[0];

  // Effective profile with real-time policy bonus factors
  const effectiveProfile = useMemo(() => {
    if (!profile) return null;
    return {
      ...profile,
      policyBonusFactors: bonusFactors
    };
  }, [profile, bonusFactors]);

  // Generate deep learning approval report for active fund using effective profile
  const report = useMemo(() => {
    if (!activeFund) return null;
    return generateDeepLearningApprovalReport(effectiveProfile, activeFund);
  }, [effectiveProfile, activeFund]);

  const handleToggleBonus = (key: keyof PolicyBonusFactors) => {
    setBonusFactors(prev => {
      const next = {
        ...prev,
        [key]: !prev[key]
      };
      if (onUpdateBonusFactors) {
        onUpdateBonusFactors(next);
      }
      return next;
    });
  };

  // Compute simulated score based on toggled action items
  const simulatedScoreBonus = useMemo(() => {
    if (!report) return 0;
    return report.improvementItems
      .filter(action => simulatedActionIds.includes(action.id))
      .reduce((acc, curr) => acc + curr.potentialUpliftPercent, 0);
  }, [report, simulatedActionIds]);

  const baseScore = report?.overallProbability || 75;
  const simulatedScore = Math.min(99, baseScore + simulatedScoreBonus);
  const baseTierInfo = getApprovalLikelihoodTier(baseScore);
  const simulatedTierInfo = getApprovalLikelihoodTier(simulatedScore);

  const activeTierInfo: ApprovalTierDetails = simulatedScoreBonus > 0 ? simulatedTierInfo : baseTierInfo;

  const toggleAction = (id: string) => {
    setSimulatedActionIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  if (!activeFund || !report) return null;

  return (
    <div id="deep-learning-approval-hub" className="bg-gradient-to-br from-slate-900 via-slate-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-indigo-500/20 relative overflow-hidden mb-8 no-print animate-fade-in">
      {/* Background Decorative Glow */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none -mr-20 -mt-20"></div>
      <div className="absolute bottom-0 left-1/3 w-80 h-80 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none"></div>

      {/* Header section */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-800 relative z-10">
        <div>
          <div className="flex items-center gap-2 mb-2 flex-wrap">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-gradient-to-r from-indigo-500/20 to-blue-500/20 border border-indigo-400/30 rounded-full text-[11px] font-black text-indigo-300">
              <BrainCircuit className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
              AI 딥러닝 패턴 매칭 v2.5
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-emerald-500/20 border border-emerald-400/30 rounded-full text-[10px] font-bold text-emerald-300">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              10,000+ 과거 승인 빅데이터 대조
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-amber-500/20 border border-amber-400/30 rounded-full text-[10px] font-bold text-amber-300">
              <Zap className="w-3 h-3 text-amber-400" />
              5단계 승인 척도 진단
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
            정책자금별 승인 가능성 5단계 정밀 진단 & 시뮬레이터
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-3xl leading-relaxed">
            대표님의 기업 프로필(신용·재무·매출·업력)을 과거 정책자금 실제 승인 빅데이터와 다차원 벡터 매칭하여 5단계 승인 확률과 구체적인 보완 액션을 제시합니다.
          </p>
        </div>

        {/* Global CTA button */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => onOpenReport(activeFund)}
            className="w-full sm:w-auto px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 rounded-xl text-xs font-black flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all cursor-pointer hover:scale-105 active:scale-95"
          >
            <Zap className="w-4 h-4 fill-slate-950 text-slate-950" />
            <span>AI 수석 심사역 전체 진단서 열기</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Fund Selector Tabs */}
      <div className="pt-6 relative z-10">
        <div className="text-xs font-bold text-slate-400 mb-2.5 flex items-center justify-between">
          <span className="flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
            진단 대상 정책자금 선택 ({funds.length}개 자금 중 상위 매칭)
          </span>
          <span className="text-[11px] text-slate-400">자금을 클릭하면 실시간으로 5단계 진단 결과가 변경됩니다</span>
        </div>

        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-slate-700">
          {funds.slice(0, 5).map((fund, idx) => {
            const isSelected = selectedFundIndex === idx;
            const fundReport = generateDeepLearningApprovalReport(effectiveProfile, fund);
            const tierInfo = getApprovalLikelihoodTier(fundReport.overallProbability);
            return (
              <button
                key={fund.id || idx}
                type="button"
                onClick={() => {
                  setSelectedFundIndex(idx);
                  setSimulatedActionIds([]);
                }}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shrink-0 border cursor-pointer ${
                  isSelected
                    ? 'bg-indigo-600/90 border-indigo-400 text-white shadow-lg shadow-indigo-600/30 ring-2 ring-indigo-400/40'
                    : 'bg-slate-800/80 hover:bg-slate-700/80 border-slate-700 text-slate-300'
                }`}
              >
                <span className="truncate max-w-[160px] text-left">{fund.title}</span>
                <span 
                  className="px-2 py-0.5 rounded-full text-[10px] font-black shrink-0 border"
                  style={{
                    backgroundColor: tierInfo.bgColor,
                    color: tierInfo.color,
                    borderColor: tierInfo.badgeColor
                  }}
                >
                  {tierInfo.tierKorean} ({fundReport.overallProbability}%)
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Policy Bonus Factor Real-time Calibration Bar */}
      <div className="mt-4 pt-3.5 border-t border-slate-800 relative z-10">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2.5 mb-2.5">
          <div className="flex items-center gap-2">
            <span className="p-1 bg-amber-500/20 text-amber-300 rounded-md">
              <Sparkles className="w-3.5 h-3.5" />
            </span>
            <span className="text-xs font-black text-slate-200">
              정부 정책적 가점 실시간 보정 컨트롤러
            </span>
            <span className="text-[11px] text-slate-400 hidden sm:inline">
              (항목을 클릭하면 즉시 승인 예측 확률이 재산정됩니다)
            </span>
          </div>
          {report.policyBonusAdjustment && report.policyBonusAdjustment.totalBonusUplift > 0 ? (
            <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-500/20 border border-emerald-400/40 rounded-lg text-xs font-bold text-emerald-300 self-start md:self-auto">
              <TrendingUp className="w-3 h-3 text-emerald-400" />
              <span>가점 보정: +{report.policyBonusAdjustment.totalBonusUplift}%p 적용 중</span>
              <span className="text-[10px] text-emerald-400/80">({report.policyBonusAdjustment.baseProbability}% ➔ {report.policyBonusAdjustment.calibratedProbability}%)</span>
            </div>
          ) : (
            <span className="text-[11px] text-slate-400 self-start md:self-auto">
              가점 항목을 선택하여 승인율을 상향해보세요
            </span>
          )}
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {/* Smart Factory Toggle */}
          <button
            type="button"
            onClick={() => handleToggleBonus('hasSmartFactory')}
            className={`p-2.5 rounded-xl border text-left transition-all flex items-center justify-between cursor-pointer ${
              bonusFactors.hasSmartFactory
                ? 'bg-blue-600/30 border-blue-400 text-white ring-1 ring-blue-400/50 shadow-xs'
                : 'bg-slate-800/60 hover:bg-slate-800 border-slate-700/80 text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="flex items-center gap-2 min-w-0">
              <Factory className={`w-4 h-4 shrink-0 ${bonusFactors.hasSmartFactory ? 'text-blue-400' : 'text-slate-500'}`} />
              <div className="truncate">
                <span className="text-xs font-black block truncate">스마트공장·공방</span>
                <span className="text-[10px] text-slate-400 block">+10~14%p 가점</span>
              </div>
            </div>
            <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-md shrink-0 ml-1 ${
              bonusFactors.hasSmartFactory ? 'bg-blue-500 text-white' : 'bg-slate-700 text-slate-400'
            }`}>
              {bonusFactors.hasSmartFactory ? '적용중' : '미적용'}
            </span>
          </button>

          {/* Carbon Neutrality Toggle */}
          <button
            type="button"
            onClick={() => handleToggleBonus('hasCarbonNeutrality')}
            className={`p-2.5 rounded-xl border text-left transition-all flex items-center justify-between cursor-pointer ${
              bonusFactors.hasCarbonNeutrality
                ? 'bg-emerald-600/30 border-emerald-400 text-white ring-1 ring-emerald-400/50 shadow-xs'
                : 'bg-slate-800/60 hover:bg-slate-800 border-slate-700/80 text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="flex items-center gap-2 min-w-0">
              <Leaf className={`w-4 h-4 shrink-0 ${bonusFactors.hasCarbonNeutrality ? 'text-emerald-400' : 'text-slate-500'}`} />
              <div className="truncate">
                <span className="text-xs font-black block truncate">탄소중립 ESG 실천</span>
                <span className="text-[10px] text-slate-400 block">+8%p · 금리감면</span>
              </div>
            </div>
            <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-md shrink-0 ml-1 ${
              bonusFactors.hasCarbonNeutrality ? 'bg-emerald-500 text-white' : 'bg-slate-700 text-slate-400'
            }`}>
              {bonusFactors.hasCarbonNeutrality ? '적용중' : '미적용'}
            </span>
          </button>

          {/* Job Creation Toggle */}
          <button
            type="button"
            onClick={() => handleToggleBonus('hasJobCreation')}
            className={`p-2.5 rounded-xl border text-left transition-all flex items-center justify-between cursor-pointer ${
              bonusFactors.hasJobCreation
                ? 'bg-purple-600/30 border-purple-400 text-white ring-1 ring-purple-400/50 shadow-xs'
                : 'bg-slate-800/60 hover:bg-slate-800 border-slate-700/80 text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="flex items-center gap-2 min-w-0">
              <Users className={`w-4 h-4 shrink-0 ${bonusFactors.hasJobCreation ? 'text-purple-400' : 'text-slate-500'}`} />
              <div className="truncate">
                <span className="text-xs font-black block truncate">청년·일자리 창출</span>
                <span className="text-[10px] text-slate-400 block">+6%p 신속보증</span>
              </div>
            </div>
            <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-md shrink-0 ml-1 ${
              bonusFactors.hasJobCreation ? 'bg-purple-500 text-white' : 'bg-slate-700 text-slate-400'
            }`}>
              {bonusFactors.hasJobCreation ? '적용중' : '미적용'}
            </span>
          </button>

          {/* Venture / Tech Innovation Toggle */}
          <button
            type="button"
            onClick={() => handleToggleBonus('hasVentureOrInnoBiz')}
            className={`p-2.5 rounded-xl border text-left transition-all flex items-center justify-between cursor-pointer ${
              bonusFactors.hasVentureOrInnoBiz
                ? 'bg-amber-600/30 border-amber-400 text-white ring-1 ring-amber-400/50 shadow-xs'
                : 'bg-slate-800/60 hover:bg-slate-800 border-slate-700/80 text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="flex items-center gap-2 min-w-0">
              <Cpu className={`w-4 h-4 shrink-0 ${bonusFactors.hasVentureOrInnoBiz ? 'text-amber-400' : 'text-slate-500'}`} />
              <div className="truncate">
                <span className="text-xs font-black block truncate">이노비즈·특허</span>
                <span className="text-[10px] text-slate-400 block">+8%p 기술우대</span>
              </div>
            </div>
            <span className={`text-[10px] font-black px-1.5 py-0.5 rounded-md shrink-0 ml-1 ${
              bonusFactors.hasVentureOrInnoBiz ? 'bg-amber-500 text-white' : 'bg-slate-700 text-slate-400'
            }`}>
              {bonusFactors.hasVentureOrInnoBiz ? '적용중' : '미적용'}
            </span>
          </button>
        </div>
      </div>

      {/* Main Diagnosis Content for Active Fund */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-12 gap-6 relative z-10">
        
        {/* Left Column: 5-Tier Gauge & Key Probability Score */}
        <div className="lg:col-span-5 bg-slate-850/90 bg-slate-800/60 backdrop-blur-md rounded-2xl p-5 border border-slate-700/80 flex flex-col justify-between">
          <div>
            <div className="flex items-start justify-between gap-3 mb-4">
              <div>
                <span className="text-[10px] font-bold text-indigo-300 uppercase tracking-wider">{activeFund.agency}</span>
                <h3 className="text-lg font-black text-white leading-tight mt-0.5">{activeFund.title}</h3>
              </div>
              <div className="text-right">
                <span className="text-[10px] font-bold text-slate-400">최대 한도</span>
                <div className="text-base font-black text-emerald-400">{activeFund.maxAmount}</div>
              </div>
            </div>

            {/* 5-Tier Visual Stepper Scale */}
            <div className="mb-5 bg-slate-900/90 rounded-xl p-3.5 border border-slate-800">
              <div className="text-[11px] font-bold text-slate-400 mb-2 flex items-center justify-between">
                <span>5단계 심사 승인 가능성 척도</span>
                <span className="text-indigo-300 font-black">매칭 신뢰도 96.4%</span>
              </div>

              <div className="grid grid-cols-5 gap-1 text-center">
                {APPROVAL_TIERS.map((tier) => {
                  const isActive = activeTierInfo.tierKorean === tier.tierKorean;
                  return (
                    <div 
                      key={tier.tierKorean}
                      className={`py-2 px-1 rounded-lg flex flex-col items-center transition-all ${
                        isActive
                          ? 'ring-2 ring-white/90 scale-105 shadow-md'
                          : 'opacity-40 hover:opacity-75'
                      }`}
                      style={{
                        backgroundColor: isActive ? tier.badgeColor : '#1e293b'
                      }}
                    >
                      <span className="text-[11px] font-black text-white">{tier.tierKorean}</span>
                      <span className="text-[9px] text-white/80 font-bold mt-0.5">{tier.minScore}p+</span>
                    </div>
                  );
                })}
              </div>

              {/* Needle / Tier Description */}
              <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-300 font-medium">현재 진단 상태:</span>
                <span 
                  className="font-black px-2 py-0.5 rounded-md text-xs"
                  style={{
                    backgroundColor: activeTierInfo.bgColor,
                    color: activeTierInfo.color
                  }}
                >
                  {activeTierInfo.tierKorean} ({activeTierInfo.label})
                </span>
              </div>
            </div>

            {/* Score Display Card */}
            <div className="bg-gradient-to-r from-slate-900 to-indigo-950/80 rounded-xl p-4 border border-indigo-500/20 mb-4">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-slate-400">승인 예측 확률</span>
                  <div className="flex items-baseline gap-2 mt-1">
                    <span className="text-3xl sm:text-4xl font-black text-white">
                      {simulatedScore}%
                    </span>
                    <span className="text-xs font-bold text-slate-400">/ 100%</span>
                    {simulatedScoreBonus > 0 && (
                      <span className="text-xs font-black text-emerald-400 bg-emerald-500/20 px-2 py-0.5 rounded-md animate-pulse">
                        +{simulatedScoreBonus}%p 상승!
                      </span>
                    )}
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-[11px] font-bold text-slate-400">유사 승인 빅데이터</div>
                  <div className="text-sm font-black text-indigo-300 mt-1">
                    {report.matchedPeers.length > 0 ? `${report.matchedPeers.length * 370}+건` : '1,480+건'} 매칭
                  </div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden mt-3 relative">
                <div 
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${simulatedScore}%`,
                    backgroundColor: activeTierInfo.badgeColor
                  }}
                ></div>
              </div>
            </div>

            {/* Policy Bonus Adjustment Details Card */}
            {report.policyBonusAdjustment && (
              <div className="mb-4 p-3 bg-slate-900/90 rounded-xl border border-indigo-500/30 text-xs">
                <div className="flex items-center justify-between mb-1.5">
                  <span className="font-bold text-indigo-300 flex items-center gap-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    정책적 가점 정밀 보정
                  </span>
                  <span className={`px-2 py-0.5 rounded text-[11px] font-black ${
                    report.policyBonusAdjustment.totalBonusUplift > 0 
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                      : 'bg-slate-800 text-slate-400'
                  }`}>
                    {report.policyBonusAdjustment.totalBonusUplift > 0 
                      ? `+${report.policyBonusAdjustment.totalBonusUplift}%p 보정` 
                      : '가점 미반영'}
                  </span>
                </div>
                {report.policyBonusAdjustment.appliedBonuses.length > 0 ? (
                  <div className="space-y-1.5 mt-2">
                    {report.policyBonusAdjustment.appliedBonuses.map(b => (
                      <div key={b.id} className="flex items-center justify-between text-[11px] bg-slate-800/80 px-2.5 py-1 rounded-lg">
                        <span className="text-slate-300 font-medium truncate max-w-[170px]">{b.name}</span>
                        <span className="text-emerald-400 font-black">+{b.points}%p</span>
                      </div>
                    ))}
                    <div className="text-[10px] text-slate-400 pt-1 leading-snug">
                      기본 확률 {report.policyBonusAdjustment.baseProbability}% ➔ 가점 보정 {report.policyBonusAdjustment.calibratedProbability}%
                    </div>
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-400 mt-1">
                    상단 가점 컨트롤러에서 스마트공장 또는 탄소중립 실천을 체크하여 승인 확률을 보정하세요.
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Quick Action Buttons */}
          <div className="flex items-center gap-2 pt-2">
            <button
              type="button"
              onClick={() => onOpenReport(activeFund)}
              className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all shadow-md cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>심층 진단 리포트</span>
            </button>
            {onOpenConsultation && (
              <button
                type="button"
                onClick={() => onOpenConsultation(activeFund)}
                className="py-2.5 px-3 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
                title="해당 자금 1:1 비대면 전문 상담 신청"
              >
                <Headphones className="w-3.5 h-3.5 text-indigo-300" />
                <span>1:1 상담</span>
              </button>
            )}
          </div>
        </div>

        {/* Right Column: 5 Dimensions & Real-Time Improvement Simulator */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* 5 Evaluated Dimensions Progress */}
          <div className="bg-slate-800/60 backdrop-blur-md rounded-2xl p-5 border border-slate-700/80">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-xs font-black text-slate-200 flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-indigo-400" />
                5대 심사 핵심 차원 정밀 평가
              </h4>
              <span className="text-[10px] font-bold text-slate-400">가중치 100% 반영</span>
            </div>

            <div className="space-y-2.5">
              {report.dimensions.map((dim) => {
                const isOptimal = dim.score >= 80;
                const isWarning = dim.score < 60;
                return (
                  <div key={dim.id} className="bg-slate-900/60 rounded-xl p-2.5 border border-slate-800">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-200">{dim.dimensionName}</span>
                        <span className="text-[10px] text-slate-400 font-medium">비중 {dim.weight}%</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                          isOptimal 
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                            : isWarning 
                              ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' 
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        }`}>
                          {dim.statusLabel}
                        </span>
                        <span className="font-black text-white">{dim.score}점</span>
                      </div>
                    </div>
                    <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all duration-300 ${
                          isOptimal ? 'bg-emerald-400' : isWarning ? 'bg-rose-500' : 'bg-amber-400'
                        }`}
                        style={{ width: `${dim.score}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Interactive Improvement Simulator (개선 조치 실시간 시뮬레이터) */}
          <div className="bg-gradient-to-br from-indigo-950/60 to-slate-900/80 rounded-2xl p-5 border border-indigo-500/30">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h4 className="text-xs font-black text-white flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-amber-400" />
                  실시간 승인 확률 개선 시뮬레이터
                </h4>
                <p className="text-[11px] text-slate-300 mt-0.5">
                  아래 보완 항목을 체크하면 실시간으로 승인 가능성 상승 효과를 확인하실 수 있습니다.
                </p>
              </div>
              {simulatedActionIds.length > 0 && (
                <button
                  type="button"
                  onClick={() => setSimulatedActionIds([])}
                  className="text-[10px] font-bold text-slate-400 hover:text-slate-200 underline cursor-pointer"
                >
                  초기화
                </button>
              )}
            </div>

            <div className="space-y-2">
              {report.improvementItems.slice(0, 3).map((action) => {
                const isChecked = simulatedActionIds.includes(action.id);
                return (
                  <div
                    key={action.id}
                    onClick={() => toggleAction(action.id)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer flex items-start gap-3 ${
                      isChecked
                        ? 'bg-emerald-950/40 border-emerald-500/50 shadow-sm ring-1 ring-emerald-400/30'
                        : 'bg-slate-900/60 hover:bg-slate-800/80 border-slate-800'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => {}}
                      className="mt-1 w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 bg-slate-800 border-slate-700 cursor-pointer shrink-0"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-0.5">
                        <span className="text-xs font-bold text-white truncate">{action.title}</span>
                        <span className="text-[10px] font-black text-emerald-300 bg-emerald-500/20 px-2 py-0.5 rounded-full shrink-0">
                          +{action.potentialUpliftPercent}%p 확률 상승
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-300 leading-tight line-clamp-2">
                        {action.actionGuide}
                      </p>
                      <div className="flex items-center gap-2 mt-1.5 text-[10px] text-slate-400 font-medium">
                        <span>예상 소요: {action.estimatedDays}</span>
                        <span>•</span>
                        <span className="text-indigo-300">우선순위: {action.priority}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Score Lift Summary Banner */}
            <div className="mt-3 pt-3 border-t border-indigo-500/20 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="text-slate-300">시뮬레이션 승인 척도 변화:</span>
                <span className="font-bold text-slate-400">{baseScore}% ({baseTierInfo.tierKorean})</span>
                <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
                <span className="font-black text-emerald-400">{simulatedScore}% ({simulatedTierInfo.tierKorean})</span>
              </div>
              <button
                type="button"
                onClick={() => onOpenReport(activeFund)}
                className="text-[11px] font-bold text-indigo-300 hover:text-indigo-200 underline flex items-center gap-1 cursor-pointer"
              >
                <span>상세 로드맵 확인</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};
