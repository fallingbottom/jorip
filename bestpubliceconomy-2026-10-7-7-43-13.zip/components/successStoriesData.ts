import { FounderAdviceItem, AiFaqItem } from '../types';

export interface SuccessStory {
  id: string;
  industryCategory: 'FOOD' | 'TECH' | 'MANUFACTURING' | 'RETAIL' | 'SERVICE' | 'OTHER';
  industryLabel: string;
  iconName: 'Coffee' | 'Laptop' | 'Factory' | 'ShoppingBag' | 'Briefcase' | 'Store';
  ownerName: string;
  businessName: string;
  location: string;
  province: string;
  district: string;
  businessAge: string;
  annualRevenue: string;
  fundingNeedType: 'DEBT_REFINANCE' | 'WORKING_CAPITAL' | 'FACILITY_EXPANSION' | 'DIGITAL_TRANSFORM';
  fundingNeedLabel: string;
  fundName: string;
  agency: string;
  approvedAmount: string;
  approvedAmountNumber: number;
  rateReduction: string;
  annualSavings: string;
  revenueGrowth: string;
  keySuccessFactor: string;
  beforeSituation: string;
  growthStory: string;
  testimonial: string;
  rating: number;
  date: string;
  badge: string;
  growthTimeline: {
    stage: string;
    description: string;
  }[];
  applicationTip: string;
  founderAdvice: FounderAdviceItem[];
  aiFaqSummary: AiFaqItem[];
}

export const SUCCESS_STORIES: SuccessStory[] = [
  // 1. 서울 마포구 - 외식/베이커리
  {
    id: 'story-food-1',
    industryCategory: 'FOOD',
    industryLabel: '외식/카페/음식업',
    iconName: 'Coffee',
    ownerName: '김** 대표님',
    businessName: '서울 마포구 O베이커리 카페',
    location: '서울 마포구',
    province: '서울',
    district: '마포구',
    businessAge: '업력 3년차',
    annualRevenue: '연 매출 2.6억원',
    fundingNeedType: 'DEBT_REFINANCE',
    fundingNeedLabel: '고금리 대환 & 운전자금',
    fundName: '소상공인 대환대출 특별자금',
    agency: '소상공인시장진흥공단',
    approvedAmount: '5,000만원',
    approvedAmountNumber: 50000000,
    rateReduction: '11.8% → 3.2% (-8.6%p)',
    annualSavings: '연간 약 430만원 이자 절감',
    revenueGrowth: '월 순익 +28% 개선',
    keySuccessFactor: '2금융권 고금리 채무 즉시 대환 매칭 + 마이데이터 부채 통합 산출 가점',
    beforeSituation: '원자재 가격 급등과 2금융권 카드론 채무 3건으로 매월 이자만 75만원 이상 지출되어 현금 흐름이 매우 경색된 상황이었습니다.',
    growthStory: '3.2% 정책 저금리로 5천만원 전액을 대환하여 월 이자 부담을 13만원대로 낮추고, 절감된 자금으로 시그니처 디저트 포장 라인을 신설했습니다.',
    testimonial: '제가 대상이 되는 줄도 몰랐던 소진공 대환대출을 BizMatch AI가 정확히 찾아주었습니다. 신청 2주 만에 고금리 굴레에서 벗어나 매장 운영에 집중할 수 있게 되었습니다.',
    rating: 5,
    date: '2026년 2월 승인',
    badge: '금리 -8.6%p 절감',
    growthTimeline: [
      { stage: '1단계: 채무 구조 개선', description: '카드론 3건 전액 상환 및 신용점수 78점 상승' },
      { stage: '2단계: 신메뉴 개발', description: '절감된 고정비로 온라인 택배 전용 베이커리 런칭' },
      { stage: '3단계: 매출 성장', description: '월 매출 1,800만원 → 2,600만원으로 44% 급증' }
    ],
    applicationTip: '2금융권 채무가 있다면 마이데이터 연동으로 부채 내역을 한 번에 증빙하여 우선 심사 트랙을 타는 것이 핵심입니다.',
    founderAdvice: [
      {
        number: 1,
        title: '2금융권 고금리 카드론은 망설이지 말고 즉시 대환 신청할 것',
        detail: '카드론이나 캐피탈 이자가 10%를 넘어가면 매달 매출이 올라도 통장에 남는 돈이 없습니다. 소진공 대환대출은 연체 전 정상 납입 중일 때 가장 신속하게 승인되므로 즉시 대환해야 합니다.',
        highlightTag: '#카드론즉시대환 #연체전신청필수',
        actionMetric: '금리 11.8% ➔ 3.2% 즉시 전환'
      },
      {
        number: 2,
        title: '마이데이터 부채 연동으로 서류 발급 비용과 심사 기간을 0일로 단축',
        detail: '금융기관마다 다니며 부채증명서나 거래확인서를 뗄 필요 없이, 마이데이터 연동 동의로 모든 채무를 한 번에 검증받아 서류 미비로 인한 보완 요청을 100% 방지했습니다.',
        highlightTag: '#마이데이터원클릭 #보완요청0건',
        actionMetric: '심사 기간 14일 ➔ 7일로 단축'
      },
      {
        number: 3,
        title: '아낀 이자 고정비는 즉시 포장/온라인 신규 매출 라인에 재투자',
        detail: '매달 절감된 이자 36만원을 모아 시그니처 구움과자 선물 패키징을 제작하고 스마트스토어를 열었습니다. 고정비 절감이 신규 매출 44% 성장으로 이어졌습니다.',
        highlightTag: '#절감액재투자 #온라인신매출창출',
        actionMetric: '월 매출 +800만원 추가 신장'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-food1-1',
        category: 'CREDIT',
        categoryLabel: '신용·부채 조건',
        question: '카드론 3건(총 5천만원)이 있고 신용점수가 750점인데 소진공 대환대출 승인이 가능한가요?',
        aiSummaryAnswer: '네, 가능합니다. 소상공인 대환대출은 2금융권 7% 이상 고금리 대출을 보유한 중·저신용 소상공인을 구제하기 위해 편성된 특별 정책자금입니다. 단 연체 이력이 없어야 하므로 연체 전 즉시 신청이 핵심입니다.',
        keyTakeaway: '📌 핵심: 2금융권 7% 이상 정상 이용 중이면 신용점수 700점대도 100% 대환 대상',
        confidenceScore: 98,
        verifiedAgency: '소상공인시장진흥공단'
      },
      {
        id: 'faq-food1-2',
        category: 'PERIOD',
        categoryLabel: '심사 기간·승인',
        question: '신청 접수 후 실제 은행 대환 입금까지 며칠이나 걸리나요?',
        aiSummaryAnswer: '마이데이터 전자접수 시 소진공 지원대상 확인서 발급까지 약 5~7영업일, 연계 시중은행(국민/신한/하나/우리/기업 등) 비대면 약정 및 채무 대환 실행까지 총 10~14영업일 소요됩니다.',
        keyTakeaway: '📌 핵심: 마이데이터 연동 시 서류 보완 없이 2주 내 대환 실행 완료',
        confidenceScore: 95,
        verifiedAgency: '소진공 & 시중 6대 은행'
      },
      {
        id: 'faq-food1-3',
        category: 'DOCS',
        categoryLabel: '필수 서류·소명',
        question: '2금융권 금융거래확인서를 각 금융사마다 직접 떼어 제출해야 하나요?',
        aiSummaryAnswer: '아닙니다. 2026년 비즈매치 시스템 및 정부 정책자금 포털에서는 마이데이터 동의 한 번으로 2금융권 대출계좌번호, 잔액, 적용이율이 실시간으로 확인되므로 서류 방문 발급이 필요 없습니다.',
        keyTakeaway: '📌 핵심: 종이 서류 발급 불필요, 간편인증 1회로 부채 전산 조회 완결',
        confidenceScore: 99,
        verifiedAgency: '공공마이데이터 포털'
      }
    ]
  },
  // 2. 서울 강남구 - IT/인공지능
  {
    id: 'story-tech-gangnam',
    industryCategory: 'TECH',
    industryLabel: 'IT/인공지능/스타트업',
    iconName: 'Laptop',
    ownerName: '정** 대표님',
    businessName: '서울 강남구 테헤란로 A인텔리전스',
    location: '서울 강남구',
    province: '서울',
    district: '강남구',
    businessAge: '업력 2년차',
    annualRevenue: '연 매출 5.8억원',
    fundingNeedType: 'WORKING_CAPITAL',
    fundingNeedLabel: 'AI R&D 서버 확충 및 인재 채용',
    fundName: '신용보증기금 퍼스트펭귄 특별보증',
    agency: '신용보증기금',
    approvedAmount: '3.0억원',
    approvedAmountNumber: 300000000,
    rateReduction: '2.4% (초저금리 우대)',
    annualSavings: '일반 여신 대비 연 1,400만원 절감',
    revenueGrowth: '연 매출 +120% 폭풍 성장',
    keySuccessFactor: 'AI 특허 2건 등록 기술성 평가 A등급 + 벤처기업 인증 연계',
    beforeSituation: 'GPU 클라우드 비용과 석박사급 머신러닝 엔지니어 추가 채용으로 매월 2천만원 이상의 고정 연구개발비 조달이 절박했습니다.',
    growthStory: '신보 퍼스트펭귄 3억원 100% 전액 보증을 승인받아 B2B 엔터프라이즈 솔루션 런칭을 완료하고 국내 금융사 3곳에 납품했습니다.',
    testimonial: '기술력은 있었지만 재무제표가 짧아 은행 문턱이 높았는데, AI의 기술특례보증 전략 리포트 덕분에 3억원 전액 보증서를 확보했습니다.',
    rating: 5,
    date: '2026년 1월 승인',
    badge: '3억원 전액 보증 승인',
    growthTimeline: [
      { stage: '1단계: 기술평가 준비', description: 'AI 알고리즘 특허 명세서 보완' },
      { stage: '2단계: 3억 자금 수혈', description: 'GPU 클러스터 증설 & 핵심 연구원 영입' },
      { stage: '3단계: 대기업 계약', description: '연간 구독 ARR 6억원 달성' }
    ],
    applicationTip: 'IT 기술기업은 기술가치평가서와 IP 특허 출원 사실 증명원을 미리 구비하면 최고 보증 한도를 받을 수 있습니다.',
    founderAdvice: [
      {
        number: 1,
        title: '재무제표가 짧다면 특허 IP와 소프트웨어 저작권 기술평가로 승부할 것',
        detail: '창업 2년차라 매출 실적이 부족했지만, 등록 특허 2건의 기술사업화 계획서를 신보 기술평가 양식에 맞추어 작성해 기술등급 A를 받았습니다.',
        highlightTag: '#기술성평가A등급 #IP특허소명',
        actionMetric: '무담보 3억원 전액 보증서 발급'
      },
      {
        number: 2,
        title: '벤처기업 확인서와 이노비즈 인증을 자금 신청 1달 전 미리 획득',
        detail: '신보 퍼스트펭귄 및 중진공 혁신자금은 벤처기업 인증 보유 시 보증비율 100%와 금리 0.5%p 추가 감면 우대를 제공하므로 사전 인증이 필수입니다.',
        highlightTag: '#벤처기업인증가점 #보증비율100%',
        actionMetric: '보증료율 0.5%p 인하 혜택'
      },
      {
        number: 3,
        title: '자금 소요 계획을 GPU 클러스터 및 개발인력 인건비로 명확히 수치화',
        detail: '단순히 "운전자금이 필요하다"가 아니라 "AI 추론 인프라 1.2억 + 연구원 3인 인건비 1.8억"으로 견적서와 채용 계획을 첨부하니 감액 없이 원안 승인되었습니다.',
        highlightTag: '#소요명세구체화 #감액없는원안승인',
        actionMetric: '3억원 신청액 100% 한도 확정'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-tech-gangnam-1',
        category: 'STRATEGY',
        categoryLabel: '실전 전략',
        question: '창업 2년차 스타트업인데 3억원 이상 대규모 보증 승인이 정말 가능한가요?',
        aiSummaryAnswer: '신용보증기금의 퍼스트펭귄 및 프론트원 프로그램은 재무제표보다 기술력, BM의 확장성, 지식재산권(특허)을 중심으로 심사합니다. 기술성 평가 A등급 이상 획득 시 최대 3~30억원까지 단계별 한도가 열립니다.',
        keyTakeaway: '📌 핵심: 재무제표 대신 특허 기술가치평가서와 BM 확장성 입증 시 대규모 보증 가능',
        confidenceScore: 96,
        verifiedAgency: '신용보증기금 (KODIT)'
      },
      {
        id: 'faq-tech-gangnam-2',
        category: 'LIMIT_RATE',
        categoryLabel: '한도·금리 혜택',
        question: '신보 보증서 대출 시 실제 적용되는 대출 금리와 보증료율은 어떻게 되나요?',
        aiSummaryAnswer: '신보 100% 전액보증서가 발급되면 시중은행 금리는 기준금리+가산금리 1%대 중반(약 2.4~3.0%)으로 낮아지며, 우대 특례로 보증료율 역시 0.5% 수준(기본 1.2% 대비 대폭 감면)으로 적용됩니다.',
        keyTakeaway: '📌 핵심: 100% 보증서로 2%대 초저금리 + 보증료 0.5% 고정 혜택',
        confidenceScore: 97,
        verifiedAgency: '신보 & 협약 금융기관'
      }
    ]
  },
  // 3. 서울 영등포구 - 도소매/유통
  {
    id: 'story-retail-seoul',
    industryCategory: 'RETAIL',
    industryLabel: '도소매/문구·팬시 유통',
    iconName: 'ShoppingBag',
    ownerName: '윤** 대표님',
    businessName: '서울 영등포구 문래동 Y디자인문구',
    location: '서울 영등포구',
    province: '서울',
    district: '영등포구',
    businessAge: '업력 4년차',
    annualRevenue: '연 매출 3.2억원',
    fundingNeedType: 'WORKING_CAPITAL',
    fundingNeedLabel: '해외 소싱 선매입 운전자금',
    fundName: '서울신용보증재단 중소기업육성자금',
    agency: '서울신용보증재단',
    approvedAmount: '5,000만원',
    approvedAmountNumber: 50000000,
    rateReduction: '3.0% (서울시 이차보전 2.0%p 반영)',
    annualSavings: '월 이자 부담 12만원 수준',
    revenueGrowth: '성수기 품절 방지로 매출 +38%',
    keySuccessFactor: '서울시 소상공인 안심통장 연계 + 제로페이 가맹 실적 가점',
    beforeSituation: '신학기 시즌을 앞두고 원자재 가격 상승으로 대량 사입 자금이 부족해 거래처 발주를 놓칠 위기에 처해 있었습니다.',
    growthStory: '서울신보 2%대 이차보전자금을 수혈받아 대량 사입 단가를 18% 낮추고 마켓컬리와 쿠팡 로켓배송에 전 품목 입점했습니다.',
    testimonial: '서울시 지자체 이차보전 자금을 AI가 딱 짚어주어 2%대 금리로 자금을 확보했습니다. 덕분에 올해 최대 매출을 갱신했습니다.',
    rating: 5,
    date: '2026년 2월 승인',
    badge: '서울시 2.0%p 이자 지원',
    growthTimeline: [
      { stage: '1단계: 이차보전 접수', description: '서울신보 보증서 발급 완료' },
      { stage: '2단계: 사입단가 절감', description: '18% 저렴하게 시즌 물량 선확보' },
      { stage: '3단계: 판로 다변화', description: '온라인 대형 플랫폼 4곳 동시 입점' }
    ],
    applicationTip: '서울 소재 사업자는 서울시 중기자금 이차보전 공고를 반드시 매월 초 신속 접수해야 마감 전 배정받을 수 있습니다.',
    founderAdvice: [
      {
        number: 1,
        title: '서울시 이차보전(이자 2.0%p 지원) 자금은 매월 1일 오픈 즉시 접수할 것',
        detail: '서울신보 지자체 이차보전 자금은 금리가 2~3%대로 워낙 저렴하여 월초 예산이 3일 내 소진되는 경우가 많습니다. 비즈매치 알림을 켜두고 공고 첫날 바로 접수해야 합니다.',
        highlightTag: '#서울시이차보전 #월초오픈즉시접수',
        actionMetric: '서울시 이자 지원 연 2.0%p 확보'
      },
      {
        number: 2,
        title: '제로페이 가맹 및 서울사랑상품권 결제 실적으로 가산점 5점 확보',
        detail: '서울시 정책자금은 지자체 소상공인 우대 정책(제로페이 가맹점, 착한가격업소 등)에 가점을 크게 줍니다. 사전에 무료 가맹만 해두어도 심사 점수가 대폭 상승합니다.',
        highlightTag: '#제로페이가맹가점 #지자체특화가점',
        actionMetric: '심사 가산점 +5점 획득'
      },
      {
        number: 3,
        title: '선매입 견적서와 거래처 발주서를 첨부해 운전자금 타당성 입증',
        detail: '단순 자금 요청보다 "신학기 시즌 사입 발주서 5천만원"을 제출하여 자금의 명확한 용처와 입고 후 즉시 매출 회수 계획을 보여준 것이 빠른 승인의 열쇠였습니다.',
        highlightTag: '#사입발주서제출 #매출회수계획소명',
        actionMetric: '사입단가 18% 절감 효과'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-retail-seoul-1',
        category: 'LIMIT_RATE',
        categoryLabel: '한도·금리 혜택',
        question: '서울시 이차보전(2.0%p)은 어떻게 적용되고 만기는 몇 년인가요?',
        aiSummaryAnswer: '서울시에서 은행 대출 이자 중 연 2.0~2.5%p를 대신 부담해 주어, 대표님은 최종 2.5~3.0%대의 초저금리만 납부하게 됩니다. 통상 1년 거치 4년 균등분할상환(총 5년) 조건으로 운영됩니다.',
        keyTakeaway: '📌 핵심: 서울시가 이자 2%p 대납, 5년 장기 분할상환으로 월 부담 최소화',
        confidenceScore: 98,
        verifiedAgency: '서울신용보증재단 & 서울특별시'
      },
      {
        id: 'faq-retail-seoul-2',
        category: 'PERIOD',
        categoryLabel: '심사 기간·승인',
        question: '서울신보 무방문 모바일 앱 접수로 신청해도 지점 방문 신청과 한도가 같나요?',
        aiSummaryAnswer: '네, 동일합니다. 서울신보 모바일 앱(또는 비즈매치 연동) 전자접수를 이용하면 현장 방문 대기 없이도 동일한 보증 한도(최대 5천만~1억원)가 적용되며, 처리 속도는 오히려 3~4일 더 빠릅니다.',
        keyTakeaway: '📌 핵심: 모바일 비대면 신청 시 대기 없이 빠른 보증서 발급',
        confidenceScore: 96,
        verifiedAgency: '서울신용보증재단'
      }
    ]
  },
  // 4. 경기 성남시 - IT/SaaS
  {
    id: 'story-tech-1',
    industryCategory: 'TECH',
    industryLabel: 'IT/소프트웨어/기술',
    iconName: 'Laptop',
    ownerName: '이** 대표님',
    businessName: '경기 성남시 판교 S소프트',
    location: '경기 성남시',
    province: '경기',
    district: '성남시',
    businessAge: '업력 2년차',
    annualRevenue: '연 매출 4.2억원',
    fundingNeedType: 'WORKING_CAPITAL',
    fundingNeedLabel: '신규 개발 인력 채용 & 운전자금',
    fundName: '창업유망 혁신기업 특례보증',
    agency: '경기신용보증재단',
    approvedAmount: '1.2억원',
    approvedAmountNumber: 120000000,
    rateReduction: '2.8% (고정금리 우대)',
    annualSavings: '일반 은행 대비 연 640만원 절감',
    revenueGrowth: '연 매출 +65% 성장',
    keySuccessFactor: '창업 7년 이내 특례 자격 자동 판별 + 벤처기업 인증 및 IP 특허 가점 10점 완비',
    beforeSituation: '신규 SaaS 제품 런칭을 앞두고 클라우드 서버 인프라 비용과 시니어 개발자 채용을 위한 단기 운전자금 1억원이 절실했습니다.',
    growthStory: '경기신보 100% 전액 보증서 발급으로 1.2억원을 2.8% 초저금리로 수혈받아 AI 모듈 탑재를 성공적으로 마무리했습니다.',
    testimonial: '일반 시중은행에서는 부동산 담보가 없다며 거절당했었는데, BizMatch AI가 기술 특례보증 공고를 발견해 주어 사업이 도약할 수 있었습니다.',
    rating: 5,
    date: '2026년 1월 승인',
    badge: '1.2억원 100% 한도 승인',
    growthTimeline: [
      { stage: '1단계: 자금 유치', description: '경기신보 특례보증 1.2억원 2.8% 확정' },
      { stage: '2단계: 인력 확충', description: '백엔드/AI 엔지니어 2명 신규 영입' },
      { stage: '3단계: 글로벌 진출', description: '일본 기업 3곳과 연간 구독 계약 체결' }
    ],
    applicationTip: '기술 스타트업은 특허 출원서 및 기술개발 계획서를 미리 PDF로 구비하면 보증 심사에서 최고 등급을 받기 유리합니다.',
    founderAdvice: [
      {
        number: 1,
        title: '부동산 담보가 없어도 무담보 100% 신용보증서 트랙을 활용할 것',
        detail: '시중은행 창구에 바로 가면 부동산 담보를 요구하지만, 경기신보 혁신기업 특례보증서를 먼저 발급받아가면 은행은 거절 없이 2.8% 고정금리로 대출을 내어줍니다.',
        highlightTag: '#무담보100%보증 #은행거절극복',
        actionMetric: '부동산 담보 없이 1.2억원 유치'
      },
      {
        number: 2,
        title: '판교/경기 스타트업 육성 펀드 및 경기도 중기육성자금 연계 신청',
        detail: '경기도 지자체 협약 자금은 금리 우대 폭이 크므로 경기신보 신청 시 "경기도 청년혁신/스타트업 연계 트랙"을 체크하여 추가 금리 1.0%p 인하를 받으세요.',
        highlightTag: '#경기도중기자금연계 #추가금리인하',
        actionMetric: '적용 금리 연 2.8% 확정'
      },
      {
        number: 3,
        title: '청년 신규 고용 계획서 첨부로 고용창출 가점 만점 획득',
        detail: '자금 수혈 후 개발자 2명을 채용하겠다는 고용창출 확약서를 제출해 심사 가점 10점을 챙겼습니다. 실제로 채용 후 4대보험 가입증명서를 제출하면 사후 평가도 완료됩니다.',
        highlightTag: '#고용창출가점10점 #심사평가만점',
        actionMetric: '개발자 2명 신규 영입 성공'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-tech1-1',
        category: 'CREDIT',
        categoryLabel: '신용·부채 조건',
        question: '업력 2년차 법인인데 대표자 개인 신용점수도 심사에 반영되나요?',
        aiSummaryAnswer: '창업 7년 이내 초기 기업의 경우 법인 재무제표와 함께 대표자의 신용점수(KCB 700점 이상 권장)가 종합 평가됩니다. 다만 벤처기업 인증이나 특허가 있으면 대표자 신용점수 감점을 상당 부분 상쇄할 수 있습니다.',
        keyTakeaway: '📌 핵심: 특허 및 벤처인증 보유 시 대표자 신용점수 다소 낮아도 보증 가능',
        confidenceScore: 94,
        verifiedAgency: '경기신용보증재단'
      },
      {
        id: 'faq-tech1-2',
        category: 'DOCS',
        categoryLabel: '필수 서류·소명',
        question: '특례보증 심사 시 기술개발계획서는 얼마나 길게 써야 하나요?',
        aiSummaryAnswer: '분량보다는 핵심 기능 차별점, 시장 수요처, 개발 로드맵이 명확해야 합니다. 2~3페이지 분량의 요약 사업계획서와 특허증 사본, 기존 매출 계약서 사본만으로도 충분히 A등급 평가를 받을 수 있습니다.',
        keyTakeaway: '📌 핵심: 3페이지 내외 핵심 BM 요약 + 특허 사본으로 충분',
        confidenceScore: 97,
        verifiedAgency: '기술보증기금 & 경기신보'
      }
    ]
  },
  // 5. 경기 화성시 - 제조/자동차부품
  {
    id: 'story-mfg-hwaseong',
    industryCategory: 'MANUFACTURING',
    industryLabel: '제조/자동차 금형 부품',
    iconName: 'Factory',
    ownerName: '장** 대표님',
    businessName: '경기 화성시 향남 H정밀금형',
    location: '경기 화성시',
    province: '경기',
    district: '화성시',
    businessAge: '업력 5년차',
    annualRevenue: '연 매출 9.2억원',
    fundingNeedType: 'FACILITY_EXPANSION',
    fundingNeedLabel: '친환경 전기차 부품 전용 라인 구축',
    fundName: '제조 소상공인 성장촉진 특별자금',
    agency: '중소벤처기업진흥공단',
    approvedAmount: '2.0억원',
    approvedAmountNumber: 200000000,
    rateReduction: '5.8% → 2.7% (-3.1%p)',
    annualSavings: '연 620만원 이자 비용 절감',
    revenueGrowth: '생산 능력 1.8배 확대',
    keySuccessFactor: '친환경 미래차 전환 기술 계획서 소명 + 뿌리기업 인증 가점',
    beforeSituation: '전기차 전용 알루미늄 경량화 금형 주문이 쇄도했으나, 전용 초정밀 와이어 커팅기 도입 자금이 부족해 외주 비용이 과다하게 발생하고 있었습니다.',
    growthStory: '중진공 성장촉진자금 2억원을 8년 장기 분할상환으로 조달하여 자체 생산라인을 가동하고 영업이익률을 11%에서 21%로 2배 끌어올렸습니다.',
    testimonial: '복잡한 중진공 시설자금 심사를 AI 가이드대로 단계별 서류를 준비하니 담당 심사역도 감탄하며 신속하게 승인해 주었습니다.',
    rating: 5,
    date: '2026년 2월 승인',
    badge: '시설자금 2억원 승인',
    growthTimeline: [
      { stage: '1단계: 장비 도입', description: '스위스제 고정밀 와이어 가공기 설치' },
      { stage: '2단계: 외주 원가 절감', description: '자체 가공 전환으로 제조원가 35% 절감' },
      { stage: '3단계: 1차 벤더 직납', description: '현대/기아 협력 1차사 직납 벤더 등록' }
    ],
    applicationTip: '시설자금은 공인된 설비 공급처의 비교 견적서 2부와 도입 후 생산성 지표를 첨부하면 감액 없이 100% 승인됩니다.',
    founderAdvice: [
      {
        number: 1,
        title: '시설자금은 반드시 정식 비교 견적서 2부와 카탈로그를 사전 준비할 것',
        detail: '설비 도입 시설자금은 장비 공급업체의 비교 견적서(A사, B사)와 도입 타당성 사유서를 함께 제출해야 심사역이 한도를 1원도 깎지 않고 100% 승인해 줍니다.',
        highlightTag: '#비교견적서2부 #시설자금원안승인',
        actionMetric: '설비자금 2억원 100% 전액 확보'
      },
      {
        number: 2,
        title: '국가 뿌리기업 확인서 발급으로 심사 우선권과 가점 챙기기',
        detail: '금형, 용접, 소성가공 등 제조기업은 뿌리산업 확인서를 발급받으면 중진공 시설자금 접수 시 우선 심사 쿼터가 배정되어 경쟁률을 피할 수 있습니다.',
        highlightTag: '#뿌리기업확인서 #우선심사쿼터',
        actionMetric: '심사 경쟁률 우회 및 우선 배정'
      },
      {
        number: 3,
        title: '시설 도입 후 외주비 절감액과 영업이익 개선율을 수치로 제시',
        detail: '사업계획서에 "월 외주비 1,200만원 절감 ➔ 연간 영업이익 1억원 개선"으로 상환 능력을 숫자로 증명하니 심사관이 즉시 승인 결정을 내렸습니다.',
        highlightTag: '#외주비절감소명 #상환능력수치화',
        actionMetric: '영업이익률 11% ➔ 21%로 2배 개선'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-mfg-hwaseong-1',
        category: 'LIMIT_RATE',
        categoryLabel: '한도·금리 혜택',
        question: '중진공 시설자금의 대출 상환 기간과 거치 기간은 어떻게 되나요?',
        aiSummaryAnswer: '시설자금은 최장 8년(거치기간 3년 포함) 또는 10년 장기 분할상환 조건으로 지원됩니다. 초기 3년 동안은 이자만 납입하므로 공장 설비 가동 초기 현금 흐름 부담이 전혀 없습니다.',
        keyTakeaway: '📌 핵심: 최장 8년 상환 + 초기 3년 거치(이자만 납부)로 초기 자금 부담 제로',
        confidenceScore: 99,
        verifiedAgency: '중소벤처기업진흥공단 (KOSME)'
      },
      {
        id: 'faq-mfg-hwaseong-2',
        category: 'DOCS',
        categoryLabel: '필수 서류·소명',
        question: '기계 도입 전 계약금을 먼저 지급했어도 시설자금 융자가 가능한가요?',
        aiSummaryAnswer: '네, 가능합니다. 설비 매매 계약서 및 계약금 이체 영수증을 제출하면 잔금 결제용으로 시설자금이 정상 집행되며, 사후에 세금계산서와 설비 설치 현장 사진만 제출하면 됩니다.',
        keyTakeaway: '📌 핵심: 계약금 선지급 영수증 제출 시 잔금 전액 시설자금 집행 가능',
        confidenceScore: 96,
        verifiedAgency: '중진공 심사팀'
      }
    ]
  },
  // 6. 경기 수원시 - 외식/치킨전문
  {
    id: 'story-food-suwon',
    industryCategory: 'FOOD',
    industryLabel: '외식/프랜차이즈/식당',
    iconName: 'Coffee',
    ownerName: '배** 대표님',
    businessName: '경기 수원시 팔달구 통닭거리 S치킨',
    location: '경기 수원시',
    province: '경기',
    district: '수원시',
    businessAge: '업력 4년차',
    annualRevenue: '연 매출 4.5억원',
    fundingNeedType: 'DIGITAL_TRANSFORM',
    fundingNeedLabel: '자동 조리 로봇 및 스마트 오더 구축',
    fundName: '스마트상점 보급 및 디지털 혁신자금',
    agency: '소상공인시장진흥공단',
    approvedAmount: '6,000만원',
    approvedAmountNumber: 60000000,
    rateReduction: '2.5% (스마트화 특별금리)',
    annualSavings: '월 인건비 280만원 절약',
    revenueGrowth: '주말 웨이팅 회전율 45% 증가',
    keySuccessFactor: '스마트상점 선정 증빙 + 주방 조리 자동화 위험도 개선 계획',
    beforeSituation: '주방 기름 열기와 고강도 조리 작업으로 조리 직원을 구하기 힘들어 주말 피크 타임에 주문을 절반밖에 소화하지 못했습니다.',
    growthStory: '자동 튀김 로봇 2대와 키오스크 4대를 설치하여 1인 운영 체계를 완성하고 하루 300마리 조리를 거뜬히 소화하고 있습니다.',
    testimonial: '기술 도입 보조금과 정책 저리 대출을 동시에 설계해 준 BizMatch 덕분에 적은 자부담으로 매장을 전자동화했습니다.',
    rating: 5,
    date: '2026년 1월 승인',
    badge: '인건비 연 3,300만 절감',
    growthTimeline: [
      { stage: '1단계: 자동화 구축', description: '튀김 로봇 2대 & 키오스크 도입' },
      { stage: '2단계: 안전성 확보', description: '주방 화상 위험 0건 달성' },
      { stage: '3단계: 일 매출 신기록', description: '주말 일 매출 400만원 돌파' }
    ],
    applicationTip: '외식업 대표님은 단순 인테리어보다 스마트 조리기기나 주문 시스템을 명시하면 스마트 정책자금 승인률이 대폭 올라갑니다.',
    founderAdvice: [
      {
        number: 1,
        title: '정부 보조금(최대 70% 지원)과 정책자금 대출을 패키지로 동시 공략',
        detail: '스마트상점 기술보급 사업(무상 보조금 최대 1,000~1,500만원)과 스마트 저리 정책융자(2.5%)를 동시 매칭하면 실질 자부담금 거의 없이 로봇/키오스크를 설치할 수 있습니다.',
        highlightTag: '#보조금융자패키지 #실자부담최소화',
        actionMetric: '설치비 70% 국비 지원 연계'
      },
      {
        number: 2,
        title: '단순 리모델링이 아닌 "주방 구인난 해소 및 근로환경 개선"으로 소명',
        detail: '신청서 작성 시 "인테리어 변경" 대신 "고열 조리 환경 개선 및 화상 안전사고 예방"을 강조했더니 심사위원들의 압도적인 고득점을 받았습니다.',
        highlightTag: '#근로환경개선소명 #심사위원고득점',
        actionMetric: '주방 안전사고 0건 달성'
      },
      {
        number: 3,
        title: '테이블 회전율 향상으로 인한 일 매출 증가 지표를 명확히 제시',
        detail: '키오스크와 자동 조리 로봇 도입 후 주문 대기시간 15분 ➔ 5분 단축 계획을 수치로 적어 정책자금 상환 안정성을 입증했습니다.',
        highlightTag: '#회전율수치제시 #상환안정성입증',
        actionMetric: '주말 웨이팅 회전율 +45% 향상'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-food-suwon-1',
        category: 'STRATEGY',
        categoryLabel: '실전 전략',
        question: '스마트상점 기술보급 보조금과 정책자금 융자를 둘 다 동시에 받을 수 있나요?',
        aiSummaryAnswer: '네, 가능합니다. 중소벤처기업부 스마트상점 기술보급 사업(보조금 지원)에 선정된 소상공인은 자부담금 충당 및 운영자금 용도로 소진공 스마트 혁신자금(연 2.5% 고정/변동)을 연계 신청할 수 있어 최적의 조합입니다.',
        keyTakeaway: '📌 핵심: 보조금(무상 지원) + 저리 융자(2.5%) 중복 수혜 가능',
        confidenceScore: 98,
        verifiedAgency: '소상공인시장진흥공단 (SEMAS)'
      },
      {
        id: 'faq-food-suwon-2',
        category: 'PERIOD',
        categoryLabel: '심사 기간·승인',
        question: '스마트상점 지원금 신청 후 기기 설치 및 검수까지 얼마나 걸리나요?',
        aiSummaryAnswer: '공고 접수 후 선정 평가에 약 3주, 제휴 공급기업 기기 설치에 1~2주, 현장 검수 후 정책자금 입금까지 총 4~6주 내에 모든 공정이 완료됩니다.',
        keyTakeaway: '📌 핵심: 접수부터 설치 완료까지 평균 1개월 내외 소요',
        confidenceScore: 95,
        verifiedAgency: '스마트상점 기술보급단'
      }
    ]
  },
  // 7. 인천 남동구 - 제조/정밀가공
  {
    id: 'story-manufacturing-1',
    industryCategory: 'MANUFACTURING',
    industryLabel: '제조/뿌리산업/부품',
    iconName: 'Factory',
    ownerName: '박** 대표님',
    businessName: '인천 남동공단 N정밀가공',
    location: '인천 남동구',
    province: '인천',
    district: '남동구',
    businessAge: '업력 6년차',
    annualRevenue: '연 매출 8.5억원',
    fundingNeedType: 'FACILITY_EXPANSION',
    fundingNeedLabel: '스마트 가공 설비 도입',
    fundName: '제조 소상공인 성장촉진 특별자금',
    agency: '중소벤처기업진흥공단',
    approvedAmount: '2.5억원',
    approvedAmountNumber: 250000000,
    rateReduction: '6.5% → 2.9% (-3.6%p)',
    annualSavings: '연간 약 900만원 금융비용 절감',
    revenueGrowth: '생산 수율 40% 향상',
    keySuccessFactor: '스마트공장 보급 사업 연계 가점 + 뿌리기업 확인서 보유 우대',
    beforeSituation: '노후된 CNC 밀링 가공기 교체와 신규 자동화 라인 증설이 필요했으나, 고금리 시기라 금융비용 부담으로 1년 넘게 투자를 보류 중이었습니다.',
    growthStory: '성장촉진 시설자금 2.5억원을 5년 거치 5년 분할상환 조건으로 조달하여 최신 5축 머시닝 센터 2대를 도입했습니다.',
    testimonial: '공고문이 50페이지가 넘어 포기하려 했는데, AI가 설비자금 필수 서류와 공략 포인트를 요약해 주어 일사천리로 승인받았습니다.',
    rating: 5,
    date: '2026년 2월 승인',
    badge: '시설 자금 2.5억원 유치',
    growthTimeline: [
      { stage: '1단계: 시설 투자', description: '5축 가공기 2대 도입 및 공정 자동화' },
      { stage: '2단계: 불량률 감소', description: '기존 4.2% 불량률을 0.3%로 획기적 절감' },
      { stage: '3단계: 대기업 납품', description: '1차 벤더사 신규 정밀 부품 공급사 등록' }
    ],
    applicationTip: '설비 견적서와 도입 후 예상 생산성 향상 지표를 수치화하여 제출하면 한도가 최대치로 승인됩니다.',
    founderAdvice: [
      {
        number: 1,
        title: '스마트공장 기초 수준확인서 발급으로 심사 가점 10점 획득',
        detail: '중소기업기술정보진흥원에서 무료로 발급해 주는 스마트공장 수준확인서를 첨부하면 중진공 및 보증재단 제조 특례에서 10점 가점을 받아 단번에 합격합니다.',
        highlightTag: '#스마트공장수준확인 #가점10점확보',
        actionMetric: '시설자금 2.5억원 최고 한도 승인'
      },
      {
        number: 2,
        title: '불량률 감소와 생산 수율 향상 지표를 전후 비교표로 작성',
        detail: '"불량률 4.2% ➔ 0.3% 감소, 월 가공능력 2,000개 ➔ 3,500개 증대" 등 명확한 생산성 개선표를 제출하면 기술성 평가 점수 만점을 받습니다.',
        highlightTag: '#생산성개선표작성 #수율40%향상',
        actionMetric: '제조 불량률 93% 감소 달성'
      },
      {
        number: 3,
        title: '거치기간 최장 5년을 선택해 초기 상환 부담을 제로로 만들 것',
        detail: '시설자금은 5년 거치 후 5년 분할상환이 가능합니다. 초기 5년 동안 이자(월 60만원대)만 내면서 신규 라인 매출을 안정화할 수 있었습니다.',
        highlightTag: '#5년거치기간활용 #초기원금부담0원',
        actionMetric: '월 금융비용 75만원 수준 유지'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-mfg-incheon-1',
        category: 'CREDIT',
        categoryLabel: '신용·부채 조건',
        question: '기존에 다른 정책자금 대출 1억원이 남아있는데도 2.5억 추가 시설자금이 나오나요?',
        aiSummaryAnswer: '네, 가능합니다. 시설자금은 담보 물건(도입 기계 설비 양도담보)과 장기 생산성 가치를 기반으로 심사하므로 기존 운전자금 대출이 있어도 한도가 별도로 산출됩니다.',
        keyTakeaway: '📌 핵심: 기존 운전자금 대출과 별개로 기계 양도담보로 추가 시설 한도 산출',
        confidenceScore: 97,
        verifiedAgency: '중소벤처기업진흥공단'
      },
      {
        id: 'faq-mfg-incheon-2',
        category: 'DOCS',
        categoryLabel: '필수 서류·소명',
        question: '수입 기계 장비의 경우 외화 견적서(USD/EUR)로도 접수가 가능한가요?',
        aiSummaryAnswer: '네, 가능합니다. 해외 수입 기계는 외화 견적서와 국내 공식 대리점의 원화 환산 견적서를 함께 첨부하면 환율 변동분을 고려하여 원화 기준으로 자금이 정상 승인됩니다.',
        keyTakeaway: '📌 핵심: 수입 설비는 공식 대리점 환산 견적서 첨부 시 100% 인정',
        confidenceScore: 96,
        verifiedAgency: '중진공 수출제조팀'
      }
    ]
  },
  // 8. 인천 부평구 - 서비스/뷰티아카데미
  {
    id: 'story-service-incheon',
    industryCategory: 'SERVICE',
    industryLabel: '전문서비스/뷰티/교육',
    iconName: 'Briefcase',
    ownerName: '송** 대표님',
    businessName: '인천 부평구 B뷰티아트스쿨',
    location: '인천 부평구',
    province: '인천',
    district: '부평구',
    businessAge: '업력 3년차',
    annualRevenue: '연 매출 2.9억원',
    fundingNeedType: 'FACILITY_EXPANSION',
    fundingNeedLabel: '실습 강의실 확장 및 국가자격증 시설 인증',
    fundName: '인천신용보증재단 뷰티서비스 특례보증',
    agency: '인천신용보증재단',
    approvedAmount: '5,000만원',
    approvedAmountNumber: 50000000,
    rateReduction: '3.1% (인천시 우대금리)',
    annualSavings: '월 이자 13만원 부담',
    revenueGrowth: '수강생 정원 40명 증원',
    keySuccessFactor: '여성기업 확인서 가점 5점 + 인천 청년 일자리 채용 서약',
    beforeSituation: '미용 국가자격증 실기 시험장 규격에 맞추기 위한 방음 실습실 인테리어 비용 5천만원이 부족했습니다.',
    growthStory: '인천신보 특례자금으로 공식 인증 시험장 규격을 갖추고 인천지역 자격증 취득률 1위를 달성했습니다.',
    testimonial: '여성기업 가점과 지역 청년 고용 가점을 활용하라는 AI 안내 덕분에 심사 점수 만점으로 단번에 통과했습니다.',
    rating: 5,
    date: '2026년 1월 승인',
    badge: '인천 여성기업 특례 승인',
    growthTimeline: [
      { stage: '1단계: 가점 인증 확보', description: '여성기업 확인서 발급' },
      { stage: '2단계: 시설 리모델링', description: '국가공인 실기 규격 실습실 완공' },
      { stage: '3단계: 수강생 2배 달성', description: '월 수강생 120명 돌파' }
    ],
    applicationTip: '여성 대표자 또는 청년 대표자는 관련 확인서를 먼저 발급받으면 보증 한도와 승인율이 2배로 높아집니다.',
    founderAdvice: [
      {
        number: 1,
        title: '여성기업 확인서는 공공구매종합정보망(SMPP)에서 무료 즉시 발급받을 것',
        detail: '여성 대표자라면 신청 전 여성기업 확인서를 무조건 발급받으세요. 지자체 보증 심사에서 가산점 5점과 함께 보증료 0.2%p 추가 감면 혜택이 주어집니다.',
        highlightTag: '#여성기업확인서 #보증료감면혜택',
        actionMetric: '가산점 +5점 & 보증료 0.2%p 인하'
      },
      {
        number: 2,
        title: '지역 청년 강사 신규 채용 서약으로 고용우수 가점 확보',
        detail: '인천시 지역 청년 1명 이상 채용 확약서를 제출하여 고용창출 특례 트랙을 탔습니다. 일자리 창출 계획은 지자체 심사에서 가장 강력한 가산점입니다.',
        highlightTag: '#청년채용확약 #고용창출우대트랙',
        actionMetric: '수강생 정원 40명 추가 증원'
      },
      {
        number: 3,
        title: '공인 시험장 규격 인테리어 비교 견적서 2부 첨부',
        detail: '단순 학원 내부 수리가 아니라 "국가기술자격 실기시험장 공인 규격 시설 구축"으로 목적을 명확히 하고 인테리어 견적서를 제출해 5천만원 전액 승인을 받았습니다.',
        highlightTag: '#공인시설구축목적 #견적서소명완비',
        actionMetric: '5,000만원 신청액 전액 승인'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-service-incheon-1',
        category: 'DOCS',
        categoryLabel: '필수 서류·소명',
        question: '여성기업 확인서는 발급받는 데 며칠이나 걸리고 비용이 드나요?',
        aiSummaryAnswer: '여성기업 확인서는 중소벤처기업부 SMPP 사이트에서 100% 무료로 발급됩니다. 온라인 신청 후 3~5영업일 내 비대면 화상면담 또는 현장확인 후 즉시 발급됩니다.',
        keyTakeaway: '📌 핵심: 비용 0원, 온라인 신청 후 3~5일 내 즉시 발급 완료',
        confidenceScore: 99,
        verifiedAgency: '중소벤처기업부 & 여성기업협회'
      },
      {
        id: 'faq-service-incheon-2',
        category: 'LIMIT_RATE',
        categoryLabel: '한도·금리 혜택',
        question: '인천시 뷰티/서비스 특례보증의 최대 지원 한도와 금리는 얼마인가요?',
        aiSummaryAnswer: '인천신보 뷰티서비스 특례는 최대 5,000만원~1억원 한도로, 인천시 이차보전 연계 시 연 2.8~3.2% 수준의 저금리로 지원됩니다.',
        keyTakeaway: '📌 핵심: 최대 5,000만원~1억원 한도, 3% 초반 우대금리 적용',
        confidenceScore: 96,
        verifiedAgency: '인천신용보증재단'
      }
    ]
  },
  // 9. 부산 해운대구 - 도소매/패션
  {
    id: 'story-retail-1',
    industryCategory: 'RETAIL',
    industryLabel: '도소매/이커머스/유통',
    iconName: 'ShoppingBag',
    ownerName: '최** 대표님',
    businessName: '부산 해운대구 M패션 유통',
    location: '부산 해운대구',
    province: '부산',
    district: '해운대구',
    businessAge: '업력 4년차',
    annualRevenue: '연 매출 3.4억원',
    fundingNeedType: 'WORKING_CAPITAL',
    fundingNeedLabel: '시즌 재고 선매입 운전자금',
    fundName: '소상공인 희망리턴 재도약 자금',
    agency: '신용보증재단중앙회',
    approvedAmount: '4,500만원',
    approvedAmountNumber: 45000000,
    rateReduction: '3.1% (고정 우대금리)',
    annualSavings: '월 이자 부담 11만원 수준',
    revenueGrowth: '성수기 품절 방지로 매출 +35%',
    keySuccessFactor: '소상공인 지식배움터 무료 온라인 교육 5시간 이수 가점 5점 획득',
    beforeSituation: '전년도 경기 둔화로 일시적 매출 부진을 겪으며 신용점수가 720점대로 하락해 시중은행 대출 문턱이 높아진 상태였습니다.',
    growthStory: '소상공인 교육 가점을 통해 감점을 상쇄하고 4,500만원을 확보하여 봄/여름 신상품 재고를 원활히 확보했습니다.',
    testimonial: '신용점수가 떨어져 막막했는데, AI가 가점을 메울 수 있는 무료 교육 과정을 안내해 주었습니다. 온라인 강의 5시간 듣고 승인을 받아냈습니다!',
    rating: 5,
    date: '2026년 1월 승인',
    badge: '신용 열위 극복 승인',
    growthTimeline: [
      { stage: '1단계: 가점 보완', description: '소상공인 온라인 경영개선 교육 수료' },
      { stage: '2단계: 사입 자금 확보', description: '단가 15% 저렴하게 시즌 물량 대량 발주' },
      { stage: '3단계: 마진율 개선', description: '온라인 오픈마켓 베스트셀러 1위 달성' }
    ],
    applicationTip: '신용점수가 700점대라도 소진공 교육 이수증, 제로페이 가맹 실적 등 비금융 가점을 챙기면 승인율이 90% 이상으로 올라갑니다.',
    founderAdvice: [
      {
        number: 1,
        title: '신용점수가 700점대라면 소상공인 무료 온라인 교육 이수증을 챙길 것',
        detail: '소상공인마당(소진공) 지식배움터에서 무료 온라인 경영 교육 5시간을 이수하고 수료증을 첨부하면 심사 가산점 5점을 받아 신용점수 부족을 완벽히 상쇄합니다.',
        highlightTag: '#소진공무료교육이수 #비금융가점5점',
        actionMetric: '신용 720점 극복 & 4,500만원 승인'
      },
      {
        number: 2,
        title: '온라인 오픈마켓 매출 정산 내역 및 주문 성장 추이 제출',
        detail: '국세청 부가세 자료 외에 쿠팡/스마트스토어 관리자 화면의 최근 3개월 결제건수 증가 캡처본을 제출하여 사업의 실시간 성장세를 입증했습니다.',
        highlightTag: '#오픈마켓정산서소명 #실시간성장입증',
        actionMetric: '매출 성장률 +35% 실적 증빙'
      },
      {
        number: 3,
        title: '사입 단가 인하로 인한 마진율 개선 계획을 수치로 명시',
        detail: '"선매입 자금 확보 시 사입단가 15% 인하 ➔ 영업마진 22%로 개선"을 보여주어 정책자금 상환 가능성에 대한 심사역의 우려를 불식시켰습니다.',
        highlightTag: '#사입단가절감 #마진율개선소명',
        actionMetric: '대량 발주로 원가 15% 절감'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-retail-1-1',
        category: 'CREDIT',
        categoryLabel: '신용·부채 조건',
        question: 'NICE 신용점수가 720점인데 희망리턴 재도약 자금 신청이 가능한가요?',
        aiSummaryAnswer: '네, 가능합니다. 희망리턴 재도약 자금은 신용점수가 하락한 성실 소상공인을 지원하기 위해 특화된 자금으로, 신용점수 700점 초반대 소상공인을 우선 대상으로 설계되어 있습니다.',
        keyTakeaway: '📌 핵심: 신용 700점대 소상공인 전용 트랙으로 감점 없이 승인 가능',
        confidenceScore: 98,
        verifiedAgency: '신용보증재단중앙회'
      },
      {
        id: 'faq-retail-1-2',
        category: 'DOCS',
        categoryLabel: '필수 서류·소명',
        question: '소진공 온라인 교육 수료증은 어떻게 발급받아 제출하나요?',
        aiSummaryAnswer: '소상공인 지식배움터(edu.sbiz.or.kr) 회원가입 후 무료 온라인 경영 교육(5~10시간)을 수강하면 즉시 PDF 수료증이 발급되며, 이를 온라인 접수 시 첨부하시면 가점 5점이 자동 반영됩니다.',
        keyTakeaway: '📌 핵심: 100% 무료 온라인 수강 즉시 PDF 수료증 발급 가능',
        confidenceScore: 99,
        verifiedAgency: '소상공인시장진흥공단'
      }
    ]
  },
  // 10. 부산 부산진구 - 외식/수산F&B
  {
    id: 'story-food-busan',
    industryCategory: 'FOOD',
    industryLabel: '외식/해산물/전통F&B',
    iconName: 'Coffee',
    ownerName: '강** 대표님',
    businessName: '부산 부산진구 서면 B해물요리',
    location: '부산 부산진구',
    province: '부산',
    district: '부산진구',
    businessAge: '업력 5년차',
    annualRevenue: '연 매출 4.8억원',
    fundingNeedType: 'DEBT_REFINANCE',
    fundingNeedLabel: '2금융권 고금리 대환 및 밀키트 개발',
    fundName: '부산신용보증재단 소상공인 이차보전 협약자금',
    agency: '부산신용보증재단',
    approvedAmount: '7,000만원',
    approvedAmountNumber: 70000000,
    rateReduction: '10.5% → 2.8% (-7.7%p)',
    annualSavings: '연간 약 540만원 이자 절감',
    revenueGrowth: '온라인 밀키트 월 매출 1,500만원 추가',
    keySuccessFactor: '부산시 2.5%p 이자 차액 보전 매칭 + 수산물 이력제 인증 가점',
    beforeSituation: '제2금융권 캐피탈 대출 3천만원의 10%대 고금리 이자로 매달 50만원 이상이 빠져나가 신메뉴 R&D를 진행하지 못했습니다.',
    growthStory: '7천만원을 2.8%로 대환하고 남은 자금으로 해물탕 급속 냉동 밀키트 라인을 런칭하여 전국 택배 판매를 시작했습니다.',
    testimonial: '이자 부담이 1/4로 줄어든 것만으로도 숨통이 트였는데, 밀키트 신사업까지 안착하여 매장 매출을 뛰어넘었습니다.',
    rating: 5,
    date: '2026년 2월 승인',
    badge: '금리 -7.7%p & 신사업 성공',
    growthTimeline: [
      { stage: '1단계: 고금리 대환', description: '부산신보 2.8% 저리 자금 조달' },
      { stage: '2단계: 밀키트 제조', description: 'HACCP 위생 포장 설비 구축' },
      { stage: '3단계: 전국 유통', description: '네이버 스마트스토어 평점 4.9점 달성' }
    ],
    applicationTip: '지자체별 이차보전 자금은 시중은행과 연계되어 조기 소진되므로 은행 지점 방문 전 보증서를 먼저 온라인 신청하세요.',
    founderAdvice: [
      {
        number: 1,
        title: '지자체 이차보전 자금은 은행 창구 가기 전 신보 보증서부터 먼저 신청',
        detail: '은행 지점에 먼저 가면 일반 대출을 권하지만, 부산신보 모바일로 이차보전 연계 보증서를 먼저 받아 은행에 제출하면 최저 2.8% 금리로 일사천리 진행됩니다.',
        highlightTag: '#신보보증서선발급 #최저금리2.8%',
        actionMetric: '연간 이자 540만원 절감 달성'
      },
      {
        number: 2,
        title: '대환과 동시에 신규 사업 운전자금을 한도 내에서 한 번에 묶어 신청',
        detail: '기존 대환 3천만원만 신청하지 않고, 밀키트 신사업 운전자금 4천만원을 합쳐 7천만원 한도로 일괄 신청해 심사 수수료와 시간을 아꼈습니다.',
        highlightTag: '#대환운전자금일괄신청 #7000만원승인',
        actionMetric: '7,000만원 100% 통합 승인'
      },
      {
        number: 3,
        title: '지역 특산물 인증(수산물이력제 등)으로 로컬 우대 가점 확보',
        detail: '부산 자갈치 산지 직송 수산물 이력제 등록증을 제출해 부산시 로컬 우대 가점을 받아 감액 없이 7천만원 전액을 승인받았습니다.',
        highlightTag: '#로컬수산물이력제 #지역특화가점',
        actionMetric: '밀키트 월 매출 +1,500만원 추가'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-food-busan-1',
        category: 'LIMIT_RATE',
        categoryLabel: '한도·금리 혜택',
        question: '부산시 이차보전 자금의 이자 지원율(2.5%p)은 몇 년간 유지되나요?',
        aiSummaryAnswer: '부산광역시 소상공인 협약 이차보전은 통상 대출 실행일로부터 최대 3~5년간 2.0~2.5%p 이자를 시에서 보전해 줍니다. 대표님 실부담 금리는 2%대 후반으로 고정/변동 적용됩니다.',
        keyTakeaway: '📌 핵심: 부산시가 최장 5년간 연 2.5%p 이자 대납 지원',
        confidenceScore: 98,
        verifiedAgency: '부산신용보증재단 & 부산광역시'
      },
      {
        id: 'faq-food-busan-2',
        category: 'CREDIT',
        categoryLabel: '신용·부채 조건',
        question: '캐피탈과 저축은행 대출을 정책자금 1건으로 묶어서 대환할 수 있나요?',
        aiSummaryAnswer: '네, 가능합니다. 여러 금융기관에 흩어져 있는 2금융권 고금리 대출을 부산신보 보증서 1건으로 통합하여 1금융권 시중은행(부산은행 등)에서 2%대 단일 대출로 묶어 대환합니다.',
        keyTakeaway: '📌 핵심: 다중 2금융 채무를 1금융권 2%대 단일 계좌로 통합 대환',
        confidenceScore: 97,
        verifiedAgency: '부산신보 & BNK부산은행'
      }
    ]
  },
  // 11. 대구 수성구 - 외식/한우전문
  {
    id: 'story-food-2',
    industryCategory: 'FOOD',
    industryLabel: '외식/프랜차이즈/식당',
    iconName: 'Coffee',
    ownerName: '한** 대표님',
    businessName: '대구 수성구 H한우 전문점',
    location: '대구 수성구',
    province: '대구',
    district: '수성구',
    businessAge: '업력 4년차',
    annualRevenue: '연 매출 5.8억원',
    fundingNeedType: 'DIGITAL_TRANSFORM',
    fundingNeedLabel: '테이블 오더 및 스마트 주방 로봇',
    fundName: '스마트상점 보급 및 기술보급 자금',
    agency: '소상공인시장진흥공단',
    approvedAmount: '7,000만원',
    approvedAmountNumber: 70000000,
    rateReduction: '2.5% (스마트화 특별 우대)',
    annualSavings: '인건비 연 2,400만원 절감',
    revenueGrowth: '테이블 회전율 35% 향상',
    keySuccessFactor: '스마트상점 기술보급 사업 선정 이력 연계 지원',
    beforeSituation: '구인난으로 홀 서빙 인력이 부족하여 피크 타임에 손님을 다 받지 못해 매출 손실이 지속되던 상태였습니다.',
    growthStory: '테이블오더 22대와 서빙 로봇 2대를 도입하여 인건비를 획기적으로 줄이고 테이블 회전율을 1.5배 끌어올렸습니다.',
    testimonial: '정책자금뿐 아니라 스마트화 보조금까지 연계해 주어 실부담금 거의 없이 최신 디지털 매장으로 리뉴얼했습니다.',
    rating: 5,
    date: '2026년 2월 승인',
    badge: '인건비 2,400만 절감',
    growthTimeline: [
      { stage: '1단계: 스마트 기술 도입', description: '테이블오더 + 서빙 로봇 2대 셋팅' },
      { stage: '2단계: 운영 효율화', description: '주문 누락 0건 & 서빙 대기시간 60% 단축' },
      { stage: '3단계: 순이익률 급증', description: '영업이익률 14% → 23%로 개선' }
    ],
    applicationTip: '스마트 오더 및 결제 시스템 도입은 정부의 디지털 소상공인 육성 정책과 완벽히 부합하여 승인율이 가장 높습니다.',
    founderAdvice: [
      {
        number: 1,
        title: '서빙로봇·테이블오더는 "구인난 해결 및 인건비 절감 계획"을 수치로 소명',
        detail: '홀 서빙 인력 2명 인건비 월 500만원 절감액과 로봇 렌탈/구입비용을 비교한 손익계산서를 첨부하면 심사역이 100% 공감하여 원안 승인합니다.',
        highlightTag: '#인건비절감손익표 #구인난소명',
        actionMetric: '연 인건비 2,400만원 순절감'
      },
      {
        number: 2,
        title: '대구시 스마트상점 보급기업 공식 파트너사 견적서 활용',
        detail: '소진공 공식 인증을 받은 스마트기기 공급업체의 비교 견적서를 제출하면 장비 신뢰도 검증 절차가 생략되어 승인 기간이 1주일 단축됩니다.',
        highlightTag: '#공식인증기기공급사 #검수기간단축',
        actionMetric: '심사 기간 1주일 단축'
      },
      {
        number: 3,
        title: "음식점 위생등급제 '매우 우수' 인증 가점을 사전 확보",
        detail: '식약처 위생등급제 별 3개(매우 우수) 인증을 미리 받아두었더니 지자체 및 소진공 자금 심사에서 최고 가점 5점을 거저 얻었습니다.',
        highlightTag: '#위생등급제매우우수 #심사가점5점',
        actionMetric: '테이블 회전율 +35% 향상'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-food2-1',
        category: 'STRATEGY',
        categoryLabel: '실전 전략',
        question: '서빙 로봇 렌탈료도 스마트상점 정책자금으로 지출할 수 있나요?',
        aiSummaryAnswer: '네, 가능합니다. 일시불 기기 구매뿐 아니라 24~36개월 로봇 렌탈료 선납 또는 약정 리스료 지출 목적으로도 스마트 혁신자금 융자가 정상 인정됩니다.',
        keyTakeaway: '📌 핵심: 기기 구매 및 렌탈 리스료 모두 정책자금 집행 대상',
        confidenceScore: 98,
        verifiedAgency: '소상공인시장진흥공단'
      },
      {
        id: 'faq-food2-2',
        category: 'LIMIT_RATE',
        categoryLabel: '한도·금리 혜택',
        question: '스마트상점 특별 우대금리 2.5%는 고정금리인가요 변동금리인가요?',
        aiSummaryAnswer: '소진공 정책자금 기준금리 연동 변동금리 또는 협약 고정금리 중 선택 가능하며, 분기별 스마트 우대금리(-0.4~0.8%p)가 차감되어 2%대 중반이 안정적으로 유지됩니다.',
        keyTakeaway: '📌 핵심: 스마트 우대 감면으로 2%대 중반 초저금리 유지',
        confidenceScore: 96,
        verifiedAgency: 'SEMAS 자금운용본부'
      }
    ]
  },
  // 12. 대구 달서구 - 제조/기계부품
  {
    id: 'story-mfg-daegu',
    industryCategory: 'MANUFACTURING',
    industryLabel: '제조/기계·장비 가공',
    iconName: 'Factory',
    ownerName: '문** 대표님',
    businessName: '대구 달서구 성서공단 D정공',
    location: '대구 달서구',
    province: '대구',
    district: '달서구',
    businessAge: '업력 7년차',
    annualRevenue: '연 매출 7.6억원',
    fundingNeedType: 'FACILITY_EXPANSION',
    fundingNeedLabel: '고정밀 레이저 절단기 도입',
    fundName: '대구신용보증재단 뿌리산업 육성자금',
    agency: '대구신용보증재단',
    approvedAmount: '1.8억원',
    approvedAmountNumber: 180000000,
    rateReduction: '3.0% (대구시 협약 우대)',
    annualSavings: '월 이자 45만원 수준 고정',
    revenueGrowth: '납기일 7일 → 3일로 50% 단축',
    keySuccessFactor: '성서공단 뿌리기업 특례 100% 보증 + 에너지 절감형 장비 인증',
    beforeSituation: '외주 레이저 가공 업체의 잦은 납기 지연으로 거래처 클레임이 빈번해 직접 절단기를 도입해야 했습니다.',
    growthStory: '대구신보 1.8억원 융자로 최신 광섬유 레이저기를 설치하여 당일 가공 당일 출하 체제를 완성했습니다.',
    testimonial: '대구시 뿌리산업 특례 트랙을 AI가 매칭해 준 덕분에 심사 대기 없이 1주일 만에 실행되었습니다.',
    rating: 5,
    date: '2026년 1월 승인',
    badge: '납기 50% 단축 달성',
    growthTimeline: [
      { stage: '1단계: 보증서 발급', description: '대구신보 뿌리산업 특례 확정' },
      { stage: '2단계: 레이저기 가동', description: '자체 24시간 가공 라인 구축' },
      { stage: '3단계: 신규 수주 폭증', description: '경북/대구 20여 개 신규 거래처 확보' }
    ],
    applicationTip: '공단 입주 기업은 산업단지 관리공단 추천서나 입주 확인서를 첨부하면 가산점 5점을 획득합니다.',
    founderAdvice: [
      {
        number: 1,
        title: '산업단지 관리공단 입주확인서 및 지자체 추천서를 챙길 것',
        detail: '성서공단, 남동공단 등 정식 산단 입주 기업은 관리공단 추천서를 첨부하면 지자체 특례보증 쿼터가 1순위로 배정되어 심사 기간이 절반으로 줄어듭니다.',
        highlightTag: '#산단입주추천서 #1순위배정',
        actionMetric: '1주일 만에 1.8억원 보증 실행'
      },
      {
        number: 2,
        title: '에너지 절감형 친환경 고효율 장비 인증서 첨부로 금리 우대',
        detail: '도입 장비가 에너지 소비효율 1등급이거나 인버터 절전형이면 탄소중립/친환경 제조 가점이 추가되어 금리가 0.3%p 추가 인하됩니다.',
        highlightTag: '#친환경장비인증 #탄소중립가점',
        actionMetric: '금리 연 3.0% 고정 확정'
      },
      {
        number: 3,
        title: '납기 단축으로 인한 거래처 수주 확약서(LOI)를 함께 제출',
        detail: '장비 도입 시 신규 발주를 약속한 협력업체 3곳의 구매의향서(LOI)를 첨부해 투자금 회수의 확실성을 보여준 것이 결정적이었습니다.',
        highlightTag: '#구매의향서LOI #수주확실성소명',
        actionMetric: '신규 거래처 20곳 확장'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-mfg-daegu-1',
        category: 'DOCS',
        categoryLabel: '필수 서류·소명',
        question: '산업단지 관리공단 추천서는 어디서 어떻게 발급받나요?',
        aiSummaryAnswer: '해당 산업단지 관리공단(성서산업단지관리공단 등) 홈페이지 또는 기업지원과 방문을 통해 입주확인서와 정책자금 연계 추천서를 당일 무료로 발급받을 수 있습니다.',
        keyTakeaway: '📌 핵심: 산단 관리공단 기업지원과에서 당일 무료 발급',
        confidenceScore: 99,
        verifiedAgency: '산업단지관리공단 & 대구신보'
      },
      {
        id: 'faq-mfg-daegu-2',
        category: 'LIMIT_RATE',
        categoryLabel: '한도·금리 혜택',
        question: '대구시 뿌리기업 특례보증의 최대 보증 한도는 얼마인가요?',
        aiSummaryAnswer: '대구신보 뿌리산업 특례는 일반 소상공인 한도(5천만원~1억원)를 뛰어넘어 기업당 최대 2억원~3억원까지 100% 전액 보증서로 발급됩니다.',
        keyTakeaway: '📌 핵심: 뿌리기업 특례 적용 시 최대 2~3억원까지 대폭 확대',
        confidenceScore: 97,
        verifiedAgency: '대구신용보증재단'
      }
    ]
  },
  // 13. 대전 유성구 - 전문서비스/교육
  {
    id: 'story-service-1',
    industryCategory: 'SERVICE',
    industryLabel: '전문서비스/교육/뷰티',
    iconName: 'Briefcase',
    ownerName: '정** 대표님',
    businessName: '대전 유성구 T전문 입시어학원',
    location: '대전 유성구',
    province: '대전',
    district: '유성구',
    businessAge: '업력 5년차',
    annualRevenue: '연 매출 3.1억원',
    fundingNeedType: 'FACILITY_EXPANSION',
    fundingNeedLabel: '2호관 확장 인테리어 & 디지털 칠판 도입',
    fundName: '서비스업 혁신성장자금',
    agency: '대전신용보증재단',
    approvedAmount: '6,000만원',
    approvedAmountNumber: 60000000,
    rateReduction: '3.3% (우대금리)',
    annualSavings: '월 이자 비용 60% 절약',
    revenueGrowth: '수강생 정원 80명 → 140명 확장',
    keySuccessFactor: '청년 고용 창출 계획서 제출로 고용우수 가점 10점 획득',
    beforeSituation: '대기 수강생이 늘어 강의실 확장이 급선무였으나 임대보증금과 인테리어 비용 6천만원이 부족했습니다.',
    growthStory: '대전신보 특례자금으로 2호관을 오픈하고 청년 강사 2명을 신규 채용하여 분원 개원을 성공시켰습니다.',
    testimonial: '고용 우대 가점을 활용하라는 AI 분석 리포트 덕분에 까다로운 서류 심사도 단번에 통과할 수 있었습니다.',
    rating: 5,
    date: '2026년 2월 승인',
    badge: '강의실 확장 2호점 개원',
    growthTimeline: [
      { stage: '1단계: 고용 우대 승인', description: '청년 인재 채용 연계 가점 확보' },
      { stage: '2단계: 분원 인테리어', description: '스마트 강의실 4개실 신규 증설' },
      { stage: '3단계: 매출 2배 도약', description: '월 수강료 매출 2,500만원 돌파' }
    ],
    applicationTip: '직원 1명 이상 신규 채용 계획이 있다면 고용보험 가입 예정 증빙을 첨부하여 고용창출 특례 트랙을 노려보세요.',
    founderAdvice: [
      {
        number: 1,
        title: '신규 고용 계획서(청년 강사 채용)를 제출해 가점 10점 챙기기',
        detail: '확장 오픈 시 청년 강사 2명을 채용하겠다는 고용창출 확약서를 제출해 대전신보 심사 가점 10점을 확보했습니다. 고용 창출은 지자체 심사의 치트키입니다.',
        highlightTag: '#고용창출가점10점 #청년채용연계',
        actionMetric: '강사 2명 신규 채용 & 정원 140명 증원'
      },
      {
        number: 2,
        title: '스마트 전자칠판 및 하이브리드 강의 시스템 도입으로 혁신성 소명',
        detail: '단순 학원 책걸상이 아니라 "온·오프라인 하이브리드 강의 시스템 및 전자칠판 도입"으로 서비스 혁신성을 소명해 6,000만원 전액을 승인받았습니다.',
        highlightTag: '#에듀테크혁신성소명 #전자칠판도입',
        actionMetric: '6,000만원 100% 원안 승인'
      },
      {
        number: 3,
        title: '학원 프랜차이즈 상표권 및 자체 교재 저작권 등록증 제출',
        detail: '원장님이 직접 개발한 커리큘럼의 저작권 등록증을 첨부하여 일반 보습학원과의 차별성과 지속 가능한 경쟁력을 입증했습니다.',
        highlightTag: '#저작권등록증제출 #차별성입증',
        actionMetric: '월 매출 2,500만원 돌파'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-service-daejeon-1',
        category: 'DOCS',
        categoryLabel: '필수 서류·소명',
        question: '학원/교육서비스업도 정책자금 시설 및 운전자금 지원 대상이 되나요?',
        aiSummaryAnswer: '네, 대상이 됩니다. 과거 유흥/사행성 업종 외에 입시, 외국어, 직업훈련, 예체능 학원은 지자체 서비스업 혁신성장자금 및 고용창출 특례보증의 1순위 지원 대상입니다.',
        keyTakeaway: '📌 핵심: 교육/학원업은 서비스업 정책자금 정상 지원 대상',
        confidenceScore: 98,
        verifiedAgency: '대전신용보증재단'
      },
      {
        id: 'faq-service-daejeon-2',
        category: 'LIMIT_RATE',
        categoryLabel: '한도·금리 혜택',
        question: '대전시 이차보전 연계 시 실제 적용되는 대출 금리는 얼마인가요?',
        aiSummaryAnswer: '대전광역시 소상공인 경영개선자금 연계 시 대전시에서 연 2.0~3.0%p 이자를 지원하여 대표님 최종 부담 금리는 연 3.0~3.3% 수준으로 유지됩니다.',
        keyTakeaway: '📌 핵심: 대전시 이자 2~3%p 보전으로 3% 초반대 저금리',
        confidenceScore: 96,
        verifiedAgency: '대전광역시 기업지원과'
      }
    ]
  },
  // 14. 광주 북구 - IT/전자부품
  {
    id: 'story-gwangju-tech',
    industryCategory: 'TECH',
    industryLabel: 'IT/광산업/전자부품',
    iconName: 'Laptop',
    ownerName: '조** 대표님',
    businessName: '광주 북구 첨단산단 G포토닉스',
    location: '광주 북구',
    province: '광주',
    district: '북구',
    businessAge: '업력 3년차',
    annualRevenue: '연 매출 4.9억원',
    fundingNeedType: 'WORKING_CAPITAL',
    fundingNeedLabel: '광통신 센서 양산 원자재 매입',
    fundName: '광주신용보증재단 유망기업 육성자금',
    agency: '광주신용보증재단',
    approvedAmount: '1.0억원',
    approvedAmountNumber: 100000000,
    rateReduction: '2.9% (광주시 이차보전 연계)',
    annualSavings: '연간 520만원 금융비용 절약',
    revenueGrowth: '양산 납품으로 연 매출 +55%',
    keySuccessFactor: '광주 광융합 클러스터 입주기업 가점 + 산학협력 연구실적',
    beforeSituation: '연구개발 완료 후 대량 양산 오더를 받았으나 수입 특수 렌즈 원자재 구매 대금 1억원이 부족했습니다.',
    growthStory: '광주신보 1억원 보증 승인으로 원자재를 전액 결제하고 첫 대량 양산 납품을 성공리에 완수했습니다.',
    testimonial: '지역 특화 클러스터 입주 가점을 찾아준 AI 덕분에 무담보 100% 보증으로 2%대 자금을 확보했습니다.',
    rating: 5,
    date: '2026년 1월 승인',
    badge: '무담보 1억원 전액 승인',
    growthTimeline: [
      { stage: '1단계: 클러스터 가점 신청', description: '광주신보 기술보증 접수' },
      { stage: '2단계: 원자재 확보', description: '광학 렌즈 원자재 3천세트 발주' },
      { stage: '3단계: 양산 납품 완결', description: '통신사 1차 협력업체 공급 완료' }
    ],
    applicationTip: '지자체별 특화산업(광주 광학, 대전 바이오 등)에 해당할 경우 관련 진흥원 추천서를 첨부하면 승인율이 95%를 상회합니다.',
    founderAdvice: [
      {
        number: 1,
        title: '지자체 특화산업(광주 광융합·인공지능 등) 지정 기업 혜택 활용',
        detail: '광주시 주력 산업인 광융합/AI 관련 기업은 한국광기술원 또는 광주TP 추천서를 받으면 보증 한도가 1억원 이상으로 즉시 증액됩니다.',
        highlightTag: '#지역특화산업우대 #광주TP추천서',
        actionMetric: '무담보 1억원 100% 보증 승인'
      },
      {
        number: 2,
        title: '대기업/통신사 납품 발주서(PO)를 증빙하여 원자재 매입 소명',
        detail: '수주가 확정된 1차 벤더사 납품 발주서를 첨부하여 "자금 투입 즉시 납품 ➔ 60일 내 대금 회수" 구조를 명쾌하게 입증했습니다.',
        highlightTag: '#납품발주서PO소명 #대금회수구조확약',
        actionMetric: '연 매출 +55% 폭풍 성장'
      },
      {
        number: 3,
        title: '광주형 일자리 참여 기업 인증으로 추가 금리 0.5%p 감면',
        detail: '광주시 상생형 지역 일자리 참여 서약서를 작성해 광주시 이차보전 2.5%p에 추가 금리 혜택까지 받아 2.9% 최종 금리를 확정했습니다.',
        highlightTag: '#광주형일자리참여 #추가금리감면',
        actionMetric: '적용 금리 연 2.9% 확정'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-gwangju-1',
        category: 'STRATEGY',
        categoryLabel: '실전 전략',
        question: '광주 테크노파크나 진흥원 추천서는 어떻게 받아 제출하나요?',
        aiSummaryAnswer: '광주테크노파크(GJTP) 기업지원포털에서 온라인으로 유망 중소기업 추천서를 신청하면 사업자등록증 및 제품 소개서 검토 후 3~5영업일 내 추천서가 무료 발급됩니다.',
        keyTakeaway: '📌 핵심: TP 기업지원포털에서 온라인 신청 5일 내 발급',
        confidenceScore: 97,
        verifiedAgency: '광주테크노파크 & 광주신보'
      },
      {
        id: 'faq-gwangju-2',
        category: 'LIMIT_RATE',
        categoryLabel: '한도·금리 혜택',
        question: '광주신보 유망기업 육성자금의 보증료율은 얼마인가요?',
        aiSummaryAnswer: '특화산업 우대 기업의 경우 기본 보증료율(1.2%)에서 0.4%p 감면된 연 0.8% 내외의 저렴한 보증료율이 적용되어 수수료 부담이 매우 적습니다.',
        keyTakeaway: '📌 핵심: 특화 가점으로 보증료율 0.8% 우대 적용',
        confidenceScore: 95,
        verifiedAgency: '광주신용보증재단'
      }
    ]
  },
  // 15. 충남 천안시 - 제조/반도체장비부품
  {
    id: 'story-mfg-cheonan',
    industryCategory: 'MANUFACTURING',
    industryLabel: '제조/반도체 장비 부품',
    iconName: 'Factory',
    ownerName: '유** 대표님',
    businessName: '충남 천안시 서북구 C세미테크',
    location: '충남 천안시',
    province: '충남',
    district: '천안시',
    businessAge: '업력 4년차',
    annualRevenue: '연 매출 6.8억원',
    fundingNeedType: 'FACILITY_EXPANSION',
    fundingNeedLabel: '클린룸 증설 및 3차원 측정기 도입',
    fundName: '충남신용보증재단 중소기업 혁신자금',
    agency: '충남신용보증재단',
    approvedAmount: '1.5억원',
    approvedAmountNumber: 150000000,
    rateReduction: '3.0% (충남도 이차보전 2.0%p)',
    annualSavings: '월 이자 부담 37만원 수준',
    revenueGrowth: '품질 검사 합격률 99.8% 달성',
    keySuccessFactor: 'ISO9001 품질인증 + 스마트공장 수준확인서 가점',
    beforeSituation: '반도체 고객사의 고정밀 공정 요구로 클린룸 100클래스 환경 및 정밀 측정기 도입이 불가피했습니다.',
    growthStory: '충남신보 1.5억원을 조달하여 클린룸을 완공하고 고객사 품질 감사에서 최고 등급(S등급)을 획득했습니다.',
    testimonial: '충남도 2% 이자 보전 사업을 제때 신청할 수 있도록 알림을 준 AI 덕분에 큰돈 들이지 않고 최신 공장을 갖췄습니다.',
    rating: 5,
    date: '2026년 2월 승인',
    badge: '클린룸 1.5억 완공',
    growthTimeline: [
      { stage: '1단계: 충남신보 승인', description: '1.5억원 3.0% 조건 확정' },
      { stage: '2단계: 클린룸 시공', description: '항온항습 정밀 측정실 준공' },
      { stage: '3단계: 고객사 감사 통과', description: '연간 고정 장비 납품 계약 체결' }
    ],
    applicationTip: '품질 인증서(ISO 등)나 스마트공장 확인서는 지자체 중기자금 심사에서 1순위 우대 항목입니다.',
    founderAdvice: [
      {
        number: 1,
        title: 'ISO9001 품질인증서는 지자체 중기자금 심사의 필수 보증수표',
        detail: '제조기업은 ISO9001 인증서를 보유하고 있으면 기술신용평가(TCB) 및 보증재단 심사에서 별도의 복잡한 현장 실사 없이도 고득점을 받습니다.',
        highlightTag: '#ISO9001품질인증 #TCB고득점',
        actionMetric: '1.5억원 100% 전액 승인'
      },
      {
        number: 2,
        title: '고객사의 품질 감사(Audit) 요구 공문을 증빙 서류로 첨부',
        detail: '삼성/SK 협력 1차사의 "클린룸 규격 보완 요청 공문"을 제출해 시설 투자가 선택이 아닌 필수 생존 요건임을 심사관에게 완벽히 납득시켰습니다.',
        highlightTag: '#고객사감사공문제출 #필수투자소명',
        actionMetric: '고객사 품질평가 S등급 획득'
      },
      {
        number: 3,
        title: '충남도 이차보전 지원으로 연간 수백만원 이자 절감',
        detail: '충청남도 중소기업 육성자금 2.0%p 이자 지원을 받아 1.5억원 대출임에도 월 이자를 37만원 수준으로 방어해 자금 부담을 없앴습니다.',
        highlightTag: '#충남도이차보전 #월이자37만원',
        actionMetric: '품질 합격률 99.8% 달성'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-mfg-cheonan-1',
        category: 'DOCS',
        categoryLabel: '필수 서류·소명',
        question: '클린룸 공사 시설자금은 공사 업체에 직접 입금되나요, 제 통장으로 들어오나요?',
        aiSummaryAnswer: '지자체 시설자금은 시공업체의 공사 계약서 및 전자세금계산서 발행 내역에 따라 은행에서 시공업체 계좌로 직접 기성금 형태로 분할 송금되어 안전하게 집행됩니다.',
        keyTakeaway: '📌 핵심: 계약서 및 세금계산서에 따라 시공업체로 안전 분할 입금',
        confidenceScore: 98,
        verifiedAgency: '충남신보 & 협약은행'
      },
      {
        id: 'faq-mfg-cheonan-2',
        category: 'LIMIT_RATE',
        categoryLabel: '한도·금리 혜택',
        question: '충남신보 중소기업 혁신자금의 대출 만기와 상환 구조는 어떻게 되나요?',
        aiSummaryAnswer: '시설자금은 통상 2~3년 거치 후 5년 균등분할상환(총 7~8년)으로 운영되며, 충남도에서 2%p 이자를 직접 보전해 주어 3.0%대 저금리가 유지됩니다.',
        keyTakeaway: '📌 핵심: 2년 거치 5년 분할상환 + 충남도 이자 2%p 대납',
        confidenceScore: 96,
        verifiedAgency: '충남신용보증재단'
      }
    ]
  },
  // 16. 제주 제주시 - 외식/로컬디저트
  {
    id: 'story-food-jeju',
    industryCategory: 'FOOD',
    industryLabel: '외식/로컬디저트/F&B',
    iconName: 'Coffee',
    ownerName: '고** 대표님',
    businessName: '제주 제주시 애월읍 J감귤 베이커리',
    location: '제주 제주시',
    province: '제주',
    district: '제주시',
    businessAge: '업력 3년차',
    annualRevenue: '연 매출 3.5억원',
    fundingNeedType: 'WORKING_CAPITAL',
    fundingNeedLabel: '제주 특산물 로컬 디저트 패키징 & 선물세트 제작',
    fundName: '제주신용보증재단 로컬크리에이터 특례보증',
    agency: '제주신용보증재단',
    approvedAmount: '5,000만원',
    approvedAmountNumber: 50000000,
    rateReduction: '2.6% (제주도 관광진흥기금 연계)',
    annualSavings: '연간 320만원 이자 절감',
    revenueGrowth: '제주공항 면세점 입점 후 매출 +60%',
    keySuccessFactor: '제주산 친환경 감귤 원료 100% 사용 로컬크리에이터 인증 가점',
    beforeSituation: '관광객 입소문으로 주문이 폭주했으나 전용 냉장 포장 설비와 선물용 패키지 대량 인쇄 자금이 부족했습니다.',
    growthStory: '제주신보 특례 5천만원을 2.6%로 받아 고급 패키징을 완료하고 제주공항 기념품 샵 및 네이버 쇼핑 라이브 1위를 기록했습니다.',
    testimonial: '제주 지역만의 로컬 특례보증 제도를 AI가 찾아주어 너무 든든했습니다. 덕분에 제주 대표 선물 브랜드로 성장했습니다.',
    rating: 5,
    date: '2026년 1월 승인',
    badge: '제주 로컬특례 승인',
    growthTimeline: [
      { stage: '1단계: 로컬특례 승인', description: '제주신보 2.6% 5천만원 조달' },
      { stage: '2단계: 시그니처 패키징', description: '감귤 파이 선물세트 3종 런칭' },
      { stage: '3단계: 공항 면세점 입점', description: '월 매출 4,000만원 돌파' }
    ],
    applicationTip: '지역 농특산물을 주원료로 사용하는 소상공인은 농식품부 또는 지자체 로컬크리에이터 특례보증을 적극 활용하세요.',
    founderAdvice: [
      {
        number: 1,
        title: '제주 농특산물 100% 원자재 수매 증빙으로 로컬크리에이터 인증 받기',
        detail: '제주 농가와의 친환경 감귤 직거래 수매 계약서를 제출해 제주도 로컬크리에이터 가점을 획득하고 제주관광진흥기금 연계 초저금리(2.6%)를 받았습니다.',
        highlightTag: '#로컬크리에이터인증 #농가직거래계약',
        actionMetric: '제주도 특별자금 연 2.6% 확정'
      },
      {
        number: 2,
        title: '공항 면세점 및 로컬 기념품샵 입점 제안서로 판로 소명',
        detail: '자금 신청 시 제주공항 기념품점 및 면세점 입점 제안서를 함께 첨부해 자금 집행 후 즉각적인 대량 판매 경로가 확보되었음을 입증했습니다.',
        highlightTag: '#공항면세점입점소명 #판로확보증빙',
        actionMetric: '면세점 입점 후 매출 +60% 급증'
      },
      {
        number: 3,
        title: '친환경 생분해 포장재 도입으로 ESG 지자체 우대 가점 확보',
        detail: '감귤 박스 및 파우치를 친환경 생분해 소재로 제작한다는 계획을 담아 제주도의 탄소중립/ESG 우대 가산점 5점을 추가로 획득했습니다.',
        highlightTag: '#ESG친환경패키징 #지자체가산점5점',
        actionMetric: '5,000만원 무담보 전액 승인'
      }
    ],
    aiFaqSummary: [
      {
        id: 'faq-food-jeju-1',
        category: 'STRATEGY',
        categoryLabel: '실전 전략',
        question: '로컬크리에이터 특례보증은 어떤 조건이어야 신청할 수 있나요?',
        aiSummaryAnswer: '지역의 자연환경, 문화적 자산, 또는 지역 농수축산물을 활용하여 혁신적인 비즈니스 모델을 운영하는 소상공인이면 누구나 신청 가능하며, 중기부 또는 지자체 공인 시 최고 우대를 받습니다.',
        keyTakeaway: '📌 핵심: 지역 원자재/문화 활용 시 최대 5,000만~1억원 특례 지원',
        confidenceScore: 98,
        verifiedAgency: '중소벤처기업부 & 제주신용보증재단'
      },
      {
        id: 'faq-food-jeju-2',
        category: 'LIMIT_RATE',
        categoryLabel: '한도·금리 혜택',
        question: '제주도 관광진흥기금 연계 시 대출 금리와 이자 지원 혜택은 어떤가요?',
        aiSummaryAnswer: '제주특별자치도 관광진흥기금 이차보전 연계 시 제주도가 연 2.0~2.5%p의 이자를 대납하여 대표님 최종 부담 금리는 연 2.5~2.8%의 초저금리로 적용됩니다.',
        keyTakeaway: '📌 핵심: 제주도 이자 지원으로 2%대 중반 초저금리 혜택',
        confidenceScore: 97,
        verifiedAgency: '제주특별자치도 관광정책과'
      }
    ]
  }
];

export const PROVINCES = [
  '전체 지역',
  '서울',
  '경기',
  '인천',
  '부산',
  '대구',
  '대전',
  '광주',
  '충남',
  '제주'
];

export const DISTRICTS_MAP: Record<string, string[]> = {
  '서울': ['전체 구', '마포구', '강남구', '영등포구', '종로구', '송파구', '서초구', '성동구', '용산구'],
  '경기': ['전체 시/군', '성남시', '수원시', '화성시', '용인시', '고양시', '부천시', '안산시', '평택시'],
  '인천': ['전체 구', '남동구', '부평구', '서구', '연수구', '미추홀구', '중구'],
  '부산': ['전체 구', '해운대구', '부산진구', '수영구', '동래구', '사상구', '남구'],
  '대구': ['전체 구', '수성구', '달서구', '중구', '북구', '동구'],
  '대전': ['전체 구', '유성구', '서구', '중구', '대덕구', '동구'],
  '광주': ['전체 구', '북구', '서구', '광산구', '동구', '남구'],
  '충남': ['전체 시/군', '천안시', '아산시', '서산시', '당진시', '공주시'],
  '제주': ['전체 시', '제주시', '서귀포시']
};

export const INDUSTRY_STATISTICS: Record<string, {
  avgAmount: string;
  avgAmountValue: number;
  avgRateDrop: string;
  avgRevenueIncrease: string;
  approvalRate: string;
  topFunds: { name: string; share: number; avgRate: string }[];
  primaryStrategy: string;
}> = {
  ALL: {
    avgAmount: '6,800만원',
    avgAmountValue: 6800,
    avgRateDrop: '-5.2%p',
    avgRevenueIncrease: '+26.8%',
    approvalRate: '94.6%',
    topFunds: [
      { name: '소상공인 대환대출 특별자금', share: 38, avgRate: '연 3.2%' },
      { name: '지역신용보증재단 특례보증', share: 32, avgRate: '연 2.8~3.5%' },
      { name: '스마트 소상공인 성장촉진자금', share: 18, avgRate: '연 2.5~3.0%' },
      { name: '재도전 특별지원자금', share: 12, avgRate: '연 3.0%' }
    ],
    primaryStrategy: '마이데이터 부채 소명 및 비금융 가점(교육/고용) 확보'
  },
  FOOD: {
    avgAmount: '5,500만원',
    avgAmountValue: 5500,
    avgRateDrop: '-6.4%p',
    avgRevenueIncrease: '+28.4%',
    approvalRate: '95.2%',
    topFunds: [
      { name: '소상공인 대환대출 자금', share: 44, avgRate: '연 3.2%' },
      { name: '외식업 긴급 경영안정자금', share: 28, avgRate: '연 2.9%' },
      { name: '스마트상점 기술보급 자금', share: 20, avgRate: '연 2.5%' },
      { name: '위생등급 우수업소 특례보증', share: 8, avgRate: '연 2.8%' }
    ],
    primaryStrategy: '2금융권 고금리 즉시 대환 + 테이블오더 스마트화 가점'
  },
  TECH: {
    avgAmount: '1.2억원',
    avgAmountValue: 12000,
    avgRateDrop: '-4.8%p',
    avgRevenueIncrease: '+48.0%',
    approvalRate: '93.8%',
    topFunds: [
      { name: '창업유망 혁신기업 특례보증', share: 42, avgRate: '연 2.8%' },
      { name: '신보 퍼스트펭귄 특별보증', share: 30, avgRate: '연 2.4%' },
      { name: '벤처·이노비즈 우대 특별자금', share: 18, avgRate: '연 2.6%' },
      { name: '청년창업 전용 특례대출', share: 10, avgRate: '연 2.0%' }
    ],
    primaryStrategy: '특허·소프트웨어 저작권 기술평가보증 100% 활용'
  },
  MANUFACTURING: {
    avgAmount: '2.1억원',
    avgAmountValue: 21000,
    avgRateDrop: '-3.8%p',
    avgRevenueIncrease: '+34.5%',
    approvalRate: '94.1%',
    topFunds: [
      { name: '제조 소상공인 시설/성장촉진자금', share: 46, avgRate: '연 2.9%' },
      { name: '스마트공장 보급연계 시설자금', share: 26, avgRate: '연 2.5%' },
      { name: '뿌리산업 특화 맞춤자금', share: 18, avgRate: '연 2.8%' },
      { name: '원자재 구매 연계 운전자금', share: 10, avgRate: '연 3.1%' }
    ],
    primaryStrategy: '설비 견적서 첨부 및 생산성 수율 향상 계획 소명'
  },
  RETAIL: {
    avgAmount: '4,800만원',
    avgAmountValue: 4800,
    avgRateDrop: '-5.6%p',
    avgRevenueIncrease: '+22.0%',
    approvalRate: '96.0%',
    topFunds: [
      { name: '희망리턴 재도약 특별자금', share: 36, avgRate: '연 3.0%' },
      { name: '지역신보 유통 소상공인 보증', share: 34, avgRate: '연 3.2%' },
      { name: '온라인 판로개척 디지털 자금', share: 20, avgRate: '연 2.7%' },
      { name: '지자체 이차보전 협약자금', share: 10, avgRate: '연 2.8%' }
    ],
    primaryStrategy: '소상공인 무료 교육 이수증 제출 및 비금융 가점 보완'
  },
  SERVICE: {
    avgAmount: '6,200만원',
    avgAmountValue: 6200,
    avgRateDrop: '-4.6%p',
    avgRevenueIncrease: '+25.4%',
    approvalRate: '94.8%',
    topFunds: [
      { name: '서비스업 혁신성장 특별자금', share: 40, avgRate: '연 3.3%' },
      { name: '고용창출 우수기업 특례보증', share: 32, avgRate: '연 2.8%' },
      { name: '여성기업/청년창업 우대자금', share: 16, avgRate: '연 2.5%' },
      { name: '지역신보 특례보증', share: 12, avgRate: '연 3.0%' }
    ],
    primaryStrategy: '신규 인력 채용 계획을 연계한 고용가점 10점 획득'
  },
  OTHER: {
    avgAmount: '5,000만원',
    avgAmountValue: 5000,
    avgRateDrop: '-5.0%p',
    avgRevenueIncrease: '+23.0%',
    approvalRate: '93.5%',
    topFunds: [
      { name: '일반 소상공인 경영안정자금', share: 45, avgRate: '연 3.2%' },
      { name: '지역신용보증재단 보증대출', share: 35, avgRate: '연 3.4%' },
      { name: '긴급 생계안정 특별자금', share: 20, avgRate: '연 3.0%' }
    ],
    primaryStrategy: '지역신보 지점 사전 예약 및 기본 요건 충족 심사'
  }
};
