import React, { useState, useEffect } from 'react';
import { 
  FileSpreadsheet, 
  Plus, 
  ExternalLink, 
  Copy, 
  Check, 
  RefreshCw, 
  Users, 
  ClipboardCheck, 
  Sparkles, 
  HelpCircle, 
  X, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Send,
  Eye,
  Settings,
  MessageSquareQuote,
  ShieldCheck,
  Building2,
  Calendar
} from 'lucide-react';
import { 
  createPolicyAssessmentForm, 
  createConsultationIntakeForm, 
  createCustomerFeedbackForm, 
  fetchGoogleFormDetails, 
  fetchGoogleFormResponses, 
  GoogleFormInfo, 
  FormResponseEntry 
} from '../services/workspaceService';
import { UserProfile, PolicyFund } from '../types';

interface GoogleFormsManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  token: string | null;
  profile?: UserProfile | null;
  selectedFund?: PolicyFund | null;
  onSignInRequired?: () => void;
}

export const GoogleFormsManagerModal: React.FC<GoogleFormsManagerModalProps> = ({
  isOpen,
  onClose,
  token,
  profile,
  selectedFund,
  onSignInRequired
}) => {
  const [activeTab, setActiveTab] = useState<'create' | 'responses' | 'history'>('create');
  const [isCreating, setIsCreating] = useState<string | null>(null);
  const [createdForm, setCreatedForm] = useState<GoogleFormInfo | null>(null);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Response viewing state
  const [targetFormId, setTargetFormId] = useState<string>('');
  const [isLoadingResponses, setIsLoadingResponses] = useState(false);
  const [formDetails, setFormDetails] = useState<any | null>(null);
  const [responsesData, setResponsesData] = useState<{ responses: FormResponseEntry[]; totalCount: number } | null>(null);

  // Saved forms history in localStorage
  const [savedForms, setSavedForms] = useState<GoogleFormInfo[]>(() => {
    try {
      const saved = localStorage.getItem('bizmatch_google_forms_history_v1');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const saveFormToHistory = (form: GoogleFormInfo) => {
    setSavedForms(prev => {
      const filtered = prev.filter(f => f.formId !== form.formId);
      const updated = [form, ...filtered];
      try {
        localStorage.setItem('bizmatch_google_forms_history_v1', JSON.stringify(updated));
      } catch (e) {
        console.error('Failed to save form history', e);
      }
      return updated;
    });
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedUrl(label);
    setTimeout(() => setCopiedUrl(null), 2500);
  };

  // 1. Create Policy Assessment Form
  const handleCreateAssessmentForm = async () => {
    if (!token) {
      if (onSignInRequired) onSignInRequired();
      return;
    }
    setIsCreating('assessment');
    setError(null);
    try {
      const formInfo = await createPolicyAssessmentForm(token, profile, selectedFund?.title);
      setCreatedForm(formInfo);
      saveFormToHistory(formInfo);
      setTargetFormId(formInfo.formId);
    } catch (err: any) {
      setError(err.message || 'Google Forms 설문지 생성에 실패했습니다.');
    } finally {
      setIsCreating(null);
    }
  };

  // 2. Create Consultation Intake Form
  const handleCreateConsultationForm = async () => {
    if (!token) {
      if (onSignInRequired) onSignInRequired();
      return;
    }
    setIsCreating('consultation');
    setError(null);
    try {
      const formInfo = await createConsultationIntakeForm(token, profile?.businessName || profile?.name);
      setCreatedForm(formInfo);
      saveFormToHistory(formInfo);
      setTargetFormId(formInfo.formId);
    } catch (err: any) {
      setError(err.message || 'Google Forms 상담 접수서 생성에 실패했습니다.');
    } finally {
      setIsCreating(null);
    }
  };

  // 3. Create Service Feedback Form
  const handleCreateFeedbackForm = async () => {
    if (!token) {
      if (onSignInRequired) onSignInRequired();
      return;
    }
    setIsCreating('feedback');
    setError(null);
    try {
      const formInfo = await createCustomerFeedbackForm(token);
      setCreatedForm(formInfo);
      saveFormToHistory(formInfo);
      setTargetFormId(formInfo.formId);
    } catch (err: any) {
      setError(err.message || 'Google Forms 만족도 설문 생성에 실패했습니다.');
    } finally {
      setIsCreating(null);
    }
  };

  // Load Form Details & Responses
  const handleFetchResponses = async (formIdToFetch?: string) => {
    const id = (formIdToFetch || targetFormId).trim();
    if (!id) {
      setError('조회할 Google Form ID를 입력해 주세요.');
      return;
    }
    if (!token) {
      if (onSignInRequired) onSignInRequired();
      return;
    }

    setIsLoadingResponses(true);
    setError(null);
    try {
      const [details, resp] = await Promise.all([
        fetchGoogleFormDetails(token, id).catch(() => null),
        fetchGoogleFormResponses(token, id)
      ]);
      setFormDetails(details);
      setResponsesData(resp);
      setActiveTab('responses');
    } catch (err: any) {
      setError(err.message || '설문 응답을 불러오는 데 실패했습니다. Form ID 또는 계정 권한을 확인하세요.');
    } finally {
      setIsLoadingResponses(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in no-print">
      <div 
        id="google-forms-manager-modal"
        className="bg-white rounded-3xl w-full max-w-4xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-purple-700 via-indigo-700 to-blue-700 text-white p-6 relative flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 shadow-inner">
              <ClipboardCheck className="w-6 h-6 text-purple-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] font-black uppercase tracking-wider bg-white/20 px-2.5 py-0.5 rounded-full text-white">
                  Google Forms × Google Workspace
                </span>
                <span className="text-[10px] font-bold bg-emerald-400/20 text-emerald-200 border border-emerald-400/30 px-2 py-0.5 rounded-full">
                  실시간 API 동기화
                </span>
              </div>
              <h2 className="text-xl sm:text-2xl font-black mt-1">
                Google Forms 정책자금 설문 & 응답 관리 허브
              </h2>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-50 px-6 shrink-0">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setActiveTab('create')}
              className={`py-3.5 px-4 text-xs font-black border-b-2 flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'create'
                  ? 'border-purple-600 text-purple-700 bg-white shadow-xs'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Plus className="w-4 h-4" />
              <span>설문지 원클릭 생성</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('responses')}
              className={`py-3.5 px-4 text-xs font-black border-b-2 flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'responses'
                  ? 'border-purple-600 text-purple-700 bg-white shadow-xs'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>응답 실시간 조회 ({responsesData ? `${responsesData.totalCount}건` : '0건'})</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('history')}
              className={`py-3.5 px-4 text-xs font-black border-b-2 flex items-center gap-1.5 transition-all cursor-pointer ${
                activeTab === 'history'
                  ? 'border-purple-600 text-purple-700 bg-white shadow-xs'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>생성된 설문 이력 ({savedForms.length})</span>
            </button>
          </div>

          {!token && (
            <button
              type="button"
              onClick={onSignInRequired}
              className="text-xs font-black text-purple-600 hover:text-purple-800 underline flex items-center gap-1"
            >
              Google 계정 연동 필요
            </button>
          )}
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          
          {/* Error Banner */}
          {error && (
            <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-3 text-rose-800 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
              <div className="flex-1">
                <p className="font-bold">{error}</p>
              </div>
            </div>
          )}

          {/* TAB 1: CREATE PRESET FORMS */}
          {activeTab === 'create' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-purple-600" />
                  소상공인 맞춤 Google Forms 템플릿 선택 생성
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  버튼 한 번으로 Google 계정에 최적화된 질문 세트가 구성된 Google Form이 즉시 생성되며, 설문 링크 및 편집 링크가 발급됩니다.
                </p>
              </div>

              {/* Template Cards Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* 1. Policy Assessment Form */}
                <div className="bg-slate-50 hover:bg-purple-50/50 border border-slate-200 hover:border-purple-300 rounded-2xl p-5 transition-all flex flex-col justify-between group shadow-xs">
                  <div>
                    <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-black mb-3 group-hover:scale-105 transition-transform">
                      <FileCheck2Icon className="w-5 h-5" />
                    </div>
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="px-2 py-0.5 bg-purple-100 text-purple-800 text-[10px] font-black rounded-md">추천 1순위</span>
                    </div>
                    <h4 className="text-sm font-black text-slate-900 leading-snug">
                      정책자금 적격성 사전 자가진단표
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">
                      신용점수, 사업자 형태, 매출 추이, 필요 한도, 부가세 납부 현황 등 심사 핵심 8개 문항이 자동 구성됩니다.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleCreateAssessmentForm}
                    disabled={isCreating !== null}
                    className="mt-5 w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all shadow-md shadow-purple-600/20 cursor-pointer disabled:opacity-50"
                  >
                    {isCreating === 'assessment' ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Plus className="w-3.5 h-3.5" />
                    )}
                    <span>진단 설문지 생성</span>
                  </button>
                </div>

                {/* 2. Consultation Intake Form */}
                <div className="bg-slate-50 hover:bg-indigo-50/50 border border-slate-200 hover:border-indigo-300 rounded-2xl p-5 transition-all flex flex-col justify-between group shadow-xs">
                  <div>
                    <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-black mb-3 group-hover:scale-105 transition-transform">
                      <MessageSquareQuote className="w-5 h-5" />
                    </div>
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 text-[10px] font-black rounded-md">1:1 상담용</span>
                    </div>
                    <h4 className="text-sm font-black text-slate-900 leading-snug">
                      전문가 상담 사전 접수 양식
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">
                      상담 희망 시간대, 중점 해결 과제, 준비 서류 체크리스트 등 1:1 수석 지도사 매칭용 6개 문항이 포함됩니다.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleCreateConsultationForm}
                    disabled={isCreating !== null}
                    className="mt-5 w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all shadow-md shadow-indigo-600/20 cursor-pointer disabled:opacity-50"
                  >
                    {isCreating === 'consultation' ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Plus className="w-3.5 h-3.5" />
                    )}
                    <span>상담 접수서 생성</span>
                  </button>
                </div>

                {/* 3. Feedback Form */}
                <div className="bg-slate-50 hover:bg-blue-50/50 border border-slate-200 hover:border-blue-300 rounded-2xl p-5 transition-all flex flex-col justify-between group shadow-xs">
                  <div>
                    <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-black mb-3 group-hover:scale-105 transition-transform">
                      <ClipboardCheck className="w-5 h-5" />
                    </div>
                    <div className="flex items-center gap-1.5 mb-1">
                      <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-[10px] font-black rounded-md">사후 관리</span>
                    </div>
                    <h4 className="text-sm font-black text-slate-900 leading-snug">
                      자금 매칭 만족도 & 승인 결과 설문
                    </h4>
                    <p className="text-[11px] text-slate-500 mt-2 leading-relaxed">
                      서비스 추천 정확도 5점 척도, 승인 여부 및 실제 자금 수령 현황 피드백을 수집하여 사후 관리에 반영합니다.
                    </p>
                  </div>

                  <button
                    type="button"
                    onClick={handleCreateFeedbackForm}
                    disabled={isCreating !== null}
                    className="mt-5 w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all shadow-md shadow-blue-600/20 cursor-pointer disabled:opacity-50"
                  >
                    {isCreating === 'feedback' ? (
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Plus className="w-3.5 h-3.5" />
                    )}
                    <span>만족도 설문지 생성</span>
                  </button>
                </div>

              </div>

              {/* Newly Created Form Success Details */}
              {createdForm && (
                <div className="bg-gradient-to-br from-purple-50 to-indigo-50 border border-purple-200 rounded-3xl p-6 relative">
                  <div className="flex items-start justify-between gap-4 mb-4">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-0.5 bg-emerald-500 text-white text-[10px] font-black rounded-full flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          Google Form 생성 완료!
                        </span>
                        <span className="text-[11px] font-mono font-bold text-slate-500">ID: {createdForm.formId}</span>
                      </div>
                      <h4 className="text-lg font-black text-slate-950 mt-1">{createdForm.title}</h4>
                      <p className="text-xs text-slate-600 mt-1 whitespace-pre-line">{createdForm.description}</p>
                    </div>
                  </div>

                  {/* Action Link Boxes */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-purple-200/80">
                    
                    {/* Respondent Link */}
                    <div className="bg-white p-3.5 rounded-2xl border border-purple-100 shadow-xs flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black text-purple-900 flex items-center gap-1">
                            <Send className="w-3.5 h-3.5 text-purple-600" />
                            응답자 설문 참여 링크 (공유용)
                          </span>
                          <span className="text-[10px] text-slate-400 font-bold">고객 전달용</span>
                        </div>
                        <input
                          type="text"
                          readOnly
                          value={createdForm.responderUri}
                          className="w-full mt-2 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-mono text-slate-700 select-all"
                        />
                      </div>

                      <div className="flex items-center gap-2 mt-3">
                        <button
                          type="button"
                          onClick={() => handleCopy(createdForm.responderUri, 'responder')}
                          className="flex-1 py-2 bg-purple-100 hover:bg-purple-200 text-purple-800 rounded-xl text-xs font-bold flex items-center justify-center gap-1 cursor-pointer transition-colors"
                        >
                          {copiedUrl === 'responder' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedUrl === 'responder' ? '복사 완료!' : '링크 복사'}</span>
                        </button>
                        <a
                          href={createdForm.responderUri}
                          target="_blank"
                          rel="noreferrer"
                          className="py-2 px-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-colors"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>열기</span>
                        </a>
                      </div>
                    </div>

                    {/* Admin Edit Link */}
                    <div className="bg-white p-3.5 rounded-2xl border border-purple-100 shadow-xs flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-black text-indigo-900 flex items-center gap-1">
                            <Settings className="w-3.5 h-3.5 text-indigo-600" />
                            관리자 설문 편집 & 질문 수정
                          </span>
                          <span className="text-[10px] text-slate-400 font-bold">Google Forms 편집창</span>
                        </div>
                        <input
                          type="text"
                          readOnly
                          value={createdForm.editUri}
                          className="w-full mt-2 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-mono text-slate-700 select-all"
                        />
                      </div>

                      <div className="flex items-center gap-2 mt-3">
                        <button
                          type="button"
                          onClick={() => handleCopy(createdForm.editUri, 'edit')}
                          className="flex-1 py-2 bg-indigo-100 hover:bg-indigo-200 text-indigo-800 rounded-xl text-xs font-bold flex items-center justify-center gap-1 cursor-pointer transition-colors"
                        >
                          {copiedUrl === 'edit' ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copiedUrl === 'edit' ? '복사 완료!' : '링크 복사'}</span>
                        </button>
                        <a
                          href={createdForm.editUri}
                          target="_blank"
                          rel="noreferrer"
                          className="py-2 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-colors"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>편집창</span>
                        </a>
                      </div>
                    </div>

                  </div>

                  {/* View Responses Button */}
                  <div className="mt-4 pt-3 border-t border-purple-200/80 flex items-center justify-between">
                    <span className="text-xs text-purple-900 font-medium">
                      응답자가 설문을 제출하면 실시간으로 응답 탭에서 답변을 모니터링할 수 있습니다.
                    </span>
                    <button
                      type="button"
                      onClick={() => handleFetchResponses(createdForm.formId)}
                      className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black flex items-center gap-1.5 cursor-pointer shadow-sm"
                    >
                      <Users className="w-3.5 h-3.5 text-purple-300" />
                      <span>응답 현황 바로 확인</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: RESPONSES VIEWER */}
          {activeTab === 'responses' && (
            <div className="space-y-5">
              {/* Form ID Search Input */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row items-center gap-3">
                <div className="flex-1 w-full">
                  <label className="text-[11px] font-bold text-slate-500 block mb-1">
                    조회할 Google Form ID 입력 (또는 상단 생성 폼 선택)
                  </label>
                  <input
                    type="text"
                    placeholder="예: 1FAIpQLSc... 또는 폼 생성 후 자동 입력"
                    value={targetFormId}
                    onChange={(e) => setTargetFormId(e.target.value)}
                    className="w-full px-3.5 py-2 bg-white border border-slate-300 rounded-xl text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-purple-500"
                  />
                </div>
                <button
                  type="button"
                  onClick={() => handleFetchResponses()}
                  disabled={isLoadingResponses || !targetFormId}
                  className="w-full sm:w-auto mt-auto px-5 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-black flex items-center justify-center gap-1.5 transition-all shadow-md shadow-purple-600/20 cursor-pointer disabled:opacity-50"
                >
                  {isLoadingResponses ? (
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Users className="w-3.5 h-3.5" />
                  )}
                  <span>실시간 응답 조회</span>
                </button>
              </div>

              {/* Form Header Info */}
              {formDetails && (
                <div className="p-4 bg-white border border-slate-200 rounded-2xl shadow-xs flex items-center justify-between">
                  <div>
                    <span className="text-[10px] font-bold text-purple-600 bg-purple-50 px-2 py-0.5 rounded-full">
                      연동된 설문
                    </span>
                    <h4 className="text-sm font-black text-slate-900 mt-1">{formDetails.info?.title || '설문 상세 정보'}</h4>
                    <p className="text-xs text-slate-500 mt-0.5">{formDetails.info?.description || '설명 없음'}</p>
                  </div>
                  <a
                    href={`https://docs.google.com/forms/d/${formDetails.formId}/edit#responses`}
                    target="_blank"
                    rel="noreferrer"
                    className="text-xs font-bold text-indigo-600 hover:text-indigo-800 underline flex items-center gap-1"
                  >
                    <span>Google Forms 공식 응답 시트 열기</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}

              {/* Responses List */}
              {responsesData ? (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      총 {responsesData.totalCount}개의 응답이 접수되었습니다.
                    </h4>
                    <button
                      type="button"
                      onClick={() => handleFetchResponses()}
                      className="text-xs font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-3 h-3" />
                      <span>새로고침</span>
                    </button>
                  </div>

                  {responsesData.totalCount === 0 ? (
                    <div className="py-12 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                      <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                      <p className="text-xs font-bold text-slate-500">아직 접수된 응답이 없습니다.</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">응답자 링크를 공유하여 설문 답변을 받아보세요.</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {responsesData.responses.map((resp, index) => {
                        const submittedTime = resp.lastSubmittedTime 
                          ? new Date(resp.lastSubmittedTime).toLocaleString('ko-KR')
                          : '기록 없음';
                        return (
                          <div 
                            key={resp.responseId || index}
                            className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs"
                          >
                            <div className="flex items-center justify-between pb-2.5 mb-2.5 border-b border-slate-100">
                              <div className="flex items-center gap-2">
                                <span className="w-6 h-6 rounded-full bg-purple-100 text-purple-800 text-xs font-black flex items-center justify-center">
                                  #{index + 1}
                                </span>
                                <span className="text-xs font-bold text-slate-800">
                                  {resp.respondentEmail || `익명 응답자 (${resp.responseId.substring(0, 8)})`}
                                </span>
                              </div>
                              <span className="text-[11px] font-medium text-slate-400">
                                접수 일시: {submittedTime}
                              </span>
                            </div>

                            {/* Answers Grid */}
                            <div className="space-y-2 text-xs">
                              {Object.entries(resp.answers).map(([qId, rawAns]) => {
                                const ans = rawAns as any;
                                return (
                                  <div key={qId} className="bg-slate-50 p-2.5 rounded-xl">
                                    <div className="text-[11px] font-bold text-slate-600 mb-0.5">
                                      {ans?.questionTitle || `질문 [${qId.substring(0, 6)}...]`}
                                    </div>
                                    <div className="font-bold text-slate-900">
                                      {ans?.textAnswers?.join(', ') || '(답변 없음)'}
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              ) : (
                <div className="py-10 text-center bg-slate-50 rounded-2xl border border-slate-200">
                  <p className="text-xs font-bold text-slate-500">
                    상단의 폼 생성 버튼을 누르거나 Form ID를 입력하여 응답을 조회하세요.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: SAVED FORMS HISTORY */}
          {activeTab === 'history' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-black text-slate-800">
                  이 브라우저에서 생성된 설문지 이력 ({savedForms.length}개)
                </h4>
                {savedForms.length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm('설문지 이력 목록을 모두 비우시겠습니까? (Google 계정 내의 실제 Form은 유지됩니다)')) {
                        setSavedForms([]);
                        localStorage.removeItem('bizmatch_google_forms_history_v1');
                      }
                    }}
                    className="text-[11px] font-bold text-rose-600 hover:text-rose-800 underline cursor-pointer"
                  >
                    이력 목록 비우기
                  </button>
                )}
              </div>

              {savedForms.length === 0 ? (
                <div className="py-12 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                  <FileSpreadsheet className="w-8 h-8 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs font-bold text-slate-500">아직 생성된 설문지 이력이 없습니다.</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">'설문지 원클릭 생성' 탭에서 새 양식을 생성해 보세요.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {savedForms.map((form) => (
                    <div 
                      key={form.formId}
                      className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 bg-purple-100 text-purple-800 text-[10px] font-black rounded-md">
                            Google Forms
                          </span>
                          <span className="text-[10px] font-mono text-slate-400">ID: {form.formId}</span>
                        </div>
                        <h4 className="text-sm font-black text-slate-900 mt-1">{form.title}</h4>
                        {form.createdAt && (
                          <span className="text-[10px] text-slate-400 block mt-0.5">
                            생성 일시: {new Date(form.createdAt).toLocaleString('ko-KR')}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => {
                            setTargetFormId(form.formId);
                            handleFetchResponses(form.formId);
                          }}
                          className="px-3 py-1.5 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors cursor-pointer"
                        >
                          <Users className="w-3.5 h-3.5" />
                          <span>응답 조회</span>
                        </button>
                        <a
                          href={form.responderUri}
                          target="_blank"
                          rel="noreferrer"
                          className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1 transition-colors"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>설문 열기</span>
                        </a>
                        <a
                          href={form.editUri}
                          target="_blank"
                          rel="noreferrer"
                          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1 transition-colors"
                        >
                          <Settings className="w-3.5 h-3.5" />
                          <span>편집</span>
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="bg-slate-50 border-t border-slate-200 p-4 px-6 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Google Forms API 공식 엔드포인트 연동 (OAuth 2.0 보안 인증)</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl text-xs font-black transition-colors cursor-pointer"
          >
            닫기
          </button>
        </div>
      </div>
    </div>
  );
};

function FileCheck2Icon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 22h14a2 2 0 0 0 2-2V7l-5-5H6a2 2 0 0 0-2 2v4" />
      <path d="M14 2v4a2 2 0 0 0 2 2h4" />
      <path d="m3 15 2 2 4-4" />
    </svg>
  );
}
