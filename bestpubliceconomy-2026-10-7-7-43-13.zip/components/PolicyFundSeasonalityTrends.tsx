import React, { useState, useMemo } from 'react';
import { 
  ResponsiveContainer, 
  ComposedChart, 
  Line, 
  Bar, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ReferenceLine,
  BarChart,
  AreaChart
} from 'recharts';
import { 
  TrendingUp, 
  Calendar, 
  DollarSign, 
  Percent, 
  AlertCircle, 
  CheckCircle2, 
  Sparkles, 
  ArrowUpRight, 
  ArrowDownRight, 
  HelpCircle, 
  Sliders, 
  Flame, 
  Clock, 
  Briefcase, 
  ChevronRight, 
  Download,
  Building2,
  ShieldCheck,
  RefreshCw,
  Info
} from 'lucide-react';
import { UserProfile, Industry, SourcePolicy } from '../types';

interface PolicyFundSeasonalityTrendsProps {
  profile?: UserProfile | null;
  latestPolicies?: SourcePolicy[];
  onNavigateToMatch?: () => void;
}

export const PolicyFundSeasonalityTrends: React.FC<PolicyFundSeasonalityTrendsProps> = ({
  profile,
  latestPolicies = [],
  onNavigateToMatch
}) => {
  // Selected industry filter (default to profile industry or RETAIL)
  const [selectedIndustry, setSelectedIndustry] = useState<Industry>(() => {
    return profile?.industry || Industry.RETAIL;
  });

  // Active chart view mode
  const [chartViewMode, setChartViewMode] = useState<'COMBINED' | 'CASH_GAP' | 'BUDGET_RATE'>('COMBINED');

  // Custom revenue simulator input (defaults from user profile or representative 150M KRW)
  const baseAnnualRevenue = profile?.annualRevenue || 180000000;
  const baseFundingNeed = profile?.fundingNeed || 50000000;
  const [simulatedAnnualRevenue, setSimulatedAnnualRevenue] = useState<number>(baseAnnualRevenue);
  const [simulatedFundingNeed, setSimulatedFundingNeed] = useState<number>(baseFundingNeed);

  // Industry seasonality factors for recent 3 months (7월, 8월, 9월)
  const industrySeasonalityMap: Record<Industry, {
    label: string;
    description: string;
    julyMultiplier: number;
    augustMultiplier: number;
    septemberMultiplier: number;
    keyDemandDriver: string;
    riskFactor: string;
  }> = {
    [Industry.RETAIL]: {
      label: '도·소매업',
      description: '추석 명절 선물세트 및 성수기 물량 선사입으로 9월 자금 수요 급증',
      julyMultiplier: 0.92, // 부가세 납부 및 비수기 진입
      augustMultiplier: 0.88, // 하계 휴가철 분산
      septemberMultiplier: 1.35, // 추석 대목 매출 및 상품 선매입
      keyDemandDriver: '추석 선물세트 대량 선사입 및 결제 대금 확보',
      riskFactor: '8월 비수기 매출 감소에 따른 일시적 현금 경색 위험'
    },
    [Industry.RESTAURANT]: {
      label: '음식점·외식업',
      description: '하계 휴가철 상권별 양극화 및 9월 명절 연휴 가족 모임 특수',
      julyMultiplier: 0.95,
      augustMultiplier: 0.90, // 도심 오피스 상권 비수기
      septemberMultiplier: 1.25, // 추석 전후 단체 예약 및 명절 외식 증가
      keyDemandDriver: '원식자재 선결제 및 명절 특별 인건비 지출',
      riskFactor: '식자재 물가 급등 및 7~8월 냉방비 등 관리비용 증가'
    },
    [Industry.MANUFACTURING]: {
      label: '제조업',
      description: '하반기 납품 물량 집중 및 원부자재 조달, 명절 상여금 지급',
      julyMultiplier: 0.98,
      augustMultiplier: 0.85, // 공장 하계 정기 휴무 및 가동률 조정
      septemberMultiplier: 1.28, // 3분기 말 납품 완료 및 명절 상여금
      keyDemandDriver: '원자재 대량 구매 선지급 및 생산 라인 확충',
      riskFactor: '납품 대금 회수 지연(어음 만기)과 현금성 명절 상여금 지급 시기 불일치'
    },
    [Industry.IT_SOFTWARE]: {
      label: 'IT·소프트웨어',
      description: '공공/기업 3분기 프로젝트 기성금 입금 및 하반기 R&D 채용 집행',
      julyMultiplier: 1.02,
      augustMultiplier: 0.96,
      septemberMultiplier: 1.15,
      keyDemandDriver: '하반기 서버 인프라 증설 및 고급 개발인력 충원',
      riskFactor: '정부 R&D 및 바우처 사업 정산 주기 전 개발 인건비 선지출'
    },
    [Industry.SERVICE]: {
      label: '서비스업',
      description: '개인 및 기업 서비스 이용 주기에 따른 9월 회복세',
      julyMultiplier: 0.96,
      augustMultiplier: 0.92,
      septemberMultiplier: 1.18,
      keyDemandDriver: '가을 성수기 마케팅 집행 및 매장 리뉴얼',
      riskFactor: '고정 임차료 및 직원 휴가 대체 인력 비용'
    },
    [Industry.OTHER]: {
      label: '기타 일반업종',
      description: '일반 소상공인 경기 변동 및 3분기 계절성 자금 소요',
      julyMultiplier: 0.95,
      augustMultiplier: 0.90,
      septemberMultiplier: 1.20,
      keyDemandDriver: '운영자금 보강 및 기존 고금리 대출 대환',
      riskFactor: '하반기 금리 변동 및 원리금 상환 부담'
    }
  };

  const currentSeasonality = industrySeasonalityMap[selectedIndustry] || industrySeasonalityMap[Industry.RETAIL];

  // Base monthly revenue calculation (KRW converted to 10,000 KRW = 만원)
  const baseMonthlyRevManwon = Math.round((simulatedAnnualRevenue / 12) / 10000);
  const baseFundingNeedManwon = Math.round(simulatedFundingNeed / 10000);

  // Recent 3 months historical & live dataset: 2026년 7월, 8월, 9월
  const trendData = useMemo(() => {
    // 7월: 부가세 납부기 + 하반기 자금 개시
    const julyRev = Math.round(baseMonthlyRevManwon * currentSeasonality.julyMultiplier);
    // 8월: 여름철 휴가기 + 소진공 3분기 정규 접수
    const augustRev = Math.round(baseMonthlyRevManwon * currentSeasonality.augustMultiplier);
    // 9월: 추석 명절 + 원자재 선구매 + 예산 소진 임박
    const septRev = Math.round(baseMonthlyRevManwon * currentSeasonality.septemberMultiplier);

    // Business expenditure estimation (COGS + fixed cost + seasonal tax/bonuses)
    const julyExpenses = Math.round(julyRev * 0.72 + (baseMonthlyRevManwon * 0.15)); // VAT payment impact
    const augustExpenses = Math.round(augustRev * 0.76 + (baseMonthlyRevManwon * 0.08)); // AC utility impact
    const septExpenses = Math.round(septRev * 0.78 + (baseMonthlyRevManwon * 0.22)); // Chuseok inventory prep & bonus

    // Net operating cash flow
    const julyCashFlow = julyRev - julyExpenses;
    const augustCashFlow = augustRev - augustExpenses;
    const septCashFlow = septRev - septExpenses;

    // Monthly funding need
    const julyNeed = Math.max(0, Math.round(baseFundingNeedManwon * 0.28));
    const augustNeed = Math.max(0, Math.round(baseFundingNeedManwon * 0.32));
    const septNeed = Math.max(0, Math.round(baseFundingNeedManwon * 0.40));

    return [
      {
        month: '2026.07 (7월)',
        monthShort: '7월',
        seasonEvent: '부가세 확정신고 / 하반기 개시',
        // 정부 정책자금 지표
        policySupplyAmount: 4800, // 4,800억원
        avgInterestRate: 3.42, // %
        budgetExhaustionRate: 64.2, // %
        announcementCount: 184, // 건
        approvalDays: 14.2, // 일
        // 사업장 재무 연계 데이터 (단위: 만원)
        businessRevenue: julyRev,
        businessExpenses: julyExpenses,
        netCashFlow: julyCashFlow,
        fundingNeed: julyNeed,
        // 계절성 지수 (100 기준)
        seasonalityIndex: Math.round(currentSeasonality.julyMultiplier * 100),
        liquidityRisk: '보통 (부가세 납부 일시적 부담)'
      },
      {
        month: '2026.08 (8월)',
        monthShort: '8월',
        seasonEvent: '하계 비수기 / 3분기 소진공 직접대출',
        // 정부 정책자금 지표
        policySupplyAmount: 3950, // 3,950억원
        avgInterestRate: 3.35, // %
        budgetExhaustionRate: 76.8, // %
        announcementCount: 142, // 건
        approvalDays: 18.5, // 일 (휴가철 심사 지연)
        // 사업장 재무 연계 데이터 (단위: 만원)
        businessRevenue: augustRev,
        businessExpenses: augustExpenses,
        netCashFlow: augustCashFlow,
        fundingNeed: augustNeed,
        // 계절성 지수
        seasonalityIndex: Math.round(currentSeasonality.augustMultiplier * 100),
        liquidityRisk: '주의 (휴가철 매출 저하 및 고정비 지속)'
      },
      {
        month: '2026.09 (9월 현황)',
        monthShort: '9월 (현재)',
        seasonEvent: '추석 특별자금 집중 / 예산 90% 소진 임박',
        // 정부 정책자금 지표
        policySupplyAmount: 6200, // 6,200억원 (명절 특별 배정)
        avgInterestRate: 3.28, // % (이차보전 특별 인하)
        budgetExhaustionRate: 89.4, // %
        announcementCount: 228, // 건
        approvalDays: 11.8, // 일 (명절 패스트트랙 신속집행)
        // 사업장 재무 연계 데이터 (단위: 만원)
        businessRevenue: septRev,
        businessExpenses: septExpenses,
        netCashFlow: septCashFlow,
        fundingNeed: septNeed,
        // 계절성 지수
        seasonalityIndex: Math.round(currentSeasonality.septemberMultiplier * 100),
        liquidityRisk: '경고 (자금 수요 급증 vs 예산 조기 소진 초임박)'
      }
    ];
  }, [baseMonthlyRevManwon, baseFundingNeedManwon, currentSeasonality]);

  // Breakdown by fund category over 3 months (운전자금, 시설자금, 대환자금, 특례보증)
  const categoryTrendData = useMemo(() => [
    {
      month: '7월',
      workingCapital: 2500, // 운전자금 (억원)
      facilityFund: 950, // 시설자금
      refinanceFund: 750, // 대환대출
      specialGuarantee: 600, // 특례보증
    },
    {
      month: '8월',
      workingCapital: 1950,
      facilityFund: 780,
      refinanceFund: 620,
      specialGuarantee: 600,
    },
    {
      month: '9월 (현재)',
      workingCapital: 3600, // 명절 수요 급증
      facilityFund: 820,
      refinanceFund: 980, // 고금리 대환 폭증
      specialGuarantee: 800,
    },
  ], []);

  // Summary KPIs comparing 7월 vs 9월
  const kpiComparison = useMemo(() => {
    const july = trendData[0];
    const sept = trendData[2];

    const supplyDelta = Math.round(((sept.policySupplyAmount - july.policySupplyAmount) / july.policySupplyAmount) * 100);
    const rateDelta = (sept.avgInterestRate - july.avgInterestRate).toFixed(2);
    const budgetBurnDelta = (sept.budgetExhaustionRate - july.budgetExhaustionRate).toFixed(1);
    const revenueDelta = Math.round(((sept.businessRevenue - july.businessRevenue) / july.businessRevenue) * 100);

    return {
      supplyDelta,
      rateDelta,
      budgetBurnDelta,
      revenueDelta,
      currentExhaustion: sept.budgetExhaustionRate,
      currentSupply: sept.policySupplyAmount,
      currentRate: sept.avgInterestRate
    };
  }, [trendData]);

  return (
    <div className="bg-white rounded-3xl p-6 md:p-8 border border-slate-200 shadow-sm space-y-8 animate-fade-in">
      
      {/* Header Title and Context */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-6 border-b border-slate-100">
        <div className="space-y-1.5">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-black">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>최근 3개월 정책자금 빅데이터 & 계절성 분석</span>
          </div>
          <h2 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <span>정부 정책자금 공급 추이 & 재무 계절성 연동 대시보드</span>
          </h2>
          <p className="text-xs md:text-sm text-slate-500 font-medium">
            2026년 7월 ~ 9월(현재) 소진공·중진공·지역신보의 집행 데이터와 사업장 재무 흐름을 교차 분석하여 최적의 신청 타이밍을 도출합니다.
          </p>
        </div>

        {/* Industry Filter Pills */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-xs font-bold text-slate-400 mr-1 flex items-center gap-1">
            <Briefcase className="w-3.5 h-3.5" /> 업종 기준:
          </span>
          {Object.entries(industrySeasonalityMap).map(([key, item]) => {
            const isSelected = selectedIndustry === key;
            return (
              <button
                key={key}
                onClick={() => setSelectedIndustry(key as Industry)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  isSelected
                    ? 'bg-blue-600 text-white shadow-xs scale-102'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* 3-Month Key Trend Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Policy Supply */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-1">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500">
            <span>9월 정책자금 공급량</span>
            <span className="inline-flex items-center text-blue-600 text-[11px] font-black">
              <ArrowUpRight className="w-3.5 h-3.5" /> +{kpiComparison.supplyDelta}% (7월 대비)
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900">
            {kpiComparison.currentSupply.toLocaleString()}억원
          </div>
          <p className="text-[11px] text-slate-500 leading-tight">
            추석 명절 대비 소진공·지역신보 특별 배정액 확대
          </p>
        </div>

        {/* Metric 2: Average Interest Rate */}
        <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-1">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500">
            <span>평균 정책금리</span>
            <span className="inline-flex items-center text-emerald-600 text-[11px] font-black">
              <ArrowDownRight className="w-3.5 h-3.5" /> {kpiComparison.rateDelta}%p
            </span>
          </div>
          <div className="text-2xl font-black text-emerald-600">
            {kpiComparison.currentRate}%
          </div>
          <p className="text-[11px] text-slate-500 leading-tight">
            이차보전 및 우대 지원 정책 가산금리 인하 반영
          </p>
        </div>

        {/* Metric 3: Cumulative Budget Exhaustion */}
        <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200/80 space-y-1">
          <div className="flex items-center justify-between text-xs font-bold text-amber-800">
            <span>예산 소진율 (소진 임박)</span>
            <span className="inline-flex items-center text-rose-600 text-[11px] font-black">
              <Flame className="w-3.5 h-3.5 mr-0.5" /> +{kpiComparison.budgetBurnDelta}%p
            </span>
          </div>
          <div className="text-2xl font-black text-amber-900">
            {kpiComparison.currentExhaustion}%
          </div>
          <p className="text-[11px] text-amber-700 leading-tight">
            연간 예산의 89% 이상 집행되어 9월 말 선착순 조기마감 주의
          </p>
        </div>

        {/* Metric 4: Business Revenue & Seasonality */}
        <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-100 space-y-1">
          <div className="flex items-center justify-between text-xs font-bold text-blue-800">
            <span>{currentSeasonality.label} 9월 계절성 지수</span>
            <span className="inline-flex items-center text-blue-700 text-[11px] font-black">
              {currentSeasonality.septemberMultiplier >= 1.0 ? '성수기 대목' : '안정기'}
            </span>
          </div>
          <div className="text-2xl font-black text-blue-900">
            {Math.round(currentSeasonality.septemberMultiplier * 100)}점
          </div>
          <p className="text-[11px] text-blue-700 leading-tight">
            월평균 대비 매출 {Math.round((currentSeasonality.septemberMultiplier - 1) * 100)}% 변동 예상
          </p>
        </div>
      </div>

      {/* Chart Tabs & Sub-Controls */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-2 rounded-2xl border border-slate-200/80">
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setChartViewMode('COMBINED')}
              className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all ${
                chartViewMode === 'COMBINED'
                  ? 'bg-white text-blue-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              📊 통합 추이 (공급규모 + 매출 + 금리 + 소진율)
            </button>
            <button
              onClick={() => setChartViewMode('CASH_GAP')}
              className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all ${
                chartViewMode === 'CASH_GAP'
                  ? 'bg-white text-indigo-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              🌊 계절성 현금흐름 갭 & 자금 수혈 분석
            </button>
            <button
              onClick={() => setChartViewMode('BUDGET_RATE')}
              className={`px-3.5 py-2 rounded-xl text-xs font-black transition-all ${
                chartViewMode === 'BUDGET_RATE'
                  ? 'bg-white text-amber-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              🎯 자금 분류별 3개월 공급 비중
            </button>
          </div>

          <div className="text-[11px] text-slate-500 font-bold px-2 flex items-center gap-1">
            <Clock className="w-3 h-3 text-slate-400" />
            <span>최신 3개월 (7월 / 8월 / 9월 기준)</span>
          </div>
        </div>

        {/* Primary Recharts Visualization Box */}
        <div className="bg-white p-4 md:p-6 rounded-2xl border border-slate-100 shadow-xs min-h-[400px]">
          {chartViewMode === 'COMBINED' && (
            <div>
              <div className="mb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-black text-slate-900">
                    최근 3개월 정부 정책자금 총공급액 vs 사업장 월매출 및 금리·소진율 변동
                  </h3>
                  <p className="text-xs text-slate-500">
                    막대: 정부 자금 공급량(억원) & 사업장 월매출(만원) | 선 그래프: 평균 정책금리(%) & 예산 소진율(%)
                  </p>
                </div>
                <div className="flex items-center gap-3 text-xs font-bold">
                  <span className="flex items-center gap-1 text-blue-600">
                    <span className="w-3 h-3 rounded-sm bg-blue-500 inline-block"></span> 정책공급(억원)
                  </span>
                  <span className="flex items-center gap-1 text-emerald-600">
                    <span className="w-3 h-3 rounded-sm bg-emerald-500 inline-block"></span> 사업장매출(만원)
                  </span>
                  <span className="flex items-center gap-1 text-rose-500">
                    <span className="w-3 h-0.5 bg-rose-500 inline-block"></span> 예산소진율(%)
                  </span>
                  <span className="flex items-center gap-1 text-indigo-500">
                    <span className="w-3 h-0.5 bg-indigo-500 inline-block"></span> 평균금리(%)
                  </span>
                </div>
              </div>

              <div className="w-full h-[340px]">
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={trendData} margin={{ top: 15, right: 30, left: 10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis 
                      dataKey="month" 
                      tick={{ fill: '#475569', fontSize: 12, fontWeight: 700 }}
                      axisLine={{ stroke: '#cbd5e1' }}
                    />
                    {/* Left Axis: Currency Scale */}
                    <YAxis 
                      yAxisId="left" 
                      orientation="left"
                      tick={{ fill: '#475569', fontSize: 11 }}
                      axisLine={{ stroke: '#cbd5e1' }}
                      tickFormatter={(val) => `${val.toLocaleString()}`}
                    />
                    {/* Right Axis: Percentage Scale (%) */}
                    <YAxis 
                      yAxisId="right" 
                      orientation="right" 
                      domain={[0, 100]}
                      tick={{ fill: '#64748b', fontSize: 11 }}
                      axisLine={{ stroke: '#cbd5e1' }}
                      tickFormatter={(val) => `${val}%`}
                    />
                    <Tooltip 
                      content={({ active, payload, label }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload;
                          return (
                            <div className="bg-slate-900/95 backdrop-blur-md text-white p-4 rounded-2xl shadow-2xl border border-white/10 text-xs space-y-2 min-w-[240px]">
                              <div className="font-black text-sm text-blue-300 border-b border-white/10 pb-1.5 flex items-center justify-between">
                                <span>{label}</span>
                                <span className="text-[10px] text-amber-300 font-semibold">{data.seasonEvent}</span>
                              </div>
                              <div className="space-y-1">
                                <div className="flex justify-between">
                                  <span className="text-slate-400">정부 정책자금 공급량:</span>
                                  <span className="font-bold text-blue-400">{data.policySupplyAmount.toLocaleString()} 억원</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-slate-400">사업장 추정 월매출:</span>
                                  <span className="font-bold text-emerald-400">{data.businessRevenue.toLocaleString()} 만원</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-slate-400">정책자금 평균 금리:</span>
                                  <span className="font-bold text-indigo-300">{data.avgInterestRate}%</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-slate-400">예산 누적 소진율:</span>
                                  <span className="font-bold text-rose-400">{data.budgetExhaustionRate}%</span>
                                </div>
                                <div className="flex justify-between border-t border-white/10 pt-1">
                                  <span className="text-slate-400">신규 공고 수:</span>
                                  <span className="font-bold text-white">{data.announcementCount}건</span>
                                </div>
                                <div className="flex justify-between">
                                  <span className="text-slate-400">평균 심사 소요기간:</span>
                                  <span className="font-bold text-white">{data.approvalDays}영업일</span>
                                </div>
                              </div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    {/* Policy Supply Volume Bar */}
                    <Bar 
                      yAxisId="left" 
                      dataKey="policySupplyAmount" 
                      name="정부 정책공급(억원)" 
                      fill="#3b82f6" 
                      radius={[8, 8, 0, 0]} 
                      barSize={36}
                    />
                    {/* Business Revenue Bar */}
                    <Bar 
                      yAxisId="left" 
                      dataKey="businessRevenue" 
                      name="사업장 추정매출(만원)" 
                      fill="#10b981" 
                      radius={[8, 8, 0, 0]} 
                      barSize={24}
                    />
                    {/* Budget Exhaustion Rate Line */}
                    <Line 
                      yAxisId="right" 
                      type="monotone" 
                      dataKey="budgetExhaustionRate" 
                      name="예산소진율(%)" 
                      stroke="#f43f5e" 
                      strokeWidth={3} 
                      dot={{ r: 5, fill: '#f43f5e', strokeWidth: 2, stroke: '#fff' }}
                    />
                    {/* Average Interest Rate Line */}
                    <Line 
                      yAxisId="right" 
                      type="monotone" 
                      dataKey="avgInterestRate" 
                      name="평균금리(%)" 
                      stroke="#6366f1" 
                      strokeWidth={2.5} 
                      strokeDasharray="4 4"
                      dot={{ r: 4, fill: '#6366f1' }}
                    />
                    <ReferenceLine yAxisId="right" y={85} stroke="#ef4444" strokeDasharray="3 3" label={{ value: '조기마감 위험선 (85%)', fill: '#ef4444', fontSize: 10, position: 'insideTopRight' }} />
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {chartViewMode === 'CASH_GAP' && (
            <div>
              <div className="mb-4">
                <h3 className="text-sm font-black text-slate-900">
                  계절성 운영비용 지출 vs 유입 매출 및 정책자금 필요 갭(Cash Flow Gap)
                </h3>
                <p className="text-xs text-slate-500">
                  7월 부가세 납부 및 9월 추석 대비 원부자재 선지급으로 발생하는 유동성 부족분을 파악합니다.
                </p>
              </div>

              <div className="w-full h-[340px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={trendData} margin={{ top: 15, right: 25, left: 10, bottom: 5 }}>
                    <defs>
                      <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorExp" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#ef4444" stopOpacity={0.4}/>
                        <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorNeed" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.5}/>
                        <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.05}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis dataKey="month" tick={{ fill: '#475569', fontSize: 12, fontWeight: 700 }} />
                    <YAxis 
                      tick={{ fill: '#475569', fontSize: 11 }}
                      tickFormatter={(val) => `${val.toLocaleString()}만`}
                    />
                    <Tooltip 
                      formatter={(val: any, name: any) => [`${Number(val).toLocaleString()} 만원`, name]}
                      labelStyle={{ fontWeight: 800, color: '#0f172a' }}
                      contentStyle={{ backgroundColor: '#ffffff', borderRadius: '16px', border: '1px solid #e2e8f0', boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)' }}
                    />
                    <Legend />
                    <Area type="monotone" dataKey="businessRevenue" name="매출 유입액(만원)" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#colorRev)" />
                    <Area type="monotone" dataKey="businessExpenses" name="계절성 지출·원가(만원)" stroke="#ef4444" strokeWidth={2.5} fillOpacity={1} fill="url(#colorExp)" />
                    <Area type="monotone" dataKey="fundingNeed" name="추천 정책자금 수혈액(만원)" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorNeed)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {chartViewMode === 'BUDGET_RATE' && (
            <div>
              <div className="mb-4">
                <h3 className="text-sm font-black text-slate-900">
                  주요 정책자금 유형별 3개월 공급 배정액 변화 (단위: 억원)
                </h3>
                <p className="text-xs text-slate-500">
                  9월 들어 명절 특별 경영안정(운전자금) 및 2금융권 채무 완화를 위한 대환대출 비중이 급격히 증가했습니다.
                </p>
              </div>

              <div className="w-full h-[340px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={categoryTrendData} margin={{ top: 15, right: 25, left: 10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                    <XAxis dataKey="month" tick={{ fill: '#475569', fontSize: 12, fontWeight: 700 }} />
                    <YAxis tick={{ fill: '#475569', fontSize: 11 }} tickFormatter={(val) => `${val}억`} />
                    <Tooltip 
                      formatter={(val: any, name: any) => [`${Number(val).toLocaleString()} 억원`, name]}
                      contentStyle={{ backgroundColor: '#ffffff', borderRadius: '16px', border: '1px solid #e2e8f0' }}
                    />
                    <Legend />
                    <Bar dataKey="workingCapital" name="경영안정 운전자금" fill="#3b82f6" stackId="a" radius={[0, 0, 0, 0]} />
                    <Bar dataKey="facilityFund" name="스마트화·시설자금" fill="#10b981" stackId="a" />
                    <Bar dataKey="refinanceFund" name="저금리 대환대출" fill="#8b5cf6" stackId="a" />
                    <Bar dataKey="specialGuarantee" name="특례보증(신보/기보)" fill="#f59e0b" stackId="a" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Seasonality Insights & Strategic Action Plan */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-2">
        {/* Card 1: 7월 분석 */}
        <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
          <div className="flex items-center justify-between">
            <span className="px-2.5 py-1 bg-slate-200 text-slate-700 text-[11px] font-black rounded-lg">
              2026년 7월 (정산기)
            </span>
            <span className="text-xs font-bold text-slate-500">예산소진 64.2%</span>
          </div>
          <h4 className="text-sm font-black text-slate-900">
            부가세 신고 납부 및 3분기 정책공고 개시
          </h4>
          <p className="text-xs text-slate-600 leading-relaxed">
            상반기 부가가치세 1기 확정신고로 일시적 세무 비용 유출이 집중되는 시기였습니다. 소진공의 일반경영안정자금과 스마트 시설자금 신규 공고가 184건 게시되며 하반기 1차 수혈이 활발했습니다.
          </p>
          <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-500 font-medium flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />
            <span>핵심 자금: 일반경영안정자금, 부가세 납부 연계 특례</span>
          </div>
        </div>

        {/* Card 2: 8월 분석 */}
        <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
          <div className="flex items-center justify-between">
            <span className="px-2.5 py-1 bg-slate-200 text-slate-700 text-[11px] font-black rounded-lg">
              2026년 8월 (침체기/휴가철)
            </span>
            <span className="text-xs font-bold text-slate-500">예산소진 76.8%</span>
          </div>
          <h4 className="text-sm font-black text-slate-900">
            하계 비수기 매출 저하 & 심사 지연 대응
          </h4>
          <p className="text-xs text-slate-600 leading-relaxed">
            휴가철 영향으로 도심 오피스 상권의 외식·도소매 매출이 일시적으로 감소하며 냉방비 등 관리비 부담이 가중되었습니다. 금융기관 심사 소요 기간이 평균 18.5일로 늘어나 선제적 신청의 중요성이 부각되었습니다.
          </p>
          <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-500 font-medium flex items-center gap-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-blue-500" />
            <span>핵심 자금: 저신용취약차주자금, 고금리 대환대출</span>
          </div>
        </div>

        {/* Card 3: 9월 (현재 시점 분석 및 골든타임) */}
        <div className="p-5 rounded-2xl bg-gradient-to-br from-blue-50 via-indigo-50/50 to-white border-2 border-blue-200 space-y-3 relative overflow-hidden">
          <div className="flex items-center justify-between">
            <span className="px-2.5 py-1 bg-blue-600 text-white text-[11px] font-black rounded-lg flex items-center gap-1">
              <Flame className="w-3 h-3 text-amber-300" /> 2026년 9월 (현재 골든타임)
            </span>
            <span className="text-xs font-black text-rose-600">예산소진 89.4% 🔥</span>
          </div>
          <h4 className="text-sm font-black text-slate-900">
            추석 명절 특별자금 집행 피크 & 4분기 소진 전 막차
          </h4>
          <p className="text-xs text-slate-700 leading-relaxed font-medium">
            정부의 추석 민생안정 대책으로 <strong>6,200억원 규모의 명절 특별자금</strong>이 긴급 투입되었습니다. 평균 금리는 연 3.28%로 3개월 중 최저 수준이나, 연간 예산의 약 90%가 이미 소진되어 <strong>향후 7~10일 이내 접수가 마감</strong>될 수 있습니다.
          </p>
          <div className="pt-2 border-t border-blue-100 flex items-center justify-between">
            <span className="text-[11px] font-bold text-blue-800">
              추석 전 신속심사(11.8영업일) 지원 중
            </span>
            {onNavigateToMatch && (
              <button
                onClick={onNavigateToMatch}
                className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold transition-all shadow-xs flex items-center gap-1"
              >
                <span>자금 매칭 신청</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Interactive Business Financial Simulation Controls */}
      <div className="p-6 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-blue-100 text-blue-700">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-sm font-black text-slate-900">내 사업장 재무 데이터 연동 시뮬레이터</h4>
              <p className="text-xs text-slate-500 font-medium">
                연매출 및 필요 운전자금을 조정하여 3개월 계절성 현금흐름과 정부 자금 필요량을 즉시 재계산합니다.
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setSimulatedAnnualRevenue(baseAnnualRevenue);
              setSimulatedFundingNeed(baseFundingNeed);
            }}
            className="text-xs font-bold text-slate-500 hover:text-slate-800 flex items-center gap-1 self-start sm:self-auto"
          >
            <RefreshCw className="w-3 h-3" />
            <span>기본 프로필값 복원</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
          {/* Revenue Slider */}
          <div className="space-y-2 bg-white p-4 rounded-xl border border-slate-200/60">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-600">연간 매출액 기준</span>
              <span className="text-blue-600 font-black text-sm">
                {(simulatedAnnualRevenue / 100000000).toFixed(1)}억원 ({Math.round(simulatedAnnualRevenue / 10000).toLocaleString()}만원)
              </span>
            </div>
            <input
              type="range"
              min={30000000}
              max={1000000000}
              step={10000000}
              value={simulatedAnnualRevenue}
              onChange={(e) => setSimulatedAnnualRevenue(Number(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-medium">
              <span>3,000만원</span>
              <span>월평균 {baseMonthlyRevManwon.toLocaleString()}만원 환산</span>
              <span>10억원</span>
            </div>
          </div>

          {/* Funding Need Slider */}
          <div className="space-y-2 bg-white p-4 rounded-xl border border-slate-200/60">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-600">필요 정책자금 규모</span>
              <span className="text-emerald-600 font-black text-sm">
                {(simulatedFundingNeed / 10000).toLocaleString()}만원
              </span>
            </div>
            <input
              type="range"
              min={10000000}
              max={200000000}
              step={5000000}
              value={simulatedFundingNeed}
              onChange={(e) => setSimulatedFundingNeed(Number(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-medium">
              <span>1,000만원</span>
              <span>대출/보증 한도 가이드</span>
              <span>2억원</span>
            </div>
          </div>
        </div>

        {/* Seasonality Strategy Guidance Banner */}
        <div className="mt-3 p-4 bg-white rounded-xl border border-slate-200 flex items-start gap-3 text-xs">
          <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <span className="font-black text-slate-900">
              {currentSeasonality.label} 대표님을 위한 9월 맞춤 조언:
            </span>
            <p className="text-slate-600 leading-relaxed">
              {currentSeasonality.description}. 
              현재 9월은 <strong>{currentSeasonality.keyDemandDriver}</strong>로 인해 유동성 지출이 연중 최고점입니다. 
              {currentSeasonality.riskFactor}. 예산 소진율이 89.4%에 달하므로 국세·지방세 완납증명서 및 매출 서류를 즉시 준비하여 이번 주 내 신청을 권장합니다.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
