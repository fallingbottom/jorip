import React, { useState, useRef } from 'react';
import { Upload, FileText, CheckCircle2, AlertCircle, RefreshCw, Check, Building2, User, MapPin, Briefcase } from 'lucide-react';

interface ParsedData {
  docType: string | null;
  taxType: string | null;
  bizNo: string | null;
  bizNoValid: boolean;
  corpName: string | null;
  repName: string | null;
  birthDate: string | null;
  openDate: string | null;
  regDate: string | null;
  address: string | null;
  bizStatus: string | null;
  bizItem: string | null;
  taxOffice: string | null;
}

const validateBizNo = (bizNo: string): boolean => {
  const digits = bizNo.replace(/[^0-9]/g, '').split('').map(Number);
  if (digits.length !== 10) return false;
  
  const weights = [1, 3, 7, 1, 3, 7, 1, 3, 5];
  let total = 0;
  for (let i = 0; i < 9; i++) {
    total += digits[i] * weights[i];
  }
  
  total += Math.floor((digits[8] * 5) / 10);
  const remainder = (10 - (total % 10)) % 10;
  return remainder === digits[9];
};

const parseBusinessLicense = (rawText: string): ParsedData => {
  let text = rawText.replace(/“/g, '"').replace(/”/g, '"').replace(/’/g, "'");
  
  const data: Partial<ParsedData> = {};
  
  const docMatch = text.match(/(사업자등록증명|사업자등록증)/);
  data.docType = docMatch ? docMatch[1] : "알수없음";

  const taxMatch = text.match(/\((일반과세자|간이과세자|면세사업자|법인사업자|비영리법인)\)/);
  data.taxType = taxMatch ? taxMatch[1] : "알수없음";

  const bizMatch = text.match(/(?:등록번호|사업자등록번호)\s*[:：]?\s*([0-9]{3}[-\s]?[0-9]{2}[-\s]?[0-9]{5})/);
  if (bizMatch) {
    const rawBiz = bizMatch[1].replace(/[^0-9]/g, "");
    if (rawBiz.length === 10) {
      data.bizNo = `${rawBiz.slice(0,3)}-${rawBiz.slice(3,5)}-${rawBiz.slice(5)}`;
      data.bizNoValid = validateBizNo(rawBiz);
    } else {
      data.bizNo = bizMatch[1];
      data.bizNoValid = false;
    }
  } else {
    data.bizNo = null;
    data.bizNoValid = false;
  }

  const corpMatch = text.match(/(?:상\s*호(?:\s*\(\s*법인명\s*\))?)\s*[:：]?\s*([^\n\r]+)/);
  if (corpMatch) {
    let name = corpMatch[1].split("사업자등록번호")[0].split("성명")[0].trim();
    data.corpName = name.replace(/\s+/g, " ");
  } else {
    data.corpName = null;
  }

  const repMatch = text.match(/(?:성\s*명(?:\s*\(\s*대표자\s*\))?)\s*[:：]?\s*([가-힣a-zA-Z\s]{2,10})/);
  data.repName = repMatch ? repMatch[1].trim() : null;

  const birthMatch = text.match(/생\s*년\s*월\s*일\s*[:：]?\s*(\d{4}\s*년\s*\d{1,2}\s*월\s*\d{1,2}\s*일|\d{4}[.\-/]\d{1,2}[.\-/]\d{1,2})/);
  data.birthDate = birthMatch ? birthMatch[1].trim() : null;

  const openMatch = text.match(/개\s*업(?:\s*연\s*월\s*일|\s*일)\s*[:：]?\s*(\d{4}\s*년\s*\d{1,2}\s*월\s*\d{1,2}\s*일|\d{4}[.\-/]\d{1,2}[.\-/]\d{1,2})/);
  data.openDate = openMatch ? openMatch[1].trim() : null;

  const regMatch = text.match(/사업자등\s*록일\s*[:：]?\s*(\d{4}\s*년\s*\d{1,2}\s*월\s*\d{1,2}\s*일|\d{4}[.\-/]\d{1,2}[.\-/]\d{1,2})/);
  data.regDate = regMatch ? regMatch[1].trim() : null;

  const addrMatch = text.match(/사\s*업\s*장\s*소\s*재\s*지\s*[:：]?\s*([\s\S]+?)(?=\s*(?:사업의\s*종류|개\s*업|업\s*태|$))/);
  if (addrMatch) {
    let cleanAddr = addrMatch[1].replace(/[\r\n]+/g, " ").trim();
    data.address = cleanAddr.replace(/\s+/g, " ");
  } else {
    data.address = null;
  }

  const statusMatch = text.match(/업\s*태\s*[:：]?\s*([^\n\r]+?)(?=\s*(?:종\s*목|발급사유|공동사업자|$))/);
  data.bizStatus = statusMatch ? statusMatch[1].replace(/\s+/g, " ").trim() : null;

  const itemMatch = text.match(/종\s*목\s*[:：]?\s*([^\n\r]+?)(?=\s*(?:발급사유|공동사업자|사업자\s*단위|위와\s*같이|$))/);
  data.bizItem = itemMatch ? itemMatch[1].replace(/\s+/g, " ").trim() : null;

  const officeMatch = text.match(/([가-힣]{2,6}세무서)(?:장)?/);
  data.taxOffice = officeMatch ? officeMatch[1] : null;

  return data as ParsedData;
};

// Mock OCR Data for Demonstration based on user's prompt
const mockOcrTextA = `
사업자등록증
(일반과세자)
등록번호 : 860-02-02840
상  호 : 태준물류
성  명 : 정태준
생 년 월 일 : 1984년 05월 03일
개 업 연 월 일 : 2023년 07월 21일
사 업 장 소 재 지 : 서울특별시 송파구 송파대로38길 21, B01호
(송파동, 우성그린맨션 지층)
사업의 종류: 업태 운수업  종목 택배업 기타물품운반
발급사유 : 신규
송파세무서장
`;

export const BusinessLicenseParser: React.FC = () => {
  const [dragActive, setDragActive] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [parsedData, setParsedData] = useState<ParsedData | null>(null);
  const [isApplied, setIsApplied] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const processSimulatedFile = () => {
    setIsProcessing(true);
    setParsedData(null);
    setIsApplied(false);
    
    // Simulate OCR processing time
    setTimeout(() => {
      const data = parseBusinessLicense(mockOcrTextA);
      setParsedData(data);
      setIsProcessing(false);
    }, 1500);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processSimulatedFile();
    }
  };

  return (
    <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden mb-6">
      <div className="p-6 md:p-8 border-b border-slate-100 bg-gradient-to-r from-blue-50/50 to-indigo-50/50">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-blue-100 flex items-center justify-center text-blue-600 shadow-sm">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900">사업자등록증 AI 자동 분석기</h2>
            <p className="text-xs text-slate-500 font-medium mt-1">
              사업자등록증 이미지를 업로드하면 정규표현식(Regex) 기반 엔진이 핵심 정보를 자동 추출합니다.
            </p>
          </div>
        </div>
      </div>

      <div className="p-6 md:p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Upload Zone */}
        <div className="flex flex-col gap-4">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center text-[10px] text-slate-500">1</span>
            문서 업로드
          </h3>
          
          <div 
            className={`relative flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-2xl transition-all ${
              dragActive 
                ? "border-blue-500 bg-blue-50" 
                : "border-slate-200 bg-slate-50 hover:bg-slate-100/50 hover:border-slate-300"
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            {isProcessing ? (
              <div className="flex flex-col items-center space-y-4">
                <RefreshCw className="w-10 h-10 text-blue-500 animate-spin" />
                <div className="text-center">
                  <p className="text-sm font-bold text-slate-800">문서 인식 및 정보 추출 중...</p>
                  <p className="text-xs text-slate-500 mt-1">OCR 분석 및 정규표현식 매칭 진행</p>
                </div>
              </div>
            ) : (
              <>
                <div className="w-16 h-16 bg-white shadow-sm rounded-full flex items-center justify-center mb-4">
                  <Upload className="w-6 h-6 text-slate-400" />
                </div>
                <div className="text-center space-y-1">
                  <p className="text-sm font-bold text-slate-700">클릭하거나 파일을 이곳에 드롭하세요</p>
                  <p className="text-xs text-slate-500">지원 형식: JPG, PNG, PDF (최대 10MB)</p>
                </div>
                <button 
                  onClick={processSimulatedFile}
                  className="mt-6 px-6 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-50 transition-colors shadow-sm"
                >
                  샘플 파일로 테스트하기
                </button>
              </>
            )}
          </div>
        </div>

        {/* Extracted Data Result */}
        <div className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center text-[10px]">2</span>
              추출된 사업자 정보
            </h3>
            {parsedData && (
              <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 rounded-full text-[10px] font-black flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" />
                추출 완료
              </span>
            )}
          </div>

          <div className="flex-1 bg-slate-50 rounded-2xl border border-slate-100 p-5 overflow-y-auto min-h-[16rem]">
            {!parsedData ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-3 opacity-60">
                <FileText className="w-12 h-12 stroke-1" />
                <p className="text-xs font-medium">업로드된 문서가 없습니다.</p>
              </div>
            ) : (
              <div className="space-y-5 animate-fade-in">
                <div className="flex gap-4">
                  <div className="flex-1 space-y-1">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider flex items-center gap-1">
                      <Building2 className="w-3 h-3" /> 상호 (법인명)
                    </label>
                    <div className="font-bold text-sm text-slate-900 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-xs">
                      {parsedData.corpName || '-'}
                    </div>
                  </div>
                  <div className="flex-1 space-y-1">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider flex items-center gap-1">
                      <User className="w-3 h-3" /> 대표자 성명
                    </label>
                    <div className="font-bold text-sm text-slate-900 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-xs">
                      {parsedData.repName || '-'}
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider">
                    사업자등록번호
                  </label>
                  <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-xs">
                    <span className="font-bold text-sm text-slate-900">{parsedData.bizNo || '-'}</span>
                    {parsedData.bizNoValid ? (
                      <span className="px-1.5 py-0.5 bg-emerald-100 text-emerald-700 rounded text-[9px] font-bold">유효함</span>
                    ) : (
                      <span className="px-1.5 py-0.5 bg-red-100 text-red-700 rounded text-[9px] font-bold flex items-center gap-0.5">
                        <AlertCircle className="w-2.5 h-2.5" /> 형식오류
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex-1 space-y-1">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider">문서 유형</label>
                    <div className="font-medium text-xs text-slate-700 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-xs">
                      {parsedData.docType || '-'}
                    </div>
                  </div>
                  <div className="flex-1 space-y-1">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider">과세 유형</label>
                    <div className="font-medium text-xs text-slate-700 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-xs">
                      {parsedData.taxType || '-'}
                    </div>
                  </div>
                </div>
                
                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider flex items-center gap-1">
                    <MapPin className="w-3 h-3" /> 사업장 소재지
                  </label>
                  <div className="font-medium text-xs text-slate-700 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-xs leading-relaxed">
                    {parsedData.address || '-'}
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-wider flex items-center gap-1">
                    <Briefcase className="w-3 h-3" /> 업태 / 종목
                  </label>
                  <div className="font-medium text-xs text-slate-700 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-xs">
                    <span className="text-slate-400 mr-2">업태:</span> {parsedData.bizStatus || '-'} <br />
                    <span className="text-slate-400 mr-2">종목:</span> {parsedData.bizItem || '-'}
                  </div>
                </div>
              </div>
            )}
          </div>

          <button 
            disabled={!parsedData || isApplied}
            onClick={() => setIsApplied(true)}
            className={`w-full py-3.5 rounded-xl text-sm font-black transition-all shadow-md flex items-center justify-center gap-2 ${
              !parsedData 
                ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                : isApplied
                  ? 'bg-emerald-500 text-white'
                  : 'bg-blue-600 hover:bg-blue-700 text-white active:scale-[0.98]'
            }`}
          >
            {isApplied ? (
              <>
                <Check className="w-4 h-4" /> 내 프로필에 적용 완료
              </>
            ) : (
              '추출된 정보로 프로필 자동 완성'
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
