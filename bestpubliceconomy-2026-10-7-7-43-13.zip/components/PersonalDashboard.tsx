import React, { useState, useEffect, useMemo } from 'react';
import { Activity } from 'lucide-react';
import { PolicyFund, SourcePolicy, UserProfile, SimilarFundRecommendation, AnalysisResult } from '../types';
import { 
  Radar, 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  ResponsiveContainer, 
  Tooltip,
  Legend,
  BarChart,
  CartesianGrid,
  XAxis,
  YAxis,
  Bar
} from 'recharts';
import { 
  Star, 
  Bell, 
  BellRing, 
  Calendar as CalendarIcon, 
  CheckCircle2, 
  AlertTriangle, 
  FileText, 
  ExternalLink, 
  Sparkles, 
  Trash2, 
  Clock, 
  Building2, 
  DollarSign, 
  ChevronRight, 
  Search,
  X,
  Info,
  Smartphone,
  Bot,
  RefreshCw,
  Lightbulb,
  Check,
  Target,
  TrendingUp,
  Zap,
  ArrowUpRight,
  Award,
  ListChecks,
  CheckSquare,
  Square,
  Plus,
  ClipboardList,
  CheckCircle,
  AlertCircle,
  ShieldAlert,
  ShieldCheck,
  HelpCircle,
  Sliders,
  FileCheck,
  BadgeAlert,
  Shield,
  BookOpen,
  FileCheck2,
  Headphones,
  ClipboardCheck,
  Layers,
  MapPin,
  Newspaper
} from 'lucide-react';
import { RealtimePolicyNews } from './RealtimePolicyNews';
import { BusinessLicenseParser } from './BusinessLicenseParser';
import { SuccessStories } from './SuccessStories';
import { FundPdfChecklistModal } from './FundPdfChecklistModal';
import { PushNotificationModal } from './PushNotificationModal';
import { ExpertConsultationModal, ConsultationRequestData } from './ExpertConsultationModal';
import { GoogleFormsManagerModal } from './GoogleFormsManagerModal';
import { FavoritePolicyChangesSummary } from './FavoritePolicyChangesSummary';
import { PolicyApplicationTracker } from './PolicyApplicationTracker';
import { FavoriteFundProgress } from './FavoriteFundProgress';
import { CreditScoreManager } from './CreditScoreManager';
import { FundLoanSimulator } from './FundLoanSimulator';
import { DocumentIssuanceGuide } from './DocumentIssuanceGuide';
import { ConsultationInquiryHistory } from './ConsultationInquiryHistory';
import { GoogleChatHub } from './GoogleChatHub';
import { PolicyFundSeasonalityTrends } from './PolicyFundSeasonalityTrends';
import { matchDocumentToIssuanceInfo } from '../src/utils/documentIssuanceMap';
import { 
  getNotificationPermission, 
  requestNotificationPermission, 
  triggerPushNotification, 
  calculateDaysRemaining,
  checkAndNotifyUpcomingDeadlines
} from '../services/notificationService';
import { createCalendarEvent } from '../services/workspaceService';
import { analyzeSimilarFunds } from '../services/geminiService';
import { fetchLatestPolicyData } from '../services/fundDataSource';

interface PersonalDashboardProps {
  favorites: (PolicyFund | SourcePolicy)[];
  onToggleFavorite: (fund: PolicyFund | SourcePolicy) => void;
  profile?: UserProfile | null;
  result?: AnalysisResult | null;
  token?: string | null;
  onNavigateToMatch?: () => void;
  latestPolicies?: SourcePolicy[];
}

export const PersonalDashboard: React.FC<PersonalDashboardProps> = ({
  favorites = [],
  onToggleFavorite,
  profile,
  result,
  token,
  onNavigateToMatch,
  latestPolicies = [],
}) => {
  const [notificationPerm, setNotificationPerm] = useState(getNotificationPermission());
  const [activeDashboardTab, setActiveDashboardTab] = useState<'ALL' | 'QUICK_CHECK' | 'TRENDS' | 'SCRAPS' | 'CONSULTATIONS' | 'CHAT' | 'RADAR' | 'TRACKER' | 'TOOLS' | 'NEWS'>('ALL');
  const [searchTerm, setSearchType] = useState('');
  const [selectedFund, setSelectedFund] = useState<(PolicyFund | SourcePolicy | SimilarFundRecommendation) | null>(null);
  const [lastCheckMessage, setLastCheckMessage] = useState<string | null>(null);
  const [radarViewMode, setRadarViewMode] = useState<'ALL' | 'ELIGIBILITY' | 'PREDICTED'>('ALL');

  // AI Recommendation State
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [aiResult, setAiResult] = useState<{
    analysisSummary: string;
    recommendations: SimilarFundRecommendation[];
  } | null>(null);

  // Application Checklist State with localStorage persistence
  const [checklistStore, setChecklistStore] = useState<Record<string, { completedDocs: string[]; currentStep: number; customDocs: { id: string; name: string; source?: string }[] }>>(() => {
    try {
      const saved = localStorage.getItem('bizmatch_checklists_v1');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Selected Fund for Checklist
  const [activeChecklistFundTitle, setActiveChecklistFundTitle] = useState<string>('');
  const [quickCheckAnswers, setQuickCheckAnswers] = useState({
    businessType: '개인사업자',
    operatingYears: '1-3',
    creditScore: '700-799',
    revenue: '30-100'
  });
  const [quickCheckResult, setQuickCheckResult] = useState<any>(null);

  const handleQuickCheckSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    let score = 50; // base score
    if (quickCheckAnswers.operatingYears === '0-1') score += 20; // Good for startup funds
    else if (quickCheckAnswers.operatingYears === '1-3') score += 10;
    
    if (quickCheckAnswers.creditScore === '>900') score += 20;
    else if (quickCheckAnswers.creditScore === '800-899') score += 15;
    else if (quickCheckAnswers.creditScore === '700-799') score += 5;
    else if (quickCheckAnswers.creditScore === '<700') score -= 10;
    
    if (quickCheckAnswers.revenue === '>300') score += 10;
    else if (quickCheckAnswers.revenue === '100-300') score += 5;
    
    const eligibilityScore = Math.min(100, Math.max(0, score));
    setQuickCheckResult({
      score: eligibilityScore,
      message: eligibilityScore >= 80 ? '인기 정책자금 승인 확률이 매우 높습니다! 정밀 진단을 받아보세요.' : 
               eligibilityScore >= 60 ? '조건에 맞는 몇 가지 유망한 정책자금이 있습니다.' : 
               '현재는 특정 신용회복 자금 등 제한적인 지원이 가능할 수 있습니다.'
    });
  };

  
  // PDF Announcement Checklist State
  const [pdfChecklistFund, setPdfChecklistFund] = useState<PolicyFund | null>(null);

  // Push Notification Settings Modal State
  const [isPushModalOpen, setIsPushModalOpen] = useState(false);
  const [pushModalTargetFund, setPushModalTargetFund] = useState<any | null>(null);

  // Expert Consultation Modal State
  const [isConsultModalOpen, setIsConsultModalOpen] = useState(false);
  const [consultModalFund, setConsultModalFund] = useState<PolicyFund | SourcePolicy | SimilarFundRecommendation | any | null>(null);
  const [consultSuccessToast, setConsultSuccessToast] = useState<string | null>(null);

  // Google Forms Modal State
  const [isFormsModalOpen, setIsFormsModalOpen] = useState(false);
  const [formsModalTargetFund, setFormsModalTargetFund] = useState<any | null>(null);

  const handleOpenConsultation = (fund: any) => {
    setConsultModalFund(fund);
    setIsConsultModalOpen(true);
  };

  const handleConsultationSuccess = (reqData: ConsultationRequestData) => {
    setConsultSuccessToast(`'${reqData.fundTitle}'에 대한 1:1 비대면 전문 상담 신청이 완료되었습니다.`);
    setTimeout(() => {
      setConsultSuccessToast(null);
    }, 4500);
  };

  const normalizeToPolicyFund = (f: any): PolicyFund => ({
    id: f.id || f.title || f.name || '',
    title: f.title || f.name || '',
    agency: f.agency || '중소벤처기업부',
    category: f.category || '운전자금',
    maxAmount: f.maxAmount || '공식 공고 확인',
    interestRate: f.interestRate || f.baseInterestRate || '변동금리',
    description: f.description || '',
    eligibility: Array.isArray(f.eligibility) ? f.eligibility.join(', ') : (f.eligibility || ''),
    requiredDocuments: f.requiredDocuments || [],
    applicationDeadline: f.applicationDeadline || f.endDate || '상시 접수',
    contactInfo: f.contactInfo || '1357',
    applicationProcedure: f.applicationProcedure || [],
    writingGuide: f.writingGuide || '',
    announcementDate: f.announcementDate || '',
    startDate: f.startDate || '',
    endDate: f.endDate || ''
  });

  const handleOpenPdfChecklist = (fund: any) => {
    if (!fund) return;
    setPdfChecklistFund(normalizeToPolicyFund(fund));
  };
  
  // Selected Fund & Filter for Validation Audit Guide
  const [selectedValidationFundTitle, setSelectedValidationFundTitle] = useState<string>('');
  const [validationFilter, setValidationFilter] = useState<'ALL' | 'GAP_ONLY' | 'MEET_ONLY'>('ALL');

  // Custom Doc Input State
  const [newDocName, setNewDocName] = useState('');
  const [newDocSource, setNewDocSource] = useState('');

  useEffect(() => {
    setNotificationPerm(getNotificationPermission());
  }, []);

  // Fetch AI Recommendations when component mounts or favorites change
  const handleFetchAiRecommendations = async () => {
    setAiLoading(true);
    setAiError(null);
    try {
      const pool = latestPolicies.length > 0 ? latestPolicies : await fetchLatestPolicyData();
      const result = await analyzeSimilarFunds(favorites, pool, profile);
      setAiResult(result);
    } catch (err: any) {
      console.error("Failed to generate AI recommendations", err);
      setAiError(err.message || "AI 연관 자금 분석 중 오류가 발생했습니다.");
    } finally {
      setAiLoading(false);
    }
  };

  useEffect(() => {
    // Automatically trigger AI recommendations if favorites exist and recommendations are not loaded yet
    if (favorites.length > 0 && !aiResult && !aiLoading) {
      handleFetchAiRecommendations();
    }
  }, [favorites.length]);

  const handleRequestPermission = async () => {
    const result = await requestNotificationPermission();
    setNotificationPerm(result);
    if (result === 'granted') {
      triggerPushNotification('🔔 [BizMatch AI] 푸시 알림이 활성화되었습니다', {
        body: '관심 등록한 정책자금의 신청 마감일이 다가오면 브라우저 알림을 전달해 드립니다.',
      });
      setLastCheckMessage('브라우저 푸시 알림 수신 동의가 완료되었습니다.');
    } else if (result === 'denied') {
      alert('브라우저 설정에서 알림 권한이 차단되어 있습니다. 주소창의 차단 설정을 해제해 주세요.');
    }
  };

  const handleTestNotification = () => {
    if (notificationPerm !== 'granted') {
      handleRequestPermission();
      return;
    }
    const success = triggerPushNotification('⏰ [마감 알림 테스트] 소상공인 대환대출', {
      body: '신청 마감일까지 D-3일 남았습니다. 필요 서류(납세증명서, 부가세 증명)를 미리 준비하세요!',
    });
    if (success) {
      setLastCheckMessage('테스트 푸시 알림을 발송했습니다. 화면 우측 상단/시스템 알림을 확인하세요.');
    }
  };

  const handleCheckDeadlinesNow = () => {
    const alerts = checkAndNotifyUpcomingDeadlines(favorites);
    if (alerts.length > 0) {
      setLastCheckMessage(`총 ${alerts.length}건의 마감 임박 자금을 감지하여 푸시 알림을 전송했습니다.`);
    } else {
      setLastCheckMessage('현재 7일 이내 마감 임박 자금이 없거나 알림 권한이 필요합니다.');
    }
  };

  const handleSetCalendarReminder = async (fund: PolicyFund | SourcePolicy | SimilarFundRecommendation) => {
    if (!token) {
      alert("알림을 구글 캘린더에 등록하려면 상단의 [Google 연동] 버튼으로 로그인해 주세요.");
      return;
    }

    const title = 'title' in fund ? fund.title : fund.name;
    const endDate = 'endDate' in fund ? fund.endDate : ('applicationDeadline' in fund ? fund.applicationDeadline : '');

    if (!endDate) {
      alert("마감일 정보가 없어 캘린더 일정을 추가할 수 없습니다.");
      return;
    }

    const confirmMsg = `[구글 캘린더 등록] '${title}' 마감일 일정을 캘린더에 등록하시겠습니까?`;
    if (!window.confirm(confirmMsg)) return;

    try {
      const summary = `🚨 [정책자금 마감] ${title}`;
      const description = `정책자금명: ${title}\n지원기관: ${fund.agency}\n이율: ${'interestRate' in fund ? fund.interestRate : fund.baseInterestRate}\n한도: ${'maxAmount' in fund ? fund.maxAmount : '상세 확인'}\n문의처: ${fund.contactInfo || '1357'}`;
      const startDateTime = `${endDate}T09:00:00`;
      const endDateTime = `${endDate}T18:00:00`;

      await createCalendarEvent(token, summary, description, startDateTime, endDateTime);
      alert(`'${title}' 마감 일정이 구글 캘린더에 성공적으로 등록되었습니다!`);
    } catch (err) {
      console.error(err);
      alert("캘린더 일정 등록에 실패했습니다. 권한을 확인해주세요.");
    }
  };

  const isFavorited = (title: string) => {
    return favorites.some(item => {
      const name = 'title' in item ? item.title : item.name;
      return name === title;
    });
  };

  // Calculate radar chart dataset for eligibility progress and predicted approval rates
  const radarData = useMemo(() => {
    let health = {
      growthPotential: 75,
      financialStability: 80,
      creditWorthiness: 85,
      policyFit: 88,
      innovation: 70,
      expectedProfitMargin: 78,
      cashFlowStatus: 72,
    };

    if (result?.businessHealth) {
      health = result.businessHealth;
    } else if (profile) {
      const creditScore = profile.creditScore || 750;
      const creditVal = Math.min(100, Math.max(50, Math.round((creditScore / 1000) * 100)));
      const debtTotal = (profile.debt1Tier || 0) + (profile.debt2Tier || 0) * 1.5 + (profile.debtCardLoan || 0) * 2;
      const finVal = Math.max(45, Math.min(95, 90 - Math.round(debtTotal / 10000000)));
      
      health = {
        growthPotential: profile.annualRevenue > 500000000 ? 90 : profile.annualRevenue > 100000000 ? 80 : 70,
        financialStability: finVal,
        creditWorthiness: creditVal,
        policyFit: profile.industry ? 88 : 75,
        innovation: profile.businessType === 'CORPORATION' ? 82 : 72,
        expectedProfitMargin: profile.expectedProfitMargin || 76,
        cashFlowStatus: profile.cashFlowStatus || 74,
      };
    }

    return [
      {
        subject: '성장성',
        eligibility: health.growthPotential,
        predictedApproval: Math.min(98, health.growthPotential + 8),
      },
      {
        subject: '재무안정성',
        eligibility: health.financialStability,
        predictedApproval: Math.min(98, health.financialStability + 6),
      },
      {
        subject: '신용도',
        eligibility: health.creditWorthiness,
        predictedApproval: Math.min(99, health.creditWorthiness + 5),
      },
      {
        subject: '정책적합성',
        eligibility: health.policyFit,
        predictedApproval: Math.min(98, health.policyFit + 7),
      },
      {
        subject: '혁신성',
        eligibility: health.innovation,
        predictedApproval: Math.min(95, health.innovation + 10),
      },
      {
        subject: '수익성',
        eligibility: health.expectedProfitMargin,
        predictedApproval: Math.min(96, health.expectedProfitMargin + 6),
      },
      {
        subject: '현금흐름',
        eligibility: health.cashFlowStatus,
        predictedApproval: Math.min(97, health.cashFlowStatus + 9),
      },
    ];
  }, [result, profile]);

  const overallEligibilityScore = useMemo(() => {
    if (result?.eligibilityScore) return result.eligibilityScore;
    const sum = radarData.reduce((acc, curr) => acc + curr.eligibility, 0);
    return Math.round(sum / radarData.length);
  }, [result, radarData]);

  const overallPredictedApprovalRate = useMemo(() => {
    const sum = radarData.reduce((acc, curr) => acc + curr.predictedApproval, 0);
    return Math.min(98, Math.round(sum / radarData.length));
  }, [radarData]);

  // List of all fund titles available for checklist selection
  const allAvailableFundTitles = useMemo(() => {
    const titles = favorites.map(f => ('title' in f ? f.title : f.name));
    const defaults = ['소상공인 대환대출', '창업유망 특례보증', '성장촉진 특별자금', '재도전 특별자금'];
    const set = new Set([...titles, ...defaults]);
    return Array.from(set);
  }, [favorites]);

  // Set default active fund for checklist & validation audit if empty
  useEffect(() => {
    if (!activeChecklistFundTitle && allAvailableFundTitles.length > 0) {
      setActiveChecklistFundTitle(allAvailableFundTitles[0]);
    }
    if (!selectedValidationFundTitle && allAvailableFundTitles.length > 0) {
      setSelectedValidationFundTitle(allAvailableFundTitles[0]);
    }
  }, [allAvailableFundTitles, activeChecklistFundTitle, selectedValidationFundTitle]);

  // Comprehensive Requirement Validation Report comparing user profile against policy announcement criteria
  const validationAuditReport = useMemo(() => {
    const creditScore = profile?.creditScore || 720;
    const debt2Tier = profile?.debt2Tier || 0;
    const debtCardLoan = profile?.debtCardLoan || 0;
    const foundedYear = parseInt(profile?.foundedYear || '2022', 10);
    const operatingYears = Math.max(1, 2026 - foundedYear);
    const revenue = profile?.annualRevenue || 150000000;
    const employees = profile?.employees || 3;
    const industry = profile?.industry || 'IT_SOFTWARE';

    // Item 1: Credit Score & Debt Structure
    const creditStatus = (creditScore >= 720 && debtCardLoan === 0) ? 'MEETS' : (creditScore >= 600 || debt2Tier > 0) ? 'WARNING' : 'UNMET';
    const itemCredit = {
      id: 'req-credit',
      category: '신용평점 및 부채 비율 요건',
      policyReq: 'KCB/NICE 신용평점 600점 이상 (우대 720점 이상), 2금융권 카드론/캐피탈 대출 비중 20% 이하 권장',
      userReality: `현재 신용평점: ${creditScore}점 / 2금융권 부채: ${(debt2Tier + debtCardLoan).toLocaleString()}원`,
      status: creditStatus as 'MEETS' | 'WARNING' | 'UNMET',
      statusText: creditStatus === 'MEETS' ? '요건 충족' : creditStatus === 'WARNING' ? '보완 필요 (2금융권 대출)' : '미달 (신용평점 부족)',
      gapSummary: creditStatus !== 'MEETS'
        ? `2금융권 카드론 및 캐피탈 채무(${(debt2Tier + debtCardLoan).toLocaleString()}원) 보유로 인해 보증재단 심사 시 한도 차감(최대 -30%) 또는 감점 우려가 있습니다.`
        : undefined,
      actionPlan: creditStatus !== 'MEETS'
        ? '① 소상공인 대환대출 자금을 신청하여 2금융권 카드론 채무를 1금융권 장기저리 자금으로 전액 전환하세요. (신용평점 35~50점 즉시 상승 효과)\n② 신용보증재단 "소상공인 신용회복 지원 컨설팅" 이수 시 가점 5점 부여.'
        : '신용도 및 부채 구조가 우수하여 최우선 보증 승인 심사 대상입니다.',
      documents: ['금융거래확인서', '부채 상환 확약서', '신용평점 상세 보고서']
    };

    // Item 2: Business Operating Age
    const ageStatus = operatingYears <= 7 ? 'MEETS' : 'UNMET';
    const itemAge = {
      id: 'req-age',
      category: '업력 및 창업 연차 요건',
      policyReq: '창업 7년 이내 소상공인 및 중소기업 (창업기업 특례 적용 대상)',
      userReality: `사업 개업연도: ${foundedYear}년 (현재 업력 ${operatingYears}년차)`,
      status: ageStatus as 'MEETS' | 'WARNING' | 'UNMET',
      statusText: ageStatus === 'MEETS' ? '요건 충족 (7년 이내)' : '미달 (창업 7년 초과)',
      gapSummary: ageStatus === 'UNMET'
        ? `현재 업력이 ${operatingYears}년으로 '창업 7년 이내' 전용 특례자금의 신청 연차 범위를 초과하였습니다.`
        : undefined,
      actionPlan: ageStatus === 'UNMET'
        ? '① 일반 "경영안정자금" 또는 "성장촉진자금" 트랙으로 지원 방향을 전환하세요.\n② 벤처기업 인증 또는 기술혁신형(Inno-Biz) 인증 취득 시 업력 제한 예외(최대 10년)가 적용됩니다.'
        : '창업기업 특례 자격에 적합하며 우대 보증 비율(90~95%)이 적용됩니다.',
      documents: ['사업자등록증명원', '법인 등기부등본']
    };

    // Item 3: Revenue & Financial Scale
    const revenueStatus = (revenue >= 30000000 && revenue <= 5000000000) ? 'MEETS' : 'WARNING';
    const itemRevenue = {
      id: 'req-revenue',
      category: '매출액 및 재무 안정성 요건',
      policyReq: '연간 매출액 3,000만원 이상 ~ 50억원 이하 (직전 연도 대비 매출 유지 또는 성장)',
      userReality: `연간 매출액: ${revenue.toLocaleString()}원 (영업이익률 추정 ${profile?.expectedProfitMargin || 75}%)`,
      status: revenueStatus as 'MEETS' | 'WARNING' | 'UNMET',
      statusText: revenueStatus === 'MEETS' ? '요건 충족' : '보완 필요 (매출 입증)',
      gapSummary: revenueStatus !== 'MEETS'
        ? '최근 분기 매출 누계액 증빙이 누락되거나 매출 규모 대비 대출 상환 여력 소명이 필요합니다.'
        : undefined,
      actionPlan: '부가가치세 과세표준증명서 제출 시 최근 3개년 매출 상승 추이 및 사업 확장 계획서를 함께 첨부하면 미래 가치 평가 가점이 부여됩니다.',
      documents: ['부가가치세 과세표준증명원(3년)', '매출 통장 거래 내역서']
    };

    // Item 4: Employees & Industry Scale
    const empStatus = employees < 5 ? 'MEETS' : 'WARNING';
    const itemEmp = {
      id: 'req-emp',
      category: '상시 근로자 및 고용 유지 요건',
      policyReq: '상시 근로자 수 5인 미만 (제조업/건설업/운수업은 10인 미만) 소상공인 요건',
      userReality: `상시 근로자 수: ${employees}명 / 업종: ${industry}`,
      status: empStatus as 'MEETS' | 'WARNING' | 'UNMET',
      statusText: empStatus === 'MEETS' ? '소상공인 요건 충족' : '중소기업 트랙 적용 권장',
      gapSummary: empStatus !== 'MEETS'
        ? '상시 근로자 5인 이상으로 소상공인 단독 특례 트랙 신청 시 세부 확인 절차가 추가됩니다.'
        : undefined,
      actionPlan: empStatus !== 'MEETS'
        ? '중소벤처기업진흥공단 "일자리 창출 촉진자금" 트랙으로 재분류하면 근로자 1인당 0.1%p 금리 감면 혜택과 한도 확대가 가능합니다.'
        : '소상공인 간이 요건을 모두 충족하며 신속 심사 패스트트랙 대상입니다.',
      documents: ['4대보험 가입자 명부', '원천징수이행상황신고서']
    };

    // Item 5: Tax Payment & Clean Default Record
    const itemTax = {
      id: 'req-tax',
      category: '세금 체납 및 금융 연체 여부',
      policyReq: '국세 및 지방세 체납 내역 없음, 금융기관 연체 및 신용도 판단 정보 미등록',
      userReality: '체납/연체 내역 없음 (마이데이터 실시간 검증 완료)',
      status: 'MEETS' as const,
      statusText: '요건 완전 충족',
      actionPlan: '국세 및 지방세 완납증명서는 발급일 기준 30일간 유효하므로 접수 당일 최신본을 발급하여 제출하세요.',
      documents: ['국세 완납증명서', '지방세 완납증명서']
    };

    // Item 6: Bonus Points & Value Addition
    const itemBonus = {
      id: 'req-bonus',
      category: '우대 가점 및 정책 합치도',
      policyReq: '소상공인 무료 컨설팅 이수, 특허/지식재산권, 고용창출 우수기업 (최대 10점 가점)',
      userReality: '기본 가점 확보 (추가 보완 시 승인 확률 15% 상승 가능)',
      status: 'WARNING' as const,
      statusText: '가점 보완 권장 (+10점 가능)',
      gapSummary: '기본 요건은 충족하나, 예산 소진 전 우선 지원을 위해 우대 가점(5~10점)을 추가 확보하는 것이 유리합니다.',
      actionPlan: '① 소상공인시장진흥공단 무료 온라인 교육(4시간) 수강 시 가점 5점 및 금리 0.2%p 우대 쿠폰 즉시 발급.\n② 주거래은행 금융거래 확인서 제출.',
      documents: ['컨설팅 이수 확인서', '주거래은행 우대 거래 내역']
    };

    const allItems = [itemCredit, itemAge, itemRevenue, itemEmp, itemTax, itemBonus];
    const meetsCount = allItems.filter(i => i.status === 'MEETS').length;
    const warningCount = allItems.filter(i => i.status === 'WARNING').length;
    const unmetCount = allItems.filter(i => i.status === 'UNMET').length;
    const complianceRate = Math.round((meetsCount / allItems.length) * 100);

    return {
      allItems,
      meetsCount,
      warningCount,
      unmetCount,
      complianceRate,
      currentFundTitle: selectedValidationFundTitle || allAvailableFundTitles[0] || '정책자금'
    };
  }, [selectedValidationFundTitle, allAvailableFundTitles, profile]);

  // Persist checklist store to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('bizmatch_checklists_v1', JSON.stringify(checklistStore));
    } catch (e) {
      console.error("Failed to save checklist state", e);
    }
  }, [checklistStore]);

  // Handlers for Checklist operations
  const handleToggleDoc = (fundTitle: string, docName: string) => {
    setChecklistStore(prev => {
      const current = prev[fundTitle] || { completedDocs: [], currentStep: 1, customDocs: [] };
      const exists = current.completedDocs.includes(docName);
      const newCompleted = exists
        ? current.completedDocs.filter(d => d !== docName)
        : [...current.completedDocs, docName];
      return {
        ...prev,
        [fundTitle]: { ...current, completedDocs: newCompleted }
      };
    });
  };

  const handleSetStep = (fundTitle: string, stepNumber: number) => {
    setChecklistStore(prev => {
      const current = prev[fundTitle] || { completedDocs: [], currentStep: 1, customDocs: [] };
      return {
        ...prev,
        [fundTitle]: { ...current, currentStep: stepNumber }
      };
    });
  };

  const handleAddCustomDoc = (fundTitle: string) => {
    if (!newDocName.trim()) return;
    const newDocObj = {
      id: `custom-${Date.now()}`,
      name: newDocName.trim(),
      source: newDocSource.trim() || '사용자 직접 추가'
    };
    setChecklistStore(prev => {
      const current = prev[fundTitle] || { completedDocs: [], currentStep: 1, customDocs: [] };
      return {
        ...prev,
        [fundTitle]: {
          ...current,
          customDocs: [...(current.customDocs || []), newDocObj]
        }
      };
    });
    setNewDocName('');
    setNewDocSource('');
  };

  const handleRemoveCustomDoc = (fundTitle: string, docId: string, docName: string) => {
    setChecklistStore(prev => {
      const current = prev[fundTitle] || { completedDocs: [], currentStep: 1, customDocs: [] };
      return {
        ...prev,
        [fundTitle]: {
          ...current,
          completedDocs: current.completedDocs.filter(d => d !== docName),
          customDocs: (current.customDocs || []).filter(d => d.id !== docId)
        }
      };
    });
  };

  // Current active fund for checklist
  const currentChecklistFundObj = useMemo(() => {
    return favorites.find(f => ('title' in f ? f.title : f.name) === activeChecklistFundTitle);
  }, [favorites, activeChecklistFundTitle]);

  const currentStepData = checklistStore[activeChecklistFundTitle] || { completedDocs: [], currentStep: 1, customDocs: [] };

  const DEFAULT_REQUIRED_DOCS = useMemo(() => [
    { id: 'doc-1', name: '사업자등록증명원 (최근 1개월 이내 발급)', source: '국세청 홈택스 / 정부24' },
    { id: 'doc-2', name: '부가가치세 과세표준증명원 (최근 3개년)', source: '국세청 홈택스' },
    { id: 'doc-3', name: '국세 완납증명서 (신용평가용)', source: '국세청 홈택스' },
    { id: 'doc-4', name: '지방세 완납증명서 (사업장 및 대표자)', source: '정부24 / 위택스' },
    { id: 'doc-5', name: '주사업장 임대차계약서 사본 또는 건물등기부등본', source: '자체 소지 서류' },
    { id: 'doc-6', name: '금융거래확인서 (부채 및 기존 대출 현황)', source: '주거래 은행 발급' },
  ], []);

  const STANDARD_STEPS = useMemo(() => [
    { step: 1, title: '서류 발급 및 사전 자격검증', desc: '국세청/정부24 발급 서류 6종 준비 및 자격 조건 체크' },
    { step: 2, title: '온라인/기관 방문 신청 접수', desc: '주관기관 시스템 접속 후 자금 신청서 작성 및 제출' },
    { step: 3, title: '현장 실사 및 보증 심사', desc: '사업장 현장 확인, 대표자 면담 및 신용보증 심사' },
    { step: 4, title: '최종 약정체결 및 자금 집행', desc: '협약 은행 방문 전자 서명 후 대출금 통장 입금' },
  ], []);

  const allDocsForActiveFund = useMemo(() => {
    let base = DEFAULT_REQUIRED_DOCS;
    if (currentChecklistFundObj && 'requiredDocuments' in currentChecklistFundObj && Array.isArray(currentChecklistFundObj.requiredDocuments) && currentChecklistFundObj.requiredDocuments.length > 0) {
      base = currentChecklistFundObj.requiredDocuments.map((doc, idx) => ({
        id: `fund-doc-${idx}`,
        name: doc,
        source: '공고문 필수 제출 서류'
      }));
    }

    const customs = (currentStepData.customDocs || []).map(cd => ({
      id: cd.id,
      name: cd.name,
      source: cd.source,
      isCustom: true
    }));

    return [...base, ...customs];
  }, [currentChecklistFundObj, currentStepData.customDocs, DEFAULT_REQUIRED_DOCS]);

  const completedDocsCount = currentStepData.completedDocs.length;
  const docProgressPercentage = allDocsForActiveFund.length > 0
    ? Math.round((completedDocsCount / allDocsForActiveFund.length) * 100)
    : 0;

  const overallProgress = Math.min(100, Math.round(docProgressPercentage * 0.6 + (currentStepData.currentStep / 4) * 40));

  // Filtered favorites
  const filteredFavorites = favorites.filter(item => {
    const name = 'title' in item ? item.title : item.name;
    const agency = item.agency;
    return name.toLowerCase().includes(searchTerm.toLowerCase()) || agency.toLowerCase().includes(searchTerm.toLowerCase());
  });

  // Calculate statistics
  
  const favoriteComparisonData = useMemo(() => {
    return filteredFavorites.map(f => {
      const name = 'title' in f ? f.title : f.name;
      const rawAmt = 'maxAmount' in f ? f.maxAmount : '';
      let limitValue = 0;
      if (rawAmt) {
        let isEok = rawAmt.includes('억');
        let digits = rawAmt.replace(/[^0-9]/g, '');
        limitValue = parseInt(digits, 10);
        if (isNaN(limitValue)) limitValue = 0;
        
        if (isEok && limitValue < 100) {
          limitValue = limitValue * 10000;
        } else if (rawAmt.includes('백만')) {
          limitValue = limitValue * 100;
        } else if (rawAmt.includes('천만')) {
          limitValue = limitValue * 1000;
        } else if (limitValue > 1000000) {
          limitValue = Math.round(limitValue / 10000);
        }
      }

      const interestStr = 'interestRate' in f ? f.interestRate : f.baseInterestRate;
      let interestValue = 0;
      if (interestStr) {
        const match = interestStr.match(/(\d+\.?\d*)\s*%/);
        if (match) {
          interestValue = parseFloat(match[1]);
        } else {
          const digits = interestStr.match(/(\d+\.?\d*)/);
          if (digits) {
            interestValue = parseFloat(digits[1]);
          }
        }
      }
      return {
        name: name.length > 8 ? name.substring(0, 8) + '...' : name,
        fullName: name,
        limit: limitValue,
        interest: interestValue
      };
    });
  }, [filteredFavorites]);
const totalFavoriteCount = favorites.length;
  
  const upcomingDeadlinesCount = favorites.filter(item => {
    const endDate = 'endDate' in item ? item.endDate : ('applicationDeadline' in item ? item.applicationDeadline : '');
    const days = calculateDaysRemaining(String(endDate || ''));
    return days >= 0 && days <= 7;
  }).length;
  
  const urgentDeadlineFunds = favorites.filter(item => {
    const endDate = 'endDate' in item ? item.endDate : ('applicationDeadline' in item ? item.applicationDeadline : '');
    const days = calculateDaysRemaining(String(endDate || ''));
    return days >= 0 && days <= 3;
  });

  const totalMaxAmountSum = favorites.reduce((sum, item) => {
    const rawAmt = 'maxAmount' in item ? item.maxAmount : '';
    if (!rawAmt) return sum;
    const digits = rawAmt.replace(/[^0-9]/g, '');
    const val = parseInt(digits, 10);
    return !isNaN(val) ? sum + val : sum;
  }, 0);

  const formatAmountSum = (sumWon: number) => {
    if (sumWon >= 100000000) {
      return `${(sumWon / 100000000).toFixed(1)}억원`;
    } else if (sumWon >= 10000) {
      return `${(sumWon / 10000).toLocaleString()}만원`;
    }
    return sumWon > 0 ? `${sumWon.toLocaleString()}원` : '상세 확인';
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-fade-in pb-16">
      
      {/* Personalized Header Banner */}
      {urgentDeadlineFunds.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-4 mb-6 shadow-sm flex items-start sm:items-center gap-3 animate-fade-in print:hidden">
          <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0 animate-pulse">
            <AlertTriangle className="w-5 h-5 text-red-600" />
          </div>
          <div className="flex-1">
            <h3 className="text-red-800 font-black text-sm mb-0.5">⚠️ 마감 임박 (3일 이내) 자금이 있습니다!</h3>
            <p className="text-red-600 text-xs font-medium">
              즐겨찾기한 자금 중 <span className="font-bold underline">{urgentDeadlineFunds.length}건</span>의 신청 기한이 3일 이내로 다가왔습니다. 서둘러 확인해주세요.
            </p>
          </div>
          <button 
            onClick={() => {
              const el = document.getElementById('scraps-section');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg transition-colors flex-shrink-0"
          >
            바로가기
          </button>
        </div>
      )}
      
      {/* Personalized Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-900 rounded-3xl p-6 md:p-8 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-xs font-bold text-blue-200 mb-3 border border-white/10">
              <Sparkles className="w-3.5 h-3.5 text-amber-300" /> MY 개인화 대시보드
            </div>
            <h1 className="text-2xl md:text-3xl font-black tracking-tight mb-2">
              {profile?.businessName ? `${profile.businessName} 대표님` : '소상공인 대표님'}의 자금 스크랩북
            </h1>
            <p className="text-xs md:text-sm text-slate-300 font-medium max-w-xl leading-relaxed">
              관심 있는 정책자금을 한곳에서 관리하고, 신청 마감 전 브라우저 푸시 알림과 구글 캘린더 연동으로 놓치지 마세요.
            </p>
          </div>

          <div className="flex items-center gap-3 self-stretch md:self-auto">
            {onNavigateToMatch && (
              <button
                onClick={onNavigateToMatch}
                className="w-full md:w-auto px-5 py-3 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-bold text-xs md:text-sm transition-all shadow-lg shadow-blue-600/30 active:scale-95 flex items-center justify-center gap-2"
              >
                <Search className="w-4 h-4" />
                <span>AI 자금 추천받기</span>
              </button>
            )}
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-8 pt-6 border-t border-white/10">
          <div className="bg-white/5 backdrop-blur-sm p-4 rounded-2xl border border-white/10">
            <div className="flex items-center gap-2 text-slate-300 text-xs font-bold mb-1">
              <Star className="w-4 h-4 text-amber-400 fill-amber-400" /> 즐겨찾기 자금
            </div>
            <div className="text-2xl font-black text-white">{totalFavoriteCount}<span className="text-xs text-slate-400 font-bold ml-1">건</span></div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm p-4 rounded-2xl border border-white/10">
            <div className="flex items-center gap-2 text-slate-300 text-xs font-bold mb-1">
              <DollarSign className="w-4 h-4 text-emerald-400" /> 최대 지원 가능액
            </div>
            <div className="text-2xl font-black text-white">{formatAmountSum(totalMaxAmountSum)}</div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm p-4 rounded-2xl border border-white/10">
            <div className="flex items-center gap-2 text-slate-300 text-xs font-bold mb-1">
              <Clock className="w-4 h-4 text-red-400" /> 마감 임박 (7일 이내)
            </div>
            <div className="text-2xl font-black text-white">{upcomingDeadlinesCount}<span className="text-xs text-slate-400 font-bold ml-1">건</span></div>
          </div>

          <div className="bg-white/5 backdrop-blur-sm p-4 rounded-2xl border border-white/10">
            <div className="flex items-center gap-2 text-slate-300 text-xs font-bold mb-1">
              <Bell className="w-4 h-4 text-indigo-400" /> 푸시 알림 상태
            </div>
            <div className="text-sm font-black text-white flex items-center gap-1.5 mt-1">
              {notificationPerm === 'granted' ? (
                <span className="text-emerald-400 flex items-center gap-1"><CheckCircle2 className="w-4 h-4" /> 수신 활성화</span>
              ) : notificationPerm === 'denied' ? (
                <span className="text-red-400 flex items-center gap-1"><AlertTriangle className="w-4 h-4" /> 권한 차단됨</span>
              ) : (
                <span className="text-amber-300 flex items-center gap-1"><Info className="w-4 h-4" /> 권한 설정 필요</span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Dashboard Sub-Tab Navigation Bar */}
      <div className="bg-white p-2 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-1.5 overflow-x-auto no-scrollbar print:hidden">
        <button
          type="button"
          onClick={() => setActiveDashboardTab('ALL')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeDashboardTab === 'ALL'
              ? 'bg-slate-900 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>전체 모아보기</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveDashboardTab('QUICK_CHECK')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeDashboardTab === 'QUICK_CHECK'
              ? 'bg-rose-500 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Zap className="w-3.5 h-3.5" />
          <span>Quick Check (사전진단)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveDashboardTab('TRENDS')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeDashboardTab === 'TRENDS'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <TrendingUp className="w-3.5 h-3.5 text-blue-500" />
          <span>3개월 자금추이 & 계절성</span>
          <span className="px-1.5 py-0.5 text-[9px] bg-blue-100 text-blue-800 rounded-full font-black">
            추천
          </span>
        </button>

        <button
          type="button"
          onClick={() => setActiveDashboardTab('SCRAPS')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeDashboardTab === 'SCRAPS'
              ? 'bg-amber-500 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Star className="w-3.5 h-3.5" />
          <span>스크랩 자금 ({totalFavoriteCount})</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveDashboardTab('CONSULTATIONS')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeDashboardTab === 'CONSULTATIONS'
              ? 'bg-indigo-600 text-white shadow-sm'
              : 'text-indigo-700 bg-indigo-50/70 hover:bg-indigo-100 border border-indigo-200/60'
          }`}
        >
          <Headphones className="w-3.5 h-3.5" />
          <span>1:1 상담 문의 내역 (Firestore)</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveDashboardTab('RADAR')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeDashboardTab === 'RADAR'
              ? 'bg-blue-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Target className="w-3.5 h-3.5" />
          <span>AI 진단 & 요건 심사</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveDashboardTab('TRACKER')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeDashboardTab === 'TRACKER'
              ? 'bg-purple-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <FileCheck2 className="w-3.5 h-3.5" />
          <span>단계별 신청 트래커</span>
        </button>

        <button
          type="button"
          onClick={() => setActiveDashboardTab('TOOLS')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeDashboardTab === 'TOOLS'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          <span>대출 시뮬레이터 & 신용관리</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveDashboardTab('NEWS')}
          className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
            activeDashboardTab === 'NEWS'
              ? 'bg-sky-500 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          <Newspaper className="w-3.5 h-3.5" />
          <span>오늘의 정책 뉴스</span>
        </button>
      </div>

      {/* 3-MONTH POLICY FUND TRENDS & FINANCIAL SEASONALITY ANALYSIS */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'TRENDS') && (
        <PolicyFundSeasonalityTrends 
          profile={profile}
          latestPolicies={latestPolicies}
          onNavigateToMatch={onNavigateToMatch}
        />
      )}

      {/* QUICK CHECK TAB */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'QUICK_CHECK') && (
        <div className="bg-white rounded-3xl p-6 md:p-8 shadow-sm border border-slate-100 space-y-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl font-black text-slate-900">Quick Check (사전 1분 진단)</h2>
              <p className="text-xs font-bold text-slate-500">본격적인 프로필 작성 전, 주요 항목만으로 인기 정책자금 승인 가능성을 가늠해보세요.</p>
            </div>
          </div>
          
          <form onSubmit={handleQuickCheckSubmit} className="space-y-4 bg-slate-50 p-6 rounded-2xl border border-slate-100">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">사업자 형태</label>
                <select 
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium"
                  value={quickCheckAnswers.businessType}
                  onChange={e => setQuickCheckAnswers(prev => ({...prev, businessType: e.target.value}))}
                >
                  <option value="개인사업자">개인사업자</option>
                  <option value="법인사업자">법인사업자</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">업력 (영업 기간)</label>
                <select 
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium"
                  value={quickCheckAnswers.operatingYears}
                  onChange={e => setQuickCheckAnswers(prev => ({...prev, operatingYears: e.target.value}))}
                >
                  <option value="0-1">1년 미만 (예비/초기창업)</option>
                  <option value="1-3">1년 ~ 3년</option>
                  <option value="3-7">3년 ~ 7년</option>
                  <option value=">7">7년 초과</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">신용 점수 (추정)</label>
                <select 
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium"
                  value={quickCheckAnswers.creditScore}
                  onChange={e => setQuickCheckAnswers(prev => ({...prev, creditScore: e.target.value}))}
                >
                  <option value=">900">900점 이상 (우수)</option>
                  <option value="800-899">800점대 (양호)</option>
                  <option value="700-799">700점대 (보통)</option>
                  <option value="<700">700점 미만 (취약)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">연간 예상 매출</label>
                <select 
                  className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-sm font-medium"
                  value={quickCheckAnswers.revenue}
                  onChange={e => setQuickCheckAnswers(prev => ({...prev, revenue: e.target.value}))}
                >
                  <option value="<30">3천만원 미만</option>
                  <option value="30-100">3천만원 ~ 1억원</option>
                  <option value="100-300">1억원 ~ 3억원</option>
                  <option value=">300">3억원 이상</option>
                </select>
              </div>
            </div>
            <div className="flex justify-end pt-2">
              <button 
                type="submit"
                className="px-6 py-3 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-xl text-sm transition-colors flex items-center gap-2"
              >
                <Activity className="w-4 h-4" /> 진단 점수 확인하기
              </button>
            </div>
          </form>

          {quickCheckResult && (
            <div className="mt-6 p-6 rounded-2xl border bg-white animate-fade-in flex items-center gap-6"
                 style={{ borderColor: quickCheckResult.score >= 80 ? '#10b981' : quickCheckResult.score >= 60 ? '#f59e0b' : '#ef4444' }}>
              <div className="flex-shrink-0 text-center">
                <div className="text-4xl font-black" style={{ color: quickCheckResult.score >= 80 ? '#10b981' : quickCheckResult.score >= 60 ? '#f59e0b' : '#ef4444' }}>
                  {quickCheckResult.score}점
                </div>
                <div className="text-xs font-bold text-slate-500 mt-1">사전 적합도</div>
              </div>
              <div>
                <p className="text-sm font-bold text-slate-800 leading-relaxed mb-2">
                  {quickCheckResult.message}
                </p>
                <button 
                  onClick={onNavigateToMatch}
                  className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 bg-indigo-50 px-3 py-1.5 rounded-lg transition-colors"
                >
                  정밀 분석(매칭) 시작하기 <ChevronRight className="w-3 h-3" />
                </button>
              </div>
            </div>
          )}
        </div>
      )}
      {/* If CONSULTATIONS Tab is active, show only ConsultationInquiryHistory */}
      {activeDashboardTab === 'CONSULTATIONS' && (
        <div className="space-y-6">
          <ConsultationInquiryHistory
            token={token}
            profile={profile}
            onOpenConsultationModal={handleOpenConsultation}
            favorites={favorites}
          />
        </div>
      )}

      {/* Visual Eligibility Progress & Predicted Approval Rates Radar Chart (Shown when ALL or RADAR) */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'RADAR') && (
      <>
      <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-slate-100 space-y-6">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 bg-blue-50 text-blue-700 rounded-full text-xs font-black mb-2 border border-blue-100">
              <Target className="w-3.5 h-3.5 text-blue-600" /> AI 진단 레이다 차트
            </div>
            <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
              자격 적합도 진척도 & 예측 승인율 분석
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-1">
              사업장의 7대 핵심 역량 지표별 자격 적합도와 자금 수혜 예측 승인율 시뮬레이션을 한눈에 시각화합니다.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-100 p-1 rounded-2xl shrink-0">
            <button
              onClick={() => setRadarViewMode('ALL')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                radarViewMode === 'ALL'
                  ? 'bg-white text-slate-900 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              전체 비교
            </button>
            <button
              onClick={() => setRadarViewMode('ELIGIBILITY')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                radarViewMode === 'ELIGIBILITY'
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              자격 적합도만
            </button>
            <button
              onClick={() => setRadarViewMode('PREDICTED')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                radarViewMode === 'PREDICTED'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              예측 승인율만
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Radar Chart Container */}
          <div className="lg:col-span-7 h-80 sm:h-96 w-full relative bg-slate-50/50 rounded-2xl p-4 border border-slate-100 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="75%" data={radarData}>
                <PolarGrid stroke="#e2e8f0" strokeDasharray="3 3" />
                <PolarAngleAxis 
                  dataKey="subject" 
                  tick={{ fill: '#334155', fontSize: 12, fontWeight: 700 }} 
                />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#94a3b8', fontSize: 10 }} />
                
                {(radarViewMode === 'ALL' || radarViewMode === 'ELIGIBILITY') && (
                  <Radar
                    name="현재 자격 적합도 (%)"
                    dataKey="eligibility"
                    stroke="#3b82f6"
                    fill="#3b82f6"
                    fillOpacity={0.4}
                    strokeWidth={2.5}
                  />
                )}

                {(radarViewMode === 'ALL' || radarViewMode === 'PREDICTED') && (
                  <Radar
                    name="예측 승인율 (%)"
                    dataKey="predictedApproval"
                    stroke="#10b981"
                    fill="#10b981"
                    fillOpacity={0.25}
                    strokeWidth={2.5}
                    strokeDasharray={radarViewMode === 'ALL' ? '4 4' : undefined}
                  />
                )}

                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#0f172a', 
                    borderRadius: '16px', 
                    border: 'none', 
                    color: '#ffffff',
                    padding: '12px 16px',
                    boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.3)'
                  }}
                  itemStyle={{ fontSize: '12px', fontWeight: 700 }}
                  labelStyle={{ color: '#94a3b8', fontSize: '11px', fontWeight: 800, marginBottom: '4px' }}
                  formatter={(value: any, name: string) => [`${value}%`, name]}
                />
                <Legend 
                  wrapperStyle={{ paddingTop: '10px', fontSize: '12px', fontWeight: 700 }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>

          {/* Right Metrics & Analysis Card */}
          <div className="lg:col-span-5 space-y-4">
            {/* Score Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-blue-50/70 p-4 rounded-2xl border border-blue-100 space-y-1">
                <span className="text-[11px] font-black text-blue-600 uppercase tracking-wider block">
                  종합 자격 적합도
                </span>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-black text-blue-900">{overallEligibilityScore}</span>
                  <span className="text-xs font-bold text-blue-600">/ 100점</span>
                </div>
                <span className="inline-block text-[10px] font-bold px-2 py-0.5 bg-blue-100 text-blue-800 rounded-full mt-1">
                  {overallEligibilityScore >= 80 ? '상위 15% 우수' : '평균 이상 수준'}
                </span>
              </div>

              <div className="bg-emerald-50/70 p-4 rounded-2xl border border-emerald-100 space-y-1">
                <span className="text-[11px] font-black text-emerald-600 uppercase tracking-wider block">
                  평균 예측 승인율
                </span>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-black text-emerald-900">{overallPredictedApprovalRate}</span>
                  <span className="text-xs font-bold text-emerald-600">%</span>
                </div>
                <span className="inline-block text-[10px] font-bold px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-full mt-1">
                  승인 가능성 유력 [A등급]
                </span>
              </div>
            </div>

            {/* Key Dimension Highlights */}
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-2.5">
              <h4 className="text-xs font-black text-slate-800 flex items-center justify-between">
                <span>지표별 진단 요약</span>
                <span className="text-[10px] font-bold text-slate-400">7개 영역 분석</span>
              </h4>

              <div className="space-y-2">
                {radarData.slice(0, 4).map((item, idx) => (
                  <div key={idx} className="flex items-center justify-between text-xs bg-white p-2.5 rounded-xl border border-slate-100 shadow-2xs">
                    <span className="font-bold text-slate-700 flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-500"></span>
                      {item.subject}
                    </span>
                    <div className="flex items-center gap-3">
                      <span className="font-semibold text-slate-500 text-[11px]">
                        적합도 <strong className="text-blue-600">{item.eligibility}%</strong>
                      </span>
                      <span className="font-semibold text-slate-500 text-[11px]">
                        예측 승인 <strong className="text-emerald-600">{item.predictedApproval}%</strong>
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* AI Actionable Guidance */}
            <div className="bg-indigo-900 text-white p-4 rounded-2xl shadow-sm space-y-2 relative overflow-hidden">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs font-black text-indigo-200">
                  <Zap className="w-4 h-4 text-amber-300" /> 승인 확률 극대화 팁
                </div>
                {onNavigateToMatch && (
                  <button
                    onClick={onNavigateToMatch}
                    className="text-[10px] font-bold bg-white/20 hover:bg-white/30 text-white px-2.5 py-1 rounded-lg transition-all flex items-center gap-1 cursor-pointer"
                  >
                    <span>정밀 AI 진단</span>
                    <ArrowUpRight className="w-3 h-3" />
                  </button>
                )}
              </div>
              <p className="text-[11px] text-indigo-100 font-medium leading-relaxed">
                신용도와 정책적합 항목 점수가 상위권입니다. <strong>소상공인 대환대출</strong> 및 <strong>창업유망 특례보증</strong> 신청 시 최우선 서류 심사 대상이 됩니다.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Policy Eligibility Validation & Gap Remediation Guide Section */}
      <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-slate-100 space-y-6">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 bg-amber-50 text-amber-900 rounded-full text-xs font-black mb-2 border border-amber-200">
              <ShieldAlert className="w-3.5 h-3.5 text-amber-600" /> 자격 정밀 검증 & 부족 요건 진단
            </div>
            <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
              정책 공고 요건 대조 검증 가이드
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-1">
              대표님의 사업장 프로필 데이터와 정책 공고 요건을 항목별로 정밀 대조하여 부족한 요건을 강조 표시하고 맞춤 보완 솔루션을 제공합니다.
            </p>
          </div>

          {/* Fund Selector Dropdown */}
          <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
            <span className="text-xs font-bold text-slate-400 shrink-0 hidden sm:inline">검증 대상 자금:</span>
            <select
              value={selectedValidationFundTitle}
              onChange={(e) => setSelectedValidationFundTitle(e.target.value)}
              className="bg-amber-50/50 border border-amber-200 text-slate-900 font-black text-xs rounded-xl px-3.5 py-2 focus:outline-none focus:ring-2 focus:ring-amber-500 cursor-pointer shadow-2xs max-w-xs truncate"
            >
              {allAvailableFundTitles.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Compliance Summary Dashboard Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-5 md:p-6 shadow-md flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
          <div className="space-y-2 relative z-10 text-center md:text-left">
            <div className="inline-flex items-center gap-2 bg-white/10 px-3 py-1 rounded-full text-[11px] font-bold text-amber-300 backdrop-blur-xs">
              <BadgeAlert className="w-3.5 h-3.5" />
              <span>[{validationAuditReport.currentFundTitle}] 자격 진단 리포트</span>
            </div>
            <h3 className="text-lg font-black text-white">
              전체 자격 요건 충족률: <span className="text-amber-400 font-extrabold">{validationAuditReport.complianceRate}%</span>
            </h3>
            <p className="text-xs text-slate-300 font-medium max-w-xl leading-relaxed">
              총 6개 평가 영역 중 <strong className="text-emerald-400">{validationAuditReport.meetsCount}개 즉시 충족</strong>, <strong className="text-amber-300">{validationAuditReport.warningCount}개 보완 권장</strong>, <strong className="text-rose-400">{validationAuditReport.unmetCount}개 미달 주의</strong> 상태입니다. 부족한 항목을 아래 솔루션으로 보완하면 승인율이 극대화됩니다.
            </p>
          </div>

          <div className="flex items-center gap-3 shrink-0 relative z-10">
            <div className="text-center px-4 py-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/15 min-w-[95px]">
              <span className="text-[10px] font-bold text-slate-300 block mb-0.5">충족 완료</span>
              <span className="text-2xl font-black text-emerald-400">{validationAuditReport.meetsCount}건</span>
            </div>
            <div className="text-center px-4 py-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/15 min-w-[95px]">
              <span className="text-[10px] font-bold text-slate-300 block mb-0.5">부족/보완 필요</span>
              <span className="text-2xl font-black text-amber-300">{validationAuditReport.warningCount + validationAuditReport.unmetCount}건</span>
            </div>
          </div>
        </div>

        {/* Filter Buttons */}
        <div className="flex items-center justify-between gap-2 border-b border-slate-100 pb-3 overflow-x-auto">
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => setValidationFilter('ALL')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                validationFilter === 'ALL'
                  ? 'bg-slate-900 text-white shadow-sm'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              전체 요건 ({validationAuditReport.allItems.length})
            </button>
            <button
              onClick={() => setValidationFilter('GAP_ONLY')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                validationFilter === 'GAP_ONLY'
                  ? 'bg-amber-600 text-white shadow-sm'
                  : 'bg-amber-50 text-amber-900 border border-amber-200 hover:bg-amber-100'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              부족/보완 필요 항목 ({validationAuditReport.warningCount + validationAuditReport.unmetCount})
            </button>
            <button
              onClick={() => setValidationFilter('MEET_ONLY')}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                validationFilter === 'MEET_ONLY'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'bg-emerald-50 text-emerald-900 border border-emerald-200 hover:bg-emerald-100'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              충족 완료 항목 ({validationAuditReport.meetsCount})
            </button>
          </div>
        </div>

        {/* Requirement Audit Cards */}
        <div className="space-y-4">
          {validationAuditReport.allItems
            .filter((item) => {
              if (validationFilter === 'GAP_ONLY') return item.status !== 'MEETS';
              if (validationFilter === 'MEET_ONLY') return item.status === 'MEETS';
              return true;
            })
            .map((item) => {
              const isUnmet = item.status === 'UNMET';
              const isWarning = item.status === 'WARNING';

              return (
                <div
                  key={item.id}
                  className={`p-5 rounded-2xl border transition-all space-y-4 ${
                    isUnmet
                      ? 'bg-rose-50/70 border-rose-200 shadow-2xs'
                      : isWarning
                      ? 'bg-amber-50/60 border-amber-200 shadow-2xs'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  {/* Category Header & Status Badge */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2.5">
                      {isUnmet ? (
                        <div className="w-8 h-8 rounded-xl bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                          <ShieldAlert className="w-5 h-5" />
                        </div>
                      ) : isWarning ? (
                        <div className="w-8 h-8 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
                          <AlertTriangle className="w-5 h-5" />
                        </div>
                      ) : (
                        <div className="w-8 h-8 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                          <ShieldCheck className="w-5 h-5" />
                        </div>
                      )}
                      <div>
                        <h4 className="text-sm font-black text-slate-900">{item.category}</h4>
                        <span className="text-[11px] font-medium text-slate-500">진단 요건 항목</span>
                      </div>
                    </div>

                    <span
                      className={`text-xs font-black px-3 py-1 rounded-full border ${
                        isUnmet
                          ? 'bg-rose-100 text-rose-800 border-rose-300 animate-pulse'
                          : isWarning
                          ? 'bg-amber-100 text-amber-900 border-amber-300'
                          : 'bg-emerald-100 text-emerald-800 border-emerald-300'
                      }`}
                    >
                      {item.statusText}
                    </span>
                  </div>

                  {/* Comparison Grid: Policy Requirement vs User Reality */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs bg-white/90 p-3.5 rounded-xl border border-slate-200/80">
                    <div className="space-y-1">
                      <span className="text-[11px] font-black text-slate-400 uppercase tracking-wider block">
                        📌 정책 공고 요구 기준
                      </span>
                      <p className="font-bold text-slate-800 leading-relaxed">{item.policyReq}</p>
                    </div>
                    <div className="space-y-1 border-t md:border-t-0 md:border-l border-slate-100 pt-2 md:pt-0 md:pl-3">
                      <span className="text-[11px] font-black text-slate-400 uppercase tracking-wider block">
                        👤 대표자 프로필 현황
                      </span>
                      <p className={`font-bold leading-relaxed ${isUnmet ? 'text-rose-700 font-black' : isWarning ? 'text-amber-800 font-black' : 'text-emerald-700 font-black'}`}>
                        {item.userReality}
                      </p>
                    </div>
                  </div>

                  {/* Highlighted Gap Warning Box */}
                  {'gapSummary' in item && Boolean((item as any).gapSummary) && (
                    <div className={`p-3.5 rounded-xl border flex items-start gap-2.5 ${
                      isUnmet ? 'bg-rose-100/90 border-rose-300 text-rose-950' : 'bg-amber-100/90 border-amber-300 text-amber-950'
                    }`}>
                      <BadgeAlert className={`w-4 h-4 shrink-0 mt-0.5 ${isUnmet ? 'text-rose-600' : 'text-amber-700'}`} />
                      <div>
                        <span className="text-xs font-black block mb-0.5">🚨 부족 요건 및 주의사항 하이라이트</span>
                        <p className="text-xs font-bold leading-relaxed">{(item as any).gapSummary}</p>
                      </div>
                    </div>
                  )}

                  {/* Actionable Recommendations to Satisfy Requirement */}
                  <div className="bg-slate-900 text-white p-4 rounded-xl space-y-2">
                    <div className="flex items-center gap-1.5 text-xs font-black text-amber-300">
                      <Lightbulb className="w-4 h-4" />
                      <span>요건 충족을 위한 보완 권장사항 및 해결 가이드</span>
                    </div>
                    <p className="text-xs text-slate-200 font-medium leading-relaxed whitespace-pre-line">
                      {item.actionPlan}
                    </p>

                    {item.documents && item.documents.length > 0 && (
                      <div className="pt-2 border-t border-slate-800 flex items-center gap-2 flex-wrap text-[11px]">
                        <span className="font-bold text-slate-400 shrink-0">보완 제출 서류:</span>
                        {item.documents.map((doc, idx) => (
                          <span key={idx} className="bg-white/10 text-slate-200 px-2.5 py-0.5 rounded-md font-semibold border border-white/10">
                            {doc}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
        </div>
      </div>
      </>
      )}

      {/* 1:1 Consultation Inquiries History (Shown when ALL) */}
      {activeDashboardTab === 'ALL' && (
        <div className="space-y-6">
          <ConsultationInquiryHistory
            token={token}
            profile={profile}
            onOpenConsultationModal={handleOpenConsultation}
            favorites={favorites}
          />
        </div>
      )}

      {/* OCR Business License Scanner (Shown when ALL or TOOLS) */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'TOOLS') && (
        <BusinessLicenseParser />
      )}
      
      {/* Credit Score Management, Fund Approval Predictor & Improvement Roadmap (Shown when ALL or TOOLS) */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'TOOLS') && (
      <CreditScoreManager
        profile={profile}
        onUpdateCreditScore={(newScore) => {
          if (profile) {
            profile.creditScore = newScore;
          }
        }}
        onSelectFundDetails={(fundTitle) => {
          const found = favorites.find(f => ('title' in f ? f.title : f.name).includes(fundTitle)) ||
                        latestPolicies.find(p => p.name.includes(fundTitle));
          if (found) {
            setSelectedFund(found as any);
          } else {
            setSearchType(fundTitle);
          }
        }}
      />
      )}

      {/* Interactive Application Checklist Section */}
      <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-slate-100 space-y-6">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 bg-emerald-50 text-emerald-700 rounded-full text-xs font-black mb-2 border border-emerald-100">
              <ClipboardList className="w-3.5 h-3.5 text-emerald-600" /> 서류 및 절차 가이드
            </div>
            <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
              신청 체크리스트 & 필수 서류 현황
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-1">
              신청을 준비하는 정책자금을 선택하고, 필요한 필수 서류 및 4단계 신청 준비 상태를 실시간 체크하세요.
            </p>
          </div>

          {/* Fund Selector Dropdown */}
          <div className="flex items-center gap-2 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0">
            <span className="text-xs font-bold text-slate-400 shrink-0 hidden sm:inline">대상 자금:</span>
            <select
              value={activeChecklistFundTitle}
              onChange={(e) => setActiveChecklistFundTitle(e.target.value)}
              className="bg-slate-50 border border-slate-200 text-slate-800 font-black text-xs rounded-xl px-3.5 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500 cursor-pointer shadow-2xs max-w-xs truncate"
            >
              {allAvailableFundTitles.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Step-by-Step Progress Roadmap (4 Steps) */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
              <ListChecks className="w-4 h-4 text-emerald-600" />
              단계별 신청 로드맵 (현재: STEP {currentStepData.currentStep})
            </h3>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-100">
              종합 준비율 {overallProgress}%
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {STANDARD_STEPS.map((s) => {
              const isActive = currentStepData.currentStep === s.step;
              const isPassed = currentStepData.currentStep > s.step;

              return (
                <button
                  key={s.step}
                  onClick={() => handleSetStep(activeChecklistFundTitle, s.step)}
                  className={`p-4 rounded-2xl text-left border transition-all cursor-pointer relative overflow-hidden ${
                    isActive
                      ? 'bg-slate-900 text-white border-slate-800 shadow-md ring-2 ring-emerald-500/30'
                      : isPassed
                      ? 'bg-emerald-50/70 text-slate-800 border-emerald-200 hover:bg-emerald-100/50'
                      : 'bg-slate-50 text-slate-600 border-slate-100 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className={`text-[10px] font-black px-2 py-0.5 rounded-md ${
                      isActive ? 'bg-emerald-500 text-white' : isPassed ? 'bg-emerald-200 text-emerald-800' : 'bg-slate-200 text-slate-600'
                    }`}>
                      STEP 0{s.step}
                    </span>
                    {isPassed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    ) : isActive ? (
                      <Clock className="w-4 h-4 text-emerald-300 animate-spin" />
                    ) : null}
                  </div>
                  <h4 className={`text-xs font-black mb-1 ${isActive ? 'text-white' : 'text-slate-900'}`}>
                    {s.title}
                  </h4>
                  <p className={`text-[11px] font-medium leading-relaxed ${isActive ? 'text-slate-300' : 'text-slate-500'}`}>
                    {s.desc}
                  </p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Document Checklist & Progress Bar */}
        <div className="bg-slate-50/70 rounded-2xl p-5 border border-slate-100 space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                <FileText className="w-4 h-4 text-indigo-600" />
                필수 구비 서류 체크리스트 ({completedDocsCount} / {allDocsForActiveFund.length}개 완료)
              </h3>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                발급을 완료한 서류를 체크해 두면 제출 준비율이 실시간으로 갱신됩니다.
              </p>
            </div>

            {/* External Government Portals Quick Links */}
            <div className="flex items-center gap-2 shrink-0">
              <a
                href="https://www.hometax.go.kr"
                target="_blank"
                rel="noreferrer"
                className="text-[11px] font-bold text-slate-600 hover:text-blue-600 bg-white border border-slate-200 px-2.5 py-1 rounded-xl transition-all flex items-center gap-1 shadow-2xs"
              >
                국세청 홈택스 <ExternalLink className="w-3 h-3 text-slate-400" />
              </a>
              <a
                href="https://www.gov.kr"
                target="_blank"
                rel="noreferrer"
                className="text-[11px] font-bold text-slate-600 hover:text-emerald-600 bg-white border border-slate-200 px-2.5 py-1 rounded-xl transition-all flex items-center gap-1 shadow-2xs"
              >
                정부24 <ExternalLink className="w-3 h-3 text-slate-400" />
              </a>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-bold text-slate-600">
              <span>서류 준비 진행률</span>
              <span className="text-emerald-600 font-black">{docProgressPercentage}%</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
              <div
                className="bg-emerald-500 h-2.5 rounded-full transition-all duration-500 ease-out"
                style={{ width: `${docProgressPercentage}%` }}
              ></div>
            </div>
          </div>

          {/* Documents Checkboxes Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 pt-2">
            {allDocsForActiveFund.map((doc) => {
              const isChecked = currentStepData.completedDocs.includes(doc.name);
              const info = matchDocumentToIssuanceInfo(doc.name);

              return (
                <div
                  key={doc.id || doc.name}
                  onClick={() => handleToggleDoc(activeChecklistFundTitle, doc.name)}
                  className={`p-3 rounded-xl border transition-all flex items-start justify-between gap-3 cursor-pointer ${
                    isChecked
                      ? 'bg-emerald-50/90 border-emerald-200 text-emerald-950 shadow-2xs'
                      : 'bg-white border-slate-200 hover:border-slate-300 text-slate-700'
                  }`}
                >
                  <div className="flex items-start gap-2.5 min-w-0 flex-1">
                    <button type="button" className="mt-0.5 text-emerald-600 shrink-0">
                      {isChecked ? (
                        <CheckSquare className="w-4 h-4 fill-emerald-600 text-white" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-300" />
                      )}
                    </button>
                    <div className="min-w-0 flex-1">
                      <span className={`text-xs font-bold block ${isChecked ? 'line-through text-slate-400 font-medium' : 'text-slate-800'}`}>
                        {doc.name}
                      </span>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <span className="text-[10px] font-semibold text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded">
                          {doc.source || info.agencyName}
                        </span>
                        <a
                          href={info.issuanceUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-[10px] font-bold text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-0.5"
                        >
                          <span>발급 바로가기</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      </div>
                    </div>
                  </div>

                  {/* Remove custom doc button if applicable */}
                  {(doc as any).isCustom && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveCustomDoc(activeChecklistFundTitle, doc.id, doc.name);
                      }}
                      className="text-slate-300 hover:text-red-500 p-1 cursor-pointer"
                      title="추가 서류 삭제"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              );
            })}
          </div>

          {/* Add Custom Document Form */}
          <div className="pt-3 border-t border-slate-200/60 flex flex-col sm:flex-row items-center gap-2">
            <input
              type="text"
              placeholder="추가로 구비할 특수 서류명을 입력하세요 (예: 특허증 사본, 사업계획서 등)"
              value={newDocName}
              onChange={(e) => setNewDocName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddCustomDoc(activeChecklistFundTitle);
                }
              }}
              className="w-full sm:flex-1 bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <input
              type="text"
              placeholder="발급처 (선택)"
              value={newDocSource}
              onChange={(e) => setNewDocSource(e.target.value)}
              className="w-full sm:w-36 bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <button
              onClick={() => handleAddCustomDoc(activeChecklistFundTitle)}
              className="w-full sm:w-auto px-4 py-2 bg-slate-900 hover:bg-emerald-600 text-white rounded-xl font-bold text-xs transition-colors flex items-center justify-center gap-1 shrink-0 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>서류 추가</span>
            </button>
          </div>
        </div>

        {/* Readiness Message */}
        {docProgressPercentage === 100 && (
          <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-2xl flex items-center gap-3 text-emerald-800">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
            <p className="text-xs font-extrabold leading-relaxed">
              🎉 축하합니다! {activeChecklistFundTitle} 신청에 필요한 모든 필수 서류 구비가 완료되었습니다! 소상공인진흥공단 온라인 시스템 접수를 진행하세요.
            </p>
          </div>
        )}
      </div>

      {/* Push Notification Setting & Control Box */}
      <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-start gap-4">
          <div className={`p-3 rounded-2xl flex-shrink-0 ${notificationPerm === 'granted' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'}`}>
            <BellRing className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="text-base font-black text-slate-900">실시간 브라우저 정책자금 푸시 알림</h3>
              <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                notificationPerm === 'granted' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-800'
              }`}>
                {notificationPerm === 'granted' ? '알림 작동 중' : '미설정'}
              </span>
              <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 border border-indigo-100 px-2 py-0.5 rounded-full">
                마감 임박 · 추가 공고 · 서류 변경
              </span>
            </div>
            <p className="text-xs font-medium text-slate-500 mt-1 leading-relaxed">
              관심 정책자금의 <strong>신청 마감 임박(D-7~D-Day), 2차 추가 공고 발생, 필수 제출 서류 및 양식 변경</strong> 시 실시간 브라우저 푸시 알림을 발송합니다.
            </p>
            {lastCheckMessage && (
              <p className="text-[11px] font-bold text-blue-600 mt-2 bg-blue-50 px-3 py-1 rounded-lg inline-block">
                💡 {lastCheckMessage}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 w-full md:w-auto flex-wrap sm:flex-nowrap">
          <button
            type="button"
            onClick={() => {
              setPushModalTargetFund(null);
              setIsPushModalOpen(true);
            }}
            className="w-full sm:w-auto px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-xs shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Sliders className="w-3.5 h-3.5 text-indigo-400" />
            <span>알림 관리 & 규칙 설정</span>
          </button>

          {notificationPerm !== 'granted' ? (
            <button
              onClick={handleRequestPermission}
              className="w-full sm:w-auto px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold text-xs shadow-md transition-all active:scale-95 flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Bell className="w-3.5 h-3.5" />
              <span>알림 허용</span>
            </button>
          ) : (
            <>
              <button
                onClick={handleCheckDeadlinesNow}
                className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
                title="마감 임박 자금 즉시 확인"
              >
                <Clock className="w-3.5 h-3.5" />
                <span>마감 검사</span>
              </button>
              <button
                onClick={() => {
                  setPushModalTargetFund(null);
                  setIsPushModalOpen(true);
                }}
                className="px-3.5 py-2.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
                title="푸시 알림 테스트 시뮬레이션 열기"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>알림 테스트</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Realtime Regional & Industry Policy News via Google Search */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'NEWS') && (
        <RealtimePolicyNews profile={profile} />
      )}

      {/* Realtime Favorite Policy Changes & Urgent Deadline Summary */}
      <FavoritePolicyChangesSummary
        favorites={favorites}
        onOpenConsultation={handleOpenConsultation}
        onOpenPdfChecklist={handleOpenPdfChecklist}
        onScheduleCalendar={handleSetCalendarReminder}
        onSelectFund={setSelectedFund}
      />

      {/* Policy Fund Application Stages Progress Tracker */}
      <PolicyApplicationTracker
        favorites={favorites}
        profile={profile}
        onOpenConsultation={handleOpenConsultation}
        onOpenPdfChecklist={handleOpenPdfChecklist}
        onOpenDocGuide={(fundTitle) => {
          if (fundTitle) {
            const f = favorites.find(fav => ('title' in fav ? fav.title : fav.name).includes(fundTitle)) ||
                      latestPolicies.find(p => p.name.includes(fundTitle));
            if (f) {
              setSelectedFund(f);
              return;
            }
          }
          if (favorites.length > 0) {
            setSelectedFund(favorites[0]);
          }
        }}
        onScheduleCalendar={handleSetCalendarReminder}
      />

      {/* Main Content Area: Favorites List & Detail Modal */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'SCRAPS') && (
      <div id="scraps-section" className="space-y-6">
        {filteredFavorites.length > 0 && (
          <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-slate-100 mb-6">
            <div className="flex items-center justify-between gap-4 mb-6">
              <div className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-blue-600" />
                <h2 className="text-lg font-black text-slate-900">정책 상품 비교 그래프 (한도 vs 금리)</h2>
              </div>
              <button
                onClick={() => window.print()}
                className="print:hidden px-4 py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-xs font-bold flex items-center gap-2 transition-all shadow-md active:scale-95 shrink-0"
                title="현재 화면을 PDF로 저장하거나 인쇄합니다"
              >
                <FileText className="w-4 h-4" />
                <span>PDF 저장 / 인쇄</span>
              </button>
            </div>
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={favoriteComparisonData}
                  margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="name" tick={{ fontSize: 10, fontWeight: 700, fill: '#64748b' }} axisLine={false} tickLine={false} />
                  <YAxis 
                    yAxisId="left" 
                    orientation="left" 
                    stroke="#3b82f6" 
                    tick={{ fontSize: 10, fontWeight: 700 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(value) => value + '만'}
                  />
                  <YAxis 
                    yAxisId="right" 
                    orientation="right" 
                    stroke="#f59e0b" 
                    tick={{ fontSize: 10, fontWeight: 700 }}
                    axisLine={false}
                    tickLine={false}
                    tickFormatter={(value) => value + '%'}
                  />
                  <Tooltip 
                    contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)', fontSize: '12px', fontWeight: 'bold' }}
                    formatter={(value, name) => [name === 'limit' ? value.toLocaleString() + '만원' : value + '%', name === 'limit' ? '대출 한도' : '금리']}
                    labelStyle={{ color: '#0f172a', marginBottom: '4px' }}
                  />
                  <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 'bold', color: '#64748b' }} />
                  <Bar yAxisId="left" dataKey="limit" name="대출 한도 (만원)" fill="#3b82f6" radius={[4, 4, 0, 0]} maxBarSize={40} />
                  <Bar yAxisId="right" dataKey="interest" name="금리 (%)" fill="#f59e0b" radius={[4, 4, 0, 0]} maxBarSize={40} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center justify-between w-full sm:w-auto">
            <div className="flex items-center gap-2">
              <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
              <h2 className="text-xl font-black text-slate-900">즐겨찾기한 정책자금 목록</h2>
              <span className="text-xs font-extrabold bg-slate-100 text-slate-600 px-2.5 py-0.5 rounded-full">
                {filteredFavorites.length}건
              </span>
            </div>
            
            <button
              onClick={() => window.print()}
              title="현재 화면을 PDF로 저장하거나 인쇄합니다"
              className="print:hidden p-2 bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors"
            >
              <FileText className="w-4 h-4" />
            </button>
          </div>

          <div className="relative w-full sm:w-64 print:hidden">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="자금명 또는 기관 검색..."
              value={searchTerm}
              onChange={(e) => setSearchType(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>

        {filteredFavorites.length === 0 ? (
          <div className="bg-white p-12 rounded-3xl border border-slate-100 text-center space-y-4 shadow-sm">
            <div className="w-16 h-16 bg-amber-50 rounded-2xl flex items-center justify-center mx-auto text-amber-500">
              <Star className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-black text-slate-900">즐겨찾기한 정책자금이 없습니다</h3>
            <p className="text-xs text-slate-500 font-medium max-w-md mx-auto leading-relaxed">
              자금 추천 진단 결과나 캘린더에서 관심 있는 자금의 별표(⭐️) 아이콘을 클릭하여 내 대시보드에 스크랩해 보세요.
            </p>
            {onNavigateToMatch && (
              <button
                onClick={onNavigateToMatch}
                className="px-6 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs rounded-xl transition-all shadow-md active:scale-95 inline-flex items-center gap-2"
              >
                <Search className="w-4 h-4" />
                <span>AI 분석 시작하기</span>
              </button>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredFavorites.map((fund) => {
              const id = 'id' in fund ? fund.id : fund.name;
              const title = 'title' in fund ? fund.title : fund.name;
              const agency = fund.agency;
              const interestRate = 'interestRate' in fund ? fund.interestRate : fund.baseInterestRate;
              const maxAmount = 'maxAmount' in fund ? fund.maxAmount : '상세 확인';
              const endDate = 'endDate' in fund ? fund.endDate : ('applicationDeadline' in fund ? fund.applicationDeadline : '');
              const description = fund.description;
              const eligibility = fund.eligibility;

              const daysLeft = calculateDaysRemaining(String(endDate || ''));
              const isExpired = daysLeft < 0;
              const isUrgent3Days = !isExpired && daysLeft <= 3;

              return (
                <div 
                  key={id} 
                  className={`rounded-3xl p-6 shadow-sm transition-all flex flex-col justify-between group relative overflow-hidden ${
                    isUrgent3Days
                      ? 'bg-gradient-to-b from-rose-50/50 via-white to-white border-2 border-rose-500/80 shadow-lg shadow-rose-500/10 ring-2 ring-rose-500/20 hover:border-rose-600'
                      : 'bg-white border border-slate-100 hover:shadow-md'
                  }`}
                >
                  {/* Urgent 3-Day Ribbon Banner */}
                  {isUrgent3Days && (
                    <div className="bg-gradient-to-r from-rose-600 to-red-600 text-white text-[11px] font-black py-1 px-4 -mx-6 -mt-6 mb-4 flex items-center justify-between shadow-xs">
                      <span className="flex items-center gap-1.5 animate-pulse">
                        <AlertCircle className="w-3.5 h-3.5" />
                        <span>⚠️ 긴급: 접수 마감 {daysLeft === 0 ? '오늘(D-DAY) 마감!' : `${daysLeft}일 전 임박!`}</span>
                      </span>
                      <span className="text-[10px] text-rose-100 font-bold">서류 최종 점검 필수</span>
                    </div>
                  )}

                  <div className="space-y-4">
                    {/* Header Top badges */}
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-1 bg-slate-100 text-slate-600 rounded-lg flex items-center gap-1">
                        <Building2 className="w-3 h-3 text-slate-400" /> {agency}
                      </span>

                      <div className="flex items-center gap-2">
                        {/* Deadline Status Badge */}
                        <span className={`text-[11px] font-black px-2.5 py-0.5 rounded-full ${
                          isExpired
                            ? 'bg-slate-100 text-slate-400'
                            : daysLeft === 0
                              ? 'bg-red-500 text-white animate-pulse'
                              : daysLeft <= 3
                                ? 'bg-red-100 text-red-600'
                                : daysLeft <= 7
                                  ? 'bg-amber-100 text-amber-700'
                                  : 'bg-emerald-100 text-emerald-700'
                        }`}>
                          {isExpired ? '마감됨' : daysLeft === 0 ? 'D-DAY 마감' : `마감 D-${daysLeft}`}
                        </span>

                        {/* Unfavorite Button */}
                        <button
                          onClick={() => onToggleFavorite(fund)}
                          className="p-1.5 text-amber-500 hover:text-slate-400 transition-colors"
                          title="즐겨찾기 해제"
                        >
                          <Star className="w-5 h-5 fill-amber-400 text-amber-500" />
                        </button>
                      </div>
                    </div>

                    {/* Title & Description */}
                    <div>
                      <h3 className="text-lg font-black text-slate-900 group-hover:text-blue-600 transition-colors leading-snug mb-1.5">
                        {title}
                      </h3>
                      <p className="text-xs text-slate-500 font-medium line-clamp-2 leading-relaxed">
                        {description}
                      </p>
                    </div>

                    {/* Key Attributes Box */}
                    <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-100 text-xs">
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 block">최대 한도</span>
                        <span className="font-black text-slate-900">{maxAmount || '상세 확인'}</span>
                      </div>
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 block">적용 이율</span>
                        <span className="font-black text-blue-600">{interestRate}</span>
                      </div>
                    </div>

                    {/* Eligibility hint */}
                    {eligibility && (
                      <div className="text-[11px] font-bold text-slate-600 bg-blue-50/50 p-2.5 rounded-xl border border-blue-100/50 flex items-start gap-1.5">
                        <Info className="w-3.5 h-3.5 text-blue-500 shrink-0 mt-0.5" />
                        <span className="line-clamp-1">{eligibility}</span>
                      </div>
                    )}

                    {/* Embedded Loan Simulator */}
                    <div className="mt-3">
                      <FundLoanSimulator
                        fund={normalizeToPolicyFund(fund)}
                        profile={profile}
                      />
                    </div>
                    
                    {/* Embedded Progress Tracker */}
                    <FavoriteFundProgress fundId={id} />
                  </div>

                    {/* Footer Actions */}
                    <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          onClick={() => {
                            window.dispatchEvent(new CustomEvent('bizmatch_track_fund', { detail: fund }));
                          }}
                          className="px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl font-black text-xs transition-colors flex items-center gap-1 cursor-pointer border border-emerald-200/60"
                          title="이 정책자금의 단계별 신청 진행 상황 트래킹에 등록"
                        >
                          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                          <span>신청 트래킹</span>
                        </button>
                        <button
                          onClick={() => handleOpenConsultation(fund)}
                          className="px-2.5 py-1.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white rounded-xl font-black text-xs transition-all flex items-center gap-1 cursor-pointer shadow-xs shadow-indigo-500/20"
                          title="이 자금의 심사 요건 및 준비 절차 1:1 비대면 전문 상담 신청"
                        >
                          <Headphones className="w-3.5 h-3.5 text-indigo-200" />
                          <span>전문가 상담</span>
                        </button>
                        <button
                          onClick={() => handleSetCalendarReminder(fund)}
                          className="px-2.5 py-1.5 bg-slate-50 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 rounded-xl font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
                          title="구글 캘린더 알림 등록"
                        >
                          <CalendarIcon className="w-3.5 h-3.5 text-indigo-500" />
                          <span className="hidden sm:inline">캘린더</span>
                        </button>
                        <button
                          onClick={() => {
                            setPushModalTargetFund(fund);
                            setIsPushModalOpen(true);
                          }}
                          className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
                          title="이 자금의 마감/공고/서류 푸시 알림 설정"
                        >
                          <BellRing className="w-3.5 h-3.5 text-indigo-600" />
                          <span>푸시 알림</span>
                        </button>
                        <button
                          onClick={() => handleOpenPdfChecklist(fund)}
                          className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl font-bold text-xs transition-colors flex items-center gap-1 cursor-pointer"
                          title="원문 공고문 PDF 분석 및 체크리스트"
                        >
                          <FileCheck2 className="w-3.5 h-3.5 text-blue-600" />
                          <span className="hidden md:inline">PDF 체크</span>
                        </button>
                      </div>

                      <button
                        onClick={() => setSelectedFund(fund)}
                        className="px-3.5 py-1.5 bg-slate-900 hover:bg-blue-600 text-white rounded-xl font-bold text-xs transition-colors flex items-center gap-1 shadow-sm cursor-pointer ml-auto"
                      >
                        <span>상세 가이드</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
      )}

      {/* AI Similar Policy Funds Recommendation Section */}
      <div className="bg-gradient-to-b from-indigo-50/50 via-white to-white p-6 md:p-8 rounded-3xl border border-indigo-100/80 shadow-sm space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-0.5 bg-indigo-100 text-indigo-700 rounded-full text-xs font-black mb-2">
              <Bot className="w-3.5 h-3.5" /> AI 연관자금 추천
            </div>
            <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              즐겨찾기 기반 연관 정책자금 AI 추천
            </h2>
            <p className="text-xs text-slate-500 font-medium mt-1">
              대표님이 스크랩한 상품의 성격(대환/운전자금/창업 등)을 Gemini AI가 종합 분석하여 시너지가 나는 최적의 연관 자금을 제안합니다.
            </p>
          </div>

          <button
            onClick={handleFetchAiRecommendations}
            disabled={aiLoading}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-300 text-white rounded-xl font-bold text-xs transition-all shadow-md active:scale-95 flex items-center gap-2 shrink-0 cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${aiLoading ? 'animate-spin' : ''}`} />
            <span>{aiLoading ? 'AI 분석 중...' : '연관 자금 재분석'}</span>
          </button>
        </div>

        {/* AI Analysis Summary Box */}
        {aiResult?.analysisSummary && (
          <div className="bg-white p-4 rounded-2xl border border-indigo-100 shadow-sm flex items-start gap-3">
            <div className="p-2 bg-indigo-50 rounded-xl text-indigo-600 shrink-0">
              <Lightbulb className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-black text-slate-900 mb-1">AI 즐겨찾기 성향 브리핑</h4>
              <p className="text-xs text-slate-600 font-medium leading-relaxed">
                {aiResult.analysisSummary}
              </p>
            </div>
          </div>
        )}

        {/* AI Loading State */}
        {aiLoading && (
          <div className="bg-white p-10 rounded-2xl border border-slate-100 text-center space-y-3">
            <div className="w-12 h-12 bg-indigo-50 rounded-full flex items-center justify-center mx-auto text-indigo-600 animate-pulse">
              <Sparkles className="w-6 h-6 animate-spin" />
            </div>
            <h4 className="text-sm font-black text-slate-800">즐겨찾기 상품을 바탕으로 연관 자금을 분석 중입니다...</h4>
            <p className="text-xs text-slate-400">Gemini AI가 실시간 소상공인 정책자금 데이터베이스를 탐색하고 있습니다.</p>
          </div>
        )}

        {/* AI Error State */}
        {aiError && !aiLoading && (
          <div className="bg-red-50 p-4 rounded-2xl border border-red-100 text-xs font-bold text-red-600 flex items-center justify-between">
            <span>⚠️ {aiError}</span>
            <button
              onClick={handleFetchAiRecommendations}
              className="px-3 py-1 bg-red-600 text-white rounded-lg text-[11px]"
            >
              재시도
            </button>
          </div>
        )}

        {/* AI Recommendations List */}
        {aiResult && !aiLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {aiResult.recommendations.map((rec) => {
              const favorited = isFavorited(rec.title);

              return (
                <div
                  key={rec.id || rec.title}
                  className="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4 relative"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-black uppercase tracking-wider px-2.5 py-1 bg-indigo-50 text-indigo-700 rounded-lg flex items-center gap-1">
                        <Building2 className="w-3 h-3 text-indigo-400" /> {rec.agency}
                      </span>

                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                          추천 부합도 {rec.matchScore}%
                        </span>

                        <button
                          onClick={() => {
                            const fundObj: PolicyFund = {
                              id: rec.id || rec.title,
                              title: rec.title,
                              agency: rec.agency,
                              category: rec.category || 'AI 연관 추천',
                              maxAmount: rec.maxAmount,
                              interestRate: rec.interestRate,
                              description: rec.description,
                              eligibility: rec.eligibility,
                              applicationDeadline: rec.applicationDeadline || '2026-12-31',
                              contactInfo: rec.contactInfo || '1357',
                              requiredDocuments: ['사업자등록증', '납세증명서'],
                              applicationProcedure: ['온라인 신청', '서류 심사', '대출 실행'],
                              writingGuide: rec.similarityReason,
                              announcementDate: '',
                              startDate: '',
                              endDate: rec.applicationDeadline || '',
                            };
                            onToggleFavorite(fundObj);
                          }}
                          className={`p-1.5 rounded-lg transition-colors ${favorited ? 'text-amber-500' : 'text-slate-300 hover:text-amber-400'}`}
                          title={favorited ? "즐겨찾기 해제" : "내 즐겨찾기에 추가"}
                        >
                          <Star className={`w-5 h-5 ${favorited ? 'fill-amber-400 text-amber-500' : ''}`} />
                        </button>
                      </div>
                    </div>

                    <div>
                      <h3 className="text-base font-black text-slate-900 mb-1">
                        {rec.title}
                      </h3>
                      <p className="text-xs text-slate-500 line-clamp-2 leading-relaxed">
                        {rec.description}
                      </p>
                    </div>

                    {/* AI Recommendation Reason */}
                    <div className="bg-indigo-50/70 p-3 rounded-2xl border border-indigo-100/80 space-y-1">
                      <div className="flex items-center gap-1.5 text-[11px] font-black text-indigo-900">
                        <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                        <span>AI 연관 분석 사유 ({rec.basedOnFundName ? `'${rec.basedOnFundName}' 기반` : '즐겨찾기 성향 분석'})</span>
                      </div>
                      <p className="text-xs text-indigo-950 font-semibold leading-relaxed">
                        {rec.similarityReason}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-xs">
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 block">최대 한도</span>
                        <span className="font-black text-slate-900">{rec.maxAmount}</span>
                      </div>
                      <div>
                        <span className="text-[10px] font-bold text-slate-400 block">금리</span>
                        <span className="font-black text-blue-600">{rec.interestRate}</span>
                      </div>
                    </div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                    <button
                      onClick={() => handleSetCalendarReminder(rec)}
                      className="px-3 py-1.5 bg-slate-50 hover:bg-indigo-50 text-slate-600 hover:text-indigo-600 rounded-xl font-bold text-xs transition-colors flex items-center gap-1.5"
                    >
                      <CalendarIcon className="w-3.5 h-3.5 text-indigo-500" />
                      <span>캘린더 등록</span>
                    </button>

                    <button
                      onClick={() => setSelectedFund(rec)}
                      className="px-4 py-1.5 bg-indigo-950 hover:bg-indigo-800 text-white rounded-xl font-bold text-xs transition-colors flex items-center gap-1 shadow-sm"
                    >
                      <span>상세 가이드</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Similar Industry Success Stories & Growth Case Studies */}
      <SuccessStories 
        profile={profile}
        onSelectFund={(fundName) => {
          // If the fund matches one of the favorites or latest policies, open it or search
          const found = favorites.find(f => ('title' in f ? f.title : f.name).includes(fundName)) ||
                        latestPolicies.find(p => p.name.includes(fundName));
          if (found) {
            setSelectedFund(found as any);
          } else {
            setSearchType(fundName);
          }
        }}
      />

      {/* Policy Detail Modal */}
      {selectedFund && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6 md:p-8 shadow-2xl relative animate-fade-in space-y-6">
            <button
              onClick={() => setSelectedFund(null)}
              className="absolute right-6 top-6 p-2 text-slate-400 hover:text-slate-600 bg-slate-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-2">
              <span className="text-xs font-black text-blue-600 uppercase tracking-widest bg-blue-50 px-3 py-1 rounded-full">
                {selectedFund.agency}
              </span>
              <h2 className="text-2xl font-black text-slate-900">
                {'title' in selectedFund ? selectedFund.title : selectedFund.name}
              </h2>
            </div>

            <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
              <div>
                <span className="text-xs font-bold text-slate-400">대출 한도</span>
                <p className="text-lg font-black text-slate-900">
                  {'maxAmount' in selectedFund ? selectedFund.maxAmount : '상세 문의'}
                </p>
              </div>
              <div>
                <span className="text-xs font-bold text-slate-400">금리 조건</span>
                <p className="text-lg font-black text-blue-600">
                  {'interestRate' in selectedFund ? selectedFund.interestRate : selectedFund.baseInterestRate}
                </p>
              </div>
            </div>

            <div className="space-y-4 text-xs font-medium text-slate-700">
              <div>
                <h4 className="font-black text-slate-900 text-sm mb-1">지원 대상 및 자격</h4>
                <p className="bg-slate-50 p-3 rounded-xl border border-slate-100">{selectedFund.eligibility}</p>
              </div>

              <div>
                <h4 className="font-black text-slate-900 text-sm mb-1">상세 설명</h4>
                <p className="bg-slate-50 p-3 rounded-xl border border-slate-100">{selectedFund.description}</p>
              </div>

              {'applicationProcedure' in selectedFund && selectedFund.applicationProcedure && (
                <div>
                  <h4 className="font-black text-slate-900 text-sm mb-1">신청 절차</h4>
                  <ol className="list-decimal pl-5 space-y-1 bg-slate-50 p-3 rounded-xl border border-slate-100">
                    {selectedFund.applicationProcedure.map((step, idx) => (
                      <li key={idx}>{step}</li>
                    ))}
                  </ol>
                </div>
              )}

              {'requiredDocuments' in selectedFund && selectedFund.requiredDocuments && (
                <div className="pt-1">
                  <DocumentIssuanceGuide
                    documents={selectedFund.requiredDocuments || []}
                    fundTitle={'title' in (selectedFund as any) ? (selectedFund as any).title : (selectedFund as any).name || ''}
                    fund={normalizeToPolicyFund(selectedFund)}
                    profile={profile}
                  />
                </div>
              )}

              <div>
                <h4 className="font-black text-slate-900 text-sm mb-1">문의처 및 담당 부서</h4>
                <p className="bg-slate-50 p-3 rounded-xl border border-slate-100 font-bold text-slate-900">
                  {selectedFund.contactInfo || '소상공인 통합 콜센터 (1357)'}
                </p>
              </div>

              {/* Loan Repayment Simulator inside Guide Modal */}
              <div className="pt-2">
                <FundLoanSimulator
                  fund={normalizeToPolicyFund(selectedFund)}
                  profile={profile}
                  defaultExpanded={true}
                />
              </div>
            </div>

            <div className="pt-4 border-t border-slate-100 flex flex-wrap gap-2.5">
              <button
                onClick={() => {
                  handleOpenConsultation(selectedFund);
                }}
                className="flex-1 min-w-[140px] py-3 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white rounded-xl font-black text-xs transition-all flex items-center justify-center gap-1.5 shadow-md shadow-indigo-500/20"
              >
                <Headphones className="w-4 h-4 text-indigo-200" /> 전문가 1:1 상담 문의
              </button>
              <button
                onClick={() => {
                  handleOpenPdfChecklist(selectedFund);
                }}
                className="flex-1 min-w-[130px] py-3 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-xl font-bold text-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <FileCheck2 className="w-4 h-4 text-blue-600" /> PDF 핵심 체크리스트
              </button>
              <button
                onClick={() => {
                  setFormsModalTargetFund(selectedFund);
                  setIsFormsModalOpen(true);
                }}
                className="flex-1 min-w-[130px] py-3 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-xl font-bold text-xs transition-colors flex items-center justify-center gap-1.5"
              >
                <ClipboardCheck className="w-4 h-4 text-purple-600" /> Google Forms 설문
              </button>
              <button
                onClick={() => {
                  handleSetCalendarReminder(selectedFund);
                }}
                className="flex-1 min-w-[130px] py-3 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 rounded-xl font-bold text-xs transition-colors flex items-center justify-center gap-2"
              >
                <CalendarIcon className="w-4 h-4" /> 구글 캘린더 등록
              </button>
              <button
                onClick={() => setSelectedFund(null)}
                className="flex-1 min-w-[100px] py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-xs transition-colors"
              >
                확인 완료
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Google Forms Modal */}
      <GoogleFormsManagerModal
        isOpen={isFormsModalOpen}
        onClose={() => {
          setIsFormsModalOpen(false);
          setFormsModalTargetFund(null);
        }}
        token={token || null}
        profile={profile}
        selectedFund={formsModalTargetFund ? normalizeToPolicyFund(formsModalTargetFund) : undefined}
      />

      {/* PDF Checklist Modal */}
      <FundPdfChecklistModal
        isOpen={!!pdfChecklistFund}
        onClose={() => setPdfChecklistFund(null)}
        fund={pdfChecklistFund}
        profile={profile}
      />

      {/* Push Notification Manager Modal */}
      <PushNotificationModal
        isOpen={isPushModalOpen}
        onClose={() => {
          setIsPushModalOpen(false);
          setPushModalTargetFund(null);
          setNotificationPerm(getNotificationPermission());
        }}
        favorites={favorites}
        initialSelectedFund={pushModalTargetFund}
        onSelectFundDetails={(fund) => {
          setSelectedFund(fund);
        }}
      />

      {/* Expert 1:1 Consultation Modal */}
      <ExpertConsultationModal
        isOpen={isConsultModalOpen}
        onClose={() => {
          setIsConsultModalOpen(false);
          setConsultModalFund(null);
        }}
        fund={consultModalFund}
        profile={profile}
        token={token || null}
        onSubmitSuccess={handleConsultationSuccess}
      />

      {/* Consultation Toast Notification */}
      {consultSuccessToast && (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-2xl border border-indigo-500/30 flex items-center gap-3 animate-fade-in text-xs font-bold max-w-lg">
          <div className="w-7 h-7 rounded-xl bg-emerald-500 text-white flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <span className="leading-snug">{consultSuccessToast}</span>
        </div>
      )}

    </div>
  );
};
