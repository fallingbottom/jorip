import React, { useState } from 'react';
import { 
  X, 
  ShieldCheck, 
  User, 
  Mail, 
  Lock, 
  Building2, 
  KeyRound, 
  CheckCircle2, 
  AlertCircle, 
  ArrowRight, 
  Sparkles, 
  Briefcase, 
  Eye, 
  EyeOff,
  LogIn
} from 'lucide-react';
import { googleSignIn } from '../../services/firebaseService';
import { 
  AdminUser, 
  AdminRole, 
  authenticateWithGoogleUser, 
  authenticateWithMasterPasscode, 
  addAdminUser, 
  getAdminSettings,
  setAdminSession 
} from '../../services/adminAuthService';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'LOGIN' | 'SIGNUP';
  isAdminRequired?: boolean;
  onSuccess: (user: AdminUser | { email: string; name: string; isApprovedAdmin: boolean }) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'LOGIN',
  isAdminRequired = false,
  onSuccess,
}) => {
  const [tab, setTab] = useState<'LOGIN' | 'SIGNUP'>(initialTab);
  
  // Login form state
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [masterPasscode, setMasterPasscode] = useState('');
  const [showMasterPinInput, setShowMasterPinInput] = useState(false);
  
  // Sign up form state
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [businessName, setBusinessName] = useState('');
  const [memberType, setMemberType] = useState<'BUSINESS' | 'ADMIN'>('BUSINESS');
  const [adminCode, setAdminCode] = useState('');
  const [agreeTerms, setAgreeTerms] = useState(true);
  
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  if (!isOpen) return null;

  // Google Login / Sign Up Handler
  const handleGoogleAuth = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      const result = await googleSignIn();
      if (result && result.user) {
        const authResult = authenticateWithGoogleUser(result.user);
        if (isAdminRequired && !authResult.isAuthorizedAdmin) {
          // If admin was strictly required but this email isn't an admin
          setErrorMessage(
            `구글 로그인 성공(${result.user.email}). 그러나 이 계정은 관리자 CRM 접근 권한이 없습니다. 시스템 슈퍼 관리자(fujinilove@gmail.com)에게 권한 승인을 요청하시거나 마스터 패스코드로 인증하세요.`
          );
          setIsLoading(false);
          setShowMasterPinInput(true);
          return;
        }

        const authenticatedUser = authResult.user || {
          id: result.user.uid,
          email: result.user.email || '',
          name: result.user.displayName || '구글 회원',
          role: 'CONSULTANT' as AdminRole,
          createdAt: new Date().toISOString(),
          isApproved: authResult.isAuthorizedAdmin,
          provider: 'google' as const,
        };

        setSuccessNotice(`${authenticatedUser.name}님 환영합니다!`);
        setTimeout(() => {
          onSuccess(authenticatedUser);
          onClose();
        }, 600);
      }
    } catch (err: any) {
      console.warn('Google Auth notice:', err);
      setErrorMessage(err?.message || '구글 인증 팝업이 취소되었거나 오류가 발생했습니다.');
    } finally {
      setIsLoading(false);
    }
  };

  // Master Passcode Login
  const handleMasterPasscodeLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!masterPasscode.trim()) {
      setErrorMessage('마스터 패스코드를 입력해주세요.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    const result = authenticateWithMasterPasscode(masterPasscode);
    if (result.success && result.user) {
      setSuccessNotice('마스터 관리자 보안 인증이 완료되었습니다.');
      setTimeout(() => {
        onSuccess(result.user!);
        onClose();
      }, 500);
    } else {
      setErrorMessage(result.error || '마스터 패스코드가 일치하지 않습니다. (초기 비밀번호: 2026)');
    }
    setIsLoading(false);
  };

  // Email / Password Login
  const handleEmailLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!loginEmail.trim()) {
      setErrorMessage('이메일을 입력해주세요.');
      return;
    }
    if (!loginPassword.trim()) {
      setErrorMessage('비밀번호를 입력해주세요.');
      return;
    }

    setIsLoading(true);

    // Check against registered admin users or mock credential
    const normalized = loginEmail.trim().toLowerCase();
    const settings = getAdminSettings();
    const isMasterAdminEmail = normalized === 'fujinilove@gmail.com' || normalized === 'admin@bizmatch.ai';

    if (isAdminRequired && !isMasterAdminEmail && !settings.authorizedEmails.includes(normalized)) {
      setErrorMessage('입력하신 계정은 관리자 CRM 접근 권한이 없습니다. 마스터 패스코드로 인증하시거나 관리자 계정을 등록하세요.');
      setIsLoading(false);
      setShowMasterPinInput(true);
      return;
    }

    const sessionUser: AdminUser = {
      id: `admin-usr-${Date.now()}`,
      email: normalized,
      name: normalized.split('@')[0] + ' 심사역',
      role: isMasterAdminEmail ? 'SUPER_ADMIN' : 'CONSULTANT',
      businessName: '소상공인 정책지원 연구소',
      createdAt: new Date().toISOString(),
      isApproved: true,
      provider: 'email',
    };

    setAdminSession(sessionUser);
    setSuccessNotice(`${sessionUser.name}님, 정상 로그인되었습니다.`);
    setTimeout(() => {
      onSuccess(sessionUser);
      onClose();
    }, 500);
    setIsLoading(false);
  };

  // Sign Up Submission
  const handleSignUp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!name.trim()) {
      setErrorMessage('이름 또는 대표자명을 입력해주세요.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorMessage('올바른 이메일 주소를 입력해주세요.');
      return;
    }
    if (!password || password.length < 6) {
      setErrorMessage('비밀번호는 6자 이상이어야 합니다.');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMessage('비밀번호 확인이 일치하지 않습니다.');
      return;
    }
    if (!agreeTerms) {
      setErrorMessage('이용약관 및 개인정보 처리방침에 동의해주세요.');
      return;
    }

    setIsLoading(true);

    const settings = getAdminSettings();
    const normalizedEmail = email.trim().toLowerCase();

    // If signing up as admin
    if (memberType === 'ADMIN') {
      const isValidAdminCode = adminCode.trim().toUpperCase() === settings.adminInvitationCode.toUpperCase() ||
                               adminCode.trim() === settings.masterPasscode;
      
      if (settings.requireAdminCode && !isValidAdminCode) {
        setErrorMessage(`관리자 초대 코드가 올바르지 않습니다. (초기 초대코드 힌트: ${settings.adminInvitationCode})`);
        setIsLoading(false);
        return;
      }

      // Add to admin list
      const newAdmin = addAdminUser(normalizedEmail, name, 'CONSULTANT', businessName);
      setAdminSession(newAdmin);
      setSuccessNotice(`관리자/심사역 회원가입이 완료되었습니다!`);
      setTimeout(() => {
        onSuccess(newAdmin);
        onClose();
      }, 600);
    } else {
      // General business member
      const memberUser: AdminUser = {
        id: `biz-user-${Date.now()}`,
        email: normalizedEmail,
        name: name.trim(),
        role: 'CONSULTANT',
        businessName: businessName.trim() || '우리 사업장',
        createdAt: new Date().toISOString(),
        isApproved: false,
        provider: 'email',
      };
      
      // Save local user profile
      try {
        localStorage.setItem('bizmatch_user_account', JSON.stringify(memberUser));
      } catch (err) {}

      setSuccessNotice(`환영합니다! 소상공인 회원가입이 완료되었습니다.`);
      setTimeout(() => {
        onSuccess(memberUser);
        onClose();
      }, 600);
    }

    setIsLoading(false);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white rounded-full hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white font-black shadow-lg shadow-indigo-600/30">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-black tracking-tight flex items-center gap-2">
                BizMatch AI 계정 인증 & 회원가입
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                {isAdminRequired 
                  ? '관리자 CRM 접근을 위한 심사역 및 관리자 인증' 
                  : '맞춤 정책자금 추천 및 원스톱 관제 서비스'}
              </p>
            </div>
          </div>

          {/* Tab Selector */}
          <div className="flex gap-2 mt-5 p-1 bg-slate-800/80 rounded-xl border border-slate-700/60">
            <button
              onClick={() => { setTab('LOGIN'); setErrorMessage(null); }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                tab === 'LOGIN' 
                  ? 'bg-indigo-600 text-white shadow-sm' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              로그인 & 관리자 인증
            </button>
            <button
              onClick={() => { setTab('SIGNUP'); setErrorMessage(null); }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all ${
                tab === 'SIGNUP' 
                  ? 'bg-indigo-600 text-white shadow-sm' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              신규 회원가입
            </button>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-5">

          {/* Admin Notice Banner if required */}
          {isAdminRequired && tab === 'LOGIN' && (
            <div className="p-3.5 bg-indigo-50/80 border border-indigo-200 rounded-2xl flex items-start gap-3">
              <KeyRound className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
              <div className="text-xs text-indigo-900 leading-relaxed">
                <span className="font-bold block">관리자 CRM 접근권한 안내</span>
                슈퍼 관리자(<span className="font-mono font-bold">fujinilove@gmail.com</span>) 및 등록된 심사역 계정으로 로그인하시거나, 아래 <span className="font-bold">마스터 패스코드(초기: 2026)</span>를 통해 즉시 보안 검증을 통과할 수 있습니다.
              </div>
            </div>
          )}

          {/* Error & Success Messages */}
          {errorMessage && (
            <div className="p-3.5 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-2.5 text-xs text-red-700 font-medium">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successNotice && (
            <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center gap-2.5 text-xs text-emerald-700 font-bold animate-pulse">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{successNotice}</span>
            </div>
          )}

          {/* Google Quick Button (Available in both tabs) */}
          <div>
            <button
              type="button"
              onClick={handleGoogleAuth}
              disabled={isLoading}
              className="w-full flex items-center justify-center gap-3 py-3 px-4 bg-white hover:bg-slate-50 border border-slate-300 rounded-2xl font-bold text-xs text-slate-800 shadow-sm transition-all hover:border-slate-400 active:scale-[0.99]"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
              </svg>
              <span>Google 계정으로 1초 {tab === 'LOGIN' ? '빠른 로그인' : '간편 가입'}</span>
            </button>
            <div className="flex items-center my-4">
              <div className="flex-1 border-t border-slate-200"></div>
              <span className="px-3 text-[11px] font-bold text-slate-400 uppercase">또는 이메일 인증</span>
              <div className="flex-1 border-t border-slate-200"></div>
            </div>
          </div>

          {/* TAB 1: LOGIN */}
          {tab === 'LOGIN' && (
            <div className="space-y-4">
              <form onSubmit={handleEmailLogin} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">이메일 계정</label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={loginEmail}
                      onChange={e => setLoginEmail(e.target.value)}
                      placeholder="admin@bizmatch.ai 또는 이메일 입력"
                      className="w-full pl-10 pr-4 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-none transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">비밀번호</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={loginPassword}
                      onChange={e => setLoginPassword(e.target.value)}
                      placeholder="비밀번호를 입력하세요"
                      className="w-full pl-10 pr-10 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-none transition-colors"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs shadow-md shadow-indigo-600/20 transition-all flex items-center justify-center gap-2"
                >
                  <LogIn className="w-4 h-4" />
                  <span>로그인</span>
                </button>
              </form>

              {/* Master Passcode Section for Admin CRM bypass */}
              <div className="pt-2 border-t border-slate-100">
                {!showMasterPinInput ? (
                  <button
                    type="button"
                    onClick={() => setShowMasterPinInput(true)}
                    className="w-full py-2 px-3 text-xs text-indigo-600 hover:text-indigo-800 font-bold bg-indigo-50/50 hover:bg-indigo-50 rounded-xl transition-colors flex items-center justify-center gap-1.5"
                  >
                    <KeyRound className="w-3.5 h-3.5" />
                    <span>관리자 마스터 패스코드로 빠른 잠금 해제 (2026)</span>
                  </button>
                ) : (
                  <form onSubmit={handleMasterPasscodeLogin} className="p-3 bg-slate-50 border border-slate-200 rounded-2xl space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                        <KeyRound className="w-4 h-4 text-amber-500" />
                        관리자 마스터 패스코드
                      </span>
                      <span className="text-[10px] text-slate-500">초기 기본값: 2026</span>
                    </div>
                    <div className="flex gap-2">
                      <input
                        type="password"
                        value={masterPasscode}
                        onChange={e => setMasterPasscode(e.target.value)}
                        placeholder="패스코드 4자리 입력"
                        maxLength={8}
                        className="flex-1 px-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:outline-none focus:border-indigo-600 font-mono tracking-widest text-center"
                      />
                      <button
                        type="submit"
                        disabled={isLoading}
                        className="px-4 py-2 bg-slate-900 hover:bg-black text-white text-xs font-bold rounded-xl shadow-sm transition-all"
                      >
                        인증
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: SIGN UP */}
          {tab === 'SIGNUP' && (
            <form onSubmit={handleSignUp} className="space-y-3.5">
              {/* Member Type Selection */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">가입 유형 선택</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setMemberType('BUSINESS')}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      memberType === 'BUSINESS'
                        ? 'bg-blue-50/70 border-blue-500 text-blue-900 shadow-xs'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Building2 className={`w-4 h-4 ${memberType === 'BUSINESS' ? 'text-blue-600' : 'text-slate-400'}`} />
                      <span className="text-xs font-black">소상공인 회원</span>
                    </div>
                    <span className="text-[10px] text-slate-500 leading-tight block">정책자금 자가진단 및 AI 맞춤 매칭</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setMemberType('ADMIN')}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      memberType === 'ADMIN'
                        ? 'bg-indigo-50/70 border-indigo-500 text-indigo-900 shadow-xs'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <Briefcase className={`w-4 h-4 ${memberType === 'ADMIN' ? 'text-indigo-600' : 'text-slate-400'}`} />
                      <span className="text-xs font-black">심사역 & 관리자</span>
                    </div>
                    <span className="text-[10px] text-slate-500 leading-tight block">CRM 관제탑 및 공고 검수 파이프라인</span>
                  </button>
                </div>
              </div>

              {/* Name & Business */}
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">성명 / 대표자명</label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={name}
                      onChange={e => setName(e.target.value)}
                      placeholder="홍길동"
                      className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">상호 / 기업명</label>
                  <div className="relative">
                    <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={businessName}
                      onChange={e => setBusinessName(e.target.value)}
                      placeholder="우리사업장"
                      className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Email */}
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">이메일 주소</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="example@bizmatch.ai"
                    className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-none"
                  />
                </div>
              </div>

              {/* Password & Confirm */}
              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">비밀번호</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      placeholder="6자 이상"
                      className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">비밀번호 확인</label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={confirmPassword}
                      onChange={e => setConfirmPassword(e.target.value)}
                      placeholder="동일하게 입력"
                      className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:border-indigo-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Admin Code if selected */}
              {memberType === 'ADMIN' && (
                <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl space-y-1.5 animate-fade-in">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                      <KeyRound className="w-3.5 h-3.5 text-amber-600" />
                      관리자 등록 초대 코드
                    </label>
                    <span className="text-[10px] text-amber-700">초기 힌트: BIZ-ADMIN-2026</span>
                  </div>
                  <input
                    type="text"
                    value={adminCode}
                    onChange={e => setAdminCode(e.target.value)}
                    placeholder="BIZ-ADMIN-2026 입력"
                    className="w-full px-3 py-1.5 text-xs bg-white border border-amber-300 rounded-lg focus:outline-none focus:border-amber-500 font-mono uppercase"
                  />
                  <p className="text-[10px] text-amber-800">
                    관리자 CRM 보안을 위해 승인된 심사역 초대 코드를 확인합니다.
                  </p>
                </div>
              )}

              {/* Terms Checkbox */}
              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="agreeTerms"
                  checked={agreeTerms}
                  onChange={e => setAgreeTerms(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4"
                />
                <label htmlFor="agreeTerms" className="text-xs text-slate-600 select-none">
                  <span className="font-bold text-slate-800">이용약관</span> 및 <span className="font-bold text-slate-800">개인정보 처리방침</span>에 동의합니다.
                </label>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs shadow-md shadow-indigo-600/20 transition-all flex items-center justify-center gap-2"
              >
                <Sparkles className="w-4 h-4" />
                <span>회원가입 완료 및 서비스 시작</span>
              </button>
            </form>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 text-center text-[11px] text-slate-500">
          {tab === 'LOGIN' ? (
            <span>
              아직 계정이 없으신가요?{' '}
              <button
                type="button"
                onClick={() => setTab('SIGNUP')}
                className="font-bold text-indigo-600 hover:underline"
              >
                무료 회원가입
              </button>
            </span>
          ) : (
            <span>
              이미 계정이 있으신가요?{' '}
              <button
                type="button"
                onClick={() => setTab('LOGIN')}
                className="font-bold text-indigo-600 hover:underline"
              >
                로그인하기
              </button>
            </span>
          )}
        </div>

      </div>
    </div>
  );
};
