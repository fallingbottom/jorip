import React, { useState, useEffect } from 'react';
import { X, Search, FileText, Banknote, Sparkles } from 'lucide-react';

export const TutorialModal: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState(0);

  useEffect(() => {
    const hasSeenTutorial = localStorage.getItem('hasSeenTutorial');
    if (!hasSeenTutorial) {
      setIsOpen(true);
    }
  }, []);

  const handleClose = () => {
    localStorage.setItem('hasSeenTutorial', 'true');
    setIsOpen(false);
  };

  if (!isOpen) return null;

  const steps = [
    {
      title: 'BizMatch AI에 오신 것을 환영합니다',
      description: '소상공인 정책자금을 가장 빠르고 정확하게 찾아주는 AI 맞춤형 매칭 서비스입니다.',
      icon: <Sparkles className="w-12 h-12 text-blue-500" />
    },
    {
      title: '1단계: 기업 정보 입력',
      description: '사업자 번호, 업종, 매출액 등 기본적인 사업체 정보를 입력합니다.',
      icon: <FileText className="w-12 h-12 text-indigo-500" />
    },
    {
      title: '2단계: AI 실시간 매칭 분석',
      description: '최신 정책자금 데이터를 바탕으로 귀하의 조건에 맞는 최적의 자금을 AI가 탐색합니다.',
      icon: <Search className="w-12 h-12 text-blue-500" />
    },
    {
      title: '3단계: 맞춤형 보고서 확인',
      description: '추천 자금, 승인 확률, 필요 서류 가이드까지 한눈에 확인하고 바로 준비하세요!',
      icon: <Banknote className="w-12 h-12 text-emerald-500" />
    }
  ];

  return (
    <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl w-full max-w-md overflow-hidden relative shadow-2xl animate-fade-in">
        <button 
          onClick={handleClose}
          className="absolute right-4 top-4 text-slate-400 hover:text-slate-600 transition-colors p-2"
        >
          <X className="w-5 h-5" />
        </button>
        
        <div className="p-8 pb-6">
          <div className="flex justify-center mb-6">
            <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center">
              {steps[step].icon}
            </div>
          </div>
          <h2 className="text-xl font-black text-center text-slate-900 mb-4">{steps[step].title}</h2>
          <p className="text-slate-600 text-center leading-relaxed h-16 text-sm">{steps[step].description}</p>
        </div>
        
        <div className="bg-slate-50 p-6 flex items-center justify-between">
          <div className="flex gap-2">
            {steps.map((_, i) => (
              <div 
                key={i} 
                className={`w-2 h-2 rounded-full transition-all ${i === step ? 'w-6 bg-blue-600' : 'bg-slate-300'}`}
              />
            ))}
          </div>
          <div className="flex gap-3">
            {step > 0 && (
              <button 
                onClick={() => setStep(s => s - 1)}
                className="px-4 py-2 font-bold text-slate-500 hover:text-slate-700 text-sm transition-colors"
              >
                이전
              </button>
            )}
            <button 
              onClick={() => {
                if (step < steps.length - 1) {
                  setStep(s => s + 1);
                } else {
                  handleClose();
                }
              }}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl shadow-md transition-colors"
            >
              {step < steps.length - 1 ? '다음' : '시작하기'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
