import React, { useState } from 'react';
import { SourcePolicy, PolicyFund } from '../types';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight, Bell, Star, Search } from 'lucide-react';
import { createCalendarEvent } from '../services/workspaceService';

interface CalendarViewProps {
  policies: SourcePolicy[];
  token?: string | null;
  favorites?: (PolicyFund | SourcePolicy)[];
  onToggleFavorite?: (fund: SourcePolicy | PolicyFund) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({ policies, token, favorites = [], onToggleFavorite }) => {
  const [currentDate, setCurrentDate] = useState(new Date('2026-07-01')); // Default to July 2026 per context

  const isFavorited = (policyName: string) => {
    return favorites.some(item => {
      const name = 'title' in item ? item.title : item.name;
      return name === policyName;
    });
  };
  
  const [filters, setFilters] = useState({
    open: true,
    upcoming: true,
    closingSoon: true
  });

  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };
  
  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };

  const daysInMonth = getDaysInMonth(currentDate);
  const firstDay = getFirstDayOfMonth(currentDate);
  
  const [searchTerm, setSearchTerm] = useState('');

  const filteredPolicies = policies.filter(p => 
    p.name.includes(searchTerm) || 
    p.description.includes(searchTerm) || 
    p.agency.includes(searchTerm)
  );

  const monthName = currentDate.toLocaleString('ko-KR', { month: 'long', year: 'numeric' });

  const getPoliciesForDate = (day: number) => {
    const currentStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return policies.filter(p => {
      if (!p.startDate || !p.endDate) return false;
      if (!(currentStr >= p.startDate && currentStr <= p.endDate)) return false;
      
      const isClosingSoon = p.currentStatus === 'BUDGET_ALMOST_EXHAUSTED';
      const isOpen = p.currentStatus === 'OPEN';
      
      if (isClosingSoon && filters.closingSoon) return true;
      if (isOpen && filters.open) return true;
      
      return false;
    });
  };

  const getPoliciesForAnnouncement = (day: number) => {
    if (!filters.upcoming) return [];
    const currentStr = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return policies.filter(p => p.announcementDate === currentStr);
  };

  const handleSetReminder = async (policy: SourcePolicy) => {
    if (!token) {
      alert("알림을 설정하려면 Google 연동 로그인이 필요합니다.");
      return;
    }
    
    if (!policy.startDate) {
      alert("시작일 정보가 없어 알림을 설정할 수 없습니다.");
      return;
    }

    const confirmMsg = `[알림 설정] '${policy.name}' 정책자금 신청 시작일 알림을 구글 캘린더에 등록하시겠습니까?`;
    if (!window.confirm(confirmMsg)) return;

    try {
      const summary = `🔔 [신청 시작] ${policy.name}`;
      const description = `정책자금명: ${policy.name}\n기관: ${policy.agency}\n이율: ${policy.baseInterestRate}\n신청기간: ${policy.startDate} ~ ${policy.endDate}\n상태: ${policy.currentStatus}`;
      const startDateTime = `${policy.startDate}T09:00:00`;
      const endDateTime = `${policy.startDate}T10:00:00`;

      await createCalendarEvent(token, summary, description, startDateTime, endDateTime);
      alert(`'${policy.name}' 알림이 구글 캘린더에 성공적으로 등록되었습니다!`);
    } catch (err) {
      console.error(err);
      alert("알림 설정에 실패했습니다. 권한을 확인해주세요.");
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 max-w-5xl mx-auto">
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8 gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center">
            <CalendarIcon className="w-5 h-5 text-indigo-600" />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900">정책자금 공고 캘린더</h2>
            <p className="text-xs font-bold text-slate-500">주요 기관의 공고 및 신청 일정을 한눈에 확인하고 알림을 설정하세요.</p>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row items-center gap-6">
          <div className="flex items-center gap-4 bg-slate-50 px-4 py-2 rounded-xl border border-slate-100">
            <label className="flex items-center gap-2 cursor-pointer">
              <input 
                type="checkbox" 
                checked={filters.open} 
                onChange={() => setFilters(f => ({ ...f, open: !f.open }))} 
                className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 border-slate-300" 
              />
              <span className="text-sm font-bold text-slate-700">접수 중</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input 
                type="checkbox" 
                checked={filters.upcoming} 
                onChange={() => setFilters(f => ({ ...f, upcoming: !f.upcoming }))} 
                className="w-4 h-4 rounded text-amber-500 focus:ring-amber-500 border-slate-300" 
              />
              <span className="text-sm font-bold text-slate-700">공고 예정</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input 
                type="checkbox" 
                checked={filters.closingSoon} 
                onChange={() => setFilters(f => ({ ...f, closingSoon: !f.closingSoon }))} 
                className="w-4 h-4 rounded text-red-500 focus:ring-red-500 border-slate-300" 
              />
              <span className="text-sm font-bold text-slate-700">마감 임박</span>
            </label>
          </div>

          <div className="flex items-center gap-4">
            <button onClick={handlePrevMonth} className="p-2 hover:bg-slate-50 rounded-lg text-slate-400 hover:text-slate-600 transition-colors">
              <ChevronLeft className="w-5 h-5" />
            </button>
            <span className="font-black text-lg text-slate-800 min-w-[120px] text-center">{monthName}</span>
            <button onClick={handleNextMonth} className="p-2 hover:bg-slate-50 rounded-lg text-slate-400 hover:text-slate-600 transition-colors">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-px bg-slate-100 border border-slate-100 rounded-xl overflow-hidden">
        {['일', '월', '화', '수', '목', '금', '토'].map((day, i) => (
          <div key={day} className={`p-3 bg-slate-50 text-center font-bold text-xs ${i === 0 ? 'text-red-500' : i === 6 ? 'text-blue-500' : 'text-slate-500'}`}>
            {day}
          </div>
        ))}
        
        {Array.from({ length: firstDay }).map((_, i) => (
          <div key={`empty-${i}`} className="bg-white p-2 min-h-[120px]"></div>
        ))}
        
        {Array.from({ length: daysInMonth }).map((_, i) => {
          const day = i + 1;
          const policiesForDate = getPoliciesForDate(day);
          const announcementsForDate = getPoliciesForAnnouncement(day);
          const isToday = new Date().getDate() === day && currentDate.getMonth() === new Date().getMonth() && currentDate.getFullYear() === new Date().getFullYear();

          return (
            <div key={day} className={`bg-white p-2 min-h-[120px] relative group border-t border-slate-100 ${isToday ? 'bg-blue-50/30' : ''}`}>
              <span className={`inline-flex items-center justify-center w-6 h-6 text-xs font-bold rounded-full mb-1 ${isToday ? 'bg-blue-600 text-white' : 'text-slate-700'}`}>
                {day}
              </span>
              
              <div className="flex flex-col gap-1 mt-1">
                {announcementsForDate.map((p, idx) => (
                  <div key={`ann-${idx}`} className="text-[9px] px-1.5 py-0.5 rounded bg-amber-50 text-amber-700 border border-amber-100 truncate cursor-pointer hover:bg-amber-100 group relative">
                    📣 {p.name} 공고
                    <div className="hidden group-hover:flex absolute left-full top-0 ml-2 z-10 w-48 bg-white border border-slate-200 shadow-xl rounded-lg p-3 flex-col gap-2">
                      <div className="font-bold text-slate-800 text-[10px]">{p.name}</div>
                      <div className="text-[9px] text-slate-500">{p.agency}</div>
                      <button 
                        onClick={() => handleSetReminder(p)}
                        className="mt-1 flex items-center justify-center gap-1 bg-indigo-50 text-indigo-600 py-1 px-2 rounded-md font-bold hover:bg-indigo-100"
                      >
                        <Bell className="w-3 h-3" /> 알림 설정
                      </button>
                    </div>
                  </div>
                ))}
                
                {policiesForDate.map((p, idx) => {
                  const isStart = p.startDate && new Date(p.startDate).getDate() === day && new Date(p.startDate).getMonth() === currentDate.getMonth();
                  const isEnd = p.endDate && new Date(p.endDate).getDate() === day && new Date(p.endDate).getMonth() === currentDate.getMonth();
                  
                  return (
                    <div key={`pol-${idx}`} className={`text-[9px] px-1.5 py-0.5 rounded border truncate cursor-pointer relative group ${
                      isStart ? 'bg-emerald-50 text-emerald-700 border-emerald-100 font-bold' : 
                      isEnd ? 'bg-red-50 text-red-700 border-red-100 font-bold' : 
                      'bg-blue-50/50 text-blue-600 border-transparent hover:border-blue-100'
                    }`}>
                      {isStart ? '▶ 시작: ' : isEnd ? '◀ 마감: ' : '· '}{p.name}
                      <div className="hidden group-hover:flex absolute left-full top-0 ml-2 z-10 w-48 bg-white border border-slate-200 shadow-xl rounded-lg p-3 flex-col gap-2">
                        <div className="font-bold text-slate-800 text-[10px]">{p.name}</div>
                        <div className="text-[9px] text-slate-500">기간: {p.startDate} ~ {p.endDate}</div>
                        <div className="text-[9px] text-slate-500">이율: {p.baseInterestRate}</div>
                        <div className="flex gap-1 mt-1">
                          {onToggleFavorite && (
                            <button
                              onClick={() => onToggleFavorite(p)}
                              className={`flex-1 flex items-center justify-center gap-1 py-1 px-2 rounded-md font-bold text-[9px] border transition-colors ${
                                isFavorited(p.name)
                                  ? 'bg-amber-50 text-amber-600 border-amber-200'
                                  : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
                              }`}
                            >
                              <Star className={`w-3 h-3 ${isFavorited(p.name) ? 'fill-amber-400 text-amber-500' : ''}`} />
                              {isFavorited(p.name) ? '즐겨찾기됨' : '즐겨찾기'}
                            </button>
                          )}
                          <button 
                            onClick={() => handleSetReminder(p)}
                            className="flex-1 flex items-center justify-center gap-1 bg-indigo-50 text-indigo-600 py-1 px-2 rounded-md font-bold text-[9px] hover:bg-indigo-100"
                          >
                            <Bell className="w-3 h-3" /> 알림
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-12 bg-white rounded-3xl border border-slate-100 p-8 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <h3 className="text-xl font-black text-slate-900">전체 정책자금 검색</h3>
            <p className="text-sm font-medium text-slate-500 mt-1">이름, 기관, 설명으로 지원 상품을 검색하세요.</p>
          </div>
          <div className="relative w-full md:w-72">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="자금명 또는 기관 검색..." 
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPolicies.length === 0 ? (
            <div className="col-span-full py-10 text-center text-slate-400 font-bold">
              검색 결과가 없습니다.
            </div>
          ) : (
            filteredPolicies.map((p, idx) => (
              <div key={idx} className="p-5 border border-slate-100 rounded-2xl hover:shadow-md transition-shadow bg-slate-50/50 flex flex-col h-full">
                <div className="flex justify-between items-start mb-3">
                  <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md">{p.agency}</span>
                  <span className="text-[10px] font-bold text-slate-400 border border-slate-200 px-1.5 py-0.5 rounded-full">{p.currentStatus === 'OPEN' ? '접수중' : p.currentStatus}</span>
                </div>
                <h4 className="font-bold text-slate-900 text-lg mb-2">{p.name}</h4>
                <p className="text-xs text-slate-600 font-medium leading-relaxed mb-4 flex-1">{p.description}</p>
                
                <div className="space-y-2 mt-auto">
                  <div className="flex items-center justify-between text-xs border-t border-slate-100 pt-3">
                    <span className="text-slate-500 font-bold">한도</span>
                    <span className="font-black text-slate-800">{p.maxAmount}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500 font-bold">금리</span>
                    <span className="font-black text-slate-800">{p.baseInterestRate}</span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
