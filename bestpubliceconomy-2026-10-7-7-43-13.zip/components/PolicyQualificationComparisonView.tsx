import React, { useState, useMemo } from 'react';
import { 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Info, 
  Landmark, 
  Percent, 
  Banknote, 
  Calendar, 
  ArrowRight, 
  FileText, 
  ExternalLink, 
  ChevronDown, 
  ChevronUp, 
  HelpCircle,
  Clock,
  Briefcase,
  Users,
  ShieldAlert,
  Sparkles,
  ArrowUpDown,
  Filter,
  Factory,
  Leaf,
  BarChart3
} from 'lucide-react';
import { 
  UserProfile, 
  ComprehensiveEvaluationResult, 
  PolicyComparisonAnalysis 
} from '../types';
import { formatKoreanCurrency } from '../services/policyEligibilityMatcher';

interface PolicyQualificationComparisonViewProps {
  profile: UserProfile;
  evaluationResult: ComprehensiveEvaluationResult;
  onApplyFundClick?: (fund: PolicyComparisonAnalysis) => void;
  onOpenChecklistModal?: (fundTitle: string) => void;
  onNavigateToComparisonDashboard?: () => void;
}

export const PolicyQualificationComparisonView: React.FC<PolicyQualificationComparisonViewProps> = ({
  profile,
  evaluationResult,
  onApplyFundClick,
  onOpenChecklistModal,
  onNavigateToComparisonDashboard
}) => {
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'ELIGIBLE' | 'CONDITIONAL' | 'INELIGIBLE'>('ALL');
  const [sortBy, setSortBy] = useState<'MATCH' | 'AMOUNT' | 'RATE'>('MATCH');
  const [expandedFundId, setExpandedFundId] = useState<string | null>(
    evaluationResult.recommendedFunds[0]?.fundId || null
  );

  const { summary, recommendedFunds, restrictedOrIneligibleFunds, strategicRoadmap, restrictionAlerts } = evaluationResult;

  const allFunds = useMemo(() => {
    return [...recommendedFunds, ...restrictedOrIneligibleFunds];
  }, [recommendedFunds, restrictedOrIneligibleFunds]);

  const filteredFunds = useMemo(() => {
    let list = [...allFunds];
    if (activeFilter === 'ELIGIBLE') {
      list = list.filter(f => f.qualificationStatus === 'ELIGIBLE');
    } else if (activeFilter === 'CONDITIONAL') {
      list = list.filter(f => f.qualificationStatus === 'CONDITIONAL');
    } else if (activeFilter === 'INELIGIBLE') {
      list = list.filter(f => f.qualificationStatus === 'INELIGIBLE');
    }

    if (sortBy === 'MATCH') {
      list.sort((a, b) => b.matchScore - a.matchScore);
    } else if (sortBy === 'AMOUNT') {
      list.sort((a, b) => b.estimatedAmount.recommendedAmount - a.estimatedAmount.recommendedAmount);
    } else if (sortBy === 'RATE') {
      list.sort((a, b) => a.estimatedInterestRate.expectedRateValue - b.estimatedInterestRate.expectedRateValue);
    }
    return list;
  }, [allFunds, activeFilter, sortBy]);

  const toggleExpand = (fundId: string) => {
    setExpandedFundId(prev => prev === fundId ? null : fundId);
  };

  return (
    <div className="space-y-8 animate-fade-in text-slate-800">
      {/* 1. 최상단 요약 브리핑 헤더 */}
      <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-blue-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-blue-500/10 blur-3xl pointer-events-none"></div>
        <div className="relative z-10 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-5">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-500/20 text-blue-300 border border-blue-400/30 rounded-full text-xs font-bold mb-2">
                <Sparkles className="w-3.5 h-3.5 text-blue-400" />
                정부 지원 소상공인 정책자금 자격 요건 정밀 비교 분석
              </div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
                <span>{profile.businessName}</span>
                <span className="text-sm font-normal text-slate-300">맞춤형 지원 가능 자금 진단</span>
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 mt-1">
                업종, 매출액, 상시 종사자 수, 부채비율({summary.debtRatioValue}%), 신청 이력을 종합 비교 검토한 결과입니다.
              </p>
              {profile.policyBonusFactors && (
                <div className="flex items-center gap-1.5 flex-wrap pt-2">
                  <span className="text-[10px] text-slate-400 font-bold">인정된 정책 가점:</span>
                  {profile.policyBonusFactors.hasSmartFactory && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-400/40">
                      <Factory className="w-3 h-3" /> 스마트공장·공방 우대
                    </span>
                  )}
                  {profile.policyBonusFactors.hasCarbonNeutrality && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-400/40">
                      <Leaf className="w-3 h-3" /> 탄소중립 ESG 실천
                    </span>
                  )}
                  {profile.policyBonusFactors.hasJobCreation && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-400/40">
                      <Users className="w-3 h-3" /> 일자리 창출 우수
                    </span>
                  )}
                  {profile.policyBonusFactors.hasVentureOrInnoBiz && (
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-400/40">
                      <Sparkles className="w-3 h-3" /> 기술혁신·특허
                    </span>
                  )}
                  {!profile.policyBonusFactors.hasSmartFactory && !profile.policyBonusFactors.hasCarbonNeutrality && (
                    <span className="text-[10px] text-slate-400 italic">스마트공장/탄소중립 등 가점 미등록</span>
                  )}
                </div>
              )}
            </div>

            <div className="flex items-center gap-3">
              {onNavigateToComparisonDashboard && (
                <button
                  type="button"
                  onClick={onNavigateToComparisonDashboard}
                  className="flex items-center gap-1.5 px-3.5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white rounded-2xl text-xs font-black shadow-md transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
                  title="분석된 정책자금들의 금리/한도/승인확률 차트 요약 비교 대시보드로 이동"
                >
                  <BarChart3 className="w-4 h-4 text-purple-200" />
                  <span>비교 대시보드 (차트 요약)</span>
                </button>
              )}
              <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-2xl border border-white/10 text-right">
                <span className="text-[11px] text-slate-300 block font-medium">종합 재무/신용 등급</span>
                <span className="text-sm sm:text-base font-black text-amber-300">{summary.overallBusinessGrade}</span>
              </div>
            </div>
          </div>

          {/* 5대 핵심 지표 그리드 */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
            <div className="bg-white/10 backdrop-blur-sm p-4 rounded-2xl border border-white/10">
              <div className="flex items-center gap-1.5 text-slate-300 text-xs font-medium mb-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                신청 가능 자금
              </div>
              <div className="text-xl sm:text-2xl font-black text-emerald-300">
                {summary.eligibleCount}
                <span className="text-xs font-bold text-slate-300 ml-1">건 (적격)</span>
              </div>
              <span className="text-[10px] text-slate-400 block mt-1">조건부 {summary.conditionalCount}건 포함</span>
            </div>

            <div className="bg-white/10 backdrop-blur-sm p-4 rounded-2xl border border-white/10">
              <div className="flex items-center gap-1.5 text-slate-300 text-xs font-medium mb-1">
                <Banknote className="w-3.5 h-3.5 text-blue-400" />
                총 예상 추천 한도
              </div>
              <div className="text-xl sm:text-2xl font-black text-blue-300">
                {formatKoreanCurrency(summary.totalAvailableEstimatedFunding)}
              </div>
              <span className="text-[10px] text-slate-400 block mt-1">연매출 상환능력 기준</span>
            </div>

            <div className="bg-white/10 backdrop-blur-sm p-4 rounded-2xl border border-white/10">
              <div className="flex items-center gap-1.5 text-slate-300 text-xs font-medium mb-1">
                <Percent className="w-3.5 h-3.5 text-indigo-400" />
                평균 예상 금리
              </div>
              <div className="text-xl sm:text-2xl font-black text-indigo-300">
                연 {summary.averageExpectedRate.toFixed(2)}%
              </div>
              <span className="text-[10px] text-slate-400 block mt-1">우대금리 반영 추정</span>
            </div>

            <div className="bg-white/10 backdrop-blur-sm p-4 rounded-2xl border border-white/10">
              <div className="flex items-center gap-1.5 text-slate-300 text-xs font-medium mb-1">
                <Briefcase className="w-3.5 h-3.5 text-amber-400" />
                부채비율 진단
              </div>
              <div className="text-xl sm:text-2xl font-black text-amber-300">
                {summary.debtRatioValue}%
              </div>
              <span className="text-[10px] text-slate-300 block mt-1">
                {summary.debtRatioGrade === 'SAFE' && '안전 (추가 한도 여력 큼)'}
                {summary.debtRatioGrade === 'NORMAL' && '적정 (통상 승인 범위)'}
                {summary.debtRatioGrade === 'WARNING' && '주의 (한도 일부 감액)'}
                {summary.debtRatioGrade === 'HIGH_RISK' && '고위험 (대환/재도전 우선)'}
              </span>
            </div>

            <div className="bg-white/10 backdrop-blur-sm p-4 rounded-2xl border border-white/10 col-span-2 sm:col-span-1">
              <div className="flex items-center gap-1.5 text-slate-300 text-xs font-medium mb-1">
                <Calendar className="w-3.5 h-3.5 text-rose-400" />
                과거 신청 이력
              </div>
              <div className="text-sm font-bold text-white leading-tight">
                {summary.priorApplicationSummary}
              </div>
              <span className="text-[10px] text-slate-400 block mt-1">중복보증/재신청 검토완료</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. 중복/부결/체납 제한 주의사항 알림 배너 */}
      {restrictionAlerts.length > 0 && (
        <div className="space-y-3">
          {restrictionAlerts.map((alert, idx) => (
            <div 
              key={idx}
              className={`p-4 sm:p-5 rounded-2xl border flex items-start gap-3.5 shadow-xs ${
                alert.type === 'CRITICAL'
                  ? 'bg-rose-50 border-rose-200 text-rose-900'
                  : alert.type === 'WARNING'
                    ? 'bg-amber-50 border-amber-200 text-amber-900'
                    : 'bg-blue-50 border-blue-200 text-blue-900'
              }`}
            >
              {alert.type === 'CRITICAL' ? (
                <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              ) : alert.type === 'WARNING' ? (
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              ) : (
                <Info className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              )}
              <div className="space-y-1 text-xs sm:text-sm">
                <h4 className="font-bold">{alert.title}</h4>
                <p className="opacity-90">{alert.message}</p>
                <div className="pt-1.5 flex items-center gap-1.5 text-xs font-semibold text-slate-700">
                  <span className="bg-white/80 px-2 py-0.5 rounded-md border border-black/10">추천 대응책</span>
                  <span>{alert.solution}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 3. 필터 및 정렬 바 */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          <button
            type="button"
            onClick={() => setActiveFilter('ALL')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
              activeFilter === 'ALL'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            전체 ({allFunds.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveFilter('ELIGIBLE')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
              activeFilter === 'ELIGIBLE'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
            }`}
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            신청 가능 (적격) ({summary.eligibleCount})
          </button>
          <button
            type="button"
            onClick={() => setActiveFilter('CONDITIONAL')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
              activeFilter === 'CONDITIONAL'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'bg-amber-50 text-amber-800 hover:bg-amber-100'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            조건부 신청 (주의) ({summary.conditionalCount})
          </button>
          <button
            type="button"
            onClick={() => setActiveFilter('INELIGIBLE')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
              activeFilter === 'INELIGIBLE'
                ? 'bg-slate-700 text-white shadow-xs'
                : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
            }`}
          >
            <XCircle className="w-3.5 h-3.5" />
            신청 불가 (비교분석) ({summary.ineligibleCount})
          </button>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          <span className="text-xs text-slate-500 font-medium flex items-center gap-1">
            <ArrowUpDown className="w-3.5 h-3.5" /> 정렬:
          </span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="text-xs font-bold bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-slate-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="MATCH">추천 적합도순</option>
            <option value="AMOUNT">예상 한도 높은순</option>
            <option value="RATE">예상 최저금리순</option>
          </select>
        </div>
      </div>

      {/* 4. 자금별 정밀 비교 분석 카드 목록 */}
      <div className="space-y-4">
        {filteredFunds.map((fund) => {
          const isExpanded = expandedFundId === fund.fundId;
          const isEligible = fund.qualificationStatus === 'ELIGIBLE';
          const isConditional = fund.qualificationStatus === 'CONDITIONAL';
          const isIneligible = fund.qualificationStatus === 'INELIGIBLE';

          return (
            <div
              key={fund.fundId}
              className={`bg-white rounded-3xl border transition-all duration-200 overflow-hidden ${
                isEligible
                  ? 'border-emerald-200 shadow-sm hover:border-emerald-300'
                  : isConditional
                    ? 'border-amber-200 shadow-sm hover:border-amber-300'
                    : 'border-slate-200 opacity-80 hover:opacity-100'
              }`}
            >
              {/* 카드 상단 헤더 행 */}
              <div 
                onClick={() => toggleExpand(fund.fundId)}
                className="p-5 sm:p-6 cursor-pointer hover:bg-slate-50/50 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-2 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    {/* 상태 라벨 뱃지 */}
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black border ${
                      isEligible
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                        : isConditional
                          ? 'bg-amber-50 text-amber-800 border-amber-300'
                          : 'bg-rose-50 text-rose-700 border-rose-300'
                    }`}>
                      {isEligible && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />}
                      {isConditional && <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />}
                      {isIneligible && <XCircle className="w-3.5 h-3.5 text-rose-600" />}
                      {fund.qualificationStatusLabel}
                    </span>

                    <span className="text-xs font-bold text-slate-600 bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-200">
                      {fund.agency}
                    </span>

                    {fund.isBudgetLow && (
                      <span className="text-xs font-black text-rose-600 bg-rose-50 px-2.5 py-1 rounded-lg border border-rose-200 animate-pulse">
                        예산 소진 임박
                      </span>
                    )}

                    <span className="ml-auto md:ml-0 text-xs font-black text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg border border-blue-200">
                      적합도 {fund.matchScore}점
                    </span>
                  </div>

                  <h3 className="text-lg font-black text-slate-900 group-hover:text-blue-600 transition-colors">
                    {fund.fundTitle}
                  </h3>

                  <p className="text-xs text-slate-500 line-clamp-1">
                    {fund.category}
                  </p>
                </div>

                {/* 2대 핵심 수치 (예상 한도 & 예상 금리) 요약 표시 */}
                <div className="flex items-center gap-4 border-t md:border-t-0 md:border-l border-slate-100 pt-3 md:pt-0 md:pl-6 shrink-0">
                  <div className="text-left md:text-right">
                    <span className="text-[11px] text-slate-400 font-bold block">예상 지원 한도</span>
                    <span className="text-base sm:text-lg font-black text-blue-600">
                      {formatKoreanCurrency(fund.estimatedAmount.recommendedAmount)}
                    </span>
                  </div>

                  <div className="text-left md:text-right">
                    <span className="text-[11px] text-slate-400 font-bold block">예상 적용 금리</span>
                    <span className="text-base sm:text-lg font-black text-emerald-600">
                      {fund.estimatedInterestRate.formattedRate}
                    </span>
                  </div>

                  <div className="text-slate-400 pl-2">
                    {isExpanded ? (
                      <ChevronUp className="w-5 h-5 text-slate-600" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-slate-600" />
                    )}
                  </div>
                </div>
              </div>

              {/* 상세 자격 요건 대조표 및 심사 가이드 (펼침 영역) */}
              {isExpanded && (
                <div className="border-t border-slate-100 bg-slate-50/70 p-5 sm:p-7 space-y-6 animate-fade-in">
                  {/* (1) 자격 요건 vs 내 사업체 정밀 대조 테이블 */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                      <FileText className="w-4 h-4 text-blue-600" />
                      자격 요건 정밀 대조 분석표
                    </h4>
                    
                    <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-2xs">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200">
                          <tr>
                            <th className="py-3 px-4 w-1/5">항목</th>
                            <th className="py-3 px-4 w-1/4">정부 공고 기준 요건</th>
                            <th className="py-3 px-4 w-1/4">내 사업체 현황</th>
                            <th className="py-3 px-3 w-20 text-center">판정</th>
                            <th className="py-3 px-4">분석 및 심사 의견</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {fund.criteriaChecks.map((check, idx) => (
                            <tr key={idx} className="hover:bg-slate-50/50 transition-colors">
                              <td className="py-3 px-4 font-bold text-slate-900">
                                {check.criterion}
                              </td>
                              <td className="py-3 px-4 text-slate-600 font-medium">
                                {check.policyRequirement}
                              </td>
                              <td className="py-3 px-4 font-bold text-slate-800">
                                {check.userValue}
                              </td>
                              <td className="py-3 px-3 text-center">
                                {check.status === 'MET' && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-md font-black text-[11px]">
                                    충족
                                  </span>
                                )}
                                {check.status === 'WARNING' && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-50 text-amber-800 border border-amber-200 rounded-md font-black text-[11px]">
                                    주의
                                  </span>
                                )}
                                {check.status === 'FAILED' && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-rose-50 text-rose-700 border border-rose-200 rounded-md font-black text-[11px]">
                                    미달
                                  </span>
                                )}
                              </td>
                              <td className="py-3 px-4 text-slate-600 text-[11px] leading-relaxed">
                                {check.detail}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  {/* (2) 예상 지원 금액 및 금리 산정 근거 */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-white p-4 sm:p-5 rounded-2xl border border-blue-100 shadow-2xs space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-blue-900 flex items-center gap-1.5">
                          <Banknote className="w-4 h-4 text-blue-600" />
                          예상 지원 금액 상세 산출
                        </span>
                        <span className="text-sm font-black text-blue-600">
                          {fund.estimatedAmount.formattedAmount}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 bg-blue-50/50 p-3 rounded-xl border border-blue-100/50 leading-relaxed">
                        <strong>산정 근거:</strong> {fund.estimatedAmount.calculationBasis}
                      </p>
                      <div className="text-[11px] text-slate-500 pt-1 flex items-center justify-between">
                        <span>최소 신청 가능액: {formatKoreanCurrency(fund.estimatedAmount.minAmount)}</span>
                        <span>최대 공고 한도: {formatKoreanCurrency(fund.estimatedAmount.maxAmount)}</span>
                      </div>
                    </div>

                    <div className="bg-white p-4 sm:p-5 rounded-2xl border border-emerald-100 shadow-2xs space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-black text-emerald-900 flex items-center gap-1.5">
                          <Percent className="w-4 h-4 text-emerald-600" />
                          예상 금리 및 우대 감면
                        </span>
                        <span className="text-sm font-black text-emerald-600">
                          {fund.estimatedInterestRate.formattedRate}
                        </span>
                      </div>
                      <div className="text-xs text-slate-600 bg-emerald-50/50 p-3 rounded-xl border border-emerald-100/50 space-y-1">
                        <div><strong>기본 금리 체계:</strong> {fund.estimatedInterestRate.baseRate}</div>
                        {fund.estimatedInterestRate.discountConditions.length > 0 && (
                          <div className="text-emerald-700 font-medium">
                            적용 가능 우대 조건: {fund.estimatedInterestRate.discountConditions.join(', ')}
                          </div>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500 pt-1">
                        상환 조건: {fund.repaymentPeriod}
                      </div>
                    </div>
                  </div>

                  {/* (3) 심사 통과를 위한 맞춤형 조언 및 주의사항 */}
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs space-y-3">
                    <h5 className="text-xs font-black text-slate-800 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-500" />
                      심사 승인 통과 전략 & 컨설턴트 의견
                    </h5>
                    <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                      {fund.strategicAdvice}
                    </p>

                    {fund.applicationCaution && (
                      <div className="p-3 bg-amber-50 text-amber-800 rounded-xl text-xs border border-amber-200 font-medium flex items-center gap-2">
                        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                        <span>{fund.applicationCaution}</span>
                      </div>
                    )}
                  </div>

                  {/* (4) 구비 서류 및 액션 버튼 바 */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-2">
                    <div className="text-xs text-slate-500 flex flex-wrap items-center gap-2">
                      <span className="font-bold text-slate-700">필수 구비서류:</span>
                      {fund.requiredDocuments.slice(0, 3).map((doc, dIdx) => (
                        <span key={dIdx} className="bg-slate-200/70 text-slate-700 px-2 py-0.5 rounded-md text-[11px]">
                          {doc}
                        </span>
                      ))}
                      {fund.requiredDocuments.length > 3 && (
                        <span className="text-[11px] text-slate-400">외 {fund.requiredDocuments.length - 3}종</span>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {onOpenChecklistModal && (
                        <button
                          type="button"
                          onClick={() => onOpenChecklistModal(fund.fundTitle)}
                          className="px-3.5 py-2 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer flex items-center gap-1.5"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          서류 체크리스트
                        </button>
                      )}

                      <a
                        href={fund.onlineApplyUrl || 'https://ols.semas.or.kr'}
                        target="_blank"
                        rel="noreferrer noopener"
                        className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 shadow-xs cursor-pointer ${
                          isEligible
                            ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-blue-500/20'
                            : isConditional
                              ? 'bg-amber-600 hover:bg-amber-700 text-white shadow-amber-500/20'
                              : 'bg-slate-700 hover:bg-slate-800 text-white'
                        }`}
                      >
                        공식 접수처 이동
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {filteredFunds.length === 0 && (
          <div className="text-center py-12 bg-white rounded-3xl border border-slate-200 p-8 space-y-3">
            <Info className="w-8 h-8 text-slate-400 mx-auto" />
            <p className="text-sm font-bold text-slate-600">선택한 필터 조건에 해당하는 자금이 없습니다.</p>
            <button
              type="button"
              onClick={() => setActiveFilter('ALL')}
              className="px-4 py-2 bg-slate-900 text-white text-xs font-bold rounded-xl cursor-pointer"
            >
              전체 자금 목록 보기
            </button>
          </div>
        )}
      </div>

      {/* 5. 최적 정책자금 신청 순서 로드맵 */}
      {strategicRoadmap.length > 0 && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-600" />
              추천 정책자금 신청 실행 로드맵 (Action Plan)
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              승인율을 극대화하고 중복보증 제한 및 부결 페널티를 피하기 위한 단계별 실행 가이드입니다.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {strategicRoadmap.map((step) => (
              <div 
                key={step.stepNumber}
                className={`p-5 rounded-2xl border relative flex flex-col justify-between ${
                  step.priority === 'FIRST_CHOICE'
                    ? 'bg-gradient-to-b from-blue-50/50 to-white border-blue-200 ring-1 ring-blue-200'
                    : 'bg-white border-slate-200'
                }`}
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className={`text-xs font-black px-2.5 py-1 rounded-lg ${
                      step.priority === 'FIRST_CHOICE'
                        ? 'bg-blue-600 text-white'
                        : 'bg-slate-100 text-slate-700'
                    }`}>
                      STEP {step.stepNumber}
                    </span>
                    <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                      {step.timing}
                    </span>
                  </div>

                  <h4 className="font-black text-sm sm:text-base text-slate-900 leading-snug">
                    {step.title}
                  </h4>

                  <div className="text-xs text-blue-700 font-bold">
                    주관: {step.agency}
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {step.actionDescription}
                  </p>
                </div>

                <div className="pt-4 mt-2 border-t border-slate-100 flex items-center justify-between text-[11px] font-bold text-slate-500">
                  <span>우선순위: {step.priority === 'FIRST_CHOICE' ? '최우선(1순위)' : step.priority === 'SECONDARY' ? '2순위 병행' : '차환/후속'}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
