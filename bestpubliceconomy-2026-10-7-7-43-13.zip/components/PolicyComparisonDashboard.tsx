import React, { useState, useMemo } from 'react';
import { PolicyFund, UserProfile, SourcePolicy } from '../types';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
  ReferenceLine,
  ScatterChart,
  Scatter,
  ZAxis,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Legend
} from 'recharts';
import {
  BarChart3,
  TrendingUp,
  Percent,
  Banknote,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  Filter,
  ArrowUpDown,
  Building2,
  Calendar,
  CheckCircle2,
  HelpCircle,
  Zap,
  Award,
  Layers,
  Factory,
  Leaf,
  Scale,
  FileText,
  Clock,
  ExternalLink,
  ChevronRight,
  Info
} from 'lucide-react';
import {
  generateDeepLearningApprovalReport,
  getApprovalLikelihoodTier
} from '../services/deepLearningApprovalEngine';
import { parseFundInterestRate, parseFundMaxAmount } from './FundLoanSimulator';

interface PolicyComparisonDashboardProps {
  funds: PolicyFund[];
  profile: UserProfile | null;
  onSelectFund?: (fund: PolicyFund) => void;
  onOpenApplicationGuide?: (fund: PolicyFund) => void;
  onOpenDeepLearningReport?: (fund: PolicyFund) => void;
  onOpenConsultation?: (fund: PolicyFund) => void;
  onNavigateToMatch?: () => void;
}

export const PolicyComparisonDashboard: React.FC<PolicyComparisonDashboardProps> = ({
  funds,
  profile,
  onSelectFund,
  onOpenApplicationGuide,
  onOpenDeepLearningReport,
  onOpenConsultation,
  onNavigateToMatch
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedAgency, setSelectedAgency] = useState<string>('ALL');
  const [sortMetric, setSortMetric] = useState<'PROBABILITY' | 'RATE' | 'LIMIT' | 'BALANCED'>('BALANCED');
  const [activeChartTab, setActiveChartTab] = useState<'COMPREHENSIVE' | 'PROBABILITY' | 'RATE' | 'LIMIT' | 'RADAR' | 'QUADRANT'>('COMPREHENSIVE');
  const [selectedFundIds, setSelectedFundIds] = useState<string[]>([]);
  const [hoveredFundTitle, setHoveredFundTitle] = useState<string | null>(null);

  // Compute processed metrics for each fund
  const enrichedFunds = useMemo(() => {
    return funds.map((fund, idx) => {
      const rateVal = parseFundInterestRate(fund.interestRate);
      const limitVal = parseFundMaxAmount(fund.maxAmount);
      const dlReport = generateDeepLearningApprovalReport(profile, fund);
      const tierInfo = getApprovalLikelihoodTier(dlReport.overallProbability);
      const bonusAdjustment = dlReport.policyBonusAdjustment;
      const baseProb = bonusAdjustment?.baseProbability ?? dlReport.overallProbability;
      const bonusUplift = bonusAdjustment?.totalBonusUplift ?? 0;

      // Balanced score (0-100 index combining high probability, low rate, high amount)
      // Rate factor: lower is better (max 6% -> min 1.5%)
      const rateScore = Math.max(10, Math.min(100, Math.round(100 - (rateVal - 1.5) * 18)));
      // Limit factor: higher is better (normalized up to 3억)
      const limitScore = Math.max(10, Math.min(100, Math.round((limitVal / 300000000) * 100)));
      // Overall balanced index: 45% probability + 35% rate + 20% limit
      const balancedScore = Math.round(dlReport.overallProbability * 0.45 + rateScore * 0.35 + limitScore * 0.20);

      // Short readable name for chart X-axis
      const shortTitle = fund.title.length > 9 ? `${fund.title.slice(0, 8)}...` : fund.title;

      return {
        id: fund.id || `fund-${idx}`,
        title: fund.title,
        shortTitle,
        agency: fund.agency,
        category: fund.category || '운전자금',
        maxAmountStr: fund.maxAmount,
        interestRateStr: fund.interestRate,
        rateVal,
        limitVal,
        limitInEok: Math.round((limitVal / 100000000) * 10) / 10,
        overallProbability: dlReport.overallProbability,
        baseProb,
        bonusUplift,
        tierInfo,
        balancedScore,
        rateScore,
        limitScore,
        rawFund: fund,
        repaymentPeriod: fund.repaymentPeriod || '5년 (거치 2년 포함)',
        hasSmartFactoryBonus: Boolean(bonusAdjustment?.appliedBonuses?.some(b => b.id.includes('smart'))),
        hasCarbonBonus: Boolean(bonusAdjustment?.appliedBonuses?.some(b => b.id.includes('carbon'))),
      };
    });
  }, [funds, profile]);

  // Categories & Agencies for dropdown filters
  const categories = useMemo(() => {
    const set = new Set<string>();
    funds.forEach(f => { if (f.category) set.add(f.category); });
    return ['ALL', ...Array.from(set)];
  }, [funds]);

  const agencies = useMemo(() => {
    const set = new Set<string>();
    funds.forEach(f => { if (f.agency) set.add(f.agency); });
    return ['ALL', ...Array.from(set)];
  }, [funds]);

  // Filtered & Sorted list
  const filteredFunds = useMemo(() => {
    let list = [...enrichedFunds];

    if (selectedCategory !== 'ALL') {
      list = list.filter(f => f.category === selectedCategory);
    }
    if (selectedAgency !== 'ALL') {
      list = list.filter(f => f.agency === selectedAgency);
    }

    // If specific funds selected via chips
    if (selectedFundIds.length > 0) {
      list = list.filter(f => selectedFundIds.includes(f.id));
    }

    // Sort
    if (sortMetric === 'PROBABILITY') {
      list.sort((a, b) => b.overallProbability - a.overallProbability);
    } else if (sortMetric === 'RATE') {
      list.sort((a, b) => a.rateVal - b.rateVal);
    } else if (sortMetric === 'LIMIT') {
      list.sort((a, b) => b.limitVal - a.limitVal);
    } else {
      list.sort((a, b) => b.balancedScore - a.balancedScore);
    }

    return list;
  }, [enrichedFunds, selectedCategory, selectedAgency, selectedFundIds, sortMetric]);

  // Best highlight awards
  const highlights = useMemo(() => {
    if (enrichedFunds.length === 0) return null;
    const highestProb = [...enrichedFunds].sort((a, b) => b.overallProbability - a.overallProbability)[0];
    const lowestRate = [...enrichedFunds].sort((a, b) => a.rateVal - b.rateVal)[0];
    const highestLimit = [...enrichedFunds].sort((a, b) => b.limitVal - a.limitVal)[0];
    const bestBalanced = [...enrichedFunds].sort((a, b) => b.balancedScore - a.balancedScore)[0];
    const avgRate = Math.round((enrichedFunds.reduce((sum, f) => sum + f.rateVal, 0) / enrichedFunds.length) * 100) / 100;
    const avgProb = Math.round(enrichedFunds.reduce((sum, f) => sum + f.overallProbability, 0) / enrichedFunds.length);

    return {
      highestProb,
      lowestRate,
      highestLimit,
      bestBalanced,
      avgRate,
      avgProb
    };
  }, [enrichedFunds]);

  // Multi-dimensional Radar Chart data for top 3 selected funds
  const radarComparison = useMemo(() => {
    const targetFunds = filteredFunds.slice(0, 3);
    if (targetFunds.length === 0) return { data: [], targetFunds: [] };

    const dimensions = [
      { key: 'rateScore', label: '금리 경쟁력' },
      { key: 'overallProbability', label: '승인 가능성' },
      { key: 'limitScore', label: '한도 규모' },
      { key: 'repaymentScore', label: '상환 여유도' },
      { key: 'guaranteeScore', label: '정책 우대성' }
    ];

    const data = dimensions.map(dim => {
      const row: any = { subject: dim.label };
      targetFunds.forEach((f, idx) => {
        let val = 70;
        if (dim.key === 'rateScore') val = f.rateScore;
        else if (dim.key === 'overallProbability') val = f.overallProbability;
        else if (dim.key === 'limitScore') val = f.limitScore;
        else if (dim.key === 'repaymentScore') {
          val = f.repaymentPeriod.includes('7') ? 95 : f.repaymentPeriod.includes('5') ? 85 : 70;
        } else if (dim.key === 'guaranteeScore') {
          val = (f.hasSmartFactoryBonus || f.hasCarbonBonus) ? 95 : f.agency.includes('소진공') ? 90 : 80;
        }
        row[`fund_${idx}`] = Math.min(100, Math.max(20, Math.round(val)));
      });
      return row;
    });

    return { data, targetFunds };
  }, [filteredFunds]);

  const toggleFundChip = (id: string) => {
    setSelectedFundIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  const handleSelectAll = () => {
    setSelectedFundIds([]);
  };

  return (
    <div id="policy-comparison-dashboard" className="space-y-8 animate-fade-in text-slate-800">
      
      {/* 1. Header Banner with Modern Fintech Slate Theme */}
      <div className="bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl relative overflow-hidden border border-indigo-500/20">
        <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none"></div>
        <div className="absolute bottom-0 left-1/3 w-72 h-72 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none"></div>

        <div className="relative z-10 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-white/10 pb-6">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-gradient-to-r from-indigo-500/20 to-blue-500/20 text-indigo-300 border border-indigo-400/30 rounded-full text-xs font-black mb-2.5">
                <BarChart3 className="w-3.5 h-3.5 text-indigo-400" />
                정부 소상공인 정책자금 시각화 비교 대시보드
              </div>
              <h2 className="text-xl sm:text-2xl lg:text-3xl font-black tracking-tight text-white flex items-center gap-2.5 flex-wrap">
                <span>{profile?.businessName || '내 사업장'} 맞춤 정책자금 한눈에 비교 분석</span>
              </h2>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-3xl leading-relaxed">
                분석된 <strong>{funds.length}개 정책자금</strong>의 <span className="text-emerald-300 font-bold">금리(%)</span>, <span className="text-blue-300 font-bold">대출 한도(억원)</span>, <span className="text-amber-300 font-bold">딥러닝 승인 예측 확률(%)</span>을 인터랙티브 차트로 종합 비교하여 최적의 금융 전략을 수립합니다.
              </p>
            </div>

            {/* Quick Status Pill */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2.5 shrink-0">
              {profile?.policyBonusFactors && (
                <div className="bg-white/10 backdrop-blur-md px-3.5 py-2 rounded-2xl border border-white/15 text-left sm:text-right">
                  <span className="text-[10px] text-slate-300 font-bold block">정책 가점 보정</span>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span className="text-xs font-black text-emerald-300">
                      {profile.policyBonusFactors.hasSmartFactory ? '스마트공장(+14%p)' : ''}
                      {profile.policyBonusFactors.hasSmartFactory && profile.policyBonusFactors.hasCarbonNeutrality ? ' · ' : ''}
                      {profile.policyBonusFactors.hasCarbonNeutrality ? '탄소중립(+8%p)' : ''}
                      {!profile.policyBonusFactors.hasSmartFactory && !profile.policyBonusFactors.hasCarbonNeutrality ? '일반 심사 기준' : ''}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* 2. Top 4 KPI Highlight Cards */}
          {highlights && (
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 pt-1">
              {/* Card 1: 최고 승인 확률 */}
              <div 
                onClick={() => onOpenDeepLearningReport?.(highlights.highestProb.rawFund)}
                className="bg-white/10 hover:bg-white/15 transition-all backdrop-blur-sm p-4 rounded-2xl border border-white/10 cursor-pointer group"
                title="클릭하여 해당 자금의 심층 진단서 확인"
              >
                <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                  <span className="flex items-center gap-1 font-bold text-emerald-300">
                    <Zap className="w-3.5 h-3.5 text-emerald-400 fill-emerald-400" />
                    최고 승인 유력 자금
                  </span>
                  <ChevronRight className="w-3.5 h-3.5 opacity-60 group-hover:opacity-100 group-hover:translate-x-0.5 transition-transform" />
                </div>
                <div className="text-lg sm:text-xl font-black text-white truncate mt-1">
                  {highlights.highestProb.title}
                </div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-2xl font-black text-emerald-400">
                    {highlights.highestProb.overallProbability}%
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
                    {highlights.highestProb.tierInfo.tierKorean}
                  </span>
                </div>
                <span className="text-[11px] text-slate-400 block mt-1 truncate">
                  {highlights.highestProb.agency} · 승인 안전권
                </span>
              </div>

              {/* Card 2: 최저 금리 */}
              <div 
                onClick={() => onOpenApplicationGuide?.(highlights.lowestRate.rawFund)}
                className="bg-white/10 hover:bg-white/15 transition-all backdrop-blur-sm p-4 rounded-2xl border border-white/10 cursor-pointer group"
                title="클릭하여 해당 자금 신청 가이드 확인"
              >
                <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                  <span className="flex items-center gap-1 font-bold text-blue-300">
                    <Percent className="w-3.5 h-3.5 text-blue-400" />
                    최저 금리 우대 자금
                  </span>
                  <ChevronRight className="w-3.5 h-3.5 opacity-60 group-hover:opacity-100 group-hover:translate-x-0.5 transition-transform" />
                </div>
                <div className="text-lg sm:text-xl font-black text-white truncate mt-1">
                  {highlights.lowestRate.title}
                </div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-2xl font-black text-blue-300">
                    연 {highlights.lowestRate.rateVal}%
                  </span>
                  <span className="text-[10px] font-bold text-slate-300 bg-white/10 px-2 py-0.5 rounded">
                    평균 대비 -{(highlights.avgRate - highlights.lowestRate.rateVal).toFixed(2)}%p
                  </span>
                </div>
                <span className="text-[11px] text-slate-400 block mt-1 truncate">
                  {highlights.lowestRate.interestRateStr}
                </span>
              </div>

              {/* Card 3: 최대 한도 */}
              <div 
                onClick={() => onSelectFund?.(highlights.highestLimit.rawFund)}
                className="bg-white/10 hover:bg-white/15 transition-all backdrop-blur-sm p-4 rounded-2xl border border-white/10 cursor-pointer group"
              >
                <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                  <span className="flex items-center gap-1 font-bold text-indigo-300">
                    <Banknote className="w-3.5 h-3.5 text-indigo-400" />
                    최대 한도 지원 자금
                  </span>
                  <ChevronRight className="w-3.5 h-3.5 opacity-60 group-hover:opacity-100 group-hover:translate-x-0.5 transition-transform" />
                </div>
                <div className="text-lg sm:text-xl font-black text-white truncate mt-1">
                  {highlights.highestLimit.title}
                </div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-2xl font-black text-indigo-300">
                    {highlights.highestLimit.maxAmountStr}
                  </span>
                </div>
                <span className="text-[11px] text-slate-400 block mt-1 truncate">
                  상환: {highlights.highestLimit.repaymentPeriod}
                </span>
              </div>

              {/* Card 4: 종합 추천 1순위 (AI 밸런스 지수) */}
              <div 
                onClick={() => onOpenDeepLearningReport?.(highlights.bestBalanced.rawFund)}
                className="bg-gradient-to-br from-indigo-600/30 to-purple-600/30 hover:from-indigo-600/40 hover:to-purple-600/40 transition-all backdrop-blur-sm p-4 rounded-2xl border border-indigo-400/30 cursor-pointer group"
              >
                <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                  <span className="flex items-center gap-1 font-bold text-amber-300">
                    <Award className="w-3.5 h-3.5 text-amber-400" />
                    종합 추천 1순위 자금
                  </span>
                  <ChevronRight className="w-3.5 h-3.5 opacity-60 group-hover:opacity-100 group-hover:translate-x-0.5 transition-transform" />
                </div>
                <div className="text-lg sm:text-xl font-black text-white truncate mt-1">
                  {highlights.bestBalanced.title}
                </div>
                <div className="flex items-baseline gap-2 mt-2">
                  <span className="text-2xl font-black text-amber-300">
                    {highlights.bestBalanced.balancedScore}점
                  </span>
                  <span className="text-[10px] font-bold text-amber-200 bg-amber-500/20 px-2 py-0.5 rounded-full border border-amber-400/30">
                    금리·한도·확률 최적
                  </span>
                </div>
                <span className="text-[11px] text-slate-300 block mt-1 truncate">
                  승인율 {highlights.bestBalanced.overallProbability}% · 연 {highlights.bestBalanced.rateVal}%
                </span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 3. Interactive Filtering & Sorting Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200/90 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Left: Fund Selection Chips */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <span className="text-xs font-bold text-slate-500 shrink-0 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-slate-400" />
            비교 대상:
          </span>
          <button
            type="button"
            onClick={handleSelectAll}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
              selectedFundIds.length === 0
                ? 'bg-slate-900 text-white shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
            }`}
          >
            전체 비교 ({enrichedFunds.length})
          </button>
          {enrichedFunds.slice(0, 6).map((f) => {
            const isSelected = selectedFundIds.includes(f.id);
            return (
              <button
                key={f.id}
                type="button"
                onClick={() => toggleFundChip(f.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 cursor-pointer border ${
                  isSelected
                    ? 'bg-indigo-50 border-indigo-300 text-indigo-700 shadow-2xs font-black'
                    : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-600'
                }`}
              >
                <span>{f.shortTitle}</span>
                <span className="text-[10px] text-slate-400 font-normal">({f.overallProbability}%)</span>
              </button>
            );
          })}
        </div>

        {/* Right: Sort & Dropdown Selectors */}
        <div className="flex items-center gap-3 shrink-0 self-end md:self-auto flex-wrap">
          {/* Agency Filter */}
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-slate-500 font-medium">기관:</span>
            <select
              value={selectedAgency}
              onChange={(e) => setSelectedAgency(e.target.value)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-800 focus:ring-1 focus:ring-indigo-500 outline-none cursor-pointer"
            >
              {agencies.map(a => (
                <option key={a} value={a}>{a === 'ALL' ? '전체 기관' : a}</option>
              ))}
            </select>
          </div>

          {/* Sort Metric Selector */}
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-slate-500 font-medium">정렬:</span>
            <select
              value={sortMetric}
              onChange={(e) => setSortMetric(e.target.value as any)}
              className="bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-800 focus:ring-1 focus:ring-indigo-500 outline-none cursor-pointer"
            >
              <option value="BALANCED">AI 밸런스 추천순</option>
              <option value="PROBABILITY">승인 확률 높은순</option>
              <option value="RATE">금리 낮은순 (유리한순)</option>
              <option value="LIMIT">대출 한도 높은순</option>
            </select>
          </div>
        </div>
      </div>

      {/* 4. Chart View Mode Tabs */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b border-slate-200 pb-2">
          <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
            <button
              type="button"
              onClick={() => setActiveChartTab('COMPREHENSIVE')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                activeChartTab === 'COMPREHENSIVE'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              <BarChart3 className="w-3.5 h-3.5" />
              <span>종합 비교 매트릭스 (금리·한도·확률)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveChartTab('PROBABILITY')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                activeChartTab === 'PROBABILITY'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              <Zap className="w-3.5 h-3.5" />
              <span>🎯 승인 예측 확률 (%) & 가점 보정</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveChartTab('RATE')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                activeChartTab === 'RATE'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              <Percent className="w-3.5 h-3.5" />
              <span>📉 금리 비교 (낮을수록 유리)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveChartTab('LIMIT')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                activeChartTab === 'LIMIT'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              <Banknote className="w-3.5 h-3.5" />
              <span>💰 지원 한도 (억원 단위)</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveChartTab('RADAR')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                activeChartTab === 'RADAR'
                  ? 'bg-purple-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              <span>🕸️ 5대 역량 스파이더 레이더 비교</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveChartTab('QUADRANT')}
              className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                activeChartTab === 'QUADRANT'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              <Scale className="w-3.5 h-3.5" />
              <span>⚡ 금리 vs 승인율 4분면 포지셔닝</span>
            </button>
          </div>
          <span className="text-[11px] text-slate-400 hidden lg:inline">
            차트 막대를 클릭하면 자금 상세 진단서가 열립니다
          </span>
        </div>

        {/* 5. Chart Canvas Area */}
        <div className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm relative">
          
          {/* TAB 1: 종합 비교 매트릭스 (Normalized 3-Metric Multi-Bar) */}
          {activeChartTab === 'COMPREHENSIVE' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                    <span>자금별 3대 핵심 지표 종합 밸런스 비교</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                      100점 환산 지수
                    </span>
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    승인 확률, 금리 경쟁력(낮을수록 고득점), 지원 한도를 균형 있게 평가한 다차원 비교입니다.
                  </p>
                </div>
                <div className="flex items-center gap-3 text-xs font-bold text-slate-600">
                  <span className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-sm bg-amber-500 inline-block" /> 승인 확률
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-sm bg-emerald-500 inline-block" /> 금리 경쟁력
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-sm bg-blue-500 inline-block" /> 한도 규모
                  </span>
                </div>
              </div>

              <div className="h-80 w-full pt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={filteredFunds}
                    margin={{ top: 15, right: 10, left: -10, bottom: 25 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis 
                      dataKey="shortTitle" 
                      tick={{ fill: '#64748b', fontSize: 11, fontWeight: 700 }}
                      interval={0}
                      angle={-15}
                      textAnchor="end"
                    />
                    <YAxis 
                      domain={[0, 100]} 
                      tick={{ fill: '#94a3b8', fontSize: 11 }}
                      unit="점"
                    />
                    <Tooltip content={<CustomComprehensiveTooltip />} />
                    <Bar 
                      dataKey="overallProbability" 
                      name="승인 확률" 
                      fill="#f59e0b" 
                      radius={[4, 4, 0, 0]} 
                      onClick={(data: any) => onOpenDeepLearningReport?.(data?.rawFund || data?.payload?.rawFund)}
                      cursor="pointer"
                    />
                    <Bar 
                      dataKey="rateScore" 
                      name="금리 경쟁력" 
                      fill="#10b981" 
                      radius={[4, 4, 0, 0]} 
                      onClick={(data: any) => onOpenDeepLearningReport?.(data?.rawFund || data?.payload?.rawFund)}
                      cursor="pointer"
                    />
                    <Bar 
                      dataKey="limitScore" 
                      name="한도 규모" 
                      fill="#3b82f6" 
                      radius={[4, 4, 0, 0]} 
                      onClick={(data: any) => onOpenDeepLearningReport?.(data?.rawFund || data?.payload?.rawFund)}
                      cursor="pointer"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* TAB 2: 금리 비교 차트 (낮을수록 유리) */}
          {activeChartTab === 'RATE' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                    <span>자금별 최종 예상 금리 (%) 비교</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                      낮을수록 금융비용 절감
                    </span>
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    시중은행 신용대출 평균(연 5.8%) 대비 절감되는 이자 혜택을 한눈에 비교합니다.
                  </p>
                </div>
                {highlights && (
                  <div className="text-xs text-slate-600 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 font-bold">
                    추천 자금 평균 금리: <span className="text-emerald-600 font-black">연 {highlights.avgRate}%</span>
                  </div>
                )}
              </div>

              <div className="h-80 w-full pt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={filteredFunds}
                    margin={{ top: 20, right: 10, left: -10, bottom: 25 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis 
                      dataKey="shortTitle" 
                      tick={{ fill: '#64748b', fontSize: 11, fontWeight: 700 }}
                      interval={0}
                      angle={-15}
                      textAnchor="end"
                    />
                    <YAxis 
                      domain={[0, 6]} 
                      tick={{ fill: '#94a3b8', fontSize: 11 }}
                      unit="%"
                    />
                    <Tooltip content={<CustomRateTooltip />} />
                    <ReferenceLine 
                      y={5.8} 
                      stroke="#ef4444" 
                      strokeDasharray="4 4" 
                      label={{ value: '시중은행 평균 5.8%', fill: '#ef4444', fontSize: 10, position: 'top' }} 
                    />
                    {highlights && (
                      <ReferenceLine 
                        y={highlights.avgRate} 
                        stroke="#10b981" 
                        strokeDasharray="3 3" 
                        label={{ value: `정책자금 평균 ${highlights.avgRate}%`, fill: '#059669', fontSize: 10, position: 'bottom' }} 
                      />
                    )}
                    <Bar 
                      dataKey="rateVal" 
                      radius={[6, 6, 0, 0]}
                      onClick={(data: any) => onOpenApplicationGuide?.(data?.rawFund || data?.payload?.rawFund)}
                      cursor="pointer"
                    >
                      {filteredFunds.map((entry, index) => {
                        const isLowest = highlights?.lowestRate.id === entry.id;
                        return (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={isLowest ? '#10b981' : entry.rateVal <= 2.5 ? '#3b82f6' : '#6366f1'} 
                          />
                        );
                      })}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* TAB 3: 대출 한도 비교 차트 (억원 단위) */}
          {activeChartTab === 'LIMIT' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                    <span>자금별 최대 지원 한도 (억원) 비교</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200">
                      최대 융자 규모
                    </span>
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    대표님의 연간 매출 및 사업 계획에 부합하는 적정 대출 규모를 대조합니다.
                  </p>
                </div>
                {profile?.fundingNeed ? (
                  <div className="text-xs text-slate-600 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 font-bold">
                    희망 자금 규모: <span className="text-blue-600 font-black">{(profile.fundingNeed / 100000000).toFixed(1)}억원</span>
                  </div>
                ) : null}
              </div>

              <div className="h-80 w-full pt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={filteredFunds}
                    margin={{ top: 20, right: 10, left: -10, bottom: 25 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis 
                      dataKey="shortTitle" 
                      tick={{ fill: '#64748b', fontSize: 11, fontWeight: 700 }}
                      interval={0}
                      angle={-15}
                      textAnchor="end"
                    />
                    <YAxis 
                      domain={[0, 'dataMax + 0.5']} 
                      tick={{ fill: '#94a3b8', fontSize: 11 }}
                      unit="억"
                    />
                    <Tooltip content={<CustomLimitTooltip />} />
                    {profile?.fundingNeed && (
                      <ReferenceLine 
                        y={Math.round((profile.fundingNeed / 100000000) * 10) / 10} 
                        stroke="#3b82f6" 
                        strokeDasharray="4 4" 
                        label={{ value: `희망 자금 ${(profile.fundingNeed / 100000000).toFixed(1)}억`, fill: '#2563eb', fontSize: 10, position: 'top' }} 
                      />
                    )}
                    <Bar 
                      dataKey="limitInEok" 
                      radius={[6, 6, 0, 0]}
                      onClick={(data: any) => onSelectFund?.(data?.rawFund || data?.payload?.rawFund)}
                      cursor="pointer"
                    >
                      {filteredFunds.map((entry, index) => {
                        const isHighest = highlights?.highestLimit.id === entry.id;
                        return (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={isHighest ? '#2563eb' : '#60a5fa'} 
                          />
                        );
                      })}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* TAB 4: 승인 예측 확률 (%) & 가점 보정 비교 */}
          {activeChartTab === 'PROBABILITY' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                    <span>AI 딥러닝 5단계 승인 예측 확률 & 정책 가점 보정 비교</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200">
                      스마트공장·탄소중립 가점 반영
                    </span>
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    기본 심사 확률과 정책적 우대 가점(+14%p)이 합산 보정된 최종 통과 확률입니다.
                  </p>
                </div>
                <div className="flex items-center gap-2 text-xs font-bold">
                  <span className="flex items-center gap-1 text-slate-600">
                    <span className="w-2.5 h-2.5 rounded-full bg-slate-300" /> 기본 확률
                  </span>
                  <span className="flex items-center gap-1 text-emerald-700">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> 가점 보정 (+OO%p)
                  </span>
                </div>
              </div>

              <div className="h-80 w-full pt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={filteredFunds}
                    margin={{ top: 20, right: 10, left: -10, bottom: 25 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis 
                      dataKey="shortTitle" 
                      tick={{ fill: '#64748b', fontSize: 11, fontWeight: 700 }}
                      interval={0}
                      angle={-15}
                      textAnchor="end"
                    />
                    <YAxis 
                      domain={[0, 100]} 
                      tick={{ fill: '#94a3b8', fontSize: 11 }}
                      unit="%"
                    />
                    <Tooltip content={<CustomProbabilityTooltip />} />
                    <ReferenceLine 
                      y={90} 
                      stroke="#10b981" 
                      strokeDasharray="4 4" 
                      label={{ value: '최유력 안전선 (90%)', fill: '#059669', fontSize: 10, position: 'top' }} 
                    />
                    <ReferenceLine 
                      y={75} 
                      stroke="#3b82f6" 
                      strokeDasharray="3 3" 
                      label={{ value: '유력 합격선 (75%)', fill: '#2563eb', fontSize: 10, position: 'top' }} 
                    />
                    <Bar 
                      dataKey="baseProb" 
                      stackId="prob"
                      name="기본 심사 확률" 
                      fill="#94a3b8" 
                      radius={[0, 0, 0, 0]}
                      onClick={(data: any) => onOpenDeepLearningReport?.(data?.rawFund || data?.payload?.rawFund)}
                      cursor="pointer"
                    />
                    <Bar 
                      dataKey="bonusUplift" 
                      stackId="prob"
                      name="정책 가점 보정" 
                      fill="#10b981" 
                      radius={[4, 4, 0, 0]}
                      onClick={(data: any) => onOpenDeepLearningReport?.(data?.rawFund || data?.payload?.rawFund)}
                      cursor="pointer"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}

          {/* TAB: 5대 핵심 역량 레이더 (Spider Comparison) */}
          {activeChartTab === 'RADAR' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                    <span>상위 추천 자금 5대 핵심 역량 다차원 레이더 비교</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-50 text-purple-700 border border-purple-200">
                      상위 3개 자금 오버레이
                    </span>
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    금리 경쟁력, 승인 가능성, 한도 규모, 상환 여유도, 정책 우대성을 방사형 스파이더 차트로 비교합니다.
                  </p>
                </div>
                <div className="flex items-center gap-3 text-xs font-bold flex-wrap">
                  {radarComparison.targetFunds.map((f, idx) => {
                    const colors = ['#3b82f6', '#10b981', '#f59e0b'];
                    return (
                      <span key={f.id} className="flex items-center gap-1.5 text-slate-700">
                        <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: colors[idx] }} />
                        <span className="max-w-[120px] truncate">{f.title}</span>
                      </span>
                    );
                  })}
                </div>
              </div>

              <div className="h-80 w-full pt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <RadarChart cx="50%" cy="50%" outerRadius="70%" data={radarComparison.data}>
                    <PolarGrid stroke="#f1f5f9" />
                    <PolarAngleAxis dataKey="subject" tick={{ fill: '#475569', fontSize: 11, fontWeight: 700 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                    {radarComparison.targetFunds.map((f, idx) => {
                      const colors = ['#3b82f6', '#10b981', '#f59e0b'];
                      return (
                        <Radar
                          key={f.id}
                          name={f.shortTitle}
                          dataKey={`fund_${idx}`}
                          stroke={colors[idx]}
                          strokeWidth={2.5}
                          fill={colors[idx]}
                          fillOpacity={0.25}
                        />
                      );
                    })}
                    <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }} />
                  </RadarChart>
                </ResponsiveContainer>
              </div>

              {/* Quick Multi-Fund Comparative Spec Summary Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                {radarComparison.targetFunds.map((f, idx) => {
                  const borderColors = ['border-blue-300 bg-blue-50/40', 'border-emerald-300 bg-emerald-50/40', 'border-amber-300 bg-amber-50/40'];
                  const textColors = ['text-blue-700', 'text-emerald-700', 'text-amber-700'];
                  return (
                    <div key={f.id} className={`p-3.5 rounded-2xl border-2 ${borderColors[idx]} space-y-2`}>
                      <div className="flex items-center justify-between">
                        <span className={`text-[10px] font-black px-2 py-0.5 rounded-md bg-white shadow-2xs ${textColors[idx]}`}>
                          추천 {idx + 1}순위
                        </span>
                        <span className="text-xs font-black text-slate-800">{f.overallProbability}% 승인</span>
                      </div>
                      <h5 className="font-black text-xs text-slate-900 truncate" title={f.title}>
                        {f.title}
                      </h5>
                      <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-slate-200/60">
                        <div>
                          <span className="text-slate-500 block">금리</span>
                          <span className="font-black text-slate-900">연 {f.rateVal}%</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block">최대 한도</span>
                          <span className="font-black text-slate-900">{f.maxAmountStr}</span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => onOpenDeepLearningReport?.(f.rawFund)}
                        className="w-full mt-1 py-1.5 px-2 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl text-[11px] font-bold text-slate-700 transition-colors cursor-pointer"
                      >
                        상세 진단서 열기 →
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* TAB 5: 금리 vs 승인율 4분면 포지셔닝 */}
          {activeChartTab === 'QUADRANT' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="text-sm font-black text-slate-900 flex items-center gap-2">
                    <span>금리(비용) vs 승인 예측 확률(안정성) 4분면 분석</span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                      최적 신청 전략 도출
                    </span>
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    우상단(승인율 높고 금리 낮은 자금)에 위치할수록 가장 먼저 접수해야 하는 최우선 자금입니다.
                  </p>
                </div>
              </div>

              {/* 4 Quadrants Visual Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-2">
                {/* 1. 최우선 신청 구간 (우상단) */}
                <div className="p-4 rounded-2xl bg-emerald-50/70 border-2 border-emerald-300 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-emerald-900 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-emerald-600" />
                      🌟 1순위 최적 구간 (낮은 금리 & 높은 승인율)
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-900">
                      우선 신청 추천
                    </span>
                  </div>
                  <p className="text-[11px] text-emerald-800 leading-snug">
                    심사 통과율이 75% 이상이면서 금리가 연 3%대 이하인 황금 자금입니다. 가장 먼저 접수하여 예산을 선점하세요.
                  </p>
                  <div className="space-y-1.5 pt-1">
                    {filteredFunds
                      .filter(f => f.overallProbability >= 70 && f.rateVal <= 3.5)
                      .map(f => (
                        <div key={f.id} className="p-2.5 bg-white rounded-xl border border-emerald-200 flex items-center justify-between text-xs">
                          <div>
                            <span className="font-black text-slate-900">{f.title}</span>
                            <span className="text-[10px] text-slate-500 block">{f.agency}</span>
                          </div>
                          <div className="text-right">
                            <span className="font-black text-emerald-600 block">{f.overallProbability}% 통과 유력</span>
                            <span className="text-[10px] text-slate-500 font-bold">연 {f.rateVal}%</span>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>

                {/* 2. 안전 승인 구간 (우하단) */}
                <div className="p-4 rounded-2xl bg-blue-50/70 border-2 border-blue-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-blue-900 flex items-center gap-1.5">
                      <ShieldCheck className="w-4 h-4 text-blue-600" />
                      🛡️ 2순위 안전 구간 (확실한 승인 & 한도 확보)
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-200 text-blue-900">
                      안정권 백업
                    </span>
                  </div>
                  <p className="text-[11px] text-blue-800 leading-snug">
                    금리는 다소 높을 수 있으나 소진공/지역신보 보증서 발급 기준을 여유있게 만족하는 안전 자금입니다.
                  </p>
                  <div className="space-y-1.5 pt-1">
                    {filteredFunds
                      .filter(f => f.overallProbability >= 70 && f.rateVal > 3.5)
                      .map(f => (
                        <div key={f.id} className="p-2.5 bg-white rounded-xl border border-blue-200 flex items-center justify-between text-xs">
                          <div>
                            <span className="font-black text-slate-900">{f.title}</span>
                            <span className="text-[10px] text-slate-500 block">{f.agency}</span>
                          </div>
                          <div className="text-right">
                            <span className="font-black text-blue-600 block">{f.overallProbability}%</span>
                            <span className="text-[10px] text-slate-500 font-bold">{f.maxAmountStr}</span>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>

                {/* 3. 초저금리 경합 구간 (좌상단) */}
                <div className="p-4 rounded-2xl bg-amber-50/70 border-2 border-amber-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-amber-900 flex items-center gap-1.5">
                      <Percent className="w-4 h-4 text-amber-600" />
                      ⚡ 3순위 초저금리 경합 구간 (가점 필수)
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-200 text-amber-900">
                      가점 보강 필수
                    </span>
                  </div>
                  <p className="text-[11px] text-amber-800 leading-snug">
                    금리는 2%대로 매우 매력적이나 동일 업종 신청자 간 경쟁이 치열합니다. 스마트공장/탄소중립 서류를 완비해 도전하세요.
                  </p>
                  <div className="space-y-1.5 pt-1">
                    {filteredFunds
                      .filter(f => f.overallProbability < 70 && f.rateVal <= 3.5)
                      .map(f => (
                        <div key={f.id} className="p-2.5 bg-white rounded-xl border border-amber-200 flex items-center justify-between text-xs">
                          <div>
                            <span className="font-black text-slate-900">{f.title}</span>
                            <span className="text-[10px] text-slate-500 block">{f.agency}</span>
                          </div>
                          <div className="text-right">
                            <span className="font-black text-amber-700 block">연 {f.rateVal}%</span>
                            <span className="text-[10px] text-slate-500 font-bold">{f.overallProbability}% 경합</span>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>

                {/* 4. 우회 및 대환 트랙 구간 (좌하단) */}
                <div className="p-4 rounded-2xl bg-purple-50/70 border-2 border-purple-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-purple-900 flex items-center gap-1.5">
                      <Clock className="w-4 h-4 text-purple-600" />
                      🔄 4순위 우회/특례 트랙 (채무 재조정 병행)
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-200 text-purple-900">
                      대환/재도전
                    </span>
                  </div>
                  <p className="text-[11px] text-purple-800 leading-snug">
                    일반 운전자금 직접 신청 시 한도 축소 위험이 있어, 저신용 특례나 고금리 대환 특별 프로그램으로 우회 신청을 권장합니다.
                  </p>
                  <div className="space-y-1.5 pt-1">
                    {filteredFunds
                      .filter(f => f.overallProbability < 70 && f.rateVal > 3.5)
                      .map(f => (
                        <div key={f.id} className="p-2.5 bg-white rounded-xl border border-purple-200 flex items-center justify-between text-xs">
                          <div>
                            <span className="font-black text-slate-900">{f.title}</span>
                            <span className="text-[10px] text-slate-500 block">{f.agency}</span>
                          </div>
                          <div className="text-right">
                            <span className="font-black text-purple-600 block">{f.overallProbability}%</span>
                            <span className="text-[10px] text-slate-500 font-bold">특례 상담 권장</span>
                          </div>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 6. Quick Comparison Table (정밀 대조 매트릭스) */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 sm:p-6 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
              <Scale className="w-5 h-5 text-indigo-600" />
              <span>자금별 7대 핵심 항목 1:1 정밀 대조표</span>
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              각 자금의 금리, 최대 한도, 승인 확률, 가점 보정 내역 및 상환 기간을 한눈에 비교하고 즉시 신청을 준비하세요.
            </p>
          </div>
          <span className="text-xs font-bold text-slate-400">
            총 {filteredFunds.length}개 자금 비교 중
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50/80 text-slate-700 uppercase font-black tracking-wider text-[11px] border-b border-slate-200">
              <tr>
                <th className="py-3.5 px-4">자금명 및 주관기관</th>
                <th className="py-3.5 px-4 text-center">승인 예측 확률 (가점 보정)</th>
                <th className="py-3.5 px-4 text-center">예상 금리</th>
                <th className="py-3.5 px-4 text-center">최대 지원 한도</th>
                <th className="py-3.5 px-4">상환 및 거치 조건</th>
                <th className="py-3.5 px-4">인정된 정책 가점</th>
                <th className="py-3.5 px-4 text-center">신청 조치</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {filteredFunds.map((fund) => {
                const isTopProb = highlights?.highestProb.id === fund.id;
                const isLowestRate = highlights?.lowestRate.id === fund.id;
                const isTopLimit = highlights?.highestLimit.id === fund.id;

                return (
                  <tr 
                    key={fund.id}
                    className="hover:bg-slate-50/80 transition-colors group"
                  >
                    {/* 자금명 & 기관 */}
                    <td className="py-4 px-4">
                      <div className="flex items-start gap-2">
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-black text-slate-900 text-xs sm:text-sm group-hover:text-indigo-600 transition-colors">
                              {fund.title}
                            </span>
                            {isTopProb && (
                              <span className="text-[10px] font-black px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-md">
                                ★ 최고 승인율
                              </span>
                            )}
                            {isLowestRate && (
                              <span className="text-[10px] font-black px-2 py-0.5 bg-blue-100 text-blue-800 rounded-md">
                                ★ 최저 금리
                              </span>
                            )}
                            {isTopLimit && (
                              <span className="text-[10px] font-black px-2 py-0.5 bg-purple-100 text-purple-800 rounded-md">
                                ★ 최대 한도
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-slate-500 font-medium block mt-0.5">
                            {fund.agency} · {fund.category}
                          </span>
                        </div>
                      </div>
                    </td>

                    {/* 승인 예측 확률 */}
                    <td className="py-4 px-4 text-center">
                      <div className="inline-flex flex-col items-center">
                        <div className="flex items-center gap-1">
                          <span className="text-sm font-black text-slate-900">
                            {fund.overallProbability}%
                          </span>
                          <span 
                            className="px-2 py-0.5 text-[10px] font-bold rounded-full border"
                            style={{
                              backgroundColor: fund.tierInfo.bgColor,
                              color: fund.tierInfo.color,
                              borderColor: fund.tierInfo.badgeColor
                            }}
                          >
                            {fund.tierInfo.tierKorean}
                          </span>
                        </div>
                        {fund.bonusUplift > 0 && (
                          <span className="text-[10px] font-bold text-emerald-600 bg-emerald-50 px-1.5 py-0.2 rounded mt-0.5 border border-emerald-200">
                            +{fund.bonusUplift}%p 가점 반영
                          </span>
                        )}
                      </div>
                    </td>

                    {/* 예상 금리 */}
                    <td className="py-4 px-4 text-center">
                      <span className={`text-sm font-black ${isLowestRate ? 'text-emerald-600 font-black' : 'text-slate-800'}`}>
                        연 {fund.rateVal}%
                      </span>
                      <span className="text-[10px] text-slate-400 block font-normal">
                        {fund.interestRateStr.includes('고정') ? '고정금리' : '변동/우대'}
                      </span>
                    </td>

                    {/* 최대 한도 */}
                    <td className="py-4 px-4 text-center">
                      <span className={`text-sm font-black ${isTopLimit ? 'text-indigo-600 font-black' : 'text-slate-800'}`}>
                        {fund.maxAmountStr}
                      </span>
                    </td>

                    {/* 상환 조건 */}
                    <td className="py-4 px-4">
                      <span className="text-xs text-slate-700 font-medium">
                        {fund.repaymentPeriod}
                      </span>
                    </td>

                    {/* 정책 가점 */}
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-1 flex-wrap">
                        {fund.hasSmartFactoryBonus && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-blue-50 text-blue-700 text-[10px] font-bold border border-blue-200">
                            <Factory className="w-3 h-3 text-blue-600" /> 스마트공장
                          </span>
                        )}
                        {fund.hasCarbonBonus && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200">
                            <Leaf className="w-3 h-3 text-emerald-600" /> 탄소중립
                          </span>
                        )}
                        {!fund.hasSmartFactoryBonus && !fund.hasCarbonBonus && (
                          <span className="text-[11px] text-slate-400">일반 요건</span>
                        )}
                      </div>
                    </td>

                    {/* 신청 및 상세 액션 */}
                    <td className="py-4 px-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => onOpenDeepLearningReport?.(fund.rawFund)}
                          className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black transition-all shadow-xs cursor-pointer"
                          title="AI 심사역 정밀 진단서 보기"
                        >
                          진단서
                        </button>
                        <button
                          type="button"
                          onClick={() => onOpenApplicationGuide?.(fund.rawFund)}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition-all shadow-xs cursor-pointer"
                          title="신청 가이드 및 서류 확인"
                        >
                          가이드
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

// Custom Tooltip for Comprehensive Multi-Bar Chart
const CustomComprehensiveTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-slate-900 text-white p-3.5 rounded-xl shadow-xl border border-slate-700 text-xs space-y-1.5 max-w-xs">
        <div className="font-black text-sm text-indigo-300 border-b border-slate-800 pb-1">
          {data.title}
        </div>
        <div className="text-[11px] text-slate-400 font-medium">
          {data.agency} · {data.category}
        </div>
        <div className="pt-1 space-y-1">
          <div className="flex justify-between gap-4">
            <span className="text-amber-400 font-bold">🎯 승인 예측 확률:</span>
            <span className="font-black">{data.overallProbability}% ({data.tierInfo.tierKorean})</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-emerald-400 font-bold">📉 예상 적용 금리:</span>
            <span className="font-black">연 {data.rateVal}%</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-blue-400 font-bold">💰 최대 지원 한도:</span>
            <span className="font-black">{data.maxAmountStr}</span>
          </div>
          {data.bonusUplift > 0 && (
            <div className="flex justify-between gap-4 text-emerald-300 pt-1 border-t border-slate-800">
              <span className="font-bold">가점 보정 혜택:</span>
              <span className="font-black">+{data.bonusUplift}%p 상향</span>
            </div>
          )}
        </div>
      </div>
    );
  }
  return null;
};

// Custom Tooltip for Interest Rate Chart
const CustomRateTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl border border-slate-700 text-xs space-y-1">
        <div className="font-black text-indigo-300">{data.title}</div>
        <div className="text-[11px] text-slate-400">{data.agency}</div>
        <div className="text-sm font-black text-emerald-400 pt-1">
          최종 금리: 연 {data.rateVal}%
        </div>
        <div className="text-[10px] text-slate-400 leading-snug">
          {data.interestRateStr}
        </div>
      </div>
    );
  }
  return null;
};

// Custom Tooltip for Limit Chart
const CustomLimitTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl border border-slate-700 text-xs space-y-1">
        <div className="font-black text-indigo-300">{data.title}</div>
        <div className="text-[11px] text-slate-400">{data.agency}</div>
        <div className="text-sm font-black text-blue-400 pt-1">
          최대 한도: {data.maxAmountStr} ({data.limitInEok}억원)
        </div>
        <div className="text-[10px] text-slate-400">
          상환 기간: {data.repaymentPeriod}
        </div>
      </div>
    );
  }
  return null;
};

// Custom Tooltip for Probability Chart
const CustomProbabilityTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl border border-slate-700 text-xs space-y-1.5">
        <div className="font-black text-indigo-300">{data.title}</div>
        <div className="text-sm font-black text-amber-400">
          최종 승인 확률: {data.overallProbability}% ({data.tierInfo.tierKorean})
        </div>
        <div className="text-[11px] text-slate-300 space-y-0.5">
          <div>기본 심사 확률: {data.baseProb}%</div>
          {data.bonusUplift > 0 && (
            <div className="text-emerald-400 font-bold">
              정책 가점(스마트공장/탄소중립): +{data.bonusUplift}%p 보정
            </div>
          )}
        </div>
      </div>
    );
  }
  return null;
};
