import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AnalysisResult, PolicyFund, UserProfile, SourcePolicy, BusinessType, Industry, ReanalysisFeedback, PolicyBonusFactors } from '../types';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend, PieChart, Pie, Cell } from 'recharts';
import { 
  CheckCircle2, 
  ChevronDown, 
  ChevronUp, 
  Download, 
  RotateCcw, 
  TrendingUp, 
  Calendar, 
  Phone, 
  FileText, 
  Search, 
  X, 
  Landmark, 
  MapPin, 
  Building2, 
  User, 
  Printer, 
  Info, 
  ClipboardCheck, 
  ArrowRightCircle, 
  AlertCircle, 
  Tag, 
  Building, 
  Eraser, 
  Siren, 
  ShieldCheck, 
  Banknote, 
  Percent, 
  Star, 
  Plus, 
  Trash2, 
  Mail, 
  FileSpreadsheet, 
  Presentation, 
  Send, 
  Loader2, 
  Pin, 
  Users, 
  BarChart3, 
  Sparkles, 
  Award, 
  Layers, 
  ThumbsUp, 
  ThumbsDown, 
  MessageSquare, 
  Smile, 
  Heart,
  Scale,
  CheckSquare,
  Square,
  ArrowRightLeft,
  FileCheck2,
  Sliders,
  BellRing,
  Bell,
  Headphones,
  UserCheck,
  ChevronRight,
  Zap,
  BrainCircuit,
  Activity,
  Target, AlertTriangle, Share2, ArrowUpDown, ArrowRight,
  ExternalLink,
  BookOpen
} from 'lucide-react';
import { CompareFundsModal } from './CompareFundsModal';
import { RealtimePolicyNews } from './RealtimePolicyNews';
import { SuccessStories } from './SuccessStories';
import { FundPdfChecklistModal } from './FundPdfChecklistModal';
import { FundApplicationGuideModal } from './FundApplicationGuideModal';
import { PushNotificationModal } from './PushNotificationModal';
import { ExpertConsultationModal, ConsultationRequestData } from './ExpertConsultationModal';
import { FavoritePolicyChangesSummary } from './FavoritePolicyChangesSummary';
import { FundLoanSimulator } from './FundLoanSimulator';
import { DocumentIssuanceGuide } from './DocumentIssuanceGuide';
import { DetailedFeedbackModal } from './DetailedFeedbackModal';
import { FundEligibilityChecklist } from './FundEligibilityChecklist';
import { DeepLearningApprovalReportModal } from './DeepLearningApprovalReportModal';
import { DeepLearningApprovalHub } from './DeepLearningApprovalHub';
import { GoogleFormsManagerModal } from './GoogleFormsManagerModal';
import { GoogleContactsManagerModal } from './GoogleContactsManagerModal';
import { GoogleTasksManagerModal } from './GoogleTasksManagerModal';
import { PolicyFundComparisonTable } from './PolicyFundComparisonTable';
import { PolicyComparisonDashboard } from './PolicyComparisonDashboard';
import { PolicyFundSeasonalityTrends } from './PolicyFundSeasonalityTrends';
import { ShareModal } from "./ShareModal";
import { PolicyApplicationGuideView } from './PolicyApplicationGuideView';
import { 
  generateDeepLearningApprovalReport, 
  getApprovalLikelihoodTier 
} from '../services/deepLearningApprovalEngine';
import { 
  saveReportToDrive, 
  createFundingGoogleSheet, 
  createWorkspaceSlideshow, 
  createWorkspaceDocument,
  sendGmailReport, 
  syncFundingEmails, 
  fetchKeepNotes, 
  createKeepNote, 
  updateKeepNote, 
  deleteKeepNote, 
  KeepNote, 
  FundingEmail,
  CalendarEvent,
  fetchUpcomingEvents,
  createCalendarEvent
} from '../services/workspaceService';
import { PolicyQualificationComparisonView } from './PolicyQualificationComparisonView';
import { ComprehensiveEvaluationResult } from '../types';
import { evaluatePolicyQualifications } from '../services/policyEligibilityMatcher';

interface ResultDashboardProps {
  result: AnalysisResult;
  onReset: () => void;
  profile?: UserProfile | null;
  token?: string | null;
  user?: any | null;
  favorites?: (PolicyFund | SourcePolicy)[];
  onToggleFavorite?: (fund: PolicyFund | SourcePolicy) => void;
  onReanalyze?: (feedback: ReanalysisFeedback) => Promise<void>;
  isReanalyzing?: boolean;
  appliedFeedback?: ReanalysisFeedback | null;
  comprehensiveEvaluation?: ComprehensiveEvaluationResult | null;
}

// 한국어 금액 문자열 파싱 (예: "1억 5천만원" -> 150000000)
const parseKoreanAmount = (str: string): number => {
  if (!str) return 0;
  const cleanStr = str.replace(/,/g, '').replace(/\s/g, '');
  
  let total = 0;
  
  // '억' 단위 처리
  const eokMatch = cleanStr.match(/(\d+(\.\d+)?)억/);
  if (eokMatch) {
    total += parseFloat(eokMatch[1]) * 100000000;
  }
  
  // '만' 단위 처리 ('억' 이후의 부분만 고려)
  const manPart = cleanStr.includes('억') ? cleanStr.split('억')[1] : cleanStr;
  const manMatch = manPart ? manPart.match(/(\d+(\.\d+)?)만/) : null;
  if (manMatch) {
    total += parseFloat(manMatch[1]) * 10000;
  } else if (!cleanStr.includes('억') && !cleanStr.includes('만')) {
    // 단위가 없는 경우 숫자로만 판단
    const rawMatch = cleanStr.match(/\d+/);
    if (rawMatch) total = parseInt(rawMatch[0]);
  }
  
  return total;
};

// 금리 문자열에서 수치 추출 (예: "2.5% ~ 3.5%" -> 2.5)
const parseInterestRate = (str: string): number => {
  if (!str) return 10;
  // '변동' 등 텍스트만 있고 숫자가 없는 경우 예외 처리
  const match = str.match(/(\d+(\.\d+)?)/);
  return match ? parseFloat(match[0]) : 10;
};

interface FeedbackState {
  helpful: boolean | null; // true: helpful, false: not helpful
  reason?: string;
  rating?: number; // 1-5
  submitted: boolean;
  comment?: string;
}


// 매출과 업종 기반으로 대략적인 예상 대출 한도 계산 (만원 단위 이하 절사)
const calculateEstimatedLoanLimit = (profile: UserProfile | null | undefined, fundMaxAmountStr: string): number | null => {
  if (!profile || !profile.annualRevenue) return null;
  
  const fundMax = parseKoreanAmount(fundMaxAmountStr);
  const revenue = profile.annualRevenue;
  
  let ratio = 0.3; // Default 30%
  switch(profile.industry) {
    case Industry.MANUFACTURING: ratio = 0.5; break;
    case Industry.IT_SOFTWARE: ratio = 0.4; break;
    case Industry.RETAIL: ratio = 0.3; break;
    case Industry.RESTAURANT: ratio = 0.25; break;
    case Industry.SERVICE: ratio = 0.25; break;
    default: ratio = 0.2; break;
  }
  
  let estimatedLimit = Math.floor(revenue * ratio);
  
  // 최소 1,000만원 보장
  if (estimatedLimit < 10000000) {
    estimatedLimit = 10000000;
  }
  
  // 상품의 최대 한도를 초과할 수 없음
  if (fundMax > 0 && estimatedLimit > fundMax) {
    estimatedLimit = fundMax;
  }
  
  // 100만원 단위 절사
  return Math.floor(estimatedLimit / 1000000) * 1000000;
};

// 숫자 금액을 한국어 단위로 포맷팅 (예: 50000000 -> 5,000만원)
const formatAmountKRW = (amount: number): string => {
  if (amount === 0) return '0원';
  if (amount >= 100000000) {
    const uk = Math.floor(amount / 100000000);
    const man = Math.floor((amount % 100000000) / 10000);
    return `${uk}억${man > 0 ? ' ' + man.toLocaleString() + '만' : ''}원`;
  }
  if (amount >= 10000) {
    const man = Math.floor(amount / 10000);
    return `${man.toLocaleString()}만원`;
  }
  return `${amount.toLocaleString()}원`;
};

const FundCard: React.FC<{ 
  fund: PolicyFund; 
  index: number; 
  isPrinting?: boolean;
  onScheduleCalendar?: (fund: PolicyFund) => void;
  isFavorite?: boolean;
  onToggleFavorite?: (fund: PolicyFund) => void;
  isSelected?: boolean;
  onToggleSelect?: (fund: PolicyFund) => void;
  onOpenPdfChecklist?: (fund: PolicyFund) => void;
  onOpenApplicationGuide?: (fund: PolicyFund) => void;
  onConfigurePush?: (fund: PolicyFund) => void;
  onOpenConsultation?: (fund: PolicyFund) => void;
  onOpenDeepLearningReport?: (fund: PolicyFund) => void;
  onOpenFormsModal?: (fund: PolicyFund) => void;
  profile?: UserProfile | null;
}> = ({ fund, index, isPrinting, onScheduleCalendar, isFavorite, onToggleFavorite, isSelected, onToggleSelect, onOpenPdfChecklist, onOpenApplicationGuide, onConfigurePush, onOpenConsultation, onOpenDeepLearningReport, onOpenFormsModal, profile }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isDescExpanded, setIsDescExpanded] = useState(false);

  // Calculate deep learning approval report & 5-tier rating
  const dlReport = useMemo(() => {
    return generateDeepLearningApprovalReport(profile, fund);
  }, [profile, fund]);

  const tierInfo = useMemo(() => {
    return getApprovalLikelihoodTier(dlReport.overallProbability);
  }, [dlReport.overallProbability]);
  
  // Feedback state per fund card (persisted to localStorage)
  const fundKey = `bizmatch_fund_feedback_${fund.title || fund.id || index}`;
  const [feedback, setFeedback] = useState<FeedbackState>(() => {
    try {
      const saved = localStorage.getItem(fundKey);
      return saved ? JSON.parse(saved) : { helpful: null, submitted: false };
    } catch {
      return { helpful: null, submitted: false };
    }
  });
  const [showFeedbackDetail, setShowFeedbackDetail] = useState(false);
  const [selectedTag, setSelectedTag] = useState<string>('');
  const [feedbackComment, setFeedbackComment] = useState<string>('');

  const handleFeedback = (isHelpful: boolean) => {
    const updated: FeedbackState = {
      ...feedback,
      helpful: isHelpful,
      submitted: true,
      reason: isHelpful ? '추천이 사업 조건과 잘 맞습니다' : '신청 조건 또는 금리가 맞지 않습니다'
    };
    setFeedback(updated);
    setShowFeedbackDetail(true);
    try {
      localStorage.setItem(fundKey, JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleSaveDetailedFeedback = () => {
    const updated: FeedbackState = {
      ...feedback,
      reason: selectedTag || feedback.reason,
      comment: feedbackComment,
      submitted: true
    };
    setFeedback(updated);
    setShowFeedbackDetail(false);
    try {
      localStorage.setItem(fundKey, JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleResetFeedback = () => {
    const resetState: FeedbackState = { helpful: null, submitted: false };
    setFeedback(resetState);
    setShowFeedbackDetail(false);
    setSelectedTag('');
    setFeedbackComment('');
    try {
      localStorage.removeItem(fundKey);
    } catch (e) {
      console.error(e);
    }
  };

  const showFullDesc = isPrinting || isExpanded || isDescExpanded;
  const showDetail = isPrinting || isExpanded;

  const isLongDescription = fund.description.length > 120;
  const isBudgetLow = fund.currentStatus === 'BUDGET_ALMOST_EXHAUSTED' || (fund.budgetExhaustionRate !== undefined && fund.budgetExhaustionRate >= 80);

  // Calculate days remaining
  const daysRemaining = useMemo(() => {
    if (!fund.applicationDeadline) return 999;
    const now = new Date();
    const end = new Date(fund.applicationDeadline);
    if (isNaN(end.getTime())) return 999;
    const diffTime = end.getTime() - now.getTime();
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }, [fund.applicationDeadline]);

  const isUrgent3Days = daysRemaining >= 0 && daysRemaining <= 3;
  const isTodayDeadline = daysRemaining === 0;

  // 3대 핵심 지표 중 예상 한도 계산
  const estLimit = useMemo(() => {
    return calculateEstimatedLoanLimit(profile, fund.maxAmount);
  }, [profile, fund.maxAmount]);
  const displayLimit = estLimit !== null ? formatAmountKRW(estLimit) : fund.maxAmount;

  // 상태 표시 색상 표준화 (Traffic Light System)
  // 안정/추천 = 파란색/초록색, 주의/확인 = 주황색, 위험/불가 = 빨간색
  const trafficLight = useMemo(() => {
    if (isBudgetLow || (dlReport && dlReport.overallProbability < 55)) {
      return {
        type: 'danger' as const,
        label: '위험 / 불가 우려',
        subLabel: isBudgetLow ? '예산 소진 임박' : '자격 요건 보완 필요',
        badgeBg: 'bg-rose-50 text-rose-700 border-rose-200',
        dotBg: 'bg-rose-500',
        accentBar: 'bg-rose-500',
        cardBorder: 'border-rose-200'
      };
    }
    if ((dlReport && dlReport.overallProbability >= 75) || index === 0) {
      return {
        type: 'safe' as const,
        label: '안정 / 추천',
        subLabel: `승인 가능성 ${dlReport.overallProbability}% (적격)`,
        badgeBg: 'bg-blue-50 text-blue-700 border-blue-200',
        dotBg: 'bg-blue-600',
        accentBar: 'bg-blue-600',
        cardBorder: 'border-blue-200'
      };
    }
    return {
      type: 'caution' as const,
      label: '주의 / 확인 필요',
      subLabel: `승인 가능성 ${dlReport.overallProbability}% (요건 검토)`,
      badgeBg: 'bg-amber-50 text-amber-800 border-amber-300',
      dotBg: 'bg-amber-500',
      accentBar: 'bg-amber-500',
      cardBorder: 'border-amber-200'
    };
  }, [isBudgetLow, dlReport, index]);

  return (
    <motion.div 
      layout="position"
      transition={{ layout: { duration: 0.35, ease: [0.16, 1, 0.3, 1] } }}
      className={`bg-white rounded-2xl shadow-sm border transition-all duration-300 relative overflow-hidden group ${
        isSelected
          ? 'ring-2 ring-indigo-500 border-indigo-300 bg-gradient-to-b from-indigo-50/20 to-white shadow-md'
          : isUrgent3Days
            ? 'border-2 border-rose-500/80 shadow-lg shadow-rose-500/10 ring-2 ring-rose-500/20'
            : isBudgetLow 
              ? 'border-rose-200 shadow-rose-100' 
              : isExpanded
                ? 'border-blue-300 shadow-lg shadow-blue-500/5 ring-1 ring-blue-100'
                : 'border-slate-200'
      } ${isPrinting ? 'mb-8 break-inside-avoid' : 'hover:shadow-lg hover:border-blue-200'}`}
    >
      <div className={`absolute top-0 left-0 w-1.5 h-full ${
        isSelected ? 'bg-indigo-600' : isUrgent3Days ? 'bg-rose-600' : trafficLight.accentBar
      }`}></div>

      {/* 3-day Urgent Deadline Alert Banner */}
      {isUrgent3Days && !isPrinting && (
        <div className="bg-gradient-to-r from-rose-600 via-red-600 to-rose-700 text-white text-[11px] font-black py-1.5 px-6 flex items-center justify-between shadow-xs">
          <div className="flex items-center gap-1.5 animate-pulse">
            <Siren className="w-3.5 h-3.5" />
            <span>⚠️ 접수 마감 {isTodayDeadline ? '오늘 18:00 D-DAY 종료!' : `D-${daysRemaining}일 전 임박!` }</span>
          </div>
          <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-bold">
            온라인 조기 접수 권장
          </span>
        </div>
      )}
      
      {/* 1. 카드 최상단: [예상 한도], [예상 금리], [지원 기관] 3대 핵심 뱃지 + 신호등 상태 표시 */}
      <div className="bg-slate-50/90 border-b border-slate-100 px-5 py-3 flex flex-wrap items-center justify-between gap-2.5">
        {/* 상태 표시 색상 표준화 (Traffic Light System) */}
        <div className="flex items-center gap-2">
          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black border ${trafficLight.badgeBg} shadow-2xs`}>
            <span className={`w-2 h-2 rounded-full ${trafficLight.dotBg} animate-pulse`} />
            <span>{trafficLight.label}</span>
          </span>
          <span className="text-[11px] font-bold text-slate-500 hidden sm:inline">
            {trafficLight.subLabel}
          </span>
        </div>

        {/* 최상단 3가지 핵심 지표 뱃지(Badge) 강조 */}
        <div className="flex items-center gap-2 flex-wrap">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-white border border-blue-200 rounded-lg shadow-2xs text-xs font-black text-slate-800">
            <span className="text-[10px] text-blue-600 font-bold">예상 한도</span>
            <span className="text-blue-700 font-black">{displayLimit}</span>
          </div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-white border border-emerald-200 rounded-lg shadow-2xs text-xs font-black text-slate-800">
            <span className="text-[10px] text-emerald-600 font-bold">예상 금리</span>
            <span className="text-emerald-700 font-black">{fund.interestRate}</span>
          </div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-white border border-indigo-200 rounded-lg shadow-2xs text-xs font-black text-slate-800">
            <span className="text-[10px] text-indigo-600 font-bold">지원 기관</span>
            <span className="text-indigo-700 font-black max-w-[130px] sm:max-w-none truncate">{fund.agency}</span>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <div className="space-y-2 pr-4 flex-grow">
            <div className="flex items-center gap-2 flex-wrap mb-1">
               {isBudgetLow && (
                 <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 text-xs font-black text-white bg-red-500 rounded-md shadow-md shadow-red-500/20 animate-pulse" title={fund.budgetExhaustionRate ? `소진율: ${fund.budgetExhaustionRate}%` : ''}>
                   <Siren className="w-3.5 h-3.5" />
                   예산 소진 임박 {fund.budgetExhaustionRate ? `(${fund.budgetExhaustionRate}%)` : ''}
                 </span>
               )}
               {!isBudgetLow && index === 0 && !isPrinting && (
                 <span className="inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold text-white bg-emerald-500 rounded-full uppercase tracking-wider">
                   Best Match
                 </span>
               )}
               <span className="inline-block px-2.5 py-1 text-[11px] font-bold text-blue-700 bg-blue-50 rounded-md border border-blue-100 uppercase tracking-tight">
                  {fund.category}
               </span>
               {!isPrinting && onOpenDeepLearningReport && (
                 <button
                   type="button"
                   onClick={(e) => {
                     e.stopPropagation();
                     onOpenDeepLearningReport(fund);
                   }}
                   className="inline-flex items-center gap-1 px-2.5 py-0.5 text-[10px] font-black rounded-full border transition-all cursor-pointer shadow-2xs hover:scale-105 active:scale-95"
                   style={{
                     backgroundColor: tierInfo.bgColor,
                     color: tierInfo.color,
                     borderColor: tierInfo.badgeColor
                   }}
                   title="과거 승인 성공 빅데이터 매칭 5단계 승인 가능성 리포트 보기"
                 >
                   <Zap className="w-3 h-3 text-amber-500 fill-amber-500" />
                   <span>승인 {tierInfo.tierKorean} ({dlReport.overallProbability}%)</span>
                   {dlReport.policyBonusAdjustment && dlReport.policyBonusAdjustment.totalBonusUplift > 0 && (
                     <span className="text-[9px] font-black text-emerald-800 bg-emerald-100/90 px-1 py-0.2 rounded ml-1" title="스마트공장·탄소중립 등 가점 보정 적용">
                       +{dlReport.policyBonusAdjustment.totalBonusUplift}%p
                     </span>
                   )}
                 </button>
               )}
               {isSelected && (
                 <span className="inline-flex items-center gap-1 px-2.5 py-0.5 text-[10px] font-black text-indigo-700 bg-indigo-100 rounded-full border border-indigo-200">
                   <Scale className="w-3 h-3" /> 비교 선택됨
                 </span>
               )}
            </div>
            
            {/* Clickable Header Area */}
            <div 
              onClick={() => !isPrinting && setIsExpanded(!isExpanded)}
              className="cursor-pointer select-none group/title py-0.5 rounded-xl hover:bg-slate-50/70 transition-colors -mx-1 px-1"
              title={isExpanded ? "클릭하여 카드 상세 정보 접기" : "클릭하여 카드 상세 정보 펼치기"}
            >
              <div className="flex items-start justify-between gap-2">
                <h3 className="text-xl font-bold text-gray-900 group-hover/title:text-blue-600 transition-colors">
                  {fund.title}
                </h3>
                <span className="text-xs font-bold text-slate-500 group-hover/title:text-blue-600 flex items-center gap-1 shrink-0 bg-slate-50 group-hover/title:bg-blue-50 border border-slate-200 group-hover/title:border-blue-200 px-2.5 py-1 rounded-full transition-all mt-0.5">
                  <span>{isExpanded ? '상세 접기' : '상세 펼치기'}</span>
                  <motion.div
                    animate={{ rotate: isExpanded ? 180 : 0 }}
                    transition={{ duration: 0.3, ease: 'easeInOut' }}
                  >
                    <ChevronDown className="w-3.5 h-3.5" />
                  </motion.div>
                </span>
              </div>
              
              <div className="flex items-center gap-1.5 px-0.5 mt-1">
                <Landmark className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-xs font-bold text-slate-500">{fund.agency}</span>
                <span className="text-slate-300">•</span>
                <span className="text-xs text-slate-500 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  기한: {fund.applicationDeadline || '별도 공지'}
                </span>
              </div>
            </div>
          </div>
          
          <div className="text-right flex-shrink-0 flex flex-col items-end gap-2">
            <div className="flex items-center gap-1.5 mt-1 flex-wrap justify-end">
              {onOpenConsultation && !isPrinting && (
                <button
                  type="button"
                  onClick={() => onOpenConsultation(fund)}
                  className="text-xs font-black bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white rounded-xl px-3 py-1.5 flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-md shadow-indigo-500/20 hover:scale-105 active:scale-95 shrink-0"
                  title="해당 자금의 심사 요건 및 부결 방지 1:1 비대면 전문 상담 신청"
                >
                  <Headphones className="w-3.5 h-3.5 text-indigo-200" />
                  <span>전문가 상담 문의</span>
                </button>
              )}
              {onOpenPdfChecklist && !isPrinting && (
                <button
                  type="button"
                  onClick={() => onOpenPdfChecklist(fund)}
                  className="text-xs font-bold border border-blue-200 bg-blue-50/80 hover:bg-blue-100 text-blue-700 rounded-xl px-2.5 py-1.5 flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs hover:shadow"
                  title="공고문 원문 PDF 분석 및 핵심 체크리스트 보기"
                >
                  <FileCheck2 className="w-3.5 h-3.5 text-blue-600" />
                  <span>PDF 체크리스트</span>
                </button>
              )}
              {onOpenApplicationGuide && !isPrinting && (
                <button
                  type="button"
                  onClick={() => onOpenApplicationGuide(fund)}
                  className="text-xs font-bold border border-emerald-200 bg-emerald-50/80 hover:bg-emerald-100 text-emerald-700 rounded-xl px-2.5 py-1.5 flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs hover:shadow"
                  title="해당 자금의 상세 신청 절차 및 필수 구비 서류 확인"
                >
                  <MapPin className="w-3.5 h-3.5 text-emerald-600" />
                  <span>신청 가이드</span>
                </button>
              )}
              {onToggleSelect && !isPrinting && (
                <button
                  type="button"
                  onClick={() => onToggleSelect(fund)}
                  className={`text-xs font-bold border rounded-xl px-2.5 py-1.5 flex items-center justify-center gap-1 transition-all cursor-pointer shadow-xs ${
                    isSelected
                      ? 'bg-indigo-600 border-indigo-600 text-white shadow-indigo-100 ring-2 ring-indigo-200'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-200'
                  }`}
                  title={isSelected ? "비교 선택 해제" : "비교 대상에 추가"}
                >
                  <Scale className={`w-3.5 h-3.5 ${isSelected ? 'text-white' : 'text-indigo-600'}`} />
                  <span>{isSelected ? '비교 해제' : '비교 선택'}</span>
                </button>
              )}
              {onToggleFavorite && (
                <button
                  type="button"
                  onClick={() => onToggleFavorite(fund)}
                  className={`text-xs font-bold border rounded-xl px-2.5 py-1.5 flex items-center justify-center gap-1 transition-all cursor-pointer shadow-xs hover:shadow ${
                    isFavorite
                      ? 'bg-amber-50 border-amber-300 text-amber-700 hover:bg-amber-100'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50 hover:text-amber-600'
                  }`}
                  title={isFavorite ? "즐겨찾기 해제" : "즐겨찾기 추가"}
                >
                  <Star className={`w-3.5 h-3.5 ${isFavorite ? 'fill-amber-400 text-amber-500' : ''}`} />
                  <span className="hidden sm:inline">{isFavorite ? '즐겨찾기됨' : '즐겨찾기'}</span>
                </button>
              )}
              {onConfigurePush && (
                <button
                  type="button"
                  onClick={() => onConfigurePush(fund)}
                  className="text-[10px] bg-slate-50 hover:bg-indigo-50 text-slate-700 hover:text-indigo-700 font-black border border-slate-200 hover:border-indigo-200 rounded-xl px-2.5 py-1.5 flex items-center justify-center gap-1 transition-all cursor-pointer shadow-xs hover:shadow"
                  title="이 자금의 마감 임박/추가 공고/서류 변경 알림 설정"
                >
                  <BellRing className="w-3.5 h-3.5 text-indigo-600" />
                  <span className="hidden sm:inline">알림 설정</span>
                </button>
              )}
              {onScheduleCalendar && (
                <button
                  type="button"
                  onClick={() => onScheduleCalendar(fund)}
                  className="text-[10px] bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-black border border-indigo-200 rounded-xl px-2.5 py-1.5 flex items-center justify-center gap-1 transition-all cursor-pointer shadow-xs hover:shadow"
                  title="구글 캘린더에 마감 일정 등록"
                >
                  <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                  <span className="hidden sm:inline">기한 등록</span>
                </button>
              )}
            </div>
          </div>
        </div>
        
        {/* 간결한 요약 설명 */}
        <div className="mb-4">
          <p className={`text-slate-600 text-sm leading-relaxed ${showFullDesc ? '' : 'line-clamp-2'}`}>
            {fund.description}
          </p>
        </div>

        {/* 점진적 정보 탐색 (Progressive Disclosure) 아코디언 토글 버튼 */}
        {!isPrinting && (
          <div className="pt-2">
            <button
              type="button"
              onClick={() => setIsExpanded(!isExpanded)}
              className={`w-full py-2.5 px-4 rounded-xl font-black text-xs flex items-center justify-center gap-2 transition-all cursor-pointer ${
                isExpanded 
                  ? 'bg-slate-100 text-slate-700 hover:bg-slate-200' 
                  : 'bg-blue-50 text-blue-700 hover:bg-blue-100 border border-blue-200/70 shadow-2xs'
              }`}
            >
              <span>{isExpanded ? '상세 정보 접기 (자격 요건 & 시뮬레이터)' : '자격 요건 · 필수 서류 · 대출 시뮬레이터 상세 펼치기'}</span>
              <motion.div
                animate={{ rotate: isExpanded ? 180 : 0 }}
                transition={{ duration: 0.25 }}
              >
                <ChevronDown className="w-4 h-4" />
              </motion.div>
            </button>
          </div>
        )}

        {/* Smooth Expandable Detail Content using Framer-Motion (Progressive Disclosure) */}
        <AnimatePresence initial={false}>
          {showDetail && (
            <motion.div
              key="fund-expanded-detail"
              initial={{ opacity: 0, height: 0, overflow: 'hidden' }}
              animate={{ 
                opacity: 1, 
                height: 'auto',
                overflow: 'visible',
                transition: { 
                  height: { duration: 0.38, ease: [0.16, 1, 0.3, 1] },
                  opacity: { duration: 0.25, delay: 0.08 }
                }
              }}
              exit={{ 
                opacity: 0, 
                height: 0,
                overflow: 'hidden',
                transition: { 
                  height: { duration: 0.28, ease: [0.4, 0, 0.2, 1] },
                  opacity: { duration: 0.15 }
                }
              }}
              className="mt-6 pt-6 border-t border-slate-100 space-y-6"
            >
              {/* Comprehensive Policy Highlights Grid (한눈에 보는 핵심 요약) */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 p-3.5 bg-gradient-to-br from-slate-50 to-blue-50/40 rounded-2xl border border-blue-100/70 text-xs">
                <div className="bg-white p-2.5 rounded-xl border border-slate-200/60 shadow-2xs">
                  <span className="text-[10px] font-bold text-slate-400 block mb-0.5">지원 대상 유형</span>
                  <span className="font-bold text-slate-800 truncate block">{fund.category}</span>
                </div>
                <div className="bg-white p-2.5 rounded-xl border border-slate-200/60 shadow-2xs">
                  <span className="text-[10px] font-bold text-slate-400 block mb-0.5">예상 금리 조건</span>
                  <span className="font-bold text-emerald-700 truncate block">{fund.interestRate}</span>
                </div>
                <div className="bg-white p-2.5 rounded-xl border border-slate-200/60 shadow-2xs">
                  <span className="text-[10px] font-bold text-slate-400 block mb-0.5">상환 및 거치 기간</span>
                  <span className="font-bold text-indigo-700 truncate block">{fund.repaymentPeriod || '최대 5년 (거치 2년)'}</span>
                </div>
                <div className="bg-white p-2.5 rounded-xl border border-slate-200/60 shadow-2xs">
                  <span className="text-[10px] font-bold text-slate-400 block mb-0.5">접수 방식</span>
                  <span className="font-bold text-blue-700 truncate block">온라인 / 방문 접수</span>
                </div>
              </div>

              {/* Online Application Link Banner if applicationUrl exists */}
              {fund.applicationUrl && !isPrinting && (
                <div className="flex items-center justify-between p-3 bg-indigo-50/80 border border-indigo-100 rounded-xl">
                  <div className="flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-indigo-600" />
                    <span className="text-xs font-bold text-indigo-950">공식 온라인 접수 창구 지원</span>
                  </div>
                  <a
                    href={fund.applicationUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="inline-flex items-center gap-1 text-xs font-black text-indigo-700 hover:text-indigo-900 bg-white px-2.5 py-1 rounded-lg border border-indigo-200 shadow-2xs hover:shadow-xs transition-all"
                  >
                    <span>온라인 신청 바로가기</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              )}

              {/* Realtime Profile-Matching Eligibility Checklist */}
              <div>
                <FundEligibilityChecklist
                  fund={fund}
                  profile={profile}
                  isPrinting={isPrinting}
                  onOpenPdfChecklist={onOpenPdfChecklist ? () => onOpenPdfChecklist(fund) : undefined}
                />
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                  <ClipboardCheck className="w-5 h-5 text-emerald-500" />
                  <span>공식 공고문 자격 요건 전문</span>
                </div>
                <div className="bg-emerald-50/30 rounded-xl p-4 border border-emerald-50">
                  <p className="text-slate-700 text-sm leading-relaxed whitespace-pre-wrap">
                    {fund.eligibility}
                  </p>
                </div>
              </div>

              <div className="pt-2">
                <DocumentIssuanceGuide
                  documents={fund.requiredDocuments || []}
                  fundTitle={fund.title}
                  fund={fund}
                  profile={profile}
                />
              </div>

              {fund.writingGuide && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                    <FileText className="w-5 h-5 text-indigo-500" />
                    <span>서류 작성 가이드라인</span>
                  </div>
                  <div className="bg-indigo-50/30 rounded-xl p-4 border border-indigo-50">
                    <p className="text-slate-700 text-sm leading-relaxed whitespace-pre-wrap">
                      {fund.writingGuide}
                    </p>
                  </div>
                </div>
              )}

              {fund.applicationProcedure && fund.applicationProcedure.length > 0 && (
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-slate-900 font-bold text-sm">
                    <ClipboardCheck className="w-5 h-5 text-purple-500" />
                    <span>신청 절차</span>
                  </div>
                  <div className="bg-purple-50/30 rounded-xl p-4 border border-purple-50">
                    <ul className="list-decimal list-inside text-slate-700 text-sm leading-relaxed space-y-2">
                      {fund.applicationProcedure.map((step, idx) => (
                        <li key={idx}>{step}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {/* 맞춤 대출 원리금 상환 시뮬레이터 */}
              {!isPrinting && (
                <div className="pt-2">
                  <FundLoanSimulator fund={fund} profile={profile} />
                </div>
              )}

              <div className="flex flex-col md:flex-row gap-4 pt-2">
                {onOpenConsultation && !isPrinting ? (
                  <div 
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenConsultation(fund);
                    }}
                    className="flex-grow bg-gradient-to-r from-indigo-900 via-slate-900 to-blue-900 text-white rounded-xl p-4 flex items-center justify-between group cursor-pointer hover:shadow-lg hover:shadow-indigo-900/30 transition-all border border-indigo-700/40"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-indigo-500/30 text-indigo-300 rounded-lg flex items-center justify-center">
                        <Headphones className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-[10px] text-indigo-300 font-bold uppercase flex items-center gap-1">
                          <span>1:1 비대면 전문 컨설팅</span>
                          <span className="bg-indigo-500/40 text-indigo-200 text-[9px] px-1.5 py-0.2 rounded font-black">무료</span>
                        </div>
                        <div className="text-sm font-black text-white group-hover:text-indigo-200 transition-colors">
                          전문가에게 상담 문의하기
                        </div>
                      </div>
                    </div>
                    <ArrowRightCircle className="w-5 h-5 text-indigo-300 group-hover:translate-x-1 transition-all" />
                  </div>
                ) : (
                  <div className="flex-grow bg-slate-900 text-white rounded-xl p-4 flex items-center justify-between group cursor-pointer hover:bg-slate-800 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center">
                        <Info className="w-5 h-5" />
                      </div>
                      <div>
                        <div className="text-[10px] text-slate-400 font-bold uppercase">신청 방법</div>
                        <div className="text-sm font-bold">온라인/오프라인 접수 가능</div>
                      </div>
                    </div>
                    <ArrowRightCircle className="w-5 h-5 text-slate-500 group-hover:text-white transition-colors" />
                  </div>
                )}

                <div className="flex-grow bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-3 shadow-sm">
                  <div className="w-10 h-10 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-[10px] text-slate-400 font-bold uppercase">주관기관 대표 문의처</div>
                    <div className="text-sm font-bold text-slate-900">{fund.contactInfo}</div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* 거절 리스크 알림 */}
        {!isPrinting && dlReport.overallProbability < 60 && dlReport.keyRiskFactors && dlReport.keyRiskFactors.length > 0 && (
          <div className="mt-4 p-4 bg-rose-50 border border-rose-200 rounded-2xl flex flex-col gap-3 shadow-sm">
            <div className="flex items-center gap-2 text-rose-700 font-bold text-sm">
              <div className="w-6 h-6 rounded-full bg-rose-200/50 flex items-center justify-center">
                <AlertTriangle className="w-3.5 h-3.5" />
              </div>
              거절 리스크 알림 (주의)
            </div>
            <div className="bg-white/60 p-3 rounded-xl border border-rose-100">
              <ul className="list-disc list-inside text-rose-800 text-[13px] font-medium space-y-1.5">
                {dlReport.keyRiskFactors.map((risk, idx) => (
                  <li key={idx}>{risk}</li>
                ))}
              </ul>
            </div>
            <p className="text-[11px] text-rose-600/80 font-medium px-1">
              해당 정책자금은 위 주요 요인으로 인해 심사에서 거절될 가능성이 있습니다. 신청 전 보완하거나 타 자금을 우선적으로 검토하시길 권장합니다.
            </p>
          </div>
        )}
        
        {/* AI Matching Feedback Section ('이 결과가 도움이 되었나요?') */}
        {!isPrinting && (
          <div className="mt-5 pt-4 border-t border-slate-100/80">
            {feedback.submitted && !showFeedbackDetail ? (
              <div className="bg-slate-50/90 rounded-2xl p-3.5 flex items-center justify-between gap-3 animate-fade-in border border-slate-100">
                <div className="flex items-center gap-2 text-xs">
                  {feedback.helpful ? (
                    <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                      <ThumbsUp className="w-3.5 h-3.5" />
                    </span>
                  ) : (
                    <span className="w-6 h-6 rounded-full bg-rose-100 text-rose-700 flex items-center justify-center font-bold">
                      <ThumbsDown className="w-3.5 h-3.5" />
                    </span>
                  )}
                  <div>
                    <span className="font-bold text-slate-800">
                      {feedback.helpful ? '도움이 됨으로 평가하셨습니다' : '개선 필요로 평가하셨습니다'}
                    </span>
                    {feedback.reason && (
                      <span className="text-slate-500 ml-1 text-[11px]">· {feedback.reason}</span>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setShowFeedbackDetail(true)}
                    className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 px-2 py-1 rounded-lg hover:bg-indigo-50 transition-colors"
                  >
                    수정 / 의견 추가
                  </button>
                  <button
                    type="button"
                    onClick={handleResetFeedback}
                    className="text-[11px] font-medium text-slate-400 hover:text-slate-600 px-1.5 py-1 rounded-lg hover:bg-slate-200/50 transition-colors"
                    title="피드백 취소"
                  >
                    취소
                  </button>
                </div>
              </div>
            ) : showFeedbackDetail ? (
              <div className="bg-gradient-to-br from-slate-50 to-indigo-50/30 rounded-2xl p-4 border border-indigo-100/60 shadow-sm animate-fade-in space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-slate-900 flex items-center gap-1.5">
                      <MessageSquare className="w-3.5 h-3.5 text-indigo-600" />
                      AI 매칭 정확도 상세 피드백
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setShowFeedbackDetail(false)}
                    className="text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <p className="text-[11px] text-slate-600">
                  {feedback.helpful
                    ? '이 추천이 어떤 점에서 유용했나요? (선택)'
                    : '어떤 부분이 사업장 조건과 맞지 않나요? AI 학습에 반영됩니다.'}
                </p>

                {/* Reason Selection Tags */}
                <div className="flex flex-wrap gap-1.5">
                  {(feedback.helpful
                    ? ['자격 요건 충족', '금리/한도 우수', '신청 기한 여유', '주관기관 신뢰도', '서류 준비 용이']
                    : ['금리가 너무 높음', '대출 한도 부족', '업종/매출 자격 미달', '제출 서류 과다', '기타']
                  ).map((tag) => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => setSelectedTag(tag === selectedTag ? '' : tag)}
                      className={`text-[11px] font-bold px-2.5 py-1 rounded-lg border transition-all ${
                        selectedTag === tag
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                          : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-200 hover:bg-indigo-50/50'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>

                {/* Additional Comment Input */}
                <div className="relative">
                  <input
                    type="text"
                    placeholder="소중한 한 줄 의견을 남겨주세요 (선택사항)"
                    value={feedbackComment}
                    onChange={(e) => setFeedbackComment(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 font-medium"
                    maxLength={100}
                  />
                </div>

                <div className="flex justify-end gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setShowFeedbackDetail(false)}
                    className="px-3 py-1.5 text-xs font-bold text-slate-500 hover:bg-slate-200/60 rounded-xl transition-colors"
                  >
                    닫기
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveDetailedFeedback}
                    className="px-4 py-1.5 text-xs font-black text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-sm transition-all"
                  >
                    피드백 등록 완료
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-1.5 text-xs font-bold text-slate-600">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                  <span>이 결과가 도움이 되었나요?</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleFeedback(true)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-50 hover:bg-emerald-50 text-slate-600 hover:text-emerald-700 border border-slate-200 hover:border-emerald-200 transition-all hover:scale-105 active:scale-95 shadow-xs"
                    title="도움이 됨"
                  >
                    <ThumbsUp className="w-3.5 h-3.5 text-emerald-600" />
                    <span>도움돼요</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleFeedback(false)}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold bg-slate-50 hover:bg-rose-50 text-slate-600 hover:text-rose-700 border border-slate-200 hover:border-rose-200 transition-all hover:scale-105 active:scale-95 shadow-xs"
                    title="도움되지 않음"
                  >
                    <ThumbsDown className="w-3.5 h-3.5 text-rose-500" />
                    <span>아쉬워요</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
        
        {!isPrinting && (
          <motion.button 
            whileHover={{ scale: 1.005 }}
            whileTap={{ scale: 0.99 }}
            onClick={() => setIsExpanded(!isExpanded)}
            className={`w-full py-3.5 mt-6 text-sm font-bold rounded-xl transition-all flex items-center justify-center gap-2 cursor-pointer ${
              isExpanded 
                ? 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200/80 shadow-2xs' 
                : isBudgetLow
                  ? 'bg-red-600 text-white hover:bg-red-700 shadow-lg shadow-red-500/20'
                  : 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white hover:from-blue-700 hover:to-indigo-700 shadow-md shadow-blue-500/20'
            }`}
          >
            <span>{isExpanded ? '상세 정보 닫기' : '카드 클릭하여 상세 자격 및 세부 정보 펼치기'}</span> 
            <motion.div
              animate={{ rotate: isExpanded ? 180 : 0 }}
              transition={{ duration: 0.3, ease: 'easeInOut' }}
            >
              <ChevronDown className="w-4 h-4" />
            </motion.div>
          </motion.button>
        )}
      </div>
    </motion.div>
  );
};

export const ResultDashboard: React.FC<ResultDashboardProps> = ({ 
  result, 
  onReset, 
  profile, 
  token, 
  user, 
  favorites = [], 
  onToggleFavorite,
  onReanalyze,
  isReanalyzing = false,
  appliedFeedback = null,
  comprehensiveEvaluation = null
}) => {
  const [dashboardTab, setDashboardTab] = useState<'QUALIFICATION' | 'COMPARISON' | 'AI_REPORT' | 'APPLICATION_GUIDE'>('QUALIFICATION');

  const [dashboardBonusFactors, setDashboardBonusFactors] = useState<PolicyBonusFactors>(() => profile?.policyBonusFactors || {});

  React.useEffect(() => {
    if (profile?.policyBonusFactors) {
      setDashboardBonusFactors(profile.policyBonusFactors);
    }
  }, [profile?.policyBonusFactors]);

  const effectiveProfile = useMemo(() => {
    if (!profile) return null;
    return {
      ...profile,
      policyBonusFactors: dashboardBonusFactors
    };
  }, [profile, dashboardBonusFactors]);

  const evalResult = useMemo(() => {
    if (effectiveProfile) return evaluatePolicyQualifications(effectiveProfile);
    if (comprehensiveEvaluation) return comprehensiveEvaluation;
    return null;
  }, [comprehensiveEvaluation, effectiveProfile]);

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedAgency, setSelectedAgency] = useState('All');
  const [minLoanAmount, setMinLoanAmount] = useState<number>(0);
  const [maxInterestRate, setMaxInterestRate] = useState<number>(10);
  const [sortOption, setSortOption] = useState<string>('default');
  const [peerMetric, setPeerMetric] = useState<'SHARE' | 'AMOUNT' | 'RATE'>('SHARE');

  // Policy Fund Comparison States (default to top 2 funds for immediate side-by-side comparison)
  const [selectedFundIds, setSelectedFundIds] = useState<string[]>(() => 
    (result.matchedFunds || []).slice(0, 2).map(f => f.id || f.title)
  );
  const [isCompareModalOpen, setIsCompareModalOpen] = useState(false);

  // Policy Fund PDF Checklist Modal State
  const [pdfChecklistFund, setPdfChecklistFund] = useState<PolicyFund | null>(null);
  const [selectedGuideFund, setSelectedGuideFund] = useState<PolicyFund | null>(null);
  const [isPrinting, setIsPrinting] = useState<boolean>(false);

  // Detailed Feedback & Reanalysis Modal State
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isDetailedFeedbackModalOpen, setIsDetailedFeedbackModalOpen] = useState(false);

  // Push Notification Modal State
  const [isPushModalOpen, setIsPushModalOpen] = useState(false);
  const [pushModalTarget, setPushModalTarget] = useState<any | null>(null);

  // Expert Consultation Modal State
  const [isConsultModalOpen, setIsConsultModalOpen] = useState(false);
  const [consultModalFund, setConsultModalFund] = useState<PolicyFund | SourcePolicy | any | null>(null);
  const [consultSuccessToast, setConsultSuccessToast] = useState<string | null>(null);

  // Deep Learning Approval Probability Report Modal State
  const [isDeepLearningModalOpen, setIsDeepLearningModalOpen] = useState(false);
  const [deepLearningModalFund, setDeepLearningModalFund] = useState<PolicyFund | SourcePolicy | any | null>(null);
  const [activeReportFundTitle, setActiveReportFundTitle] = useState<string>('');

  // Google Forms Survey & Assessment Modal State
  const [isFormsModalOpen, setIsFormsModalOpen] = useState(false);
  const [formsModalTarget, setFormsModalTarget] = useState<PolicyFund | null>(null);

  // Google Contacts (People API) Modal State
  const [isContactsModalOpen, setIsContactsModalOpen] = useState(false);

  // Google Tasks API Modal State
  const [isTasksModalOpen, setIsTasksModalOpen] = useState(false);
  const [tasksModalTarget, setTasksModalTarget] = useState<PolicyFund | null>(null);

  const handleOpenDeepLearningReport = (fund: PolicyFund | SourcePolicy | any) => {
    setDeepLearningModalFund(fund);
    setIsDeepLearningModalOpen(true);
  };

  const handleOpenConsultation = (fund: PolicyFund | SourcePolicy | any) => {
    setConsultModalFund(fund);
    setIsConsultModalOpen(true);
  };

  const handleConsultationSuccess = (reqData: ConsultationRequestData) => {
    setConsultSuccessToast(`'${reqData.fundTitle}'에 대한 1:1 비대면 전문 상담 신청이 정상 접수되었습니다. (배정: ${reqData.assignedExpert?.name})`);
    setTimeout(() => {
      setConsultSuccessToast(null);
    }, 5000);
  };

  // Overall Report Satisfaction Feedback State
  const reportFeedbackKey = `bizmatch_report_feedback_${profile?.businessName || 'default'}`;
  const [reportFeedback, setReportFeedback] = useState<FeedbackState>(() => {
    try {
      const saved = localStorage.getItem(reportFeedbackKey);
      return saved ? JSON.parse(saved) : { helpful: null, rating: 0, submitted: false };
    } catch {
      return { helpful: null, rating: 0, submitted: false };
    }
  });
  const [showReportFeedbackModal, setShowReportFeedbackModal] = useState(false);
  const [reportComment, setReportComment] = useState('');
  const [reportTags, setReportTags] = useState<string[]>([]);
  const [reportRating, setReportRating] = useState<number>(0);

  const handleSaveDetailedFeedback = (feedback: ReanalysisFeedback) => {
    const updated: FeedbackState = {
      helpful: feedback.isHelpful,
      rating: feedback.satisfactionRating,
      reason: feedback.selectedReasons.join(', '),
      comment: feedback.userCustomPrompt || '',
      submitted: true
    };
    setReportFeedback(updated);
    setReportRating(feedback.satisfactionRating);
    try {
      localStorage.setItem(reportFeedbackKey, JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleTriggerReanalysis = async (feedback: ReanalysisFeedback) => {
    handleSaveDetailedFeedback(feedback);
    if (onReanalyze) {
      await onReanalyze(feedback);
      setIsDetailedFeedbackModalOpen(false);
    }
  };

  const handleReportHelpful = (isHelpful: boolean) => {
    const updated: FeedbackState = {
      ...reportFeedback,
      helpful: isHelpful,
      submitted: true,
      rating: isHelpful ? 5 : 2
    };
    setReportFeedback(updated);
    setReportRating(isHelpful ? 5 : 2);
    setShowReportFeedbackModal(true);
    try {
      localStorage.setItem(reportFeedbackKey, JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleSaveReportFeedback = () => {
    const updated: FeedbackState = {
      ...reportFeedback,
      rating: reportRating || reportFeedback.rating || 5,
      reason: reportTags.join(', '),
      comment: reportComment,
      submitted: true
    };
    setReportFeedback(updated);
    setShowReportFeedbackModal(false);
    try {
      localStorage.setItem(reportFeedbackKey, JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleResetReportFeedback = () => {
    const resetState: FeedbackState = { helpful: null, rating: 0, submitted: false };
    setReportFeedback(resetState);
    setShowReportFeedbackModal(false);
    setReportComment('');
    setReportTags([]);
    setReportRating(0);
    try {
      localStorage.removeItem(reportFeedbackKey);
    } catch (e) {
      console.error(e);
    }
  };

  // Google Workspace execution feedback states
  const [isExportingSheet, setIsExportingSheet] = useState(false);
  const [sheetUrl, setSheetUrl] = useState<string | null>(null);
  
  const [isExportingSlide, setIsExportingSlide] = useState(false);
  const [slideUrl, setSlideUrl] = useState<string | null>(null);
  
  const [isExportingDoc, setIsExportingDoc] = useState(false);
  const [docUrl, setDocUrl] = useState<string | null>(null);
  
  const [isArchivingDrive, setIsArchivingDrive] = useState(false);
  const [archiveFileId, setArchiveFileId] = useState<string | null>(null);
  
  const [isSendingMail, setIsSendingMail] = useState(false);
  const [emailTo, setEmailTo] = useState(user?.email || '');
  const [mailSuccess, setMailSuccess] = useState<string | null>(null);
  
  const [fundingEmails, setFundingEmails] = useState<FundingEmail[]>([]);
  const [isSyncingMails, setIsSyncingMails] = useState(false);
  const [emailSyncError, setEmailSyncError] = useState(false);
  
  const [notes, setNotes] = useState<KeepNote[]>([]);
  const [newNoteTitle, setNewNoteTitle] = useState('');
  const [newNoteContent, setNewNoteContent] = useState('');
  const [newNoteColor, setNewNoteColor] = useState('bg-yellow-50');
  const [isCreatingNote, setIsCreatingNote] = useState(false);

  // Google Calendar integration states
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>([]);
  const [isSyncingCalendar, setIsSyncingCalendar] = useState(false);
  const [calendarSyncError, setCalendarSyncError] = useState(false);
  const [isCreatingEvent, setIsCreatingEvent] = useState(false);
  const [calendarSuccess, setCalendarSuccess] = useState<string | null>(null);

  // Custom manual event form states
  const [newCalTitle, setNewCalTitle] = useState('');
  const [newCalDesc, setNewCalDesc] = useState('');
  const [newCalDate, setNewCalDate] = useState('');
  const [newCalTime, setNewCalTime] = useState('14:00');

  // Load notes and sync email inboxes / calendars if user is logged in
  React.useEffect(() => {
    if (user && token) {
      loadKeepNotes();
      loadInboxFunding();
      loadUpcomingCalendarEvents();
      setEmailTo(user.email || '');
    }
  }, [user, token]);

  const loadUpcomingCalendarEvents = async () => {
    if (!token) return;
    setIsSyncingCalendar(true);
    setCalendarSyncError(false);
    try {
      const items = await fetchUpcomingEvents(token);
      setCalendarEvents(items);
    } catch (err) {
      console.error("Calendar Load Error", err);
      setCalendarSyncError(true);
    } finally {
      setIsSyncingCalendar(false);
    }
  };

  const loadKeepNotes = async () => {
    if (!user) return;
    try {
      const dbNotes = await fetchKeepNotes(user.uid);
      setNotes(dbNotes);
    } catch (err) {
      console.error("Keep Load Error", err);
    }
  };

  const loadInboxFunding = async () => {
    if (!token) return;
    setIsSyncingMails(true);
    setEmailSyncError(false);
    try {
      const ems = await syncFundingEmails(token);
      setFundingEmails(ems);
    } catch (err) {
      console.error(err);
      setEmailSyncError(true);
    } finally {
      setIsSyncingMails(false);
    }
  };

  const handleCreateNote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newNoteTitle.trim() || !newNoteContent.trim()) return;
    setIsCreatingNote(true);
    try {
      await createKeepNote(user.uid, {
        title: newNoteTitle,
        content: newNoteContent,
        color: newNoteColor,
        isPinned: false
      });
      setNewNoteTitle('');
      setNewNoteContent('');
      setNewNoteColor('bg-yellow-50');
      await loadKeepNotes();
    } catch (e) {
      console.error(e);
    } finally {
      setIsCreatingNote(false);
    }
  };

  const handleTogglePin = async (note: KeepNote) => {
    if (!user || !note.id) return;
    try {
      await updateKeepNote(user.uid, note.id, { isPinned: !note.isPinned });
      await loadKeepNotes();
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeleteNote = async (noteId: string) => {
    if (!user) return;
    try {
      await deleteKeepNote(user.uid, noteId);
      await loadKeepNotes();
    } catch (e) {
      console.error(e);
    }
  };

  const categories = useMemo(() => {
    const cats = new Set(result.matchedFunds.map(f => f.category));
    return ['All', ...Array.from(cats)];
  }, [result.matchedFunds]);

  const agencies = useMemo(() => {
    const ags = new Set(result.matchedFunds.map(f => f.agency));
    return ['All', ...Array.from(ags)];
  }, [result.matchedFunds]);

  // 필터가 하나라도 적용되었는지 확인
  const isFiltered = searchQuery !== '' || selectedCategory !== 'All' || selectedAgency !== 'All' || minLoanAmount !== 0 || maxInterestRate !== 10 || sortOption !== 'default';

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedAgency('All');
    setMinLoanAmount(0);
    setMaxInterestRate(10);
    setSortOption('default');
  };

  // Google Sheets Export Routines
  const handleSheetExport = async () => {
    if (!token) return;
    setIsExportingSheet(true);
    try {
      const title = `${profile?.businessName || '소상공인'} 자금 매칭 분석 시트`;
      const headers = ['정책자금명', '주관기관', '카테고리', '자격기준', '최대한도', '이율', '기한', '문의처'];
      const rows = filteredFunds.map(f => [
        f.title, f.agency, f.category, f.eligibility, f.maxAmount, f.interestRate, f.applicationDeadline || (f as any).deadline || '', f.contactInfo
      ]);
      const url = await createFundingGoogleSheet(token, title, headers, rows);
      setSheetUrl(url);
    } catch (err) {
      console.error(err);
    } finally {
      setIsExportingSheet(false);
    }
  };

  // Google Slides Export Routines
  const handleSlideExport = async () => {
    if (!token) return;
    setIsExportingSlide(true);
    try {
      const pTitle = `BizMatch AI - ${profile?.businessName || '우리기업'} 피칭 분석 프리젠테이션`;
      const url = await createWorkspaceSlideshow(token, pTitle, profile || {}, result);
      setSlideUrl(url);
    } catch (err) {
      console.error(err);
    } finally {
      setIsExportingSlide(false);
    }
  };

  // Google Docs Export Routines
  const handleDocExport = async () => {
    if (!token) return;
    setIsExportingDoc(true);
    try {
      const docTitle = `BizMatch AI - ${profile?.businessName || '우리기업'} 맞춤형 정책자금 진단 보고서`;
      const url = await createWorkspaceDocument(token, docTitle, profile || {}, result);
      setDocUrl(url);
    } catch (err) {
      console.error(err);
    } finally {
      setIsExportingDoc(false);
    }
  };

  // Google Calendar Manual Booking
  const handleCreateManualCalendarEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !newCalTitle.trim() || !newCalDate) return;

    // Explicit confirmation dialog per Workspace Integration guide
    const confirmMsg = `[구글 캘린더 일정 추가] '${newCalTitle}' 일정을 구글 캘린더에 등록하시겠습니까?`;
    const confirmed = window.confirm(confirmMsg);
    if (!confirmed) return;

    setIsCreatingEvent(true);
    setCalendarSuccess(null);
    try {
      const startDateTime = `${newCalDate}T${newCalTime}:00`;
      const [hours, minutes] = newCalTime.split(':');
      const nextHour = String((parseInt(hours) + 1) % 24).padStart(2, '0');
      const endDateTime = `${newCalDate}T${nextHour}:${minutes}:00`;

      await createCalendarEvent(token, newCalTitle, newCalDesc, startDateTime, endDateTime);
      setCalendarSuccess(`새 일정이 성공적으로 생성되었습니다.`);
      setNewCalTitle('');
      setNewCalDesc('');
      setNewCalDate('');
      await loadUpcomingCalendarEvents();
    } catch (err) {
      console.error(err);
      setCalendarSuccess(`일정 생성 실패: 구글 계정 권한 또는 토큰 만료 상태를 점검하세요.`);
    } finally {
      setIsCreatingEvent(false);
    }
  };

  // Google Calendar One-click Fund Deadline Booking
  const handleScheduleFundReminder = async (fund: PolicyFund) => {
    if (!token) return;
    
    const deadlineStr = fund.applicationDeadline || (fund as any).deadline || '';
    // Default deadline date (tomorrow)
    let dateStr = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    if (deadlineStr) {
      const dateMatch = deadlineStr.match(/(\d{4})[-.](\d{1,2})[-.](\d{1,2})/);
      if (dateMatch) {
         dateStr = `${dateMatch[1]}-${dateMatch[2].padStart(2, '0')}-${dateMatch[3].padStart(2, '0')}`;
      }
    }

    const confirmMsg = `[구글 캘린더 일정 추가] '${fund.title}' (${fund.agency}) 지원 사업 마감 기한을 구글 캘린더 일정으로 추가하시겠습니까?\n\n마감일시: ${dateStr} 14:00 (마감 안내 알림)`;
    const confirmed = window.confirm(confirmMsg);
    if (!confirmed) return;

    setIsCreatingEvent(true);
    setCalendarSuccess(null);
    try {
      const summary = `🕒 [소상공인 정책자금 마감] ${fund.title}`;
      const description = `소상공인 정책자금 마감 일정 기한 리마인더\n지원기관: ${fund.agency}\n이율/기한: ${fund.interestRate} / ${deadlineStr}\n최대한도: ${fund.maxAmount}\n문의처: ${fund.contactInfo || '주관기관 담당부서'}\n\n* BizMatch AI 맞춤형 매칭 서비스를 통해 등록된 알림 일정입니다.`;
      
      const startDateTime = `${dateStr}T14:00:00`;
      const endDateTime = `${dateStr}T15:00:00`;

      await createCalendarEvent(token, summary, description, startDateTime, endDateTime);
      alert(`[${fund.title}] 일정이 구글 캘린더에 성공적으로 추가되었습니다!`);
      await loadUpcomingCalendarEvents();
      
      const element = document.getElementById('workspace-integrations-section');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    } catch (err) {
      console.error(err);
      alert(`상호 연동에 실패했습니다. 권한 진단이 필요합니다.`);
    } finally {
      setIsCreatingEvent(false);
    }
  };

  // Google Drive Archive Routines
  const handleArchiveDrive = async () => {
    if (!token) return;
    setIsArchivingDrive(true);
    try {
      const fileName = `BizMatch_AI_${profile?.businessName || '우리기업'}_분석리포트.txt`;
      const reportText = `
[BizMatch AI 자금 진단 매칭 상세 보고서]
상호명: ${profile?.businessName || '미지정'} (대표자: ${profile?.name || '미지정'})
기업형태 / 업종: ${profile?.businessType} / ${profile?.industry}
종합 적합도 평점: ${result.eligibilityScore} 점

■ AI 경영 분석 제언:
${result.strategicAdvice}

■ 추천 세부 실행 계획:
${result.actionPlan.map((p, i) => `${i+1}. ${p}`).join('\n')}

■ 매칭 완료된 지원 사업 수: ${result.matchedFunds.length} 건
-----------------------------------------------------------
${result.matchedFunds.map((f, idx) => `
[${idx+1}] ${f.title} (${f.agency})
- 한도: ${f.maxAmount} / 이율: ${f.interestRate}
- 비고: ${f.applicationDeadline || (f as any).deadline || ''} (기한)
- 주요 eligibility 기준: ${f.eligibility}
`).join('\n')}
      `;
      const fileId = await saveReportToDrive(token, fileName, reportText);
      setArchiveFileId(fileId);
    } catch (err) {
      console.error(err);
    } finally {
      setIsArchivingDrive(false);
    }
  };

  // Gmail Distribution Routines
  const handleSendGmail = async () => {
    if (!token || !emailTo.trim()) return;
    setIsSendingMail(true);
    setMailSuccess(null);
    try {
      const emailSubject = `[BizMatch AI] ${profile?.businessName || '우리기업'} 맞춤형 정책자금 진단 보고서`;
      const emailHtml = `
        <div style="font-family: 'Pretendard', sans-serif; max-width: 600px; margin: 0 auto; color: #1e293b; line-height: 1.6;">
          <div style="background-color: #0f172a; padding: 30px; border-radius: 20px 20px 0 0; text-align: center; color: white;">
            <h1 style="margin: 0; font-size: 24px; font-weight: 800;">BizMatch <span style="color: #3b82f6;">AI</span></h1>
            <p style="margin: 5px 0 0 0; font-size: 13px; color: #94a3b8;">소상공인 맞춤 지능형 매칭 보고서</p>
          </div>
          <div style="padding: 30px; background-color: white; border: 1px solid #e2e8f0; border-radius: 0 0 20px 20px;">
            <h2 style="font-weight: 900; margin-top: 0; border-bottom: 2px solid #3b82f6; padding-bottom: 10px;">종합 정책 자금 매칭 진단</h2>
            <p style="font-size: 14px; font-weight: bold;">[${profile?.businessName || '우리기업'}]의 진단 등급과 분석 결과입니다.</p>
            
            <div style="background-color: #f8fafc; padding: 20px; border-radius: 12px; margin-bottom: 20px; text-align: center;">
              <span style="font-size: 12px; font-weight: bold; color: #64748b; text-transform: uppercase;">종합 부합도 점수</span>
              <h3 style="font-size: 36px; font-weight: 900; color: #2563eb; margin: 5px 0;">${result.eligibilityScore}점</h3>
            </div>

            <h3 style="font-weight: 800; color: #0d9488;">AI 맞춤 경영 조언</h3>
            <p style="font-size: 13px; background-color: #f0fdfa; padding: 15px; border-radius: 12px; margin-bottom: 20px;">${result?.strategicAdvice || '부합성 기준에 의거하여 추가 요건을 구비하시기 바랍니다.'}</p>

            <h3 style="font-weight: 800; color: #1e293b;">추천 자금 매칭 내역 (${filteredFunds.length}건)</h3>
            <div style="margin-bottom: 20px;">
              ${filteredFunds.slice(0, 10).map(f => `
                <div style="border-bottom: 1px solid #f1f5f9; padding: 10px 0;">
                  <strong style="color: #1e1e1e; font-size: 14px;">${f.title}</strong><br/>
                  <span style="font-size: 11px; font-weight: bold; color: #64748b;">주관: ${f.agency} | 한도: ${f.maxAmount} | 금리: ${f.interestRate}</span>
                </div>
              `).join('')}
            </div>

            <p style="font-size: 11px; color: #94a3b8; text-align: center; margin-top: 30px; border-top: 1px dashed #cbd5e1; padding-top: 15px;">
              본 진단서는 구글 워크스페이스 OAuth 원클릭 연동 서비스를 사용하여 발송되었습니다.
            </p>
          </div>
        </div>
      `;
      await sendGmailReport(token, emailTo, emailSubject, emailHtml);
      setMailSuccess(`${emailTo} 메일함으로 분석 보고서를 발송했습니다.`);
    } catch (err: any) {
      console.error(err);
      setMailSuccess(`발송 오류: 구글 클라우드 권한 승인을 다시 확인해 주십시오.`);
    } finally {
      setIsSendingMail(false);
    }
  };

  const filteredFunds = useMemo(() => {
    let resultFunds = result.matchedFunds.filter(fund => {
      const matchesSearch = 
        fund.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        fund.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        fund.agency.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory = selectedCategory === 'All' || fund.category === selectedCategory;
      const matchesAgency = selectedAgency === 'All' || fund.agency === selectedAgency;

      const fundMaxVal = parseKoreanAmount(fund.maxAmount);
      const matchesAmount = minLoanAmount === 0 || fundMaxVal >= minLoanAmount;

      const fundRateVal = parseInterestRate(fund.interestRate);
      const matchesInterest = maxInterestRate === 10 || fundRateVal <= maxInterestRate;
      
      return matchesSearch && matchesCategory && matchesAgency && matchesAmount && matchesInterest;
    });

    if (sortOption !== 'default') {
      resultFunds = [...resultFunds].sort((a, b) => {
        if (sortOption === 'limit_desc') {
          return parseKoreanAmount(b.maxAmount) - parseKoreanAmount(a.maxAmount);
        } else if (sortOption === 'limit_asc') {
          return parseKoreanAmount(a.maxAmount) - parseKoreanAmount(b.maxAmount);
        } else if (sortOption === 'rate_asc') {
          return parseInterestRate(a.interestRate) - parseInterestRate(b.interestRate);
        } else if (sortOption === 'rate_desc') {
          return parseInterestRate(b.interestRate) - parseInterestRate(a.interestRate);
        } else if (sortOption === 'target_asc') {
          return a.eligibility.localeCompare(b.eligibility);
        } else if (sortOption === 'target_desc') {
          return b.eligibility.localeCompare(a.eligibility);
        }
        return 0;
      });
    }

    return resultFunds;
  }, [result.matchedFunds, searchQuery, selectedCategory, selectedAgency, minLoanAmount, maxInterestRate, sortOption]);

  // Selected funds for comparison modal
  const selectedFundsList = useMemo(() => {
    return result.matchedFunds.filter(f => selectedFundIds.includes(f.id || f.title));
  }, [result.matchedFunds, selectedFundIds]);

  const handleToggleSelectFund = (fund: PolicyFund) => {
    const key = fund.id || fund.title;
    setSelectedFundIds(prev => {
      if (prev.includes(key)) {
        return prev.filter(id => id !== key);
      } else {
        if (prev.length >= 4) {
          alert('비교표에는 한 번에 최대 4개의 정책자금까지 추가할 수 있습니다.');
          return prev;
        }
        return [...prev, key];
      }
    });
  };

  const handleRemoveFundFromCompare = (fundId: string) => {
    setSelectedFundIds(prev => prev.filter(id => id !== fundId));
  };

  const handleClearFundSelection = () => {
    setSelectedFundIds([]);
  };

  const handleQuickCompareTop = (count: number = 3) => {
    const topFunds = (filteredFunds.length > 0 ? filteredFunds : result.matchedFunds).slice(0, count);
    const topIds = topFunds.map(f => f.id || f.title);
    setSelectedFundIds(topIds);
  };

  const chartData = [
    { subject: '성장성', A: result.businessHealth.growthPotential, B: 65, fullMark: 100 },
    { subject: '안정성', A: result.businessHealth.financialStability, B: 72, fullMark: 100 },
    { subject: '신용도', A: result.businessHealth.creditWorthiness, B: 70, fullMark: 100 },
    { subject: '정책적합', A: result.businessHealth.policyFit, B: 55, fullMark: 100 },
    { subject: '혁신성', A: result.businessHealth.innovation, B: 50, fullMark: 100 },
    { subject: '수익률', A: result.businessHealth.expectedProfitMargin, B: 68, fullMark: 100 },
    { subject: '현금흐름', A: result.businessHealth.cashFlowStatus, B: 75, fullMark: 100 },
  ];

  const comparisonChartData = useMemo(() => {
    return filteredFunds.slice(0, 3).map(fund => {
      // 상환 기간 추출 시도 (숫자만, 기본값 5년)
      let repaymentYears = 5;
      if (fund.repaymentPeriod) {
        const match = fund.repaymentPeriod.match(/(\d+)/);
        if (match) repaymentYears = parseInt(match[0], 10);
      } else {
        const match = fund.description.match(/(\d+)년/);
        if (match) repaymentYears = parseInt(match[1], 10);
      }

      return {
        name: fund.title.length > 8 ? fund.title.substring(0, 8) + '...' : fund.title,
        fullTitle: fund.title,
        maxAmount: parseKoreanAmount(fund.maxAmount) / 100000000, // 억원 단위
        interestRate: parseInterestRate(fund.interestRate),
        repaymentPeriod: repaymentYears,
      };
    });
  }, [filteredFunds]);

  const industryLabel = useMemo(() => {
    switch (profile?.industry) {
      case Industry.MANUFACTURING: return '제조업';
      case Industry.IT_SOFTWARE: return 'IT/소프트웨어';
      case Industry.RETAIL: return '도소매업';
      case Industry.SERVICE: return '서비스업';
      case Industry.RESTAURANT: return '음식점업';
      default: return '동일 업종';
    }
  }, [profile?.industry]);

  const businessTypeLabel = useMemo(() => {
    switch (profile?.businessType) {
      case BusinessType.PRE_STARTUP: return '예비창업자';
      case BusinessType.INDIVIDUAL: return '개인사업자';
      case BusinessType.CORPORATION: return '법인사업자';
      default: return '소상공인';
    }
  }, [profile?.businessType]);

  const peerDistributionData = useMemo(() => {
    const isPreStartup = profile?.businessType === BusinessType.PRE_STARTUP;
    const isIT = profile?.industry === Industry.IT_SOFTWARE;
    const isMfg = profile?.industry === Industry.MANUFACTURING;
    const isRestaurant = profile?.industry === Industry.RESTAURANT;
    const isRetail = profile?.industry === Industry.RETAIL;
    const hasHighDebt = ((profile?.debtCardLoan || 0) + (profile?.debt2Tier || 0)) > 0;
    const isLowCredit = (profile?.creditScore || 800) < 750;

    if (isPreStartup) {
      return [
        {
          category: '청년·예비창업 특례자금',
          share: 42,
          avgAmount: 0.5,
          avgRate: 2.3,
          count: '4,620건',
          highlight: true,
          desc: '초기 사업화 자금 및 보증비율 100% 우대로 가장 높은 선호도',
          color: '#4f46e5'
        },
        {
          category: '신용보증재단 창업보증',
          share: 28,
          avgAmount: 0.3,
          avgRate: 3.1,
          count: '3,080건',
          highlight: false,
          desc: '지역신보 매칭을 통한 1금융권 저금리 대출 연계',
          color: '#3b82f6'
        },
        {
          category: '기술혁신·스타트업 패키지',
          share: 18,
          avgAmount: 1.0,
          avgRate: 2.7,
          count: '1,980건',
          highlight: false,
          desc: '기술성 평가 기반의 중진공/기보 고액 창업 패키지',
          color: '#10b981'
        },
        {
          category: '지자체 창업육성 특별펀드',
          share: 12,
          avgAmount: 0.2,
          avgRate: 1.8,
          count: '1,320건',
          highlight: false,
          desc: '지역 내 거주/사업 영위 대상 지자체 이차보전 자금',
          color: '#f59e0b'
        },
      ];
    }

    if (hasHighDebt || isLowCredit) {
      return [
        {
          category: '고금리 대환 특별보증',
          share: 38,
          avgAmount: 0.5,
          avgRate: 4.5,
          count: '4,180건',
          highlight: true,
          desc: '7% 이상 제2금융권·카드론 대출을 4%대 장기 저금리로 전환',
          color: '#4f46e5'
        },
        {
          category: '신용취약 소상공인 직접대출',
          share: 30,
          avgAmount: 0.3,
          avgRate: 3.8,
          count: '3,300건',
          highlight: false,
          desc: '신용점수 839점 이하 대상 소진공 비대면 직접 대출',
          color: '#3b82f6'
        },
        {
          category: '일반경영안정 긴급자금',
          share: 20,
          avgAmount: 0.6,
          avgRate: 3.5,
          count: '2,200건',
          highlight: false,
          desc: '일시적 유동성 애로 해소를 위한 경영안정 운전자금',
          color: '#10b981'
        },
        {
          category: '성실상환·재도전 특별지원',
          share: 12,
          avgAmount: 0.45,
          avgRate: 2.9,
          count: '1,320건',
          highlight: false,
          desc: '채무조정 성실이행 및 재창업 소상공인 재기 지원',
          color: '#f59e0b'
        },
      ];
    }

    if (isMfg) {
      return [
        {
          category: '스마트공장·시설도입자금',
          share: 36,
          avgAmount: 2.5,
          avgRate: 2.6,
          count: '3,960건',
          highlight: true,
          desc: '생산설비 구축 및 공정 자동화용 장기 저리 시설자금',
          color: '#4f46e5'
        },
        {
          category: '중진공 성장유망 운전자금',
          share: 28,
          avgAmount: 1.2,
          avgRate: 3.0,
          count: '3,080건',
          highlight: false,
          desc: '원자재 구매 및 수주 기반 원활한 제품 양산용 자금',
          color: '#3b82f6'
        },
        {
          category: '신용보증기금(KODIT) 특례',
          share: 22,
          avgAmount: 1.5,
          avgRate: 2.8,
          count: '2,420건',
          highlight: false,
          desc: '제조업 특화 담보대체 신용보증서 발급 지원',
          color: '#10b981'
        },
        {
          category: '수출·글로벌 판로개척자금',
          share: 14,
          avgAmount: 0.8,
          avgRate: 3.1,
          count: '1,540건',
          highlight: false,
          desc: '해외 인증 및 전시회 연계 무역금융 특별우대',
          color: '#f59e0b'
        },
      ];
    }

    if (isIT) {
      return [
        {
          category: '혁신성장·R&D 기술자금',
          share: 37,
          avgAmount: 1.5,
          avgRate: 2.7,
          count: '4,070건',
          highlight: true,
          desc: 'SW 개발 및 클라우드 인프라 구축을 위한 기술성 우대자금',
          color: '#4f46e5'
        },
        {
          category: '기술보증기금(KIBO) 벤처보증',
          share: 29,
          avgAmount: 1.0,
          avgRate: 2.9,
          count: '3,190건',
          highlight: false,
          desc: '지식재산권(IP) 및 기술가치 평가 기반 특례보증',
          color: '#3b82f6'
        },
        {
          category: '디지털 전환·비대면 바우처',
          share: 21,
          avgAmount: 0.4,
          avgRate: 2.2,
          count: '2,310건',
          highlight: false,
          desc: 'IT 솔루션 도입 및 플랫폼 확장을 위한 바우처 연계',
          color: '#10b981'
        },
        {
          category: '청년인재 고용연계 특별자금',
          share: 13,
          avgAmount: 0.7,
          avgRate: 2.5,
          count: '1,430건',
          highlight: false,
          desc: '개발자 채용 시 인건비 부담 완화를 위한 이차보전',
          color: '#f59e0b'
        },
      ];
    }

    if (isRestaurant || isRetail) {
      return [
        {
          category: '소진공 일반경영안정자금',
          share: 36,
          avgAmount: 0.6,
          avgRate: 3.3,
          count: '3,960건',
          highlight: true,
          desc: '매장 운영비 및 임차료 등 필수 유동성 공급 최다 선택',
          color: '#4f46e5'
        },
        {
          category: '지역신보 골목상권 특례보증',
          share: 28,
          avgAmount: 0.4,
          avgRate: 3.0,
          count: '3,080건',
          highlight: false,
          desc: '지자체 협약으로 금리 1~2%p 이차보전 지원',
          color: '#3b82f6'
        },
        {
          category: '스마트상점·키오스크 보급',
          share: 20,
          avgAmount: 0.25,
          avgRate: 2.0,
          count: '2,200건',
          highlight: false,
          desc: '테이블오더, 무인결제기기 도입 국비지원 연계',
          color: '#10b981'
        },
        {
          category: '고금리 대환 특별대출',
          share: 16,
          avgAmount: 0.5,
          avgRate: 4.5,
          count: '1,760건',
          highlight: false,
          desc: '기존 고금리 금융비용 절감을 위한 정책 대환',
          color: '#f59e0b'
        },
      ];
    }

    return [
      {
        category: '소상공인 일반경영안정자금',
        share: 35,
        avgAmount: 0.7,
        avgRate: 3.2,
        count: '3,850건',
        highlight: true,
        desc: '업력 및 규모 무관 보편적 유동성 공급으로 가장 높은 활용도',
        color: '#4f46e5'
      },
      {
        category: '지역신용보증재단 특례보증',
        share: 29,
        avgAmount: 0.5,
        avgRate: 2.9,
        count: '3,190건',
        highlight: false,
        desc: '담보력 부족을 보완하는 지자체 연계 1금융권 대출',
        color: '#3b82f6'
      },
      {
        category: '스마트·혁신형 소상공인자금',
        share: 21,
        avgAmount: 0.4,
        avgRate: 2.6,
        count: '2,310건',
        highlight: false,
        desc: '온라인 판로 개척 및 업무 디지털화를 위한 우대자금',
        color: '#10b981'
      },
      {
        category: '고용유지·일자리 창출자금',
        share: 15,
        avgAmount: 0.6,
        avgRate: 2.8,
        count: '1,650건',
        highlight: false,
        desc: '직원 고용 유지 및 신규 채용 시 금리 감면 혜택',
        color: '#f59e0b'
      },
    ];
  }, [profile]);

  const { industryAvgRate, recommendedAvgRate, rateChartData, industryName } = useMemo(() => {
    const industryLabels: Record<string, string> = {
      MANUFACTURING: '제조업',
      IT_SOFTWARE: 'IT/SW',
      RETAIL: '도소매업',
      SERVICE: '서비스업',
      RESTAURANT: '외식업',
      OTHER: '기타'
    };
    
    const industryRates: Record<string, number> = {
      MANUFACTURING: 5.2,
      IT_SOFTWARE: 4.8,
      RETAIL: 6.5,
      SERVICE: 6.0,
      RESTAURANT: 6.8,
      OTHER: 6.0
    };

    const userIndustryStr = profile?.industry || 'OTHER';
    const iName = industryLabels[userIndustryStr] || '해당 업종';
    const iRate = industryRates[userIndustryStr] || 6.0;

    const parseRate = (str: string) => {
      const matches = str.match(/(\d+\.\d+|\d+)/g);
      if (matches && matches.length > 0) {
        return Math.min(...matches.map(Number));
      }
      return null;
    };

    let totalRate = 0;
    let count = 0;
    filteredFunds.forEach(fund => {
      const rateStr = fund.interestRate || '';
      const rate = parseRate(rateStr);
      if (rate !== null && rate > 0) {
        let actualRate = rate;
        if (rateStr.includes('기준') || rateStr.includes('+')) {
          actualRate = 3.5 + rate; // rough estimate of base rate
        }
        totalRate += actualRate;
        count++;
      }
    });

    const recRate = count > 0 ? Number((totalRate / count).toFixed(2)) : 2.5;

    const data = [
      {
        category: `${iName} 일반대출 평균`,
        rate: iRate,
        fill: '#94a3b8'
      },
      {
        category: '추천 정책자금 평균',
        rate: recRate,
        fill: '#3b82f6'
      }
    ];

    return { industryAvgRate: iRate, recommendedAvgRate: recRate, rateChartData: data, industryName: iName };
  }, [profile, filteredFunds]);

  const handleSaveReport = () => {
    setIsPrinting(true);
    setTimeout(() => {
      window.print();
      setIsPrinting(false);
    }, 150);
  };

  return (
    <div className="max-w-5xl mx-auto pb-20 animate-fade-in relative">
      <style>{`
        .print-only { display: none !important; }
        @media print {
          @page { size: A4 portrait; margin: 15mm; }
          body { background: white !important; margin: 0; padding: 0; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          header, footer, .no-print { display: none !important; }
          main { padding: 0 !important; }
          .print-only { display: block !important; }
          .print-flex { display: flex !important; }
          .max-w-5xl { max-width: 100% !important; margin: 0 !important; width: 100% !important; }
          .bg-white { border: 1px solid #e2e8f0 !important; box-shadow: none !important; }
          .bg-slate-50 { background: #f8fafc !important; }
          .rounded-3xl, .rounded-2xl, .rounded-xl { border-radius: 8px !important; }
          .shadow-sm, .shadow-lg, .shadow-xl { box-shadow: none !important; }
          .break-inside-avoid { break-inside: avoid !important; }
          .page-break-before { page-break-before: always !important; }
          .animate-fade-in { animation: none !important; }
          
          /* Hide non-essential dashboard elements for a clean report */
          .dashboard-interactive-header { display: none !important; }
          .report-only-header { display: block !important; margin-bottom: 20px; border-bottom: 2px solid #000; padding-bottom: 10px; }
          
        }
        .report-only-header { display: none; }
      `}</style>

      {/* -------------------------------------------------------------
          Print Only Cover Page (Standardized Report)
         ------------------------------------------------------------- */}
      <div className="print-only flex flex-col items-center justify-center h-[90vh] break-after-page">
        <div className="text-center w-full max-w-3xl mx-auto border-8 border-slate-900 p-16">
          <div className="mb-4 text-xl font-bold text-slate-500 tracking-[0.2em] uppercase">BizMatch AI Report</div>
          <h1 className="text-5xl font-black mb-16 text-slate-900 leading-tight">소상공인 정책자금<br/>분석 리포트</h1>
          
          <table className="w-full text-left border-collapse mt-12 text-lg">
            <tbody>
              <tr>
                <th className="py-5 border-t border-b-2 border-slate-800 w-1/3 font-bold text-slate-600 bg-slate-50 px-4">기업명 (상호)</th>
                <td className="py-5 border-t border-b-2 border-slate-800 font-black text-slate-900 px-4">{profile?.businessName || '미입력'}</td>
              </tr>
              <tr>
                <th className="py-5 border-b border-slate-300 font-bold text-slate-600 bg-slate-50 px-4">대표자명</th>
                <td className="py-5 border-b border-slate-300 font-bold text-slate-900 px-4">{profile?.name || '미입력'}</td>
              </tr>
              <tr>
                <th className="py-5 border-b border-slate-300 font-bold text-slate-600 bg-slate-50 px-4">사업자등록번호</th>
                <td className="py-5 border-b border-slate-300 font-bold text-slate-900 px-4">{profile?.businessRegistrationNumber || '미입력'}</td>
              </tr>
              <tr>
                <th className="py-5 border-b border-slate-300 font-bold text-slate-600 bg-slate-50 px-4">주요 업종</th>
                <td className="py-5 border-b border-slate-300 font-bold text-slate-900 px-4">{profile?.industry || '미입력'}</td>
              </tr>
              <tr>
                <th className="py-5 border-b border-slate-300 font-bold text-slate-600 bg-slate-50 px-4">발급 일자</th>
                <td className="py-5 border-b border-slate-300 font-bold text-slate-900 px-4">{new Date().toLocaleDateString('ko-KR')}</td>
              </tr>
            </tbody>
          </table>
          
          <div className="mt-24 text-slate-500 text-sm leading-relaxed text-left">
            <p>※ 본 리포트는 실시간 정책자금 데이터 및 기업 진단 정보를 바탕으로 AI가 분석하여 자동 생성한 표준화된 보고서입니다.</p>
            <p>※ 대출 및 보증 심사 시 보조 참고 자료로 활용하실 수 있으며, 최종 승인 여부는 각 금융기관의 개별 심사 기준에 따릅니다.</p>
          </div>
        </div>
      </div>

      {/* Applied Feedback Banner (If Re-analysis was triggered) */}
      {appliedFeedback && (
        <div className="mb-6 p-4 sm:p-5 bg-gradient-to-r from-indigo-900 via-slate-900 to-blue-900 text-white rounded-3xl shadow-lg border border-indigo-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 no-print animate-fade-in">
          <div className="flex items-center gap-3.5">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/30 border border-indigo-400/40 text-amber-300 flex items-center justify-center shadow-inner shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs sm:text-sm font-black text-white">
                  대표님의 피드백을 반영하여 재분석된 추천 결과입니다
                </span>
                {appliedFeedback.preferredInterestRateMax && (
                  <span className="text-[10px] font-black px-2 py-0.5 bg-blue-500 text-white rounded-md">
                    최대 금리 {appliedFeedback.preferredInterestRateMax}% 이하
                  </span>
                )}
                {appliedFeedback.preferredFundCategory && appliedFeedback.preferredFundCategory !== 'ALL' && (
                  <span className="text-[10px] font-black px-2 py-0.5 bg-indigo-500 text-white rounded-md">
                    {appliedFeedback.preferredFundCategory}
                  </span>
                )}
                {appliedFeedback.excludedFundIds && appliedFeedback.excludedFundIds.length > 0 && (
                  <span className="text-[10px] font-black px-2 py-0.5 bg-rose-500 text-white rounded-md">
                    제외 자금 {appliedFeedback.excludedFundIds.length}건 교체됨
                  </span>
                )}
              </div>
              <p className="text-xs text-blue-200/90 leading-snug">
                반영 사유: {appliedFeedback.selectedReasons?.join(', ') || '조건 정밀 튜닝'}
                {appliedFeedback.userCustomPrompt && ` • "${appliedFeedback.userCustomPrompt}"`}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsDetailedFeedbackModalOpen(true)}
            className="px-4 py-2 bg-white/15 hover:bg-white/25 text-white font-black text-xs rounded-xl border border-white/20 transition-all flex items-center gap-1.5 shrink-0 cursor-pointer shadow-2xs hover:scale-[1.02] active:scale-[0.98]"
          >
            <Sliders className="w-3.5 h-3.5 text-blue-300" />
            <span>조건 다시 변경하기</span>
          </button>
        </div>
      )}

      {/* Header Profile Section */}
      <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100 mb-8 flex flex-col md:flex-row gap-8 items-center overflow-hidden">
        {profile?.businessPhotoUrl ? (
          <div className="w-full md:w-48 h-48 rounded-2xl overflow-hidden flex-shrink-0 shadow-xl bg-gray-100 border-4 border-white">
            <img 
              src={profile.businessPhotoUrl} 
              alt="Business Photo" 
              className="w-full h-full object-cover"
            />
          </div>
        ) : (
          <div className="w-full md:w-48 h-48 rounded-2xl bg-slate-50 border-2 border-dashed border-gray-200 flex flex-col items-center justify-center text-gray-400 gap-2 flex-shrink-0 no-print">
            <Building2 className="w-10 h-10" />
            <span className="text-xs font-medium">사진 없음</span>
          </div>
        )}
        
        <div className="flex-grow text-center md:text-left">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-4">
            <div>
                <div className="flex items-center gap-2 mb-1 justify-center md:justify-start">
                   <h1 className="text-3xl font-bold text-gray-900 tracking-tight">{profile?.businessName || '사업장'} 진단 리포트</h1>
                   {profile?.isMyDataLinked ? (
                       <span className="px-2 py-0.5 bg-emerald-600 text-white text-[10px] font-bold rounded-full uppercase tracking-wider no-print flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3" /> MyData Verified
                       </span>
                   ) : (
                       <span className="px-2 py-0.5 bg-blue-600 text-white text-[10px] font-bold rounded-full uppercase tracking-wider no-print">AI Verified</span>
                   )}
                </div>
                <div className="flex flex-wrap gap-4 text-sm justify-center md:justify-start mt-2">
                  <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 rounded-full text-slate-700 font-semibold">
                    <User className="w-3.5 h-3.5 text-slate-400" /> {profile?.name || '대표자'}
                  </div>
                  <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 rounded-full text-slate-700 font-semibold">
                    <MapPin className="w-3.5 h-3.5 text-slate-400" /> {profile?.location || '지역'}
                  </div>
                  <div className="flex items-center gap-1.5 px-3 py-1 bg-slate-100 rounded-full text-slate-700 font-semibold">
                    <Building2 className="w-3.5 h-3.5 text-slate-400" /> {profile?.industry || '업종'}
                  </div>
                </div>
            </div>
            <div className="flex flex-wrap gap-2 w-full md:w-auto no-print">
                <button
                  type="button"
                  onClick={() => {
                    setPushModalTarget(null);
                    setIsPushModalOpen(true);
                  }}
                  className="flex-grow md:flex-grow-0 px-3.5 py-2.5 text-sm font-bold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 flex items-center justify-center gap-1.5 transition-all shadow-xs cursor-pointer"
                  title="관심 정책자금 브라우저 푸시 알림 설정"
                >
                  <BellRing className="w-4 h-4 text-indigo-600" />
                  <span>푸시 알림 관리</span>
                </button>
                <button
                  type="button"
                  onClick={() => setIsDetailedFeedbackModalOpen(true)}
                  className="flex-grow md:flex-grow-0 px-4 py-2.5 text-sm font-black text-indigo-700 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200/80 rounded-xl flex items-center justify-center gap-2 transition-all shadow-xs cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
                  title="추천 결과에 대한 상세 피드백을 전달하고 원하는 조건으로 다시 분석합니다"
                >
                  <Sliders className="w-4 h-4 text-indigo-600" />
                  <span>상세 피드백 & AI 재분석</span>
                </button>
                <button onClick={onReset} className="flex-grow md:flex-grow-0 px-4 py-2.5 text-sm font-bold text-slate-600 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 flex items-center justify-center gap-2 transition-all">
                    <RotateCcw className="w-4 h-4" /> 다시 하기
                </button>
                <button
                  onClick={() => setIsShareModalOpen(true)}
                  className="flex-grow md:flex-grow-0 px-4 py-2.5 text-sm font-bold text-slate-700 bg-white border border-slate-200 rounded-xl hover:bg-slate-50 flex items-center justify-center gap-2 shadow-xs transition-all"
                >
                  <Share2 className="w-4 h-4 text-indigo-600" /> <span>공유하기</span>
                </button>
                <button 
                  onClick={handleSaveReport}
                  className="flex-grow md:flex-grow-0 px-6 py-2.5 text-sm font-bold text-white bg-slate-900 rounded-xl hover:bg-slate-800 flex items-center justify-center gap-2 shadow-xl shadow-slate-900/20 transition-all"
                >
                    <Download className="w-4 h-4" /> PDF 리포트 저장
                </button>
            </div>
          </div>
          <p className="text-slate-500 text-sm leading-relaxed max-w-2xl mt-4">
            본 리포트는 실시간 정책자금 공고 데이터를 AI가 분석하여 {profile?.businessName || '귀하의 사업장'}에 최적화된 매칭 결과를 도출한 것입니다.
          </p>
        </div>
      </div>

      {/* Primary View Switcher: Qualification Comparison vs Policy Comparison Dashboard vs Application Guide vs AI Report */}
      {evalResult && profile && (
        <div className="mb-8 bg-slate-100/90 p-1.5 rounded-2xl grid grid-cols-2 lg:grid-cols-4 items-center gap-1.5 border border-slate-200 shadow-xs no-print">
          <button
            type="button"
            onClick={() => setDashboardTab('QUALIFICATION')}
            className={`py-3.5 px-3 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              dashboardTab === 'QUALIFICATION'
                ? 'bg-white text-blue-600 shadow-md ring-1 ring-black/5'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <Sparkles className="w-4 h-4 text-blue-600 shrink-0" />
            <span className="truncate">자격 요건 정밀 비교</span>
            <span className={`px-2 py-0.5 rounded-full text-xs font-black shrink-0 ${
              dashboardTab === 'QUALIFICATION' ? 'bg-blue-100 text-blue-800' : 'bg-slate-200 text-slate-700'
            }`}>
              적격 {evalResult.summary.eligibleCount}건
            </span>
          </button>

          <button
            type="button"
            onClick={() => setDashboardTab('COMPARISON')}
            className={`py-3.5 px-3 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              dashboardTab === 'COMPARISON'
                ? 'bg-white text-purple-600 shadow-md ring-1 ring-black/5'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <BarChart3 className="w-4 h-4 text-purple-600 shrink-0" />
            <span className="truncate">비교 대시보드</span>
            <span className={`px-2 py-0.5 rounded-full text-xs font-black shrink-0 ${
              dashboardTab === 'COMPARISON' ? 'bg-purple-100 text-purple-800' : 'bg-slate-200 text-slate-700'
            }`}>
              차트 요약
            </span>
          </button>

          <button
            type="button"
            onClick={() => setDashboardTab('APPLICATION_GUIDE')}
            className={`py-3.5 px-3 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              dashboardTab === 'APPLICATION_GUIDE'
                ? 'bg-white text-emerald-600 shadow-md ring-1 ring-black/5'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <BookOpen className="w-4 h-4 text-emerald-600 shrink-0" />
            <span className="truncate">신청 가이드·FAQ</span>
            <span className={`px-2 py-0.5 rounded-full text-xs font-black shrink-0 ${
              dashboardTab === 'APPLICATION_GUIDE' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-700'
            }`}>
              필독 가이드
            </span>
          </button>

          <button
            type="button"
            onClick={() => setDashboardTab('AI_REPORT')}
            className={`py-3.5 px-3 rounded-xl font-black text-xs sm:text-sm flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
              dashboardTab === 'AI_REPORT'
                ? 'bg-white text-indigo-600 shadow-md ring-1 ring-black/5'
                : 'text-slate-600 hover:text-slate-900 hover:bg-white/50'
            }`}
          >
            <TrendingUp className="w-4 h-4 text-indigo-600 shrink-0" />
            <span className="truncate">AI 종합 진단</span>
            <span className={`px-2 py-0.5 rounded-full text-xs font-black shrink-0 ${
              dashboardTab === 'AI_REPORT' ? 'bg-indigo-100 text-indigo-800' : 'bg-slate-200 text-slate-700'
            }`}>
              종합 {result.eligibilityScore}점
            </span>
          </button>
        </div>
      )}

      {/* Render Qualification Comparison View */}
      {dashboardTab === 'QUALIFICATION' && evalResult && profile ? (
        <div className="mb-10 animate-fade-in no-print">
          <PolicyQualificationComparisonView
            profile={profile}
            evaluationResult={evalResult}
            onOpenChecklistModal={(title) => {
              const matched = (result.matchedFunds || []).find(f => f.title === title);
              if (matched) setPdfChecklistFund(matched);
            }}
            onNavigateToComparisonDashboard={() => setDashboardTab('COMPARISON')}
          />
        </div>
      ) : null}

      {/* Render Policy Comparison Dashboard View */}
      {dashboardTab === 'COMPARISON' ? (
        <div className="mb-10 animate-fade-in no-print">
          <PolicyComparisonDashboard
            funds={result.matchedFunds || []}
            profile={effectiveProfile}
            onSelectFund={(fund) => {
              const matched = (result.matchedFunds || []).find(f => (f.id || f.title) === (fund.id || fund.title));
              if (matched) {
                setDashboardTab('AI_REPORT');
                setTimeout(() => {
                  const el = document.getElementById(matched.id || matched.title);
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }
            }}
            onOpenApplicationGuide={(fund) => {
              setSelectedGuideFund(fund);
              setDashboardTab('APPLICATION_GUIDE');
            }}
            onOpenDeepLearningReport={handleOpenDeepLearningReport}
            onOpenConsultation={handleOpenConsultation}
            onNavigateToMatch={onReset}
          />
        </div>
      ) : null}

      {/* Render Application Guide View */}
      {dashboardTab === 'APPLICATION_GUIDE' ? (
        <div className="mb-10 animate-fade-in no-print">
          <PolicyApplicationGuideView
            profile={profile}
            matchedFunds={result.matchedFunds}
            onOpenChecklistModal={(title) => {
              const matched = (result.matchedFunds || []).find(f => f.title === title);
              if (matched) setPdfChecklistFund(matched);
            }}
            onNavigateToMatch={onReset}
          />
        </div>
      ) : null}

      {/* AI Detailed Report (Visible when tab is AI_REPORT or during Print) */}
      <div className={dashboardTab !== 'AI_REPORT' ? 'print-only' : 'animate-fade-in'}>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {/* Score Card */}
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex flex-col items-center justify-center text-center break-inside-avoid">
            <h3 className="text-slate-400 text-xs font-black uppercase tracking-widest mb-6">종합 정책 부합도</h3>
            <div className="relative w-48 h-48 flex items-center justify-center -mt-2">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'score', value: result.eligibilityScore },
                        { name: 'remaining', value: 100 - result.eligibilityScore }
                      ]}
                      cx="50%"
                      cy="50%"
                      startAngle={90}
                      endAngle={-270}
                      innerRadius="75%"
                      outerRadius="100%"
                      dataKey="value"
                      stroke="none"
                      isAnimationActive={true}
                    >
                      <Cell fill={result.eligibilityScore >= 80 ? '#10b981' : result.eligibilityScore >= 60 ? '#3b82f6' : '#94a3b8'} />
                      <Cell fill="#f1f5f9" />
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute inset-0 flex items-center justify-center flex-col">
                    <span className="text-5xl font-black text-slate-900">{result.eligibilityScore}</span>
                    <span className="text-xs text-slate-400 font-bold tracking-widest mt-1">/ 100</span>
                </div>
            </div>
            <div className={`mt-6 px-4 py-1.5 rounded-full text-xs font-black uppercase tracking-widest ${
              result.eligibilityScore >= 80 ? 'bg-emerald-100 text-emerald-700' : 
              result.eligibilityScore >= 60 ? 'bg-blue-100 text-blue-700' : 'bg-slate-100 text-slate-700'
            }`}>
                {result.eligibilityScore >= 80 ? 'EXCELLENT' : result.eligibilityScore >= 60 ? 'GOOD' : 'NORMAL'}
            </div>
        </div>

        {/* Radar Chart */}
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 col-span-1 md:col-span-2 break-inside-avoid">
            <h3 className="text-slate-900 font-black text-lg mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-500" />
              사업 핵심 역량 분석
            </h3>
            <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                    <RadarChart cx="50%" cy="50%" outerRadius="70%" data={chartData}>
                        <PolarGrid stroke="#f1f5f9" />
                        <PolarAngleAxis dataKey="subject" tick={{ fill: '#64748b', fontSize: 12, fontWeight: 700 }} />
                        <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
                        <Radar
                            name="내 사업장"
                            dataKey="A"
                            stroke="#3b82f6"
                            strokeWidth={3}
                            fill="#3b82f6"
                            fillOpacity={0.4}
                        />
                        <Radar
                            name="업종 평균 (벤치마크)"
                            dataKey="B"
                            stroke="#cbd5e1"
                            strokeWidth={2}
                            fill="#cbd5e1"
                            fillOpacity={0.2}
                            strokeDasharray="4 4"
                        />
                        <Tooltip 
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                          itemStyle={{ fontWeight: 700 }}
                        />
                        <Legend wrapperStyle={{ fontSize: '12px', fontWeight: 600, paddingTop: '10px' }} />
                    </RadarChart>
                </ResponsiveContainer>
            </div>
        </div>
      </div>

      {result.approvalFactors && result.approvalFactors.length > 0 && (
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 mb-8 break-inside-avoid animate-fade-in">
          <h3 className="text-slate-900 font-black text-lg mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-emerald-500" />
            승인 확률 기여 요인 분석
          </h3>
          <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    layout="vertical"
                    data={result.approvalFactors}
                    margin={{ top: 5, right: 30, left: 10, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                    <XAxis type="number" hide />
                    <YAxis dataKey="factor" type="category" tick={{ fill: '#64748b', fontSize: 13, fontWeight: 700 }} axisLine={false} tickLine={false} width={140} />
                    <Tooltip 
                      cursor={{fill: '#f8fafc'}}
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                      formatter={(value: number) => [value > 0 ? `+${value}` : value, '기여도']}
                    />
                    <Bar dataKey="impact" radius={4} barSize={24}>
                      {
                        result.approvalFactors.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.impact > 0 ? '#10b981' : '#ef4444'} />
                        ))
                      }
                    </Bar>
                  </BarChart>
              </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Similar Business Owners Policy Fund Distribution Analysis */}
      <div className="bg-white p-6 sm:p-8 rounded-3xl shadow-sm border border-gray-100 mb-8 break-inside-avoid animate-fade-in">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6 pb-5 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                <Users className="w-4 h-4" />
              </div>
              <span className="text-[10px] font-black uppercase tracking-wider text-indigo-600 bg-indigo-50/70 px-2.5 py-0.5 rounded-full border border-indigo-100/50">
                유사 프로필 빅데이터 비교
              </span>
            </div>
            <h3 className="text-xl font-black text-slate-900 tracking-tight">
              유사 소상공인 주요 선택 정책자금 유형
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              대표님과 유사한 업종(<span className="font-bold text-slate-700">{industryLabel}</span>) 및 기업형태(<span className="font-bold text-slate-700">{businessTypeLabel}</span>) 소상공인 10,000+ 사업자의 실제 선택 통계
            </p>
          </div>

          {/* Metric Selector Tabs */}
          <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200/70 self-stretch md:self-auto justify-center">
            <button
              type="button"
              onClick={() => setPeerMetric('SHARE')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all ${
                peerMetric === 'SHARE'
                  ? 'bg-white text-indigo-700 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              선택 비율 (%)
            </button>
            <button
              type="button"
              onClick={() => setPeerMetric('AMOUNT')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all ${
                peerMetric === 'AMOUNT'
                  ? 'bg-white text-indigo-700 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              평균 승인 한도
            </button>
            <button
              type="button"
              onClick={() => setPeerMetric('RATE')}
              className={`px-3 py-1.5 rounded-xl text-xs font-black transition-all ${
                peerMetric === 'RATE'
                  ? 'bg-white text-indigo-700 shadow-sm'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              평균 금리
            </button>
          </div>
        </div>

        {/* Dynamic Demographic Summary Chips */}
        <div className="flex flex-wrap items-center gap-2 mb-6 text-xs text-slate-600">
          <span className="text-[11px] font-bold text-slate-400">대조 기준 군:</span>
          <span className="px-2.5 py-1 bg-slate-100 rounded-lg font-bold text-slate-700 border border-slate-200/50">
            업종: {industryLabel}
          </span>
          <span className="px-2.5 py-1 bg-slate-100 rounded-lg font-bold text-slate-700 border border-slate-200/50">
            형태: {businessTypeLabel}
          </span>
          <span className="px-2.5 py-1 bg-slate-100 rounded-lg font-bold text-slate-700 border border-slate-200/50">
            신용도: {profile?.creditScore ? `${profile.creditScore}점대` : '중위 신용'}
          </span>
          <span className="px-2.5 py-1 bg-indigo-50 text-indigo-700 rounded-lg font-bold border border-indigo-100 ml-auto hidden sm:inline-flex items-center gap-1">
            <Sparkles className="w-3 h-3" /> 최다 선택: {peerDistributionData[0]?.category} ({peerDistributionData[0]?.share}%)
          </span>
        </div>

        {/* Recharts Bar Chart */}
        <div className="h-72 w-full mb-6">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              layout="vertical"
              data={peerDistributionData}
              margin={{ top: 5, right: 40, left: 10, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
              <XAxis 
                type="number" 
                tick={{ fill: '#94a3b8', fontSize: 11, fontWeight: 700 }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(val) => `${val}${peerMetric === 'SHARE' ? '%' : peerMetric === 'AMOUNT' ? '억' : '%'}`}
              />
              <YAxis 
                dataKey="category" 
                type="category" 
                tick={{ fill: '#334155', fontSize: 12, fontWeight: 700 }} 
                axisLine={false} 
                tickLine={false} 
                width={170}
              />
              <Tooltip 
                cursor={{ fill: '#f8fafc' }}
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div className="bg-slate-900 text-white p-4 rounded-2xl shadow-xl border border-slate-800 text-xs max-w-xs space-y-2">
                        <div className="flex items-center justify-between gap-2 border-b border-slate-800 pb-2">
                          <span className="font-black text-sm text-white">{data.category}</span>
                          {data.highlight && (
                            <span className="px-2 py-0.5 bg-indigo-500 text-white text-[10px] font-black rounded-full">
                              1위 인기
                            </span>
                          )}
                        </div>
                        <div className="grid grid-cols-3 gap-2 py-1 bg-white/5 p-2 rounded-xl text-center">
                          <div>
                            <span className="text-[10px] text-slate-400 block">선택 비율</span>
                            <span className="font-black text-indigo-400 text-sm">{data.share}%</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-slate-400 block">평균 한도</span>
                            <span className="font-black text-emerald-400 text-sm">{data.avgAmount}억원</span>
                          </div>
                          <div>
                            <span className="text-[10px] text-slate-400 block">평균 금리</span>
                            <span className="font-black text-amber-400 text-sm">{data.avgRate}%</span>
                          </div>
                        </div>
                        <p className="text-[11px] text-slate-300 leading-relaxed font-medium pt-1">
                          💡 {data.desc}
                        </p>
                        <div className="text-[10px] text-slate-400 text-right">
                          누적 신청 표본: {data.count}
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Bar 
                dataKey={peerMetric === 'SHARE' ? 'share' : peerMetric === 'AMOUNT' ? 'avgAmount' : 'avgRate'} 
                radius={[0, 8, 8, 0]} 
                barSize={24}
              >
                {peerDistributionData.map((entry, index) => (
                  <Cell 
                    key={`peer-cell-${index}`} 
                    fill={entry.color || '#3b82f6'} 
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Analytical Insight Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
          {peerDistributionData.map((item, idx) => (
            <div 
              key={idx}
              className={`p-4 rounded-2xl border transition-all ${
                item.highlight 
                  ? 'bg-indigo-50/50 border-indigo-200 shadow-sm' 
                  : 'bg-slate-50 border-slate-100'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
                  item.highlight ? 'bg-indigo-600 text-white' : 'bg-slate-200 text-slate-700'
                }`}>
                  {idx + 1}순위
                </span>
                <span className="text-xs font-black text-slate-900">
                  {item.share}%
                </span>
              </div>
              <h4 className="font-bold text-xs text-slate-900 mb-1 truncate" title={item.category}>
                {item.category}
              </h4>
              <p className="text-[11px] text-slate-500 leading-snug line-clamp-2">
                {item.desc}
              </p>
              <div className="mt-3 pt-2 border-t border-slate-200/50 flex justify-between text-[10px] font-bold text-slate-600">
                <span>평균 {item.avgAmount}억</span>
                <span className="text-indigo-600">연 {item.avgRate}%</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Google Search Grounded Real-Time Policy News & Announcements */}
      <RealtimePolicyNews profile={profile} />

      {/* Similar Industry Success Stories & Case Studies */}
      <SuccessStories 
        profile={profile} 
        onSelectFund={(fundName) => {
          setSearchQuery(fundName);
          const filterElem = document.getElementById('matched-funds-filter-section');
          if (filterElem) {
            filterElem.scrollIntoView({ behavior: 'smooth' });
          }
        }} 
      />

      {/* AI Deep Learning Pattern Matching 5-Tier Approval Probability Diagnosis Hub */}
      {result.matchedFunds && result.matchedFunds.length > 0 && (
        <DeepLearningApprovalHub
          profile={effectiveProfile}
          funds={result.matchedFunds}
          onOpenReport={handleOpenDeepLearningReport}
          onOpenConsultation={handleOpenConsultation}
          onUpdateBonusFactors={(factors) => setDashboardBonusFactors(factors)}
        />
      )}

      {/* 3-Month Policy Fund Supply Trends & Financial Seasonality Analysis */}
      <div className="mb-8 no-print">
        <PolicyFundSeasonalityTrends 
          profile={profile}
          latestPolicies={result.matchedFunds as any}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
            {/* 필터링 섹션 강화 */}
            <div id="matched-funds-filter-section" className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 mb-8 no-print">
              <div className="flex flex-col gap-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <div className="w-1.5 h-6 bg-blue-600 rounded-full"></div>
                    <h2 className="text-xl font-bold text-slate-900">
                      맞춤 추천 자금 <span className="text-blue-600 ml-1">{filteredFunds.length}</span>
                    </h2>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <button 
                      type="button"
                      onClick={() => {
                        setDashboardTab('COMPARISON');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-purple-50 to-indigo-50 hover:from-purple-100 hover:to-indigo-100 border border-purple-200/80 text-purple-700 rounded-xl text-xs font-black transition-all shadow-2xs cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
                      title="금리/한도/승인확률을 차트로 요약 비교하는 전용 대시보드로 이동합니다"
                    >
                      <BarChart3 className="w-3.5 h-3.5 text-purple-600" />
                      <span>📊 한눈에 비교 대시보드</span>
                    </button>
                    <button 
                      type="button"
                      onClick={() => setIsDetailedFeedbackModalOpen(true)}
                      className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 border border-blue-200/80 text-blue-700 rounded-xl text-xs font-black transition-all shadow-2xs cursor-pointer hover:scale-[1.02] active:scale-[0.98]"
                      title="AI 추천 항목 중 금리/업종/한도 등이 부적합한 경우 피드백을 반영하여 다시 분석합니다"
                    >
                      <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                      <span>매칭 불만족? 상세 피드백 및 재분석</span>
                    </button>
                    {isFiltered && (
                      <button 
                        onClick={clearFilters}
                        className="flex items-center gap-2 px-3 py-1.5 text-xs font-bold text-red-500 hover:bg-red-50 rounded-lg transition-colors border border-transparent hover:border-red-100"
                      >
                        <Eraser className="w-3.5 h-3.5" />
                        필터 초기화
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
                  {/* 검색창 */}
                  <div className="md:col-span-12 lg:col-span-4 relative group">
                    <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
                    <input 
                      type="text"
                      placeholder="자금명 검색..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="w-full pl-11 pr-10 py-3 bg-slate-50 border border-slate-100 rounded-2xl text-sm text-slate-900 focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 focus:bg-white transition-all outline-none font-medium"
                    />
                  </div>

                  {/* 기관 필터 */}
                  <div className="md:col-span-6 lg:col-span-2 relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">
                      <Building className={`w-4 h-4 transition-colors ${selectedAgency !== 'All' ? 'text-blue-600' : 'text-slate-400'}`} />
                    </div>
                    <select 
                      value={selectedAgency}
                      onChange={(e) => setSelectedAgency(e.target.value)}
                      className={`w-full pl-11 pr-8 py-3 rounded-2xl text-sm appearance-none outline-none border transition-all font-bold cursor-pointer ${
                        selectedAgency !== 'All' ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-slate-50 border-slate-100 text-slate-600'
                      }`}
                    >
                      {agencies.map(ag => (
                        <option key={ag} value={ag}>{ag === 'All' ? '전체 기관' : ag}</option>
                      ))}
                    </select>
                  </div>

                  {/* 최소 한도 필터 */}
                  <div className="md:col-span-6 lg:col-span-2 relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">
                      <Banknote className={`w-4 h-4 transition-colors ${minLoanAmount !== 0 ? 'text-blue-600' : 'text-slate-400'}`} />
                    </div>
                    <select 
                      value={minLoanAmount}
                      onChange={(e) => setMinLoanAmount(Number(e.target.value))}
                      className={`w-full pl-11 pr-8 py-3 rounded-2xl text-sm appearance-none outline-none border transition-all font-bold cursor-pointer ${
                        minLoanAmount !== 0 ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-slate-50 border-slate-100 text-slate-600'
                      }`}
                    >
                      <option value={0}>최소 한도</option>
                      <option value={30000000}>3천만↑</option>
                      <option value={50000000}>5천만↑</option>
                      <option value={100000000}>1억↑</option>
                      <option value={300000000}>3억↑</option>
                    </select>
                  </div>

                  {/* 최대 금리 필터 */}
                  <div className="md:col-span-6 lg:col-span-2 relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">
                      <Percent className={`w-4 h-4 transition-colors ${maxInterestRate !== 10 ? 'text-blue-600' : 'text-slate-400'}`} />
                    </div>
                    <select 
                      value={maxInterestRate}
                      onChange={(e) => setMaxInterestRate(Number(e.target.value))}
                      className={`w-full pl-11 pr-8 py-3 rounded-2xl text-sm appearance-none outline-none border transition-all font-bold cursor-pointer ${
                        maxInterestRate !== 10 ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-slate-50 border-slate-100 text-slate-600'
                      }`}
                    >
                      <option value={10}>최대 금리</option>
                      <option value={2.0}>2.0%↓</option>
                      <option value={3.0}>3.0%↓</option>
                      <option value={4.0}>4.0%↓</option>
                      <option value={5.0}>5.0%↓</option>
                    </select>
                  </div>

                  {/* 카테고리 필터 */}
                  <div className="md:col-span-6 lg:col-span-2 relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">
                      <Tag className={`w-4 h-4 transition-colors ${selectedCategory !== 'All' ? 'text-blue-600' : 'text-slate-400'}`} />
                    </div>
                    <select 
                      value={selectedCategory}
                      onChange={(e) => setSelectedCategory(e.target.value)}
                      className={`w-full pl-11 pr-8 py-3 rounded-2xl text-sm appearance-none outline-none border transition-all font-bold cursor-pointer ${
                        selectedCategory !== 'All' ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-slate-50 border-slate-100 text-slate-600'
                      }`}
                    >
                      {categories.map(cat => (
                        <option key={cat} value={cat}>{cat === 'All' ? '전체 분야' : cat}</option>
                      ))}
                    </select>
                  </div>

                  {/* 정렬 필터 */}
                  <div className="md:col-span-6 lg:col-span-2 relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">
                      <ArrowUpDown className={`w-4 h-4 transition-colors ${sortOption !== 'default' ? 'text-blue-600' : 'text-slate-400'}`} />
                    </div>
                    <select 
                      value={sortOption}
                      onChange={(e) => setSortOption(e.target.value)}
                      className={`w-full pl-11 pr-8 py-3 rounded-2xl text-sm appearance-none outline-none border transition-all font-bold cursor-pointer ${
                        sortOption !== 'default' ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-slate-50 border-slate-100 text-slate-600'
                      }`}
                    >
                      <option value="default">기본 추천순</option>
                      <option value="rate_asc">금리 낮은순</option>
                      <option value="rate_desc">금리 높은순</option>
                      <option value="limit_desc">한도 높은순</option>
                      <option value="limit_asc">한도 낮은순</option>
                      <option value="target_asc">지원대상 (가나다순)</option>
                      <option value="target_desc">지원대상 (역순)</option>
                    </select>
                  </div>
                </div>
                
                {/* 정책적 가점 (스마트공장, 탄소중립 등) 빠른 토글 바 */}
                <div className="flex items-center gap-2 flex-wrap pt-3 border-t border-slate-100 text-xs">
                  <span className="font-bold text-slate-500 flex items-center gap-1.5 shrink-0">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    정책 가점 즉시 보정:
                  </span>
                  <button
                    type="button"
                    onClick={() => setDashboardBonusFactors(prev => ({ ...prev, hasSmartFactory: !prev.hasSmartFactory }))}
                    className={`px-3 py-1.5 rounded-xl font-bold border transition-all flex items-center gap-1.5 cursor-pointer ${
                      dashboardBonusFactors.hasSmartFactory 
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs' 
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    <span>🏭 스마트공장·공방</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${dashboardBonusFactors.hasSmartFactory ? 'bg-white/20 text-white' : 'bg-blue-100 text-blue-800'}`}>+10~14%p</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setDashboardBonusFactors(prev => ({ ...prev, hasCarbonNeutrality: !prev.hasCarbonNeutrality }))}
                    className={`px-3 py-1.5 rounded-xl font-bold border transition-all flex items-center gap-1.5 cursor-pointer ${
                      dashboardBonusFactors.hasCarbonNeutrality 
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs' 
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    <span>🌿 탄소중립 ESG</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${dashboardBonusFactors.hasCarbonNeutrality ? 'bg-white/20 text-white' : 'bg-emerald-100 text-emerald-800'}`}>+8%p</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setDashboardBonusFactors(prev => ({ ...prev, hasJobCreation: !prev.hasJobCreation }))}
                    className={`px-3 py-1.5 rounded-xl font-bold border transition-all flex items-center gap-1.5 cursor-pointer ${
                      dashboardBonusFactors.hasJobCreation 
                        ? 'bg-purple-600 text-white border-purple-600 shadow-xs' 
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    <span>👥 일자리 창출</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${dashboardBonusFactors.hasJobCreation ? 'bg-white/20 text-white' : 'bg-purple-100 text-purple-800'}`}>+6%p</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setDashboardBonusFactors(prev => ({ ...prev, hasVentureOrInnoBiz: !prev.hasVentureOrInnoBiz }))}
                    className={`px-3 py-1.5 rounded-xl font-bold border transition-all flex items-center gap-1.5 cursor-pointer ${
                      dashboardBonusFactors.hasVentureOrInnoBiz 
                        ? 'bg-amber-600 text-white border-amber-600 shadow-xs' 
                        : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200'
                    }`}
                  >
                    <span>💡 기술혁신·특허</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded ${dashboardBonusFactors.hasVentureOrInnoBiz ? 'bg-white/20 text-white' : 'bg-amber-100 text-amber-800'}`}>+8%p</span>
                  </button>
                </div>

                {/* 선택된 필터 뱃지 표시 */}
                {isFiltered && (
                  <div className="flex flex-wrap gap-2 pt-2 animate-fade-in">
                    {searchQuery && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-slate-100 text-slate-600 rounded-full text-[11px] font-bold border border-slate-200">
                        "{searchQuery}" <X className="w-3 h-3 cursor-pointer" onClick={() => setSearchQuery('')} />
                      </span>
                    )}
                    {selectedAgency !== 'All' && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-[11px] font-bold border border-blue-200">
                        {selectedAgency} <X className="w-3 h-3 cursor-pointer" onClick={() => setSelectedAgency('All')} />
                      </span>
                    )}
                    {minLoanAmount > 0 && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-[11px] font-bold border border-blue-200">
                         {minLoanAmount >= 100000000 ? `${minLoanAmount/100000000}억↑` : `${minLoanAmount/10000}만↑`}
                         <X className="w-3 h-3 cursor-pointer" onClick={() => setMinLoanAmount(0)} />
                      </span>
                    )}
                    {maxInterestRate < 10 && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-[11px] font-bold border border-blue-200">
                         {maxInterestRate}% 이하
                         <X className="w-3 h-3 cursor-pointer" onClick={() => setMaxInterestRate(10)} />
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* 정책자금 비교 차트 */}
            {filteredFunds.length > 0 && (
              <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 mb-8 break-inside-avoid animate-fade-in">
                <h3 className="text-slate-900 font-black text-lg mb-6 flex items-center gap-2">
                  <Banknote className="w-5 h-5 text-blue-500" />
                  상위 추천 자금 핵심 조건 비교 (Top 3)
                </h3>
                <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={comparisonChartData}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 12, fontWeight: 600 }} axisLine={false} tickLine={false} />
                      <YAxis yAxisId="left" orientation="left" stroke="#3b82f6" tick={{ fill: '#64748b', fontSize: 12, fontWeight: 700 }} axisLine={false} tickLine={false} />
                      <YAxis yAxisId="right" orientation="right" stroke="#ef4444" tick={{ fill: '#ef4444', fontSize: 12, fontWeight: 700 }} axisLine={false} tickLine={false} tickFormatter={(value) => `${value}%`} />
                      <Tooltip
                        contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                        itemStyle={{ fontWeight: 700 }}
                        formatter={(value: any, name: string) => {
                          if (name === '한도') return [`${value}억원`, name];
                          if (name === '금리') return [`${value}%`, name];
                          if (name === '상환기간') return [`${value}년`, name];
                          return [value, name];
                        }}
                      />
                      <Legend wrapperStyle={{ fontSize: '12px', fontWeight: 600, color: '#64748b' }} />
                      <Bar yAxisId="left" dataKey="maxAmount" name="한도" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={20} />
                      <Bar yAxisId="right" dataKey="interestRate" name="금리" fill="#ef4444" radius={[4, 4, 0, 0]} barSize={20} />

                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            {/* 정책자금 대출 조건 비교표 (Side-by-Side Comparison Table) */}
            <PolicyFundComparisonTable
              funds={result.matchedFunds}
              selectedFundIds={selectedFundIds}
              onToggleSelectFund={handleToggleSelectFund}
              onClearSelection={handleClearFundSelection}
              onQuickCompareTop={handleQuickCompareTop}
              onOpenConsultation={handleOpenConsultation}
              onOpenPdfChecklist={(fund) => {
                setPdfChecklistFund(fund);
              }}
              onScheduleCalendar={user && token ? handleScheduleFundReminder : undefined}
              onToggleFavorite={onToggleFavorite}
              favorites={favorites}
              profile={profile}
              onOpenFullComparisonDashboard={() => {
                setDashboardTab('COMPARISON');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            />

            {/* Realtime Favorite Policy Changes & Urgent Deadline Summary */}
            {favorites && favorites.length > 0 && (
              <FavoritePolicyChangesSummary
                favorites={favorites}
                onOpenConsultation={handleOpenConsultation}
                onOpenPdfChecklist={(fund) => {
                  setPdfChecklistFund(fund);
                }}
                onScheduleCalendar={user && token ? handleScheduleFundReminder : undefined}
                onSelectFund={(fund) => {
                  const el = document.getElementById(fund.id || fund.title);
                  if (el) {
                    el.scrollIntoView({ behavior: 'smooth' });
                  }
                }}
              />
            )}

            <div className="grid grid-cols-1 gap-6">
                {filteredFunds.length > 0 ? (
                    filteredFunds.map((fund, idx) => {
                      const isFav = (favorites || []).some(item => {
                        const name = 'title' in item ? item.title : item.name;
                        return name === fund.title;
                      });
                      const isSelected = selectedFundIds.includes(fund.id || fund.title);
                      return (
                        <motion.div
                          key={fund.id || idx}
                          layout="position"
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ 
                            layout: { duration: 0.35, ease: [0.16, 1, 0.3, 1] },
                            duration: 0.5, 
                            delay: idx * 0.05, 
                            ease: 'easeOut' 
                          }}
                        >
                          <FundCard 
                            fund={fund} 
                            index={idx} 
                            isPrinting={false} 
                            onOpenApplicationGuide={setSelectedGuideFund}
                            onScheduleCalendar={user && token ? handleScheduleFundReminder : undefined} 
                            isFavorite={isFav}
                            onToggleFavorite={onToggleFavorite}
                            isSelected={isSelected}
                            onToggleSelect={handleToggleSelectFund}
                            onOpenPdfChecklist={setPdfChecklistFund}
                            onConfigurePush={(f) => {
                              setPushModalTarget(f);
                              setIsPushModalOpen(true);
                            }}
                            onOpenConsultation={handleOpenConsultation}
                            onOpenDeepLearningReport={handleOpenDeepLearningReport}
                            onOpenFormsModal={(f) => {
                              setFormsModalTarget(f);
                              setIsFormsModalOpen(true);
                            }}
                            profile={effectiveProfile}
                          />
                        </motion.div>
                      );
                    })
                ) : (
                    <div className="bg-white rounded-3xl p-16 text-center border-2 border-dashed border-slate-200 no-print">
                      <Search className="w-10 h-10 text-slate-300 mx-auto mb-4" />
                      <h3 className="text-xl font-bold text-slate-900 mb-2">조건에 맞는 결과가 없습니다</h3>
                      <p className="text-slate-500 text-sm mb-6">필터 설정을 변경하여 더 많은 자금을 확인해보세요.</p>
                      <button 
                        onClick={clearFilters}
                        className="px-6 py-2.5 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 transition-all flex items-center gap-2 mx-auto"
                      >
                        <RotateCcw className="w-4 h-4" /> 모든 필터 초기화
                      </button>
                    </div>
                )}
            </div>
        </div>

        {/* 우측 전략 코멘트 및 분석 차트 */}
        <div className="space-y-6">
            {/* 금리 절감 효과 비교 차트 */}
            <div className="bg-white border border-slate-200 rounded-3xl shadow-sm p-6 no-print">
              <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                  <span className="font-black text-sm">%</span>
                </div>
                업종 평균 대비 금리 절감 효과
              </h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={rateChartData} margin={{ top: 20, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis 
                      dataKey="category" 
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: '#64748b', fontSize: 11, fontWeight: 700 }}
                      dy={10}
                    />
                    <YAxis 
                      axisLine={false}
                      tickLine={false}
                      tick={{ fill: '#94a3b8', fontSize: 10 }}
                      tickFormatter={(value) => `${value}%`}
                    />
                    <Tooltip 
                      cursor={{ fill: 'transparent' }}
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          return (
                            <div className="bg-white p-3 border border-slate-100 shadow-xl rounded-xl">
                              <p className="text-[11px] font-bold text-slate-500 mb-1">{payload[0].payload.category}</p>
                              <p className="text-base font-black text-blue-600">연 {payload[0].value}%</p>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Bar 
                      dataKey="rate" 
                      radius={[6, 6, 0, 0]} 
                      barSize={36}
                      label={{ position: 'top', fill: '#0f172a', fontSize: 12, fontWeight: 700, formatter: (val) => `${val}%` }}
                    >
                      {rateChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="mt-2 pt-4 border-t border-slate-100">
                <p className="text-[11px] text-slate-500 leading-relaxed text-center font-medium">
                  {industryName} 평균 대출 금리 대비
                  <br />
                  <span className="font-black text-blue-600 mx-1 text-sm">
                    연 {(industryAvgRate - recommendedAvgRate).toFixed(2)}%p
                  </span> 
                  절감이 예상됩니다.
                </p>
              </div>
            </div>

            <div className="bg-slate-900 text-white p-8 rounded-3xl shadow-2xl break-inside-avoid">
                <h3 className="text-lg font-black mb-6 flex items-center gap-2 text-blue-400">
                    <TrendingUp className="w-5 h-5" />
                    AI 전략 코멘트
                </h3>
                <p className="text-slate-300 text-sm leading-relaxed whitespace-pre-line font-medium">
                    {result.strategicAdvice}
                </p>
            </div>

            <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 break-inside-avoid">
                <h3 className="text-lg font-black mb-6 text-slate-900 flex items-center gap-2">
                  <ArrowRightCircle className="w-5 h-5 text-blue-500" />
                  향후 실행 계획
                </h3>
                <ul className="space-y-4">
                    {result.actionPlan.map((plan, idx) => (
                        <li key={idx} className="flex items-start gap-4 text-sm text-slate-600 group">
                            <span className="flex-shrink-0 w-8 h-8 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center font-black text-xs group-hover:bg-blue-600 group-hover:text-white transition-all">
                                {idx + 1}
                            </span>
                            <span className="mt-1.5 font-semibold group-hover:text-slate-900 transition-colors">{plan}</span>
                        </li>
                    ))}
                </ul>
            </div>

            {/* AI 매칭 정확도 & 리포트 유용성 피드백 카드 */}
            <div className="bg-gradient-to-br from-indigo-900 via-slate-900 to-slate-950 text-white p-6 rounded-3xl shadow-xl border border-indigo-500/20 no-print">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[10px] font-black uppercase tracking-widest text-indigo-400 bg-indigo-950/80 px-2.5 py-1 rounded-full border border-indigo-700/40">
                    AI Accuracy Feedback
                  </span>
                  {reportFeedback.submitted && (
                    <span className="text-[11px] font-bold text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> 피드백 저장됨
                    </span>
                  )}
                </div>

                <h4 className="text-base font-black text-white mb-1.5 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-indigo-400" />
                  이 분석 결과가 도움이 되셨나요?
                </h4>
                <p className="text-slate-300 text-xs leading-relaxed mb-4">
                  소상공인 대표님의 소중한 피드백은 AI 정책자금 매칭 엔진의 알고리즘 정밀도를 향상시키는 데 직접 활용됩니다.
                </p>

                {reportFeedback.submitted ? (
                  <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10 space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs font-bold text-slate-200">
                        {reportFeedback.helpful ? (
                          <span className="flex items-center gap-1 text-emerald-400">
                            <ThumbsUp className="w-3.5 h-3.5" /> 만족스러운 결과
                          </span>
                        ) : (
                          <span className="flex items-center gap-1 text-rose-400">
                            <ThumbsDown className="w-3.5 h-3.5" /> 개선이 필요한 결과
                          </span>
                        )}
                        <span className="text-amber-400 ml-1">★ {reportFeedback.rating || 5}/5</span>
                      </div>
                      <button
                        type="button"
                        onClick={handleResetReportFeedback}
                        className="text-[10px] text-slate-400 hover:text-slate-200 underline"
                      >
                        다시 평가
                      </button>
                    </div>
                    {reportFeedback.reason && (
                      <p className="text-[11px] text-indigo-200 bg-indigo-950/40 px-2.5 py-1 rounded-lg">
                        {reportFeedback.reason}
                      </p>
                    )}
                    {reportFeedback.comment && (
                      <p className="text-xs text-slate-300 italic pt-1">
                        "{reportFeedback.comment}"
                      </p>
                    )}
                    <div className="pt-2 border-t border-white/10 flex justify-end">
                      <button
                        type="button"
                        onClick={() => setIsDetailedFeedbackModalOpen(true)}
                        className="px-3 py-1.5 bg-indigo-500/30 hover:bg-indigo-500/50 text-indigo-200 border border-indigo-400/30 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        <Sliders className="w-3.5 h-3.5" />
                        <span>조건 변경 및 AI 재분석</span>
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => handleReportHelpful(true)}
                        className="flex items-center justify-center gap-2 py-2.5 px-3 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 rounded-xl text-xs font-bold transition-all hover:scale-[1.02] active:scale-[0.98]"
                      >
                        <ThumbsUp className="w-4 h-4" />
                        <span>매우 유익해요</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleReportHelpful(false)}
                        className="flex items-center justify-center gap-2 py-2.5 px-3 bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 rounded-xl text-xs font-bold transition-all hover:scale-[1.02] active:scale-[0.98]"
                      >
                        <ThumbsDown className="w-4 h-4" />
                        <span>보완이 필요해요</span>
                      </button>
                    </div>

                    <div className="pt-1">
                      <button
                        type="button"
                        onClick={() => setIsDetailedFeedbackModalOpen(true)}
                        className="w-full py-2.5 px-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-xl text-xs font-black transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-900/40 cursor-pointer"
                      >
                        <Sliders className="w-3.5 h-3.5" />
                        <span>상세 피드백 보내기 & AI 맞춤 재분석 ⚡</span>
                      </button>
                    </div>

                    {showReportFeedbackModal && (
                      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-4 border border-white/10 space-y-3 animate-fade-in">
                        <div className="flex items-center justify-between text-xs font-bold text-slate-200">
                          <span>별점 평가</span>
                          <div className="flex gap-1">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <button
                                key={star}
                                type="button"
                                onClick={() => setReportRating(star)}
                                className={`text-sm transition-transform hover:scale-125 ${
                                  (reportRating || 0) >= star ? 'text-amber-400' : 'text-slate-600'
                                }`}
                              >
                                ★
                              </button>
                            ))}
                          </div>
                        </div>

                        <input
                          type="text"
                          placeholder="어떤 점이 좋았거나 아쉬웠나요? (선택)"
                          value={reportComment}
                          onChange={(e) => setReportComment(e.target.value)}
                          className="w-full px-3 py-2 text-xs bg-slate-950/60 border border-slate-700 text-white rounded-xl outline-none focus:border-indigo-400 placeholder:text-slate-500"
                        />

                        <div className="flex justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => setShowReportFeedbackModal(false)}
                            className="px-3 py-1.5 text-xs text-slate-400 hover:text-white"
                          >
                            닫기
                          </button>
                          <button
                            type="button"
                            onClick={handleSaveReportFeedback}
                            className="px-4 py-1.5 text-xs font-black text-slate-900 bg-indigo-300 hover:bg-indigo-200 rounded-xl transition-colors"
                          >
                            피드백 제출
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
            </div>
        </div>
      </div>

      {/* -------------------------------------------------------------
          Google Workspace Integrations Dashboard
         ------------------------------------------------------------- */}
      <div className="no-print border-t border-slate-200 mt-12 pt-12" id="workspace-integrations-section">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <div>
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-600 block mb-1">Google Workspace Cloud Core</span>
            <h2 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              구글 워크스페이스 & BizKeep 통합 데스크
            </h2>
          </div>
          {!user && (
            <span className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-1.5 rounded-full">
              ⚠️ 클라우드 연동 전 (상단 로그인 필요)
            </span>
          )}
        </div>

        {!user ? (
          <div className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl p-16 text-center">
            <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 text-2xl font-bold">
              ▲
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">구글 워크스페이스 클라우드 연동 활성화</h3>
            <p className="text-slate-500 text-sm max-w-lg mx-auto mb-6 leading-relaxed">
              상단의 [Google 연동] 버튼을 눌러 계정을 인증하면 매칭 결과를 구글 시트/슬라이드로 내보내고, Gmail로 분석 리포트를 송신하며, 소상공인 BizKeep 노트를 활용할 수 있습니다.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            {/* 1. Workspace Exports & Gmail Inbox panel */}
            <div className="space-y-6">
              <div className="bg-white border border-slate-200 shadow-sm rounded-3xl p-6 flex flex-col gap-6">
                <h3 className="font-black text-base text-slate-950 flex items-center gap-2 pb-4 border-b border-slate-100">
                  <span className="text-blue-650">✉</span> 원클릭 스마트 클라우드 내보내기
                </h3>
                
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-7 gap-3">
                  {/* Google Forms Creator */}
                  <div className="flex flex-col">
                    <button
                      type="button"
                      onClick={() => {
                        setFormsModalTarget(result.matchedFunds?.[0] || null);
                        setIsFormsModalOpen(true);
                      }}
                      className="w-full py-3 px-3 bg-purple-50 hover:bg-purple-100 text-purple-700 rounded-2xl font-black text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs hover:shadow"
                    >
                      <ClipboardCheck className="w-4 h-4 text-purple-600" />
                      설문·진단표
                    </button>
                    <span className="text-[10px] font-bold text-center text-purple-600 mt-2">
                      Forms 생성 ↗
                    </span>
                  </div>

                  {/* Sheets Export */}
                  <div className="flex flex-col">
                    <button
                      type="button"
                      onClick={handleSheetExport}
                      disabled={isExportingSheet}
                      className="w-full py-3 px-4 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-2xl font-black text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      {isExportingSheet ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileSpreadsheet className="w-4 h-4" />}
                      시트 생성
                    </button>
                    {sheetUrl && (
                      <a 
                        href={sheetUrl} 
                        target="_blank" 
                        rel="noreferrer"
                        className="text-[10px] font-bold text-center text-emerald-600 mt-2 underline"
                      >
                        시트 즉시 열기 ↗
                      </a>
                    )}
                  </div>

                  {/* Slides Export */}
                  <div className="flex flex-col">
                    <button
                      type="button"
                      onClick={handleSlideExport}
                      disabled={isExportingSlide}
                      className="w-full py-3 px-4 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-2xl font-black text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      {isExportingSlide ? <Loader2 className="w-4 h-4 animate-spin" /> : <Presentation className="w-4 h-4" />}
                      슬라이드 제작
                    </button>
                    {slideUrl && (
                      <a 
                        href={slideUrl} 
                        target="_blank" 
                        rel="noreferrer"
                        className="text-[10px] font-bold text-center text-amber-600 mt-2 underline"
                      >
                        발표 자료 열기 ↗
                      </a>
                    )}
                  </div>

                  {/* Docs Export */}
                  <div className="flex flex-col">
                    <button
                      type="button"
                      onClick={handleDocExport}
                      disabled={isExportingDoc}
                      className="w-full py-3 px-4 bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-2xl font-black text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      {isExportingDoc ? <Loader2 className="w-4 h-4 animate-spin" /> : <FileText className="w-4 h-4" />}
                      문서 제작
                    </button>
                    {docUrl && (
                      <a 
                        href={docUrl} 
                        target="_blank" 
                        rel="noreferrer"
                        className="text-[10px] font-bold text-center text-blue-600 mt-2 underline"
                      >
                        보고서 열기 ↗
                      </a>
                    )}
                  </div>

                  {/* Drive Archive */}
                  <div className="flex flex-col">
                    <button
                      type="button"
                      onClick={handleArchiveDrive}
                      disabled={isArchivingDrive}
                      className="w-full py-3 px-4 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-2xl font-black text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
                    >
                      {isArchivingDrive ? <Loader2 className="w-4 h-4 animate-spin" /> : <Download className="w-4 h-4" />}
                      드라이브 저장
                    </button>
                    {archiveFileId && (
                      <span className="text-[9px] font-bold text-center text-indigo-600 mt-2">
                        성공 (ID: {archiveFileId.substring(0,6)}...)
                      </span>
                    )}
                  </div>

                  {/* Google Contacts (People API) */}
                  <div className="flex flex-col">
                    <button
                      type="button"
                      onClick={() => setIsContactsModalOpen(true)}
                      className="w-full py-3 px-3 bg-cyan-50 hover:bg-cyan-100 text-cyan-800 rounded-2xl font-black text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs hover:shadow"
                    >
                      <Users className="w-4 h-4 text-cyan-600" />
                      연락처·자문단
                    </button>
                    <span className="text-[10px] font-bold text-center text-cyan-700 mt-2">
                      Contacts 연동 ↗
                    </span>
                  </div>

                  {/* Google Tasks API */}
                  <div className="flex flex-col">
                    <button
                      type="button"
                      onClick={() => {
                        setTasksModalTarget(result.matchedFunds?.[0] || null);
                        setIsTasksModalOpen(true);
                      }}
                      className="w-full py-3 px-3 bg-rose-50 hover:bg-rose-100 text-rose-800 rounded-2xl font-black text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer shadow-xs hover:shadow"
                    >
                      <CheckSquare className="w-4 h-4 text-rose-600" />
                      할 일·Tasks
                    </button>
                    <span className="text-[10px] font-bold text-center text-rose-700 mt-2">
                      Tasks 연동 ↗
                    </span>
                  </div>
                </div>

                {/* Gmail Delivering form */}
                <div className="pt-4 border-t border-slate-100">
                  <div className="flex items-center justify-between mb-2">
                    <label className="text-xs font-black text-slate-500">Gmail로 상호 진단 분석 발송</label>
                    <button
                      type="button"
                      onClick={() => setIsContactsModalOpen(true)}
                      className="text-[11px] font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 hover:underline cursor-pointer"
                    >
                      <Users className="w-3.5 h-3.5" />
                      <span>Google 연락처에서 선택</span>
                    </button>
                  </div>
                  <div className="flex gap-2">
                    <input 
                      type="email" 
                      placeholder="수신 이메일 주소" 
                      value={emailTo} 
                      onChange={(e) => setEmailTo(e.target.value)}
                      className="flex-grow px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all"
                    />
                    <button
                      type="button"
                      onClick={handleSendGmail}
                      disabled={isSendingMail || !emailTo}
                      className="px-5 bg-slate-900 text-white rounded-xl text-xs font-black flex items-center gap-2 hover:bg-slate-800 transition-all"
                    >
                      {isSendingMail ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                      발송
                    </button>
                  </div>
                  {mailSuccess && (
                    <div className="mt-2 text-[10px] font-black text-emerald-600 bg-emerald-50 py-1 px-3 rounded-lg">
                      {mailSuccess}
                    </div>
                  )}
                </div>
              </div>

              {/* Sync Inbox Emails */}
              <div className="bg-white border border-slate-200 shadow-sm rounded-3xl p-6 flex flex-col gap-4">
                <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                  <h3 className="font-black text-sm text-slate-950 flex items-center gap-2">
                     ✉ 실시간 소상공인 정책 지원 이메일 인박스
                  </h3>
                  <button 
                    type="button"
                    onClick={loadInboxFunding} 
                    disabled={isSyncingMails}
                    className="text-[10px] font-black text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full hover:bg-blue-100 transition-colors"
                  >
                    {isSyncingMails ? '동기화 중...' : '메일 갱신'}
                  </button>
                </div>

                {isSyncingMails ? (
                  <div className="py-6 text-center text-xs text-slate-400 font-bold flex flex-col items-center gap-2">
                    <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                    지정 메일함의 정책 자금 메일 필터링 중...
                  </div>
                ) : emailSyncError ? (
                  <div className="py-6 text-center text-xs text-red-500 font-bold">
                    메일 보관함을 동기화하지 못했습니다. OAuth 권한을 진단하세요.
                  </div>
                ) : fundingEmails.length === 0 ? (
                  <div className="py-6 text-center text-xs text-slate-400 font-bold">
                    메일함에 정책자금 관련 최신 메일이 없습니다.
                  </div>
                ) : (
                  <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1">
                    {fundingEmails.map((e) => (
                      <div key={e.id} className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex flex-col gap-1.5">
                        <div className="flex justify-between items-center">
                          <span className="text-[10px] font-black text-indigo-600 truncate max-w-[130px]" title={e.sender}>{e.sender.split('<')[0]}</span>
                          <span className="text-[9px] font-bold text-slate-400">{e.date}</span>
                        </div>
                        <h4 className="font-extrabold text-[11px] text-slate-900 truncate leading-snug">{e.subject}</h4>
                        <p className="text-[10px] text-slate-500 truncate leading-relaxed font-medium">{e.snippet}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Sync Upcoming Google Calendars & Quick Event Booker */}
              <div className="bg-white border border-slate-200 shadow-sm rounded-3xl p-6 flex flex-col gap-5">
                <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                  <h3 className="font-indigo-900 font-black text-sm text-slate-950 flex items-center gap-2">
                     📅 실시간 구글 캘린더 일정 관리 데스크
                  </h3>
                  <button 
                    type="button"
                    onClick={loadUpcomingCalendarEvents} 
                    disabled={isSyncingCalendar}
                    className="text-[10px] font-black text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full hover:bg-indigo-100 transition-colors cursor-pointer"
                  >
                    {isSyncingCalendar ? '동기화 중...' : '일정 갱신'}
                  </button>
                </div>

                {/* Quick Add Event Form */}
                <form onSubmit={handleCreateManualCalendarEvent} className="bg-slate-50 p-4 rounded-2xl border border-slate-100 flex flex-col gap-3">
                  <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block mb-1">컨설팅 / 신청 일정 직접 추가</span>
                  <input 
                    type="text" 
                    placeholder="일정 제목 (예: 소진공 담당 컨설턴트 미팅)" 
                    value={newCalTitle}
                    onChange={(e) => setNewCalTitle(e.target.value)}
                    className="px-3.5 py-2 bg-white border border-slate-200 rounded-xl font-bold text-xs focus:outline-none focus:ring-1 focus:ring-blue-600 text-slate-800"
                    required
                  />
                  <input 
                    type="text" 
                    placeholder="메모/내용 (예: 구비서류 지참 필수, 3시 예약)" 
                    value={newCalDesc}
                    onChange={(e) => setNewCalDesc(e.target.value)}
                    className="px-3.5 py-2 bg-white border border-slate-200 rounded-xl font-bold text-xs focus:outline-none focus:ring-1 focus:ring-blue-600 text-slate-800"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input 
                      type="date" 
                      value={newCalDate}
                      onChange={(e) => setNewCalDate(e.target.value)}
                      className="px-3.5 py-2 bg-white border border-slate-200 rounded-xl font-bold text-xs focus:outline-none focus:ring-1 focus:ring-blue-600 text-slate-800"
                      required
                    />
                    <input 
                      type="time" 
                      value={newCalTime}
                      onChange={(e) => setNewCalTime(e.target.value)}
                      className="px-3.5 py-2 bg-white border border-slate-200 rounded-xl font-bold text-xs focus:outline-none focus:ring-1 focus:ring-blue-600 text-slate-800"
                      required
                    />
                  </div>
                  
                  <button
                    type="submit"
                    disabled={isCreatingEvent || !newCalTitle.trim() || !newCalDate}
                    className="w-full py-2 bg-slate-900 text-white font-black text-xs rounded-xl hover:bg-slate-800 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {isCreatingEvent ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />}
                    일정 구글 캘린더에 추가하기
                  </button>

                  {calendarSuccess && (
                    <div className="mt-1 text-[10px] font-black text-emerald-600 bg-emerald-50 py-1.5 px-3 rounded-lg text-center">
                      {calendarSuccess}
                    </div>
                  )}
                </form>

                {/* Upcoming List View */}
                <div>
                  <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block mb-2">내 향후 캘린더 일정 목록</span>
                  {isSyncingCalendar ? (
                    <div className="py-6 text-center text-xs text-slate-400 font-bold flex flex-col items-center gap-2 bg-slate-50 rounded-2xl">
                      <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                      구글 캘린더 일정을 실시간 조회 중...
                    </div>
                  ) : calendarSyncError ? (
                    <div className="py-6 text-center text-xs text-red-500 font-bold bg-red-50/50 rounded-2xl p-4">
                      구글 캘린더를 연동하여 일정을 로드하지 못했습니다. 토큰이나 권한을 갱신하세요.
                    </div>
                  ) : calendarEvents.length === 0 ? (
                    <div className="py-6 text-center text-xs text-slate-400 font-bold bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                      구글 캘린더에 예정된 자금 신청 및 주요 일정이 없습니다.
                    </div>
                  ) : (
                    <div className="space-y-2.5 max-h-[220px] overflow-y-auto pr-1">
                      {calendarEvents.map((evt) => {
                        const dateVal = evt.start.dateTime || evt.start.date || '';
                        const formattedDate = dateVal 
                          ? new Date(dateVal).toLocaleDateString('ko-KR', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) 
                          : '일정 확인 불가';
                        return (
                          <div key={evt.id} className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex flex-col gap-1">
                            <div className="flex justify-between items-center">
                              <span className="text-[9px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">Schedule</span>
                              <span className="text-[9px] font-extrabold text-slate-400">{formattedDate}</span>
                            </div>
                            <h4 className="font-extrabold text-[11px] text-slate-900 truncate leading-snug">{evt.summary}</h4>
                            {evt.description && (
                              <p className="text-[10px] text-slate-500 truncate leading-relaxed font-semibold">{evt.description}</p>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* 2. BizKeep Note dashboard (Firestore) */}
            <div className="bg-white border border-slate-200 shadow-sm rounded-3xl p-6 flex flex-col gap-6">
              <div className="pb-4 border-b border-slate-100">
                <h3 className="font-black text-base text-slate-950 flex items-center gap-2">
                   📑 BizKeep - 자금 신청 관리 메모판
                </h3>
                <p className="text-[10px] font-bold text-slate-400 mt-1">Firestore 실시간 클라우드 DB에 동기화되는 맞춤형 킵 메모 보드</p>
              </div>

              {/* Create Keep Note Form */}
              <form onSubmit={handleCreateNote} className="bg-slate-50 p-4 rounded-2xl border border-slate-100 flex flex-col gap-3">
                <input 
                  type="text" 
                  placeholder="메모 제목 (예: 소진공 구비 서류 목록)" 
                  value={newNoteTitle}
                  onChange={(e) => setNewNoteTitle(e.target.value)}
                  className="px-3.5 py-2 bg-white border border-slate-200 rounded-xl font-bold text-xs focus:outline-none focus:ring-1 focus:ring-blue-600 text-slate-800"
                />
                <textarea 
                  placeholder="세부적인 실행 계획이나 체크리스트 메모를 작성하세요..." 
                  value={newNoteContent}
                  onChange={(e) => setNewNoteContent(e.target.value)}
                  className="px-3.5 py-2 bg-white border border-slate-200 rounded-xl font-bold text-xs focus:outline-none focus:ring-1 focus:ring-blue-600 h-16 resize-none text-slate-800"
                />
                <div className="flex justify-between items-center">
                  <div className="flex gap-1.5">
                    {[
                      { class: 'bg-yellow-50 border-yellow-200', text: '일반' },
                      { class: 'bg-emerald-50 border-emerald-200', text: '준비물' },
                      { class: 'bg-blue-50 border-blue-200', text: '기한' }
                    ].map(col => (
                      <button
                        type="button"
                        key={col.class}
                        onClick={() => setNewNoteColor(col.class)}
                        className={`px-2.5 py-1 text-[9px] font-black border rounded-lg transition-all ${
                          newNoteColor === col.class 
                            ? 'ring-2 ring-indigo-500 border-indigo-500 scale-105' 
                            : 'opacity-70'
                        }`}
                      >
                        {col.text}
                      </button>
                    ))}
                  </div>
                  <button
                    type="submit"
                    disabled={isCreatingNote || !newNoteTitle.trim() || !newNoteContent.trim()}
                    className="px-4 py-1.5 bg-slate-900 text-white font-black text-xs rounded-xl hover:bg-slate-800 transition-all flex items-center gap-1.5"
                  >
                    {isCreatingNote ? <Loader2 className="w-3" /> : <Plus className="w-3 h-3" />}
                    추가
                  </button>
                </div>
              </form>

              {/* Notes display */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[280px] overflow-y-auto pr-1">
                {notes.length === 0 ? (
                  <div className="col-span-2 text-center py-12 text-slate-400 text-xs font-bold leading-relaxed">
                    등록된 자금 신청 메모가 없습니다.<br/>위에서 첫 번째 BizKeep 메모를 남겨보세요!
                  </div>
                ) : (
                  notes.map((note) => (
                    <div 
                      key={note.id} 
                      className={`p-4 rounded-2xl border transition-all relative flex flex-col justify-between group ${note.color} ${note.isPinned ? 'ring-2 ring-indigo-500 border-indigo-200' : 'border-slate-100'}`}
                    >
                      <div>
                        <div className="flex justify-between items-start gap-2 mb-1">
                          <h4 className="font-extrabold text-xs text-slate-950 truncate max-w-[130px]" title={note.title}>{note.title}</h4>
                          <button 
                            type="button"
                            onClick={() => handleTogglePin(note)}
                            className={`p-1 rounded hover:bg-white/55 transition-colors ${note.isPinned ? 'text-indigo-600' : 'text-slate-400 opacity-0 group-hover:opacity-100'}`}
                            title="메모 고정"
                          >
                            <Pin className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <p className="text-[11px] font-bold text-slate-600 whitespace-pre-line leading-relaxed pb-4">{note.content}</p>
                      </div>

                      <div className="flex justify-between items-center border-t border-slate-950/5 pt-2 mt-auto">
                        <span className="text-[8px] font-bold text-slate-400">
                          {note.updatedAt?.seconds 
                            ? new Date(note.updatedAt.seconds * 1000).toLocaleDateString('ko-KR', { month: 'short', day: 'numeric' })
                            : '갱신 중...'}
                        </span>
                        <button
                          type="button"
                          onClick={() => note.id && handleDeleteNote(note.id)}
                          className="text-slate-400 hover:text-red-500 p-1 rounded hover:bg-white/55 transition-colors opacity-0 group-hover:opacity-100"
                          title="삭제"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

          </div>
        )}
      </div>
      </div>

      {/* Floating Comparison Dock when funds are selected */}
      {selectedFundIds.length > 0 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-slate-950/95 backdrop-blur-md text-white px-5 py-3.5 rounded-2xl shadow-2xl border border-indigo-500/30 flex items-center gap-4 max-w-2xl w-[92vw] sm:w-auto animate-fade-in no-print">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
              <Scale className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-black text-white block">
                {selectedFundIds.length}개 자금 비교 선택됨
              </span>
              <span className="text-[10px] text-slate-400 hidden sm:block">
                대출 금리·한도·상환조건을 한눈에 나란히 비교
              </span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-1.5 max-w-xs overflow-hidden">
            {selectedFundsList.map(fund => (
              <span 
                key={fund.id || fund.title} 
                className="text-[10px] bg-white/10 px-2 py-1 rounded-lg text-slate-200 truncate max-w-[90px] border border-white/10"
                title={fund.title}
              >
                {fund.title}
              </span>
            ))}
          </div>

          <div className="flex items-center gap-2 ml-auto">
            <button
              type="button"
              onClick={handleClearFundSelection}
              className="text-[11px] font-bold text-slate-400 hover:text-slate-200 px-2 py-1 cursor-pointer"
            >
              전체 해제
            </button>
            <button
              type="button"
              onClick={() => setIsCompareModalOpen(true)}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black rounded-xl shadow-lg shadow-indigo-600/30 flex items-center gap-1.5 transition-all hover:scale-105 cursor-pointer"
            >
              <Scale className="w-3.5 h-3.5" />
              <span>조건 비교표 보기</span>
            </button>
          </div>
        </div>
      )}

      {/* Compare Funds Modal */}
      <CompareFundsModal
        isOpen={isCompareModalOpen}
        onClose={() => setIsCompareModalOpen(false)}
        allFunds={result.matchedFunds}
        selectedFunds={selectedFundsList}
        onToggleSelect={handleToggleSelectFund}
        onRemoveFund={handleRemoveFundFromCompare}
        onScheduleCalendar={user && token ? handleScheduleFundReminder : undefined}
        favorites={favorites}
        onToggleFavorite={onToggleFavorite}
        onOpenConsultation={handleOpenConsultation}
      />

      {/* Fund Official PDF Checklist Modal */}
      <FundPdfChecklistModal
        isOpen={!!pdfChecklistFund}
        onClose={() => setPdfChecklistFund(null)}
        fund={pdfChecklistFund}
        profile={profile}
      />

      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        result={result}
        profile={profile}
      />

      {/* Fund Application Step-by-Step Guide Modal */}
      <FundApplicationGuideModal
        isOpen={!!selectedGuideFund}
        onClose={() => setSelectedGuideFund(null)}
        fund={selectedGuideFund}
      />
      {/* Detailed Feedback & AI Re-analysis Modal */}
      <DetailedFeedbackModal
        isOpen={isDetailedFeedbackModalOpen}
        onClose={() => setIsDetailedFeedbackModalOpen(false)}
        matchedFunds={result.matchedFunds}
        onSaveFeedbackOnly={handleSaveDetailedFeedback}
        onReanalyze={handleTriggerReanalysis}
        isReanalyzing={isReanalyzing}
      />

      {/* Push Notification Manager Modal */}
      <PushNotificationModal
        isOpen={isPushModalOpen}
        onClose={() => {
          setIsPushModalOpen(false);
          setPushModalTarget(null);
        }}
        favorites={favorites.length > 0 ? favorites : result.matchedFunds}
        initialSelectedFund={pushModalTarget}
      />

      {/* Expert 1:1 Consultation Modal */}
      <ExpertConsultationModal
        isOpen={isConsultModalOpen}
        onClose={() => {
          setIsConsultModalOpen(false);
          setConsultModalFund(null);
        }}
        fund={consultModalFund}
        profile={profile}
        token={token || null}
        onSubmitSuccess={handleConsultationSuccess}
      />

      {/* Deep Learning 5-Tier Approval Diagnosis & Improvement Report Modal */}
      <DeepLearningApprovalReportModal
        isOpen={isDeepLearningModalOpen}
        onClose={() => {
          setIsDeepLearningModalOpen(false);
          setDeepLearningModalFund(null);
        }}
        fund={deepLearningModalFund || (result.matchedFunds && result.matchedFunds[0])}
        profile={effectiveProfile}
        allFunds={result.matchedFunds}
      />

      {/* Google Forms Survey & Assessment Modal */}
      <GoogleFormsManagerModal
        isOpen={isFormsModalOpen}
        onClose={() => {
          setIsFormsModalOpen(false);
          setFormsModalTarget(null);
        }}
        token={token || null}
        profile={profile}
        selectedFund={formsModalTarget || (result.matchedFunds && result.matchedFunds[0])}
      />

      {/* Google Contacts Manager Modal (People API) */}
      <GoogleContactsManagerModal
        isOpen={isContactsModalOpen}
        onClose={() => setIsContactsModalOpen(false)}
        token={token || null}
        profile={effectiveProfile}
        targetFund={result.matchedFunds?.[0] || null}
        onShareToContact={(contact) => {
          if (contact.email) {
            setEmailTo(contact.email);
            setConsultSuccessToast(`Google 연락처 '${contact.name}' (${contact.email}) 님이 수신 이메일로 지정되었습니다.`);
            setTimeout(() => setConsultSuccessToast(null), 3500);
            const emailElem = document.getElementById('workspace-integrations-section');
            if (emailElem) emailElem.scrollIntoView({ behavior: 'smooth' });
          }
        }}
      />

      {/* Google Tasks Manager Modal (Tasks API) */}
      <GoogleTasksManagerModal
        isOpen={isTasksModalOpen}
        onClose={() => {
          setIsTasksModalOpen(false);
          setTasksModalTarget(null);
        }}
        token={token || null}
        profile={effectiveProfile}
        targetFund={tasksModalTarget || result.matchedFunds?.[0] || null}
      />

      {/* Consultation Toast Notification */}
      {consultSuccessToast && (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-2xl border border-indigo-500/30 flex items-center gap-3 animate-fade-in text-xs font-bold max-w-lg">
          <div className="w-7 h-7 rounded-xl bg-emerald-500 text-white flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-4 h-4" />
          </div>
          <span className="leading-snug">{consultSuccessToast}</span>
        </div>
      )}

      {/* Unified B2C Action CTA Floating Dock */}
      {!isPrinting && (
        <div className="sticky bottom-4 z-40 max-w-5xl mx-auto px-4 mt-8 no-print">
          <div className="bg-slate-900/95 backdrop-blur-md text-white p-4 sm:p-4.5 rounded-2xl shadow-2xl border border-slate-700/80 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-500 text-white flex items-center justify-center shrink-0 shadow-sm">
                <Headphones className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black text-white">정책자금 전문 자문위원 1:1 심층 진단</span>
                  <span className="text-[10px] font-black bg-emerald-500 text-white px-1.5 py-0.2 rounded-full">무료 접수</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  부결 방지 사전 검토 · 정책자금 우선 배정 심층 가이드
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2.5 w-full sm:w-auto">
              <button
                type="button"
                onClick={handleSaveReport}
                className="flex-1 sm:flex-initial px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition-all cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>맞춤 리포트 발급 (PDF)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setConsultModalFund(result.matchedFunds && result.matchedFunds[0] ? result.matchedFunds[0] : null);
                  setIsConsultModalOpen(true);
                }}
                className="flex-1 sm:flex-initial px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white rounded-xl font-black text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-indigo-600/30 transition-all active:scale-95 cursor-pointer"
              >
                <span>전문가 심층 진단 받기</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      )}

      <button 
        onClick={handleSaveReport}
        className="fixed bottom-6 right-6 md:hidden w-14 h-14 bg-slate-900 text-white rounded-full shadow-2xl flex items-center justify-center no-print z-50"
      >
        <Printer className="w-6 h-6" />
      </button>
    </div>
  );
};
