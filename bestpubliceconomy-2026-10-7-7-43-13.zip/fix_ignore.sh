sed -i 's/import { \/\* @ts-ignore \*\/ analyzePolicyMatching }/\/\/ @ts-ignore\nimport { analyzePolicyMatching }/g' components/admin/ConsultantDashboard.tsx components/admin/CustomerDetail.tsx
sed -i 's/import \/\/ @ts-ignore\n{ analyzePolicyMatching }/\/\/ @ts-ignore\nimport { analyzePolicyMatching }/g' components/admin/ConsultantDashboard.tsx components/admin/CustomerDetail.tsx
sed -i '/import { analyzePolicyMatching } from/i \/\/ @ts-ignore' components/admin/ConsultantDashboard.tsx components/admin/CustomerDetail.tsx
