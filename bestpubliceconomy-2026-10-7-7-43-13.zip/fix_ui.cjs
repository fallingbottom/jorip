const fs = require('fs');
let code = fs.readFileSync('components/ResultDashboard.tsx', 'utf8');

const targetUI = `<div className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-1">정책 최대 한도</div>
              <div className="text-xl font-black text-slate-900 line-through text-slate-400 decoration-slate-300 text-sm">{fund.maxAmount}</div>
              {(() => {
                const estLimit = calculateEstimatedLoanLimit(profile, fund.maxAmount);
                if (estLimit !== null) {
                  return (
                    <div className="mt-1">
                      <div className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded inline-block mb-0.5">내 사업장 예상 한도</div>
                      <div className="text-xl font-black text-emerald-700">{formatAmountKRW(estLimit)}</div>
                    </div>
                  );
                }
                return <div className="text-xl font-black text-slate-900">{fund.maxAmount}</div>;
              })()}`;

const replacementUI = `<div className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-1 flex items-center justify-end gap-1">
                <span>최대 한도</span>
              </div>
              {(() => {
                const estLimit = calculateEstimatedLoanLimit(profile, fund.maxAmount);
                if (estLimit !== null) {
                  return (
                    <div className="flex flex-col items-end">
                      <div className="text-sm font-bold text-slate-400 line-through decoration-slate-300 mb-0.5">{fund.maxAmount}</div>
                      <div className="text-[10px] font-black text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded flex items-center gap-1 mb-0.5">
                        <Sparkles className="w-2.5 h-2.5" /> 내 사업장 예상 한도
                      </div>
                      <div className="text-xl font-black text-emerald-700">{formatAmountKRW(estLimit)}</div>
                    </div>
                  );
                }
                return <div className="text-xl font-black text-slate-900">{fund.maxAmount}</div>;
              })()}`;

code = code.replace(targetUI, replacementUI);
fs.writeFileSync('components/ResultDashboard.tsx', code);
