with open('components/admin/AnnouncementCurationManager.tsx', 'r') as f:
    lines = f.readlines()

new_lines = []
skip = False
for i, line in enumerate(lines):
    if "</button>" in line and "</button>" in lines[i-1] and "Eye" in lines[i-2]:
        continue # skip the extra button
    new_lines.append(line)

with open('components/admin/AnnouncementCurationManager.tsx', 'w') as f:
    f.writelines(new_lines)
