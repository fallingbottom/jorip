
import React, { useState, useEffect, useCallback } from 'react';
import { StepWizard } from './components/StepWizard';
import { AdminCRM } from "./components/admin/AdminCRM";
import { ResultDashboard } from './components/ResultDashboard';
import { CalendarView } from './components/CalendarView';
import { PersonalDashboard } from './components/PersonalDashboard';
import { DebtReliefScreening } from './components/DebtReliefScreening';
import { TutorialModal } from './components/TutorialModal';
import { SuccessStories } from './components/SuccessStories';
import { FloatingChatbot } from './components/FloatingChatbot';
import { analyzePolicyMatching } from './services/geminiService';
import { fetchLatestPolicyData } from './services/fundDataSource';
import { checkAndNotifyUpcomingDeadlines } from './services/notificationService';
import { UserProfile, AnalysisResult, SourcePolicy, PolicyFund, ReanalysisFeedback, ComprehensiveEvaluationResult, Industry, BusinessType } from './types';
import { Building2, Landmark, ShieldCheck, RefreshCw, CheckCircle, AlertTriangle, Download, Smartphone, LogIn, LogOut, User as UserIcon, Calendar as CalendarIcon, Search, Star, MapPin, Compass, Award, ArrowLeft, UserPlus, Lock, Sparkles, BookOpen } from 'lucide-react';
import { initAuth, googleSignIn, logout, db } from './services/firebaseService';
import { evaluatePolicyQualifications } from './services/policyEligibilityMatcher';
import { PolicyQualificationComparisonView } from './components/PolicyQualificationComparisonView';
import { PolicyApplicationGuideView } from './components/PolicyApplicationGuideView';
import { User } from 'firebase/auth';
import { doc, getDocFromServer } from 'firebase/firestore';
import { AuthModal } from './components/auth/AuthModal';
import { 
  AdminUser, 
  getCurrentAdminSession, 
  isAuthorizedAdminEmail, 
  getAdminSettings,
  clearAdminSession,
  authenticateWithGoogleUser
} from './services/adminAuthService';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'MATCH' | 'EVAL' | 'GUIDE' | 'STORIES' | 'CALENDAR' | 'DASHBOARD' | 'ADMIN' | 'DEBT_RELIEF'>('MATCH');
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [comprehensiveEvaluation, setComprehensiveEvaluation] = useState<ComprehensiveEvaluationResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Authentication & Admin Access Modal State
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalTab, setAuthModalTab] = useState<'LOGIN' | 'SIGNUP'>('LOGIN');
  const [isModalAdminRequired, setIsModalAdminRequired] = useState(false);
  const [adminSession, setAdminSessionState] = useState<AdminUser | null>(() => getCurrentAdminSession());
  
  // Favorites state with persistence
  const [favorites, setFavorites] = useState<(PolicyFund | SourcePolicy)[]>(() => {
    try {
      const saved = localStorage.getItem('bizmatch_favorites');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem('bizmatch_favorites', JSON.stringify(favorites));
    } catch (err) {
      console.error("Failed to save favorites to localStorage", err);
    }
  }, [favorites]);

  const handleToggleFavorite = (item: PolicyFund | SourcePolicy) => {
    setFavorites(prev => {
      const itemTitle = 'title' in item ? item.title : item.name;
      const exists = prev.some(f => ('title' in f ? f.title : f.name) === itemTitle);
      if (exists) {
        return prev.filter(f => ('title' in f ? f.title : f.name) !== itemTitle);
      } else {
        return [...prev, item];
      }
    });
  };

  // Check deadline push notifications periodically
  useEffect(() => {
    if (favorites.length > 0) {
      checkAndNotifyUpcomingDeadlines(favorites);
    }
  }, [favorites]);
  
  // Google Auth state management
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Initialize and subscribe to Auth events
  useEffect(() => {
    const unsubscribe = initAuth(
      (currentUser, cachedToken) => {
        setUser(currentUser);
        setToken(cachedToken);
        if (currentUser) {
          const authCheck = authenticateWithGoogleUser(currentUser);
          if (authCheck.isAuthorizedAdmin && authCheck.user) {
            setAdminSessionState(authCheck.user);
          }
        }
      },
      () => {
        setUser(null);
        setToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const resultObj = await googleSignIn();
      if (resultObj) {
        setUser(resultObj.user);
        setToken(resultObj.accessToken);
        const authCheck = authenticateWithGoogleUser(resultObj.user);
        if (authCheck.isAuthorizedAdmin && authCheck.user) {
          setAdminSessionState(authCheck.user);
        }
      }
    } catch (err) {
      console.error("Login popup failed:", err);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogoutClick = async () => {
    try {
      clearAdminSession();
      setAdminSessionState(null);
      await logout();
      setUser(null);
      setToken(null);
    } catch (err) {
      console.error(err);
    }
  };

  // Admin Access Control Check
  const isCurrentAdmin = Boolean(
    (user && isAuthorizedAdminEmail(user.email)) || 
    (adminSession && adminSession.isApproved)
  );

  const handleAdminTabClick = () => {
    const settings = getAdminSettings();
    if (settings.isProtectionEnabled && !isCurrentAdmin) {
      setIsModalAdminRequired(true);
      setAuthModalTab('LOGIN');
      setIsAuthModalOpen(true);
    } else {
      setActiveTab('ADMIN');
    }
  };

  const handleOpenSignUp = () => {
    setIsModalAdminRequired(false);
    setAuthModalTab('SIGNUP');
    setIsAuthModalOpen(true);
  };

  const handleOpenLogin = () => {
    setIsModalAdminRequired(false);
    setAuthModalTab('LOGIN');
    setIsAuthModalOpen(true);
  };

  const handleAuthSuccess = (authenticated: any) => {
    if (authenticated && 'role' in authenticated && authenticated.isApproved) {
      setAdminSessionState(authenticated);
      if (isModalAdminRequired) {
        setActiveTab('ADMIN');
      }
    }
    setIsAuthModalOpen(false);
  };
  
  // Real-time policy data state
  const [latestPolicies, setLatestPolicies] = useState<SourcePolicy[]>([]);
  const [lastSyncTime, setLastSyncTime] = useState<string | null>(null);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncError, setSyncError] = useState(false);

  // PWA Install Prompt State
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showInstallBtn, setShowInstallBtn] = useState(false);

  // Periodic fetch mechanism
  const syncPolicyData = useCallback(async () => {
    if (isSyncing) return;
    
    setIsSyncing(true);
    setSyncError(false);
    try {
      const data = await fetchLatestPolicyData();
      setLatestPolicies(data);
      setLastSyncTime(new Date().toLocaleTimeString('ko-KR', { 
        hour: '2-digit', 
        minute: '2-digit',
        second: '2-digit'
      }));
    } catch (err) {
      console.error("Failed to sync policy data:", err);
      setSyncError(true);
    } finally {
      setIsSyncing(false);
    }
  }, [isSyncing]);

  useEffect(() => {
    // Initial fetch
    syncPolicyData();

    // Periodic fetch every 5 minutes (300,000 ms)
    const interval = setInterval(syncPolicyData, 300000);
    return () => clearInterval(interval);
  }, [syncPolicyData]);

  // PWA Install Event Listener
  useEffect(() => {
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowInstallBtn(true);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setShowInstallBtn(false);
    }
    setDeferredPrompt(null);
  };

  const [isReanalyzing, setIsReanalyzing] = useState(false);
  const [lastAppliedFeedback, setLastAppliedFeedback] = useState<ReanalysisFeedback | null>(null);

  const handleAnalysis = async (userProfile: UserProfile) => {
    setIsLoading(true);
    setError(null);
    setProfile(userProfile);
    setLastAppliedFeedback(null);
    
    // Evaluate deterministic policy qualifications and financial conditions
    const evalResult = evaluatePolicyQualifications(userProfile, latestPolicies);
    setComprehensiveEvaluation(evalResult);

    try {
      // Pass the latest fetched data as context to Gemini
      const analysis = await analyzePolicyMatching(userProfile, latestPolicies);
      setResult(analysis);
    } catch (err) {
      console.error(err);
      setError("분석 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleReanalysis = async (feedback: ReanalysisFeedback) => {
    if (!profile) return;
    setIsReanalyzing(true);
    setError(null);
    try {
      const updatedAnalysis = await analyzePolicyMatching(profile, latestPolicies, feedback);
      setResult(updatedAnalysis);
      setLastAppliedFeedback(feedback);
      const updatedEval = evaluatePolicyQualifications(profile, latestPolicies);
      setComprehensiveEvaluation(updatedEval);
    } catch (err) {
      console.error("Re-analysis error:", err);
      setError("AI 맞춤 조건 재분석 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.");
    } finally {
      setIsReanalyzing(false);
    }
  };

  const handleReset = () => {
    setResult(null);
    setProfile(null);
    setComprehensiveEvaluation(null);
    setError(null);
    setLastAppliedFeedback(null);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <TutorialModal />
      {/* Header */}
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50 shadow-sm print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 cursor-pointer group" onClick={handleReset}>
            <div className="w-9 h-9 bg-slate-900 rounded-xl flex items-center justify-center text-white font-black text-xl shadow-lg shadow-slate-900/20 group-hover:scale-105 transition-transform">
              B
            </div>
            <span className="text-xl font-black text-slate-900 tracking-tighter hidden md:inline">BizMatch <span className="text-blue-600">AI</span></span>
            <span className="text-xl font-black text-slate-900 tracking-tighter md:hidden">BizMatch</span>
          </div>

          <div className="flex items-center gap-2 md:gap-4">
            {/* Install Button (Only shows if installable) */}
            {showInstallBtn && (
              <button
                onClick={handleInstallClick}
                className="flex items-center gap-2 px-3 py-1.5 md:px-4 md:py-2 bg-slate-900 text-white rounded-full text-xs md:text-sm font-bold shadow-lg hover:bg-slate-800 transition-all active:scale-95 animate-pulse"
              >
                <Smartphone className="w-4 h-4" />
                <span className="hidden md:inline">앱 설치하기</span>
                <span className="md:hidden">앱 설치</span>
              </button>
            )}

            {/* Authentication State / Login & Sign Up Buttons */}
            {user || adminSession ? (
              <div className="flex items-center gap-2 border-l border-slate-200 pl-4 animate-fade-in">
                {user?.photoURL ? (
                  <img src={user.photoURL} alt="Google avatar" className="w-8 h-8 rounded-full border border-slate-200" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-slate-900 flex items-center justify-center text-white font-bold text-xs">
                    <UserIcon className="w-4 h-4" />
                  </div>
                )}
                <div className="hidden lg:flex flex-col items-start leading-none max-w-[130px]">
                  <span className="text-xs font-black text-slate-800 truncate w-full">
                    {adminSession?.name || user?.displayName || '회원 대표님'}
                  </span>
                  <div className="flex items-center gap-1 mt-0.5">
                    {isCurrentAdmin ? (
                      <span className="text-[9px] font-bold text-indigo-600 bg-indigo-50 px-1.5 py-0.2 rounded border border-indigo-200">
                        관리자·심사역
                      </span>
                    ) : (
                      <span className="text-[9px] font-bold text-emerald-600">소상공인 회원</span>
                    )}
                  </div>
                </div>
                <button
                  onClick={handleLogoutClick}
                  className="p-1.5 md:p-2 bg-slate-50 hover:bg-slate-100 rounded-lg text-slate-500 hover:text-red-500 transition-colors"
                  title="로그아웃"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 border-l border-slate-200 pl-3">
                <button
                  onClick={handleOpenLogin}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-slate-700 hover:text-indigo-600 hover:bg-slate-100 rounded-xl transition-all"
                >
                  <LogIn className="w-3.5 h-3.5" />
                  <span>로그인</span>
                </button>
                <button
                  onClick={handleOpenSignUp}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl shadow-xs transition-all active:scale-95"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>회원가입</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow p-4 md:p-8">
        
        {/* Tab Selector */}
        {!result && !isLoading && (
          <div className="max-w-5xl mx-auto flex justify-center mb-8 print:hidden">
            <div className="inline-flex bg-slate-100/90 p-1.5 rounded-2xl border border-slate-200/80 shadow-xs backdrop-blur-sm flex-wrap gap-1 justify-center">
              <button
                onClick={() => setActiveTab('MATCH')}
                className={`flex items-center gap-2 px-4 md:px-4.5 py-2.5 rounded-xl font-bold text-xs md:text-sm transition-all duration-200 cursor-pointer ${
                  activeTab === 'MATCH' 
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <Search className={`w-4 h-4 ${activeTab === 'MATCH' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>AI 맞춤 매칭</span>
              </button>
              <button
                onClick={() => setActiveTab('EVAL')}
                className={`flex items-center gap-2 px-4 md:px-4.5 py-2.5 rounded-xl font-bold text-xs md:text-sm transition-all duration-200 cursor-pointer ${
                  activeTab === 'EVAL' 
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <Sparkles className={`w-4 h-4 ${activeTab === 'EVAL' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>자격 요건 분석</span>
              </button>
              <button
                onClick={() => setActiveTab('GUIDE')}
                className={`flex items-center gap-2 px-4 md:px-4.5 py-2.5 rounded-xl font-bold text-xs md:text-sm transition-all duration-200 cursor-pointer ${
                  activeTab === 'GUIDE' 
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <BookOpen className={`w-4 h-4 ${activeTab === 'GUIDE' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>신청 가이드</span>
              </button>
              <button
                onClick={() => setActiveTab('STORIES')}
                className={`flex items-center gap-2 px-4 md:px-4.5 py-2.5 rounded-xl font-bold text-xs md:text-sm transition-all duration-200 cursor-pointer ${
                  activeTab === 'STORIES' 
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <Award className={`w-4 h-4 ${activeTab === 'STORIES' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>실전 성공사례</span>
              </button>
              <button
                onClick={() => setActiveTab('CALENDAR')}
                className={`flex items-center gap-2 px-4 md:px-4.5 py-2.5 rounded-xl font-bold text-xs md:text-sm transition-all duration-200 cursor-pointer ${
                  activeTab === 'CALENDAR' 
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <CalendarIcon className={`w-4 h-4 ${activeTab === 'CALENDAR' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>정책자금 캘린더</span>
              </button>
              <button
                onClick={() => setActiveTab('DASHBOARD')}
                className={`flex items-center gap-2 px-4 md:px-4.5 py-2.5 rounded-xl font-bold text-xs md:text-sm transition-all duration-200 cursor-pointer ${
                  activeTab === 'DASHBOARD' 
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <Star className={`w-4 h-4 ${activeTab === 'DASHBOARD' ? 'text-amber-500 fill-amber-400' : 'text-slate-400'}`} />
                <span>MY 대시보드</span>
                {favorites.length > 0 && (
                  <span className="ml-0.5 px-1.5 py-0.2 text-[10px] bg-slate-200 text-slate-700 rounded-md font-bold leading-none">
                    {favorites.length}
                  </span>
                )}
              </button>
              <button
                onClick={handleAdminTabClick}
                className={`flex items-center gap-2 px-4 md:px-4.5 py-2.5 rounded-xl font-bold text-xs md:text-sm transition-all duration-200 cursor-pointer ${
                  activeTab === 'ADMIN' 
                    ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80' 
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <ShieldCheck className={`w-4 h-4 ${activeTab === 'ADMIN' ? 'text-indigo-600' : 'text-slate-400'}`} />
                <span>관리자 CRM</span>
                {isCurrentAdmin ? (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" title="관리자 권한 승인됨" />
                ) : (
                  <span title="인증 필요">
                    <Lock className="w-3 h-3 text-slate-400" />
                  </span>
                )}
              </button>
            </div>
          </div>
        )}

        {activeTab === 'MATCH' && !result && !isLoading && (
          <div className="max-w-4xl mx-auto space-y-12 pt-2">
            <div className="text-center space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-xs font-black uppercase tracking-widest mb-2">
                <ShieldCheck className="w-3.5 h-3.5" /> Trusted by 5,000+ Business Owners
              </div>
              <h1 className="text-4xl md:text-6xl font-black text-slate-900 leading-[1.1] tracking-tight">
                소상공인을 위한 <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 via-blue-500 to-emerald-500">
                  실시간 정책자금 매칭
                </span>
              </h1>
              <p className="text-lg text-slate-500 max-w-2xl mx-auto font-medium">
                정부 기관 공고를 5분마다 동기화하여 실시간으로 분석합니다. <br />
                내 사업에 가장 유리한 금리와 한도를 단 1분 만에 확인하세요.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col items-center text-center group hover:shadow-md transition-shadow">
                    <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center mb-4 text-blue-600 group-hover:scale-110 transition-transform">
                        <Landmark className="w-6 h-6" />
                    </div>
                    <h3 className="font-bold text-slate-900 mb-2">실시간 기관 연동</h3>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed">소진공, 중진공 등 주요 기관 공고 5분 단위 실시간 동기화</p>
                </div>
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col items-center text-center group hover:shadow-md transition-shadow">
                    <div className="w-12 h-12 bg-emerald-50 rounded-xl flex items-center justify-center mb-4 text-emerald-600 group-hover:scale-110 transition-transform">
                        <Building2 className="w-6 h-6" />
                    </div>
                    <h3 className="font-bold text-slate-900 mb-2">업종별 정밀 분석</h3>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed">제조, IT, 음식점 등 업종별 특화 가점 요건 완벽 분석</p>
                </div>
                <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex flex-col items-center text-center group hover:shadow-md transition-shadow">
                    <div className="w-12 h-12 bg-purple-50 rounded-xl flex items-center justify-center mb-4 text-purple-600 group-hover:scale-110 transition-transform">
                        <ShieldCheck className="w-6 h-6" />
                    </div>
                    <h3 className="font-bold text-slate-900 mb-2">AI 승인 예측</h3>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed">신용도와 매출 지표를 기반으로 자금별 승인 확률 시뮬레이션</p>
                </div>
            </div>

            <StepWizard onComplete={handleAnalysis} isLoading={isLoading} token={token} />
          </div>
        )}

        {/* Dedicated Policy Qualification & Condition Comparison Tab */}
        {activeTab === 'EVAL' && !isLoading && (
          <div className="max-w-7xl mx-auto pt-2 space-y-6 animate-fade-in">
            {profile ? (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => setActiveTab('MATCH')}
                      className="p-2 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-xl transition-all shadow-xs cursor-pointer"
                      title="AI 맞춤 매칭으로 이동"
                    >
                      <ArrowLeft className="w-4 h-4" />
                    </button>
                    <div>
                      <h2 className="text-xl font-black text-slate-900 flex items-center gap-2">
                        <span>{profile.businessName || '내 사업장'} 자격 요건 정밀 분석 리포트</span>
                        <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800">
                          실시간 기준
                        </span>
                      </h2>
                      <p className="text-xs text-slate-500 font-medium mt-0.5">
                        입력된 업종·매출·고용·부채비율·신용점수 및 과거 이력을 바탕으로 한 정책별 수혜 가능성 대조표
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setActiveTab('MATCH')}
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer flex items-center gap-1.5"
                    >
                      <Search className="w-3.5 h-3.5" />
                      <span>정보 수정 및 AI 재매칭</span>
                    </button>
                  </div>
                </div>

                <PolicyQualificationComparisonView
                  profile={profile}
                  evaluationResult={comprehensiveEvaluation || evaluatePolicyQualifications(profile, latestPolicies)}
                />
              </div>
            ) : (
              <div className="max-w-3xl mx-auto p-8 bg-white rounded-3xl border border-slate-200 shadow-sm text-center space-y-6">
                <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mx-auto shadow-xs">
                  <Sparkles className="w-7 h-7" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-2xl font-black text-slate-900">
                    정책자금 자격 요건 비교 분석
                  </h3>
                  <p className="text-sm text-slate-500 max-w-lg mx-auto leading-relaxed font-medium">
                    소상공인의 업종, 연 매출, 상시 근로자 수, 부채비율, 세금체납 여부 및 과거 정책자금 수혜 이력을 종합하여 정부 정책자금의 요건과 1:1 대조 분석합니다.
                  </p>
                </div>

                <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => setActiveTab('MATCH')}
                    className="w-full sm:w-auto px-6 py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-black shadow-lg shadow-blue-600/20 transition-all cursor-pointer flex items-center justify-center gap-2"
                  >
                    <span>내 사업체 정보 입력하고 분석하기 (3분)</span>
                  </button>
                </div>

                {/* Instant Sample Experience Presets */}
                <div className="pt-6 border-t border-slate-100 space-y-3">
                  <span className="text-xs font-bold text-slate-400 block uppercase tracking-wider">
                    ⚡ 테스트 샘플 데이터로 즉시 결과 체험하기
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-left">
                    <button
                      type="button"
                      onClick={() => {
                        const sampleProfile: UserProfile = {
                          name: '홍길동',
                          businessName: '길동분식',
                          businessRegistrationNumber: '123-45-67890',
                          businessAddress: '서울 강동구 성내로 123',
                          industry: Industry.RESTAURANT,
                          businessType: BusinessType.INDIVIDUAL,
                          location: '서울 강동구',
                          foundedYear: '2021',
                          annualRevenue: 280000000,
                          employees: 3,
                          creditScore: 710,
                          expectedProfitMargin: 16,
                          cashFlowStatus: 78,
                          debt1Tier: 120000000,
                          debt2Tier: 0,
                          debtCardLoan: 15000000,
                          debtOther: 45000000,
                          debtRatio: 64,
                          hasTaxArrears: false,
                          hasOverdue: false,
                          fundingNeed: 50000000,
                          policyBonusFactors: {
                            hasSmartFactory: true,
                            hasCarbonNeutrality: true,
                            hasJobCreation: false,
                            hasVentureOrInnoBiz: false,
                            hasCreditEducation: true,
                            smartFactoryLevel: 'SMART_WORKSHOP',
                            carbonCertType: 'PLEDGE'
                          },
                          applicationHistories: [
                            {
                              id: 'A2025-0001',
                              agency: '소상공인시장진흥공단',
                              productName: '일반경영안정자금',
                              applyYear: 2024,
                              applyMonth: 6,
                              applyAmount: 50000000,
                              status: 'APPROVED',
                              approvedAmount: 40000000,
                              remainingBalance: 20000000
                            }
                          ]
                        };
                        handleAnalysis(sampleProfile);
                      }}
                      className="p-4 rounded-2xl border border-slate-200 hover:border-blue-300 hover:bg-blue-50/50 transition-all cursor-pointer group"
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xs font-black text-slate-900 group-hover:text-blue-600">
                          🍽️ 길동분식 (일반음식점)
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded-md">
                          매출 2.8억
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 leading-snug">
                        근로자 3인 · 부채비율 64% · 신용 710점 · <strong className="text-blue-600">스마트상점+탄소중립 가점(+18%p) 보유</strong>
                      </p>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        const sampleProfile: UserProfile = {
                          name: '김순희',
                          businessName: '예쁜카페',
                          businessRegistrationNumber: '234-56-78901',
                          businessAddress: '서울 강동구 천호대로 456',
                          industry: Industry.SERVICE,
                          businessType: BusinessType.INDIVIDUAL,
                          location: '서울 강동구',
                          foundedYear: '2022',
                          annualRevenue: 150000000,
                          employees: 2,
                          creditScore: 695,
                          expectedProfitMargin: 18,
                          cashFlowStatus: 72,
                          debt1Tier: 70000000,
                          debt2Tier: 10000000,
                          debtCardLoan: 10000000,
                          debtOther: 5000000,
                          debtRatio: 63,
                          hasTaxArrears: false,
                          hasOverdue: false,
                          fundingNeed: 30000000,
                          policyBonusFactors: {
                            hasSmartFactory: false,
                            hasCarbonNeutrality: false,
                            hasJobCreation: true,
                            hasVentureOrInnoBiz: false,
                            hasCreditEducation: false
                          },
                          applicationHistories: [
                            {
                              id: 'A2025-0002',
                              agency: '국민은행/지역신보',
                              productName: '소상공인 특례보증',
                              applyYear: 2024,
                              applyMonth: 9,
                              applyAmount: 30000000,
                              status: 'APPROVED',
                              approvedAmount: 30000000,
                              remainingBalance: 30000000
                            }
                          ]
                        };
                        handleAnalysis(sampleProfile);
                      }}
                      className="p-4 rounded-2xl border border-slate-200 hover:border-blue-300 hover:bg-blue-50/50 transition-all cursor-pointer group"
                    >
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="text-xs font-black text-slate-900 group-hover:text-blue-600">
                          ☕ 예쁜카페 (카페/음료)
                        </span>
                        <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-100 text-blue-800 rounded-md">
                          매출 1.5억
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 leading-snug">
                        근로자 2인 · 부채비율 63% · 신용 695점 · <strong className="text-purple-600">청년 고용 창출 가점(+6%p) 보유</strong>
                      </p>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'STORIES' && !isLoading && (
          <div className="max-w-7xl mx-auto pt-2 space-y-6 animate-fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <button
                type="button"
                onClick={() => setActiveTab('MATCH')}
                className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer hover:scale-105 active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>AI 맞춤 매칭으로 돌아가기</span>
              </button>
              <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span>전국 소상공인 실전 성공사례 단독 페이지</span>
              </div>
            </div>
            <SuccessStories 
              profile={profile} 
              isStandalonePage={true}
              onSelectFund={(fundName) => {
                setActiveTab('MATCH');
              }}
            />
          </div>
        )}

        {activeTab === 'CALENDAR' && !isLoading && (
          <div className="pt-2">
            <CalendarView 
              policies={latestPolicies} 
              token={token} 
              favorites={favorites} 
              onToggleFavorite={handleToggleFavorite} 
            />
          </div>
        )}

        {activeTab === 'DASHBOARD' && !isLoading && (
          <div className="pt-2">
            <PersonalDashboard 
              favorites={favorites} 
              onToggleFavorite={handleToggleFavorite} 
              token={token} 
              profile={profile} 
              result={result}
              latestPolicies={latestPolicies}
              onNavigateToMatch={() => setActiveTab('MATCH')}
            />
          </div>
        )}

        {activeTab === 'ADMIN' && !isLoading && (
          <div className="pt-2">
            <AdminCRM onExitToMainApp={() => setActiveTab('MATCH')} />
          </div>
        )}
        {activeTab === 'DEBT_RELIEF' && !isLoading && (
          <div className="pt-2">
            <DebtReliefScreening />
          </div>
        )}

        {activeTab === 'GUIDE' && !isLoading && (
          <div className="max-w-7xl mx-auto pt-2 space-y-6 animate-fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <button
                type="button"
                onClick={() => setActiveTab('MATCH')}
                className="flex items-center gap-2 px-4 py-2 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer hover:scale-105 active:scale-95"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>AI 맞춤 매칭으로 돌아가기</span>
              </button>
              <div className="flex items-center gap-2 text-xs font-bold text-slate-500">
                <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                <span>정부지원 소상공인 정책자금 신청 완벽 가이드</span>
              </div>
            </div>
            <PolicyApplicationGuideView
              profile={profile}
              matchedFunds={result?.matchedFunds || []}
              onNavigateToMatch={() => setActiveTab('MATCH')}
            />
          </div>
        )}

        {isLoading && (
          <div className="fixed inset-0 bg-white/90 backdrop-blur-md z-50 flex flex-col items-center justify-center">
            <div className="relative w-32 h-32 mb-10">
              <div className="absolute inset-0 border-[6px] border-blue-50 rounded-full"></div>
              <div className="absolute inset-0 border-[6px] border-blue-600 rounded-full border-t-transparent animate-spin"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-3xl font-black text-slate-900">AI</span>
              </div>
            </div>
            <h2 className="text-3xl font-black text-slate-900 mb-3 tracking-tight">최적의 자금을 선별하고 있습니다</h2>
            <div className="flex items-center gap-2 px-4 py-1.5 bg-slate-900 text-white rounded-full text-xs font-bold mb-8">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-blue-400" />
              {latestPolicies.length}개 실시간 공고 데이터 대조 중
            </div>
            
            <div className="grid grid-cols-1 gap-3 max-w-sm w-full px-6">
                {[
                  "소상공인시장진흥공단 공고 스캔 완료",
                  "신용보증재단 특례보증 요건 분석 중",
                  "업종별 가점 항목 매칭 중",
                  "최종 승인 확률 시뮬레이션 생성 중"
                ].map((text, i) => (
                  <div key={i} className="flex items-center gap-3 py-3 px-5 bg-white border border-slate-100 rounded-2xl shadow-sm animate-pulse" style={{ animationDelay: `${i * 200}ms` }}>
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span className="text-xs font-bold text-slate-600">{text}</span>
                  </div>
                ))}
            </div>
          </div>
        )}

        {activeTab === 'MATCH' && result && !isLoading && (
            <ResultDashboard 
              result={result} 
              onReset={handleReset} 
              profile={profile} 
              token={token} 
              user={user} 
              favorites={favorites} 
              onToggleFavorite={handleToggleFavorite} 
              onReanalyze={handleReanalysis}
              isReanalyzing={isReanalyzing}
              appliedFeedback={lastAppliedFeedback}
              comprehensiveEvaluation={comprehensiveEvaluation}
            />
        )}

        {error && !isLoading && !result && (
            <div className="max-w-md mx-auto mt-8 p-6 bg-red-50 text-red-700 rounded-3xl border border-red-100 text-center shadow-xl shadow-red-500/5">
                <AlertTriangle className="w-8 h-8 mx-auto mb-4 text-red-500" />
                <p className="font-bold mb-4">{error}</p>
                <button 
                  onClick={() => setError(null)} 
                  className="px-6 py-2 bg-red-600 text-white rounded-xl font-bold text-sm hover:bg-red-700 transition-colors"
                >
                  다시 시도하기
                </button>
            </div>
        )}
      </main>
      
      {/* Footer */}
      <footer className="bg-white border-t border-slate-100 py-10 mt-auto">
        <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-6">
            <div className="flex items-center gap-2 opacity-50 grayscale">
              <div className="w-6 h-6 bg-slate-900 rounded-md flex items-center justify-center text-white font-bold text-xs">B</div>
              <span className="text-sm font-bold text-slate-900 tracking-tighter">BizMatch AI</span>
            </div>
            <p className="text-slate-400 text-[11px] font-bold text-center max-w-md leading-relaxed">
              BizMatch AI는 공공데이터를 활용한 분석 정보를 제공하며, 실제 승인 여부는 금융기관의 최종 심사에 따릅니다.
            </p>
            <p className="text-slate-400 text-[11px] font-bold">&copy; 2024 BizMatch AI. All rights reserved.</p>
        </div>
      </footer>
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialTab={authModalTab}
        isAdminRequired={isModalAdminRequired}
        onSuccess={handleAuthSuccess}
      />
      <FloatingChatbot profile={profile} result={result} />
    </div>
  );
};

export default App;
