const fs = require('fs');
let code = fs.readFileSync('components/PersonalDashboard.tsx', 'utf8');

code = code.replace(
  "import { RealtimePolicyNews } from './RealtimePolicyNews';",
  "import { RealtimePolicyNews } from './RealtimePolicyNews';\nimport { BusinessLicenseParser } from './BusinessLicenseParser';"
);

const target = `{/* Credit Score Management, Fund Approval Predictor & Improvement Roadmap (Shown when ALL or TOOLS) */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'TOOLS') && (
      <CreditScoreManager`;

const replacement = `{/* OCR Business License Scanner (Shown when ALL or TOOLS) */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'TOOLS') && (
        <BusinessLicenseParser />
      )}
      
      {/* Credit Score Management, Fund Approval Predictor & Improvement Roadmap (Shown when ALL or TOOLS) */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'TOOLS') && (
      <CreditScoreManager`;

code = code.replace(target, replacement);

fs.writeFileSync('components/PersonalDashboard.tsx', code);
