const fs = require('fs');
let code = fs.readFileSync('services/fundDataSource.ts', 'utf8');

const newFunds = `    },
    {
      name: "청년테크스타보증",
      agency: "기술보증기금 (KIBO)",
      baseInterestRate: "보증부대출 취급은행 금리",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "우수 기술을 보유한 청년 창업자의 혁신성장 및 기술개발 지원",
      eligibility: "대표자가 만 39세 이하이고 창업 후 7년 이내인 기술혁신형 중소기업",
      maxAmount: "300,000,000",
      repaymentPeriod: "최대 5년 (거치 2년 포함)",
      applicationProcedure: ["기술보증기금 영업점 방문 또는 온라인 상담", "기술평가 및 보증심사", "보증서 발급 및 은행 대출"],
      contactInfo: "기술보증기금 고객센터 (1544-1120)"
    },
    {
      name: "미소금융 창업·운영자금",
      agency: "서민금융진흥원 (미소금융)",
      baseInterestRate: "연 4.5% (고정금리)",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "제도권 금융 이용이 어려운 취약계층의 창업 및 생계형 사업 운영 지원",
      eligibility: "개인신용평점 하위 20% 이거나 기초생활수급자·차상위계층",
      maxAmount: "창업 70,000,000 / 운영 20,000,000",
      repaymentPeriod: "최대 5.5년 (거치 6개월 포함)",
      applicationProcedure: ["서민금융진흥원 또는 미소금융 지점 방문 상담", "사업장 현장실사 및 심사", "대출금 지급"],
      contactInfo: "서민금융콜센터 (1397)"
    },
    {
      name: "스타트업 NEST 보증",
      agency: "신용보증기금 (KODIT)",
      baseInterestRate: "보증부대출 취급은행 금리",
      currentStatus: koditStatus,
      budgetExhaustionRate: koditStatus === 'BUDGET_ALMOST_EXHAUSTED' ? 95 : 65,
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "유망 스타트업을 발굴하여 보증, 투자 등 금융지원 및 컨설팅 융복합 지원",
      eligibility: "창업 후 3년 이내의 혁신성장 유망 스타트업",
      maxAmount: "500,000,000",
      repaymentPeriod: "협약 은행 기준에 따름",
      applicationProcedure: ["신보스타트업 플랫폼 회원가입 및 접수", "서류 및 발표 평가", "보증 및 금융지원"],
      contactInfo: "신용보증기금 고객센터 (1588-6565)"
    },
    {
      name: "온라인셀러 특별보증",
      agency: "신용보증기금 (KODIT)",
      baseInterestRate: "보증부대출 취급은행 금리",
      currentStatus: "OPEN",
      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),
      lastUpdated: now,
      startDate: "2026-01-01",
      endDate: "2026-12-31",
      announcementDate: "2026-01-01",
      description: "전자상거래 플랫폼(쿠팡, 네이버 등) 입점 소상공인을 위한 선정산 및 유동성 지원",
      eligibility: "주요 이커머스 플랫폼에 입점하여 6개월 이상 영업 중인 온라인 셀러",
      maxAmount: "100,000,000",
      repaymentPeriod: "최대 5년",
      applicationProcedure: ["온라인셀러 전용 플랫폼 또는 신용보증기금 영업점 신청", "매출 데이터 기반 보증심사", "보증서 발급"],
      contactInfo: "신용보증기금 고객센터 (1588-6565)"
    }
  ];`;

code = code.replace(/    \}\n  \];/, newFunds);
fs.writeFileSync('services/fundDataSource.ts', code);
