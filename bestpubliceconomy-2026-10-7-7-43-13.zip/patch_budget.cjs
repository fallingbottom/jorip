const fs = require('fs');
let code = fs.readFileSync('services/fundDataSource.ts', 'utf8');

code = code.replace(
  /currentStatus: "OPEN",/g,
  "currentStatus: \"OPEN\",\n      budgetExhaustionRate: Math.floor(Math.random() * (98 - 40 + 1) + 40),"
);

code = code.replace(
  /currentStatus: koditStatus,/g,
  "currentStatus: koditStatus,\n      budgetExhaustionRate: koditStatus === 'BUDGET_ALMOST_EXHAUSTED' ? 95 : 75,"
);

fs.writeFileSync('services/fundDataSource.ts', code);
