const fs = require('fs');
let code = fs.readFileSync('components/PersonalDashboard.tsx', 'utf8');

// 1. Add 'NEWS' to the state type
code = code.replace(
  "const [activeDashboardTab, setActiveDashboardTab] = useState<'ALL' | 'QUICK_CHECK' | 'SCRAPS' | 'CONSULTATIONS' | 'CHAT' | 'RADAR' | 'TRACKER' | 'TOOLS'>('ALL');",
  "const [activeDashboardTab, setActiveDashboardTab] = useState<'ALL' | 'QUICK_CHECK' | 'SCRAPS' | 'CONSULTATIONS' | 'CHAT' | 'RADAR' | 'TRACKER' | 'TOOLS' | 'NEWS'>('ALL');"
);

// 2. Add Newspaper to lucide-react imports
code = code.replace(
  "  MapPin\n} from 'lucide-react';",
  "  MapPin,\n  Newspaper\n} from 'lucide-react';"
);

// 3. Add the NEWS button in the tab bar
const tabTarget = `<button
          type="button"
          onClick={() => setActiveDashboardTab('TOOLS')}
          className={\`px-4 py-2.5 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer flex items-center gap-1.5 \${
            activeDashboardTab === 'TOOLS'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }\`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          <span>대출 시뮬레이터 & 신용관리</span>
        </button>
      </div>`;

const tabReplacement = `<button
          type="button"
          onClick={() => setActiveDashboardTab('TOOLS')}
          className={\`px-4 py-2.5 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer flex items-center gap-1.5 \${
            activeDashboardTab === 'TOOLS'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }\`}
        >
          <DollarSign className="w-3.5 h-3.5" />
          <span>대출 시뮬레이터 & 신용관리</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveDashboardTab('NEWS')}
          className={\`px-4 py-2.5 rounded-xl text-xs font-black transition-all shrink-0 cursor-pointer flex items-center gap-1.5 \${
            activeDashboardTab === 'NEWS'
              ? 'bg-sky-500 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-100'
          }\`}
        >
          <Newspaper className="w-3.5 h-3.5" />
          <span>오늘의 정책 뉴스</span>
        </button>
      </div>`;

code = code.replace(tabTarget, tabReplacement);

// 4. Wrap RealtimePolicyNews
const newsTarget = `{/* Realtime Regional & Industry Policy News via Google Search */}
      <RealtimePolicyNews profile={profile} />`;

const newsReplacement = `{/* Realtime Regional & Industry Policy News via Google Search */}
      {(activeDashboardTab === 'ALL' || activeDashboardTab === 'NEWS') && (
        <RealtimePolicyNews profile={profile} />
      )}`;

code = code.replace(newsTarget, newsReplacement);

fs.writeFileSync('components/PersonalDashboard.tsx', code);
