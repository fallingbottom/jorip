const fs = require('fs');
let code = fs.readFileSync('components/PersonalDashboard.tsx', 'utf8');
code = code.replace(
  "      </div>\\n\\n      {/* AI Similar Policy Funds Recommendation Section */}",
  "      </div>\\n      )}\\n\\n      {/* AI Similar Policy Funds Recommendation Section */}"
);
fs.writeFileSync('components/PersonalDashboard.tsx', code);
