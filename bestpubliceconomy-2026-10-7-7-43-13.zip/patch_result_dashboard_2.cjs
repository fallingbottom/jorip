const fs = require('fs');
let code = fs.readFileSync('components/ResultDashboard.tsx', 'utf8');

const stateTarget = `  const [selectedPdfFund, setSelectedPdfFund] = useState<PolicyFund | null>(null);`;
const stateReplacement = `  const [selectedPdfFund, setSelectedPdfFund] = useState<PolicyFund | null>(null);
  const [selectedGuideFund, setSelectedGuideFund] = useState<PolicyFund | null>(null);`;

code = code.replace(stateTarget, stateReplacement);

const modalRenderTarget = `      <FundPdfChecklistModal
        isOpen={!!selectedPdfFund}
        onClose={() => setSelectedPdfFund(null)}
        fund={selectedPdfFund}
      />`;
const modalRenderReplacement = `      <FundPdfChecklistModal
        isOpen={!!selectedPdfFund}
        onClose={() => setSelectedPdfFund(null)}
        fund={selectedPdfFund}
      />
      
      <FundApplicationGuideModal
        isOpen={!!selectedGuideFund}
        onClose={() => setSelectedGuideFund(null)}
        fund={selectedGuideFund}
      />`;

code = code.replace(modalRenderTarget, modalRenderReplacement);

// We need to pass onOpenApplicationGuide={setSelectedGuideFund} to all FundCard usages.
const fundCardPropTarget = `isPrinting={false} 
                            onScheduleCalendar={user && token ? handleScheduleFundReminder : undefined}`;
const fundCardPropReplacement = `isPrinting={false} 
                            onOpenApplicationGuide={setSelectedGuideFund}
                            onScheduleCalendar={user && token ? handleScheduleFundReminder : undefined}`;
code = code.replaceAll(fundCardPropTarget, fundCardPropReplacement);


fs.writeFileSync('components/ResultDashboard.tsx', code);
