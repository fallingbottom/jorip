import re

with open('components/admin/AnnouncementCurationManager.tsx', 'r') as f:
    content = f.read()

# We changed '<button' to '<button type="button"' globally.
# So now we have instances of `<button type="button"` that might also have another `type="button"` or `type="submit"` nearby.
# Let's just remove ` type="button"` from `<button type="button"` everywhere, 
# then we can let the original code be (some buttons might be missing type="button", which is fine as long as they don't submit forms unexpectedly).

content = content.replace('<button type="button"', '<button')

with open('components/admin/AnnouncementCurationManager.tsx', 'w') as f:
    f.write(content)
