const fs = require('fs');
let code = fs.readFileSync('App.tsx', 'utf8');

// 1. Update the type for activeTab
code = code.replace(
  "useState<'MATCH' | 'MAP' | 'CALENDAR' | 'DASHBOARD' | 'ADMIN'>('MATCH');",
  "useState<'MATCH' | 'MAP' | 'CALENDAR' | 'DASHBOARD' | 'ADMIN' | 'DEBT_RELIEF'>('MATCH');"
);

// 2. Add import for the new component and icon
code = code.replace(
  "import { PersonalDashboard } from './components/PersonalDashboard';",
  "import { PersonalDashboard } from './components/PersonalDashboard';\nimport { DebtReliefScreening } from './components/DebtReliefScreening';"
);
code = code.replace(
  "import { User, Sparkles, Building2, Search, ArrowRight, LayoutDashboard, Map as MapIcon, Calendar, CheckCircle2 } from 'lucide-react';",
  "import { User, Sparkles, Building2, Search, ArrowRight, LayoutDashboard, Map as MapIcon, Calendar, CheckCircle2, ShieldAlert } from 'lucide-react';"
);

// 3. Add the button to the Sidebar navigation
const targetButton = `              <button 
                onClick={() => setActiveTab('ADMIN')}
                className={\`w-full flex items-center justify-between p-3 rounded-2xl transition-all font-bold text-sm \${
                  activeTab === 'ADMIN' 
                    ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md' 
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }\`}
              >
                <div className="flex items-center gap-3">
                  <div className={\`p-2 rounded-xl \${activeTab === 'ADMIN' ? 'bg-white/20' : 'bg-slate-100'}\`}>
                    <User className="w-4 h-4" />
                  </div>
                  운영자 CRM
                </div>
              </button>`;
const addButton = targetButton + `
              <button 
                onClick={() => setActiveTab('DEBT_RELIEF')}
                className={\`w-full flex items-center justify-between p-3 rounded-2xl transition-all font-bold text-sm \${
                  activeTab === 'DEBT_RELIEF' 
                    ? 'bg-gradient-to-r from-rose-600 to-red-600 text-white shadow-md' 
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }\`}
              >
                <div className="flex items-center gap-3">
                  <div className={\`p-2 rounded-xl \${activeTab === 'DEBT_RELIEF' ? 'bg-white/20' : 'bg-slate-100'}\`}>
                    <ShieldAlert className="w-4 h-4" />
                  </div>
                  채무조정 진단
                </div>
              </button>`;
code = code.replace(targetButton, addButton);

// 4. Add the component render
const targetRender = `        {activeTab === 'ADMIN' && !isLoading && (
          <div className="pt-2">
            <AdminCRM />
          </div>
        )}`;
const addRender = targetRender + `
        {activeTab === 'DEBT_RELIEF' && !isLoading && (
          <div className="pt-2">
            <DebtReliefScreening />
          </div>
        )}`;
code = code.replace(targetRender, addRender);

fs.writeFileSync('App.tsx', code);
