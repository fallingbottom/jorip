const fs = require('fs');
let code = fs.readFileSync('components/PersonalDashboard.tsx', 'utf8');
code = code.replace(
  "import { BusinessLicenseParser } from './BusinessLicenseParser';\\nimport { BusinessLicenseParser } from './BusinessLicenseParser';",
  "import { BusinessLicenseParser } from './BusinessLicenseParser';"
);
fs.writeFileSync('components/PersonalDashboard.tsx', code);
