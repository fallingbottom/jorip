const fs = require('fs');
let code = fs.readFileSync('services/geminiService.ts', 'utf8');

const promptTarget = `    - Expected Profit Margin (expectedProfitMargin) - percentage 0 to 50`;
const promptReplacement = `    - Province/City (location) - Based on the address, determine the major province/city and map exactly to one of these: '서울', '경기', '인천', '부산', '대구', '광주', '대전', '울산', '강원', '충북', '충남', '전북', '전남', '경북', '경남', '제주'.
    - Expected Profit Margin (expectedProfitMargin) - percentage 0 to 50`;

code = code.replace(promptTarget, promptReplacement);

const schemaTarget = `          expectedProfitMargin: { type: Type.INTEGER },`;
const schemaReplacement = `          location: { type: Type.STRING },
          expectedProfitMargin: { type: Type.INTEGER },`;

code = code.replace(schemaTarget, schemaReplacement);

fs.writeFileSync('services/geminiService.ts', code);
