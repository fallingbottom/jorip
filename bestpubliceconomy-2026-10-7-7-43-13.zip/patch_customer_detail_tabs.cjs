const fs = require('fs');
let code = fs.readFileSync('components/admin/CustomerDetail.tsx', 'utf8');

const runSimulationMethod = `
  const handleRunSimulation = async () => {
    if (!customer) return;
    setIsSimulating(true);
    setSimResult(null);
    try {
      const policies = await fetchLatestPolicyData();
      
      const profile: UserProfile = {
        name: customer.ceoName || '고객',
        businessName: customer.businessName || '사업장',
        businessRegistrationNumber: '',
        businessAddress: customer.address || '',
        businessType: customer.businessType === '법인' ? BusinessType.CORPORATION : BusinessType.INDIVIDUAL,
        industry: Industry.SERVICE, // fallback
        location: customer.province || '전국',
        foundedYear: customer.openDate ? customer.openDate.split('-')[0] : new Date().getFullYear().toString(),
        annualRevenue: simRevenue,
        creditScore: simCredit,
        employees: customer.employeeCount || 0,
        fundingNeed: 50000000,
        expectedProfitMargin: 15,
        cashFlowStatus: 70,
        debt1Tier: 0,
        debt2Tier: 0,
        debtCardLoan: 0,
        debtOther: 0,
        isMyDataLinked: true
      };

      const result = await analyzePolicyMatching(profile, policies);
      setSimResult(result);
    } catch (e) {
      console.error(e);
      alert('시뮬레이션 중 오류가 발생했습니다.');
    } finally {
      setIsSimulating(false);
    }
  };

  return (
`;

code = code.replace("  return (", runSimulationMethod);

const tabHeadersTarget = `        <button
          onClick={() => setActiveTab('consultation')}
          className={\`pb-4 px-2 font-bold text-sm transition-colors border-b-2 \${activeTab === 'consultation' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-800'}\`}
        >
          <MessageCircle className="w-4 h-4 inline-block mr-2" />
          상담기록 (Sheet 4)
        </button>
      </div>`;

const tabHeadersReplacement = `        <button
          onClick={() => setActiveTab('consultation')}
          className={\`pb-4 px-2 font-bold text-sm transition-colors border-b-2 \${activeTab === 'consultation' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-500 hover:text-slate-800'}\`}
        >
          <MessageCircle className="w-4 h-4 inline-block mr-2" />
          상담기록 (Sheet 4)
        </button>
        <button
          onClick={() => setActiveTab('simulation')}
          className={\`pb-4 px-2 font-bold text-sm transition-colors border-b-2 \${activeTab === 'simulation' ? 'border-amber-500 text-amber-600' : 'border-transparent text-slate-500 hover:text-slate-800'}\`}
        >
          <Sparkles className="w-4 h-4 inline-block mr-2 text-amber-500" />
          상담원 전용 시뮬레이션
        </button>
      </div>`;

code = code.replace(tabHeadersTarget, tabHeadersReplacement);

const simTabTarget = `            {/* Consultation Tab */}
            {activeTab === 'consultation' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-bold text-lg text-slate-800">상담 기록</h3>
                  <button onClick={() => setShowConModal(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-indigo-700">
                    <Plus className="w-4 h-4" /> 추가
                  </button>
                </div>
                <ConsultationTimeline consultations={consultations} />
              </div>
            )}`;

const simTabReplacement = `            {/* Consultation Tab */}
            {activeTab === 'consultation' && (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-bold text-lg text-slate-800">상담 기록</h3>
                  <button onClick={() => setShowConModal(true)} className="bg-indigo-600 text-white px-4 py-2 rounded-xl text-sm font-bold flex items-center gap-2 hover:bg-indigo-700">
                    <Plus className="w-4 h-4" /> 추가
                  </button>
                </div>
                <ConsultationTimeline consultations={consultations} />
              </div>
            )}
            
            {/* Simulation Tab */}
            {activeTab === 'simulation' && (
              <div className="animate-fade-in">
                <div className="bg-amber-50 border border-amber-200 rounded-3xl p-6 mb-8">
                  <h3 className="text-xl font-black text-amber-900 mb-4 flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-amber-500" />
                    AI 정책자금 추천 시뮬레이션
                  </h3>
                  <p className="text-amber-700 text-sm mb-6">
                    현재 고객({customer?.ceoName})의 예상 매출과 신용점수를 입력하여, 어떤 정책자금이 추천될지 상담 전에 미리 테스트해 볼 수 있습니다.
                  </p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                    <div>
                      <label className="block text-sm font-bold text-amber-900 mb-2">예상 연 매출액 (원)</label>
                      <input 
                        type="number" 
                        value={simRevenue} 
                        onChange={e => setSimRevenue(Number(e.target.value))} 
                        className="w-full p-3 rounded-xl border-amber-200 focus:border-amber-500 focus:ring-amber-500"
                        step="1000000"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-amber-900 mb-2">예상 신용점수</label>
                      <input 
                        type="number" 
                        value={simCredit} 
                        onChange={e => setSimCredit(Number(e.target.value))} 
                        className="w-full p-3 rounded-xl border-amber-200 focus:border-amber-500 focus:ring-amber-500"
                        min="0" max="1000"
                      />
                    </div>
                  </div>
                  
                  <button 
                    onClick={handleRunSimulation}
                    disabled={isSimulating}
                    className="w-full sm:w-auto px-6 py-3 bg-amber-500 hover:bg-amber-600 text-white font-bold rounded-xl flex items-center justify-center gap-2 transition-colors disabled:opacity-70"
                  >
                    {isSimulating ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
                    {isSimulating ? '시뮬레이션 분석 중...' : '시뮬레이션 실행'}
                  </button>
                </div>

                {simResult && (
                  <div className="border-t border-slate-200 pt-8 mt-8">
                    <h4 className="text-lg font-black text-slate-800 mb-6">시뮬레이션 결과</h4>
                    <div className="scale-95 origin-top">
                      <ResultDashboard 
                        result={simResult} 
                        onReset={() => setSimResult(null)}
                      />
                    </div>
                  </div>
                )}
              </div>
            )}`;

code = code.replace(simTabTarget, simTabReplacement);

fs.writeFileSync('components/admin/CustomerDetail.tsx', code);
