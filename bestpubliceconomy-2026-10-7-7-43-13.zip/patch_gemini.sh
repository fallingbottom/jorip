sed -i '/export const enhanceDocumentSectionAI/i \
export const generateTailoredApplicationGuide = async (\
  profile: UserProfile | null,\
  fund: PolicyFund | null\
): Promise<{\
  customProcedure: { step: number; title: string; detail: string; estimatedDays: string }[];\
  documentChecklist: { name: string; required: boolean; issuePlace: string; tip: string }[];\
  writingExample: {\
    businessOverview: string;\
    usagePlan: string;\
    repaymentPlan: string;\
  };\
  expertTip: string;\
}> => {\
  const bName = profile?.businessName || "대한상사";\
  const cName = profile?.name || "홍길동";\
  const indStr = profile?.industry ? profile.industry : "해당 업종";\
  const revWon = profile?.annualRevenue || 120000000;\
  const revMillion = Math.round(revWon / 1000000);\
  const fundTitle = fund?.title || "소상공인 정책자금";\
  const agency = fund?.agency || "관할 기관";\
\
  try {\
    const key = getApiKey();\
    const ai = new GoogleGenAI({ apiKey: key });\
    const systemPrompt = `\
당신은 중소벤처기업부 및 소상공인시장진흥공단의 최고 정책자금 컨설턴트입니다.\
사용자의 사업체 정보와 신청하려는 정책자금 정보를 바탕으로 [신청 절차, 필요 서류 목록, 사업계획서 작성 예시]를 사용자 맞춤형으로 꼼꼼하게 작성해주세요.\
\
[기업 정보]\
- 상호: ${bName}\
- 대표자: ${cName}\
- 업종: ${indStr}\
- 연매출: ${revMillion}백만원\
\
[신청 정책자금]\
- 자금명: ${fundTitle}\
- 주관기관: ${agency}\
\
반드시 아래 JSON 형식으로만 응답하세요:\
\`\`\`json\
{\
  "customProcedure": [\
    { "step": 1, "title": "온라인 자가진단", "detail": "소상공인정책자금 사이트에서 자가진단 수행", "estimatedDays": "당일" }\
  ],\
  "documentChecklist": [\
    { "name": "사업자등록증명원", "required": true, "issuePlace": "국세청 홈택스", "tip": "최근 1개월 이내 발급분" }\
  ],\
  "writingExample": {\
    "businessOverview": "당사는 ~을 주력으로 하는 업체로...",\
    "usagePlan": "본 자금은 ~의 용도로 사용할 계획임...",\
    "repaymentPlan": "매출 증가분과 ~을 통해 상환 재원을 마련할 예정임..."\
  },\
  "expertTip": "신청 시 유의사항 등 전문가 팁 1~2문장"\
}\
\`\`\`\
`;\
    const response = await ai.models.generateContent({\
      model: 'gemini-2.5-flash',\
      contents: [{ role: 'user', parts: [{ text: "가이드를 생성해주세요." }] }],\
      config: {\
        systemInstruction: systemPrompt,\
        temperature: 0.2,\
        responseMimeType: "application/json"\
      }\
    });\
    const responseText = response.text() || "{}";\
    return JSON.parse(responseText);\
  } catch (error) {\
    console.error("Guide Generation Error:", error);\
    throw error;\
  }\
};\
'
sh patch_gemini.sh
