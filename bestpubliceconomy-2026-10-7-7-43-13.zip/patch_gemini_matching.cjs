const fs = require('fs');
let code = fs.readFileSync('services/geminiService.ts', 'utf8');

const importStr = `import { filterAndScorePolicies } from './matchingAlgorithm';\n`;

// Insert import at top if not there
if (!code.includes('filterAndScorePolicies')) {
  code = importStr + code;
}

const matchFn = `export const analyzePolicyMatching = async (
  profile: UserProfile, 
  latestPolicies: SourcePolicy[], 
  feedback?: ReanalysisFeedback
): Promise<AnalysisResult> => {
  const ai = new GoogleGenAI({ apiKey: getApiKey() });

  // 1. Run strict rule-based filtering and scoring
  const scoredPolicies = filterAndScorePolicies(profile, latestPolicies);
  const topMatches = scoredPolicies.filter(p => p.matchScore >= 50).slice(0, 5); // Take top 5 eligible

  // 2. Create a context string from the real-time policy data AND their algorithmic scores
  const policyContext = topMatches.map(p => 
    \അ- \${p.name} (\${p.agency}):
      * Base Rate: \${p.baseInterestRate}
      * Status: \${p.currentStatus}
      * Budget Exhaustion: \${p.budgetExhaustionRate || 0}%
      * Algorithmic Match Score: \${p.matchScore}/100
      * Algorithmic Match Reasons: \${p.matchReasons.join(', ')}
      * Eligibility: \${p.eligibility || 'N/A'}
      * Repayment: \${p.repaymentPeriod || 'N/A'}
      * Max Amount: \${p.maxAmount || 'N/A'}
      * Description: \${p.description || 'N/A'}
      * Contact: \${p.contactInfo || 'N/A'}\അ
  ).join('\\n\\n');`;

// Replace everything from export const analyzePolicyMatching = async ( ... down to policyContext = ... ).join('\n');
code = code.replace(/export const analyzePolicyMatching = async \([\s\S]*?\)\.join\('\\n'\);/m, matchFn.replace(/\\അ/g, '`'));

fs.writeFileSync('services/geminiService.ts', code);
