const fs = require('fs');
let code = fs.readFileSync('services/fundDataSource.ts', 'utf8');

// I'll define constraints for some known funds:
// 1. 일반경영안정자금
code = code.replace('name: "일반경영안정자금",', 'name: "일반경영안정자금",\n      matchConstraints: { maxEmployees: 5, maxRevenue: 3000000000 },');
// 2. 신용취약소상공인자금
code = code.replace('name: "신용취약소상공인자금",', 'name: "신용취약소상공인자금",\n      matchConstraints: { maxEmployees: 5 },'); // also minCreditScore? they usually target low credit
// 3. 소공인특화자금
code = code.replace('name: "소공인특화자금",', 'name: "소공인특화자금",\n      matchConstraints: { targetIndustries: ["MANUFACTURING"], maxEmployees: 10 },');
// 4. 청년고용연계자금
code = code.replace('name: "청년고용연계자금",', 'name: "청년고용연계자금",\n      matchConstraints: { minFoundedYears: 0 },');
// 5. 청년테크스타보증
code = code.replace('name: "청년테크스타보증",', 'name: "청년테크스타보증",\n      matchConstraints: { maxFoundedYears: 7 },');
// 6. 스타트업 NEST 보증
code = code.replace('name: "스타트업 NEST 보증",', 'name: "스타트업 NEST 보증",\n      matchConstraints: { maxFoundedYears: 3 },');

fs.writeFileSync('services/fundDataSource.ts', code);
