const fs = require('fs');
let code = fs.readFileSync('services/geminiService.ts', 'utf8');

const newPromptStr = `
  const prompt = \`
    You are an expert consultant for Korean government policy funds (소상공인 정책자금).
    We have ALREADY run a strict rule-based algorithm to find the top matching policy funds for this user.
    You MUST ONLY recommend the funds listed in "Real-time Policy Data (Top Algorithmic Matches)". Do not invent or recommend funds outside of this list unless specifically requested as a fallback.
    
    When generating the 'matchingReason' for each fund, YOU MUST incorporate the 'Algorithmic Match Reasons' provided in the context, expanding on them naturally for the user. Include details like eligibility, max amount, and repayment period based on the context data.

    User Profile:
    - Business: \${profile.businessName} (\${profile.name})
    - Type: \${mapEnumToKorean(profile.businessType)}
    - Industry: \${mapEnumToKorean(profile.industry)}
    - Location: \${profile.location}
    - Revenue: \${profile.annualRevenue} KRW
    - Founded Year (Business Duration): \${profile.foundedYear}
    - Credit Score: \${profile.creditScore}
    - Employees: \${profile.employees}
    - Funding Need: \${profile.fundingNeed} KRW
    - Metrics: Profit Margin \${profile.expectedProfitMargin}%, Cash Flow Score \${profile.cashFlowStatus}
    - Debt: 1st Tier \${profile.debt1Tier}, 2nd Tier \${profile.debt2Tier}, Card/Capital \${profile.debtCardLoan}

    Real-time Policy Data (Top Algorithmic Matches):
    \${policyContext}
    \${feedbackPromptSection}
`;

// Replace from const prompt = ` down to ${feedbackPromptSection}
code = code.replace(/const prompt = `[\s\S]*?\$\{feedbackPromptSection\}/, newPromptStr.trim());

fs.writeFileSync('services/geminiService.ts', code);
