import sys

with open('components/ResultDashboard.tsx', 'r', encoding='utf8') as f:
    code = f.read()

# Add ArrowUpDown
code = code.replace(
    "Target, AlertTriangle, Share2\n} from 'lucide-react';",
    "Target, AlertTriangle, Share2, ArrowUpDown\n} from 'lucide-react';"
)

# Add state
state_target = "const [maxInterestRate, setMaxInterestRate] = useState<number>(10);"
code = code.replace(
    state_target,
    state_target + "\n  const [sortOption, setSortOption] = useState<string>('default');"
)

# Filter logic
old_filter = """  const filteredFunds = useMemo(() => {
    return result.matchedFunds.filter(fund => {
      const matchesSearch = 
        fund.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        fund.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        fund.agency.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory = selectedCategory === 'All' || fund.category === selectedCategory;
      const matchesAgency = selectedAgency === 'All' || fund.agency === selectedAgency;

      const fundMaxVal = parseKoreanAmount(fund.maxAmount);
      const matchesAmount = minLoanAmount === 0 || fundMaxVal >= minLoanAmount;

      const fundRateVal = parseInterestRate(fund.interestRate);
      const matchesInterest = maxInterestRate === 10 || fundRateVal <= maxInterestRate;
      
      return matchesSearch && matchesCategory && matchesAgency && matchesAmount && matchesInterest;
    });
  }, [result.matchedFunds, searchQuery, selectedCategory, selectedAgency, minLoanAmount, maxInterestRate]);"""

new_filter = """  const filteredFunds = useMemo(() => {
    let resultFunds = result.matchedFunds.filter(fund => {
      const matchesSearch = 
        fund.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        fund.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        fund.agency.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesCategory = selectedCategory === 'All' || fund.category === selectedCategory;
      const matchesAgency = selectedAgency === 'All' || fund.agency === selectedAgency;

      const fundMaxVal = parseKoreanAmount(fund.maxAmount);
      const matchesAmount = minLoanAmount === 0 || fundMaxVal >= minLoanAmount;

      const fundRateVal = parseInterestRate(fund.interestRate);
      const matchesInterest = maxInterestRate === 10 || fundRateVal <= maxInterestRate;
      
      return matchesSearch && matchesCategory && matchesAgency && matchesAmount && matchesInterest;
    });

    if (sortOption !== 'default') {
      resultFunds = [...resultFunds].sort((a, b) => {
        if (sortOption === 'limit_desc') {
          return parseKoreanAmount(b.maxAmount) - parseKoreanAmount(a.maxAmount);
        } else if (sortOption === 'limit_asc') {
          return parseKoreanAmount(a.maxAmount) - parseKoreanAmount(b.maxAmount);
        } else if (sortOption === 'rate_asc') {
          return parseInterestRate(a.interestRate) - parseInterestRate(b.interestRate);
        } else if (sortOption === 'rate_desc') {
          return parseInterestRate(b.interestRate) - parseInterestRate(a.interestRate);
        } else if (sortOption === 'target_asc') {
          return a.eligibility.localeCompare(b.eligibility);
        } else if (sortOption === 'target_desc') {
          return b.eligibility.localeCompare(a.eligibility);
        }
        return 0;
      });
    }

    return resultFunds;
  }, [result.matchedFunds, searchQuery, selectedCategory, selectedAgency, minLoanAmount, maxInterestRate, sortOption]);"""

code = code.replace(old_filter, new_filter)

# Clear filters
old_clear = """  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedAgency('All');
    setMinLoanAmount(0);
    setMaxInterestRate(10);
  };"""

new_clear = """  const clearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedAgency('All');
    setMinLoanAmount(0);
    setMaxInterestRate(10);
    setSortOption('default');
  };"""
code = code.replace(old_clear, new_clear)

# isFiltered
old_is_filtered = "const isFiltered = searchQuery !== '' || selectedCategory !== 'All' || selectedAgency !== 'All' || minLoanAmount !== 0 || maxInterestRate !== 10;"
new_is_filtered = "const isFiltered = searchQuery !== '' || selectedCategory !== 'All' || selectedAgency !== 'All' || minLoanAmount !== 0 || maxInterestRate !== 10 || sortOption !== 'default';"
code = code.replace(old_is_filtered, new_is_filtered)

# UI Dropdown
target_ui = """                      {categories.map(cat => (
                        <option key={cat} value={cat}>{cat === 'All' ? '전체 분야' : cat}</option>
                      ))}
                    </select>
                  </div>"""

sort_ui = """                      {categories.map(cat => (
                        <option key={cat} value={cat}>{cat === 'All' ? '전체 분야' : cat}</option>
                      ))}
                    </select>
                  </div>

                  {/* 정렬 필터 */}
                  <div className="md:col-span-6 lg:col-span-2 relative group">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none">
                      <ArrowUpDown className={`w-4 h-4 transition-colors ${sortOption !== 'default' ? 'text-blue-600' : 'text-slate-400'}`} />
                    </div>
                    <select 
                      value={sortOption}
                      onChange={(e) => setSortOption(e.target.value)}
                      className={`w-full pl-11 pr-8 py-3 rounded-2xl text-sm appearance-none outline-none border transition-all font-bold cursor-pointer ${
                        sortOption !== 'default' ? 'bg-blue-50 border-blue-200 text-blue-700' : 'bg-slate-50 border-slate-100 text-slate-600'
                      }`}
                    >
                      <option value="default">기본 추천순</option>
                      <option value="rate_asc">금리 낮은순</option>
                      <option value="rate_desc">금리 높은순</option>
                      <option value="limit_desc">한도 높은순</option>
                      <option value="limit_asc">한도 낮은순</option>
                      <option value="target_asc">지원대상 (가나다순)</option>
                      <option value="target_desc">지원대상 (역순)</option>
                    </select>
                  </div>"""

code = code.replace(target_ui, sort_ui)

with open('components/ResultDashboard.tsx', 'w', encoding='utf8') as f:
    f.write(code)

print("Done")
