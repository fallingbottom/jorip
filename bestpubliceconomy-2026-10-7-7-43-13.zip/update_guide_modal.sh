sed -i 's/import { PolicyFund } from '"'"'..\/types'"'"';/import { PolicyFund, UserProfile } from '"'"'..\/types'"'"';\nimport { generateTailoredApplicationGuide } from '"'"'..\/services\/geminiService'"'"';\nimport { Sparkles, Loader2, PenTool } from '"'"'lucide-react'"'"';/g' components/FundApplicationGuideModal.tsx
sed -i 's/fund: PolicyFund | null;/fund: PolicyFund | null;\n  profile: UserProfile | null;/g' components/FundApplicationGuideModal.tsx
sed -i 's/fund/fund,\n  profile/g' components/FundApplicationGuideModal.tsx
