sed -i 's/import {  } from/import { analyzePolicyMatching } from/g' components/admin/ConsultantDashboard.tsx
sed -i 's/import { \/\* @ts-ignore \*\/ analyzePolicyMatching } from/import { analyzePolicyMatching } from/g' components/admin/CustomerDetail.tsx
sed -i '/import { analyzePolicyMatching } from/i \/\/ @ts-ignore' components/admin/ConsultantDashboard.tsx components/admin/CustomerDetail.tsx
