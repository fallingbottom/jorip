cat << 'INNER_EOF' > replacement.txt
                          <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); setViewingOriginal(item); }}
                            className="p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                            title="공고 원문 보기"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={(e) => handleOpenRuleModal(item, 'view', e)}
                            className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                            title="JSON 정책 규칙 보기/수정"
                          >
                            <FileCode2 className="w-4 h-4" />
INNER_EOF

# Remove lines 1099-1111 and insert replacement.txt at line 1099
sed -i '1099,1111d' components/admin/AnnouncementCurationManager.tsx
sed -i '1098r replacement.txt' components/admin/AnnouncementCurationManager.tsx
