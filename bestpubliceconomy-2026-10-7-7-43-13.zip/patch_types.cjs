const fs = require('fs');
let code = fs.readFileSync('types.ts', 'utf8');

// SourcePolicy
code = code.replace(
  '  contactInfo?: string;',
  '  contactInfo?: string;\n  applicationUrl?: string;\n  requiredDocuments?: string[];'
);

// PolicyFund
code = code.replace(
  '  requiredDocuments: string[];',
  '  requiredDocuments: string[];\n  applicationUrl?: string;'
);

fs.writeFileSync('types.ts', code);
