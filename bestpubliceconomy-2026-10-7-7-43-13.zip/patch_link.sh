sed -i '/title="공고 원문 보기"/i \
                          {item.sourceUrl && (\
                            <a\
                              href={item.sourceUrl}\
                              target="_blank"\
                              rel="noopener noreferrer"\
                              onClick={(e) => e.stopPropagation()}\
                              className="p-1.5 text-slate-400 hover:text-cyan-600 hover:bg-cyan-50 rounded-lg transition-colors"\
                              title="공고 웹페이지 바로가기"\
                            >\
                              <ExternalLink className="w-4 h-4" />\
                            </a>\
                          )}' components/admin/AnnouncementCurationManager.tsx
