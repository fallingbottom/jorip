const fs = require('fs');
let code = fs.readFileSync('components/ResultDashboard.tsx', 'utf8');

// 1. Add motion import
const reactImport = "import React, { useState, useMemo } from 'react';";
if (!code.includes("import { motion } from 'motion/react';")) {
  code = code.replace(
    "import React, { useState, useMemo } from 'react';",
    "import React, { useState, useMemo } from 'react';\nimport { motion } from 'motion/react';"
  );
  if (code.indexOf("import { motion } from 'motion/react';") === -1) {
     // fallback if the import line was slightly different
     code = "import { motion } from 'motion/react';\n" + code;
  }
}

// 2. Wrap FundCard with motion.div
const targetMap = `                    filteredFunds.map((fund, idx) => {
                      const isFav = (favorites || []).some(item => {
                        const name = 'title' in item ? item.title : item.name;
                        return name === fund.title;
                      });
                      const isSelected = selectedFundIds.includes(fund.id || fund.title);
                      return (
                        <FundCard 
                          key={fund.id || idx} 
                          fund={fund} 
                          index={idx} 
                          isPrinting={false} 
                          onScheduleCalendar={user && token ? handleScheduleFundReminder : undefined} 
                          isFavorite={isFav}
                          onToggleFavorite={onToggleFavorite}
                          isSelected={isSelected}
                          onToggleSelect={handleToggleSelectFund}
                          onOpenPdfChecklist={setPdfChecklistFund}
                          onConfigurePush={(f) => {
                            setPushModalTarget(f);
                            setIsPushModalOpen(true);
                          }}
                          onOpenConsultation={handleOpenConsultation}
                          onOpenDeepLearningReport={handleOpenDeepLearningReport}
                          onOpenFormsModal={(f) => {
                            setFormsModalTarget(f);
                            setIsFormsModalOpen(true);
                          }}
                          profile={profile}
                        />
                      );
                    })`;

const replacementMap = `                    filteredFunds.map((fund, idx) => {
                      const isFav = (favorites || []).some(item => {
                        const name = 'title' in item ? item.title : item.name;
                        return name === fund.title;
                      });
                      const isSelected = selectedFundIds.includes(fund.id || fund.title);
                      return (
                        <motion.div
                          key={fund.id || idx}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.5, delay: idx * 0.1, ease: 'easeOut' }}
                        >
                          <FundCard 
                            fund={fund} 
                            index={idx} 
                            isPrinting={false} 
                            onScheduleCalendar={user && token ? handleScheduleFundReminder : undefined} 
                            isFavorite={isFav}
                            onToggleFavorite={onToggleFavorite}
                            isSelected={isSelected}
                            onToggleSelect={handleToggleSelectFund}
                            onOpenPdfChecklist={setPdfChecklistFund}
                            onConfigurePush={(f) => {
                              setPushModalTarget(f);
                              setIsPushModalOpen(true);
                            }}
                            onOpenConsultation={handleOpenConsultation}
                            onOpenDeepLearningReport={handleOpenDeepLearningReport}
                            onOpenFormsModal={(f) => {
                              setFormsModalTarget(f);
                              setIsFormsModalOpen(true);
                            }}
                            profile={profile}
                          />
                        </motion.div>
                      );
                    })`;

code = code.replace(targetMap, replacementMap);

fs.writeFileSync('components/ResultDashboard.tsx', code);
