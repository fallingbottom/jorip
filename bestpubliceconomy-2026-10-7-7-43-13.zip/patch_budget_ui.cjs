const fs = require('fs');
let code = fs.readFileSync('components/ResultDashboard.tsx', 'utf8');

const target1 = `  const isBudgetLow = fund.currentStatus === 'BUDGET_ALMOST_EXHAUSTED';`;
const replacement1 = `  const isBudgetLow = fund.currentStatus === 'BUDGET_ALMOST_EXHAUSTED' || (fund.budgetExhaustionRate !== undefined && fund.budgetExhaustionRate >= 80);`;

code = code.replace(target1, replacement1);

const target2 = `               {isBudgetLow && (
                 <span className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-black text-white bg-red-500 rounded-md shadow-md shadow-red-500/20 animate-pulse">
                   <Siren className="w-3.5 h-3.5" />
                   예산 소진 임박
                 </span>
               )}`;

const replacement2 = `               {isBudgetLow && (
                 <span className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-black text-white bg-red-500 rounded-md shadow-md shadow-red-500/20 animate-pulse" title={fund.budgetExhaustionRate ? \`소진율: \${fund.budgetExhaustionRate}%\` : ''}>
                   <Siren className="w-3.5 h-3.5" />
                   예산 소진 임박 {fund.budgetExhaustionRate ? \`(\${fund.budgetExhaustionRate}%)\` : ''}
                 </span>
               )}`;

code = code.replace(target2, replacement2);
fs.writeFileSync('components/ResultDashboard.tsx', code);
