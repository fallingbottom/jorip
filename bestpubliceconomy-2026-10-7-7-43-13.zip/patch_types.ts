import fs from 'fs';

const crmTypes = `

// Admin CRM Types
export interface CrmCustomer {
  id: string;
  displayId: string;
  userId: string;
  ceoName: string;
  businessName: string;
  industryName?: string;
  industryCode?: string;
  businessType?: string;
  province?: string;
  city?: string;
  address?: string;
  openDate?: string;
  employeeCount?: number;
  phone?: string;
  memo?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CrmFinancial {
  id: string;
  userId: string;
  customerId: string;
  year: number;
  vatRevenue?: number;
  cardRevenue?: number;
  cashRevenueEstimate?: number;
  incomeAmount?: number;
  creditScore?: number;
  creditGrade?: string;
  totalLoanBalance?: number;
  bizLoan?: number;
  cardLoan?: number;
  cashAdvance?: number;
  isOverdue?: 'Y' | 'N';
  isTaxArrears?: 'Y' | 'N';
  note?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CrmApplication {
  id: string;
  displayId: string;
  userId: string;
  customerId: string;
  applyDate: string;
  applyType: '직접대출' | '대리대출' | '보증';
  agency: string;
  productName: string;
  applyAmount: number;
  purpose: '운영자금' | '설비투자' | '인테리어' | '기존대출대환' | '세금납부' | '기타';
  status: '승인' | '부결' | '진행중' | '보류';
  approvedAmount?: number;
  interestRate?: number;
  guaranteeRatio?: number;
  reason?: string;
  followUp?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CrmConsultation {
  id: string;
  displayId: string;
  userId: string;
  customerId: string;
  consultDate: string;
  channel: '전화' | '대면' | '카톡' | '이메일' | '기타';
  primaryNeeds: string;
  primaryDiagnosis: string;
  nextStep: string;
  importantNote?: string;
  createdAt: string;
  updatedAt: string;
}
`;

let content = fs.readFileSync('types.ts', 'utf8');
content += crmTypes;
fs.writeFileSync('types.ts', content);
