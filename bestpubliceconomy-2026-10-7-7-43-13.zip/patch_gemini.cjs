const fs = require('fs');
let code = fs.readFileSync('services/geminiService.ts', 'utf8');

// Update policy context
code = code.replace(
  "`- ${p.name} (${p.agency}): Base Rate ${p.baseInterestRate}, Status: ${p.currentStatus}, Last Updated: ${p.lastUpdated}`",
  "`- ${p.name} (${p.agency}): Base Rate ${p.baseInterestRate}, Status: ${p.currentStatus}, Budget Exhaustion: ${p.budgetExhaustionRate || 0}%, Last Updated: ${p.lastUpdated}`"
);

// Add budgetExhaustionRate to properties
const propertiesTarget = `            repaymentPeriod: { type: Type.STRING },
          },
          required: ["id", "title", "agency", "category", "maxAmount", "interestRate", "description", "eligibility", "applicationDeadline", "contactInfo", "requiredDocuments", "currentStatus", "applicationProcedure", "writingGuide", "announcementDate", "startDate", "endDate", "repaymentPeriod"],`;
const propertiesReplacement = `            repaymentPeriod: { type: Type.STRING },
            budgetExhaustionRate: { type: Type.INTEGER },
          },
          required: ["id", "title", "agency", "category", "maxAmount", "interestRate", "description", "eligibility", "applicationDeadline", "contactInfo", "requiredDocuments", "currentStatus", "applicationProcedure", "writingGuide", "announcementDate", "startDate", "endDate", "repaymentPeriod"],`;
code = code.replace(propertiesTarget, propertiesReplacement);

const similarPropertiesTarget = `            description: { type: Type.STRING },
            basedOnFundName: { type: Type.STRING },
          },
          required: ["id", "title", "agency", "category", "maxAmount", "interestRate", "similarityReason", "matchScore", "eligibility", "applicationDeadline", "description", "basedOnFundName"],`;
const similarPropertiesReplacement = `            description: { type: Type.STRING },
            basedOnFundName: { type: Type.STRING },
            budgetExhaustionRate: { type: Type.INTEGER },
          },
          required: ["id", "title", "agency", "category", "maxAmount", "interestRate", "similarityReason", "matchScore", "eligibility", "applicationDeadline", "description", "basedOnFundName"],`;
code = code.replace(similarPropertiesTarget, similarPropertiesReplacement);


fs.writeFileSync('services/geminiService.ts', code);
