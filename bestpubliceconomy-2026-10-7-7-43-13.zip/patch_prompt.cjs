const fs = require('fs');
let code = fs.readFileSync('services/geminiService.ts', 'utf8');

const target = `    당신은 대한민국 중소벤처기업부 및 소상공인시장진흥공단 정책 전문 AI 분석관입니다.
    Google Search를 실시간으로 활용하여, 아래 사업자의 [지역]과 [업종]에 가장 밀접한 최신 소상공인 지원 정책 뉴스, 정부/지자체 지원 공고, 금융·보조금 혜택 및 법령·제도 개편 정보를 검색하고 분석해주세요.`;

const replacement = `    당신은 대한민국 기획재정부 등 주요 경제 부처와 중소벤처기업부 정책 전문 AI 분석관입니다.
    Google Search를 실시간으로 활용하여, 기획재정부, 금융위원회 등 주요 경제 부처 및 중소벤처기업부의 최신 정책 보도자료를 수집하고, 아래 사업자의 [지역]과 [업종]에 가장 밀접한 최신 소상공인 지원 정책 뉴스, 정부/지자체 지원 공고, 금융·보조금 혜택 및 법령·제도 개편 정보를 검색하고 분석해주세요.`;

code = code.replace(target, replacement);

const target2 = `1. 2025년~2026년 최신 소상공인 정책 공고, 중소벤처기업부, 소상공인시장진흥공단(소진공), 신용보증재단중앙회, 해당 지자체`;
const replacement2 = `1. 2025년~2026년 최신 소상공인 정책 공고, 기획재정부, 금융위원회, 중소벤처기업부, 소상공인시장진흥공단(소진공), 신용보증재단중앙회, 해당 지자체`;

code = code.replace(target2, replacement2);

fs.writeFileSync('services/geminiService.ts', code);
