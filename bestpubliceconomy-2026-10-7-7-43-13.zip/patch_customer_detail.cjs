const fs = require('fs');
let code = fs.readFileSync('components/admin/CustomerDetail.tsx', 'utf8');

const importTarget = `import { getFinancials, addFinancial, getApplications, addApplication, getConsultations, addConsultation } from '../../services/crmService';`;
const importReplacement = `import { getCustomer, getFinancials, addFinancial, getApplications, addApplication, getConsultations, addConsultation } from '../../services/crmService';
import { CrmCustomer, UserProfile, BusinessType, Industry, AnalysisResult } from '../../types';
import { analyzePolicyMatching } from '../../services/geminiService';
import { fetchLatestPolicyData } from '../../services/fundDataSource';
import { ResultDashboard } from '../ResultDashboard';
import { Sparkles, Loader2 } from 'lucide-react';`;
code = code.replace(importTarget, importReplacement);

const stateTarget = `  const [activeTab, setActiveTab] = useState<'financial' | 'application' | 'consultation'>('financial');`;
const stateReplacement = `  const [activeTab, setActiveTab] = useState<'financial' | 'application' | 'consultation' | 'simulation'>('financial');
  const [customer, setCustomer] = useState<CrmCustomer | null>(null);
  
  // Simulation States
  const [simRevenue, setSimRevenue] = useState(0);
  const [simCredit, setSimCredit] = useState(700);
  const [simResult, setSimResult] = useState<AnalysisResult | null>(null);
  const [isSimulating, setIsSimulating] = useState(false);`;
code = code.replace(stateTarget, stateReplacement);

const loadDataTarget = `      const [fins, apps, cons] = await Promise.all([
        getFinancials(customerId),
        getApplications(customerId),
        getConsultations(customerId)
      ]);
      setFinancials(fins);`;
const loadDataReplacement = `      const [cust, fins, apps, cons] = await Promise.all([
        getCustomer(customerId),
        getFinancials(customerId),
        getApplications(customerId),
        getConsultations(customerId)
      ]);
      if (cust) setCustomer(cust);
      setFinancials(fins);
      if (fins.length > 0) {
        setSimRevenue(fins[0].vatRevenue || 0);
        setSimCredit(fins[0].creditScore || 700);
      }`;
code = code.replace(loadDataTarget, loadDataReplacement);

fs.writeFileSync('components/admin/CustomerDetail.tsx', code);
