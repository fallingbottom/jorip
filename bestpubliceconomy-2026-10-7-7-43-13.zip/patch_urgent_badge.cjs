const fs = require('fs');
let code = fs.readFileSync('components/PersonalDashboard.tsx', 'utf8');

const target1 = `  const upcomingDeadlinesCount = favorites.filter(item => {
    const endDate = 'endDate' in item ? item.endDate : ('applicationDeadline' in item ? item.applicationDeadline : '');
    const days = calculateDaysRemaining(String(endDate || ''));
    return days >= 0 && days <= 7;
  }).length;`;

const replacement1 = `  const upcomingDeadlinesCount = favorites.filter(item => {
    const endDate = 'endDate' in item ? item.endDate : ('applicationDeadline' in item ? item.applicationDeadline : '');
    const days = calculateDaysRemaining(String(endDate || ''));
    return days >= 0 && days <= 7;
  }).length;
  
  const urgentDeadlineFunds = favorites.filter(item => {
    const endDate = 'endDate' in item ? item.endDate : ('applicationDeadline' in item ? item.applicationDeadline : '');
    const days = calculateDaysRemaining(String(endDate || ''));
    return days >= 0 && days <= 3;
  });`;

code = code.replace(target1, replacement1);

const target2 = `      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-900 rounded-3xl p-6 md:p-8 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">`;

const replacement2 = `      {urgentDeadlineFunds.length > 0 && (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-4 mb-6 shadow-sm flex items-start sm:items-center gap-3 animate-fade-in print:hidden">
          <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center flex-shrink-0 animate-pulse">
            <AlertTriangle className="w-5 h-5 text-red-600" />
          </div>
          <div className="flex-1">
            <h3 className="text-red-800 font-black text-sm mb-0.5">⚠️ 마감 임박 (3일 이내) 자금이 있습니다!</h3>
            <p className="text-red-600 text-xs font-medium">
              즐겨찾기한 자금 중 <span className="font-bold underline">{urgentDeadlineFunds.length}건</span>의 신청 기한이 3일 이내로 다가왔습니다. 서둘러 확인해주세요.
            </p>
          </div>
          <button 
            onClick={() => {
              const el = document.getElementById('scraps-section');
              if (el) el.scrollIntoView({ behavior: 'smooth' });
            }}
            className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg transition-colors flex-shrink-0"
          >
            바로가기
          </button>
        </div>
      )}
      
      {/* Personalized Header Banner */}
      <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-blue-900 rounded-3xl p-6 md:p-8 text-white shadow-2xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">`;

code = code.replace(target2, replacement2);

fs.writeFileSync('components/PersonalDashboard.tsx', code);
