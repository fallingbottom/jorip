const fs = require('fs');
let code = fs.readFileSync('services/geminiService.ts', 'utf8');

const promptDupe = `    - Province/City (location) - Based on the address, determine the major province/city and map exactly to one of these: '서울', '경기', '인천', '부산', '대구', '광주', '대전', '울산', '강원', '충북', '충남', '전북', '전남', '경북', '경남', '제주'.
    - Province/City (location) - Based on the address, determine the major province/city and map exactly to one of these: '서울', '경기', '인천', '부산', '대구', '광주', '대전', '울산', '강원', '충북', '충남', '전북', '전남', '경북', '경남', '제주'.`;

const promptFixed = `    - Province/City (location) - Based on the address, determine the major province/city and map exactly to one of these: '서울', '경기', '인천', '부산', '대구', '광주', '대전', '울산', '강원', '충북', '충남', '전북', '전남', '경북', '경남', '제주'.`;

code = code.replace(promptDupe, promptFixed);

fs.writeFileSync('services/geminiService.ts', code);
