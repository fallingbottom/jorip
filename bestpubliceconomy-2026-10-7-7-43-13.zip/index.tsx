import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

// Global error sanitizer for external scripts such as Google Maps Platform
if (typeof window !== 'undefined') {
  const originalConsoleError = console.error;
  console.error = function (...args: any[]) {
    const fullText = args.map(a => (typeof a === 'string' ? a : (a?.message || ''))).join(' ');
    if (
      fullText.includes('ApiNotActivatedMapError') ||
      fullText.includes('api-not-activated-map-error') ||
      fullText.includes('Google Maps JavaScript API error') ||
      fullText.includes('InvalidKeyMapError') ||
      fullText.includes('RESOURCE_EXHAUSTED') ||
      fullText.includes('exceeded your current quota') ||
      fullText.includes('rate-limits') ||
      fullText.includes('Failed to fetch realtime policy news')
    ) {
      console.warn('[Handled Notice] External API quota or service limitation handled gracefully:', fullText);
      try {
        if (fullText.includes('MapError')) {
          window.dispatchEvent(new CustomEvent('gmp:api-not-activated', { detail: { message: fullText } }));
        }
      } catch {}
      return;
    }
    originalConsoleError.apply(console, args);
  };
}

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);